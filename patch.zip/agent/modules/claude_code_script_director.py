"""
Claude Code backend for Script Director.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional, Tuple, Any

import config
from modules.claude_code_runner import ClaudeCodeRunner
from modules.script_director import GeminiScriptDirector


class _ClaudeTextResponse:
    def __init__(self, text: str):
        self.text = text


def _extract_result_text(stdout: str) -> str:
    for line in reversed([l.strip() for l in stdout.splitlines() if l.strip()]):
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            continue
        for key in ('result', 'text', 'message', 'content'):
            val = data.get(key)
            if isinstance(val, str) and val.strip():
                return val
    return stdout.strip()


class ClaudeCodeScriptDirector(GeminiScriptDirector):
    def __init__(self, model_name: Optional[str] = None):
        self.model_name = model_name or config.CLAUDE_MODEL
        self.input_tokens = 0
        self.output_tokens = 0
        self.runner = ClaudeCodeRunner(self.model_name, config.CLAUDE_DIRECTOR_TIMEOUT)
        self._working_dir = Path.cwd()
        self._call_idx = 0

    def analyze(self, *args, **kwargs):
        output_dir = kwargs.get('output_dir')
        if output_dir is None and len(args) >= 3:
            output_dir = args[2]
        if output_dir:
            self._working_dir = Path(output_dir)
            self._working_dir.mkdir(parents=True, exist_ok=True)
        return super().analyze(*args, **kwargs)

    def _make_api_call(
        self,
        prompt: str,
        pass2_mode: bool = False,
        spinner_msg: str = "Claude Code думает",
        system_instruction: str = '',
    ) -> Tuple[Any, Optional[dict]]:
        self._call_idx += 1
        task_file = self._working_dir / f'_claude_script_call_{self._call_idx}.md'
        task_file.write_text(
            f"""# System Instruction
{system_instruction}

# User Task
{prompt}

# Output
Return the requested content in the exact format requested by the task.
""",
            encoding='utf-8',
        )
        _rc, stdout, stderr, _elapsed = self.runner.run_task_file(
            task_file=task_file,
            working_dir=self._working_dir,
            label=f"Script {self._call_idx}",
        )
        text = _extract_result_text(stdout)
        if not text:
            raise RuntimeError(f"Claude Code вернул пустой ответ\nstderr: {stderr[-1200:]}")
        return _ClaudeTextResponse(text), None

