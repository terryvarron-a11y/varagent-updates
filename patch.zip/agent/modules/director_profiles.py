"""Shared helpers for non-standard Director behavior profiles."""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


def normalize_director_profile(value: str | None) -> str:
    profile = (value or "standard").strip().lower()
    if profile not in {"standard", "auto_visual_story"}:
        raise ValueError(f"Unknown director profile: {profile}")
    return profile


def parse_json_response(raw: str) -> dict[str, Any]:
    text = (raw or "").strip()
    fenced = re.search(r"```(?:json)?\s*(.*?)```", text, re.DOTALL | re.IGNORECASE)
    if fenced:
        text = fenced.group(1).strip()
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start < 0 or end <= start:
            raise ValueError("Director profile transport returned no JSON object")
        payload = json.loads(text[start:end + 1])
    if not isinstance(payload, dict):
        raise ValueError("Director profile response must be a JSON object")
    return payload


def coerce_json_list(value: Any, field_name: str) -> list[Any]:
    """Accept an API field as a JSON list or a string-serialized JSON list."""
    if isinstance(value, str):
        text = value.strip()
        try:
            value = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ValueError(
                f"Director profile field {field_name!r} is not a JSON list"
            ) from exc
    if not isinstance(value, list):
        raise ValueError(
            f"Director profile field {field_name!r} must be a list, "
            f"got {type(value).__name__}"
        )
    return value


class DirectorProfileTransport:
    """Use the already-selected standard Director instance as a JSON transport."""

    def __init__(self, director: Any, project_dir: str | Path):
        self.director = director
        self.project_dir = Path(project_dir).resolve()
        self.raw_dir = self.project_dir / "visual_story" / "raw"
        self.raw_dir.mkdir(parents=True, exist_ok=True)

    @property
    def provider_label(self) -> str:
        provider = getattr(self.director, "provider", "")
        model = getattr(self.director, "model_name", "")
        return "/".join(part for part in (provider, model) if part) or type(self.director).__name__

    def call_json(
        self,
        *,
        phase: str,
        prompt: str,
        schema_file: str,
    ) -> dict[str, Any]:
        result_path = self.raw_dir / f"{phase}_result.json"

        if hasattr(self.director, "_chat"):
            raw = self.director._chat(
                [{"role": "user", "content": prompt}],
                json_mode=True,
            )
            (self.raw_dir / f"{phase}_response.txt").write_text(
                raw or "", encoding="utf-8"
            )
            payload = parse_json_response(raw)
        elif hasattr(self.director, "_run_codex"):
            payload = self.director._run_codex(
                prompt,
                schema_file,
                result_path,
                self.project_dir,
            )
        elif hasattr(self.director, "_make_api_call"):
            response, _cost = self.director._make_api_call(
                prompt,
                spinner_msg=f"Visual Story: {phase}",
            )
            raw = getattr(response, "text", "") or ""
            (self.raw_dir / f"{phase}_response.txt").write_text(
                raw, encoding="utf-8"
            )
            payload = parse_json_response(raw)
        else:
            raise TypeError(
                f"Unsupported Director transport: {type(self.director).__name__}"
            )

        result_path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return payload
