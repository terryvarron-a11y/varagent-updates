# Context Builder selective integration

Date: 2026-08-18

## Scope

- Added deterministic `agent/modules/visual_context.py`.
- Added unit coverage in `agent/test_visual_context.py`.
- Real Photo/EPF query cards now receive compact neighboring context.
- Stock query cards now receive the same compact context.
- YouTube query planning and Vision ranking now receive the Auto Visual Story
  context packet for the scene, including chapter/entity state and neighboring
  scenes. The packet is saved as `youtube/clips/NNN/context.json`.
- Existing Auto Visual Story seed queries are preserved and passed into the
  YouTube planner instead of being silently replaced by a generic scene-only
  query.
- Existing facts are copied only when already present in `montage_plan.json`;
  the builder does not invent entities or resolve narration by itself.
- Context is limited to disambiguation and continuity. Neighboring narration is
  explicitly not copied into the final search query.

## Explicit non-scope

- No changes to `agent/modules/imggen.py`.
- No changes to `agent/modules/gpt_director.py`.
- No changes to `agent/prompts/gpt_director_pass2.txt`.
- No ImageGen prompt validation, enrichment, or contract changes.
- No PORTABLE sync was performed. API remains the only modified tree pending
  user testing.

## Verification

- `python -m pytest test_visual_context.py test_image_claims.py -q`
  -> 5 passed.
- `python -m pytest test_youtube_stage_sources.py test_visual_context.py -q`
  -> 24 passed.
- `python -m py_compile modules/visual_context.py modules/real_photo.py modules/stock_stage.py modules/stock_prompter.py`
  -> passed.
- `python -m py_compile modules/youtube_stage.py test_youtube_stage_sources.py`
  -> passed.
- Backup:
  `VARAGENT_API/_backup_context_builder_20260819_013306`
- Additional backup:
  `VARAGENT_API/_backup_youtube_context_20260820_093000`
