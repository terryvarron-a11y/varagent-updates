#!/bin/bash
# SCENAGENT RTG - Auto Installer for macOS
# Run: double-click this file in Finder

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Auto-set execute permissions
chmod +x *.command 2>/dev/null
[ -f "$SCRIPT_DIR/.venv/bin/activate" ] && source "$SCRIPT_DIR/.venv/bin/activate"

PYTHON_CMD="python3"

echo ""
echo "================================================================================"
echo " SCENAGENT RTG - AUTO INSTALLER (macOS)"
echo "================================================================================"
echo ""

# ============================================================================
# HELPER: activate Homebrew in current shell session
# ============================================================================
_brew_activate() {
    if [ -f /opt/homebrew/bin/brew ]; then
        eval "$(/opt/homebrew/bin/brew shellenv)"
    elif [ -f /usr/local/bin/brew ]; then
        eval "$(/usr/local/bin/brew shellenv)"
    fi
}

# ============================================================================
# HELPER: install Homebrew if missing
# ============================================================================
_ensure_brew() {
    _brew_activate
    if command -v brew &>/dev/null; then
        return 0
    fi
    echo " Homebrew not found. Installing Homebrew..."
    echo " (will request administrator password)"
    echo ""
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    _brew_activate
    if ! command -v brew &>/dev/null; then
        echo " [ERROR] Failed to install Homebrew."
        echo "   Download manually: https://brew.sh"
        exit 1
    fi
    echo ""
    echo " [OK] Homebrew installed"
}

# ============================================================================
# 1. PYTHON3
# ============================================================================
echo "[1/4] Python3..."

MIN_PY_MAJOR=3
MIN_PY_MINOR=10

PYVER=$(python3 --version 2>&1)
if [ $? -eq 0 ]; then
    # Check minimum version (need 3.10+ for google-genai)
    PY_MAJOR=$(python3 -c "import sys; print(sys.version_info.major)" 2>/dev/null)
    PY_MINOR=$(python3 -c "import sys; print(sys.version_info.minor)" 2>/dev/null)
    if [ -n "$PY_MAJOR" ] && [ -n "$PY_MINOR" ]; then
        if [ "$PY_MAJOR" -lt "$MIN_PY_MAJOR" ] || { [ "$PY_MAJOR" -eq "$MIN_PY_MAJOR" ] && [ "$PY_MINOR" -lt "$MIN_PY_MINOR" ]; }; then
            echo " [WARN] $PYVER is too old (need ${MIN_PY_MAJOR}.${MIN_PY_MINOR}+)"
            echo " Installing newer Python via Homebrew..."
            echo ""
            _ensure_brew
            brew install python@3.12
            _brew_activate
            # Prefer Homebrew python
            for p in /opt/homebrew/bin/python3 /usr/local/bin/python3; do
                if "$p" --version &>/dev/null; then
                    HB_MAJOR=$("$p" -c "import sys; print(sys.version_info.major)" 2>/dev/null)
                    HB_MINOR=$("$p" -c "import sys; print(sys.version_info.minor)" 2>/dev/null)
                    if [ "$HB_MAJOR" -ge "$MIN_PY_MAJOR" ] && [ "$HB_MINOR" -ge "$MIN_PY_MINOR" ]; then
                        PYTHON_CMD="$p"
                        break
                    fi
                fi
            done
            PYVER=$($PYTHON_CMD --version 2>&1)
            PY_MAJOR=$($PYTHON_CMD -c "import sys; print(sys.version_info.major)" 2>/dev/null)
            PY_MINOR=$($PYTHON_CMD -c "import sys; print(sys.version_info.minor)" 2>/dev/null)
            if [ "$PY_MAJOR" -lt "$MIN_PY_MAJOR" ] || { [ "$PY_MAJOR" -eq "$MIN_PY_MAJOR" ] && [ "$PY_MINOR" -lt "$MIN_PY_MINOR" ]; }; then
                echo " [ERROR] Could not install Python ${MIN_PY_MAJOR}.${MIN_PY_MINOR}+"
                echo "   Download manually: https://www.python.org/downloads/"
                exit 1
            fi
            echo " [OK] $PYVER (installed via Homebrew)"
        else
            echo " [OK] $PYVER"
        fi
    else
        echo " [OK] $PYVER"
    fi
else
    echo " python3 not found. Installing..."
    echo ""
    _ensure_brew
    brew install python3
    if [ $? -ne 0 ]; then
        echo " [ERROR] brew failed to install python3."
        echo "   Download manually: https://www.python.org/downloads/"
        exit 1
    fi
    _brew_activate
    if python3 --version &>/dev/null; then
        PYTHON_CMD="python3"
    else
        for p in /opt/homebrew/bin/python3 /usr/local/bin/python3; do
            if "$p" --version &>/dev/null; then
                PYTHON_CMD="$p"
                break
            fi
        done
    fi
    PYVER=$($PYTHON_CMD --version 2>&1)
    echo " [OK] $PYVER (installed via Homebrew)"
fi

# ============================================================================
# 2. PIP
# ============================================================================
echo ""
echo "[2/4] pip..."

# Убедимся что Homebrew в PATH
_brew_activate

PIP_CMD=""
# 1. python3 -m pip
if $PYTHON_CMD -m pip --version &>/dev/null 2>&1; then
    PIP_CMD="$PYTHON_CMD -m pip"
fi
# 2. pip3 в PATH или в типичных Homebrew-путях
if [ -z "$PIP_CMD" ]; then
    for _pip in pip3 /opt/homebrew/bin/pip3 /usr/local/bin/pip3; do
        if "$_pip" --version &>/dev/null 2>&1; then
            PIP_CMD="$_pip"
            break
        fi
    done
fi
# 3. Попытка через ensurepip
if [ -z "$PIP_CMD" ]; then
    $PYTHON_CMD -m ensurepip --upgrade 2>/dev/null
    if $PYTHON_CMD -m pip --version &>/dev/null 2>&1; then
        PIP_CMD="$PYTHON_CMD -m pip"
    fi
fi
# 4. Установка pip через get-pip.py с --break-system-packages (Homebrew PEP 668)
if [ -z "$PIP_CMD" ]; then
    echo " Trying get-pip.py..."
    curl -fsSL https://bootstrap.pypa.io/get-pip.py -o /tmp/get-pip.py 2>/dev/null
    $PYTHON_CMD /tmp/get-pip.py --break-system-packages 2>/dev/null
    rm -f /tmp/get-pip.py
    if $PYTHON_CMD -m pip --version &>/dev/null 2>&1; then
        PIP_CMD="$PYTHON_CMD -m pip"
    fi
fi

if [ -z "$PIP_CMD" ]; then
    echo " [ERROR] Failed to find or install pip."
    exit 1
fi
echo " [OK] pip available"

# ============================================================================
# 3. PYTHON PACKAGES
# ============================================================================
echo ""
echo "[3/4] Python packages..."
echo ""

if [ ! -f "agent/requirements.txt" ]; then
    echo " [ERROR] agent/requirements.txt not found!"
    echo " Make sure you run install.command from the Var_Agent folder."
    exit 1
fi

echo " Installing packages from requirements.txt..."
$PIP_CMD install -r agent/requirements.txt 2>&1
if [ $? -ne 0 ]; then
    echo ""
    echo " Retrying with --break-system-packages (Homebrew Python)..."
    $PIP_CMD install --break-system-packages -r agent/requirements.txt
    if [ $? -ne 0 ]; then
        echo ""
        echo " [ERROR] Failed to install packages!"
        echo " Check internet connection and try again."
        echo ""
        echo " Alternative - install manually:"
        echo "   $PIP_CMD install --break-system-packages assemblyai google-genai python-dotenv tqdm httpx pydantic"
        exit 1
    fi
fi
echo ""
echo " [OK] All packages installed"

# ============================================================================
# 4. TKINTER
# ============================================================================
echo ""
echo "[4/5] tkinter..."

$PYTHON_CMD -c "import tkinter" 2>/dev/null
if [ $? -ne 0 ]; then
    echo " tkinter not found. Installing via Homebrew..."
    _ensure_brew
    # Determine exact python version for correct formula (e.g. python-tk@3.14)
    PY_VER_SHORT=$($PYTHON_CMD -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>/dev/null)
    brew install "python-tk@${PY_VER_SHORT}" 2>/dev/null || brew install python-tk
    $PYTHON_CMD -c "import tkinter" 2>/dev/null
    if [ $? -ne 0 ]; then
        echo " [ERROR] tkinter still not found."
        echo "   Try manually: brew install python-tk@${PY_VER_SHORT}"
        exit 1
    fi
    echo " [OK] tkinter installed"
else
    echo " [OK] tkinter available"
fi

# ============================================================================
# 5. FFMPEG
# ============================================================================
echo ""
echo "[5/5] FFmpeg..."

if ffmpeg -version &>/dev/null && ffprobe -version &>/dev/null; then
    echo " [OK] FFmpeg and ffprobe already installed"
else
    echo " FFmpeg or ffprobe not found. Installing via Homebrew..."
    echo ""
    _ensure_brew
    brew install ffmpeg
    if [ $? -ne 0 ]; then
        echo " [ERROR] brew failed to install FFmpeg."
        echo "   Try manually: brew install ffmpeg"
        exit 1
    fi
    _brew_activate
    if ! ffmpeg -version &>/dev/null || ! ffprobe -version &>/dev/null; then
        brew link --overwrite ffmpeg >/dev/null 2>&1 || true
        _brew_activate
    fi
    if ffmpeg -version &>/dev/null && ffprobe -version &>/dev/null; then
        echo " [OK] FFmpeg and ffprobe installed and working"
    else
        echo " [ERROR] Homebrew finished, but ffmpeg/ffprobe are unavailable."
        exit 1
    fi
fi

# ============================================================================
# .ENV FILE
# ============================================================================
echo ""
echo "================================================================================"
echo " Configuration (.env)..."
echo "================================================================================"

if [ ! -f "agent/.env" ]; then
    if [ -f "agent/.env.example" ]; then
        cp "agent/.env.example" "agent/.env"
        echo " [OK] Created agent/.env from template"
        echo ""
        echo " [!!!] API KEYS REQUIRED!"
        echo " Open agent/.env and fill in:"
        echo ""
        echo "   ASSEMBLYAI_API_KEY  = https://www.assemblyai.com/app/"
        echo "   GEMINI_API_KEY      = https://aistudio.google.com/app/apikey"
        echo "   FASTGEN_API_KEY     = https://fast-gen.ai"
        echo ""
    else
        echo " [WARN] agent/.env.example not found. Create agent/.env manually."
    fi
else
    echo " [OK] agent/.env already exists"
fi

# ============================================================================
# Make all .command scripts executable
# ============================================================================
echo ""
chmod +x "$SCRIPT_DIR"/*.command 2>/dev/null
echo " [OK] chmod +x *.command"

# ============================================================================
# DONE
# ============================================================================
echo ""
echo "================================================================================"
echo " INSTALLATION COMPLETE!"
echo "================================================================================"
echo ""
echo " Next steps:"
echo " 1. Open agent/.env and set your API keys"
echo " 2. Put audio file (.mp3/.wav/.m4a) in pipeline_queue/"
echo " 3. Add style guide to style_guides/ (filename: project.txt)"
echo " 4. Run: ./run_stage1_simple.command"
echo ""
echo "================================================================================"
echo ""
