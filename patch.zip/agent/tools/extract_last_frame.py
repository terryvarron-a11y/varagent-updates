"""
Extract last frame from mp4 via ffmpeg for chain extend mode.

Helper для Chain mode: извлекает последний (предпоследний) кадр из видео
для использования как start_image в следующем клипе chain'а.

CLI usage:
    python extract_last_frame.py <input_mp4> <output_png> [--offset 0.5]

API usage:
    from tools.extract_last_frame import get_last_frame_path
    path = get_last_frame_path(project_dir, clip_id, offset=0.5)
"""
import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional


def extract_last_frame(
    input_mp4: Path,
    output_png: Path,
    offset: float = 0.5,
    force: bool = False,
) -> bool:
    """
    Извлекает последний кадр из mp4 (с отступом от конца).

    Args:
        input_mp4: Путь к исходному mp4
        output_png: Путь для сохранения PNG кадра
        offset: Секунд от конца (ffmpeg -sseof). 0.5 = ~12 кадров от конца при 24fps.
                VEO часто затухает в последних 5-10 кадрах → берём с отступом.
        force: Пересоздать даже если output_png уже существует

    Returns:
        True если успешно, False при ошибке
    """
    if not input_mp4.exists() or input_mp4.stat().st_size < 1000:
        print(f"[extract_last_frame] ERROR: source mp4 missing or too small: {input_mp4}")
        return False

    # Invalidation: если mp4 новее чем png → re-extract
    if output_png.exists() and not force:
        if input_mp4.stat().st_mtime <= output_png.stat().st_mtime:
            # PNG актуален
            return True
        # mp4 регенерирован после png → удалить stale png
        output_png.unlink()

    output_png.parent.mkdir(parents=True, exist_ok=True)

    # ffmpeg: -sseof -0.5 = 0.5 sec before end
    #         -vframes 1 = one frame
    #         -q:v 2 = best JPEG quality (ignored for PNG, lossless)
    cmd = [
        'ffmpeg',
        '-y',                           # overwrite
        '-sseof', f'-{offset}',         # offset from end (negative)
        '-i', str(input_mp4),
        '-vframes', '1',
        '-q:v', '2',
        str(output_png),
    ]

    try:
        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding='utf-8',
            errors='replace',
        )
        if result.returncode != 0:
            print(f"[extract_last_frame] ffmpeg FAILED (exit {result.returncode}): {input_mp4.name}")
            print(result.stderr[-500:])  # last 500 chars of error
            return False
        if not output_png.exists() or output_png.stat().st_size < 1000:
            print(f"[extract_last_frame] ERROR: output png missing or too small: {output_png}")
            return False
        return True
    except Exception as e:
        print(f"[extract_last_frame] Exception: {e}")
        return False


def get_last_frame_path(
    project_dir: Path,
    clip_id: int,
    offset: Optional[float] = None,
) -> Optional[Path]:
    """
    Возвращает путь к last_frame.png для заданного clip_id.
    Извлекает если нет или invalidated (mp4 новее чем png).

    Args:
        project_dir: Папка проекта (содержит vid_img/ и vid_img_lastframes/)
        clip_id: ID клипа
        offset: Секунд от конца (default читается из config.VIDEO_EXTEND_FRAME_OFFSET)

    Returns:
        Path к png если успешно, None при ошибке
    """
    if offset is None:
        # Import here to avoid circular dependency at module level
        try:
            import config
            offset = getattr(config, 'VIDEO_EXTEND_FRAME_OFFSET', 0.5)
        except Exception:
            offset = 0.5

    mp4 = project_dir / 'vid_img' / f"{clip_id:03d}.mp4"
    if not mp4.exists() or mp4.stat().st_size < 1000:
        return None

    lf_dir = project_dir / 'vid_img_lastframes'
    lf_dir.mkdir(exist_ok=True)
    lf = lf_dir / f"{clip_id:03d}.png"

    # Extract if missing or stale
    ok = extract_last_frame(mp4, lf, offset=offset)
    return lf if ok and lf.exists() else None


def main():
    parser = argparse.ArgumentParser(description='Extract last frame from mp4')
    parser.add_argument('input', type=str, help='Input mp4 file')
    parser.add_argument('output', type=str, help='Output PNG file')
    parser.add_argument('--offset', type=float, default=0.5,
                        help='Seconds from end (default: 0.5)')
    parser.add_argument('--force', action='store_true',
                        help='Force re-extract even if output exists')
    args = parser.parse_args()

    ok = extract_last_frame(
        Path(args.input),
        Path(args.output),
        offset=args.offset,
        force=args.force,
    )
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    main()
