import json
import base64
import urllib.request

token = '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'
repo = 'terryvarron-a11y/varagent-updates'
url = f'https://api.github.com/repos/{repo}/contents/version.json'

req = urllib.request.Request(url, headers={
    'Authorization': f'token {token}',
    'User-Agent': 'varagent-publisher',
    'Accept': 'application/vnd.github.v3+json',
})

resp = urllib.request.urlopen(req)
d = json.loads(resp.read())
version_json = json.loads(base64.b64decode(d['content']))

print('Версия:', version_json.get('version'))
print()
print('MD5 в version.json:')
for f in ['agent/modules/updater.py', 'varagent.py', 'split_srt.bat']:
    print(f'  {f}: {version_json.get("files", {}).get(f)}')
