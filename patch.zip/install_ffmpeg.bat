@echo off
chcp 65001 >nul
color 0A
echo ========================================================
echo               Автоматическая установка FFmpeg
echo ========================================================
echo.

echo Проверка наличия Winget...
where winget >nul 2>nul
if %errorlevel% neq 0 (
    echo [ОШИБКА] Winget не найден! Убедитесь, что у вас Windows 10 или 11 с последними обновлениями.
    pause
    exit /b
)

echo [ОК] Winget найден. Начинаем установку FFmpeg...
echo.

:: Команда для установки с автоматическим принятием лицензионных соглашений
winget install --id Gyan.FFmpeg -e --accept-source-agreements --accept-package-agreements

echo.
echo ========================================================
echo Установка завершена! 
echo ========================================================
echo ВАЖНО: Если FFmpeg не распознается сразу, просто перезагрузите ПК 
echo или откройте новое окно командной строки.
echo.
echo Для проверки версии введите: ffmpeg -version
echo.
pause