@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0\agent"

echo.
echo ================================================================================
echo  STAGE 1: QUEUE + PIPELINE
echo  Source: pipeline_queue\   New files only!
echo ================================================================================
echo.

REM ============================================================================
REM  ЯЗЫК ОЗВУЧКИ
REM ============================================================================

echo  Yazyk ozvuchki:
echo.
echo    [1] ru  - Russkiy      (po umolchaniyu)
echo    [2] en  - English
echo    [3] es  - Espanol
echo    [4] de  - Deutsch
echo    [5] fr  - Francais
echo    [6] it  - Italiano
echo    [7] pt  - Portugues
echo    [8] zh  - Chinese
echo    [9] Drugoy (vvedi kod vruchnuyu)
echo.

set "LANG=ru"
set /p LANG_CHOICE="  Yazyk [1-9] (Enter = ru): "

if "!LANG_CHOICE!"=="1" set "LANG=ru"
if "!LANG_CHOICE!"=="2" set "LANG=en"
if "!LANG_CHOICE!"=="3" set "LANG=es"
if "!LANG_CHOICE!"=="4" set "LANG=de"
if "!LANG_CHOICE!"=="5" set "LANG=fr"
if "!LANG_CHOICE!"=="6" set "LANG=it"
if "!LANG_CHOICE!"=="7" set "LANG=pt"
if "!LANG_CHOICE!"=="8" set "LANG=zh"
if not "!LANG_CHOICE!"=="9" goto :skip_lang_manual
set /p LANG="  Vvedi kod yazyka (en, ru, es, de, fr, it, pt, nl, pl, ja, zh, ko, hi, ar): "
:skip_lang_manual

echo.
echo  [OK] Yazyk: !LANG!
echo.

REM ============================================================================
REM  REZHIM REZHISSURY
REM ============================================================================

echo  Vyberi rezhim rezhissury:
echo.
echo    [1]  1-prohodnyy  (bystree, dlya proektov do ~15 min / ~200 klipov)
echo    [2]  2-prohodnyy  (dlya dlinnykh proektov, 242+ klipov, bez obrezaniya)
echo.

set /p "CHOICE=Vvedi 1 ili 2 i nazh Enter: "

if "!CHOICE!"=="1" (
    set "TWO_PASS_FLAG="
    echo.
    echo  [OK] Rezhim: 1-prohodnyy
) else if "!CHOICE!"=="2" (
    set "TWO_PASS_FLAG=--two-pass"
    echo.
    echo  [OK] Rezhim: 2-prohodnyy
) else (
    echo.
    echo  [ERROR] Neverniy vybor. Zapusk otmenen.
    pause
    exit /b 1
)

echo.
echo ================================================================================
echo.

python agent.py process --run --language !LANG! !TWO_PASS_FLAG!

echo.
echo ================================================================================
echo  DONE. Check folders in projects\
echo ================================================================================
echo.
echo NEXT STEP: Open prompts_*.txt and generate video in Veo3
echo.
pause
