#!/bin/bash
cd "$(dirname "$0")"
echo "========================================"
echo "VARAGENT Emergency Update"
echo "========================================"
echo ""
echo "Этот скрипт обходит SSL ошибку и"
echo "устанавливает обновление напрямую."
echo ""
python3 emergency_update.py
if [ $? -ne 0 ]; then
    echo ""
    echo "ОШИБКА при обновлении!"
    read -p "Нажмите Enter для выхода..."
    exit 1
fi
