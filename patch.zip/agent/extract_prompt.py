#!/usr/bin/env python3
"""
Извлечение промпта для конкретного фрагмента из {project}_prompts_{date}.txt

Формат:
[промпт 1]

[промпт 2]

[промпт 3]
...

Важно:
- 4list_prompts.txt ЗАМОРОЖЕН (исключён из пайплайна)
- Используем только prompts.txt который создаётся в первом этапе
"""
import re
import sys
import os
from pathlib import Path


def find_prompts_file(directory: str = ".") -> str:
    """
    Найти файл промптов в директории по маске *_prompts_*.txt

    Args:
        directory: Директория для поиска

    Returns:
        Путь к файлу промптов или None
    """
    dir_path = Path(directory)
    prompts_files = list(dir_path.glob('*_prompts_*.txt'))
    
    if prompts_files:
        # Возвращаем самый новый по времени модификации
        prompts_files.sort(key=lambda f: f.stat().st_mtime, reverse=True)
        return str(prompts_files[0])
    
    # Если не найдено - пробуем prompts.txt (для обратной совместимости)
    default_prompts = dir_path / 'prompts.txt'
    if default_prompts.exists():
        return str(default_prompts)
    
    return None


def extract_prompt(fragment_id: int, file_path: str = None) -> str:
    """
    Извлекает промпт для указанного фрагмента

    Args:
        fragment_id: Номер фрагмента (1-based)
        file_path: Путь к файлу промптов (если None - ищется автоматически)

    Returns:
        Текст промпта или сообщение об ошибке
    """
    try:
        # Если путь не указан - ищем файл
        if file_path is None:
            file_path = find_prompts_file()
            if file_path is None:
                return "❌ Не найден файл промптов (*_prompts_*.txt) в текущей директории"
        
        # Пробуем разные кодировки
        content = None
        for encoding in ['utf-8', 'cp1251', 'latin-1']:
            try:
                with open(file_path, 'r', encoding=encoding) as f:
                    content = f.read()
                break
            except UnicodeDecodeError:
                continue
        
        if content is None:
            return f"❌ Не удалось прочитать файл {file_path} (неподдерживаемая кодировка)"

        # Разделяем промпты по ОДНОЙ пустой строке
        # Формат Gemini: промпт1\n\nпромпт2\n\nпромпт3
        prompts = re.split(r'\n\n+', content.strip())
        
        # fragment_id начинается с 1, массив с 0
        if 1 <= fragment_id <= len(prompts):
            return prompts[fragment_id - 1].strip()
        else:
            return f"❌ Промпт для фрагмента #{fragment_id} не найден (всего промптов: {len(prompts)})"

    except FileNotFoundError:
        return f"❌ Файл {file_path} не найден"
    except Exception as e:
        return f"❌ Ошибка: {e}"


def extract_all_prompts(file_path: str = None) -> dict:
    """
    Извлекает все промпты из файла

    Args:
        file_path: Путь к файлу промптов (если None - ищется автоматически)

    Returns:
        Словарь {fragment_id: prompt_text}
    """
    try:
        # Если путь не указан - ищем файл
        if file_path is None:
            file_path = find_prompts_file()
            if file_path is None:
                return {}
        
        # Пробуем разные кодировки
        content = None
        for encoding in ['utf-8', 'cp1251', 'latin-1']:
            try:
                with open(file_path, 'r', encoding=encoding) as f:
                    content = f.read()
                break
            except UnicodeDecodeError:
                continue
        
        if content is None:
            return {}

        # Разделяем промпты по пустым строкам. Newer Pass 2 may preserve real
        # montage IDs via a leading "[CLIP N]" / "[N]" prefix; parse that first
        # so Real Photo gaps do not collapse prompt numbering.
        prompts = [p.strip() for p in re.split(r'\n\s*\n', content.strip()) if p.strip()]

        prefixed = {}
        id_re = re.compile(r'^\s*\[(?:CLIP\s+)?(\d+)\]\s*(.*)$', re.IGNORECASE | re.DOTALL)
        for prompt in prompts:
            m = id_re.match(prompt)
            if not m:
                continue
            cid = int(m.group(1))
            body = m.group(2).strip()
            if body:
                prefixed[cid] = body
        if prefixed and len(prefixed) >= max(1, len(prompts) // 2):
            return prefixed

        result = {}
        for i, prompt in enumerate(prompts, start=1):
            result[i] = prompt.strip()

        return result

    except Exception as e:
        return {}


def remap_dense_prompts_for_montage(prompts: dict, clips: list) -> tuple:
    """
    Compatibility shim for projects created while Real Photo clips were removed
    before Pass 2. Those prompt files are dense 1..N, where N equals the number
    of non-real-photo clips, but the keys are not actual montage clip IDs.

    Returns: (prompts_map, remapped_bool)
    """
    if not prompts or not clips:
        return prompts, False

    real_sources = {'real_photo', 'real_photo_pending', 'real_video'}
    non_real_clips = [c for c in clips if c.get('source') not in real_sources]
    real_count = len(clips) - len(non_real_clips)
    if real_count <= 0:
        return prompts, False

    keys = set(prompts.keys())
    dense_keys = set(range(1, len(prompts) + 1))
    has_id_gaps = any(c.get('id') != i + 1 for i, c in enumerate(non_real_clips))
    if len(prompts) == len(non_real_clips) and keys == dense_keys and has_id_gaps:
        remapped = {
            int(clip['id']): prompts[i + 1]
            for i, clip in enumerate(non_real_clips)
            if (i + 1) in prompts and 'id' in clip
        }
        return remapped, True

    return prompts, False


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Использование:")
        print("  python extract_prompt.py <fragment_id>     - извлечь промпт для фрагмента")
        print("  python extract_prompt.py --all             - извлечь все промпты")
        sys.exit(1)

    if sys.argv[1] == '--all':
        prompts = extract_all_prompts()
        for fragment_id, prompt in sorted(prompts.items()):
            print(f"\n{'='*80}")
            print(f"ФРАГМЕНТ #{fragment_id}")
            print(f"{'='*80}\n")
            print(prompt)
    else:
        try:
            fragment_id = int(sys.argv[1])
            prompt = extract_prompt(fragment_id)
            print(prompt)
        except ValueError:
            print(f"❌ Ошибка: '{sys.argv[1]}' не является числом")
            sys.exit(1)
