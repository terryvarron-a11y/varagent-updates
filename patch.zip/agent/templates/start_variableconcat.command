#!/bin/bash
# START_VARIABLECONCAT.COMMAND - Variable concat: video + photo from vid_img/
# Run: double-click this file in Finder

PROJECT_NAME="{project_name}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

chmod +x *.command 2>/dev/null
[ -f "$SCRIPT_DIR/.venv/bin/activate" ] && source "$SCRIPT_DIR/.venv/bin/activate"

if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e 'tell app "Terminal" to do script "cd '\''$SCRIPT_DIR'\'' && exec '\''$0'\''"'
    exit 0
fi

clear
cd "$SCRIPT_DIR"

echo ""
echo "================================================================================"
echo " VARIABLE CONCAT - Video + photo from vid_img/"
echo " Project: {project_name}"
echo "================================================================================"
echo ""

if [ ! -f "montage_plan.json" ]; then
    echo "[ERROR] montage_plan.json not found!"
    echo "   Run run_director.command to create the plan"
    echo "Press Enter to exit..." && read
    exit 1
fi

if [ ! -d "vid_img" ]; then
    echo "[WARN] vid_img/ folder not found."
    echo "   Put fragments in vid_img/ as: 001.mp4, 002.mp4 or 001.png ..."
    echo ""
fi

# Find audio
AUDIO_FILE=""
for EXT in wav mp3 flac m4a aac; do
    for F in *.$EXT; do
        [ -f "$F" ] && AUDIO_FILE="$F" && break 2
    done
done

if [ -z "$AUDIO_FILE" ]; then
    echo "[ERROR] Audio file not found!"
    echo "   Put .wav/.mp3 in the project folder"
    echo "Press Enter to exit..." && read
    exit 1
fi
echo "   Audio: $AUDIO_FILE"
echo ""

echo " Resolution:"
echo "   [1] 1920x1080   Full HD landscape  (default)"
echo "   [2] 1280x720    HD landscape"
echo "   [3] 1080x1920   Full HD portrait (Reels/Shorts)"
echo "   [4] 1080x1080   Square"
echo ""
RESOLUTION="1920x1080"
echo -n "  Resolution [1-4] (Enter = 1920x1080): "
read RES_CHOICE
case "$RES_CHOICE" in
    2) RESOLUTION="1280x720" ;;
    3) RESOLUTION="1080x1920" ;;
    4) RESOLUTION="1080x1080" ;;
esac
echo "   Selected: $RESOLUTION"
echo ""

echo " FPS:"
echo "   [1] 25 fps"
echo "   [2] 30 fps"
echo "   [3] 60 fps  (rekomendуetsya)"
echo ""
read -p "  FPS [1-3] (Enter = 60): " FPS_CHOICE
FPS=60
case "$FPS_CHOICE" in
    1) FPS=25 ;;
    2) FPS=30 ;;
    3) FPS=60 ;;
esac
echo "   Vybrano: $FPS fps"
echo ""

OUTPUT_FILE="{project_name}_variable.mp4"
echo " Output file: $OUTPUT_FILE"
echo ""
echo "================================================================================"
echo " SUMMARY:"
echo "   Project:    {project_name}"
echo "   Audio:      $AUDIO_FILE"
echo "   Resolution: $RESOLUTION"
echo "   FPS:        $FPS"
echo "   Output:     $OUTPUT_FILE"
echo "================================================================================"
echo ""
echo "   [1] Start"
echo "   [2] Cancel"
echo ""
read -p "  Vybor [1/2]: " CONFIRM
if [[ "$CONFIRM" == "2" ]] || ([[ -n "$CONFIRM" ]] && [[ "$CONFIRM" != "1" ]]); then
    echo " Cancelled."
    echo "Press Enter to exit..." && read
    exit 0
fi

echo ""
echo " Renaming files in vid_img/..."
if [ -f "rename_videos.py" ]; then
    python3 rename_videos.py --dir vid_img
else
    echo "   [WARN] rename_videos.py not found, skipping..."
fi
echo ""

echo " Running variable concat..."
echo ""

python3 variable_concat.py montage_plan.json     -a "$AUDIO_FILE"     -o "$OUTPUT_FILE"     --resolution "$RESOLUTION"     --fps $FPS     -b 10M
RESULT=$?

if [ $RESULT -ne 0 ]; then
    echo ""
    echo "[ERROR] Failed! Check variable_concat_*.log"
    echo "Press Enter to exit..." && read
    exit 1
fi

echo ""
echo "================================================================================"
echo " DONE!"
echo "================================================================================"
echo "   Result: $OUTPUT_FILE"
echo ""
echo "Press Enter to exit..." && read
