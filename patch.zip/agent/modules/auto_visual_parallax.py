"""Auto Visual Story handoff for selective EPF/stock-photo parallax."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable

import config
from modules.clip_sources import AUTO_VISUAL_PARALLAX_PHOTO_SOURCES
from modules.parallax import select_every_n_clip_ids


IMAGE_EXTENSIONS = (".png", ".jpg", ".jpeg", ".webp")


def ready_auto_visual_photo_ids(project_dir: str | Path) -> list[int]:
    """Return ordered ready EPF/stock photo IDs, excluding all video sources."""
    project = Path(project_dir)
    plan_path = project / "montage_plan.json"
    raw = json.loads(plan_path.read_text(encoding="utf-8-sig"))
    plan = raw.get("montage_plan", raw)
    generated = project / "generated"
    result: list[int] = []
    for clip in plan.get("clips", []):
        if clip.get("source") not in AUTO_VISUAL_PARALLAX_PHOTO_SOURCES:
            continue
        try:
            clip_id = int(clip["id"])
        except (KeyError, TypeError, ValueError):
            continue
        if any((generated / f"{clip_id:03d}{ext}").is_file() for ext in IMAGE_EXTENSIONS):
            result.append(clip_id)
    return result


def run_auto_visual_parallax(
    project_dir: str | Path,
    generate_videos: Callable[..., dict[str, Any]],
) -> dict[str, Any]:
    """Run normal Veo I2V for every Nth ready EPF/stock photo.

    ``generate_videos`` is the regular ``veo_generate_all_videos`` entrypoint,
    injected here so the selection behavior can be tested without network calls.
    """
    project = Path(project_dir)
    eligible_ids = ready_auto_visual_photo_ids(project)
    try:
        every_n = max(
            1,
            int(getattr(config, "VEONONSTOP_I2V_PARALLAX_EVERY_N", 2) or 2),
        )
    except (TypeError, ValueError):
        every_n = 2
    selected_ids = select_every_n_clip_ids(eligible_ids, every_n)
    summary: dict[str, Any] = {
        "eligible_ids": eligible_ids,
        "selected_ids": selected_ids,
        "every_n": every_n,
        "result": None,
    }
    if not selected_ids:
        return summary
    summary["result"] = generate_videos(
        project_dir=str(project),
        mode="i2v",
        clip_ids=selected_ids,
        silent=True,
        no_cancel=True,
        allow_external_image_clip_ids=selected_ids,
        parallax_only=True,
    )
    return summary
