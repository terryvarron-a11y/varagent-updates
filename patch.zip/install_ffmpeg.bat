@echo off
chcp 65001 >nul
color 0A
set "NO_PAUSE="
if /I "%~1"=="/nopause" set "NO_PAUSE=1"
if /I "%~1"=="--nopause" set "NO_PAUSE=1"
echo ========================================================
echo               Automatic FFmpeg Installation
echo ========================================================
echo.

REM Check if already installed
ffmpeg -version >nul 2>&1
if not errorlevel 1 (
    echo [OK] FFmpeg already installed.
    ffmpeg -version 2>&1 | findstr /C:"ffmpeg version"
    echo.
    if not defined NO_PAUSE pause
    exit /b 0
)

REM --- Try winget first ---
echo Checking winget...
winget --version >nul 2>&1
if not errorlevel 1 (
    echo [winget] Installing Gyan.FFmpeg...
    REM --source winget --exact: avoid msstore certificate errors and source ambiguity
    winget install --id Gyan.FFmpeg --source winget --exact -e --accept-source-agreements --accept-package-agreements
    for /f "usebackq delims=" %%P in (`powershell -NoProfile -Command "[Environment]::GetEnvironmentVariable('PATH','Machine') + ';' + [Environment]::GetEnvironmentVariable('PATH','User')"`) do set "PATH=%%P"
    ffmpeg -version >nul 2>&1
    if not errorlevel 1 (
        echo [OK] FFmpeg installed via winget
        goto :done
    )
    echo [WARN] winget finished but ffmpeg not in PATH. Trying direct download...
)

REM --- Direct download via PowerShell ---
echo.
echo Downloading FFmpeg directly...
echo.

set "FFMPEG_URL=https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"
set "FFMPEG_ZIP=%TEMP%\ffmpeg_download.zip"
set "FFMPEG_EXTRACT=%TEMP%\ffmpeg_extract"
set "FFMPEG_DEST=%LOCALAPPDATA%\ffmpeg"

echo Downloading from %FFMPEG_URL%...
powershell -NoProfile -Command "try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri '%FFMPEG_URL%' -OutFile '%FFMPEG_ZIP%' -UseBasicParsing; Write-Host '[OK] Downloaded' } catch { Write-Host '[ERROR]' $_.Exception.Message; exit 1 }"
if errorlevel 1 (
    echo.
    echo [ERROR] Download failed.
    echo Download manually: %FFMPEG_URL%
    echo Extract ffmpeg.exe and ffprobe.exe to a folder in your PATH.
    if not defined NO_PAUSE pause
    exit /b 1
)

echo Extracting...
if exist "%FFMPEG_EXTRACT%" rmdir /s /q "%FFMPEG_EXTRACT%"
powershell -NoProfile -Command "try { Expand-Archive -Path '%FFMPEG_ZIP%' -DestinationPath '%FFMPEG_EXTRACT%' -Force; Write-Host '[OK] Extracted' } catch { Write-Host '[ERROR]' $_.Exception.Message; exit 1 }"
if errorlevel 1 (
    echo [ERROR] Extraction failed.
    if not defined NO_PAUSE pause
    exit /b 1
)

REM Find the bin folder inside extracted archive (it's nested: ffmpeg-X.X-essentials_build/bin/)
set "BIN_DIR="
for /d %%D in ("%FFMPEG_EXTRACT%\ffmpeg-*") do (
    if exist "%%D\bin\ffmpeg.exe" set "BIN_DIR=%%D\bin"
)
if "%BIN_DIR%"=="" (
    echo [ERROR] Could not find ffmpeg.exe in extracted archive.
    echo Check: %FFMPEG_EXTRACT%
    if not defined NO_PAUSE pause
    exit /b 1
)

echo Installing to %FFMPEG_DEST%...
if not exist "%FFMPEG_DEST%" mkdir "%FFMPEG_DEST%"
copy /y "%BIN_DIR%\ffmpeg.exe" "%FFMPEG_DEST%\ffmpeg.exe" >nul
copy /y "%BIN_DIR%\ffprobe.exe" "%FFMPEG_DEST%\ffprobe.exe" >nul

REM Add to user PATH
echo Adding to PATH...
powershell -NoProfile -Command "$p = [Environment]::GetEnvironmentVariable('PATH','User'); if ($p -notlike '*%FFMPEG_DEST%*') { [Environment]::SetEnvironmentVariable('PATH', $p + ';%FFMPEG_DEST%', 'User'); Write-Host '[OK] Added to PATH' } else { Write-Host '[OK] Already in PATH' }"

REM Update PATH in current session
for /f "usebackq delims=" %%P in (`powershell -NoProfile -Command "[Environment]::GetEnvironmentVariable('PATH','Machine') + ';' + [Environment]::GetEnvironmentVariable('PATH','User')"`) do set "PATH=%%P"

REM Cleanup
del "%FFMPEG_ZIP%" 2>nul
rmdir /s /q "%FFMPEG_EXTRACT%" 2>nul

REM Verify
ffmpeg -version >nul 2>&1
if not errorlevel 1 (
    echo.
    echo [OK] FFmpeg installed and working!
    ffmpeg -version 2>&1 | findstr /C:"ffmpeg version"
) else (
    echo.
    echo [WARN] FFmpeg installed to %FFMPEG_DEST% but not yet in PATH.
    echo Restart your terminal or PC, then check: ffmpeg -version
)

:done
echo.
echo ========================================================
echo Installation complete!
echo ========================================================
echo.
if not defined NO_PAUSE pause
exit /b 0
