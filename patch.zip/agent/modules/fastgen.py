"""
FastGen API - генерация изображений (этап 3 пайплайна)

Поддерживает два режима:
- Flow API: до 10 референсов как общий массив
- Whisk Remix: категоризированные референсы (subject/scene/style)
"""
import base64
import json
import sys
import time
import random
import logging

IS_PIPE = not sys.stdout.isatty()  # True когда запущен как subprocess (pipeline mode)
import threading
import requests
from pathlib import Path
from typing import Optional, Dict, List, Any
from datetime import datetime

# Flow Ultra — module-level shutdown signal + active client registry.
# Control Panel's Stop button sets event + calls cancel_all_tasks on each registered client.
_flowultra_shutdown_event: threading.Event = threading.Event()
_flowultra_active_clients: 'list' = []
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm
import colorama
from colorama import Fore, Style

colorama.init(autoreset=True)

# Worker tracking для dual-key стаггера (первый запуск vs повторный)
_fg_started_workers: set = set()
_fg_started_workers_lock = threading.Lock()
_fg_worker_map: dict = {}
_fg_worker_lock = threading.Lock()
_fg_worker_counter: dict = {'next': 0}

# Цветовые алиасы для консольного вывода
_YELLOW = Fore.YELLOW    # обычный retry (сеть, таймаут, ratelimit)
_RED    = Fore.RED       # цензура — переписывание промпта
_GREEN  = Fore.GREEN     # OK
_RESET  = Style.RESET_ALL

import os
import config
from extract_prompt import extract_all_prompts, find_prompts_file

# Ensure agent/modules/ and agent/tools/ are on sys.path
_modules_dir = str(Path(__file__).resolve().parent)
_agent_dir   = str(Path(__file__).resolve().parent.parent)
for _p in (_modules_dir, _agent_dir):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from remix import remix_ref


# ======================================================================
# SynthID inflight watermark removal
# ======================================================================

def _synthid_clean_if_needed(file_path: str) -> None:
    """
    Called from worker thread immediately after each image is saved.
    If VARAGENT_SYNTHID_CLEAN=1 env var is set, runs SynthID watermark
    removal on the single image file in-place.
    Safe to call concurrently from multiple worker threads.
    """
    if os.environ.get('VARAGENT_SYNTHID_CLEAN') != '1':
        return
    try:
        _tools_dir = str(Path(__file__).resolve().parent.parent / 'tools')
        if _tools_dir not in sys.path:
            sys.path.insert(0, _tools_dir)
        from synthid_cleaner import clean_single_image
        _strength   = os.environ.get('VARAGENT_SYNTHID_STRENGTH',  'moderate')
        _version    = os.environ.get('VARAGENT_SYNTHID_VERSION',   'v1')
        _save_orig  = os.environ.get('VARAGENT_SYNTHID_SAVE_ORIG', '0') == '1'
        _ok = clean_single_image(file_path, strength=_strength, version=_version, save_orig=_save_orig)
        _status = 'OK' if _ok else 'FAILED'
        print(f"  [SynthID] {Path(file_path).name}: {_status}", flush=True)
    except Exception as _e:
        print(f"  [SynthID] WARNING: {_e}", flush=True)


# Поддерживаемые форматы изображений
IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.webp'}


def _clean_resp_text(text: str, limit: int = 300) -> str:
    """Обрезает resp.text — убирает HTML-мусор (Cloudflare/502) из сообщений об ошибках."""
    if '<html' in text.lower() or '<!doctype' in text.lower():
        return f"[HTML response, likely Cloudflare/5xx] {text[:150].replace(chr(10), ' ')}"
    return text[:limit]


class FastGenClient:
    """Клиент FastGen API для генерации изображений"""

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or config.FASTGEN_API_KEY
        self.base_url = config.FASTGEN_API_BASE
        self.storage_url = config.FASTGEN_STORAGE_URL
        self.headers = {
            'X-API-Key': self.api_key,
            'Content-Type': 'application/json',
        }
        # Set to True when _preflight_test_refs returns True due to exception
        # (not actual success). Caller checks this to avoid logging false "OK".
        self._last_preflight_skipped = False

        if not self.api_key:
            raise ValueError("FASTGEN_API_KEY not set in .env")

    # ------------------------------------------------------------------
    # Storage: загрузка референсов
    # ------------------------------------------------------------------

    def upload_reference(self, image_path: str) -> str:
        """
        Загрузить референсное изображение в FastGen Storage.

        Args:
            image_path: Путь к файлу изображения

        Returns:
            URI вида 'file:abc123def' для использования в reference_images
        """
        path = Path(image_path)
        if not path.exists():
            raise FileNotFoundError(f"Reference image not found: {image_path}")

        url = f"{self.storage_url}/upload"

        # Отправляем в оригинальном формате — не конвертируем в PNG,
        # чтобы не раздувать тело запроса (JPEG ~1MB vs PNG ~5-8MB)
        mime_map = {'.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
                    '.webp': 'image/webp', '.png': 'image/png'}
        mime = mime_map.get(path.suffix.lower(), 'image/png')
        with open(path, 'rb') as f:
            resp = requests.post(
                url,
                headers={'X-API-Key': self.api_key},
                files={'file': (path.name, f, mime)},
                timeout=60,
            )

        if resp.status_code != 200:
            raise RuntimeError(f"Storage upload failed ({resp.status_code}): {_clean_resp_text(resp.text)}")

        data = resp.json()
        # API returns {"file_hash": "file:abc123...", ...}
        uri = data.get('file_hash') or data.get('uri') or data.get('file_uri') or data.get('id')
        if not uri:
            raise RuntimeError(f"Storage upload: no URI in response: {data}")

        # Ensure file: prefix
        if not uri.startswith('file:'):
            uri = f"file:{uri}"

        logging.info(f"Uploaded reference {path.name} -> {uri}")
        return uri

    # ------------------------------------------------------------------
    # Flow API: генерация изображений (async)
    # ------------------------------------------------------------------

    # Маппинг движков по имени модели
    _ENGINE_MAP = {
        'GEM_PIX':    'flow',
        'GEM_PIX_2':  'flow',
        'IMAGEN_3_5': 'flow',
        'NARWHAL':    'flow',   # Nano Banana 2
        'FLOWER':     'flower', # Nano Banana 2 via Flower
        'WHISK':      'whisk',
        'GEMINI':     'gemini',
        'GROK':       'grok',
    }

    @staticmethod
    def _get_engine(model: str) -> str:
        """Определить API-движок по имени модели"""
        return FastGenClient._ENGINE_MAP.get((model or '').upper(), 'flow')

    # aspect_ratio aliases → полный Google enum (для Flow/Whisk)
    _ASPECT_MAP = {
        'landscape': 'IMAGE_ASPECT_RATIO_LANDSCAPE',
        '16:9':      'IMAGE_ASPECT_RATIO_LANDSCAPE',
        'portrait':  'IMAGE_ASPECT_RATIO_PORTRAIT',
        '9:16':      'IMAGE_ASPECT_RATIO_PORTRAIT',
        'square':    'IMAGE_ASPECT_RATIO_SQUARE',
    }

    # aspect_ratio aliases → формат Grok (1:1, 2:3, 3:2, 9:16, 16:9)
    _ASPECT_MAP_GROK = {
        'landscape': '16:9',
        '16:9':      '16:9',
        'portrait':  '9:16',
        '9:16':      '9:16',
        'square':    '1:1',
        '1:1':       '1:1',
        '2:3':       '2:3',
        '3:2':       '3:2',
    }

    @staticmethod
    def _map_aspect(aspect: str) -> str:
        """Нормализовать aspect_ratio в полный Google формат (Flow/Whisk)"""
        if aspect and aspect.startswith('IMAGE_ASPECT_RATIO_'):
            return aspect
        return FastGenClient._ASPECT_MAP.get(aspect.lower() if aspect else '', 'IMAGE_ASPECT_RATIO_LANDSCAPE')

    @staticmethod
    def _map_aspect_grok(aspect: str) -> str:
        """Нормализовать aspect_ratio в формат Grok"""
        return FastGenClient._ASPECT_MAP_GROK.get(aspect.lower() if aspect else '', '16:9')

    def generate_flow(
        self,
        prompt: str,
        reference_uris: Optional[List[str]] = None,
        model: Optional[str] = None,
        aspect_ratio: Optional[str] = None,
        seed: Optional[int] = None,
    ) -> str:
        """
        Запустить генерацию через V4 Flow API (асинхронный).

        Args:
            prompt: Текст промпта
            reference_uris: Список URI референсов (file:... или data:...)
            model: Модель (GEM_PIX, GEM_PIX_2, IMAGEN_3_5)
            aspect_ratio: Соотношение сторон

        Returns:
            operation_id для поллинга
        """
        url = f"{self.base_url}/v4/flow/image/generate"
        body = {
            'prompt': prompt,
            'model': model or config.FASTGEN_MODEL,
            'aspect_ratio': self._map_aspect(aspect_ratio or config.FASTGEN_ASPECT_RATIO),
        }
        if reference_uris:
            body['reference_images'] = reference_uris[:10]  # max 10
        if seed is not None:
            body['seed'] = seed

        resp = requests.post(url, headers=self.headers, json=body, timeout=30)

        if resp.status_code == 429:
            raise RateLimitError("Rate limit exceeded (429)")
        if resp.status_code != 200:
            raise RuntimeError(f"Flow generate failed ({resp.status_code}): {_clean_resp_text(resp.text)}")

        data = resp.json()
        op_id = data.get('operation_id') or data.get('id')
        if not op_id:
            raise RuntimeError(f"No operation_id in response: {data}")

        return op_id

    # ------------------------------------------------------------------
    # Whisk Remix API: генерация с категоризированными референсами
    # ------------------------------------------------------------------

    def generate_whisk(
        self,
        prompt: str,
        subject_uris: Optional[List[str]] = None,
        scene_uris: Optional[List[str]] = None,
        style_uris: Optional[List[str]] = None,
    ) -> str:
        """
        Запустить генерацию через V4 Whisk Remix API (асинхронный).

        Args:
            prompt: Текст промпта
            subject_uris: Референсы персонажей (MEDIA_CATEGORY_SUBJECT)
            scene_uris: Референсы локаций (MEDIA_CATEGORY_SCENE)
            style_uris: Референсы стиля (MEDIA_CATEGORY_STYLE)

        Returns:
            operation_id для поллинга
        """
        url = f"{self.base_url}/v4/whisk/image/remix"

        # Docs: reference_images = [{"image": "file:...", "category": "MEDIA_CATEGORY_..."}, ...]
        reference_images = []
        for uri in (subject_uris or []):
            reference_images.append({'image': uri, 'category': 'MEDIA_CATEGORY_SUBJECT'})
        for uri in (scene_uris or []):
            reference_images.append({'image': uri, 'category': 'MEDIA_CATEGORY_SCENE'})
        for uri in (style_uris or []):
            reference_images.append({'image': uri, 'category': 'MEDIA_CATEGORY_STYLE'})

        body = {
            'prompt': prompt,
            'reference_images': reference_images[:3],  # max 3
        }

        resp = requests.post(url, headers=self.headers, json=body, timeout=30)

        if resp.status_code == 429:
            raise RateLimitError("Rate limit exceeded (429)")
        if resp.status_code != 200:
            raise RuntimeError(f"Whisk generate failed ({resp.status_code}): {_clean_resp_text(resp.text)}")

        data = resp.json()
        op_id = data.get('operation_id') or data.get('id')
        if not op_id:
            raise RuntimeError(f"No operation_id in response: {data}")

        return op_id

    def generate_whisk_text(
        self,
        prompt: str,
        aspect_ratio: Optional[str] = None,
        seed: Optional[int] = None,
    ) -> str:
        """Whisk без референсов — только текст (Imagen 4)"""
        url = f"{self.base_url}/v4/whisk/image/generate"
        body = {
            'prompt': prompt,
            'aspect_ratio': self._map_aspect(aspect_ratio or config.FASTGEN_ASPECT_RATIO),
        }
        if seed is not None:
            body['seed'] = seed
        resp = requests.post(url, headers=self.headers, json=body, timeout=30)
        if resp.status_code == 429:
            raise RateLimitError("Rate limit exceeded (429)")
        if resp.status_code != 200:
            raise RuntimeError(f"Whisk text generate failed ({resp.status_code}): {_clean_resp_text(resp.text)}")
        data = resp.json()
        op_id = data.get('operation_id') or data.get('id')
        if not op_id:
            raise RuntimeError(f"No operation_id in response: {data}")
        return op_id

    def generate_gemini(
        self,
        prompt: str,
        reference_uris: Optional[List[str]] = None,
        seed: Optional[int] = None,
    ) -> str:
        """Gemini image generation (gemini-imagen model)"""
        url = f"{self.base_url}/v4/gemini/image/generate"
        body = {'prompt': prompt}
        if reference_uris:
            body['reference_images'] = reference_uris
        if seed is not None:
            body['seed'] = seed
        resp = requests.post(url, headers=self.headers, json=body, timeout=30)
        if resp.status_code == 429:
            raise RateLimitError("Rate limit exceeded (429)")
        if resp.status_code != 200:
            raise RuntimeError(f"Gemini generate failed ({resp.status_code}): {_clean_resp_text(resp.text)}")
        data = resp.json()
        op_id = data.get('operation_id') or data.get('id')
        if not op_id:
            raise RuntimeError(f"No operation_id in response: {data}")
        return op_id

    def generate_flower(
        self,
        prompt: str,
        aspect_ratio: Optional[str] = None,
        reference_image: Optional[str] = None,
    ) -> str:
        """Flower image generation (Nano Banana 2 via Flower). Supports img2img via reference_image."""
        url = f"{self.base_url}/v4/flower/image/generate"
        _FLOWER_ASPECT = {'landscape': '16:9', '16:9': '16:9', 'portrait': '9:16', '9:16': '9:16',
                          'square': '1:1', '1:1': '1:1'}
        body = {
            'prompt': prompt,
            'aspect_ratio': _FLOWER_ASPECT.get((aspect_ratio or '16:9').lower(), '16:9'),
        }
        if reference_image:
            body['reference_image'] = reference_image
        resp = requests.post(url, headers=self.headers, json=body, timeout=30)
        if resp.status_code == 429:
            raise RateLimitError("Rate limit exceeded (429)")
        if resp.status_code != 200:
            raise RuntimeError(f"Flower generate failed ({resp.status_code}): {_clean_resp_text(resp.text)}")
        data = resp.json()
        op_id = data.get('operation_id') or data.get('id')
        if not op_id:
            raise RuntimeError(f"No operation_id in response: {data}")
        return op_id

    def generate_grok(
        self,
        prompt: str,
        aspect_ratio: Optional[str] = None,
        seed: Optional[int] = None,
    ) -> str:
        """Grok image generation (возвращает 4 варианта, берём первый)"""
        url = f"{self.base_url}/v4/grok/image/generate"
        body = {
            'prompt': prompt,
            'aspect_ratio': self._map_aspect_grok(aspect_ratio or config.FASTGEN_ASPECT_RATIO),
        }
        if seed is not None:
            body['seed'] = seed
        resp = requests.post(url, headers=self.headers, json=body, timeout=30)
        if resp.status_code == 429:
            raise RateLimitError("Rate limit exceeded (429)")
        if resp.status_code != 200:
            raise RuntimeError(f"Grok generate failed ({resp.status_code}): {_clean_resp_text(resp.text)}")
        data = resp.json()
        op_id = data.get('operation_id') or data.get('id')
        if not op_id:
            raise RuntimeError(f"No operation_id in response: {data}")
        return op_id

    def edit_grok(self, image: str, prompt: str) -> str:
        """
        Grok image-to-image edit/transform.

        Args:
            image: Data URI (data:image/jpeg;base64,...) или file reference (file:xxx)
            prompt: Описание трансформации ('graphic novel style', etc.)

        Returns:
            operation_id для поллинга. Результат: list of 2 edited image data URIs.
        """
        url = f"{self.base_url}/v4/grok/image/edit"
        body = {'image': image, 'prompt': prompt}
        resp = requests.post(url, headers=self.headers, json=body, timeout=30)
        if resp.status_code == 429:
            raise RateLimitError("Rate limit exceeded (429)")
        if resp.status_code != 200:
            raise RuntimeError(f"Grok edit failed ({resp.status_code}): {_clean_resp_text(resp.text)}")
        data = resp.json()
        op_id = data.get('operation_id') or data.get('id')
        if not op_id:
            raise RuntimeError(f"No operation_id in Grok edit response: {data}")
        return op_id

    # ------------------------------------------------------------------
    # Поллинг операций
    # ------------------------------------------------------------------

    def poll_operation(
        self,
        operation_id: str,
        timeout: Optional[int] = None,
        interval: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Поллить статус операции до завершения.

        Args:
            operation_id: ID операции
            timeout: Макс. время ожидания (секунды)
            interval: Интервал между проверками (секунды)

        Returns:
            Результат операции (содержит images или error)
        """
        timeout = timeout or config.FASTGEN_POLL_TIMEOUT
        interval = interval or config.FASTGEN_POLL_INTERVAL
        url = f"{self.base_url}/v4/operations/{operation_id}"
        deadline = time.time() + timeout

        while time.time() < deadline:
            # Hard Stop / shutdown — abort immediately so hung polls release
            if _flowultra_shutdown_event.is_set():
                raise InterruptedError(f"Operation {operation_id} aborted by shutdown signal")
            resp = requests.get(url, headers=self.headers, timeout=15)
            if resp.status_code != 200:
                raise RuntimeError(f"Poll failed ({resp.status_code}): {_clean_resp_text(resp.text)}")

            data = resp.json()
            # Docs: status enum = pending | processing | success | error (lowercase)
            status = data.get('status', '').lower()

            if status == 'success':
                return data
            elif status in ('error', 'failed', 'cancelled'):
                error_msg = data.get('error', '') or data.get('message', 'Unknown error')
                # Если сервер вернул HTML (Cloudflare/502/503) — заменяем мусор чистым сообщением
                if '<html' in error_msg.lower() or '<!doctype' in error_msg.lower():
                    short = error_msg[:200].replace('\n', ' ')
                    logging.warning(f"Operation {operation_id} server error (HTML response): {short}")
                    raise GenerationError(f"Operation {operation_id} failed: server returned HTML (Cloudflare/503)")
                logging.warning(f"Operation {operation_id} failed: {error_msg[:300]}")
                if is_reference_blocked_error(error_msg):
                    raise ReferenceBlockedError(error_msg)
                if is_content_policy_error(error_msg):
                    raise ContentPolicyError(error_msg)
                raise GenerationError(f"Operation {operation_id} failed: {error_msg}")

            time.sleep(interval)

        raise TimeoutError(f"Operation {operation_id} timed out after {timeout}s")

    # ------------------------------------------------------------------
    # Переписка промпта через FastGen Prompt API
    # ------------------------------------------------------------------

    def rewrite_prompt(self, original_prompt: str, project_dir=None, clip_id=None) -> str:
        """
        Rewrite a blocked prompt via Gemini API.
        Instruction loaded from agent/prompts/rewrite_prompt.txt (user-editable).
        """
        from gemini_rewrite import rewrite_prompt as _gr
        return _gr(original_prompt, project_dir=project_dir, clip_id=clip_id)

    def rewrite_prompt_for_person(self, original_prompt: str, project_dir=None, clip_id=None) -> str:
        """
        Rewrite a blocked prompt with famous person name via Gemini API.
        Unified with rewrite_prompt — the instruction handles both cases.
        """
        from gemini_rewrite import rewrite_prompt as _gr
        return _gr(original_prompt, project_dir=project_dir, clip_id=clip_id)

    # ------------------------------------------------------------------
    # Grok remix (censorship bypass)
    # ------------------------------------------------------------------

    # Дефолтные промпты — используются если файл промпта удалён
    _DEFAULT_REF_REMIX = (
        "Remake this photo in graphic novel / comic book art style. "
        "Preserve the exact facial features, face structure and likeness precisely. "
        "Change only the art rendering style, not the face or identity."
    )
    _DEFAULT_I2V_REMIX = (
        "Same scene from a different camera angle. "
        "Use medium shot or wide shot. Avoid direct face close-up. "
        "Keep same lighting, mood and composition."
    )

    def _load_remix_prompt(self, filename: str, default: str) -> str:
        """Читает промпт из agent/prompts/{filename}. Fallback — default."""
        p = Path(__file__).parent.parent / 'prompts' / filename
        try:
            return p.read_text('utf-8').strip() if p.exists() else default
        except Exception:
            return default

    def _image_to_data_uri(self, image_path: str) -> str:
        """Читает локальный файл изображения и возвращает data URI."""
        p = Path(image_path)
        mime_map = {'.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
                    '.webp': 'image/webp', '.png': 'image/png'}
        mime = mime_map.get(p.suffix.lower(), 'image/png')
        data = base64.b64encode(p.read_bytes()).decode()
        return f"data:{mime};base64,{data}"

    def _grok_edit_and_save(self, image_path: str, output_path: str, prompt: str,
                            poll_timeout: int = 180) -> str:
        """Отправляет изображение в Grok edit, поллит, сохраняет первый вариант.
        При 429 — пробует backup ключ, затем Kie.ai fallback.

        poll_timeout: макс. время ожидания результата (default 180s для i2v — большие картинки).
        Для ref remix вызывающие передают 15s — если Grok висит, это скорее censorship, а не реальная обработка."""
        data_uri = self._image_to_data_uri(image_path)
        # Build list of clients to try: current key → backup key
        _clients = [self]
        _backup_key = config.FASTGEN_API_KEY_BACKUP if hasattr(config, 'FASTGEN_API_KEY_BACKUP') else ''
        _key2 = getattr(config, 'FASTGEN_API_KEY_2', '')
        for _alt_key in (_backup_key, _key2):
            if _alt_key and _alt_key != self.api_key:
                _clients.append(FastGenClient(api_key=_alt_key))
        name = Path(image_path).name
        _last_err = None
        for _ci, _client in enumerate(_clients):
            _key_label = f"key{_ci+1}" if _ci > 0 else "main"
            try:
                op_id = _client.edit_grok(data_uri, prompt)
                _res: list = [None]
                _exc: list = [None]
                def _poll(_c=_client, _oid=op_id, _to=poll_timeout):
                    try:
                        _res[0] = _c.poll_operation(_oid, timeout=_to)
                    except Exception as e:
                        _exc[0] = e
                t = threading.Thread(target=_poll, daemon=True)
                t.start()
                with tqdm(total=180, desc=f"  [GROK {_key_label}] {name}", unit="s",
                          bar_format="{desc}: {bar}| {n:.0f}/{total}s", leave=False) as pbar:
                    while t.is_alive():
                        if _flowultra_shutdown_event.is_set():
                            raise InterruptedError(f"Grok edit {name} aborted by shutdown signal")
                        time.sleep(1)
                        pbar.update(1)
                t.join()
                if _exc[0] is not None:
                    raise _exc[0]
                result = _res[0]
                images = result.get('result') or result.get('images') or []
                if not images:
                    raise RuntimeError(f"Grok edit returned no images: {result}")
                self.save_image(images[0], output_path)
                return output_path
            except (RateLimitError, Exception) as e:
                _last_err = e
                if '429' in str(e) or 'Too many' in str(e) or isinstance(e, RateLimitError):
                    print(f"  {_YELLOW}[GROK 429]{_RESET} {name}: rate limit on {_key_label}, trying next key...")
                    logging.warning(f"Grok edit 429 on {_key_label}: {e}")
                    continue
                raise  # non-429 error — don't fallback
        # All keys exhausted with 429
        raise _last_err or RuntimeError("Grok edit: all keys returned 429")

    def remix_ref_grok(self, image_path: str, output_path: str) -> str:
        """Ремикс референса через Grok. Промпт берётся из ref_remix_prompt.txt.
        poll_timeout=15: если Grok висит >15s на рефе — это скрытый ref-block, быстрее переключаемся."""
        prompt = self._load_remix_prompt('ref_remix_prompt.txt', self._DEFAULT_REF_REMIX)
        print(f"  {_YELLOW}[GROK REMIX]{_RESET} {Path(image_path).name}")
        return self._grok_edit_and_save(image_path, output_path, prompt, poll_timeout=15)

    def remix_ref_flower(self, image_path: str, output_path: str) -> str:
        """Ремикс референса через Flower img2img (/v4/flower/image/generate + reference_image).
        Альтернатива Grok edit когда xAI Cloudflare блокирует edit endpoint."""
        prompt = self._load_remix_prompt('ref_remix_prompt.txt', self._DEFAULT_REF_REMIX)
        print(f"  {_YELLOW}[FLOWER REMIX]{_RESET} {Path(image_path).name}")
        data_uri = self._image_to_data_uri(image_path)
        op_id = self.generate_flower(prompt=prompt, reference_image=data_uri)
        result = self.poll_operation(op_id, timeout=120)
        images = result.get('result') or result.get('images') or []
        if not images:
            raise RuntimeError(f"Flower remix returned no images: {result}")
        self.save_image(images[0], output_path)
        logging.info(f"Flower REF REMIX: {Path(image_path).name} -> {output_path} OK")
        return output_path

    def remix_i2v_grok(self, image_path: str, output_path: str) -> str:
        """Ремикс i2v-кадра через Grok. Промпт берётся из i2v_remix_prompt.txt."""
        prompt = self._load_remix_prompt('i2v_remix_prompt.txt', self._DEFAULT_I2V_REMIX)
        print(f"  {_YELLOW}[GROK I2V REMIX]{_RESET} {Path(image_path).name}")
        return self._grok_edit_and_save(image_path, output_path, prompt)

    def remix_i2v_flower(self, image_path: str, output_path: str, prompt: str) -> str:
        """Ремикс i2v-кадра через Flower img2img. Альтернатива Grok edit (без xAI Cloudflare)."""
        print(f"  {_YELLOW}[FLOWER I2V REMIX]{_RESET} {Path(image_path).name}")
        data_uri = self._image_to_data_uri(image_path)
        op_id = self.generate_flower(prompt=prompt, reference_image=data_uri)
        result = self.poll_operation(op_id, timeout=120)
        images = result.get('result') or result.get('images') or []
        if not images:
            raise RuntimeError(f"Flower i2v remix returned no images: {result}")
        self.save_image(images[0], output_path)
        logging.info(f"Flower I2V REMIX: {Path(image_path).name} -> {output_path} OK")
        return output_path

    def _preflight_test_refs(self, ref_uris: List[str], desc: str = "  [PREFLIGHT] Testing refs",
                             prompt: Optional[str] = None,
                             model: Optional[str] = None,
                             ref_paths: Optional[List] = None) -> bool:
        """
        Тестирует список ref_uris промптом используя тот же движок что и основная генерация.
        True = рефы приняты, False = ReferenceBlockedError.

        Если передан ref_paths (и prompt не переопределён явно) — промпт собирается
        из stem'ов имён файлов: "CHEKAN_ref, FIMA_ref sitting on a chair, cinematic".
        Это воспроизводит реальный промпт генерации (с токенами рефов) чтобы Google
        backend увидел celebrity-триггер на этапе preflight, а не в runtime.
        """
        if not ref_uris:
            return True
        # Auto-prompt из имён файлов (stem без расширения, _ref сохраняется как часть токена)
        if prompt is None:
            if ref_paths:
                _tokens = [Path(p).stem for p in ref_paths[:len(ref_uris)]]
                prompt = f"{', '.join(_tokens)} sitting on a chair, cinematic scene"
            else:
                prompt = "abstract cinematic background, no people"
        self._last_preflight_skipped = False
        _effective_model = model or config.FASTGEN_MODEL
        engine = self._get_engine(_effective_model)
        try:
            if engine == 'gemini':
                op_id = self.generate_gemini(
                    prompt,
                    reference_uris=list(ref_uris),
                    seed=42,
                )
            elif engine == 'flower':
                # Flower endpoint (/v4/flower/image/generate) не принимает `model`
                # и берёт только один reference_image. Для preflight берём первый ref
                # из списка — этого достаточно чтобы Google классификатор среагировал
                # на celebrity-триггер, и валидация Flow API не упала на FLOWER в body.
                op_id = self.generate_flower(
                    prompt=prompt,
                    reference_image=(list(ref_uris)[0] if ref_uris else None),
                )
            else:
                # Передаём model явно — иначе generate_flow берёт config.FASTGEN_MODEL,
                # который может не совпадать с тем что выбрано в GUI (→ 422 validation).
                op_id = self.generate_flow(
                    prompt,
                    reference_uris=list(ref_uris),
                    model=_effective_model,
                    seed=42,
                )
            # Показываем таймер пока poll_operation блокирует
            _result: list = [None]
            _exc:    list = [None]
            # Timeout 180s — Gemini/Banana cold-start + очередь FastGen бывает до 90-120s легитимно.
            # Раньше было 15s → cold-start постоянно trigger'ил ложный "ref-block".
            _PREFLIGHT_POLL_TIMEOUT = 180
            def _poll():
                try:
                    _result[0] = self.poll_operation(op_id, timeout=_PREFLIGHT_POLL_TIMEOUT)
                except Exception as e:
                    _exc[0] = e
            t = threading.Thread(target=_poll, daemon=True)
            t.start()
            with tqdm(total=_PREFLIGHT_POLL_TIMEOUT, desc=desc, unit="s",
                      bar_format="{desc}: {bar}| {n:.0f}/{total}s",
                      leave=False) as pbar:
                while t.is_alive():
                    if _flowultra_shutdown_event.is_set():
                        raise InterruptedError("Preflight aborted by shutdown signal")
                    time.sleep(1)
                    pbar.update(1)
            t.join()
            if _exc[0] is not None:
                raise _exc[0]
            return True
        except ReferenceBlockedError:
            return False
        except (InterruptedError, KeyboardInterrupt):
            # Hard Stop — пробрасываем наверх, чтобы retry-циклы в _isolate_blocked_refs
            # и главном caller'е прервались, а не крутили SKIPPED→retry бесконечно.
            raise
        except TimeoutError as _te:
            # Timeout = SKIPPED (transient), НЕ BLOCKED. Cold-start Gemini/Banana
            # легитимно > 60s. Caller (_isolate_blocked_refs или main) делает retry
            # через _last_preflight_skipped=True. Если после 2 retries всё ещё
            # timeout → там принимается pessimistic BLOCKED. Раньше TimeoutError
            # → return False мгновенно → безобидные рефы ложно помечались bad.
            self._last_preflight_skipped = True
            logging.warning(f"PREFLIGHT: timeout (>{_PREFLIGHT_POLL_TIMEOUT}s) — treating as SKIPPED (transient): {_te}")
            print(f"  {_YELLOW}[PREFLIGHT]{_RESET} TIMEOUT (>{_PREFLIGHT_POLL_TIMEOUT}s) — SKIPPED (transient, will retry)")
            return True
        except Exception as _e:
            _err_low = str(_e).lower()
            # Suspect ref-block: FastGen API иногда маскирует ref-block под generic
            # "Failed to generate" / "Generation failed" без указания причины.
            # Если рефы передавались и ошибка общая (не network/rate/auth) —
            # считаем потенциальным ref-block → caller запустит binary search.
            _generic_fail_markers = ('failed to generate', 'generation failed', 'operation failed')
            _transient_markers   = ('connection', 'rate limit', '429',
                                     '500', '502', '503', 'service unavailable',
                                     'cloudflare', 'econnreset')
            _is_generic_fail  = any(m in _err_low for m in _generic_fail_markers)
            _is_transient     = any(m in _err_low for m in _transient_markers)
            if ref_uris and _is_generic_fail and not _is_transient:
                logging.warning(f"PREFLIGHT: generic '{type(_e).__name__}' with refs — treating as ref-block suspect")
                print(f"  {_YELLOW}[PREFLIGHT]{_RESET} generic fail with refs — treating as ref-block (will isolate)")
                return False  # caller (main preflight or isolate) запустит binary search
            # Не цензура рефов, но и не "OK" — preflight фактически не выполнен.
            # Выставляем флаг, чтобы caller не печатал ложное "OK — refs accepted".
            self._last_preflight_skipped = True
            logging.warning(f"PREFLIGHT: skipped due to exception ({type(_e).__name__}): {_e}")
            print(f"  [PREFLIGHT] SKIPPED ({type(_e).__name__}: {str(_e)[:200]})")
            return True  # пропускаем пайплайн дальше, рефы не забракованы

    def _isolate_blocked_refs(self, uris: List[str], prompt: Optional[str] = None,
                              _step: list = None, model: Optional[str] = None,
                              paths: Optional[List] = None) -> List[int]:
        """
        Бинарный поиск заблокированных рефов.
        Возвращает список индексов плохих рефов в исходном списке.

        paths: список ref_paths (параллельный uris). Если передан — используется для
        auto-промпта в _preflight_test_refs (с токенами из имён файлов).
        """
        if _step is None:
            _step = [0]
        if not uris:
            return []
        # helper: читаемое имя subset'а (токены если paths, иначе счётчик)
        def _subset_label(sub_paths, sub_uris):
            if sub_paths:
                _names = [Path(p).stem for p in sub_paths]
                if len(_names) <= 3:
                    return ', '.join(_names)
                return f"{_names[0]}..{_names[-1]} (x{len(_names)})"
            return f"{len(sub_uris)} refs"

        # helper: test refs with retry on SKIPPED (для transient network errors / timeouts).
        # InterruptedError (Hard Stop) пробрасывается наверх через _preflight_test_refs —
        # retry-цикл прерывается, не крутится на SKIPPED после Stop.
        def _test_with_retry(sub_uris, sub_paths, sub_desc, sub_lbl, step_num, max_retries=2):
            # Check shutdown BEFORE first attempt (user pressed Stop before this step)
            if _flowultra_shutdown_event.is_set():
                raise InterruptedError(f"Isolate step {step_num} aborted by shutdown signal")
            _ok = self._preflight_test_refs(sub_uris, desc=sub_desc, prompt=prompt, model=model, ref_paths=sub_paths)
            _retries_done = 0
            while getattr(self, '_last_preflight_skipped', False) and _retries_done < max_retries:
                _retries_done += 1
                # Check shutdown BEFORE sleep+retry — иначе после Stop будет крутиться 10s+10s попусту
                if _flowultra_shutdown_event.is_set():
                    raise InterruptedError(f"Isolate step {step_num} aborted by shutdown signal (during retry)")
                print(f"  {_YELLOW}[ISOLATE Step {step_num}]{_RESET} SKIPPED — retry {_retries_done}/{max_retries} in 10s: {sub_lbl}", flush=True)
                # Interruptible sleep: 10 × 1s ticks, check shutdown each
                for _ in range(10):
                    if _flowultra_shutdown_event.is_set():
                        raise InterruptedError(f"Isolate step {step_num} aborted by shutdown signal (in retry wait)")
                    time.sleep(1)
                _ok = self._preflight_test_refs(sub_uris, desc=sub_desc, prompt=prompt, model=model, ref_paths=sub_paths)
            if getattr(self, '_last_preflight_skipped', False):
                # после всех retries всё равно SKIPPED — пессимистично BLOCKED
                return False, 'SKIPPED→BLOCKED (all retries failed)'
            return _ok, ('BLOCKED' if not _ok else 'OK')
        if len(uris) == 1:
            _step[0] += 1
            _lbl = _subset_label(paths, uris)
            desc = f"  [ISOLATE] Step {_step[0]} — testing 1 ref ({_lbl})"
            print(f"  {_YELLOW}[ISOLATE Step {_step[0]}]{_RESET} testing 1 ref: {_lbl}", flush=True)
            _ok, _verdict = _test_with_retry(uris, paths, desc, _lbl, _step[0])
            print(f"  {_YELLOW}[ISOLATE Step {_step[0]}]{_RESET} → {_verdict}: {_lbl}", flush=True)
            return [0] if not _ok else []
        mid = len(uris) // 2
        left, right = uris[:mid], uris[mid:]
        left_paths  = paths[:mid] if paths else None
        right_paths = paths[mid:] if paths else None
        bad: List[int] = []
        if left:
            _step[0] += 1
            _lbl = _subset_label(left_paths, left)
            desc = f"  [ISOLATE] Step {_step[0]} — left 1-{mid} ({_lbl})"
            print(f"  {_YELLOW}[ISOLATE Step {_step[0]}]{_RESET} testing left {len(left)} ref(s): {_lbl}", flush=True)
            _ok, _verdict = _test_with_retry(left, left_paths, desc, _lbl, _step[0])
            print(f"  {_YELLOW}[ISOLATE Step {_step[0]}]{_RESET} → {_verdict}: {_lbl}", flush=True)
            if not _ok:
                bad.extend(self._isolate_blocked_refs(left, prompt=prompt, _step=_step, model=model, paths=left_paths))
        if right:
            _step[0] += 1
            _lbl = _subset_label(right_paths, right)
            desc = f"  [ISOLATE] Step {_step[0]} — right {mid+1}-{len(uris)} ({_lbl})"
            print(f"  {_YELLOW}[ISOLATE Step {_step[0]}]{_RESET} testing right {len(right)} ref(s): {_lbl}", flush=True)
            _ok, _verdict = _test_with_retry(right, right_paths, desc, _lbl, _step[0])
            print(f"  {_YELLOW}[ISOLATE Step {_step[0]}]{_RESET} → {_verdict}: {_lbl}", flush=True)
            if not _ok:
                bad.extend(i + mid for i in self._isolate_blocked_refs(right, prompt=prompt, _step=_step, model=model, paths=right_paths))
        return bad

    # ------------------------------------------------------------------
    # Сохранение изображения
    # ------------------------------------------------------------------

    @staticmethod
    def save_image(data_uri: str, output_path: str):
        """
        Декодировать data:image/...;base64,... и сохранить в файл.

        Args:
            data_uri: Base64 data URI
            output_path: Путь для сохранения
        """
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)

        if data_uri.startswith('data:'):
            # data:image/png;base64,iVBOR...
            header, b64data = data_uri.split(',', 1)
        else:
            b64data = data_uri

        img_bytes = base64.b64decode(b64data)
        with open(path, 'wb') as f:
            f.write(img_bytes)

    # ------------------------------------------------------------------
    # Проверка квоты
    # ------------------------------------------------------------------

    def get_usage(self) -> Dict[str, Any]:
        """
        Получить информацию об использовании API (квоты, лимиты).

        Returns:
            Словарь с данными usage
        """
        url = f"{self.base_url}/v2/usage"
        resp = requests.get(url, headers=self.headers, timeout=15)
        if resp.status_code != 200:
            logging.warning(f"Usage check failed ({resp.status_code})")
            return {}
        return resp.json()

    def get_flow_ultra_usage(self) -> Dict[str, int]:
        """
        Получить Flow Ultra-специфичные лимиты из /api/v2/usage.

        Returns:
            {
                'hour_limit':      int,  # flow_ultra_hour_limit
                'threads_allowed': int,  # flow_ultra_threads_allowed (для Spinbox Parallel)
                'active_threads':  int,  # current flow_ultra_threads (используется сейчас)
                'available':       bool, # True если threads_allowed > 0 (подписка активна)
            }
        """
        usage = self.get_usage()
        al = usage.get('account_limits', {}) or {}
        cu = usage.get('current_usage', {}).get('active_threads', {}) or {}
        threads_allowed = int(al.get('flow_ultra_threads_allowed', 0) or 0)
        return {
            'hour_limit':      int(al.get('flow_ultra_hour_limit', 0) or 0),
            'threads_allowed': threads_allowed,
            'active_threads':  int(cu.get('flow_ultra_threads', 0) or 0),
            'available':       threads_allowed > 0,
        }

    # ------------------------------------------------------------------
    # Flow Ultra — T2V (text-to-video) generation
    # Endpoint: POST /api/v4/flow-ultra/video/from-text
    # Result: {status:"success", result: ["data:video/mp4;base64,..."]}
    # Typical gen time: ~90s per 5s clip
    # ------------------------------------------------------------------

    def generate_flow_ultra_t2v(
        self,
        prompt: str,
        output_path: str,
        aspect_ratio: str = "16:9",
        quality: Optional[str] = None,
        poll_interval: int = 5,
        poll_timeout: int = 600,
    ) -> str:
        """
        Сгенерировать видео text-to-video через FastGen Flow Ultra.
        Длительность — фиксированная 8 секунд (зашита в Veo-модель, API игнорит custom duration).

        Args:
            prompt: текст-промпт
            output_path: куда сохранить .mp4
            aspect_ratio: '16:9' | '9:16' | '1:1'
            quality: 'fast' | 'ultra' | None (дефолт)
            poll_interval: опрос статуса каждые N секунд
            poll_timeout: максимум времени ожидания (секунды)

        Returns:
            Путь к сохранённому файлу .mp4
        """
        import base64 as _b64

        url = f"{self.base_url}/v4/flow-ultra/video/from-text"
        body = {"prompt": prompt, "aspect_ratio": aspect_ratio}
        if quality:
            body["quality"] = quality

        # Skip if shutdown already requested
        if _flowultra_shutdown_event.is_set():
            raise GenerationError("flow-ultra: shutdown requested before submit")

        resp = requests.post(url, headers=self.headers, json=body, timeout=60)
        if resp.status_code != 200:
            raise GenerationError(
                f"flow-ultra submit failed ({resp.status_code}): {_clean_resp_text(resp.text)}"
            )
        data = resp.json()
        if not data.get("success") or not data.get("operation_id"):
            raise GenerationError(f"flow-ultra submit bad response: {str(data)[:300]}")
        op_id = data["operation_id"]
        logging.info(f"flow-ultra T2V submitted: operation_id={op_id}")

        # Poll until done
        deadline = time.time() + poll_timeout
        while time.time() < deadline:
            if _flowultra_shutdown_event.is_set():
                raise GenerationError(f"flow-ultra: shutdown requested (op_id={op_id})")
            time.sleep(poll_interval)
            op_url = f"{self.base_url}/v4/operations/{op_id}"
            try:
                opr = requests.get(op_url, headers=self.headers, timeout=20)
            except requests.exceptions.RequestException as _e:
                logging.warning(f"flow-ultra poll error: {_e}")
                continue
            if opr.status_code != 200:
                logging.warning(f"flow-ultra poll HTTP {opr.status_code}: {opr.text[:200]}")
                continue
            pdata = opr.json()
            status = pdata.get("status")
            if status == "success":
                result = pdata.get("result") or []
                if not result:
                    raise GenerationError(f"flow-ultra succeeded but empty result: {pdata}")
                # Result item: 'data:video/mp4;base64,...'
                entry = result[0]
                if isinstance(entry, str) and entry.startswith("data:"):
                    b64 = entry.split(",", 1)[-1]
                    video_bytes = _b64.b64decode(b64)
                    out = Path(output_path)
                    out.parent.mkdir(parents=True, exist_ok=True)
                    out.write_bytes(video_bytes)
                    logging.info(f"flow-ultra T2V done -> {output_path} ({len(video_bytes)//1024} KB)")
                    return str(out)
                # Fallback: URL?
                if isinstance(entry, str) and entry.startswith("http"):
                    r = requests.get(entry, timeout=(30, 300), stream=True)
                    if r.status_code != 200:
                        raise GenerationError(f"flow-ultra result URL fetch failed: {r.status_code}")
                    out = Path(output_path)
                    out.parent.mkdir(parents=True, exist_ok=True)
                    with open(out, "wb") as f:
                        for chunk in r.iter_content(8192):
                            f.write(chunk)
                    logging.info(f"flow-ultra T2V done -> {output_path} (via URL)")
                    return str(out)
                raise GenerationError(f"flow-ultra unknown result entry type: {str(entry)[:120]}")
            if status in ("failed", "error"):
                err = pdata.get("error") or str(pdata)[:300]
                raise GenerationError(f"flow-ultra operation failed: {err}")
            # still pending/processing — continue polling

        raise GenerationError(f"flow-ultra polling timeout after {poll_timeout}s (op_id={op_id})")

    # ------------------------------------------------------------------
    # Flow Ultra — Ingredients (ref-image driven t2v) and Keyframes (start+end)
    # ------------------------------------------------------------------

    def _flow_ultra_submit_and_poll(
        self,
        endpoint_suffix: str,
        body: dict,
        output_path: str,
        poll_interval: int = 5,
        poll_timeout: int = 600,
    ) -> str:
        """Shared submit + poll + save helper for all flow-ultra video endpoints."""
        import base64 as _b64

        if _flowultra_shutdown_event.is_set():
            raise GenerationError("flow-ultra: shutdown requested before submit")

        url = f"{self.base_url}{endpoint_suffix}"
        resp = requests.post(url, headers=self.headers, json=body, timeout=60)
        if resp.status_code != 200:
            raise GenerationError(
                f"flow-ultra submit failed ({resp.status_code}): {_clean_resp_text(resp.text)}"
            )
        data = resp.json()
        if not data.get("success") or not data.get("operation_id"):
            raise GenerationError(f"flow-ultra submit bad response: {str(data)[:300]}")
        op_id = data["operation_id"]
        logging.info(f"flow-ultra submitted {endpoint_suffix}: operation_id={op_id}")

        deadline = time.time() + poll_timeout
        while time.time() < deadline:
            if _flowultra_shutdown_event.is_set():
                raise GenerationError(f"flow-ultra: shutdown requested (op_id={op_id})")
            time.sleep(poll_interval)
            try:
                opr = requests.get(
                    f"{self.base_url}/v4/operations/{op_id}",
                    headers=self.headers, timeout=20,
                )
            except requests.exceptions.RequestException:
                continue
            if opr.status_code != 200:
                continue
            pdata = opr.json()
            status = pdata.get("status")
            if status == "success":
                result = pdata.get("result") or []
                if not result:
                    raise GenerationError(f"flow-ultra empty result: {pdata}")
                entry = result[0]
                out = Path(output_path)
                out.parent.mkdir(parents=True, exist_ok=True)
                if isinstance(entry, str) and entry.startswith("data:"):
                    out.write_bytes(_b64.b64decode(entry.split(",", 1)[-1]))
                    return str(out)
                if isinstance(entry, str) and entry.startswith("http"):
                    r = requests.get(entry, timeout=(30, 300), stream=True)
                    if r.status_code != 200:
                        raise GenerationError(f"flow-ultra URL fetch failed: {r.status_code}")
                    with open(out, "wb") as f:
                        for chunk in r.iter_content(8192):
                            f.write(chunk)
                    return str(out)
                raise GenerationError(f"flow-ultra unknown result entry: {str(entry)[:120]}")
            if status in ("failed", "error"):
                err = pdata.get("error") or str(pdata)[:300]
                raise GenerationError(f"flow-ultra operation failed: {err}")
        raise GenerationError(f"flow-ultra polling timeout after {poll_timeout}s (op_id={op_id})")

    @staticmethod
    def _image_to_b64_data_uri(path: str) -> str:
        """Load image file → 'data:image/<ext>;base64,...' data URI for API."""
        import base64 as _b64
        p = Path(path)
        ext = p.suffix.lower().lstrip(".") or "jpeg"
        mime_map = {"jpg": "jpeg", "jpeg": "jpeg", "png": "png", "webp": "webp"}
        mime = mime_map.get(ext, "jpeg")
        b64 = _b64.b64encode(p.read_bytes()).decode("ascii")
        return f"data:image/{mime};base64,{b64}"

    def generate_flow_ultra_ingredients(
        self,
        prompt: str,
        reference_images: List[str],     # list of local image paths (1-3)
        output_path: str,
        aspect_ratio: str = "16:9",
        seed: Optional[int] = None,
        poll_interval: int = 5,
        poll_timeout: int = 600,
    ) -> str:
        """Flow Ultra: video from text + 1-3 reference images (t2v with ref guidance)."""
        if not reference_images:
            raise GenerationError("ingredients requires at least 1 reference image")
        if len(reference_images) > 3:
            reference_images = reference_images[:3]
        refs = [self._image_to_b64_data_uri(p) for p in reference_images]
        body = {"prompt": prompt, "reference_images": refs, "aspect_ratio": aspect_ratio}
        if seed is not None:
            body["seed"] = int(seed)
        return self._flow_ultra_submit_and_poll(
            "/v4/flow-ultra/video/from-ingredients", body, output_path,
            poll_interval=poll_interval, poll_timeout=poll_timeout,
        )

    def generate_flow_ultra_keyframes(
        self,
        prompt: str,
        start_image: str,                # local path
        output_path: str,
        end_image: Optional[str] = None, # optional local path
        aspect_ratio: str = "16:9",
        seed: Optional[int] = None,
        poll_interval: int = 5,
        poll_timeout: int = 600,
    ) -> str:
        """Flow Ultra: video from start (+ optional end) keyframes (i2v / extend-like)."""
        body = {
            "prompt": prompt,
            "start_image": self._image_to_b64_data_uri(start_image),
            "aspect_ratio": aspect_ratio,
        }
        if end_image:
            body["end_image"] = self._image_to_b64_data_uri(end_image)
        if seed is not None:
            body["seed"] = int(seed)
        return self._flow_ultra_submit_and_poll(
            "/v4/flow-ultra/video/from-keyframes", body, output_path,
            poll_interval=poll_interval, poll_timeout=poll_timeout,
        )

    def cancel_all_tasks(self) -> dict:
        """
        Отменить все активные операции (pending/processing) для этого API ключа.
        Pending-задачи получают рефанд токенов.
        Returns: {'total_found': N, 'total_cancelled': N, 'total_refunded': N}
        """
        url = f"{self.base_url}/v4/operations/cancel-all"
        try:
            resp = requests.get(url, headers=self.headers, timeout=15)
            if resp.status_code == 200:
                return resp.json()
            logging.warning(f"cancel_all_tasks failed ({resp.status_code}): {_clean_resp_text(resp.text)}")
        except Exception as e:
            logging.warning(f"cancel_all_tasks error: {e}")
        return {}


def parse_usage_remaining(usage: Dict[str, Any]):
    """
    Вычисляет оставшиеся генерации из ответа /v2/usage.

    Структура ответа API:
      account_limits.img_gen_per_hour_limit  — лимит в час
      current_usage.hourly_usage.image_generation.current_usage — использовано

    Возвращает int или None если данные недоступны.
    """
    if not usage:
        return None
    limit = usage.get('account_limits', {}).get('img_gen_per_hour_limit')
    if limit is None:
        return None
    hourly = usage.get('current_usage', {}).get('hourly_usage', {})
    img_gen = hourly.get('image_generation') if hourly else None
    used = img_gen.get('current_usage', 0) if img_gen else 0
    return max(0, int(limit) - int(used))


def parse_usage_threads(usage: Dict[str, Any]):
    """Возвращает кол-во разрешённых потоков генерации или '?'."""
    if not usage:
        return '?'
    return usage.get('account_limits', {}).get('img_generation_threads_allowed', '?')


# ======================================================================
# Кастомные исключения
# ======================================================================

class RateLimitError(Exception):
    """429 — превышен лимит запросов"""
    pass


class QuotaExhaustedError(Exception):
    """Часовая квота полностью исчерпана (img_gen_per_hour_remaining=0)"""
    pass


class ContentPolicyError(Exception):
    """Генерация отклонена из-за нарушения content policy"""
    pass


class ProminentPersonPromptError(ContentPolicyError):
    """Цензура из-за упоминания известной личности по имени в тексте промпта"""
    pass


class ReferenceBlockedError(Exception):
    """Генерация отклонена из-за референсных изображений (лица известных людей и т.п.)"""
    pass


class GenerationError(Exception):
    """Общая ошибка генерации"""
    pass


def is_content_policy_error(error_msg: str) -> bool:
    """Определить, является ли ошибка нарушением content policy"""
    msg_lower = error_msg.lower()
    return any(phrase in msg_lower for phrase in [
        'content policy',
        'policy violation',
        'safety filter',
        'blocked by safety',
        'harmful content',
    ])


def is_reference_blocked_error(error_msg: str) -> bool:
    """Определить, является ли ошибка блокировкой из-за референсов"""
    msg_lower = error_msg.lower()
    return any(phrase in msg_lower for phrase in [
        'prominent people',
        'well-known individuals',
        'known individuals',
        'celebrity',
        'public figure',
    ])


# ======================================================================
# Сканирование референсов
# ======================================================================

def scan_references(project_dir: str) -> Dict[str, List[Path]]:
    """
    Сканировать папку ref/ в проекте на наличие изображений.

    Структура:
        ref/            ← корневые файлы (для Flow)
        ref/subject/    ← персонажи (для Whisk)
        ref/scene/      ← локации (для Whisk)
        ref/style/      ← стиль (для Whisk)

    Returns:
        {
            'root': [Path, ...],
            'subject': [Path, ...],
            'scene': [Path, ...],
            'style': [Path, ...],
        }
    """
    ref_dir = Path(project_dir) / 'ref'
    result = {'root': [], 'subject': [], 'scene': [], 'style': []}

    if not ref_dir.exists():
        return result

    # Корневые файлы (не в подпапках)
    for f in ref_dir.iterdir():
        if f.is_file() and f.suffix.lower() in IMAGE_EXTENSIONS:
            result['root'].append(f)

    # Подпапки
    for category in ('subject', 'scene', 'style'):
        cat_dir = ref_dir / category
        if cat_dir.exists() and cat_dir.is_dir():
            for f in cat_dir.iterdir():
                if f.is_file() and f.suffix.lower() in IMAGE_EXTENSIONS:
                    result[category].append(f)

    # Сортировка по имени
    for key in result:
        result[key].sort(key=lambda p: p.name.lower())

    return result


def detect_reference_mode(refs: Dict[str, List[Path]]) -> Optional[str]:
    """
    Автоматически определить режим референсов.

    Returns:
        'flow' — если файлы только в корне
        'whisk' — если файлы только в подпапках
        'ask' — если файлы и там и там (нужен выбор)
        None — если нет файлов
    """
    has_root = len(refs['root']) > 0
    has_categories = any(len(refs[cat]) > 0 for cat in ('subject', 'scene', 'style'))

    if not has_root and not has_categories:
        return None
    if has_root and not has_categories:
        return 'flow'
    if has_categories and not has_root:
        return 'whisk'
    return 'ask'


def print_reference_summary(refs: Dict[str, List[Path]]):
    """Вывести информацию о найденных референсах"""
    print("\n" + "=" * 60)
    print("  REFERENCES")
    print("=" * 60)

    for category, label in [('root', 'ref/ (root)'), ('subject', 'ref/subject/'),
                             ('scene', 'ref/scene/'), ('style', 'ref/style/')]:
        files = refs[category]
        if files:
            names = ', '.join(f.name for f in files[:5])
            if len(files) > 5:
                names += f", ... (+{len(files) - 5})"
            print(f"  {label:<18} {len(files)} file(s)  ({names})")
        else:
            print(f"  {label:<18} 0 files")


def ask_reference_mode() -> str:
    """Спросить у пользователя режим референсов"""
    print("\n  Available modes:")
    print("    [1] Flow API  - all files as general references (up to 10)")
    print("    [2] Whisk Remix - categorized: subject, scene, style (up to 3 total)")
    print()

    while True:
        choice = input("  Select mode [1/2]: ").strip()
        if choice == '1':
            return 'flow'
        elif choice == '2':
            return 'whisk'
        print("  Invalid choice, enter 1 or 2")


# ======================================================================
# Генерация одного клипа с retry + rewrite
# ======================================================================

def _run_generate_attempt(
    client: FastGenClient,
    clip_id: int,
    prompt: str,
    ref_uris: Optional[List[str]],
    mode: str,
    whisk_refs: Optional[Dict[str, List[str]]],
    output_dir: Path,
    model: str,
    aspect_ratio: str,
    seed: Optional[int],
) -> Dict[str, Any]:
    """
    Один полный цикл: запуск генерации + поллинг + сохранение.
    Возвращает {'ok': True, 'file': str, 'elapsed': float}
    или бросает исключение.
    """
    import random as _random
    effective_seed = seed if seed is not None else _random.randint(1, 2**31)
    engine = FastGenClient._get_engine(model)

    if engine == 'gemini':
        op_id = client.generate_gemini(prompt=prompt, reference_uris=ref_uris or None, seed=effective_seed)
    elif engine == 'grok':
        op_id = client.generate_grok(prompt=prompt, aspect_ratio=aspect_ratio, seed=effective_seed)
    elif engine == 'flower':
        op_id = client.generate_flower(prompt=prompt, aspect_ratio=aspect_ratio)
    elif engine == 'whisk':
        if mode == 'whisk' and whisk_refs:
            op_id = client.generate_whisk(
                prompt=prompt,
                subject_uris=whisk_refs.get('subject'),
                scene_uris=whisk_refs.get('scene'),
                style_uris=whisk_refs.get('style'),
            )
        else:
            op_id = client.generate_whisk_text(prompt=prompt, aspect_ratio=aspect_ratio, seed=effective_seed)
    else:  # flow
        if mode == 'whisk' and whisk_refs:
            op_id = client.generate_whisk(
                prompt=prompt,
                subject_uris=whisk_refs.get('subject'),
                scene_uris=whisk_refs.get('scene'),
                style_uris=whisk_refs.get('style'),
            )
        else:
            op_id = client.generate_flow(
                prompt=prompt, reference_uris=ref_uris, model=model,
                aspect_ratio=aspect_ratio, seed=effective_seed,
            )

    op_result = client.poll_operation(op_id)
    images = op_result.get('result') or []
    if not images:
        raise GenerationError(f"No images in operation result: {op_result}")

    output_path = output_dir / f"{clip_id:03d}.png"
    client.save_image(images[0], str(output_path))
    # ── SynthID watermark removal (inflight, runs in worker thread) ──────────
    if output_path.exists():
        _synthid_clean_if_needed(str(output_path))
    return {'ok': True, 'file': str(output_path), 'operation_id': op_id}


def _attempt_phase(
    client: FastGenClient,
    clip_id: int,
    prompt: str,
    ref_uris, mode, whisk_refs, output_dir,
    model: str, aspect_ratio: str,
    max_attempts: int,
    phase_label: str,
    stop_event=None,
) -> Dict[str, Any]:
    """
    Фаза: max_attempts попыток с новым случайным сидом каждый раз.
    Возвращает {'ok': True, ...} или {'ok': False, 'last_error': str, 'censored': bool}.
    stop_event: threading.Event — если установлен, прерывает попытки досрочно (рефреш рефов).
    """
    import random as _random
    censored = False
    prominent_people = False
    ref_blocked = False
    last_error = ''

    for attempt in range(1, max_attempts + 1):
        # Проверяем стоп-сигнал (досрочный рефреш рефов)
        if stop_event is not None and stop_event.is_set():
            last_error = 'interrupted: ref TTL refresh requested'
            break
        # Hard Stop — мгновенно выходим из цикла попыток
        if _flowultra_shutdown_event.is_set():
            last_error = 'interrupted: hard stop'
            break
        seed = _random.randint(1, 2**31)
        try:
            start = time.time()
            res = _run_generate_attempt(
                client, clip_id, prompt, ref_uris, mode, whisk_refs,
                output_dir, model, aspect_ratio, seed,
            )
            elapsed = round(time.time() - start, 1)
            res['elapsed'] = elapsed
            return res

        except ReferenceBlockedError as e:
            last_error = str(e)
            has_refs = bool(ref_uris or whisk_refs)
            if has_refs:
                ref_blocked = True
                logging.error(f"Clip #{clip_id} [{phase_label}]: REF BLOCKED — reference images contain a prominent person")
                print(f"\n  {_RED}[REF BLOCKED]{_RESET} #{clip_id}: ⚠  Reference image contains a prominent/famous person!")
                print(f"               Fix: remove or replace the reference images for this clip.")
                print(f"               Prompt rewrite cannot help — problem is in the ref image, not the text.")
            else:
                prominent_people = True
                logging.warning(f"Clip #{clip_id} [{phase_label}]: PROMINENT PERSON IN PROMPT — will rewrite with appearance description")
                print(f"\n  {_RED}[PERSON NAME]{_RESET} #{clip_id}: prompt mentions a famous person by name — will rewrite using appearance description")
            break

        except ContentPolicyError as e:
            censored = True
            last_error = str(e)
            logging.warning(f"Clip #{clip_id} [{phase_label}] attempt {attempt}: CENSORED — {e}")
            print(f"\n  {_RED}[CENSORED]{_RESET} #{clip_id} [{phase_label}] attempt {attempt}/{max_attempts}")
            # При цензуре нет смысла ретраить с новым сидом — сразу выходим из фазы
            break

        except RateLimitError:
            # Проверяем: это обычный rate limit или часовая квота исчерпана?
            try:
                usage = client.get_usage()
                remaining = parse_usage_remaining(usage)
                if remaining is not None and remaining == 0:
                    raise QuotaExhaustedError("Hourly quota exhausted (remaining=0)")
            except QuotaExhaustedError:
                raise  # пробрасываем наверх
            except Exception:
                pass  # не смогли проверить — продолжаем стандартный ретрай
            _rl_wait = int(5 + random.uniform(1, 5))
            msg = f"#{clip_id} [{phase_label}] attempt {attempt}: rate limit, waiting {_rl_wait}s..."
            logging.warning(f"Clip {msg}")
            print(f"\n  {_YELLOW}[RATELIMIT]{_RESET} {msg}")
            with tqdm(total=_rl_wait, desc=f"  [RATELIMIT] #{clip_id}", unit="s",
                      bar_format="{desc}: {bar}| {n:.0f}/{total}s", leave=False) as _pbar:
                for _ in range(_rl_wait):
                    time.sleep(1)
                    _pbar.update(1)
            # Не считаем за попытку

        except TimeoutError as e:
            last_error = str(e)
            logging.warning(f"Clip #{clip_id} [{phase_label}] attempt {attempt}/{max_attempts}: timeout")
            print(f"\n  {_YELLOW}[TIMEOUT]{_RESET}   #{clip_id} [{phase_label}] {attempt}/{max_attempts}, seed={seed}")
            if attempt < max_attempts:
                delay = min(5 * attempt, 30)
                print(f"  {_YELLOW}[RETRY]{_RESET}     new seed, waiting {delay}s...")
                time.sleep(delay)

        except InterruptedError as e:
            # Hard Stop / shutdown — не ретраим, выходим немедленно
            last_error = str(e)
            logging.info(f"Clip #{clip_id} [{phase_label}]: hard stop — no retry")
            break

        except Exception as e:
            last_error = str(e)
            _err_low = str(e).lower()
            # Fatal auth errors — no point retrying
            _fatal_kw = ['license_expired', 'license expired', 'auth.license_expired',
                         'credits insufficient', 'account suspended']
            if any(kw in _err_low for kw in _fatal_kw):
                logging.error(f"Clip #{clip_id} [{phase_label}]: FATAL auth error — {e}")
                print(f"\n  {_RED}[AUTH FATAL]{_RESET} #{clip_id}: {e}")
                print(f"  {_RED}[AUTH FATAL]{_RESET} Skipping all retries — key/license is dead")
                break
            # Suspect ref-block: FastGen маскирует ref-block под generic "Failed to generate".
            # Если рефы переданы и ошибка общая (не network/auth/rate) — триггерим ref_blocked.
            _generic_fail_markers = ('failed to generate', 'generation failed', 'operation failed')
            _transient_markers   = ('timeout', 'connection', 'rate limit', '429',
                                     '500', '502', '503', 'service unavailable',
                                     'cloudflare', 'econnreset')
            if ref_uris and any(m in _err_low for m in _generic_fail_markers) \
                    and not any(m in _err_low for m in _transient_markers):
                ref_blocked = True
                logging.warning(f"Clip #{clip_id} [{phase_label}]: generic fail with refs — treating as ref-block")
                print(f"\n  {_YELLOW}[SUSPECT REF-BLOCK]{_RESET} #{clip_id}: generic fail with refs — will trigger remix cycle")
                break
            logging.warning(f"Clip #{clip_id} [{phase_label}] attempt {attempt}/{max_attempts}: {e}")
            print(f"\n  {_YELLOW}[ERROR]{_RESET}     #{clip_id} [{phase_label}] {attempt}/{max_attempts}, seed={seed}: {e}")
            if attempt < max_attempts:
                delay = min(5 * attempt, 30)
                print(f"  {_YELLOW}[RETRY]{_RESET}     new seed, waiting {delay}s...")
                time.sleep(delay)

    _fatal_kw = ['license_expired', 'license expired', 'auth.license_expired',
                 'credits insufficient', 'account suspended']
    _is_dead = any(kw in last_error.lower() for kw in _fatal_kw) if last_error else False
    return {
        'ok': False,
        'last_error': last_error,
        'censored': censored,
        'prominent_people': prominent_people,
        'ref_blocked': ref_blocked,
        'license_dead': _is_dead,
    }


def generate_single_clip(
    client,   # FastGenClient or None (None when clients_cfg_list provided)
    clip_id: int,
    prompt: str,
    ref_uris: Optional[List[str]],
    mode: str,
    whisk_refs: Optional[Dict[str, List[str]]],
    output_dir: Path,
    model: Optional[str] = None,
    aspect_ratio: Optional[str] = None,
    stop_event=None,
    stagger_delay: float = 0.0,
    worker_id_fn=None,       # если задан — трекаем worker_id для dual-key
    clients_cfg_list=None,   # если задан — worker-assignment вместо round-robin
    on_ref_blocked=None,     # callback(): ремикс рефов через Grok, обновляет cfg в-place
    cfg_ref=None,            # dict cfg текущего ключа (для re-read ref_uris после ремикса)
) -> Dict[str, Any]:
    """
    Генерация одного изображения.

    Логика:
      Фаза 1: 10 попыток с новым сидом каждый раз.
      Если все 10 провалились → rewrite промпта через Prompt API.
      Фаза 2: ещё 10 попыток с переписанным промптом (новый сид каждый раз).
      Если снова провал → возвращает статус 'error'/'censored' с деталями.

    stop_event: threading.Event — при установке прерывает попытки между итерациями.

    Returns:
        {'id': int, 'status': 'ok'|'error'|'censored', 'file': str,
         'rewritten': bool, 'phase': int, 'error': str, ...}
    """
    # ── Worker-assignment: определяем client/refs по worker_id (если dual-key) ──
    if clients_cfg_list and worker_id_fn:
        worker_id = worker_id_fn()
        cumulative = 0
        _selected = clients_cfg_list[-1]
        _group_start = 0
        for _cfg in clients_cfg_list:
            if worker_id < cumulative + _cfg['mp']:
                _selected = _cfg
                _group_start = cumulative
                break
            cumulative += _cfg['mp']
        client     = _selected['client']
        ref_uris   = _selected.get('ref_uris') or []
        whisk_refs = _selected.get('whisk_refs') or {}
        cfg_ref    = _selected   # для re-read после remix
        _local_id  = worker_id - _group_start
        # Стаггер: первый запуск воркера — разброс; повторный — 1s + jitter
        with _fg_started_workers_lock:
            is_first = worker_id not in _fg_started_workers
            _fg_started_workers.add(worker_id)
        stagger_delay = (_local_id * 2.0 + random.uniform(1, 5)) if is_first else (1.0 + random.uniform(0.5, 1.5))

    if stagger_delay > 0:
        time.sleep(stagger_delay)

    MAX_ATTEMPTS = 10
    effective_model = model or config.FASTGEN_MODEL

    result = {
        'id': clip_id,
        'status': 'error',
        'file': None,
        'operation_id': None,
        'error': None,
        'duration_sec': 0,
        'rewritten': False,
        'phase': 1,
    }

    # ── ФАЗА 1: оригинальный промпт, 10 попыток ──────────────────────
    phase1 = _attempt_phase(
        client, clip_id, prompt, ref_uris, mode, whisk_refs,
        output_dir, effective_model, aspect_ratio or config.FASTGEN_ASPECT_RATIO,
        MAX_ATTEMPTS, 'phase1', stop_event=stop_event,
    )

    if phase1['ok']:
        result.update({
            'status': 'ok',
            'file': phase1['file'],
            'operation_id': phase1.get('operation_id'),
            'duration_sec': phase1.get('elapsed', 0),
            'phase': 1,
        })
        suffix = ""
        logging.info(f"Clip #{clip_id}: OK phase1 ({result['duration_sec']}s)")
        print(f"  {_GREEN}[OK]{_RESET} #{clip_id}: {result['duration_sec']}s")
        return result

    # Фаза 1 провалилась
    # License dead — no rewrite/remix, signal to caller to switch key
    if phase1.get('license_dead'):
        result['error'] = phase1['last_error']
        result['license_dead'] = True
        return result

    # Ref-blocked: ремиксим через remix engine (grok/kieai) до 3 раз. Без рефов НЕ генерим.
    if phase1.get('ref_blocked'):
        REF_REMIX_ATTEMPTS = 3
        for _remix_attempt in range(1, REF_REMIX_ATTEMPTS + 1):
            if _remix_attempt == 1 and on_ref_blocked and ref_uris:
                # Первый ремикс — через session-level callback (binary search + upload всех ключей)
                print(f"  {_YELLOW}[REF BLOCKED → REMIX {_remix_attempt}/{REF_REMIX_ATTEMPTS}]{_RESET} #{clip_id}: remixing refs...")
                logging.warning(f"Clip #{clip_id}: REF BLOCKED — ref remix attempt {_remix_attempt}/{REF_REMIX_ATTEMPTS}")
                on_ref_blocked()
                if cfg_ref is not None:
                    ref_uris = cfg_ref.get('ref_uris') or []
            elif _remix_attempt > 1 and cfg_ref is not None:
                # Повторные ремиксы — прямой вызов remix_ref для свежего варианта
                ref_paths = cfg_ref.get('ref_paths_flow') or []
                if not ref_paths:
                    break
                print(f"  {_YELLOW}[REF BLOCKED → REMIX {_remix_attempt}/{REF_REMIX_ATTEMPTS}]{_RESET} #{clip_id}: fresh remix...")
                logging.warning(f"Clip #{clip_id}: REF BLOCKED — ref remix attempt {_remix_attempt}/{REF_REMIX_ATTEMPTS}")
                new_uris = []
                try:
                    for orig in ref_paths:
                        remix_ref(str(orig), str(orig))
                        new_uris.append(client.upload_reference(str(orig)))
                    cfg_ref['ref_uris'] = new_uris
                    ref_uris = new_uris
                except Exception as _re:
                    logging.error(f"Clip #{clip_id}: remix attempt {_remix_attempt} failed: {_re}")
                    continue
            else:
                break

            if not ref_uris:
                break

            phase1_remixed = _attempt_phase(
                client, clip_id, prompt, ref_uris, mode, whisk_refs,
                output_dir, effective_model, aspect_ratio or config.FASTGEN_ASPECT_RATIO,
                MAX_ATTEMPTS, f'phase1_remix{_remix_attempt}', stop_event=stop_event,
            )
            if phase1_remixed['ok']:
                result.update({
                    'status': 'ok',
                    'file': phase1_remixed['file'],
                    'operation_id': phase1_remixed.get('operation_id'),
                    'duration_sec': phase1_remixed.get('elapsed', 0),
                    'phase': 1,
                    'rewritten': False,
                })
                logging.info(f"Clip #{clip_id}: OK after ref remix #{_remix_attempt} ({result['duration_sec']}s)")
                print(f"  {_GREEN}[OK-REMIX-{_remix_attempt}]{_RESET} #{clip_id}: {result['duration_sec']}s")
                return result
            phase1 = phase1_remixed
            if not phase1.get('ref_blocked'):
                break  # другая ошибка — дальше ремикс не поможет

        # Попытка 4: ремикс последнего ремикса (remix of remix)
        if cfg_ref is not None and phase1.get('ref_blocked'):
            ref_paths = cfg_ref.get('ref_paths_flow') or []
            _ror_uris = []
            _ror_ok = False
            try:
                print(f"  {_YELLOW}[REF BLOCKED → REMIX-OF-REMIX]{_RESET} #{clip_id}: remixing last remix output...")
                logging.warning(f"Clip #{clip_id}: REF BLOCKED — remix-of-remix attempt")
                for orig in ref_paths:
                    remix_ref(str(orig), str(orig))
                    _ror_uris.append(client.upload_reference(str(orig)))
                _ror_ok = bool(_ror_uris)
            except Exception as _re:
                logging.error(f"Clip #{clip_id}: remix-of-remix failed: {_re}")

            if _ror_ok:
                phase1_ror = _attempt_phase(
                    client, clip_id, prompt, _ror_uris, mode, whisk_refs,
                    output_dir, effective_model, aspect_ratio or config.FASTGEN_ASPECT_RATIO,
                    MAX_ATTEMPTS, 'phase1_remix_ror', stop_event=stop_event,
                )
                if phase1_ror['ok']:
                    result.update({
                        'status': 'ok',
                        'file': phase1_ror['file'],
                        'operation_id': phase1_ror.get('operation_id'),
                        'duration_sec': phase1_ror.get('elapsed', 0),
                        'phase': 1,
                        'rewritten': False,
                    })
                    logging.info(f"Clip #{clip_id}: OK after remix-of-remix ({result['duration_sec']}s)")
                    print(f"  {_GREEN}[OK-REMIX-ROR]{_RESET} #{clip_id}: {result['duration_sec']}s")
                    return result
                phase1 = phase1_ror

        # Все попытки ремикса не помогли — клип пропускаем, без рефов не генерим
        print(f"  {_RED}[REF BLOCKED — SKIP]{_RESET} #{clip_id}: still blocked after all remix attempts, skipping")
        logging.error(f"Clip #{clip_id}: ref blocked after all remix attempts — clip skipped")
        result.update({'status': 'skipped', 'error': 'ref_blocked_after_remix'})
        return result

    # Prominent person в промпте → специальный rewrite с заменой имени на внешность
    _proj_dir = output_dir.parent if output_dir else None
    # ── ФАЗА 2+: до 5 циклов реврайта, каждый MAX_ATTEMPTS попыток ──────
    _is_person = bool(phase1.get('prominent_people'))
    _current_prompt = prompt
    _last_rw_phase = phase1
    MAX_REWRITES = 5
    MAX_REWRITE_ATTEMPTS = MAX_ATTEMPTS  # 10 попыток на каждый реврайт (Gemini дешёвый)
    result['phase'] = 2

    for _rw_n in range(1, MAX_REWRITES + 1):
        # Hard Stop — не тратим квоту на rewrite если юзер остановил
        if _flowultra_shutdown_event.is_set():
            logging.info(f"Clip #{clip_id}: rewrite loop aborted by shutdown")
            result['status'] = 'error'
            result['error'] = 'hard stop'
            return result
        _lbl = 'PERSON REWRITE' if (_is_person and _rw_n == 1) else 'REWRITE'
        print(f"  {_RED}[{_lbl} #{_rw_n}/{MAX_REWRITES}]{_RESET} #{clip_id}: rewriting prompt...")
        logging.info(f"Clip #{clip_id}: rewrite #{_rw_n}/{MAX_REWRITES} (is_person={_is_person and _rw_n == 1})")

        try:
            if _is_person and _rw_n == 1:
                _new_prompt = client.rewrite_prompt_for_person(_current_prompt, project_dir=_proj_dir, clip_id=clip_id)
            else:
                _new_prompt = client.rewrite_prompt(_current_prompt, project_dir=_proj_dir, clip_id=clip_id)
        except Exception as _rw_err:
            logging.warning(f"Clip #{clip_id}: rewrite #{_rw_n} API error ({_rw_err}), using previous prompt")
            _new_prompt = _current_prompt

        if _new_prompt and _new_prompt != _current_prompt:
            result['rewritten'] = True
            _current_prompt = _new_prompt
            logging.info(f"Clip #{clip_id}: rewrite #{_rw_n} new prompt, starting phase2_rw{_rw_n}...")
        else:
            print(f"  {_YELLOW}[{_lbl} #{_rw_n}]{_RESET} #{clip_id}: rewrite returned same prompt")
            logging.warning(f"Clip #{clip_id}: rewrite #{_rw_n} returned same prompt")

        _ph = _attempt_phase(
            client, clip_id, _current_prompt, ref_uris, mode, whisk_refs,
            output_dir, effective_model, aspect_ratio or config.FASTGEN_ASPECT_RATIO,
            MAX_REWRITE_ATTEMPTS, f'phase2_rw{_rw_n}', stop_event=stop_event,
        )
        _last_rw_phase = _ph

        if _ph.get('license_dead'):
            result['error'] = _ph['last_error']
            result['license_dead'] = True
            return result

        if _ph['ok']:
            result.update({
                'status': 'ok',
                'file': _ph['file'],
                'operation_id': _ph.get('operation_id'),
                'duration_sec': _ph.get('elapsed', 0),
                'total_rewrite_phases': _rw_n,
            })
            suffix = f" (rewrite #{_rw_n})" if result['rewritten'] else f" (phase2 rw#{_rw_n})"
            logging.info(f"Clip #{clip_id}: OK phase2 (rewrite #{_rw_n}, {result['duration_sec']}s)")
            print(f"  {_GREEN}[OK]{_RESET} #{clip_id}: {result['duration_sec']}s{suffix}")
            return result
        # Не прерываем цикл на технических ошибках — пробуем все 10 реврайтов

    # Все реврайты исчерпаны
    result['total_rewrite_phases'] = MAX_REWRITES
    censored = phase1['censored'] or _last_rw_phase.get('censored', False)
    result['status'] = 'censored' if censored else 'error'
    result['error'] = _last_rw_phase.get('last_error') or phase1.get('last_error', '')

    if censored:
        logging.error(f"Clip #{clip_id}: CENSORED after {MAX_REWRITES} rewrites")
        print(f"  {_RED}[SKIP]{_RESET}     #{clip_id}: censored after {MAX_REWRITES} rewrites, giving up")
    else:
        logging.error(f"Clip #{clip_id}: FAILED after {MAX_REWRITES} rewrites ({MAX_REWRITES * MAX_REWRITE_ATTEMPTS} attempts total)")
        print(f"  {_YELLOW}[FAILED]{_RESET}    #{clip_id}: {MAX_REWRITES} rewrites x {MAX_REWRITE_ATTEMPTS} attempts exhausted")

    return result


# ======================================================================
# Основная функция генерации (этап 3)
# ======================================================================

def generate_all_images(
    project_dir: str,
    max_parallel: Optional[int] = None,
    clip_ids: Optional[List[int]] = None,
    mode: Optional[str] = None,
    model: Optional[str] = None,
    aspect_ratio: Optional[str] = None,
    api_key: Optional[str] = None,
    preflight: bool = True,
    dual_key: bool = False,
    silent: bool = False,
) -> Dict[str, Any]:
    """
    Основная функция этапа 3: генерация изображений для всех клипов.

    Args:
        project_dir: Путь к папке проекта
        max_parallel: Максимум параллельных генераций
        clip_ids: Список ID клипов (если None — все)
        mode: Режим референсов: 'flow', 'whisk', None=auto
        model: Модель FastGen
        aspect_ratio: Соотношение сторон
        api_key: API ключ (если не из .env)

    Returns:
        Лог генерации (dict)
    """
    project_path = Path(project_dir)
    max_parallel = max_parallel or config.FASTGEN_MAX_PARALLEL

    # Подавить DEBUG-спам от urllib3/requests в консоли
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    logging.getLogger('requests').setLevel(logging.WARNING)

    # Лог-файл для генерации (в папке проекта, skip if path too long)
    from datetime import datetime as _dt
    log_ts = _dt.now().strftime('%Y%m%d_%H%M%S')
    gen_log_path = project_path / f'gen_{log_ts}.log'
    file_handler = None
    try:
        file_handler = logging.FileHandler(str(gen_log_path), encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)  # файл пишет всё включая DEBUG
        file_handler.setFormatter(logging.Formatter('%(asctime)s | %(levelname)-8s | %(message)s'))
        logging.getLogger().addHandler(file_handler)
    except OSError:
        logging.warning(f"Cannot create log file (path too long?): {gen_log_path}")
    logging.info(f"=== FastGen generation started for {project_path.name} ===")

    print("\n" + "=" * 60)
    print("STAGE 3: IMAGE GENERATION (FastGen)")
    print("=" * 60)
    print(f"  Log: {gen_log_path}")

    # ------------------------------------------------------------------
    # 1. Чтение промптов
    # ------------------------------------------------------------------
    prompts_file = find_prompts_file(str(project_path))
    if not prompts_file:
        raise FileNotFoundError(
            f"Prompts file not found in {project_path} "
            f"(expected *_prompts_*.txt)"
        )

    all_prompts = extract_all_prompts(prompts_file)
    if not all_prompts:
        raise ValueError(f"No prompts found in {prompts_file}")

    print(f"\n  Prompts file: {Path(prompts_file).name}")
    print(f"  Total prompts: {len(all_prompts)}")

    # Фильтрация по ID
    if clip_ids:
        all_prompts = {k: v for k, v in all_prompts.items() if k in clip_ids}
        print(f"  Selected clips: {len(all_prompts)} ({', '.join(map(str, sorted(all_prompts.keys())))})")

    if not all_prompts:
        raise ValueError("No prompts to generate after filtering")

    # ------------------------------------------------------------------
    # 2. Инициализация клиентов (dual-key если FASTGEN_API_KEY_2 задан)
    # ------------------------------------------------------------------
    client = FastGenClient(api_key=api_key)
    mp1 = max_parallel

    # Отменяем зависшие задачи от прошлых прогонов (освобождаем слоты)
    print("\n  Cancelling leftover tasks from previous runs...")
    _ca = client.cancel_all_tasks()
    _found = _ca.get('total_found', 0)
    if _found:
        _cancelled = _ca.get('total_cancelled', 0)
        _refunded = _ca.get('total_refunded', 0)
        print(f"  Cancelled: {_cancelled}/{_found} tasks, refunded: {_refunded}")
        if _cancelled:
            time.sleep(3)  # даём серверу освободить слоты
    else:
        print("  No leftover tasks.")

    # Проверка квоты Key1
    try:
        usage = client.get_usage()
    except Exception:
        usage = {}
    if usage:
        remaining = parse_usage_remaining(usage)
        threads = parse_usage_threads(usage)
        remaining_str = remaining if remaining is not None else '?'
        print(f"\n  [Key1] API quota: {remaining_str} gen/h remaining | threads: {threads}")
        if threads:
            mp1 = min(max_parallel, threads)

    clients_cfg: list = [{'client': client, 'mp': mp1,
                          'ref_uris': [], 'whisk_refs': {}, 'label': 'Key1'}]

    if dual_key and config.FASTGEN_API_KEY_2:
        client2 = FastGenClient(api_key=config.FASTGEN_API_KEY_2)
        _ca2 = client2.cancel_all_tasks()
        _f2 = _ca2.get('total_found', 0)
        if _f2:
            print(f"  [Key2] Cancelled {_ca2.get('total_cancelled',0)}/{_f2} leftover tasks")
        mp2 = config.FASTGEN_MAX_PARALLEL_2
        try:
            usage2 = client2.get_usage()
            if usage2:
                t2 = parse_usage_threads(usage2)
                r2 = parse_usage_remaining(usage2)
                print(f"  [Key2] API quota: {r2 if r2 is not None else '?'} gen/h remaining | threads: {t2}")
                if t2:
                    mp2 = t2   # доверяем API напрямую, не капаем конфигом
        except Exception:
            pass
        clients_cfg.append({'client': client2, 'mp': mp2,
                             'ref_uris': [], 'whisk_refs': {}, 'label': 'Key2'})

    max_parallel = sum(cfg['mp'] for cfg in clients_cfg)
    if len(clients_cfg) > 1:
        print(f"  Dual-key: {' + '.join(str(c['mp']) for c in clients_cfg)} = {max_parallel} workers")

    # ------------------------------------------------------------------
    # 3. Пропуск уже сгенерированных (ДО загрузки рефов)
    # ------------------------------------------------------------------
    output_dir = project_path / 'generated'
    output_dir.mkdir(exist_ok=True)

    skipped = []
    for cid in list(all_prompts.keys()):
        found = False
        for ext in ('.png', '.jpeg', '.jpg', '.webp'):
            p = output_dir / f"{cid:03d}{ext}"
            if p.exists() and p.stat().st_size > 0:
                found = True
                break
        if found:
            skipped.append(cid)
            del all_prompts[cid]
    if skipped:
        print(f"\n  Skipped (already exist): {len(skipped)}, remaining: {len(all_prompts)}")

    if not all_prompts:
        print("  All images already exist. Nothing to generate.")
        return {'generated': len(skipped), 'failed': 0, 'results': []}

    # ------------------------------------------------------------------
    # 4. Сканирование и загрузка референсов
    # ------------------------------------------------------------------
    refs = scan_references(str(project_path))
    total_refs = sum(len(v) for v in refs.values())

    ref_uris = []        # для Flow (Key1) — backward compat для preflight
    whisk_refs = {}      # для Whisk (Key1) — backward compat
    ref_paths_flow: List[Path] = []  # параллельный список путей для ремикса
    effective_mode = 'flow'  # по умолчанию

    if total_refs > 0:
        print_reference_summary(refs)

        # Определение режима
        if mode:
            effective_mode = mode
        else:
            detected = detect_reference_mode(refs)
            if detected == 'ask':
                effective_mode = ask_reference_mode()
            elif detected:
                effective_mode = detected
                print(f"  Auto-detected: {effective_mode.upper()}")

        print(f"  Reference mode: {effective_mode.upper()}")

        def _upload_refs_to_cfg(cfg: dict, label: str):
            """Загрузить рефы в Storage конкретного клиента."""
            _cl = cfg['client']
            print(f"\n  [{label}] Uploading {total_refs} reference(s)...")
            if effective_mode == 'flow':
                all_ref_files = refs['root'] + refs['subject'] + refs['scene'] + refs['style']
                _uris: List[str] = []
                _paths: List[Path] = []
                for rf in tqdm(all_ref_files[:10], desc=f"  [{label}] Upload refs", unit="file"):
                    try:
                        uri = _cl.upload_reference(str(rf))
                        _uris.append(uri)
                        _paths.append(rf)
                    except Exception as e:
                        logging.warning(f"[{label}] Failed to upload {rf.name}: {e}")
                cfg['ref_uris'] = _uris
                cfg['ref_paths_flow'] = _paths
                print(f"  [{label}] Uploaded: {len(_uris)} reference(s)")
                return _uris, _paths
            elif effective_mode == 'whisk':
                _wr: Dict[str, List[str]] = {'subject': [], 'scene': [], 'style': []}
                for category in ('subject', 'scene', 'style'):
                    for rf in refs[category]:
                        try:
                            uri = _cl.upload_reference(str(rf))
                            _wr[category].append(uri)
                        except Exception as e:
                            logging.warning(f"[{label}] Failed to upload {rf.name}: {e}")
                cfg['whisk_refs'] = _wr
                tw = sum(len(v) for v in _wr.values())
                print(f"  [{label}] Uploaded: {tw} ref(s) (sub={len(_wr['subject'])} sce={len(_wr['scene'])} sty={len(_wr['style'])})")
                return _wr, []
            return [], []

        # Key1 всегда
        ref_uris, ref_paths_flow = _upload_refs_to_cfg(clients_cfg[0], 'Key1')
        clients_cfg[0]['ref_paths_flow'] = ref_paths_flow

        # Key2 whisk: заливаем сразу (preflight для whisk не запускается)
        # Key2 flow: заливаем ПОСЛЕ preflight (чтобы получить remixed файлы если нужно)
        if effective_mode == 'whisk':
            for cfg in clients_cfg[1:]:
                _upload_refs_to_cfg(cfg, cfg['label'])

    else:
        print("\n  No references found (ref/ folder missing or empty)")
        print("  Generating without reference images")

    refs_uploaded_at = time.time()

    # ------------------------------------------------------------------
    # 4b. Предполётная проверка рефов (Preflight)
    # ------------------------------------------------------------------
    if (preflight and effective_mode == 'flow' and ref_uris
            and config.FASTGEN_PREFLIGHT_REFS and config.KIE_AI_REMIX):
        _preflight_model = model or config.FASTGEN_MODEL
        print(f"\n  [PREFLIGHT] Testing reference images before generation (Key1, model={_preflight_model})...")
        logging.info(f"PREFLIGHT: testing ref images via Key1, model={_preflight_model}")

        # Main preflight: до 2 retries на SKIPPED (transient timeouts / network).
        # Это защита от cold-start сервера: первый вызов может уйти в timeout 180s,
        # второй — в уже прогретый backend за несколько секунд.
        # Только если ВСЕ попытки SKIPPED → pessimistic BLOCKED → isolate.
        # Hard Stop: InterruptedError пробрасывается наверх — retry цикл прерывается.
        _pf_result = client._preflight_test_refs(ref_uris, model=_preflight_model, ref_paths=ref_paths_flow)
        _pf_retries = 0
        _PF_MAX_RETRIES = 2
        while getattr(client, '_last_preflight_skipped', False) and _pf_retries < _PF_MAX_RETRIES:
            _pf_retries += 1
            # Check shutdown before sleep+retry
            if _flowultra_shutdown_event.is_set():
                raise InterruptedError("Main preflight aborted by shutdown signal")
            print(f"  {_YELLOW}[PREFLIGHT]{_RESET} SKIPPED — retry {_pf_retries}/{_PF_MAX_RETRIES} in 15s (cold-start wait)...")
            logging.warning(f"PREFLIGHT: SKIPPED, retry {_pf_retries}/{_PF_MAX_RETRIES}")
            # Interruptible sleep: 15 × 1s, check shutdown each
            for _ in range(15):
                if _flowultra_shutdown_event.is_set():
                    raise InterruptedError("Main preflight aborted by shutdown signal (in retry wait)")
                time.sleep(1)
            _pf_result = client._preflight_test_refs(ref_uris, model=_preflight_model, ref_paths=ref_paths_flow)
        if getattr(client, '_last_preflight_skipped', False):
            print(f"  {_YELLOW}[PREFLIGHT]{_RESET} Still SKIPPED after {_PF_MAX_RETRIES} retries → isolating via binary search")
            logging.warning(f"PREFLIGHT: {_PF_MAX_RETRIES}x SKIPPED — treating as BLOCKED, running isolate")
            _pf_result = False  # падаем в isolate

        if False:  # placeholder to keep elif structure
            pass
        elif not _pf_result:
            print(f"  {_RED}[PREFLIGHT]{_RESET} REF BLOCKED — isolating bad refs...")
            logging.warning("PREFLIGHT: REF BLOCKED — isolating bad refs via binary search")
            bad_idxs = client._isolate_blocked_refs(ref_uris, model=_preflight_model, paths=ref_paths_flow)
            bad_names = [ref_paths_flow[i].name for i in bad_idxs if i < len(ref_paths_flow)]
            print(f"  {_RED}[PREFLIGHT]{_RESET} Bad refs: {bad_names}")
            logging.warning(f"PREFLIGHT: bad refs identified: {bad_names}")
            for idx in bad_idxs:
                if idx >= len(ref_paths_flow):
                    continue
                orig = ref_paths_flow[idx]
                try:
                    remix_ref(str(orig), str(orig))
                    new_uri = client.upload_reference(str(orig))
                    ref_uris[idx] = new_uri
                    logging.info(f"PREFLIGHT: remixed {orig.name} in-place, re-uploaded")
                except Exception as e:
                    logging.error(f"PREFLIGHT: failed to remix {orig.name}: {e}")
                    print(f"  {_RED}[PREFLIGHT]{_RESET} Remix failed for {orig.name}: {e}")
            # Повторный preflight после remix — одна попытка.
            # Если SKIPPED → оптимистично считаем OK (inline handler catch'нет ref-block при генерации)
            _pf_result2 = client._preflight_test_refs(ref_uris, model=_preflight_model, ref_paths=ref_paths_flow)
            _pf2_skipped = getattr(client, '_last_preflight_skipped', False)
            if _pf2_skipped:
                logging.warning("PREFLIGHT post-remix: SKIPPED — assuming OK, inline handler catches blocks")
                print(f"  {_YELLOW}[PREFLIGHT]{_RESET} Post-remix check SKIPPED — proceeding with remixed refs")
                clients_cfg[0]['ref_uris'] = ref_uris
                clients_cfg[0]['ref_paths_flow'] = ref_paths_flow
            elif not _pf_result2:
                print(f"  {_RED}[PREFLIGHT]{_RESET} STILL BLOCKED after remix — dropping refs")
                logging.warning("PREFLIGHT: still blocked after remix — refs dropped")
                ref_uris = []
                clients_cfg[0]['ref_uris'] = []
            else:
                print(f"  {_GREEN}[PREFLIGHT]{_RESET} OK after remix — continuing with remixed refs")
                logging.info("PREFLIGHT: OK after remix")
                clients_cfg[0]['ref_uris'] = ref_uris
                clients_cfg[0]['ref_paths_flow'] = ref_paths_flow
        else:
            if getattr(client, '_last_preflight_skipped', False):
                # Exception уже залогирован внутри _preflight_test_refs.
                # Не печатаем "OK" — рефы не протестированы фактически.
                pass
            else:
                print(f"  {_GREEN}[PREFLIGHT]{_RESET} OK — refs accepted")
                logging.info("PREFLIGHT: refs OK")

        # Sync финальных рефов (оригинальные или remixed) во все остальные ключи
        if len(clients_cfg) > 1 and ref_paths_flow:
            for _k2cfg in clients_cfg[1:]:
                _lbl = _k2cfg['label']
                print(f"  Uploading final refs to {_lbl}...")
                _k2uris: List[str] = []
                for rf in tqdm(ref_paths_flow, desc=f"  [{_lbl}] Upload refs", unit="file"):
                    try:
                        uri = _k2cfg['client'].upload_reference(str(rf))
                        _k2uris.append(uri)
                    except Exception as e:
                        logging.warning(f"[{_lbl}] failed to upload {rf.name}: {e}")
                _k2cfg['ref_uris'] = _k2uris
                _k2cfg['ref_paths_flow'] = ref_paths_flow
                print(f"  [{_lbl}] Uploaded: {len(_k2uris)} reference(s)")

    # Если preflight не запускался для flow — синкаем оригинальные рефы в Key2 сейчас
    _preflight_ran = (preflight and effective_mode == 'flow' and ref_uris
                      and config.FASTGEN_PREFLIGHT_REFS and config.KIE_AI_REMIX)
    if not _preflight_ran and effective_mode == 'flow' and ref_paths_flow and len(clients_cfg) > 1:
        for _k2cfg in clients_cfg[1:]:
            _lbl = _k2cfg['label']
            print(f"  Uploading refs to {_lbl}...")
            _k2uris = []
            for rf in tqdm(ref_paths_flow, desc=f"  [{_lbl}] Upload refs", unit="file"):
                try:
                    _k2uris.append(_k2cfg['client'].upload_reference(str(rf)))
                except Exception as e:
                    logging.warning(f"[{_lbl}] failed to upload {rf.name}: {e}")
            _k2cfg['ref_uris'] = _k2uris
            print(f"  [{_lbl}] Uploaded: {len(_k2uris)} reference(s)")

    # ------------------------------------------------------------------
    # 5. Генерация изображений
    # ------------------------------------------------------------------
    used_model = model or config.FASTGEN_MODEL
    used_aspect = aspect_ratio or config.FASTGEN_ASPECT_RATIO

    print(f"\n  Model: {used_model}")
    print(f"  Aspect ratio: {used_aspect}")
    if len(clients_cfg) > 1:
        print(f"  Parallel workers: {max_parallel} ({' + '.join(str(c['mp']) for c in clients_cfg)} keys)")
    else:
        print(f"  Parallel workers: {max_parallel}")
    print("=" * 60)

    # Накопленные OK-результаты по всем циклам (не перегенерируются)
    accumulated_ok: Dict[int, Dict] = {}   # clip_id -> result
    pending_prompts = dict(all_prompts)    # clip_id -> prompt_text (убывает при OK)

    # Worker ID tracking для dual-key worker-assignment
    def _get_fg_worker_id() -> int:
        tid = threading.get_ident()
        with _fg_worker_lock:
            if tid not in _fg_worker_map:
                _fg_worker_map[tid] = _fg_worker_counter['next']
                _fg_worker_counter['next'] += 1
            return _fg_worker_map[tid]

    cycle_num = 0
    quota_exhausted = False  # флаг: в этом цикле была ошибка QuotaExhaustedError
    using_backup = bool(api_key and api_key == config.FASTGEN_API_KEY_BACKUP)
    start_total = time.time()
    cycle_results: List[Dict] = []  # результаты последнего цикла
    ctrlc_count = 0  # счётчик Ctrl+C (нужно 3 нажатия для выхода)

    # ── Auto-fallback state (non-interactive / silent mode only) ──
    _original_fg_model = used_model
    _fallback_fg_model = 'GEM_PIX_2' if _original_fg_model.upper() == 'GEMINI' else 'GEMINI'
    _fallback_model_done = False  # True once the alt-model cycle has been triggered

    REF_REFRESH_INTERVAL = 50 * 60  # 50 минут в секундах (TTL Storage = 1 час)

    # Ремикс заблокированных рефов (вызывается любым воркером при REF BLOCKED)
    # Обновляет ref_uris во ВСЕХ clients_cfg, чтобы последующие клипы тоже получили новые рефы
    _ref_remix_lock = threading.Lock()
    _ref_remixed = [False]  # выполнить только один раз (первый воркер, остальные ждут)

    def _on_ref_blocked():
        # Вызывается когда реальный промпт + рефы = REF BLOCKED.
        # Тестируем с промптом содержащим имя — это триггерит "prominent people"
        # даже без реального промпта клипа.
        with _ref_remix_lock:
            if _ref_remixed[0]:
                return   # уже сделано другим воркером
            key1_cfg  = clients_cfg[0]
            k1_client = key1_cfg['client']
            k1_uris   = key1_cfg.get('ref_uris') or []
            k1_paths  = key1_cfg.get('ref_paths_flow') or []
            if not k1_uris or not k1_paths:
                _ref_remixed[0] = True
                return
            # Используем auto-prompt из stem'ов имён файлов (CHEKAN_ref, FIMA_ref, ...)
            # — воспроизводит реальную форму промптов генерации, celebrity триггер срабатывает точно.
            print(f"\n  {_YELLOW}[REF REMIX]{_RESET} Isolating blocked ref via binary search (auto-prompt from ref filenames)...")
            logging.warning("REF BLOCKED: isolating with auto-prompt from ref file stems")
            bad_idxs = k1_client._isolate_blocked_refs(k1_uris, prompt=None, paths=k1_paths)
            if not bad_idxs:
                # Изоляция не нашла плохой реф — ремиксим все
                print(f"  {_YELLOW}[REF REMIX]{_RESET} Could not isolate — remixing all {len(k1_paths)} refs...")
                bad_idxs = list(range(len(k1_paths)))
            else:
                bad_names = [k1_paths[i].name for i in bad_idxs if i < len(k1_paths)]
                print(f"  {_YELLOW}[REF REMIX]{_RESET} Bad refs: {bad_names} — remixing...")
                logging.warning(f"REF BLOCKED: bad refs={bad_names}")
            new_paths = list(k1_paths)
            _remix_failed_indices: list = []  # индексы рефов которые не удалось ремикснуть
            for idx in bad_idxs:
                if _flowultra_shutdown_event.is_set():
                    logging.warning("_on_ref_blocked: shutdown during remix loop — aborting")
                    print(f"  {_YELLOW}[REF REMIX]{_RESET} aborted by shutdown signal")
                    return  # НЕ ставим _ref_remixed[0]=True — следующие вызовы увидят что ничего не сделано
                if idx >= len(k1_paths):
                    continue
                orig = k1_paths[idx]
                try:
                    remix_ref(str(orig), str(orig))
                    logging.info(f"Remixed: {orig.name} in-place")
                except Exception as e:
                    _remix_failed_indices.append(idx)
                    print(f"  {_RED}[REF REMIX FAILED]{_RESET} {orig.name}: {str(e)[:200]}")
                    logging.error(f"Remix failed for {orig.name}: {e}")

            # ФИКС А: если не удалось отремиксить ВСЕ плохие — дропаем их совсем
            # (иначе следующие клипы снова упрутся в тот же celebrity-реф).
            if _remix_failed_indices:
                _dropped_names = [k1_paths[i].name for i in _remix_failed_indices if i < len(k1_paths)]
                print(f"  {_RED}[REF REMIX]{_RESET} {len(_remix_failed_indices)} ref(s) could not be remixed — DROPPING: {_dropped_names}")
                logging.error(f"REF REMIX: dropping {len(_remix_failed_indices)} unremixable refs: {_dropped_names}")
                # Фильтруем bad_idxs и new_paths — удаляем failed напрямую
                _drop_set = set(_remix_failed_indices)
                new_paths = [p for i, p in enumerate(k1_paths) if i not in _drop_set]
                if not new_paths:
                    print(f"  {_RED}[REF REMIX]{_RESET} ВСЕ рефы непригодны — пайплайн продолжит БЕЗ рефов")
                    logging.error("REF REMIX: all refs dropped — generation will proceed without refs")
            # Re-upload в Storage каждого ключа
            for cfg in clients_cfg:
                if _flowultra_shutdown_event.is_set():
                    logging.warning("_on_ref_blocked: shutdown during re-upload — aborting")
                    return
                lbl = cfg['label']
                new_uris: List[str] = []
                for rf in tqdm(new_paths, desc=f"  [{lbl}] Re-upload remixed", unit="file"):
                    if _flowultra_shutdown_event.is_set():
                        break
                    try:
                        new_uris.append(cfg['client'].upload_reference(str(rf)))
                    except Exception as e:
                        logging.warning(f"[{lbl}] remix re-upload failed {Path(rf).name}: {e}")
                cfg['ref_uris']       = new_uris
                cfg['ref_paths_flow'] = new_paths
                print(f"  [{lbl}] Remixed refs uploaded: {len(new_uris)}")
            _ref_remixed[0] = True

    def _do_ref_refresh():
        """Перезагрузить рефы в FastGen Storage для всех ключей (вызывается при TTL)."""
        elapsed_min = int((time.time() - refs_uploaded_at) / 60)
        print(f"\n  {_YELLOW}[REFS REFRESH]{_RESET} {elapsed_min}m since last upload (TTL=60m) — re-uploading...")
        logging.info(f"Re-uploading {total_refs} refs (elapsed={elapsed_min}m)")
        for _cfg in clients_cfg:
            _lbl = _cfg['label']
            if effective_mode == 'flow':
                _paths = _cfg.get('ref_paths_flow') or (refs['root'] + refs['subject'] + refs['scene'] + refs['style'])
                _new_uris: List[str] = []
                for rf in tqdm(_paths[:10], desc=f"  [{_lbl}] Re-upload", unit="file"):
                    try:
                        _new_uris.append(_cfg['client'].upload_reference(str(rf)))
                    except Exception as e:
                        logging.warning(f"[{_lbl}] Re-upload failed {Path(rf).name}: {e}")
                _cfg['ref_uris'] = _new_uris
                print(f"  [{_lbl}] Re-uploaded: {len(_new_uris)} reference(s)")
            elif effective_mode == 'whisk':
                _wr: Dict[str, List[str]] = {'subject': [], 'scene': [], 'style': []}
                for category in ('subject', 'scene', 'style'):
                    for rf in refs[category]:
                        try:
                            _wr[category].append(_cfg['client'].upload_reference(str(rf)))
                        except Exception as e:
                            logging.warning(f"[{_lbl}] Re-upload failed {rf.name}: {e}")
                _cfg['whisk_refs'] = _wr
                print(f"  [{_lbl}] Re-uploaded: {sum(len(v) for v in _wr.values())} reference(s)")
        # Обновляем backward-compat vars для Key1
        ref_uris.clear()
        ref_uris.extend(clients_cfg[0].get('ref_uris', []))
        return time.time()

    while True:
        cycle_num += 1
        cycle_ids = sorted(pending_prompts.keys())
        print(f"\n  [Cycle {cycle_num}] Generating {len(cycle_ids)} images...")

        # Перезагрузка рефов если прошло ≥50 минут с последней загрузки (до старта цикла)
        if total_refs > 0 and (time.time() - refs_uploaded_at) >= REF_REFRESH_INTERVAL:
            refs_uploaded_at = _do_ref_refresh()

        cycle_results = []
        quota_exhausted = False  # сбрасываем в начале каждого цикла
        interrupted = False  # флаг KeyboardInterrupt
        ref_refresh_needed = False  # флаг досрочного рефреша внутри цикла
        stop_event = threading.Event()  # сигнал воркерам: прекратить попытки между итерациями

        # Сброс worker tracking для нового цикла
        with _fg_worker_lock:
            _fg_worker_map.clear()
            _fg_worker_counter['next'] = 0
        with _fg_started_workers_lock:
            _fg_started_workers.clear()

        try:
            with ThreadPoolExecutor(max_workers=max_parallel) as executor:
                futures = {}
                for i, cid in enumerate(cycle_ids):
                    if len(clients_cfg) > 1:
                        # Dual-key: worker-assignment внутри generate_single_clip
                        future = executor.submit(
                            generate_single_clip,
                            client=None,
                            clip_id=cid,
                            prompt=pending_prompts[cid],
                            ref_uris=None,
                            mode=effective_mode,
                            whisk_refs=None,
                            output_dir=output_dir,
                            model=used_model,
                            aspect_ratio=used_aspect,
                            stop_event=stop_event,
                            worker_id_fn=_get_fg_worker_id,
                            clients_cfg_list=clients_cfg,
                            on_ref_blocked=_on_ref_blocked if effective_mode == 'flow' else None,
                        )
                    else:
                        # Single-key: классический режим
                        future = executor.submit(
                            generate_single_clip,
                            client=client,
                            clip_id=cid,
                            prompt=pending_prompts[cid],
                            ref_uris=clients_cfg[0].get('ref_uris') if effective_mode == 'flow' else None,
                            mode=effective_mode,
                            whisk_refs=clients_cfg[0].get('whisk_refs') if effective_mode == 'whisk' else None,
                            output_dir=output_dir,
                            model=used_model,
                            aspect_ratio=used_aspect,
                            stop_event=stop_event,
                            stagger_delay=i * 2.0 if i < max_parallel else 0.0,
                            on_ref_blocked=_on_ref_blocked if effective_mode == 'flow' else None,
                            cfg_ref=clients_cfg[0] if effective_mode == 'flow' else None,
                        )
                    futures[future] = cid

                _cycle_ok_durs = []
                _cycle_total = len(futures)
                _cycle_done = 0
                _wall_start = time.time()
                if IS_PIPE:
                    print(f"  Cycle {cycle_num}: 0/{_cycle_total} clips", flush=True)
                _tqdm_ctx = tqdm(total=_cycle_total, desc=f"  Cycle {cycle_num}", unit="clip", smoothing=0) if not IS_PIPE else None
                for future in as_completed(futures):
                    cid = futures[future]
                    try:
                        clip_result = future.result()
                        cycle_results.append(clip_result)
                        status_icon = {'ok': '+', 'censored': 'C', 'error': 'X'}.get(
                            clip_result['status'], '?')
                        dur = clip_result.get('duration_sec', 0)
                        if clip_result['status'] == 'ok' and dur > 0:
                            _cycle_ok_durs.append(dur)
                        if _tqdm_ctx:
                            avg_s = f" avg={sum(_cycle_ok_durs)/len(_cycle_ok_durs):.0f}s" if _cycle_ok_durs else ""
                            _tqdm_ctx.set_postfix_str(f"#{cid}: {status_icon}{avg_s}")
                        if clip_result['status'] == 'ok' and _cycle_ok_durs:
                            _avg = sum(_cycle_ok_durs) / len(_cycle_ok_durs)
                            _wall = time.time() - _wall_start
                            _wall_cpm = _cycle_done / (_wall / 60) if _wall > 0 else 0
                            _wall_spc = 60.0 / _wall_cpm if _wall_cpm > 0 else 0
                            print(f"  {_CYAN}[SPEED]{_RESET} worker avg={_avg:.0f}s/clip  |  pool {_wall_spc:.1f}s/clip ({_wall_cpm:.1f} clip/min)")
                        # ── Auto-switch to backup key on license_dead ──
                        if (clip_result.get('license_dead') and not using_backup
                                and config.FASTGEN_API_KEY_BACKUP
                                and config.FASTGEN_API_KEY_BACKUP != config.FASTGEN_API_KEY):
                            print(f"\n  {_RED}[AUTH FATAL]{_RESET} Key dead — auto-switching to BACKUP key")
                            logging.error(f"[AUTH FATAL] Main key dead, switching to backup")
                            client = FastGenClient(api_key=config.FASTGEN_API_KEY_BACKUP)
                            using_backup = True
                            # Re-upload refs with new key
                            if total_refs > 0:
                                print(f"  Re-uploading {total_refs} reference(s) with backup key...")
                                if effective_mode == 'flow':
                                    ref_uris.clear()
                                    all_ref_files = refs['root'] + refs['subject'] + refs['scene'] + refs['style']
                                    for ref_file in all_ref_files[:10]:
                                        try:
                                            uri = client.upload_reference(str(ref_file))
                                            ref_uris.append(uri)
                                        except Exception as _re:
                                            logging.warning(f"Re-upload failed {ref_file.name}: {_re}")
                            # Update clients_cfg if dual-key mode
                            if clients_cfg:
                                for _cfg in clients_cfg:
                                    _cfg['client'] = client
                                    _cfg['ref_uris'] = list(ref_uris)
                    except QuotaExhaustedError:
                        cycle_results.append({
                            'id': cid, 'status': 'error', 'error': 'quota_exhausted',
                            'file': None, 'operation_id': None, 'duration_sec': 0,
                        })
                        quota_exhausted = True
                        if _tqdm_ctx:
                            _tqdm_ctx.set_postfix_str(f"#{cid}: QUOTA!")
                    except Exception as e:
                        cycle_results.append({
                            'id': cid, 'status': 'error', 'error': str(e),
                            'file': None, 'operation_id': None, 'duration_sec': 0,
                        })
                        if _tqdm_ctx:
                            _tqdm_ctx.set_postfix_str(f"#{cid}: X")
                    _cycle_done += 1
                    if _tqdm_ctx:
                        _tqdm_ctx.update(1)
                    if IS_PIPE:
                        print(f"PROGRESS:{_cycle_done}/{_cycle_total}", flush=True)

                    # Проверяем TTL рефов после каждого завершённого клипа
                    if total_refs > 0 and not ref_refresh_needed and (time.time() - refs_uploaded_at) >= REF_REFRESH_INTERVAL:
                        ref_refresh_needed = True
                        stop_event.set()
                        msg = f"\n  {_YELLOW}[REFS TTL]{_RESET} 50m elapsed — stopping retries and refreshing refs..."
                        if _tqdm_ctx:
                            _tqdm_ctx.write(msg)
                        else:
                            print(msg, flush=True)
                        logging.info("Ref TTL reached — stop_event set, waiting for current operations to finish")
                if _tqdm_ctx:
                    _tqdm_ctx.close()

        except KeyboardInterrupt:
            ctrlc_count += 1
            stop_event.set()  # останавливаем воркеры между попытками при любом Ctrl+C
            if ctrlc_count < 3:
                print(f"\n\n  {_YELLOW}[Ctrl+C #{ctrlc_count}]{_RESET} Press Ctrl+C {3 - ctrlc_count} more time(s) to stop. Continuing...")
                logging.info(f"KeyboardInterrupt #{ctrlc_count} ignored — stop_event set, waiting for workers...")
            else:
                interrupted = True
                print(f"\n\n  {_YELLOW}[INTERRUPTED]{_RESET} Ctrl+C x3 — saving results and finishing gracefully...")
                logging.warning("KeyboardInterrupt x3 caught — finishing with partial results")

        # Разбираем результаты цикла: перемещаем OK в накопитель
        for r in cycle_results:
            if r['status'] == 'ok':
                accumulated_ok[r['id']] = r
                pending_prompts.pop(r['id'], None)

        cycle_ok_new = sum(1 for r in cycle_results if r['status'] == 'ok')
        failed_ids = sorted(pending_prompts.keys())

        print(f"\n  [Cycle {cycle_num}] OK this cycle: {cycle_ok_new},  still missing: {len(failed_ids)}")

        # Прерывание по Ctrl+C x3 — выходим с тем что есть
        if interrupted:
            print(f"  Stopped by user. {len(accumulated_ok)} clips saved to generated/")
            break

        # Если TTL истёк во время цикла — обновляем рефы и сразу повторяем без вопросов
        if ref_refresh_needed and failed_ids:
            refs_uploaded_at = _do_ref_refresh()
            print(f"  Refs refreshed — restarting for {len(failed_ids)} remaining clips...")
            continue

        # Все сгенерированы — выходим
        if not failed_ids:
            break

        # ------------------------------------------------------------------
        # Интерактивный финал: есть проваленные клипы
        # ------------------------------------------------------------------
        print("\n" + "=" * 60)
        print(f"  {_RED}MISSING CLIPS ({len(failed_ids)} total):{_RESET}")
        print("=" * 60)

        # Вывод промптов отсутствующих клипов
        for cid in failed_ids:
            last_r = next((r for r in reversed(cycle_results) if r['id'] == cid), None)
            status_label = 'CENSORED' if (last_r and last_r.get('status') == 'censored') else 'FAILED'
            print(f"\n  {'─' * 56}")
            print(f"  {_RED}Clip #{cid} [{status_label}]{_RESET}")
            print(f"  Prompt:")
            prompt_text = pending_prompts[cid]
            # Перенос строк по 72 символа для читаемости
            words = prompt_text.split()
            line = "    "
            for word in words:
                if len(line) + len(word) + 1 > 76:
                    print(line)
                    line = "    " + word
                else:
                    line = (line + " " + word) if line != "    " else "    " + word
            if line.strip():
                print(line)

        print(f"\n  {'─' * 56}")
        print(f"\n  {_YELLOW}What would you like to do?{_RESET}")
        print(f"    [1] Repeat full cycle for missing clips ({len(failed_ids)} clips)")
        print(f"    [2] Finish — use prompts above for manual generation in Veo3")

        # Переключение ключа — всегда доступно если есть оба ключа
        backup_key = config.FASTGEN_API_KEY_BACKUP
        main_key = config.FASTGEN_API_KEY
        has_both_keys = bool(backup_key) and bool(main_key)
        if has_both_keys:
            if using_backup:
                print(f"    [3] Switch to MAIN API key and repeat ({len(failed_ids)} clips)")
            else:
                print(f"    [3] Switch to BACKUP API key and repeat ({len(failed_ids)} clips)")

        print(f"    [4] Edit prompt manually and retry")

        if quota_exhausted and not has_both_keys:
            print(f"  {_YELLOW}  [!] Hourly quota exhausted. No second API key in .env.{_RESET}")
        print()

        valid_choices = {'1', '2', '4'} | ({'3'} if has_both_keys else set())
        if silent or not sys.stdin.isatty():
            # ── Cycles 1-2: standard FastGen retry (same model) ──
            if cycle_num <= 2:
                choice = '1'
                print(f"  [AUTO] Non-interactive: retry same model (cycle {cycle_num})")

            # ── Cycle 3: switch to fallback FastGen model ──
            elif not _fallback_model_done:
                _fallback_model_done = True
                print(f"\n  {_YELLOW}[AUTO FALLBACK]{_RESET} FastGen: switching model {_original_fg_model} → {_fallback_fg_model} (service may be down)")
                logging.warning(f"AUTO FALLBACK: FastGen model switch {_original_fg_model} → {_fallback_fg_model}")
                used_model = _fallback_fg_model
                choice = '1'

            # ── After model-switch cycle: VeoNonStop Banana Pro fallback (2 cycles), then stop ──
            else:
                if config.VEONONSTOP_API_KEY:
                    for _veo_c in range(1, 3):
                        _veo_pending = list(pending_prompts.keys())
                        if not _veo_pending:
                            break
                        print(f"\n  {_YELLOW}[AUTO FALLBACK]{_RESET} VeoNonStop Banana Pro cycle {_veo_c}/2 for {len(_veo_pending)} clips...")
                        logging.warning(f"AUTO FALLBACK: VeoNonStop Banana cycle {_veo_c}/2, clips: {_veo_pending}")
                        try:
                            from imggen import generate_all_images as _veo_imggen
                            _veo_imggen(
                                project_dir=project_dir,
                                mode='banana',
                                clip_ids=_veo_pending,
                                silent=True,
                                max_cycles=1,
                            )
                        except Exception as _veo_e:
                            print(f"  {_RED}[AUTO FALLBACK]{_RESET} VeoNonStop cycle {_veo_c} error: {_veo_e}")
                            logging.error(f"AUTO FALLBACK VeoNonStop cycle {_veo_c}: {_veo_e}")
                        # Sync any newly generated images into accumulated_ok / pending_prompts
                        for _cid in list(pending_prompts.keys()):
                            for _ext in ('.png', '.jpg', '.jpeg', '.webp'):
                                _fp = output_dir / f"{_cid:03d}{_ext}"
                                if _fp.exists() and _fp.stat().st_size > 0:
                                    accumulated_ok[_cid] = {'id': _cid, 'status': 'ok',
                                                            'file': str(_fp), 'duration_sec': 0}
                                    pending_prompts.pop(_cid, None)
                                    break
                else:
                    print(f"  {_YELLOW}[AUTO FALLBACK]{_RESET} VEONONSTOP_API_KEY not set — skipping VeoNonStop fallback")
                    logging.warning("AUTO FALLBACK: VEONONSTOP_API_KEY not set — skipping VeoNonStop fallback")

                if pending_prompts:
                    print(f"\n  {_RED}[AUTO FALLBACK]{_RESET} All cycles exhausted — {len(pending_prompts)} clips still missing.")
                    print(f"  {_RED}[AUTO FALLBACK]{_RESET} Infrastructure failure — manual intervention required.")
                    logging.error(f"AUTO FALLBACK: all cycles exhausted, {len(pending_prompts)} clips failed permanently")
                else:
                    print(f"\n  {_GREEN}[AUTO FALLBACK]{_RESET} All clips recovered via VeoNonStop Banana fallback!")
                break
        else:
            while True:
                prompt_str = "  Enter choice [1-4]: " if has_both_keys else "  Enter choice [1/2/4]: "
                try:
                    choice = input(prompt_str).strip()
                except (EOFError, KeyboardInterrupt):
                    choice = '2'
                    print("2")
                if choice in valid_choices:
                    break
                print(f"  Invalid choice, enter {'/'.join(sorted(valid_choices))}")

        if choice == '1':
            print(f"\n  Repeating for clips: {', '.join(f'#{i}' for i in failed_ids)}")
        elif choice == '2':
            print(f"\n  Finishing. Prompts above — copy to Veo3 for manual generation.")
            break
        elif choice == '3':
            # Переключение на другой ключ
            if using_backup:
                print(f"\n  {_YELLOW}Switching to MAIN API key...{_RESET}")
                client = FastGenClient(api_key=main_key)
                using_backup = False
            else:
                print(f"\n  {_YELLOW}Switching to BACKUP API key...{_RESET}")
                client = FastGenClient(api_key=backup_key)
                using_backup = True
            # Перезаливаем референсы с новым клиентом (storage привязан к ключу)
            if total_refs > 0:
                key_label = "backup" if using_backup else "main"
                print(f"  Re-uploading {total_refs} reference(s) with {key_label} key...")
                if effective_mode == 'flow':
                    ref_uris.clear()
                    all_ref_files = refs['root'] + refs['subject'] + refs['scene'] + refs['style']
                    for ref_file in tqdm(all_ref_files[:10], desc="  Re-upload", unit="file"):
                        try:
                            uri = client.upload_reference(str(ref_file))
                            ref_uris.append(uri)
                        except Exception as e:
                            logging.warning(f"Re-upload failed {ref_file.name}: {e}")
                elif effective_mode == 'whisk':
                    for cat in whisk_refs:
                        whisk_refs[cat].clear()
                    for category in ('subject', 'scene', 'style'):
                        for ref_file in refs[category]:
                            try:
                                uri = client.upload_reference(str(ref_file))
                                whisk_refs[category].append(uri)
                            except Exception as e:
                                logging.warning(f"Re-upload failed {ref_file.name}: {e}")
            key_label = "BACKUP" if using_backup else "MAIN"
            print(f"  {_GREEN}[OK]{_RESET} Switched to {key_label} key. Repeating {len(failed_ids)} clips...")
        elif choice == '4':
            # Ручной ввод промпта для каждого пропущенного клипа
            for cid in list(failed_ids):
                old_prompt = pending_prompts.get(cid, '')
                print(f"\n  {_YELLOW}--- Clip #{cid:03d} ---{_RESET}")
                print(f"  Current prompt:")
                print(f"    {old_prompt[:200]}")
                print()
                new_text = input("  New prompt (Enter = keep current, 's' = skip this clip): ").strip()
                if new_text.lower() == 's':
                    failed_ids.remove(cid)
                    pending_prompts.pop(cid, None)
                    print(f"  #{cid:03d} skipped")
                elif new_text:
                    pending_prompts[cid] = new_text
                    print(f"  #{cid:03d} prompt updated")
                else:
                    print(f"  #{cid:03d} keeping current prompt")
            if not failed_ids:
                break
        # choice '1', '3' или '4' → продолжаем цикл

    elapsed_total = round(time.time() - start_total, 1)

    # ------------------------------------------------------------------
    # 6. Итоги
    # ------------------------------------------------------------------
    # Финальный список: ok из накопителя + failed из pending (результат последнего цикла)
    all_results = list(accumulated_ok.values())
    for cid in sorted(pending_prompts.keys()):
        last_r = next((r for r in reversed(cycle_results) if r['id'] == cid), None)
        if last_r:
            all_results.append(last_r)
        else:
            all_results.append({
                'id': cid, 'status': 'error', 'error': 'not attempted',
                'file': None, 'operation_id': None, 'duration_sec': 0,
            })
    all_results.sort(key=lambda r: r['id'])

    ok_count = sum(1 for r in all_results if r['status'] == 'ok')
    err_count = sum(1 for r in all_results if r['status'] == 'error')
    cen_count = sum(1 for r in all_results if r['status'] == 'censored')

    print("\n" + "=" * 60)
    print(f"  FINAL RESULTS:")
    print(f"    OK:       {ok_count}")
    if cen_count:
        print(f"    Censored: {cen_count}")
    if err_count:
        print(f"    Errors:   {err_count}")
    print(f"    Total:    {len(all_results)}")
    print(f"    Time:     {elapsed_total}s ({cycle_num} cycle(s))")
    print("=" * 60)

    # ------------------------------------------------------------------
    # 7. Сохранение лога
    # ------------------------------------------------------------------
    log_data = {
        'timestamp': datetime.now().isoformat(),
        'model': used_model,
        'aspect_ratio': used_aspect,
        'reference_mode': effective_mode if total_refs > 0 else None,
        'references_used': total_refs,
        'total_clips': len(all_prompts),
        'generated': ok_count,
        'censored': cen_count,
        'failed': err_count,
        'cycles': cycle_num,
        'duration_sec': elapsed_total,
        'clips': all_results,
    }

    log_path = project_path / 'generation_log.json'
    with open(log_path, 'w', encoding='utf-8') as f:
        json.dump(log_data, f, ensure_ascii=False, indent=2)

    logging.info(f"=== Generation done: {ok_count} OK, {err_count} errors, {cen_count} censored, {cycle_num} cycle(s) ===")
    logging.getLogger().removeHandler(file_handler)
    file_handler.close()

    print(f"\n  Log: {log_path}")
    print(f"  Detailed log: {gen_log_path}")

    return log_data
