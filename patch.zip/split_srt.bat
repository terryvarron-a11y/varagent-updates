@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

REM ============================================================================
REM SPLIT_SRT.BAT - Razbit SRT na frazy do N simvolov s proporsionalnym timing
REM Peretashchi .srt fail na etot batnik ili zapusti iz papki s .srt
REM Rezultat: _split.srt  +  _split.txt (prosto tekst fraz)
REM ============================================================================

set "MAX_LEN=99"

REM --- Script location (split_srt.py next to bat, or 3 levels up for SRT subfolders) ---
set "BAT_DIR=%~dp0"
set "PY_SCRIPT=%BAT_DIR%split_srt.py"
if not exist "!PY_SCRIPT!" set "PY_SCRIPT=%BAT_DIR%..\..\..\split_srt.py"
if not exist "!PY_SCRIPT!" (
    echo [ERROR] split_srt.py not found near this bat.
    pause
    exit /b 1
)

REM --- Input file ---
if not "%~1"=="" (
    set "SRT_IN=%~1"
    set "SRT_DIR=%~dp1"
    set "SRT_BASE=%~n1"
) else (
    set "SRT_IN="
    set "SRT_DIR=%CD%\"
    set "SRT_BASE="
    for /f "delims=" %%f in ('dir /b /o-d "*.srt" 2^>nul') do (
        if "!SRT_IN!"=="" (
            echo %%f | findstr /i "_split" >nul || (
                set "SRT_IN=!SRT_DIR!%%f"
                set "SRT_BASE=%%~nf"
            )
        )
    )
    if "!SRT_IN!"=="" (
        echo [ERROR] SRT file not found. Drag-drop .srt onto this bat or run from SRT folder.
        pause
        exit /b 1
    )
)

set "SRT_OUT=!SRT_DIR!!SRT_BASE!_split.srt"
set "TXT_OUT=!SRT_DIR!!SRT_BASE!_split.txt"

echo.
echo ================================================================================
echo  SRT SPLITTER
echo  Input:   !SRT_IN!
echo  Max len: %MAX_LEN% chars
echo  Out SRT: !SRT_OUT!
echo  Out TXT: !TXT_OUT!
echo ================================================================================
echo.

python "!PY_SCRIPT!" "!SRT_IN!" "!SRT_OUT!" "!TXT_OUT!" %MAX_LEN%

if errorlevel 1 (
    echo.
    echo [ERROR] Split failed.
    pause
    exit /b 1
)

echo.
echo [OK] !SRT_OUT!
echo [OK] !TXT_OUT!
echo.
pause
