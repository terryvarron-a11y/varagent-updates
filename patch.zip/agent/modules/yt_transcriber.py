"""
yt_transcriber.py — Транскрибирует видео YouTube канала через AssemblyAI.

Использование из кода:
    from modules.yt_transcriber import run_channel_transcription
    run_channel_transcription(
        channel_url="https://www.youtube.com/@SomeChannel/videos",
        out_dir=Path("projects/channel_subs"),
        max_videos=10,
        sort_mode="latest",   # latest | popular | oldest | random
        ytdlp_path=None,      # auto-detect
        progress_cb=None,     # callback(msg: str, level: str)
        stop_event=None,      # threading.Event для отмены
    )
"""

import os
import sys
import json
import logging
import time
import random
import shutil
import threading
import subprocess
import requests
from pathlib import Path
from typing import Optional, Callable

import config


def _utf8_env() -> dict:
    """Return env dict that forces UTF-8 output from subprocesses (yt-dlp)."""
    env = dict(os.environ)
    env['PYTHONUTF8'] = '1'
    env['PYTHONIOENCODING'] = 'utf-8'
    return env


def _run_ytdlp(cmd: list, **kwargs) -> subprocess.CompletedProcess:
    """Run yt-dlp subprocess with correct encoding handling.
    On Windows yt-dlp outputs cp1251, not UTF-8.
    Injects --js-runtimes nodejs if node is available."""
    # Inject common flags after the exe path (cmd[0])
    inject = []
    if '--js-runtimes' not in cmd:
        import shutil
        if shutil.which('node'):
            inject += ['--js-runtimes', 'node']
    if '--cookies-from-browser' not in cmd:
        _browser = getattr(config, 'YTDLP_COOKIES_BROWSER', 'opera')
        inject += ['--cookies-from-browser', _browser]
    if inject:
        cmd = [cmd[0]] + inject + cmd[1:]
    kwargs.setdefault('capture_output', True)
    kwargs.setdefault('env', _utf8_env())
    # Read as bytes, decode manually
    kwargs.pop('text', None)
    kwargs.pop('encoding', None)
    kwargs.pop('errors', None)
    result = subprocess.run(cmd, **kwargs)
    # Try UTF-8 first, fallback to cp1251 (Windows Russian locale)
    for enc in ('utf-8', 'cp1251', 'latin-1'):
        try:
            result.stdout = result.stdout.decode(enc)
            break
        except (UnicodeDecodeError, AttributeError):
            continue
    if isinstance(result.stdout, bytes):
        result.stdout = result.stdout.decode('utf-8', errors='replace')
    if isinstance(result.stderr, bytes):
        result.stderr = result.stderr.decode('utf-8', errors='replace')
    return result


# ── AssemblyAI helpers ───────────────────────────────────────────────────────

_POLL_INTERVAL = 10
_MAX_WAIT = 900  # 15 min max per video


def _ms_to_srt(ms: int) -> str:
    h  = ms // 3_600_000; ms -= h * 3_600_000
    m  = ms // 60_000;    ms -= m * 60_000
    s  = ms // 1_000;     ms -= s * 1_000
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def _words_to_srt(words: list, max_chars: int = 60, max_gap_ms: int = 1000) -> str:
    if not words:
        return ""
    groups, group = [], []
    for w in words:
        if group:
            gap = w["start"] - group[-1]["end"]
            text_so_far = " ".join(x["text"] for x in group)
            if gap > max_gap_ms or len(text_so_far) + len(w["text"]) + 1 > max_chars:
                groups.append(group)
                group = []
        group.append(w)
    if group:
        groups.append(group)

    parts = []
    for i, grp in enumerate(groups, 1):
        start = _ms_to_srt(grp[0]["start"])
        end   = _ms_to_srt(grp[-1]["end"])
        text  = " ".join(w["text"] for w in grp)
        parts.append(f"{i}\n{start} --> {end}\n{text}\n")
    return "\n".join(parts)


def _get_segments(transcript_id: str, api_key: str, mode: str = "sentences") -> list:
    """Get sentences or paragraphs from AssemblyAI for a completed transcript."""
    endpoint = "sentences" if mode == "sentences" else "paragraphs"
    url = f"https://api.assemblyai.com/v2/transcript/{transcript_id}/{endpoint}"
    resp = requests.get(url, headers={"authorization": api_key}, timeout=60)
    resp.raise_for_status()
    return resp.json().get(endpoint, [])


def _segments_to_srt(segments: list) -> str:
    """Convert AssemblyAI sentences/paragraphs to SRT format."""
    if not segments:
        return ""
    blocks = []
    for i, seg in enumerate(segments, 1):
        start_ms = seg.get("start", 0)
        end_ms = seg.get("end", 0)
        text = seg.get("text", "").strip()
        if not text:
            continue
        blocks.append(f"{i}\n{_ms_to_srt(start_ms)} --> {_ms_to_srt(end_ms)}\n{text}\n")
    return "\n".join(blocks)


def _srt_to_plain(srt_text: str) -> str:
    """Убирает временные метки и номера блоков — чистый текст."""
    lines, out = srt_text.splitlines(), []
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        # пропускаем номер блока (только цифры)
        if line.isdigit():
            i += 1
            continue
        # пропускаем строку с временем (содержит "-->")
        if "-->" in line:
            i += 1
            continue
        if line:
            out.append(line)
        i += 1
    return " ".join(out)


def _upload_audio(file_path: Path, api_key: str) -> str:
    """Загружает аудиофайл в AssemblyAI, возвращает upload_url."""
    with open(file_path, "rb") as f:
        resp = requests.post(
            "https://api.assemblyai.com/v2/upload",
            headers={"authorization": api_key},
            data=f,
            timeout=300,
        )
    resp.raise_for_status()
    return resp.json()["upload_url"]


def _try_download_subs(vid_id: str, ytdlp: str, lang: str, out_srt: Path, out_txt: Path,
                        log: Callable) -> bool:
    """Try to download auto-subs or manual subs via yt-dlp. Returns True if successful."""
    tmp_dir = out_srt.parent / "_tmp_subs"
    tmp_dir.mkdir(exist_ok=True)
    tmp_base = str(tmp_dir / vid_id)

    # Try auto-generated subs first, then manual subs
    for sub_flag in ["--write-auto-subs", "--write-subs"]:
        cmd = [
            ytdlp, "--skip-download",
            sub_flag,
            "--sub-langs", f"{lang},en",
            "--sub-format", "srt",
            "--convert-subs", "srt",
            "-o", tmp_base + ".%(ext)s",
            f"https://www.youtube.com/watch?v={vid_id}",
        ]
        try:
            r = _run_ytdlp(cmd, timeout=60)
        except Exception:
            continue

        # Find downloaded .srt file
        for try_lang in [lang, "en"]:
            srt_file = tmp_dir / f"{vid_id}.{try_lang}.srt"
            if srt_file.exists() and srt_file.stat().st_size > 100:
                import shutil
                shutil.copy(str(srt_file), str(out_srt))
                # Convert SRT to plain text
                text_lines = []
                for line in srt_file.read_text(encoding='utf-8', errors='replace').splitlines():
                    line = line.strip()
                    if not line or line.isdigit() or '-->' in line:
                        continue
                    text_lines.append(line)
                out_txt.write_text('\n'.join(text_lines), encoding='utf-8')
                label = "auto-subs" if sub_flag == "--write-auto-subs" else "manual subs"
                log(f"   Субтитры скачаны ({label}, {try_lang}): {out_srt.name}")
                # Cleanup
                try:
                    import shutil as _sh
                    _sh.rmtree(str(tmp_dir), ignore_errors=True)
                except Exception:
                    pass
                return True
    # Cleanup
    try:
        import shutil as _sh
        _sh.rmtree(str(tmp_dir), ignore_errors=True)
    except Exception:
        pass
    return False


def _submit_transcription(audio_url: str, api_key: str) -> str:
    """Отправляет задание на транскрипцию, возвращает transcript_id."""
    resp = requests.post(
        "https://api.assemblyai.com/v2/transcript",
        headers={"authorization": api_key, "content-type": "application/json"},
        json={
            "audio_url": audio_url,
            "language_detection": True,
            "speech_models": config.ASSEMBLYAI_SPEECH_MODELS or ["universal-3-pro", "universal-2"],
        },
        timeout=60,
    )
    resp.raise_for_status()
    return resp.json()["id"]


def _wait_result(transcript_id: str, api_key: str,
                 stop_event: Optional[threading.Event] = None,
                 progress_cb=None) -> dict:
    url = f"https://api.assemblyai.com/v2/transcript/{transcript_id}"
    headers = {"authorization": api_key}
    elapsed = 0
    while elapsed < _MAX_WAIT:
        if stop_event and stop_event.is_set():
            raise InterruptedError("Cancelled")
        resp = requests.get(url, headers=headers, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        status = data["status"]
        if status == "completed":
            return data
        if status == "error":
            raise RuntimeError(f"AssemblyAI error: {data.get('error')}")
        time.sleep(_poll_interval := _POLL_INTERVAL)
        elapsed += _poll_interval
        if progress_cb:
            progress_cb(f"   [{elapsed}s] {status}...", "INFO")
    raise TimeoutError(f"Timeout after {_MAX_WAIT}s")


# ── yt-dlp helpers ───────────────────────────────────────────────────────────

def _find_ytdlp(ytdlp_path: Optional[str] = None) -> str:
    if ytdlp_path and Path(ytdlp_path).exists():
        return ytdlp_path
    # рядом со скриптом varagent.py
    candidates = [
        Path(__file__).parent.parent.parent / "yt-dlp.exe",
        Path(__file__).parent.parent.parent / "yt-dlp",
    ]
    for c in candidates:
        if c.exists():
            return str(c)
    # в PATH
    return "yt-dlp"


def _get_channel_name(channel_url: str, ytdlp: str) -> str:
    """Возвращает реальное имя канала через yt-dlp.
    --flat-playlist не отдаёт channel metadata, поэтому используем
    --skip-download --playlist-items 1 для получения полной метадаты одного видео."""
    _bad = {"NA", "na", "N/A", "n/a", "None", ""}
    for field in ("%(channel)s", "%(uploader)s"):
        cmd = [ytdlp, "--playlist-items", "1", "--skip-download",
               "--print", field,
               channel_url]
        result = _run_ytdlp(cmd)
        for line in result.stdout.splitlines():
            val = line.strip()
            if val and val not in _bad:
                return val
    # Fallback: parse @handle from URL
    url_clean = channel_url.rstrip("/")
    if "/@" in url_clean:
        return url_clean.split("/@")[-1].split("/")[0]
    if "/c/" in url_clean or "/channel/" in url_clean:
        return url_clean.split("/")[-1]
    return ""


def _get_video_list(channel_url: str, ytdlp: str,
                    sort_mode: str = "latest",
                    max_videos: int = 0,
                    progress_cb=None) -> list:
    """Возвращает список видео [{id, title, date, view_count}].
    sort_mode: latest | popular | oldest | random
    max_videos: 0 = все
    """
    cmd = [ytdlp, "--flat-playlist", "--print", "%(id)s\t%(title)s\t%(upload_date)s\t%(view_count)s",
           channel_url]
    if progress_cb:
        progress_cb("Получаем список видео...", "INFO")
    result = _run_ytdlp(cmd)
    videos = []
    for line in result.stdout.splitlines():
        parts = line.strip().split("\t")
        if len(parts) >= 2 and parts[0].strip():
            vid_id = parts[0].strip()
            title  = parts[1].strip() if len(parts) > 1 else vid_id
            date   = parts[2].strip() if len(parts) > 2 else "00000000"
            views  = int(parts[3].strip()) if len(parts) > 3 and parts[3].strip().isdigit() else 0
            videos.append({"id": vid_id, "title": title, "date": date, "views": views})

    if sort_mode == "latest":
        videos.sort(key=lambda v: v["date"], reverse=True)
    elif sort_mode == "oldest":
        videos.sort(key=lambda v: v["date"])
    elif sort_mode == "popular":
        videos.sort(key=lambda v: v["views"], reverse=True)
    elif sort_mode == "random":
        random.shuffle(videos)

    if max_videos and max_videos > 0:
        videos = videos[:max_videos]

    if progress_cb:
        progress_cb(f"Найдено видео: {len(videos)}", "INFO")
    return videos


def _download_audio(vid_id: str, ytdlp: str, tmp_dir: Path,
                    progress_cb=None) -> Path:
    """Скачивает аудио видео в tmp_dir, возвращает путь к файлу."""
    yt_url = f"https://www.youtube.com/watch?v={vid_id}"
    out_tmpl = str(tmp_dir / f"{vid_id}.%(ext)s")
    cmd = [ytdlp,
           "--extract-audio", "--audio-format", "mp3", "--audio-quality", "5",
           "--no-playlist",
           "-o", out_tmpl,
           yt_url]
    result = _run_ytdlp(cmd)
    # Debug: log what yt-dlp said
    logging.info(f"yt-dlp audio stdout: {(result.stdout or '')[-500:]}")
    logging.info(f"yt-dlp audio stderr: {(result.stderr or '')[-500:]}")
    logging.info(f"yt-dlp audio returncode: {result.returncode}")
    logging.info(f"yt-dlp looking for audio in: {tmp_dir}")
    # List what's actually in tmp_dir
    if tmp_dir.exists():
        found = list(tmp_dir.iterdir())
        logging.info(f"yt-dlp tmp_dir contents: {[f.name for f in found]}")
    for ext in ("mp3", "m4a", "opus", "webm", "ogg", "wav"):
        p = tmp_dir / f"{vid_id}.{ext}"
        if p.exists():
            return p
    # Fallback: any audio file in tmp_dir with vid_id in name
    for f in tmp_dir.iterdir():
        if vid_id in f.name and f.suffix in ('.mp3', '.m4a', '.opus', '.webm', '.ogg', '.wav'):
            logging.info(f"yt-dlp fallback match: {f.name}")
            return f
    raise RuntimeError("Audio file not found after yt-dlp download")


# ── Main public function ─────────────────────────────────────────────────────

def run_channel_transcription(
    channel_url: str,
    out_dir: Path,
    max_videos: int = 0,
    sort_mode: str = "latest",
    ytdlp_path: Optional[str] = None,
    progress_cb: Optional[Callable] = None,
    stop_event: Optional[threading.Event] = None,
    try_subs_first: bool = False,
    subs_lang: str = "ru",
    seg_mode: str = "sentences",
) -> dict:
    """
    Транскрибирует видео YouTube-канала через AssemblyAI.

    Сохраняет в out_dir:
      - {date}_{title}_{id}.srt         — субтитры с метками времени
      - {date}_{title}_{id}.txt         — чистый текст (скрипт)
      - 0_split_{channel_slug}.txt  — все скрипты в одном файле

    Возвращает: {"done": N, "total": M, "srt_dir": str(out_dir)}
    """

    def log(msg, level="INFO"):
        if progress_cb:
            progress_cb(msg, level)

    api_key = getattr(config, "ASSEMBLYAI_API_KEY", "") or os.getenv("ASSEMBLYAI_API_KEY", "")
    if not api_key:
        raise RuntimeError("ASSEMBLYAI_API_KEY не задан в config/.env")

    ytdlp = _find_ytdlp(ytdlp_path)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Получаем реальное имя канала и список видео
    channel_name = _get_channel_name(channel_url, ytdlp)
    videos = _get_video_list(channel_url, ytdlp, sort_mode, max_videos, log)
    if not videos:
        log("Нет видео на канале или yt-dlp не смог получить список", "ERROR")
        return {"done": 0, "total": 0, "srt_dir": str(out_dir)}

    # Имя папки канала
    if channel_name:
        channel_slug = "".join(c if c.isalnum() or c in " _-" else "_" for c in channel_name)[:60].strip()
    else:
        # Fallback: из URL
        channel_slug = channel_url.rstrip("/").split("/")[-1].lstrip("@")[:40]
        channel_slug = "".join(c if c.isalnum() or c in "-_" else "_" for c in channel_slug)
    log(f"Канал: {channel_name or channel_slug}", "INFO")

    # Подпапка для каждого канала
    out_dir = out_dir / channel_slug
    out_dir.mkdir(parents=True, exist_ok=True)
    tmp_dir = out_dir / "_tmp_audio"
    tmp_dir.mkdir(exist_ok=True)

    split_path = out_dir / f"0_split_{channel_slug}.txt"

    log(f"Транскрибируем {len(videos)} видео → {out_dir}", "INFO")
    done = 0

    for i, v in enumerate(videos, 1):
        if stop_event and stop_event.is_set():
            log("Остановлено пользователем", "WARNING")
            break

        vid_id = v["id"]
        title  = v["title"]
        date   = v["date"]
        safe   = "".join(c if c.isalnum() or c in " _-" else "_" for c in title)[:80].strip()

        srt_path = out_dir / f"{date}_{safe}_{vid_id}.srt"
        txt_path = out_dir / f"{date}_{safe}_{vid_id}.txt"

        if srt_path.exists() and txt_path.exists():
            log(f"[{i}/{len(videos)}] SKIP (уже есть): {srt_path.name}", "INFO")
            # Append skipped to splitscript too
            if txt_path.exists():
                plain = txt_path.read_text(encoding='utf-8', errors='replace').strip()
                if plain:
                    with open(split_path, "a", encoding="utf-8") as sf:
                        sf.write(f"\n\n{'='*60}\n")
                        sf.write(f"## {title}\n")
                        sf.write(f"{'='*60}\n\n")
                        sf.write(plain)
                        sf.write("\n")
            done += 1
            continue

        log(f"[{i}/{len(videos)}] {title[:70]}", "INFO")

        # Try downloading existing subtitles first
        if try_subs_first:
            if _try_download_subs(vid_id, ytdlp, subs_lang, srt_path, txt_path, log):
                # Append to splitscript
                if txt_path.exists():
                    plain = txt_path.read_text(encoding='utf-8', errors='replace')
                    with open(split_path, "a", encoding="utf-8") as sf:
                        sf.write(f"\n\n{'='*60}\n")
                        sf.write(f"# {title}\n")
                        sf.write(f"# {date} | subs\n")
                        sf.write(f"{'='*60}\n\n")
                        sf.write(plain)
                done += 1
                continue
            log(f"   Субтитры не найдены, транскрибируем через AssemblyAI...", "INFO")

        audio_file = None
        try:
            # 1. Скачиваем аудио
            log(f"   Скачиваем аудио...", "INFO")
            audio_file = _download_audio(vid_id, ytdlp, tmp_dir, log)
            sz = audio_file.stat().st_size // 1024
            log(f"   Скачано: {audio_file.name} ({sz} KB)", "INFO")

            # 2. Загружаем в AssemblyAI
            log(f"   Загружаем в AssemblyAI...", "INFO")
            upload_url = _upload_audio(audio_file, api_key)
            log(f"   Загружено OK", "INFO")

            # 3. Транскрибируем
            tid = _submit_transcription(upload_url, api_key)
            log(f"   Транскрибируем ({tid[:8]}...)...", "INFO")
            data = _wait_result(tid, api_key, stop_event, log)
            log("", "INFO")  # clear progress line

            lang     = data.get("language_code", "?")
            duration = data.get("audio_duration", 0)
            words    = data.get("words") or []

            if seg_mode in ("sentences", "paragraphs"):
                try:
                    segments = _get_segments(tid, api_key, seg_mode)
                    srt_text = _segments_to_srt(segments)
                except Exception as _seg_e:
                    log(f"   {seg_mode} failed ({_seg_e}), fallback to words", "WARNING")
                    srt_text = _words_to_srt(words) if words else ""
            elif words:
                srt_text = _words_to_srt(words)
            else:
                text    = data.get("text") or ""
                dur_ms  = int((duration or 0) * 1000)
                srt_text = f"1\n00:00:00,000 --> {_ms_to_srt(dur_ms)}\n{text}\n" if text else ""

            if srt_text:
                srt_path.write_text(srt_text, encoding="utf-8")
                plain = _srt_to_plain(srt_text)
                txt_path.write_text(plain, encoding="utf-8")

                # Дописываем в splitscript
                with open(split_path, "a", encoding="utf-8") as sf:
                    sf.write(f"\n\n{'='*60}\n")
                    sf.write(f"# {title}\n")
                    sf.write(f"# {date} | {lang} | {int(duration or 0)}s\n")
                    sf.write(f"{'='*60}\n\n")
                    sf.write(plain)

                log(f"   OK [{lang}] {len(words)} words → {srt_path.name}", "SUCCESS")
                done += 1
            else:
                log(f"   EMPTY — текст не получен", "WARNING")

        except InterruptedError:
            break
        except Exception as e:
            log(f"   ERROR: {e}", "ERROR")
        finally:
            if audio_file and audio_file.exists():
                try:
                    audio_file.unlink()
                except Exception:
                    pass

        time.sleep(2)

    # Удаляем tmp папку если пустая
    try:
        if tmp_dir.exists() and not any(tmp_dir.iterdir()):
            tmp_dir.rmdir()
    except Exception:
        pass

    log(f"Готово: {done}/{len(videos)} субтитров в {out_dir}", "SUCCESS")
    return {"done": done, "total": len(videos), "srt_dir": str(out_dir)}
