"""
VeoNonStop imggen — batch-генерация изображений (альтернатива FastGen)

Режимы:
  imagen       — Imagen 3.5 text-to-image
  banana       — Banana Pro text-to-image       (model: GEM_PIX_2)
  banana_ref   — Banana Pro + style-reference   (model: GEM_PIX_2)
  banana2      — Banana 2 text-to-image         (model: NARWHAL)
  banana2_ref  — Banana 2 + style-reference     (model: NARWHAL)

Результат: generated/{id:03d}.png  (совместимо с i2v и Ken Burns)
"""

import sys
import time
import random
import logging
import threading

IS_PIPE = not sys.stdout.isatty()  # True когда запущен как subprocess (pipeline mode)
import signal
import requests
import contextlib
from pathlib import Path
from typing import Optional, Dict, List, Any
from datetime import datetime
import concurrent.futures
from concurrent.futures import ThreadPoolExecutor, as_completed

# Ensure agent/ and agent/modules/ dirs are on sys.path
_agent_dir = str(Path(__file__).resolve().parent.parent)
_modules_dir = str(Path(__file__).resolve().parent)
if _agent_dir not in sys.path:
    sys.path.insert(0, _agent_dir)
if _modules_dir not in sys.path:
    sys.path.insert(0, _modules_dir)

from tqdm import tqdm
import colorama
from colorama import Fore, Style

colorama.init(autoreset=True)

_YELLOW = Fore.YELLOW
_RED    = Fore.RED
_GREEN  = Fore.GREEN
_CYAN   = Fore.CYAN
_RESET  = Style.RESET_ALL

import config
from extract_prompt import extract_all_prompts, find_prompts_file
from veononstop import (
    VeoNonStopClient,
    VeoNonStopError,
    VeoNonStopTimeoutError,
    VeoNonStopGenerationError,
    VeoNonStopRateLimitError,
    VeoNonStopTokenExpiredError,
    _load_ref_images,
)


# ======================================================================
# Rewrite промпта при цензуре
# ======================================================================

def _rewrite_prompt(original_prompt: str) -> str:
    """
    Rewrite a blocked prompt via Gemini API.
    Instruction is loaded from agent/prompts/rewrite_prompt.txt (user-editable).
    """
    from gemini_rewrite import rewrite_prompt as _gemini_rewrite
    return _gemini_rewrite(original_prompt)


# ======================================================================
# Генерация одного изображения
# ======================================================================

# Нумерация воркеров: thread_id → worker_id (для красивого лога)
_imggen_worker_map: Dict[int, int] = {}        # thread_id → worker_id
_imggen_worker_task_count: Dict[int, int] = {} # thread_id → tasks done by this worker
_imggen_worker_counter = [0]
_imggen_worker_lock = threading.Lock()
_banana_submit_sem: Optional[threading.Semaphore] = None  # лимит одновременных banana-запросов
_shutdown_event = threading.Event()
_active_clients: list = []  # list of VeoNonStopClient for Ctrl+C cancel
# Legacy alias for single-client access
_active_client: list = [None]


def _sigint_handler(sig, frame):
    if _shutdown_event.is_set():
        return
    _shutdown_event.set()
    print(f"\n\n  [CANCELLING] Ctrl+C — sending cancel-all to server...", flush=True)
    for c in _active_clients:
        try:
            cancelled = c.cancel_all_tasks()
            print(f"  [CANCELLING] {cancelled} task(s) cancelled on server", flush=True)
        except Exception as e:
            print(f"  [CANCELLING] cancel-all failed: {e}", flush=True)
    print(f"  [CANCELLING] Stopping workers...\n", flush=True)

_CENSORSHIP_KEYWORDS = [
    'invalid argument', 'safety', 'blocked', 'censored',
    'harmful', 'policy', 'prohibited', 'violat',
    'prominent person', 'dangerous', 'inappropriate',
    # VeoNonStop API error codes
    'prominent_people_filter',
    'public_error_danger_filter',
    'public_error_unsafe_generation',
    'public_error_ip_input_image',
    'public_error_audio_filtered',
]


def _is_censorship_error(err_str: str) -> bool:
    """Проверяет, является ли ошибка цензурной."""
    err_lower = err_str.lower()
    return any(kw in err_lower for kw in _CENSORSHIP_KEYWORDS)


def _try_generate(
    client: VeoNonStopClient,
    clip_id: int,
    prompt: str,
    mode: str,
    output_path: Path,
    aspect_ratio: Optional[str] = None,
    ref_images: Optional[List[Dict[str, str]]] = None,
    max_retries: int = 3,
    phase_label: str = "phase1",
    worker_id: int = 0,
    submit_sem=None,
    ok_run: Optional[dict] = None,
) -> Dict[str, Any]:
    """
    Внутренний цикл генерации (одна фаза).
    Возвращает {'status': 'ok'|'blocked'|'error', 'block_count': int, ...}
    """
    result = {
        'id': clip_id,
        'status': 'error',
        'file': None,
        'error': None,
        'duration_sec': 0,
        'task_id': None,
        'block_count': 0,
    }

    attempt = 0
    while attempt < max_retries:
        if _shutdown_event.is_set():
            result['error'] = 'shutdown requested'
            return result
        attempt += 1
        try:
            start = time.time()

            if mode == 'imagen':
                client.generate_imagen(
                    prompt=prompt,
                    output_path=str(output_path),
                    aspect_ratio=aspect_ratio,
                )
            elif mode in ('banana', 'banana_ref'):
                _sem = submit_sem if submit_sem is not None else _banana_submit_sem
                with (_sem if _sem is not None else contextlib.nullcontext()):
                    client.generate_banana(
                        prompt=prompt,
                        output_path=str(output_path),
                        aspect_ratio=aspect_ratio,
                        num_images=1,
                        reference_images=ref_images if mode == 'banana_ref' else None,
                    )
            elif mode in ('banana2', 'banana2_ref'):
                _sem = submit_sem if submit_sem is not None else _banana_submit_sem
                with (_sem if _sem is not None else contextlib.nullcontext()):
                    client.generate_banana(
                        prompt=prompt,
                        output_path=str(output_path),
                        aspect_ratio=aspect_ratio,
                        num_images=1,
                        reference_images=ref_images if mode == 'banana2_ref' else None,
                        model_key='NARWHAL',
                    )
            else:
                raise ValueError(f"Unknown imggen mode: {mode}")

            elapsed = round(time.time() - start, 1)
            result.update({
                'status': 'ok',
                'file': str(output_path),
                'duration_sec': elapsed,
            })
            print(f"  {_GREEN}[OK]{_RESET} #{clip_id} [W{worker_id}]: {elapsed}s")
            if ok_run is not None:
                with ok_run['lock']:
                    ok_run['n'] += 1
                    ok_run['total'] += elapsed
                    _avg = ok_run['total'] / ok_run['n']
                    _n   = ok_run['n']
                _wall = time.time() - ok_run['wall_start']
                _wall_cpm = _n / (_wall / 60) if _wall > 0 else 0
                _wall_spc = 60.0 / _wall_cpm if _wall_cpm > 0 else 0
                print(f"  {_CYAN}[SPEED]{_RESET} worker avg={_avg:.0f}s/clip  |  pool {_wall_spc:.1f}s/clip ({_wall_cpm:.1f} clip/min)")
            logging.info(f"Clip #{clip_id}: imggen OK ({elapsed}s) [{phase_label}]")
            return result

        except VeoNonStopTokenExpiredError:
            # Не тратим попытку, не считаем блоком — временная ошибка сервера
            attempt -= 1
            msg = f"#{clip_id} [W{worker_id}] [{phase_label}] attempt {attempt}: token expired, waiting 30s..."
            logging.warning(f"Clip {msg}")
            print(f"\n  {_YELLOW}[TOKEN]{_RESET} {msg}")
            time.sleep(30)

        except VeoNonStopRateLimitError:
            # Не тратим попытку
            attempt -= 1
            msg = f"#{clip_id} [W{worker_id}] [{phase_label}] attempt {attempt}: rate limit, waiting 60s..."
            logging.warning(f"Clip {msg}")
            print(f"\n  {_YELLOW}[RATELIMIT]{_RESET} {msg}")
            time.sleep(60)

        except VeoNonStopTimeoutError as e:
            result['error'] = str(e)
            logging.warning(f"Clip #{clip_id} [W{worker_id}] [{phase_label}] attempt {attempt}/{max_retries}: timeout")
            print(f"\n  {_YELLOW}[TIMEOUT]{_RESET} #{clip_id} [{phase_label}] {attempt}/{max_retries}")
            if attempt < max_retries:
                time.sleep(min(10 * attempt, 60))

        except (VeoNonStopGenerationError, VeoNonStopError) as e:
            err_str = str(e).lower()
            result['error'] = str(e)

            # Цензура / invalid argument — считаем блокировки
            if _is_censorship_error(err_str):
                result['block_count'] += 1
                logging.warning(f"Clip #{clip_id} [W{worker_id}] [{phase_label}] attempt {attempt}/{max_retries}: BLOCKED ({result['block_count']}x) — {e}")
                print(f"\n  {_RED}[BLOCKED]{_RESET}  #{clip_id} [{phase_label}] {attempt}/{max_retries} (block #{result['block_count']})")
                if attempt < max_retries:
                    time.sleep(5)
                continue

            # reCAPTCHA / FORBIDDEN — не тратим попытку
            if 'recaptcha' in err_str or 'forbidden' in err_str:
                attempt -= 1
                msg = f"#{clip_id} [W{worker_id}] [{phase_label}] attempt {attempt}: reCAPTCHA/FORBIDDEN — waiting 15s..."
                logging.warning(msg)
                print(f"\n  {_YELLOW}[RECAPTCHA]{_RESET} {msg}")
                time.sleep(15)
                continue

            # Cookie slots full — ждём пока предыдущие задачи завершатся, не тратим попытку
            if 'cookie slots full' in err_str:
                attempt -= 1
                if not hasattr(_try_generate, '_slots_full_counts'):
                    _try_generate._slots_full_counts = {}
                key = (clip_id, phase_label)
                n = _try_generate._slots_full_counts.get(key, 0) + 1
                _try_generate._slots_full_counts[key] = n
                # Экспоненциальный backoff: 20s, 40s, 60s, 90s, 120s, cap 300s
                wait = min(20 * (2 ** (n - 1)), 300)
                logging.warning(f"Clip #{clip_id} [W{worker_id}] [{phase_label}]: slots full #{n}, waiting {wait}s...")
                print(f"\n  {_YELLOW}[SLOTS FULL]{_RESET} #{clip_id} [W{worker_id}] (#{n}): waiting {wait}s...")
                time.sleep(wait)
                continue

            logging.error(f"Clip #{clip_id} [W{worker_id}] [{phase_label}] attempt {attempt}/{max_retries}: {e}")
            print(f"\n  {_RED}[FAILED]{_RESET}  #{clip_id} [{phase_label}] {attempt}/{max_retries}: {e}")
            if attempt < max_retries:
                time.sleep(min(10 * attempt, 60))

        except (requests.exceptions.ProxyError, requests.exceptions.ConnectionError) as e:
            # Не тратим попытку
            attempt -= 1
            msg = f"#{clip_id} [W{worker_id}] [{phase_label}] {attempt}/{max_retries}: proxy/connection error — waiting 30s..."
            logging.warning(msg)
            print(f"\n  {_YELLOW}[PROXY]{_RESET}   {msg}")
            time.sleep(30)

        except Exception as e:
            result['error'] = str(e)
            logging.error(f"Clip #{clip_id} [W{worker_id}] [{phase_label}] attempt {attempt}/{max_retries}: {e}")
            print(f"\n  {_RED}[ERROR]{_RESET}   #{clip_id} [{phase_label}] {attempt}/{max_retries}: {e}")
            if attempt < max_retries:
                time.sleep(min(10 * attempt, 60))

    # Если были только блокировки — отмечаем
    if result['block_count'] > 0 and result['status'] != 'ok':
        result['status'] = 'blocked'
    return result


def _generate_single_image(
    client: VeoNonStopClient,
    clip_id: int,
    prompt: str,
    mode: str,
    output_dir: Path,
    aspect_ratio: Optional[str] = None,
    ref_images: Optional[List[Dict[str, str]]] = None,
    max_retries: int = 3,
    clients_cfg=None,   # if provided: dual-key worker-assignment overrides client
    ok_run: Optional[dict] = None,
) -> Dict[str, Any]:
    """
    Генерация одного изображения с двумя фазами:
    Фаза 1: до max_retries попыток с оригинальным промптом.
    Фаза 2 (при блокировке): rewrite промпта → ещё max_retries попыток.
    """
    output_path = output_dir / f"{clip_id:03d}.png"

    # Назначаем worker_id по thread_id (для красивого лога)
    tid = threading.get_ident()
    with _imggen_worker_lock:
        if tid not in _imggen_worker_map:
            _imggen_worker_map[tid] = _imggen_worker_counter[0]
            _imggen_worker_counter[0] += 1
            _imggen_worker_task_count[tid] = 0
        worker_id = _imggen_worker_map[tid]
        task_num = _imggen_worker_task_count[tid]
        _imggen_worker_task_count[tid] += 1

    # ── Worker-assignment: dual-key — выбираем client+sem по worker_id ──
    _submit_sem = None
    _key_label = ''
    if clients_cfg:
        cumulative = 0
        _selected = clients_cfg[-1]
        _group_start = 0
        for _cfg in clients_cfg:
            if worker_id < cumulative + _cfg['mp']:
                _selected = _cfg
                _group_start = cumulative
                break
            cumulative += _cfg['mp']
        client = _selected['client']
        _submit_sem = _selected['sem']
        _key_label = f" [{_selected['label']}]"
        local_worker_id = worker_id - _group_start
    else:
        local_worker_id = worker_id

    # Stagger:
    #   Первая задача каждого воркера — local_worker_id × REQUEST_DELAY (волновой запуск)
    #   Последующие задачи — REQUEST_DELAY + микроджиттер (контролируется из .env)
    jitter = random.uniform(0.5, 1.0)
    if task_num == 0:
        stagger = local_worker_id * config.VEONONSTOP_REQUEST_DELAY
    else:
        stagger = config.VEONONSTOP_REQUEST_DELAY
    total_delay = stagger + jitter
    logging.info(f"Clip #{clip_id} [W{worker_id}]{_key_label} task#{task_num}: stagger {stagger}s + jitter {jitter:.1f}s")
    time.sleep(total_delay)

    # ── Фаза 1: оригинальный промпт ──
    phase1 = _try_generate(
        client, clip_id, prompt, mode, output_path,
        aspect_ratio=aspect_ratio, ref_images=ref_images,
        max_retries=max_retries, phase_label="phase1", worker_id=worker_id,
        submit_sem=_submit_sem, ok_run=ok_run,
    )

    if phase1['status'] == 'ok':
        return phase1

    # Если не было блокировок — техническая ошибка, rewrite не поможет
    if phase1['status'] != 'blocked':
        return phase1

    # ── Rewrite промпта ──
    print(f"  {_RED}[REWRITE]{_RESET}  #{clip_id}: blocked {phase1['block_count']}x, rewriting prompt...")
    logging.info(f"Clip #{clip_id}: blocked {phase1['block_count']}x, starting rewrite")

    new_prompt = _rewrite_prompt(prompt)
    if new_prompt == prompt:
        print(f"  {_YELLOW}[REWRITE]{_RESET}  #{clip_id}: rewrite returned same prompt, giving up")
        logging.warning(f"Clip #{clip_id}: rewrite returned same prompt")
        phase1['status'] = 'blocked'
        return phase1

    print(f"  {_RED}[REWRITE]{_RESET}  #{clip_id}: prompt rewritten, starting phase2...")
    logging.info(f"Clip #{clip_id}: new prompt: {new_prompt[:100]}...")

    # ── Фаза 2: переписанный промпт ──
    phase2 = _try_generate(
        client, clip_id, new_prompt, mode, output_path,
        aspect_ratio=aspect_ratio, ref_images=ref_images,
        max_retries=max_retries, phase_label="phase2", worker_id=worker_id,
        submit_sem=_submit_sem, ok_run=ok_run,
    )

    # Накапливаем block_count обеих фаз
    phase2['block_count'] = phase2.get('block_count', 0) + phase1.get('block_count', 0)

    if phase2['status'] == 'ok':
        return phase2

    # Обе фазы провалились
    if phase2['status'] == 'blocked':
        print(f"  {_RED}[SKIP]{_RESET}     #{clip_id}: blocked after rewrite (total blocks: {phase2['block_count']}), giving up")
        logging.error(f"Clip #{clip_id}: BLOCKED after both phases (total blocks: {phase2['block_count']})")
    else:
        print(f"  {_RED}[FAILED]{_RESET}   #{clip_id}: failed after rewrite")
        logging.error(f"Clip #{clip_id}: FAILED after both phases: {phase2.get('error')}")

    phase2['status'] = 'blocked' if phase2.get('block_count', 0) > 0 else 'error'
    return phase2


# ======================================================================
# Основная функция: batch-генерация изображений
# ======================================================================

def generate_all_images(
    project_dir: str,
    mode: str = 'imagen',
    max_parallel: Optional[int] = None,
    clip_ids: Optional[List[int]] = None,
    aspect_ratio: Optional[str] = None,
    ref_dir: Optional[str] = None,
    silent: bool = False,
    preflight: bool = True,
    max_cycles: Optional[int] = None,
    active_keys: Optional[List[int]] = None,
) -> Dict[str, Any]:
    """
    Batch-генерация изображений через VeoNonStop (Imagen 3.5 / Banana Pro).

    Args:
        project_dir:    Путь к папке проекта
        mode:           'imagen' | 'banana' | 'banana_ref' | 'banana2' | 'banana2_ref'
        max_parallel:   Макс. параллельных задач
        clip_ids:       Список ID клипов (если None — все из промптов)
        aspect_ratio:   Соотношение сторон
        ref_dir:        Папка с style-reference (для banana_ref). Если None — PROJECT/ref/
        silent:         Авто-режим (без интерактивных вопросов):
                        2 авто-цикла → если ещё остались failed →
                        фоллбэк на FastGen (Gemini) для остатков
        active_keys:    Список 1-based индексов ключей [1], [1,2], [1,2,3,4] и т.д.

    Returns:
        Сводка генерации
    """
    project_path = Path(project_dir)
    max_parallel = max_parallel or config.VEONONSTOP_MAX_PARALLEL

    _KEY_DEFS = [
        (config.VEONONSTOP_API_KEY,   config.VEONONSTOP_MAX_PARALLEL,   config.VEONONSTOP_KEY1_NAME or 'Key1'),
        (config.VEONONSTOP_API_KEY_2, config.VEONONSTOP_MAX_PARALLEL_2, config.VEONONSTOP_KEY2_NAME or 'Key2'),
        (config.VEONONSTOP_API_KEY_3, config.VEONONSTOP_MAX_PARALLEL_3, config.VEONONSTOP_KEY3_NAME or 'Key3'),
        (config.VEONONSTOP_API_KEY_4, config.VEONONSTOP_MAX_PARALLEL_4, config.VEONONSTOP_KEY4_NAME or 'Key4'),
    ]
    _active_keys = active_keys if active_keys else [1]

    # Подавить DEBUG-спам
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    logging.getLogger('requests').setLevel(logging.WARNING)

    # Лог-файл
    log_ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    gen_log_path = project_path / f'imggen_{log_ts}.log'
    file_handler = logging.FileHandler(str(gen_log_path), encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(logging.Formatter('%(asctime)s | %(levelname)-8s | %(message)s'))
    logging.getLogger().addHandler(file_handler)
    logging.info(f"=== VeoNonStop imggen started for {project_path.name} (mode={mode}) ===")

    print("\n" + "=" * 60)
    print(f"  IMGGEN: VeoNonStop ({mode.upper()})")
    print("=" * 60)
    print(f"  Log: {gen_log_path}")

    # ------------------------------------------------------------------
    # 1. Чтение промптов
    # ------------------------------------------------------------------
    prompts_file = find_prompts_file(str(project_path))
    if not prompts_file:
        raise FileNotFoundError(
            f"Prompts file not found in {project_path} "
            f"(expected *_prompts_*.txt)"
        )

    all_prompts = extract_all_prompts(prompts_file)
    if not all_prompts:
        raise ValueError(f"No prompts found in {prompts_file}")

    print(f"\n  Prompts file: {Path(prompts_file).name}")
    print(f"  Total prompts: {len(all_prompts)}")

    # Фильтрация по ID
    if clip_ids:
        all_prompts = {k: v for k, v in all_prompts.items() if k in clip_ids}
        print(f"  Selected clips: {len(all_prompts)}")

    if not all_prompts:
        raise ValueError("No prompts to generate after filtering")

    # ------------------------------------------------------------------
    # 2. Подготовка
    # ------------------------------------------------------------------
    output_dir = project_path / 'generated'
    output_dir.mkdir(exist_ok=True)

    # Загрузка style-reference для banana_ref / banana2_ref
    ref_images = None
    if mode in ('banana_ref', 'banana2_ref'):
        effective_ref_dir = ref_dir or str(project_path / 'ref')
        ref_images = _load_ref_images(effective_ref_dir)
        if not ref_images:
            raise FileNotFoundError(
                f"Mode is {mode} but no reference images found in: {effective_ref_dir}\n"
                f"Add images to project/ref/ or switch to banana/imagen mode."
            )
        else:
            print(f"  Style references: {len(ref_images)} images from {effective_ref_dir}")

    # Пропуск уже существующих (.png, .jpeg, .jpg, .webp)
    skipped = []
    for cid in list(all_prompts.keys()):
        found = False
        for ext in ('.png', '.jpeg', '.jpg', '.webp'):
            p = output_dir / f"{cid:03d}{ext}"
            if p.exists() and p.stat().st_size > 0:
                found = True
                break
        if found:
            skipped.append(cid)
            del all_prompts[cid]

    if skipped:
        print(f"  Skipped (already exist): {len(skipped)}, remaining: {len(all_prompts)}")

    if not all_prompts:
        print("  All images already exist. Nothing to generate.")
        return {'generated': len(skipped), 'failed': 0, 'results': []}

    # ------------------------------------------------------------------
    # 3. Инициализация клиента + сброс зомби-тасков
    # ------------------------------------------------------------------
    # ------------------------------------------------------------------
    # Multi-key init: loop over active_keys, create client per key
    # ------------------------------------------------------------------
    clients_cfg = []
    _any_cancelled = False
    for idx in _active_keys:
        key, mp_cfg, label = _KEY_DEFS[idx - 1]
        if not key:
            continue
        c = VeoNonStopClient(api_key=key)
        print(f"  {_YELLOW}[CLEANUP]{_RESET} [{label}] Cancelling zombie tasks...")
        cancelled = c.cancel_all_tasks()
        if cancelled > 0:
            print(f"  {_YELLOW}[CLEANUP]{_RESET} [{label}] Cancelled {cancelled} zombie task(s).")
            logging.info(f"Startup cancel-all {label}: {cancelled} tasks cancelled")
            _any_cancelled = True
        else:
            print(f"  {_YELLOW}[CLEANUP]{_RESET} [{label}] No active tasks found.")
        try:
            acc = c.get_account_info()
            ct = acc.get('concurrent_tasks', mp_cfg)
            mp = min(mp_cfg, ct)
            print(f"  [{label}] Plan: {acc.get('plan', '?')} | concurrent_tasks: {ct} | using: {mp}")
            logging.info(f"Account {label}: plan={acc.get('plan')}, concurrent_tasks={ct}, mp={mp}")
        except Exception as e:
            mp = mp_cfg
            logging.warning(f"Could not get account info ({label}): {e}")
        sem = threading.Semaphore(max(1, mp // 3))
        clients_cfg.append({'client': c, 'mp': mp, 'sem': sem, 'label': label})

    if _any_cancelled:
        print(f"  {_YELLOW}[CLEANUP]{_RESET} Waiting 3s for server to release slots...")
        time.sleep(3)

    if not clients_cfg:
        raise ValueError("None of the specified VeoNonStop keys are configured in .env")

    # Ctrl+C handler (signal only works in main thread)
    _shutdown_event.clear()
    _active_client[0] = clients_cfg[0]['client']
    _active_clients.clear()
    _active_clients.extend(cfg['client'] for cfg in clients_cfg)
    _old_sigint = None
    if threading.current_thread() is threading.main_thread():
        _old_sigint = signal.signal(signal.SIGINT, _sigint_handler)

    max_parallel = sum(cfg['mp'] for cfg in clients_cfg)
    for cfg in clients_cfg:
        print(f"  [{cfg['label']}] {cfg['mp']} workers | semaphore: {cfg['sem']._value} slots")

    print(f"\n  Mode: {mode.upper()}")
    print(f"  Aspect ratio: {aspect_ratio or config.VEONONSTOP_ASPECT_RATIO}")
    print(f"  Parallel workers: {max_parallel}")
    print("=" * 60)

    # ------------------------------------------------------------------
    # 3b. Предполётная проверка рефов для banana_ref (Preflight)
    # ------------------------------------------------------------------
    if mode in ('banana_ref', 'banana2_ref') and ref_images and preflight and config.FASTGEN_PREFLIGHT_REFS and config.REMIX_AVAILABLE:
        import tempfile, os as _os

        _pf_aspect = aspect_ratio or config.VEONONSTOP_ASPECT_RATIO
        _pf_test_num = [0]   # счётчик тестов для прогресса

        _PF_NET_KEYWORDS = ['connection', 'reset', 'aborted', 'timeout', 'refused', 'network', 'socket', 'recaptcha']

        def _is_network_error(err_str: str) -> bool:
            low = err_str.lower()
            return any(kw in low for kw in _PF_NET_KEYWORDS)

        def _banana_ref_ok(refs_subset, label='', _retry_on_net=5):
            """
            Тест подмножества рефов. True=OK, False=цензура.
            Сетевые ошибки (ConnectionReset, timeout и т.п.) ретраим до _retry_on_net раз,
            чтобы отличить временный сбой соединения от реальной проблемы с рефом.
            Если все ретраи — сетевые ошибки → raise RuntimeError (не продолжаем вслепую).
            """
            if not refs_subset:
                return True
            _pf_test_num[0] += 1
            names = ', '.join(r.get('name', '?') for r in refs_subset)
            tag = f"[{_pf_test_num[0]}]" if not label else f"[{_pf_test_num[0]}] {label}"
            desc = f"  [PREFLIGHT] {tag} {len(refs_subset)} ref(s)"

            net_errors = []

            for attempt in range(1, _retry_on_net + 2):  # +2: initial + retries
                _exc: list = [None]
                _t0 = [time.time()]

                try:
                    with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmp:
                        tmp_path = tmp.name
                except Exception:
                    return True

                _pf_client = clients_cfg[0]['client']

                def _run():
                    try:
                        _pf_client.generate_banana(
                            "abstract cinematic background, no people",
                            output_path=tmp_path,
                            aspect_ratio=_pf_aspect,
                            reference_images=refs_subset,
                        )
                    except Exception as e:
                        _exc[0] = e
                    finally:
                        if _os.path.exists(tmp_path):
                            try:
                                _os.unlink(tmp_path)
                            except Exception:
                                pass

                retry_label = desc if attempt == 1 else f"{desc} [retry {attempt - 1}/{_retry_on_net}]"
                t = threading.Thread(target=_run, daemon=True)
                t.start()
                with tqdm(total=150, desc=retry_label, unit="s",
                          bar_format="{desc}: {bar}| {n:.0f}/{total}s", leave=False) as pbar:
                    while t.is_alive():
                        time.sleep(1)
                        pbar.update(1)
                t.join()

                elapsed = int(time.time() - _t0[0])

                if _exc[0] is None:
                    print(f"  {_GREEN}[PREFLIGHT]{_RESET} {tag} {len(refs_subset)} ref(s): {names}  → OK ({elapsed}s)", flush=True)
                    logging.info(f"PREFLIGHT [{tag}]: OK — {names}")
                    return True

                err_str = str(_exc[0])
                blocked = _is_censorship_error(err_str)

                if blocked:
                    print(f"  {_RED}[PREFLIGHT]{_RESET} {tag} {len(refs_subset)} ref(s): {names}  → BLOCKED ({elapsed}s)", flush=True)
                    logging.warning(f"PREFLIGHT [{tag}]: BLOCKED — {_exc[0]}")
                    return False  # censorship confirmed, no retry

                if _is_network_error(err_str):
                    net_errors.append(err_str)
                    print(f"  {_YELLOW}[PREFLIGHT]{_RESET} {tag}: network error (attempt {attempt}) — {err_str[:80]}", flush=True)
                    logging.warning(f"PREFLIGHT [{tag}] attempt {attempt}: network error — {_exc[0]}")
                    if attempt <= _retry_on_net:
                        wait = 15 * attempt
                        print(f"  {_YELLOW}[PREFLIGHT]{_RESET} Waiting {wait}s before retry...", flush=True)
                        time.sleep(wait)
                        continue
                    # All retries exhausted — proceed with warning, cannot determine ref safety
                    logging.warning(
                        f"PREFLIGHT [{tag}]: all {_retry_on_net + 1} network retries exhausted — "
                        "assuming OK, cannot confirm ref safety (network issue)"
                    )
                    print(
                        f"  {_YELLOW}[PREFLIGHT]{_RESET} {tag}: network retries exhausted — "
                        f"assuming OK (cannot confirm due to connection issues)", flush=True
                    )
                    return True

                # Other non-censorship, non-network error
                print(f"  {_YELLOW}[PREFLIGHT]{_RESET} {tag} {len(refs_subset)} ref(s): {names}  → error ({elapsed}s): {err_str[:80]}", flush=True)
                logging.warning(f"PREFLIGHT [{tag}]: non-censorship error — {_exc[0]}")
                if len(refs_subset) == 1:
                    # Single ref with any non-network 500 → treat as blocked;
                    # API sometimes returns truncated error instead of full "invalid argument"
                    logging.warning(f"PREFLIGHT [{tag}]: single ref non-network error — treating as BLOCKED for safety")
                    return False
                return True

        print(f"\n{'─'*60}")
        print(f"  {_YELLOW}[PREFLIGHT]{_RESET} Testing {len(ref_images)} banana_ref reference(s)...")
        print(f"{'─'*60}", flush=True)
        logging.info(f"PREFLIGHT banana_ref: testing {len(ref_images)} refs")

        if not _banana_ref_ok(ref_images, label='ALL'):
            print(f"\n  {_RED}[PREFLIGHT]{_RESET} BLOCKED — binary search for bad ref(s)...")
            logging.warning("PREFLIGHT banana_ref: BLOCKED — isolating via binary search")

            def _isolate_banana(refs_list, offset=0):
                if len(refs_list) == 0:
                    return []
                if len(refs_list) == 1:
                    lbl = f"single: {refs_list[0].get('name', '?')}"
                    return [offset] if not _banana_ref_ok(refs_list, label=lbl) else []
                mid = len(refs_list) // 2
                bad = []
                if not _banana_ref_ok(refs_list[:mid], label=f"left {offset+1}–{offset+mid}"):
                    bad.extend(_isolate_banana(refs_list[:mid], offset))
                if not _banana_ref_ok(refs_list[mid:], label=f"right {offset+mid+1}–{offset+len(refs_list)}"):
                    bad.extend(_isolate_banana(refs_list[mid:], offset + mid))
                return bad

            # Ремикс через Kie.ai — до 2 раундов: бинарный поиск → ремикс → ретест
            from remix import remix_ref
            effective_ref_dir_path = Path(effective_ref_dir)

            for _remix_round in range(1, 3):
                _rnd_sfx = f" (round {_remix_round})" if _remix_round > 1 else ""
                bad_idxs = _isolate_banana(ref_images)
                bad_names = [ref_images[i].get('name', f'ref_{i}') for i in bad_idxs]
                print(f"\n  {_RED}[PREFLIGHT]{_RESET} Bad refs identified{_rnd_sfx}: {bad_names}")
                logging.warning(f"PREFLIGHT banana_ref{_rnd_sfx}: bad refs: {bad_names}")

                if not bad_idxs:
                    # Binary search found no bad refs — initial ALL failure was transient (reCAPTCHA, fluke).
                    print(f"  {_GREEN}[PREFLIGHT]{_RESET} No bad refs found individually — transient error. Continuing with original refs.")
                    logging.info("PREFLIGHT banana_ref: bad_idxs empty — transient error in ALL test, continuing")
                    break

                remixed_any = False
                for idx in bad_idxs:
                    ref_name = ref_images[idx].get('name', '')
                    orig_file = None
                    for ext in ('.jpg', '.jpeg', '.png', '.webp'):
                        candidate = effective_ref_dir_path / (ref_name + ext)
                        if candidate.exists():
                            orig_file = candidate
                            break
                    if orig_file is None:
                        logging.warning(f"PREFLIGHT: could not find file for ref '{ref_name}'")
                        print(f"  {_YELLOW}[PREFLIGHT]{_RESET} File not found for ref '{ref_name}' — skipping remix")
                        continue
                    try:
                        remix_ref(str(orig_file), str(orig_file))
                        remixed_any = True
                        logging.info(f"PREFLIGHT banana_ref{_rnd_sfx}: Kie.ai remixed {orig_file.name}")
                    except Exception as e:
                        logging.error(f"PREFLIGHT banana_ref{_rnd_sfx}: Kie.ai remix failed for {orig_file.name}: {e}")
                        print(f"  {_RED}[PREFLIGHT]{_RESET} Kie.ai remix failed for {orig_file.name}: {e}")

                if not remixed_any:
                    logging.error("PREFLIGHT banana_ref: no refs could be remixed (Kie.ai unavailable?) — stopping")
                    raise RuntimeError(
                        "PREFLIGHT FAILED: reference images are blocked and Kie.ai remix is unavailable.\n"
                        "Generation stopped — without refs the character will not match.\n"
                        "Fix: check KIE_AI_API_KEY in .env, replace blocked ref images, or switch to banana/imagen mode."
                    )

                retest_label = f"ALL (remixed r{_remix_round})"
                print(f"\n  {_YELLOW}[PREFLIGHT]{_RESET} Re-testing with remixed refs{_rnd_sfx}...")
                ref_images = _load_ref_images(effective_ref_dir)
                if _banana_ref_ok(ref_images, label=retest_label):
                    print(f"  {_GREEN}[PREFLIGHT]{_RESET} OK after Kie.ai remix{_rnd_sfx} — continuing with remixed refs")
                    logging.info(f"PREFLIGHT banana_ref: OK after remix{_rnd_sfx}")
                    break
                elif _remix_round < 2:
                    logging.warning(f"PREFLIGHT: still blocked after round {_remix_round} — starting round {_remix_round + 1} binary search")
                    print(f"\n  {_RED}[PREFLIGHT]{_RESET} Still blocked after round {_remix_round} — starting round {_remix_round + 1} binary search...")
                else:
                    logging.error("PREFLIGHT banana_ref: still blocked after 2 Kie.ai remix rounds — stopping")
                    raise RuntimeError(
                        "PREFLIGHT FAILED: reference images are blocked by censorship even after 2 Kie.ai remix rounds.\n"
                        "Generation stopped — without refs the character will not match.\n"
                        "Fix: replace blocked ref images manually, or switch to banana/imagen mode."
                    )
        else:
            pass  # OK — уже распечатано в _banana_ref_ok

        print(f"{'─'*60}\n", flush=True)

    # ------------------------------------------------------------------
    # 4. Генерация с retry-loop
    # ------------------------------------------------------------------
    accumulated_ok: Dict[int, Dict] = {}
    pending_prompts = dict(all_prompts)

    cycle_num = 0
    start_total = time.time()

    # Shared running-average stats across all cycles (thread-safe)
    _ok_run = {'n': 0, 'total': 0.0, 'lock': threading.Lock(), 'wall_start': time.time()}

    while True:
        cycle_num += 1
        cycle_ids = sorted(pending_prompts.keys())
        print(f"\n  [Cycle {cycle_num}] Generating {len(cycle_ids)} images...")

        # Reset worker map для нового цикла (чтобы worker_id начинались с 0)
        with _imggen_worker_lock:
            _imggen_worker_map.clear()
            _imggen_worker_task_count.clear()
            _imggen_worker_counter[0] = 0

        # Семафор на одновременные banana-запросы (single-key: глобальный; multi-key: per-cfg)
        global _banana_submit_sem
        _multi_key = len(clients_cfg) > 1
        if not _multi_key and mode in ('banana', 'banana_ref', 'banana2', 'banana2_ref'):
            _banana_submit_sem = clients_cfg[0]['sem']
        else:
            _banana_submit_sem = None

        _clients_cfg_arg = clients_cfg if _multi_key else None

        cycle_results: List[Dict] = []

        with ThreadPoolExecutor(max_workers=max_parallel) as executor:
            futures = {}
            for cid in cycle_ids:
                future = executor.submit(
                    _generate_single_image,
                    client=clients_cfg[0]['client'],
                    clip_id=cid,
                    prompt=pending_prompts[cid],
                    mode=mode,
                    output_dir=output_dir,
                    aspect_ratio=aspect_ratio,
                    ref_images=ref_images,
                    clients_cfg=_clients_cfg_arg,
                    ok_run=_ok_run,
                )
                futures[future] = cid

            # Спиннер пока воркеры загружают рефы и стартуют (до первого completed)
            _spinner_stop = threading.Event()
            _is_tty = sys.stdout.isatty()
            label = "  [Uploading refs to workers]" if mode == 'banana_ref' else "  [Submitting tasks to workers]"
            if not _is_tty:
                print(f"{label}...", flush=True)
            def _run_spinner():
                frames = ['|', '/', '-', '\\']
                i = 0
                while not _spinner_stop.is_set():
                    sys.stdout.write(f"\r{label} {frames[i % 4]}  ")
                    sys.stdout.flush()
                    i += 1
                    time.sleep(0.15)
                sys.stdout.write("\r" + " " * 60 + "\r")
                sys.stdout.flush()
            spinner_thread = threading.Thread(target=_run_spinner, daemon=True)
            if _is_tty:
                spinner_thread.start()

            _cycle_ok_durs = []
            _cycle_total = len(futures)
            _cycle_done = 0
            if IS_PIPE:
                print(f"  Cycle {cycle_num}: 0/{_cycle_total} imgs", flush=True)
            _tqdm_ctx = tqdm(total=_cycle_total, desc=f"  Cycle {cycle_num}", unit="img", smoothing=0) if not IS_PIPE else None
            pending = dict(futures)  # future -> cid
            try:
                while pending and not _shutdown_event.is_set():
                    done, _ = concurrent.futures.wait(
                        list(pending.keys()),
                        timeout=1.0,
                        return_when=concurrent.futures.FIRST_COMPLETED,
                    )
                    for future in done:
                        cid = pending.pop(future)
                        _spinner_stop.set()
                        try:
                            clip_result = future.result()
                            cycle_results.append(clip_result)
                            icon = '+' if clip_result['status'] == 'ok' else 'X'
                            dur = clip_result.get('duration_sec', 0)
                            if clip_result['status'] == 'ok' and dur > 0:
                                _cycle_ok_durs.append(dur)
                            if _tqdm_ctx:
                                avg_s = f" avg={sum(_cycle_ok_durs)/len(_cycle_ok_durs):.0f}s" if _cycle_ok_durs else ""
                                _tqdm_ctx.set_postfix_str(f"#{cid}: {icon}{avg_s}")
                        except Exception as e:
                            cycle_results.append({
                                'id': cid, 'status': 'error', 'error': str(e),
                                'file': None, 'task_id': None, 'duration_sec': 0,
                            })
                            if _tqdm_ctx:
                                _tqdm_ctx.set_postfix_str(f"#{cid}: X")
                        _cycle_done += 1
                        if _tqdm_ctx:
                            _tqdm_ctx.update(1)
                        if IS_PIPE:
                            print(f"PROGRESS:{_cycle_done}/{_cycle_total}", flush=True)
            except KeyboardInterrupt:
                _shutdown_event.set()
                print(f"\n\n  [CANCELLING] Ctrl+C — sending cancel-all to server...", flush=True)
                for _cc in _active_clients:
                    try:
                        cancelled = _cc.cancel_all_tasks()
                        print(f"  [CANCELLING] {cancelled} task(s) cancelled on server", flush=True)
                    except Exception as e:
                        print(f"  [CANCELLING] cancel-all failed: {e}", flush=True)
                print(f"  [CANCELLING] Stopping workers...\n", flush=True)
            if _shutdown_event.is_set():
                for f in pending:
                    f.cancel()
            if _tqdm_ctx:
                _tqdm_ctx.close()

        if _shutdown_event.is_set():
            break

        # Разбор результатов
        for r in cycle_results:
            if r['status'] == 'ok':
                accumulated_ok[r['id']] = r
                pending_prompts.pop(r['id'], None)

        cycle_ok = sum(1 for r in cycle_results if r['status'] == 'ok')
        failed_ids = sorted(pending_prompts.keys())

        print(f"\n  [Cycle {cycle_num}] OK: {cycle_ok},  still missing: {len(failed_ids)}")

        if not failed_ids:
            break

        # ── Silent mode: авто-ретрай ──────────────────────────────
        if silent:
            if max_cycles is not None:
                # Limited-cycles mode (used as fallback from fastgen.py — no nested FastGen fallback)
                if cycle_num < max_cycles:
                    print(f"\n  {_YELLOW}[SILENT]{_RESET} {len(failed_ids)} images failed, auto-retry ({cycle_num + 1}/{max_cycles})...")
                    logging.info(f"Silent max_cycles={max_cycles}: {len(failed_ids)} failed after cycle {cycle_num}, retrying")
                    continue
                else:
                    print(f"\n  {_YELLOW}[SILENT]{_RESET} {len(failed_ids)} images failed after {cycle_num} cycle(s).")
                    logging.info(f"Silent max_cycles={max_cycles}: stopping after {cycle_num} cycle(s), {len(failed_ids)} still failed")
                    break
            elif cycle_num < 3:
                # Авто-ретрай: до 3 циклов VeoNonStop перед фоллбэком на FastGen
                print(f"\n  {_YELLOW}[SILENT]{_RESET} {len(failed_ids)} images failed, auto-retrying (cycle {cycle_num + 1}/3)...")
                logging.info(f"Silent mode: {len(failed_ids)} failed after cycle {cycle_num}, auto-retrying ({cycle_num + 1}/3)")
                continue
            else:
                # После 3 циклов VeoNonStop — фоллбэк на FastGen.
                # FastGen auto-scans project/ref/ через scan_references() → рефы подхватываются автоматически,
                # персонаж сохраняется даже в banana_ref режиме.
                print(f"\n  {_YELLOW}[SILENT]{_RESET} {len(failed_ids)} images still failed after {cycle_num} cycles.")
                if mode in ('banana_ref', 'banana2_ref'):
                    print(f"  {_YELLOW}[SILENT]{_RESET} {mode} mode: FastGen will auto-load refs from project/ref/")
                    logging.info(f"Silent mode {mode}: falling back to FastGen — refs will be picked up from project/ref/")
                print(f"  {_YELLOW}[SILENT]{_RESET} Falling back to FastGen for remaining {len(failed_ids)} images...")
                logging.info(f"Silent mode: {len(failed_ids)} failed after {cycle_num} cycles, falling back to FastGen")

                MAX_FASTGEN_CYCLES = 3
                fg_remaining = list(failed_ids)

                try:
                    from fastgen import generate_all_images as fastgen_generate

                    for fg_cycle in range(1, MAX_FASTGEN_CYCLES + 1):
                        if not fg_remaining:
                            break
                        print(f"\n  {_YELLOW}[FASTGEN]{_RESET} Cycle {fg_cycle}/{MAX_FASTGEN_CYCLES}: generating {len(fg_remaining)} images...")
                        fg_result = fastgen_generate(
                            project_dir=str(project_path),
                            clip_ids=fg_remaining,
                        )
                        fg_ok = fg_result.get('generated', 0)
                        print(f"  {_GREEN}[FASTGEN]{_RESET} Cycle {fg_cycle}: generated {fg_ok}/{len(fg_remaining)} images")
                        logging.info(f"FastGen fallback cycle {fg_cycle}: {fg_ok}/{len(fg_remaining)}")

                        # Update results
                        if fg_ok > 0:
                            for r in fg_result.get('results', []):
                                rid = r.get('id')
                                if rid and r.get('status') == 'ok':
                                    accumulated_ok[rid] = r
                                    pending_prompts.pop(rid, None)
                                    if rid in fg_remaining:
                                        fg_remaining.remove(rid)

                        # Пересчитываем remaining по файлам (на случай если results неполные)
                        fg_remaining = [cid for cid in fg_remaining
                                        if not any((output_dir / f"{cid:03d}{ext}").exists()
                                                   for ext in ('.png', '.jpg', '.jpeg', '.webp'))]

                        if not fg_remaining:
                            print(f"  {_GREEN}[FASTGEN]{_RESET} All remaining images generated!")
                            break

                        if fg_cycle < MAX_FASTGEN_CYCLES:
                            print(f"  {_YELLOW}[FASTGEN]{_RESET} {len(fg_remaining)} still missing, retrying...")

                    if fg_remaining:
                        print(f"  {_RED}[FASTGEN]{_RESET} {len(fg_remaining)} images still failed after {MAX_FASTGEN_CYCLES} FastGen cycles")
                        logging.warning(f"FastGen fallback: {len(fg_remaining)} still failed after {MAX_FASTGEN_CYCLES} cycles")

                except Exception as e:
                    print(f"  {_RED}[FASTGEN]{_RESET} FastGen fallback failed: {e}")
                    logging.error(f"FastGen fallback failed: {e}")
                break

        # ── Interactive mode: спрашиваем юзера ────────────────────
        print("\n" + "=" * 60)
        print(f"  {_RED}MISSING IMAGES ({len(failed_ids)} total):{_RESET}")
        for cid in failed_ids:
            last_r = next((r for r in reversed(cycle_results) if r['id'] == cid), None)
            err = (last_r.get('error', '') if last_r else '')[:80]
            prompt_short = pending_prompts.get(cid, '')[:90].replace('\n', ' ')
            print(f"  #{cid:03d}: {prompt_short}")
            if err:
                print(f"         err: {err}")
        print("=" * 60)

        print(f"\n  {_YELLOW}What would you like to do?{_RESET}")
        print(f"    [1] Retry missing images ({len(failed_ids)})")
        print(f"    [2] Finish — skip failed")
        print(f"    [3] Edit prompt manually and retry")
        print()

        while True:
            choice = input("  Select [1/2/3]: ").strip()
            if choice in ('1', '2', '3'):
                break
            print("  Enter 1, 2 or 3")

        if choice == '2':
            failed_ids = []
            break

        if choice == '3':
            # Ручной ввод промпта для каждого пропущенного клипа
            for cid in list(failed_ids):
                old_prompt = pending_prompts.get(cid, '')
                print(f"\n  {_YELLOW}--- Clip #{cid:03d} ---{_RESET}")
                print(f"  Current prompt:")
                print(f"    {old_prompt[:200]}")
                print()
                new_text = input("  New prompt (Enter = keep current, 's' = skip this clip): ").strip()
                if new_text.lower() == 's':
                    failed_ids.remove(cid)
                    pending_prompts.pop(cid, None)
                    print(f"  #{cid:03d} skipped")
                elif new_text:
                    pending_prompts[cid] = new_text
                    print(f"  #{cid:03d} prompt updated")
                else:
                    print(f"  #{cid:03d} keeping current prompt")

        if not failed_ids:
            break

    # ------------------------------------------------------------------
    # 5. Итоги
    # ------------------------------------------------------------------
    elapsed_total = round(time.time() - start_total, 1)
    total_ok = len(accumulated_ok)
    total_failed = len(pending_prompts)

    print("\n" + "=" * 60)
    print(f"  IMGGEN COMPLETE")
    print(f"  Generated: {total_ok}")
    print(f"  Failed:    {total_failed}")
    print(f"  Skipped:   {len(skipped)}")
    print(f"  Total time: {elapsed_total}s")
    print(f"  Output: {output_dir}")
    print("=" * 60)

    logging.info(f"=== imggen complete: {total_ok} ok, {total_failed} failed, {elapsed_total}s ===")

    logging.getLogger().removeHandler(file_handler)
    file_handler.close()

    if threading.current_thread() is threading.main_thread() and _old_sigint is not None:
        signal.signal(signal.SIGINT, _old_sigint)
    _active_client[0] = None
    _active_clients.clear()

    return {
        'generated': total_ok,
        'failed': total_failed,
        'skipped': len(skipped),
        'elapsed_sec': elapsed_total,
        'results': list(accumulated_ok.values()),
    }


# ======================================================================
# CLI
# ======================================================================

if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='VeoNonStop image generation (Imagen/Banana)')
    parser.add_argument('--dir', required=True, help='Project directory')
    parser.add_argument('--mode', choices=['imagen', 'banana', 'banana_ref'], default='imagen')
    parser.add_argument('--parallel', type=int, default=None)
    parser.add_argument('--ratio', default=None, help='Aspect ratio (16:9, 9:16, 1:1)')
    parser.add_argument('--ids', default=None, help='Comma-separated clip IDs')
    parser.add_argument('--ref-dir', default=None, help='Style reference images directory')
    parser.add_argument('--silent', action='store_true', help='Silent mode: auto-retry + FastGen fallback')

    args = parser.parse_args()

    clip_ids = None
    if args.ids:
        clip_ids = [int(x.strip()) for x in args.ids.split(',')]

    logging.basicConfig(level=logging.DEBUG, format=config.LOG_FORMAT)

    try:
        result = generate_all_images(
            project_dir=args.dir,
            mode=args.mode,
            max_parallel=args.parallel,
            clip_ids=clip_ids,
            aspect_ratio=args.ratio,
            ref_dir=args.ref_dir,
            silent=args.silent,
        )
        sys.exit(0 if result['failed'] == 0 else 1)
    except Exception as e:
        print(f"\n  {_RED}ERROR:{_RESET} {e}")
        logging.exception("imggen failed")
        sys.exit(1)
