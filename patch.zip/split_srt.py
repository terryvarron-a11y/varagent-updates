"""split_srt.py — splits SRT phrases to <= MAX_LEN chars with proportional timecodes"""
import sys
import re

MAX_LEN = int(sys.argv[4]) if len(sys.argv) > 4 else 50
src  = sys.argv[1]
dst  = sys.argv[2]
txto = sys.argv[3]


def parse_ms(s):
    h, m, rest = s.split(':')
    sec, ms = re.split('[,.]', rest)
    return int(h)*3600000 + int(m)*60000 + int(sec)*1000 + int(ms)


def fmt_ms(ms):
    h = ms // 3600000; ms %= 3600000
    m = ms // 60000;   ms %= 60000
    s = ms // 1000;    ms %= 1000
    return f'{h:02d}:{m:02d}:{s:02d},{ms:03d}'


def split_text(text, max_len):
    words = text.split()
    chunks, cur = [], ''
    for w in words:
        test = (cur + ' ' + w).strip()
        if len(test) <= max_len:
            cur = test
        else:
            if cur:
                chunks.append(cur)
            cur = w
    if cur:
        chunks.append(cur)
    return chunks if chunks else [text]


def distribute(t0, t1, chunks):
    total = sum(len(c) for c in chunks)
    dur = t1 - t0
    out, t = [], t0
    for i, c in enumerate(chunks):
        end = t1 if i == len(chunks) - 1 else t + round(dur * len(c) / total)
        out.append((t, end))
        t = end
    return out


text = open(src, encoding='utf-8-sig').read()
blocks = [b.strip() for b in re.split(r'\n{2,}', text) if b.strip()]

srt_blocks = []
txt_lines  = []
idx = 1
for b in blocks:
    lines = b.splitlines()
    if len(lines) < 2:
        continue
    tc_line = next((l for l in lines if '-->' in l), None)
    if not tc_line:
        continue
    tc_idx = lines.index(tc_line)
    t0_str, t1_str = [s.strip() for s in tc_line.split('-->')]
    t0, t1 = parse_ms(t0_str), parse_ms(t1_str)
    phrase = ' '.join(lines[tc_idx + 1:]).strip()
    if not phrase:
        continue

    chunks = split_text(phrase, MAX_LEN)
    times  = distribute(t0, t1, chunks)
    for chunk, (s, e) in zip(chunks, times):
        srt_blocks.append(f'{idx}\n{fmt_ms(s)} --> {fmt_ms(e)}\n{chunk}')
        txt_lines.append(chunk)
        idx += 1

srt_content = '\n\n'.join(srt_blocks) + '\n'
open(dst,  'w', encoding='utf-8-sig').write(srt_content)
open(txto, 'w', encoding='utf-8-sig').write(srt_content)
print(f'OK: {idx - 1} blocks written.')
