#!/usr/bin/env python3
"""
VarAgent GUI — Visual Pipeline Manager
=======================================
Tab 1: Pipeline Launcher (replaces pipeline.bat)
Tab 2: Control Panel (project browser + .env editor)
Tab 3: VeoNonStop Generator (standalone generation)
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext, simpledialog
import threading
import re
import requests
import base64
import os
import sys
import subprocess
import importlib
import json
import time
import queue
import shutil
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from contextlib import contextmanager
from typing import Optional, List, Dict, Any

# ============ PATH SETUP ============
SCRIPT_DIR = Path(__file__).resolve().parent
AGENT_DIR = SCRIPT_DIR / 'agent'
AGENT_ENV_FILE = AGENT_DIR / '.env'
sys.path.insert(0, str(AGENT_DIR))
os.chdir(str(SCRIPT_DIR))

if sys.platform == 'win32':
    os.system('chcp 65001 >nul')

# Suppress tqdm in GUI mode
os.environ['TQDM_DISABLE'] = '1'

import config

# ============ COLORS ============
COLORS = {
    'bg_dark': '#181825',
    'bg_card': '#222236',
    'bg_input': '#2e2e44',
    'border': '#2d2d3a',
    'text': '#e8e8f2',
    'text_dim': '#a0a0b8',
    'text_muted': '#707088',
    'accent': '#7c5cfc',
    'accent_hover': '#9d7eff',
    'yellow': '#f5c842',
    'green': '#34d399',
    'orange': '#fb923c',
    'red': '#f87171',
    'blue': '#60a5fa',
    'cyan': '#22d3ee',
}

# Font sizes — bump for better readability on HiDPI
FONT_MAIN = ("Segoe UI", 11)
FONT_MAIN_BOLD = ("Segoe UI", 11, "bold")
FONT_DIM = ("Segoe UI", 10)
FONT_HEADER = ("Segoe UI", 18, "bold")
FONT_SECTION = ("Segoe UI", 12, "bold")
FONT_BUTTON = ("Segoe UI", 11, "bold")
FONT_LOG = ("Consolas", 10)
FONT_TAB = ("Segoe UI", 11, "bold")

# Display name → API model_key mapping
FASTGEN_MODELS = [
    ("Banana Pro", "GEM_PIX_2"),
    ("Banana 2", "NARWHAL"),
    ("Gemini", "GEMINI"),
    ("Grok", "GROK"),
    ("Imagen 4", "IMAGEN_3_5"),
    ("Banana", "GEM_PIX"),
]
FASTGEN_DISPLAY = [m[0] for m in FASTGEN_MODELS]
FASTGEN_NAME_TO_KEY = {m[0]: m[1] for m in FASTGEN_MODELS}
FASTGEN_KEY_TO_NAME = {m[1]: m[0] for m in FASTGEN_MODELS}

BANANA_MODELS = [("Banana Pro", "GEM_PIX_2"), ("Banana 2", "NARWHAL")]
BANANA_DISPLAY = [m[0] for m in BANANA_MODELS]
BANANA_NAME_TO_KEY = {m[0]: m[1] for m in BANANA_MODELS}
BANANA_KEY_TO_NAME = {m[1]: m[0] for m in BANANA_MODELS}

_GEMINI_MODEL_OPTS = [
    "gemini-2.5-pro", "gemini-2.5-flash",
    "gemini-3-pro-preview", "gemini-3.1-pro-preview",
    "gemini-2.0-flash-exp",
]
_FASTGEN_MODEL_OPTS = [
    "GEM_PIX_2 — Banana Pro",
    "NARWHAL — Banana 2",
    "GEMINI — Gemini",
    "GROK — Grok",
    "GEM_PIX — Banana",
    "IMAGEN_3_5 — Imagen 4",
]

ENV_DROPDOWN_OPTIONS: dict = {
    # AssemblyAI
    "ASSEMBLYAI_LANGUAGE_CODE":   ["ru", "en", "es", "de", "fr", "it", "pl", "pt", "zh", "ja", "ko", "uk", "tr", "ar"],
    "ASSEMBLYAI_SPEECH_MODELS":   ["universal-3-pro,universal-2", "universal-3-pro", "universal-2"],
    "ASSEMBLYAI_SEGMENTATION_MODE": ["words", "sentences", "paragraphs"],
    # Gemini director
    "GEMINI_MODEL":               _GEMINI_MODEL_OPTS,
    "GEMINI_THINKING_LEVEL":      ["low", "medium", "high"],
    "GEMINI_THINKING_LEVEL_PASS2": ["low", "medium", "high"],
    "GEMINI_TWO_PASS":            ["false", "true"],
    "GENERATE_DIRECTOR_ANALYSIS": ["false", "true"],
    # TTS
    "TTS_SERVICE":                ["mat3u", "csv666"],
    "TTS_MAT3U_MODEL_ID":         ["eleven_multilingual_v2", "eleven_v3", "eleven_turbo_v2_5",
                                   "eleven_turbo_v2", "eleven_flash_v2_5", "eleven_flash_v2"],
    "TTS_MAT3U_SPLIT_TYPE":       ["smart", "sentences", "paragraphs", "max_length"],
    "TTS_MAT3U_SPLIT_OUTPUT":     ["false", "true"],
    "TTS_MAT3U_AUTO_PAUSE_ENABLED": ["false", "true"],
    "TTS_CSV666_OUTPUT_FORMAT":   ["mp3", "zip"],
    # FastGen
    "FASTGEN_MODEL":              _FASTGEN_MODEL_OPTS,
    "FASTGEN_ASPECT_RATIO":       ["landscape", "portrait", "square"],
    # VeoNonStop
    "VEONONSTOP_ASPECT_RATIO":    ["16:9", "9:16", "1:1", "4:3", "3:4"],
    "VEONONSTOP_IMGGEN_MODE":     ["banana", "banana+ref", "imagen"],
    "VEONONSTOP_BANANA_MODEL":    [
        "GEM_PIX_2 — Banana Pro",
        "NARWHAL — Banana 2",
    ],
    "VEONONSTOP_REQUEST_DELAY":   ["0.5", "1.0", "2.0", "3.0", "5.0", "10.0"],
    # Pipeline defaults
    "PIPELINE_IMG_GEN":           ["veononstop", "fastgen", "skip"],
    # YT Packer
    "YT_PACK_MODEL":              _GEMINI_MODEL_OPTS,
    "YT_PACK_TRANSLATE_MODEL":    _GEMINI_MODEL_OPTS,
    "YT_PACK_CONTENT_MODEL":      _GEMINI_MODEL_OPTS,
    "YT_PACK_COVER_MODEL":        _FASTGEN_MODEL_OPTS,
    "YT_PACK_SUBTITLES":          ["false", "true"],
    "YT_PACK_DESCRIPTION":        ["false", "true"],
    "YT_PACK_COVERS":             ["false", "true"],
    "YT_PACK_LANGUAGES":          ["ru,en", "en,ru", "ru", "en", "es", "de", "fr"],
}

BASE_URL = "https://veononstop.org/api/v1"
REQUEST_TIMEOUT = 180
VIDEO_POLL_INTERVAL = 5
IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.webp'}


# ============ STDOUT CAPTURE ============

class LogRedirector:
    """Redirects sys.stdout to a log queue for GUI display."""
    def __init__(self, log_queue, tab_target, original):
        self.log_queue = log_queue
        self.tab_target = tab_target
        self.original = original
        self.buffer = ""

    def write(self, text):
        self.original.write(text)
        self.buffer += text
        while '\n' in self.buffer:
            line, self.buffer = self.buffer.split('\n', 1)
            if line.strip():
                level = 'INFO'
                low = line.lower()
                if any(x in low for x in ['error', 'fail', 'traceback']):
                    level = 'ERROR'
                elif any(x in low for x in ['[ok]', 'success', 'complete', 'saved']):
                    level = 'SUCCESS'
                elif any(x in low for x in ['warn', 'skip', 'retry']):
                    level = 'WARNING'
                self.log_queue.put((line.rstrip(), level, None, self.tab_target))

    def flush(self):
        self.original.flush()


@contextmanager
def capture_stdout(log_queue, tab_target):
    old_out = sys.stdout
    old_err = sys.stderr
    redir = LogRedirector(log_queue, tab_target, old_out)
    sys.stdout = redir
    sys.stderr = redir
    try:
        yield
    finally:
        sys.stdout = old_out
        sys.stderr = old_err


def _image_to_base64(filepath):
    """Load image file as base64 + detect MIME type."""
    ext = Path(filepath).suffix.lower()
    mime_map = {'.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp'}
    mime = mime_map.get(ext, 'image/png')
    with open(filepath, 'rb') as f:
        b64 = base64.b64encode(f.read()).decode('utf-8')
    return b64, mime


def get_output_dir():
    output_dir = SCRIPT_DIR / "veononstop_output"
    try:
        output_dir.mkdir(exist_ok=True)
        return output_dir
    except PermissionError:
        fallback = Path.home() / "veononstop_output"
        fallback.mkdir(exist_ok=True)
        return fallback


# ════════════════════════════════════════════════════════════════════
# MAIN APPLICATION
# ════════════════════════════════════════════════════════════════════

class VarAgentGUI:
    """Main application: window, theme, Notebook, shared log queue."""

    def __init__(self, root):
        self.root = root
        self.root.title("VarAgent — Video Production Pipeline")
        self.root.geometry("1300x950")
        self.root.configure(bg=COLORS['bg_dark'])
        self.root.minsize(1100, 800)

        self.log_queue = queue.Queue()
        self.setup_styles()

        # Notebook with 4 tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.tab_pipeline = PipelineLauncherTab(self.notebook, self)
        self.tab_control = ControlPanelTab(self.notebook, self)
        self.tab_veo = VeoGeneratorTab(self.notebook, self)
        self.tab_settings = SettingsTab(self.notebook, self)
        self.tab_prompts = PromptsTab(self.notebook, self)
        self.tab_donate = DonateTab(self.notebook, self)

        self.notebook.add(self.tab_pipeline.frame, text="  Pipeline  ")
        self.notebook.add(self.tab_control.frame, text="  Control Panel  ")
        self.notebook.add(self.tab_veo.frame, text="  VeoNonStop  ")
        self.notebook.add(self.tab_settings.frame, text="  Settings  ")
        self.notebook.add(self.tab_prompts.frame, text="  Prompts  ")
        self.notebook.add(self.tab_donate.frame, text="  Donate  ")

        self.process_log_queue()

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure("TFrame", background=COLORS['bg_dark'])
        style.configure("Card.TFrame", background=COLORS['bg_card'])
        style.configure("TLabel", background=COLORS['bg_dark'],
                        foreground=COLORS['text'], font=FONT_MAIN)
        style.configure("Card.TLabel", background=COLORS['bg_card'],
                        foreground=COLORS['text'], font=FONT_MAIN)
        style.configure("Dim.TLabel", background=COLORS['bg_card'],
                        foreground=COLORS['text_dim'], font=FONT_DIM)
        style.configure("Header.TLabel", font=FONT_HEADER,
                        foreground=COLORS['accent'], background=COLORS['bg_dark'])
        style.configure("Section.TLabel", font=FONT_SECTION,
                        foreground=COLORS['accent'], background=COLORS['bg_card'])
        style.configure("Stats.TLabel", font=FONT_MAIN_BOLD,
                        background=COLORS['bg_card'])
        # Buttons — dark theme with readable hover
        style.configure("TButton", background=COLORS['bg_card'],
                        foreground=COLORS['text'], font=FONT_MAIN, padding=6,
                        borderwidth=1, relief="flat")
        style.map("TButton",
                  background=[("active", COLORS['accent']),
                              ("pressed", COLORS['accent']),
                              ("disabled", COLORS['border'])],
                  foreground=[("active", "#ffffff"),
                              ("pressed", "#ffffff"),
                              ("disabled", COLORS['text_muted'])])
        style.configure("Accent.TButton", font=FONT_BUTTON, padding=8,
                        background=COLORS['accent'], foreground="#ffffff")
        style.map("Accent.TButton",
                  background=[("active", COLORS['accent_hover']),
                              ("pressed", COLORS['accent']),
                              ("disabled", COLORS['border'])],
                  foreground=[("active", "#ffffff"),
                              ("pressed", "#ffffff"),
                              ("disabled", COLORS['text_muted'])])
        style.configure("TCombobox", fieldbackground=COLORS['bg_input'],
                        background=COLORS['bg_input'],
                        foreground=COLORS['text'],
                        arrowcolor=COLORS['text_dim'],
                        borderwidth=0, relief="flat")
        style.map("TCombobox",
                  fieldbackground=[("readonly", COLORS['bg_input'])],
                  foreground=[("readonly", COLORS['text'])])
        style.configure("TRadiobutton", background=COLORS['bg_card'],
                        foreground=COLORS['text'], font=FONT_MAIN)
        style.map("TRadiobutton",
                  background=[("active", COLORS['bg_card'])],
                  foreground=[("active", COLORS['accent'])])
        style.configure("TCheckbutton", background=COLORS['bg_card'],
                        foreground=COLORS['text'], font=FONT_MAIN)
        style.map("TCheckbutton",
                  background=[("active", COLORS['bg_card'])],
                  foreground=[("active", COLORS['accent'])])
        style.configure("Green.Horizontal.TProgressbar",
                        troughcolor=COLORS['bg_input'],
                        background=COLORS['green'], thickness=8)
        style.configure("Custom.Horizontal.TProgressbar",
                        troughcolor=COLORS['bg_input'],
                        background=COLORS['accent'], thickness=8)
        # Notebook tab styling
        style.configure("TNotebook", background=COLORS['bg_dark'], borderwidth=0)
        style.configure("TNotebook.Tab", background=COLORS['bg_card'],
                        foreground=COLORS['text_dim'], font=FONT_TAB,
                        padding=[14, 7])
        style.map("TNotebook.Tab",
                  background=[("selected", COLORS['accent'])],
                  foreground=[("selected", "#ffffff")])

    def process_log_queue(self):
        try:
            for _ in range(50):  # batch up to 50 messages per tick
                message, level, thread_id, tab = self.log_queue.get_nowait()
                self._route_log(message, level, thread_id, tab)
        except queue.Empty:
            pass
        self.root.after(100, self.process_log_queue)

    def _route_log(self, message, level, thread_id, tab_target):
        """Route log message to the correct tab's log widget."""
        if tab_target == "pipeline" and hasattr(self.tab_pipeline, 'log_widget'):
            self._write_log(self.tab_pipeline.log_widget, message, level, thread_id)
        elif tab_target == "control" and hasattr(self.tab_control, 'log_widget'):
            self._write_log(self.tab_control.log_widget, message, level, thread_id)
        elif tab_target == "veo" and hasattr(self.tab_veo, 'log_widget'):
            self._write_log(self.tab_veo.log_widget, message, level, thread_id)

    def _write_log(self, widget, message, level, thread_id=None):
        ts = datetime.now().strftime("%H:%M:%S")
        prefix = {"INFO": "", "SUCCESS": "[OK]", "ERROR": "[ERR]", "WARNING": "[WARN]"}.get(level, "")
        thread_str = f"[T{thread_id}] " if thread_id is not None else ""
        tag = level.lower() if level.lower() in ("success", "error", "warning", "info") else ""
        widget.insert(tk.END, f"[{ts}] {thread_str}{prefix} {message}\n", tag)
        if getattr(widget, '_autoscroll', True):
            widget.see(tk.END)

    def log(self, message, level="INFO", thread_id=None, tab="pipeline"):
        self.log_queue.put((message, level, thread_id, tab))

    @staticmethod
    def create_card(parent, title=None):
        card = ttk.Frame(parent, style="Card.TFrame", padding=12)
        card.pack(fill=tk.X, pady=4, padx=2)
        if title:
            ttk.Label(card, text=title, style="Section.TLabel").pack(anchor=tk.W)
        return card

    @staticmethod
    def create_log_widget(parent):
        log = scrolledtext.ScrolledText(parent, height=12, bg=COLORS['bg_input'],
                                        fg=COLORS['text'], font=FONT_LOG,
                                        insertbackground=COLORS['text'], relief=tk.FLAT,
                                        borderwidth=0, wrap=tk.WORD, spacing3=2)
        log.pack(fill=tk.BOTH, expand=True, pady=(4, 0))
        log.tag_configure("success", foreground=COLORS['green'])
        log.tag_configure("error", foreground=COLORS['red'])
        log.tag_configure("warning", foreground=COLORS['orange'])
        log.tag_configure("info", foreground=COLORS['blue'])
        # Double-click toggles auto-scroll: first double-click pauses, second resumes and jumps to bottom
        log._autoscroll = True
        def _toggle_autoscroll(event):
            log._autoscroll = not log._autoscroll
            if log._autoscroll:
                log.see(tk.END)
        log.bind("<Double-Button-1>", _toggle_autoscroll)
        log.bind("<Button-1>", lambda e: log.focus_set())
        def _copy_selection(event):
            try:
                sel = log.selection_get()
                log.clipboard_clear()
                log.clipboard_append(sel)
            except tk.TclError:
                pass
            return "break"
        log.bind("<Control-c>", _copy_selection)
        log.bind("<Control-C>", _copy_selection)
        return log


# ════════════════════════════════════════════════════════════════════
# TAB 1: PIPELINE LAUNCHER
# ════════════════════════════════════════════════════════════════════

class PipelineLauncherTab:
    """Replaces pipeline.bat — visual form for all pipeline settings."""

    def __init__(self, notebook, app: VarAgentGUI):
        self.app = app
        self.root = app.root
        self.frame = ttk.Frame(notebook)
        self.is_running = False

        # Variables (defaults from config)
        self.start_point    = tk.StringVar(value=config.PIPELINE_START_POINT)
        self.language       = tk.StringVar(value=config.ASSEMBLYAI_LANGUAGE_CODE)
        self.direction_mode = tk.StringVar(value="2-pass" if config.GEMINI_TWO_PASS else "1-pass")
        self.clip_mode      = tk.StringVar(value=config.PIPELINE_CLIP_MODE)
        self.clip_min       = tk.IntVar(value=config.VIDEO_CLIP_MIN_DURATION)
        self.clip_max       = tk.IntVar(value=config.VIDEO_CLIP_MAX_DURATION)
        self.img_gen        = tk.StringVar(value=config.PIPELINE_IMG_GEN)
        self.fastgen_model  = tk.StringVar(value=FASTGEN_KEY_TO_NAME.get(config.FASTGEN_MODEL, config.FASTGEN_MODEL))
        self.fastgen_aspect = tk.StringVar(value=config.FASTGEN_ASPECT_RATIO)
        self.fastgen_parallel = tk.IntVar(value=config.FASTGEN_MAX_PARALLEL)
        self.fastgen_api_key  = tk.StringVar(value='main')
        self.veo_imggen_mode  = tk.StringVar(value=config.VEONONSTOP_IMGGEN_MODE)
        self.veo_banana_model = tk.StringVar(value=BANANA_KEY_TO_NAME.get(config.VEONONSTOP_BANANA_MODEL, "Banana Pro"))
        self.video_mode     = tk.StringVar(value=config.PIPELINE_VIDEO_MODE)
        self.veo_ratio      = tk.StringVar(value=config.VEONONSTOP_ASPECT_RATIO)
        self.veo_parallel   = tk.IntVar(value=config.VEONONSTOP_MAX_PARALLEL)
        self.veo_request_delay = tk.DoubleVar(value=config.VEONONSTOP_REQUEST_DELAY)
        self.prompt_mode    = tk.StringVar(value=config.PIPELINE_PROMPT_MODE)
        self.intro_duration = tk.IntVar(value=config.INTRO_BLOCK_DURATION)
        self.intro_clip_min = tk.IntVar(value=config.INTRO_CLIP_MIN_DURATION)
        self.intro_clip_max = tk.IntVar(value=config.INTRO_CLIP_MAX_DURATION)
        self.render_mode    = tk.StringVar(value=config.PIPELINE_RENDER_MODE)
        self.watermark      = tk.StringVar(value=config.PIPELINE_WATERMARK)
        self.keep_files     = tk.BooleanVar(value=config.PIPELINE_KEEP_FILES)
        self.keep_veo_sound = tk.BooleanVar(value=getattr(config, 'PIPELINE_KEEP_VEO_SOUND', False))
        self.script_type_var  = tk.StringVar(value="prose")
        self.ref_images: list[Path] = []
        self.logo_path: Optional[Path] = None
        self.single_prompt_path: Optional[Path] = None
        self.yt_pack_enabled    = tk.BooleanVar(value=False)
        self.yt_pack_languages  = tk.StringVar(value=getattr(config, 'YT_PACK_LANGUAGES', 'ru,en') if not isinstance(getattr(config, 'YT_PACK_LANGUAGES', ''), list) else ','.join(config.YT_PACK_LANGUAGES))
        self.yt_pack_subtitles  = tk.BooleanVar(value=bool(getattr(config, 'YT_PACK_SUBTITLES', True)))
        self.yt_pack_description = tk.BooleanVar(value=bool(getattr(config, 'YT_PACK_DESCRIPTION', True)))
        self.yt_pack_covers     = tk.BooleanVar(value=bool(getattr(config, 'YT_PACK_COVERS', True)))

        self.create_ui()

    def _defaults_map(self):
        """Возвращает {ключ: tk.Variable} для сохранения/загрузки дефолтов."""
        return {
            'start_point':       self.start_point,
            'language':          self.language,
            'direction_mode':    self.direction_mode,
            'clip_mode':         self.clip_mode,
            'clip_min':          self.clip_min,
            'clip_max':          self.clip_max,
            'img_gen':           self.img_gen,
            'fastgen_model':     self.fastgen_model,
            'fastgen_aspect':    self.fastgen_aspect,
            'fastgen_parallel':  self.fastgen_parallel,
            'fastgen_api_key':   self.fastgen_api_key,
            'veo_imggen_mode':   self.veo_imggen_mode,
            'veo_banana_model':  self.veo_banana_model,
            'video_mode':        self.video_mode,
            'veo_ratio':         self.veo_ratio,
            'veo_parallel':      self.veo_parallel,
            'veo_request_delay': self.veo_request_delay,
            'prompt_mode':       self.prompt_mode,
            'render_mode':       self.render_mode,
            'watermark':         self.watermark,
            'keep_files':        self.keep_files,
            'keep_veo_sound':    self.keep_veo_sound,
            'intro_duration':    self.intro_duration,
            'intro_clip_min':    self.intro_clip_min,
            'intro_clip_max':    self.intro_clip_max,
            'yt_pack_enabled':   self.yt_pack_enabled,
            'yt_pack_languages': self.yt_pack_languages,
            'yt_pack_subtitles': self.yt_pack_subtitles,
            'yt_pack_description': self.yt_pack_description,
            'yt_pack_covers':    self.yt_pack_covers,
        }

    def _save_defaults(self):
        """Сохраняет текущие настройки пайплайна в agent/.env"""
        d = {k: v.get() for k, v in self._defaults_map().items()}

        def _b(val): return 'true' if val else 'false'

        updates = {
            'PIPELINE_START_POINT':      str(d['start_point']),
            'ASSEMBLYAI_LANGUAGE_CODE':  str(d['language']),
            'GEMINI_TWO_PASS':           'true' if d['direction_mode'] == '2-pass' else 'false',
            'PIPELINE_CLIP_MODE':        str(d['clip_mode']),
            'VIDEO_CLIP_MIN_DURATION':   str(d['clip_min']),
            'VIDEO_CLIP_MAX_DURATION':   str(d['clip_max']),
            'PIPELINE_IMG_GEN':          str(d['img_gen']),
            'FASTGEN_MODEL':             FASTGEN_NAME_TO_KEY.get(d['fastgen_model'], d['fastgen_model']),
            'FASTGEN_ASPECT_RATIO':      str(d['fastgen_aspect']),
            'FASTGEN_MAX_PARALLEL':      str(d['fastgen_parallel']),
            'VEONONSTOP_IMGGEN_MODE':    str(d['veo_imggen_mode']),
            'VEONONSTOP_BANANA_MODEL':   BANANA_NAME_TO_KEY.get(d['veo_banana_model'], 'GEM_PIX_2'),
            'PIPELINE_VIDEO_MODE':       str(d['video_mode']),
            'VEONONSTOP_ASPECT_RATIO':   str(d['veo_ratio']),
            'VEONONSTOP_MAX_PARALLEL':   str(d['veo_parallel']),
            'VEONONSTOP_REQUEST_DELAY':  str(d['veo_request_delay']),
            'PIPELINE_PROMPT_MODE':      str(d['prompt_mode']),
            'PIPELINE_RENDER_MODE':      str(d['render_mode']),
            'PIPELINE_WATERMARK':        str(d['watermark']),
            'PIPELINE_KEEP_FILES':       _b(d['keep_files']),
            'PIPELINE_KEEP_VEO_SOUND':   _b(d['keep_veo_sound']),
            'INTRO_BLOCK_DURATION':      str(d['intro_duration']),
            'INTRO_CLIP_MIN_DURATION':   str(d['intro_clip_min']),
            'INTRO_CLIP_MAX_DURATION':   str(d['intro_clip_max']),
            'YT_PACK_LANGUAGES':         str(d['yt_pack_languages']),
            'YT_PACK_SUBTITLES':         _b(d['yt_pack_subtitles']),
            'YT_PACK_DESCRIPTION':       _b(d['yt_pack_description']),
            'YT_PACK_COVERS':            _b(d['yt_pack_covers']),
        }

        try:
            lines = AGENT_ENV_FILE.read_text(encoding='utf-8').splitlines(keepends=True)
            remaining = set(updates.keys())
            new_lines = []
            for line in lines:
                stripped = line.rstrip('\r\n')
                if '=' in stripped and not stripped.startswith('#'):
                    key = stripped.split('=', 1)[0].strip()
                    if key in updates:
                        eol = '\r\n' if line.endswith('\r\n') else '\n'
                        new_lines.append(f'{key}={updates[key]}{eol}')
                        remaining.discard(key)
                        continue
                new_lines.append(line)
            if remaining:
                eol = '\r\n' if lines and lines[0].endswith('\r\n') else '\n'
                new_lines.append(f'{eol}# Pipeline GUI extras{eol}')
                for key in sorted(remaining):
                    new_lines.append(f'{key}={updates[key]}{eol}')
            AGENT_ENV_FILE.write_text(''.join(new_lines), encoding='utf-8')
            self.app.log("Pipeline defaults saved to .env", "SUCCESS", tab="pipeline")
        except Exception as e:
            self.app.log(f"Failed to save defaults: {e}", "ERROR", tab="pipeline")

    def create_ui(self):
        # Two columns: left = form, right = summary + log
        content = ttk.Frame(self.frame)
        content.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        # LEFT: scrollable settings
        left_outer = ttk.Frame(content)
        left_outer.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 5))

        canvas = tk.Canvas(left_outer, bg=COLORS['bg_dark'], highlightthickness=0, width=420)
        scrollbar = ttk.Scrollbar(left_outer, orient=tk.VERTICAL, command=canvas.yview)
        self.left = ttk.Frame(canvas)
        self.left.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.left, anchor=tk.NW)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        # mousewheel: only active while mouse is inside this canvas
        _mw = lambda e: canvas.yview_scroll(-1 * (e.delta // 120), "units")
        canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", _mw))
        canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))

        # RIGHT: summary + log
        right = ttk.Frame(content)
        right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self._build_form()
        self._build_right(right)

    def _build_form(self):
        # Start Point
        card = self.app.create_card(self.left, "Start Point")
        ttk.Radiobutton(card, text="From audio", variable=self.start_point,
                        value="audio", command=self._on_start_point_change).pack(anchor=tk.W)
        ttk.Radiobutton(card, text="From script (to audio)", variable=self.start_point,
                        value="script_tts", command=self._on_start_point_change).pack(anchor=tk.W)
        ttk.Radiobutton(card, text="From script (no audio)", variable=self.start_point,
                        value="script_no_audio", command=self._on_start_point_change).pack(anchor=tk.W)

        # Script type (shown only for script_no_audio)
        self.type_row = ttk.Frame(card, style="Card.TFrame")
        ttk.Label(self.type_row, text="Type:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Radiobutton(self.type_row, text="Prose", variable=self.script_type_var, value="prose").pack(side=tk.LEFT, padx=6)
        ttk.Radiobutton(self.type_row, text="Screenplay", variable=self.script_type_var, value="screenplay").pack(side=tk.LEFT)

        # Transcription + Direction
        card = self.app.create_card(self.left, "Transcription + Direction")
        self.lang_row = ttk.Frame(card, style="Card.TFrame")
        row = self.lang_row
        row.pack(fill=tk.X, pady=2)
        ttk.Label(row, text="Language:", style="Card.TLabel").pack(side=tk.LEFT)
        langs = ['ru', 'en', 'es', 'de', 'fr', 'it', 'pt', 'zh', 'pl']
        lang_cb = ttk.Combobox(row, textvariable=self.language, values=langs, width=5, state='readonly')
        lang_cb.pack(side=tk.LEFT, padx=5)

        row2 = ttk.Frame(card, style="Card.TFrame")
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="Direction:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Radiobutton(row2, text="1-pass", variable=self.direction_mode, value="1-pass").pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(row2, text="2-pass", variable=self.direction_mode, value="2-pass").pack(side=tk.LEFT)

        row3 = ttk.Frame(card, style="Card.TFrame")
        row3.pack(fill=tk.X, pady=2)
        ttk.Label(row3, text="Clip mode:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Radiobutton(row3, text="video", variable=self.clip_mode, value="video").pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(row3, text="slideshow", variable=self.clip_mode, value="slideshow").pack(side=tk.LEFT)

        row4 = ttk.Frame(card, style="Card.TFrame")
        row4.pack(fill=tk.X, pady=2)
        ttk.Label(row4, text="Duration:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row4, textvariable=self.clip_min, from_=1, to=30, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row4, text="—", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row4, textvariable=self.clip_max, from_=2, to=60, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row4, text="sec", style="Card.TLabel").pack(side=tk.LEFT)

        # Intro Block
        card = self.app.create_card(self.left, "Intro Block")
        row_i1 = ttk.Frame(card, style="Card.TFrame")
        row_i1.pack(fill=tk.X, pady=2)
        ttk.Label(row_i1, text="Intro zone:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row_i1, textvariable=self.intro_duration, from_=0, to=120, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row_i1, text="sec", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Label(row_i1, text="  (0 = off)", style="Dim.TLabel").pack(side=tk.LEFT, padx=4)

        row_i2 = ttk.Frame(card, style="Card.TFrame")
        row_i2.pack(fill=tk.X, pady=2)
        ttk.Label(row_i2, text="Intro clips:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row_i2, textvariable=self.intro_clip_min, from_=0, to=30, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row_i2, text="—", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row_i2, textvariable=self.intro_clip_max, from_=0, to=60, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row_i2, text="sec", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Label(row_i2, text="  (0 = inherit)", style="Dim.TLabel").pack(side=tk.LEFT, padx=4)

        # Image Generation
        card = self.app.create_card(self.left, "Image Generation")
        ttk.Radiobutton(card, text="FastGen", variable=self.img_gen, value="fastgen",
                        command=self._on_imggen_change).pack(anchor=tk.W)
        ttk.Radiobutton(card, text="VeoNonStop", variable=self.img_gen, value="veononstop",
                        command=self._on_imggen_change).pack(anchor=tk.W)
        ttk.Radiobutton(card, text="Skip (for t2v)", variable=self.img_gen, value="skip",
                        command=self._on_imggen_change).pack(anchor=tk.W)

        # FastGen sub-settings
        self.fg_frame = ttk.Frame(card, style="Card.TFrame")
        self.fg_frame.pack(fill=tk.X, pady=4)
        r = ttk.Frame(self.fg_frame, style="Card.TFrame")
        r.pack(fill=tk.X)
        ttk.Label(r, text="Model:", style="Dim.TLabel").pack(side=tk.LEFT)
        models = FASTGEN_DISPLAY
        ttk.Combobox(r, textvariable=self.fastgen_model, values=models, width=12, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(r, text="Aspect:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Combobox(r, textvariable=self.fastgen_aspect, values=['landscape', 'portrait', 'square'],
                     width=10, state='readonly').pack(side=tk.LEFT, padx=4)
        r2 = ttk.Frame(self.fg_frame, style="Card.TFrame")
        r2.pack(fill=tk.X, pady=(2, 0))
        ttk.Label(r2, text="Key:", style="Dim.TLabel").pack(side=tk.LEFT)
        _fg_key_vals = ['main'] + (['backup'] if getattr(config, 'FASTGEN_API_KEY_BACKUP', '') else [])
        ttk.Combobox(r2, textvariable=self.fastgen_api_key, values=_fg_key_vals,
                     width=8, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(r2, text="Threads:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Spinbox(r2, textvariable=self.fastgen_parallel, from_=1, to=32,
                    width=4).pack(side=tk.LEFT, padx=4)

        # VeoNonStop sub-settings
        self.veo_img_frame = ttk.Frame(card, style="Card.TFrame")
        r = ttk.Frame(self.veo_img_frame, style="Card.TFrame")
        r.pack(fill=tk.X)
        ttk.Label(r, text="Mode:", style="Dim.TLabel").pack(side=tk.LEFT)
        for val, txt in [('banana', 'Banana'), ('banana_ref', 'Banana+ref'), ('imagen', 'Imagen')]:
            ttk.Radiobutton(r, text=txt, variable=self.veo_imggen_mode, value=val,
                            command=self._on_veo_mode_change).pack(side=tk.LEFT, padx=3)
        self.veo_model_row = ttk.Frame(self.veo_img_frame, style="Card.TFrame")
        self.veo_model_row.pack(fill=tk.X, pady=(4, 0))
        ttk.Label(self.veo_model_row, text="Model:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Combobox(self.veo_model_row, textvariable=self.veo_banana_model, values=BANANA_DISPLAY,
                     width=12, state='readonly').pack(side=tk.LEFT, padx=4)

        # Ref images picker (for FastGen and banana_ref)
        self.ref_row = ttk.Frame(card, style="Card.TFrame")
        ref_top = ttk.Frame(self.ref_row, style="Card.TFrame")
        ref_top.pack(fill=tk.X)
        ttk.Label(ref_top, text="Refs:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Button(ref_top, text="Browse…", command=self._browse_ref_images).pack(side=tk.LEFT, padx=3)
        ttk.Button(ref_top, text="Remove", command=self._remove_ref_image).pack(side=tk.LEFT, padx=2)
        ttk.Button(ref_top, text="Clear", command=self._clear_ref_images).pack(side=tk.LEFT, padx=2)
        self.ref_listbox = tk.Listbox(self.ref_row, height=2, bg=COLORS['bg_input'], fg=COLORS['text'],
                                      font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        self.ref_listbox.pack(fill=tk.X, pady=(2, 0))


        self._on_imggen_change()

        # Video Generation
        card = self.app.create_card(self.left, "Video Generation")
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(fill=tk.X, pady=2)
        for val, txt in [('i2v', 'i2v'), ('t2v', 't2v'), ('components', 'components')]:
            ttk.Radiobutton(row, text=txt, variable=self.video_mode, value=val).pack(side=tk.LEFT, padx=5)

        row2 = ttk.Frame(card, style="Card.TFrame")
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="Ratio:", style="Card.TLabel").pack(side=tk.LEFT)
        for val in ['16:9', '9:16', '1:1']:
            ttk.Radiobutton(row2, text=val, variable=self.veo_ratio, value=val).pack(side=tk.LEFT, padx=3)

        row2b = ttk.Frame(card, style="Card.TFrame")
        row2b.pack(fill=tk.X, pady=2)
        ttk.Label(row2b, text="Workers:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row2b, textvariable=self.veo_parallel, from_=1, to=24, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row2b, text="  Delay:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row2b, textvariable=self.veo_request_delay, from_=0.5, to=30.0,
                   increment=0.5, width=4, format="%.1f",
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row2b, text="s", style="Dim.TLabel").pack(side=tk.LEFT)

        row3 = ttk.Frame(card, style="Card.TFrame")
        row3.pack(fill=tk.X, pady=2)
        ttk.Label(row3, text="Prompts:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Radiobutton(row3, text="single", variable=self.prompt_mode, value="single").pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(row3, text="per-clip", variable=self.prompt_mode, value="perclip").pack(side=tk.LEFT)

        # Single prompt file loader — shown only in "single" mode
        self.single_prompt_row = ttk.Frame(card, style="Card.TFrame")
        ttk.Label(self.single_prompt_row, text="Prompt file:", style="Dim.TLabel").pack(side=tk.LEFT)
        self.single_prompt_lbl = ttk.Label(self.single_prompt_row, text="(none)", style="Dim.TLabel")
        self.single_prompt_lbl.pack(side=tk.LEFT, padx=4, fill=tk.X, expand=True)
        ttk.Button(self.single_prompt_row, text="Browse", command=self._browse_single_prompt).pack(side=tk.RIGHT, padx=2)
        self.prompt_mode.trace_add('write', lambda *a: self._on_prompt_mode_change())
        self._on_prompt_mode_change()

        # Render
        card = self.app.create_card(self.left, "Render & Concat")
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(fill=tk.X, pady=2)
        ttk.Radiobutton(row, text="720p fast", variable=self.render_mode, value="720p").pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(row, text="1080p re-encode", variable=self.render_mode, value="1080p").pack(side=tk.LEFT)
        row2 = ttk.Frame(card, style="Card.TFrame")
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="Watermark:", style="Card.TLabel").pack(side=tk.LEFT)
        for val, txt in [('as_is', 'none'), ('logo', 'logo'), ('blur', 'blur')]:
            ttk.Radiobutton(row2, text=txt, variable=self.watermark, value=val).pack(side=tk.LEFT, padx=3)
        # Logo file picker
        logo_row = ttk.Frame(card, style="Card.TFrame")
        logo_row.pack(fill=tk.X, pady=2)
        ttk.Label(logo_row, text="Logo:", style="Dim.TLabel").pack(side=tk.LEFT)
        self.logo_lbl = ttk.Label(logo_row, text="(none)", style="Dim.TLabel")
        self.logo_lbl.pack(side=tk.LEFT, padx=4, fill=tk.X, expand=True)
        ttk.Button(logo_row, text="Browse", command=self._browse_logo).pack(side=tk.RIGHT, padx=2)
        ttk.Checkbutton(card, text="Keep retiming files", variable=self.keep_files).pack(anchor=tk.W, pady=2)
        ttk.Checkbutton(card, text="Keep VEO sound (save retimed_sound/ folder)",
                        variable=self.keep_veo_sound).pack(anchor=tk.W, pady=2)

        # YT Pack
        card = self.app.create_card(self.left, "YT Packer (final stage)")
        ttk.Checkbutton(card, text="Run YT Pack after pipeline", variable=self.yt_pack_enabled,
                        command=self._on_ytpack_toggle).pack(anchor=tk.W)
        self.yt_pack_subform = ttk.Frame(card, style="Card.TFrame")
        r1 = ttk.Frame(self.yt_pack_subform, style="Card.TFrame")
        r1.pack(fill=tk.X, pady=(4, 2))
        ttk.Label(r1, text="Languages:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Entry(r1, textvariable=self.yt_pack_languages, width=16).pack(side=tk.LEFT, padx=4)
        ttk.Label(r1, text="(comma-separated, e.g. ru,en)", style="Dim.TLabel").pack(side=tk.LEFT)
        r2 = ttk.Frame(self.yt_pack_subform, style="Card.TFrame")
        r2.pack(fill=tk.X, pady=2)
        ttk.Checkbutton(r2, text="Subtitles", variable=self.yt_pack_subtitles).pack(side=tk.LEFT, padx=2)
        ttk.Checkbutton(r2, text="Description", variable=self.yt_pack_description).pack(side=tk.LEFT, padx=6)
        ttk.Checkbutton(r2, text="Covers", variable=self.yt_pack_covers).pack(side=tk.LEFT, padx=6)

    def _on_ytpack_toggle(self):
        if self.yt_pack_enabled.get():
            self.yt_pack_subform.pack(fill=tk.X, pady=(2, 0))
        else:
            self.yt_pack_subform.pack_forget()

    def _build_right(self, parent):
        # ── Source Files + Style Guide side by side ─────────────────────
        top_row = ttk.Frame(parent)
        top_row.pack(fill=tk.X, pady=4, padx=2)

        # Source Files (left half)
        files_card = ttk.Frame(top_row, style="Card.TFrame", padding=12)
        files_card.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 3))
        ttk.Label(files_card, text="Start Files", style="Section.TLabel").pack(anchor=tk.W)
        self.files_listbox = tk.Listbox(files_card, height=3, bg=COLORS['bg_input'], fg=COLORS['text'],
                                         font=FONT_DIM, selectbackground=COLORS['accent'],
                                         selectforeground='#ffffff', relief=tk.FLAT, borderwidth=0)
        self.files_listbox.pack(fill=tk.X, pady=(4, 4))
        self.loaded_files: list[Path] = []
        btn_row = ttk.Frame(files_card, style="Card.TFrame")
        btn_row.pack(fill=tk.X)
        ttk.Button(btn_row, text="Add", command=self._add_source_files).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="Remove", command=self._remove_source_file).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="Clear", command=self._clear_source_files).pack(side=tk.LEFT, padx=2)
        self.files_count_lbl = ttk.Label(files_card, text="0 files", style="Dim.TLabel")
        self.files_count_lbl.pack(anchor=tk.W, pady=(2, 0))

        # Style Guide (right half)
        sg_card = ttk.Frame(top_row, style="Card.TFrame", padding=12)
        sg_card.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(3, 0))
        # Title + radio buttons on the same line
        sg_title_row = ttk.Frame(sg_card, style="Card.TFrame")
        sg_title_row.pack(fill=tk.X)
        ttk.Label(sg_title_row, text="Style Guide", style="Section.TLabel").pack(side=tk.LEFT)
        self.sg_mode = tk.StringVar(value="one_for_all")
        ttk.Radiobutton(sg_title_row, text="One for all", variable=self.sg_mode,
                        value="one_for_all", command=self._on_sg_mode_change).pack(side=tk.LEFT, padx=(10, 4))
        ttk.Radiobutton(sg_title_row, text="Individual", variable=self.sg_mode,
                        value="individual", command=self._on_sg_mode_change).pack(side=tk.LEFT)
        # Sub-panels stacked via place — guaranteed full coverage, no size jump
        _C = COLORS['bg_card']
        sg_stack = tk.Frame(sg_card, bg=_C)
        sg_stack.pack(fill=tk.X)
        # Individual panel (defines the container height — taller of the two)
        self.sg_ind_frame = tk.Frame(sg_stack, bg=_C)
        self.sg_ind_frame.pack(fill=tk.X)   # drives height
        self.sg_ind_listbox = tk.Listbox(self.sg_ind_frame, height=3, bg=COLORS['bg_input'],
                                          fg=COLORS['text'], font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        self.sg_ind_listbox.pack(fill=tk.X, pady=(0, 4))
        self.sg_individual: dict[str, Optional[Path]] = {}
        sg_btn_row = tk.Frame(self.sg_ind_frame, bg=_C)
        sg_btn_row.pack(fill=tk.X)
        ttk.Button(sg_btn_row, text="Set", command=self._set_individual_sg).pack(side=tk.LEFT, padx=2)
        ttk.Button(sg_btn_row, text="Clear", command=self._clear_individual_sg).pack(side=tk.LEFT, padx=2)
        # One-for-all panel — placed over ind_frame, same size
        self.sg_one_frame = tk.Frame(sg_stack, bg=_C)
        self.sg_one_frame.place(x=0, y=0, relwidth=1, relheight=1)
        self.sg_global_path: Optional[Path] = None
        self.sg_global_lbl = ttk.Label(self.sg_one_frame, text="(none)", style="Dim.TLabel")
        self.sg_global_lbl.pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(self.sg_one_frame, text="Browse", command=self._browse_sg_global).pack(side=tk.RIGHT, padx=2)

        # ── Summary (2-column) ───────────────────────────────────────────
        card = self.app.create_card(parent, "Summary")
        sum_cols = ttk.Frame(card, style="Card.TFrame")
        sum_cols.pack(fill=tk.X, pady=4)
        self.summary_label_left = tk.Label(sum_cols, text="", bg=COLORS['bg_card'], fg=COLORS['text'],
                                           font=FONT_LOG, justify=tk.LEFT, anchor=tk.NW)
        self.summary_label_left.pack(side=tk.LEFT, fill=tk.X, expand=True, anchor=tk.NW)
        self.summary_label_right = tk.Label(sum_cols, text="", bg=COLORS['bg_card'], fg=COLORS['text'],
                                            font=FONT_LOG, justify=tk.LEFT, anchor=tk.NW)
        self.summary_label_right.pack(side=tk.LEFT, fill=tk.X, expand=True, anchor=tk.NW)
        self._update_summary()
        # Trace all variables to auto-update summary
        for var in [self.start_point, self.language, self.direction_mode, self.clip_mode,
                    self.img_gen, self.fastgen_model, self.video_mode, self.veo_ratio,
                    self.prompt_mode, self.render_mode, self.watermark, self.veo_imggen_mode,
                    self.veo_banana_model]:
            var.trace_add('write', lambda *a: self._update_summary())
        for var in [self.clip_min, self.clip_max, self.veo_parallel, self.fastgen_parallel,
                    self.keep_files, self.intro_duration, self.intro_clip_min, self.intro_clip_max]:
            var.trace_add('write', lambda *a: self._update_summary())

        # Stage progress
        card = self.app.create_card(parent, "Stage Progress")
        self.stage_frame = ttk.Frame(card, style="Card.TFrame")
        self.stage_frame.pack(fill=tk.X, pady=4)
        self.stage_labels = []
        stages = ["Queue", "Transcribe", "Direction", "ImgGen", "VideoGen", "Concat"]
        for i, name in enumerate(stages):
            lbl = tk.Label(self.stage_frame, text=name, bg=COLORS['bg_card'],
                           fg=COLORS['text_muted'], font=FONT_DIM)
            lbl.pack(side=tk.LEFT, padx=3)
            self.stage_labels.append(lbl)
            if i < len(stages) - 1:
                tk.Label(self.stage_frame, text="->", bg=COLORS['bg_card'],
                         fg=COLORS['text_muted'], font=FONT_DIM).pack(side=tk.LEFT)
        self.stage_progress = ttk.Progressbar(card, mode='determinate', maximum=len(stages))
        self.stage_progress.pack(fill=tk.X, pady=(4, 2))
        # Per-stage task progress
        task_row = ttk.Frame(card, style="Card.TFrame")
        task_row.pack(fill=tk.X, pady=(2, 0))
        self.task_progress = ttk.Progressbar(task_row, mode='determinate', maximum=100)
        self.task_progress.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.task_progress_lbl = ttk.Label(task_row, text="", style="Dim.TLabel", width=10, anchor=tk.E)
        self.task_progress_lbl.pack(side=tk.RIGHT, padx=(6, 0))

        # Buttons
        btn_frame = ttk.Frame(parent, style="Card.TFrame")
        btn_frame.pack(fill=tk.X, pady=4, padx=2)
        self.start_btn = ttk.Button(btn_frame, text="Start Pipeline",
                                    command=self.start_pipeline, style="Accent.TButton")
        self.start_btn.pack(side=tk.LEFT, padx=4)
        self.stop_btn = ttk.Button(btn_frame, text="Stop", command=self.stop_pipeline,
                                   state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=4)
        ttk.Button(btn_frame, text="Save Defaults", command=self._save_defaults).pack(side=tk.RIGHT, padx=4)

        # Log — expand to fill remaining height
        log_card = ttk.Frame(parent, style="Card.TFrame", padding=12)
        log_card.pack(fill=tk.BOTH, expand=True, pady=4, padx=2)
        log_hdr = ttk.Frame(log_card, style="Card.TFrame")
        log_hdr.pack(fill=tk.X)
        ttk.Label(log_hdr, text="Pipeline Log", style="Section.TLabel").pack(side=tk.LEFT)
        ttk.Button(log_hdr, text="Clear", command=lambda: self.log_widget.delete("1.0", tk.END)).pack(side=tk.RIGHT)
        self.log_widget = self.app.create_log_widget(log_card)
        self.spinner_lbl = ttk.Label(log_card, text="", style="Dim.TLabel", anchor=tk.W,
                                     font=FONT_DIM)
        self.spinner_lbl.pack(fill=tk.X, pady=(1, 0))

    def _on_imggen_change(self):
        mode = self.img_gen.get()
        self.fg_frame.pack_forget()
        self.veo_img_frame.pack_forget()
        self.ref_row.pack_forget()
        if mode == "fastgen":
            self.fg_frame.pack(fill=tk.X, pady=4)
            self.ref_row.pack(fill=tk.X, pady=(0, 4))
        elif mode == "veononstop":
            self.veo_img_frame.pack(fill=tk.X, pady=4)
            self._on_veo_mode_change()

    def _on_prompt_mode_change(self):
        if self.prompt_mode.get() == "single":
            self.single_prompt_row.pack(fill=tk.X, pady=2)
        else:
            self.single_prompt_row.pack_forget()

    def _on_veo_mode_change(self):
        mode = self.veo_imggen_mode.get()
        if mode == 'imagen':
            self.veo_model_row.pack_forget()
            self.ref_row.pack_forget()
        elif mode == 'banana_ref':
            self.veo_model_row.pack(fill=tk.X, pady=(4, 0))
            self.ref_row.pack(fill=tk.X, pady=(4, 0))
        else:
            self.veo_model_row.pack(fill=tk.X, pady=(4, 0))
            self.ref_row.pack_forget()

    def _browse_ref_images(self):
        paths = filedialog.askopenfilenames(
            title="Select reference images",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp"), ("All files", "*.*")]
        )
        for p in paths:
            pp = Path(p)
            if pp not in self.ref_images:
                self.ref_images.append(pp)
        self._refresh_ref_listbox()

    def _remove_ref_image(self):
        sel = self.ref_listbox.curselection()
        if sel:
            self.ref_images.pop(sel[0])
            self._refresh_ref_listbox()

    def _clear_ref_images(self):
        self.ref_images.clear()
        self._refresh_ref_listbox()

    def _refresh_ref_listbox(self):
        self.ref_listbox.delete(0, tk.END)
        for p in self.ref_images:
            self.ref_listbox.insert(tk.END, p.name)
        self.ref_listbox.config(height=max(2, min(len(self.ref_images), 6)))

    def _browse_logo(self):
        path = filedialog.askopenfilename(title="Select logo image",
                                           filetypes=[("Images", "*.png *.jpg *.jpeg *.webp"), ("All", "*.*")])
        if path:
            self.logo_path = Path(path)
            self.logo_lbl.config(text=self.logo_path.name)

    def _browse_single_prompt(self):
        path = filedialog.askopenfilename(title="Select single prompt file",
                                           filetypes=[("Text", "*.txt"), ("All", "*.*")])
        if path:
            self.single_prompt_path = Path(path)
            self.single_prompt_lbl.config(text=self.single_prompt_path.name)
            self._update_summary()

    # ── Source Files management ──

    def _add_source_files(self):
        sp = self.start_point.get()
        if sp == "audio":
            ftypes = [("Audio", "*.mp3 *.wav *.flac *.m4a *.aac"), ("All", "*.*")]
        else:
            ftypes = [("Scripts", "*.txt *.md"), ("All", "*.*")]
        paths = filedialog.askopenfilenames(title="Select source files", filetypes=ftypes)
        if not paths:
            return
        for p in paths:
            pp = Path(p)
            if pp not in self.loaded_files:
                self.loaded_files.append(pp)
        self._refresh_files_list()

    def _remove_source_file(self):
        sel = self.files_listbox.curselection()
        if not sel:
            return
        idx = sel[0]
        removed = self.loaded_files.pop(idx)
        # Also remove from individual style guide map
        self.sg_individual.pop(removed.name, None)
        self._refresh_files_list()

    def _clear_source_files(self):
        self.loaded_files.clear()
        self.sg_individual.clear()
        self._refresh_files_list()

    def _refresh_files_list(self):
        self.files_listbox.delete(0, tk.END)
        for f in self.loaded_files:
            self.files_listbox.insert(tk.END, f.name)
        n = len(self.loaded_files)
        self.files_count_lbl.config(text=f"{n} file{'s' if n != 1 else ''} loaded")
        self._refresh_sg_ind_list()
        self._update_summary()

    # ── Style Guide management ──

    def _on_sg_mode_change(self):
        if self.sg_mode.get() == "one_for_all":
            self.sg_one_frame.tkraise()
        else:
            self.sg_ind_frame.tkraise()
            self._refresh_sg_ind_list()

    def _browse_sg_global(self):
        path = filedialog.askopenfilename(title="Select style guide",
                                           filetypes=[("Text", "*.txt *.md"), ("All", "*.*")])
        if path:
            self.sg_global_path = Path(path)
            self.sg_global_lbl.config(text=self.sg_global_path.name)
            self._update_summary()

    def _refresh_sg_ind_list(self):
        self.sg_ind_listbox.delete(0, tk.END)
        for f in self.loaded_files:
            sg = self.sg_individual.get(f.name)
            sg_name = sg.name if sg else "(none)"
            self.sg_ind_listbox.insert(tk.END, f"{f.name}  ->  {sg_name}")

    def _set_individual_sg(self):
        sel = self.sg_ind_listbox.curselection()
        if not sel:
            messagebox.showinfo("Info", "Select a file in the list first")
            return
        idx = sel[0]
        if idx >= len(self.loaded_files):
            return
        target = self.loaded_files[idx]
        path = filedialog.askopenfilename(title=f"Style guide for {target.name}",
                                           filetypes=[("Text", "*.txt *.md"), ("All", "*.*")])
        if path:
            self.sg_individual[target.name] = Path(path)
            self._refresh_sg_ind_list()
            self._update_summary()

    def _clear_individual_sg(self):
        sel = self.sg_ind_listbox.curselection()
        if not sel:
            return
        idx = sel[0]
        if idx >= len(self.loaded_files):
            return
        target = self.loaded_files[idx]
        self.sg_individual.pop(target.name, None)
        self._refresh_sg_ind_list()

    def _on_start_point_change(self):
        mode = self.start_point.get()
        # Clear files to avoid stale audio/script mix
        self._clear_source_files()
        if mode == "script_no_audio":
            self.type_row.pack(fill=tk.X, pady=(4, 0))
            self.lang_row.pack_forget()
        else:  # audio or script_tts
            self.type_row.pack_forget()
            self.lang_row.pack(fill=tk.X, pady=2)
        self._update_summary()

    def _update_summary(self):
        ig = self.img_gen.get()
        if ig == "fastgen":
            img_desc = f"FastGen ({self.fastgen_model.get()}, {self.fastgen_aspect.get()})"
        elif ig == "veononstop":
            veo_mode = self.veo_imggen_mode.get()
            if veo_mode == 'imagen':
                img_desc = "VeoNonStop (Imagen)"
            else:
                img_desc = f"VeoNonStop ({veo_mode}, {self.veo_banana_model.get()})"
        else:
            img_desc = "Skip"

        intro_dur = self.intro_duration.get()
        if intro_dur > 0:
            imin = self.intro_clip_min.get()
            imax = self.intro_clip_max.get()
            intro_desc = f"{intro_dur}s zone, clips {imin}-{imax}s" if imin > 0 else f"{intro_dur}s zone (inherit)"
        else:
            intro_desc = "off"

        # Files info
        n_files = len(self.loaded_files)
        files_desc = f"{n_files} file{'s' if n_files != 1 else ''}" if n_files > 0 else "ready_to_go/"
        sg_mode = self.sg_mode.get()
        if sg_mode == "one_for_all" and self.sg_global_path:
            sg_desc = self.sg_global_path.name
        elif sg_mode == "individual":
            n_sg = sum(1 for v in self.sg_individual.values() if v)
            sg_desc = f"{n_sg}/{n_files} individual"
        else:
            sg_desc = "auto (ready_to_go/)"
        logo_desc = self.logo_path.name if self.logo_path else "none"
        prompt_desc = self.single_prompt_path.name if self.single_prompt_path else "auto"

        sp = self.start_point.get()
        if sp == "script_no_audio":
            script_name = self.loaded_files[0].name if self.loaded_files else "(none)"
            start_desc = f"script ({self.script_type_var.get()}: {script_name})"
            lang_desc = "—"
        elif sp == "script_tts":
            script_name = self.loaded_files[0].name if self.loaded_files else "(none)"
            start_desc = f"script→audio ({script_name})"
            lang_desc = self.language.get()
        else:
            start_desc = "audio"
            lang_desc = self.language.get()

        left_lines = [
            f"Files:     {files_desc}",
            f"Style:     {sg_desc}",
            f"Start:     {start_desc}",
            f"Language:  {lang_desc}",
            f"Direction: {self.direction_mode.get()}",
            f"Clips:     {self.clip_mode.get()} ({self.clip_min.get()}-{self.clip_max.get()}s)",
        ]
        right_lines = [
            f"Intro:     {intro_desc}",
            f"ImgGen:    {img_desc}",
            f"VideoGen:  {self.video_mode.get()} ({self.veo_ratio.get()}, x{self.veo_parallel.get()})",
            f"Prompt:    {prompt_desc}",
            f"Render:    {self.render_mode.get()}, wm={self.watermark.get()}",
            f"Logo:      {logo_desc}",
        ]
        self.summary_label_left.config(text="\n".join(left_lines))
        self.summary_label_right.config(text="\n".join(right_lines))

    def _set_stage(self, index):
        for i, lbl in enumerate(self.stage_labels):
            if i == index:
                lbl.config(fg=COLORS['yellow'])   # active
            elif i < index:
                lbl.config(fg=COLORS['green'])    # done
            else:
                lbl.config(fg=COLORS['accent'])   # pending
        self.stage_progress['value'] = index
        # Reset task progress on new stage
        self.task_progress['value'] = 0
        self.task_progress['maximum'] = 100
        self.task_progress_lbl.config(text="")

    def _set_task_progress(self, current: int, total: int):
        self.task_progress['maximum'] = total
        self.task_progress['value'] = current
        self.task_progress_lbl.config(text=f"{current} / {total}")

    def start_pipeline(self):
        if self.is_running:
            return

        # Сброс лога и индикаторов стадий
        self.log_widget.delete("1.0", tk.END)
        for lbl in self.stage_labels:
            lbl.config(fg=COLORS['accent'])
        self.stage_progress['value'] = 0
        self.spinner_lbl.config(text="")

        rtg = SCRIPT_DIR / 'ready_to_go'
        rtg.mkdir(parents=True, exist_ok=True)

        # If user loaded files via GUI — copy them to ready_to_go
        if self.loaded_files:
            for src in self.loaded_files:
                dst = rtg / src.name
                if not dst.exists():
                    shutil.copy2(str(src), str(dst))
                    self.app.log(f"Copied: {src.name} -> ready_to_go/", "INFO", tab="pipeline")

            # Copy style guides with proper naming
            sg_mode = self.sg_mode.get()
            if sg_mode == "one_for_all" and self.sg_global_path and self.sg_global_path.exists():
                sg_dst = rtg / f"SG_ALL_{self.sg_global_path.stem}.txt"
                shutil.copy2(str(self.sg_global_path), str(sg_dst))
                self.app.log(f"Style guide (global): {sg_dst.name}", "INFO", tab="pipeline")
            elif sg_mode == "individual":
                for f in self.loaded_files:
                    sg = self.sg_individual.get(f.name)
                    if sg and sg.exists():
                        # Name: {audio_stem}_{sg_stem}.txt — keeps original sg name, matched to audio
                        sg_dst = rtg / f"{f.stem}_{sg.stem}{sg.suffix}"
                        shutil.copy2(str(sg), str(sg_dst))
                        self.app.log(f"Style guide: {sg_dst.name}", "INFO", tab="pipeline")

            # Copy logo if set
            if self.logo_path and self.logo_path.exists():
                logo_dst = rtg / self.logo_path.name
                if not logo_dst.exists():
                    shutil.copy2(str(self.logo_path), str(logo_dst))
        else:
            # No files loaded — check ready_to_go directly
            audio = list(rtg.glob('*.mp3')) + list(rtg.glob('*.wav')) + list(rtg.glob('*.flac'))
            if not audio and self.start_point.get() == "audio":
                messagebox.showerror("Error", "No files loaded and no audio in ready_to_go/")
                return

        # Stage ref images → .pending_refs/ (queue.py copies to project/ref/ and cleans up)
        if self.ref_images:
            staging = SCRIPT_DIR / '.pending_refs'
            if staging.exists():
                shutil.rmtree(str(staging))
            staging.mkdir()
            for img in self.ref_images:
                shutil.copy2(str(img), str(staging / img.name))
            self.app.log(f"Staged {len(self.ref_images)} ref image(s) -> .pending_refs/", "INFO", tab="pipeline")

        # Script mode validation
        start_mode = self.start_point.get()
        if start_mode in ("script_no_audio", "script_tts"):
            if not self.loaded_files:
                messagebox.showerror("Error", "No script file loaded. Use Add in Start Files to select a .txt script.")
                return
            if not self.loaded_files[0].exists():
                messagebox.showerror("Error", f"Script file not found:\n{self.loaded_files[0]}")
                return
            if start_mode == "script_no_audio":
                sg_mode = self.sg_mode.get()
                if sg_mode == "one_for_all" and not (self.sg_global_path and self.sg_global_path.exists()):
                    messagebox.showerror("Error", "Style guide required for script mode.\nSet a global style guide in the Style Guide card.")
                    return
            # script_tts: files already copied to ready_to_go/ in the loaded_files loop above

        self.is_running = True
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self._cancel = threading.Event()
        threading.Thread(target=self._pipeline_worker, daemon=True).start()

    def stop_pipeline(self):
        self._cancel.set()
        self.app.log("Pipeline stop requested...", "WARNING", tab="pipeline")

    def _pipeline_worker(self):
        try:
            # Set config overrides
            two_pass = self.direction_mode.get() == "2-pass"
            post_action = 'skip'
            ig = self.img_gen.get()
            vm = self.video_mode.get()
            if ig == "fastgen" and vm == "i2v":
                post_action = 'fastgen_i2v'
            elif ig == "veononstop" and vm == "i2v":
                post_action = 'veo_i2v'
            elif vm == "t2v":
                post_action = 't2v'
            elif vm == "components":
                post_action = 'components'

            # Build CLI phases (list of arg lists, run sequentially)
            start_mode = self.start_point.get()

            # Standard process pipeline (used by audio and script_tts phase 2)
            process_args = ['python', str(AGENT_DIR / 'agent.py'), 'process', '--run',
                            '--language', self.language.get(),
                            '--clip-mode', self.clip_mode.get(),
                            '--clip-min', str(self.clip_min.get()),
                            '--clip-max', str(self.clip_max.get()),
                            '--post-action', post_action,
                            '--prompt-mode', self.prompt_mode.get()]
            if two_pass:
                process_args.append('--two-pass')
            # Передаём style guide из GUI — обходит автопоиск по ready_to_go
            _sg_mode = self.sg_mode.get()
            if _sg_mode == 'one_for_all' and self.sg_global_path:
                process_args.extend(['--style', str(self.sg_global_path)])

            if start_mode == "script_no_audio":
                script_path = str(self.loaded_files[0])
                sg_mode = self.sg_mode.get()
                style_path = str(self.sg_global_path) if (sg_mode == "one_for_all" and self.sg_global_path) else ""
                project_name = Path(script_path).stem
                script_args = ['python', str(AGENT_DIR / 'agent.py'), 'script',
                               '--script', script_path,
                               '--style', style_path,
                               '--project', project_name,
                               '--script-type', self.script_type_var.get(),
                               '--clip-mode', self.clip_mode.get(),
                               '--clip-min', str(self.clip_min.get()),
                               '--clip-max', str(self.clip_max.get()),
                               '--post-action', post_action]
                if two_pass:
                    script_args.append('--two-pass')
                phases = [script_args]
            elif start_mode == "script_tts":
                # Phase 1: TTS only → generates audio in ready_to_go/
                tts_args = ['python', str(AGENT_DIR / 'tools' / 'tts_runner.py'),
                            '--mode', 'silent', '--tts-only']
                # Phase 2: full pipeline with all GUI settings (identical to audio mode)
                phases = [tts_args, process_args]
            else:
                phases = [process_args]

            # Set env vars for the subprocess
            env = os.environ.copy()
            env['VEONONSTOP_MAX_PARALLEL'] = str(self.veo_parallel.get())
            env['VEONONSTOP_ASPECT_RATIO'] = self.veo_ratio.get()
            env['VEONONSTOP_REQUEST_DELAY'] = str(self.veo_request_delay.get())
            env['FASTGEN_MODEL'] = FASTGEN_NAME_TO_KEY.get(self.fastgen_model.get(), self.fastgen_model.get())
            env['FASTGEN_ASPECT_RATIO'] = self.fastgen_aspect.get()
            env['FASTGEN_MAX_PARALLEL'] = str(self.fastgen_parallel.get())
            if self.fastgen_api_key.get() == 'backup':
                bk = getattr(config, 'FASTGEN_API_KEY_BACKUP', '')
                if bk:
                    env['FASTGEN_API_KEY'] = bk
            env['VIDEO_CLIP_MIN_DURATION'] = str(self.clip_min.get())
            env['VIDEO_CLIP_MAX_DURATION'] = str(self.clip_max.get())
            env['ASSEMBLYAI_LANGUAGE_CODE'] = self.language.get()
            env['INTRO_BLOCK_DURATION'] = str(self.intro_duration.get())
            env['INTRO_CLIP_MIN_DURATION'] = str(self.intro_clip_min.get())
            env['INTRO_CLIP_MAX_DURATION'] = str(self.intro_clip_max.get())
            if ig == "veononstop":
                env['VEONONSTOP_IMGGEN_MODE'] = self.veo_imggen_mode.get()
                env['VEONONSTOP_BANANA_MODEL'] = BANANA_NAME_TO_KEY.get(self.veo_banana_model.get(), 'GEM_PIX_2')
            wm = self.watermark.get()
            if wm != 'as_is':
                env['WATERMARK_MODE'] = wm
            if self.logo_path and self.logo_path.exists():
                env['LOGO_PATH'] = str(self.logo_path)
            if self.single_prompt_path and self.single_prompt_path.exists():
                env['SINGLE_PROMPT_FILE'] = str(self.single_prompt_path)
            staging = SCRIPT_DIR / '.pending_refs'
            if staging.exists():
                env['VARAGENT_REF_STAGING'] = str(staging)
            if self.yt_pack_enabled.get():
                env['YT_PACK_LANGUAGES'] = self.yt_pack_languages.get()
                env['YT_PACK_SUBTITLES'] = 'true' if self.yt_pack_subtitles.get() else 'false'
                env['YT_PACK_DESCRIPTION'] = 'true' if self.yt_pack_description.get() else 'false'
                env['YT_PACK_COVERS'] = 'true' if self.yt_pack_covers.get() else 'false'
                # Add --yt-pack to every agent.py phase (not tts_runner)
                for phase in phases:
                    if 'tts_runner' not in phase[1] and '--yt-pack' not in phase:
                        phase.append('--yt-pack')

            self.app.log("Starting pipeline...", "INFO", tab="pipeline")
            # ── Settings dump ──
            self.app.log("━" * 56, tab="pipeline")
            files_str = ", ".join(f.name for f in self.loaded_files) if self.loaded_files else "(none)"
            self.app.log(f"  Start:     {start_mode}  |  Files: {files_str}", tab="pipeline")
            self.app.log(f"  Language:  {self.language.get()}  |  Direction: {self.direction_mode.get()}", tab="pipeline")
            self.app.log(f"  Clips:     {self.clip_mode.get()} {self.clip_min.get()}-{self.clip_max.get()}s  |  Intro: {self.intro_duration.get()}s block {self.intro_clip_min.get()}-{self.intro_clip_max.get()}s", tab="pipeline")
            self.app.log(f"  Post:      {post_action}  |  Prompt: {self.prompt_mode.get()}  |  Render: {self.render_mode.get()}", tab="pipeline")
            if ig == "veononstop":
                self.app.log(f"  VeoNonStop: imggen={self.veo_imggen_mode.get()} model={self.veo_banana_model.get()} ratio={self.veo_ratio.get()} x{self.veo_parallel.get()}", tab="pipeline")
            elif ig == "fastgen":
                self.app.log(f"  FastGen:   model={self.fastgen_model.get()} ratio={self.fastgen_aspect.get()} x{self.fastgen_parallel.get()}", tab="pipeline")
            extras = []
            if wm != 'as_is':
                extras.append(f"watermark={wm}")
            if self.logo_path and self.logo_path.exists():
                extras.append(f"logo={self.logo_path.name}")
            if self.ref_images:
                extras.append(f"refs={len(self.ref_images)} ({', '.join(r.name for r in self.ref_images)})")
            if self.single_prompt_path and self.single_prompt_path.exists():
                extras.append(f"prompt={self.single_prompt_path.name}")
            if extras:
                self.app.log(f"  Extras:    {' | '.join(extras)}", tab="pipeline")
            if self.yt_pack_enabled.get():
                self.app.log(f"  YT Pack:   langs={self.yt_pack_languages.get()} subs={self.yt_pack_subtitles.get()} desc={self.yt_pack_description.get()} covers={self.yt_pack_covers.get()}", tab="pipeline")
            self.app.log(f"  Phases:    {len(phases)}", tab="pipeline")
            for _pi, _ph in enumerate(phases, 1):
                self.app.log(f"    [{_pi}] {' '.join(_ph)}", tab="pipeline")
            self.app.log("━" * 56, tab="pipeline")
            self.root.after(0, lambda: self._set_stage(0))

            stage_map = {
                'STAGE 1': 1, 'Transcrib': 1,
                'STAGE 2': 2, 'Direction': 2, 'Director': 2,
                'STAGE 3:': 3, 'Image gen': 3, 'FastGen': 3, 'imggen': 3,
                'STAGE 3.5': 4, 'Video gen': 4, 'veo_video': 4,
                'STAGE 4': 5, 'Concat': 5, 'video_concat': 5,
                'YT Pack': 6, 'YT PACKER': 6, 'yt_pack': 6,
            }

            _SPINNER_CHARS = set('⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏⏳')
            captured_projects = []  # пути к проектам готовым для конката
            failed = False
            for _phase_idx, phase_args in enumerate(phases, 1):
                if self._cancel.is_set():
                    break
                if len(phases) > 1:
                    phase_label = Path(phase_args[1]).name if len(phase_args) > 1 else phase_args[0]
                    self.app.log(f"── Phase {_phase_idx}/{len(phases)}: {phase_label} ──", "INFO", tab="pipeline")
                proc = subprocess.Popen(
                    phase_args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, encoding='utf-8', errors='replace',
                    cwd=str(SCRIPT_DIR), env=env
                )
                for line in proc.stdout:
                    if self._cancel.is_set():
                        proc.terminate()
                        break
                    line = line.rstrip()
                    if not line:
                        continue
                    # Spinner lines (braille frames from director _run_with_spinner)
                    stripped = line.strip()
                    if stripped and stripped[0] in _SPINNER_CHARS and '✅' not in line:
                        self.root.after(0, lambda t=stripped: self.spinner_lbl.config(text=t))
                        continue
                    # Done line — clear spinner
                    if '✅' in line:
                        self.root.after(0, lambda: self.spinner_lbl.config(text=""))
                    # Сигнал от agent.py: проект полностью готов к конкату
                    if line.startswith('PROJECT_DONE:'):
                        proj_path = line.split(':', 1)[1].strip()
                        if proj_path:
                            captured_projects.append(proj_path)
                        continue
                    for key, idx in stage_map.items():
                        if key.lower() in line.lower():
                            self.root.after(0, lambda i=idx: self._set_stage(i))
                            break
                    m = re.search(r'\b(\d+)\s*/\s*(\d+)\b', line)
                    if m:
                        cur, total = int(m.group(1)), int(m.group(2))
                        if 0 < total <= 50000 and 0 <= cur <= total:
                            self.root.after(0, lambda c=cur, t=total: self._set_task_progress(c, t))
                    level = 'INFO'
                    low = line.lower()
                    if any(x in low for x in ['error', 'fail', 'traceback']):
                        level = 'ERROR'
                    elif any(x in low for x in ['[ok]', 'success', 'complete']):
                        level = 'SUCCESS'
                    elif any(x in low for x in ['warn', 'skip', 'retry']):
                        level = 'WARNING'
                    self.app.log(line, level, tab="pipeline")
                proc.wait()
                if proc.returncode != 0:
                    self.app.log(f"Phase failed (exit code {proc.returncode})", "ERROR", tab="pipeline")
                    failed = True
                    break

            self.root.after(0, lambda: self.spinner_lbl.config(text=""))

            # ── Конкат для каждого завершённого проекта ──
            if not failed and not self._cancel.is_set() and captured_projects:
                self.root.after(0, lambda: self._set_stage(5))
                render = self.render_mode.get()
                bitrate = '20M' if render == '1080p' else '10M'
                for proj_dir in captured_projects:
                    proj_path = Path(proj_dir)
                    proj_name = proj_path.name
                    self.app.log(f"── Concat: {proj_name} ({render}, {bitrate}) ──", "INFO", tab="pipeline")
                    concat_cmd = ['python', 'video_concat.py',
                                  'montage_plan.json', '-o', f'{proj_name}.mp4', '-b', bitrate]
                    if render == '1080p':
                        concat_cmd.extend(['-r', '1080'])
                    if self.watermark.get() == 'blur':
                        concat_cmd.append('--blur-borders')
                    if self.logo_path and self.logo_path.exists():
                        concat_cmd.extend(['--logo', str(self.logo_path)])
                    if self.keep_veo_sound.get():
                        concat_cmd.append('--veo-audio-inline')
                        concat_cmd.append('--keep-veo-sound')
                    if self.keep_files.get():
                        concat_cmd.append('--no-cleanup')
                    concat_proc = subprocess.Popen(
                        concat_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                        text=True, encoding='utf-8', errors='replace',
                        cwd=str(proj_path), env=env
                    )
                    for line in concat_proc.stdout:
                        if self._cancel.is_set():
                            concat_proc.terminate()
                            break
                        line = line.rstrip()
                        if not line:
                            continue
                        level = 'INFO'
                        low = line.lower()
                        if any(x in low for x in ['error', 'fail', 'traceback']):
                            level = 'ERROR'
                        elif any(x in low for x in ['done', 'ok', 'complete', 'success', 'written']):
                            level = 'SUCCESS'
                        self.app.log(line, level, tab="pipeline")
                    concat_proc.wait()
                    if concat_proc.returncode != 0:
                        self.app.log(f"Concat failed (exit {concat_proc.returncode})", "ERROR", tab="pipeline")
                        failed = True

            if not failed and not self._cancel.is_set():
                self.app.log("Pipeline complete!", "SUCCESS", tab="pipeline")
                self.root.after(0, lambda: self._set_stage(len(self.stage_labels)))
            elif self._cancel.is_set():
                self.app.log("Pipeline cancelled.", "WARNING", tab="pipeline")

        except Exception as e:
            self.app.log(f"Pipeline error: {e}", "ERROR", tab="pipeline")
        finally:
            self.is_running = False
            self.root.after(0, lambda: self.start_btn.config(state=tk.NORMAL))
            self.root.after(0, lambda: self.stop_btn.config(state=tk.DISABLED))


# ════════════════════════════════════════════════════════════════════
# TAB 2: CONTROL PANEL
# ════════════════════════════════════════════════════════════════════

class ControlPanelTab:
    """Project browser, per-stage buttons, .env editor."""

    def __init__(self, notebook, app: VarAgentGUI):
        self.app = app
        self.root = app.root
        self.frame = ttk.Frame(notebook)
        self.active_tasks = 0
        self.create_ui()

    def create_ui(self):
        # Top: project list
        card = self.app.create_card(self.frame, "Projects")

        btn_row = ttk.Frame(card, style="Card.TFrame")
        btn_row.pack(fill=tk.X, pady=(0, 4))
        ttk.Button(btn_row, text="Refresh", command=self.refresh_projects).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="Dry-Run", command=self._run_dryrun).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="Mock Run", command=self._run_mock).pack(side=tk.LEFT, padx=2)

        cols = ("name", "audio", "transcr", "plan", "images", "videos", "mp4", "status")
        self.tree = ttk.Treeview(card, columns=cols, show='headings', height=8)
        for c, w in zip(cols, [180, 40, 40, 40, 50, 50, 40, 140]):
            self.tree.heading(c, text=c.title())
            self.tree.column(c, width=w, anchor=tk.CENTER if w < 100 else tk.W)
        self.tree.pack(fill=tk.BOTH, expand=True)
        self.tree.bind('<Double-1>', self._open_project_folder)

        # Stage buttons
        card2 = self.app.create_card(self.frame, "Run Stage")
        self.stage_buttons = []
        # Row 1: start stages (no project required — will create one)
        row1 = ttk.Frame(card2, style="Card.TFrame")
        row1.pack(fill=tk.X)
        for label, cmd in [
            ("Script→Audio", self._run_script_tts),
            ("Script→Video", self._run_script_video),
            ("Transcribe", self._run_transcribe),
        ]:
            btn = ttk.Button(row1, text=label, command=cmd)
            btn.pack(side=tk.LEFT, padx=3, pady=2)
            self.stage_buttons.append(btn)
        # Row 2: continuation stages (require existing project)
        row2 = ttk.Frame(card2, style="Card.TFrame")
        row2.pack(fill=tk.X, pady=(2, 0))
        for label, cmd in [
            ("Scene Director", self._run_direct),
            ("ImageGen", self._run_imagegen),
            ("VideoGen", self._run_videogen),
            ("Concat", self._run_concat),
            ("YT Pack", self._run_ytpack),
        ]:
            btn = ttk.Button(row2, text=label, command=cmd)
            btn.pack(side=tk.LEFT, padx=3, pady=2)
            self.stage_buttons.append(btn)

        # Status bar + progress
        status_frame = ttk.Frame(card2, style="Card.TFrame")
        status_frame.pack(fill=tk.X, pady=(6, 0))
        self.status_label = tk.Label(status_frame, text="Ready", bg=COLORS['bg_card'],
                                     fg=COLORS['text_dim'], font=FONT_DIM, anchor=tk.W)
        self.status_label.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.progress_bar = ttk.Progressbar(card2, style="Custom.Horizontal.TProgressbar",
                                            mode='indeterminate', length=300)
        self.progress_bar.pack(fill=tk.X, pady=(4, 0))

        # Log (takes remaining space)
        log_card = self.app.create_card(self.frame, "Task Log")
        self.log_widget = self.app.create_log_widget(log_card)

        # Load data
        self.root.after(200, self.refresh_projects)

    def refresh_projects(self):
        self.tree.delete(*self.tree.get_children())
        projects_dir = SCRIPT_DIR / 'projects'
        if not projects_dir.exists():
            return
        for p in sorted(projects_dir.iterdir()):
            if not p.is_dir() or p.name.startswith('_'):
                continue
            info = self._scan_project(p)
            self.tree.insert('', tk.END, values=(
                info['name'],
                'Y' if info['has_audio'] else '-',
                'Y' if info['has_transcription'] else '-',
                'Y' if info['has_plan'] else '-',
                str(info['img_count']) if info['img_count'] else '-',
                str(info['vid_count']) if info['vid_count'] else '-',
                'Y' if info['has_mp4'] else '-',
                info['status'],
            ))

    def _scan_project(self, p: Path) -> dict:
        has_audio = bool(list(p.glob('*.mp3')) + list(p.glob('*.wav')) + list(p.glob('*.flac')))
        has_tr = (p / 'transcription.json').exists()
        has_plan = (p / 'montage_plan.json').exists()
        gen = p / 'generated'
        vid = p / 'vid_img'
        img_count = len(list(gen.glob('*.png'))) if gen.exists() else 0
        vid_count = len(list(vid.glob('*.mp4'))) if vid.exists() else 0
        has_mp4 = bool([f for f in p.glob('*.mp4') if f.parent == p])

        if has_mp4:
            status = 'Complete'
        elif vid_count > 0:
            status = 'Ready for Concat'
        elif img_count > 0:
            status = 'Ready for VideoGen'
        elif has_plan:
            status = 'Ready for ImgGen'
        elif has_tr:
            status = 'Ready for Direction'
        elif has_audio:
            status = 'Ready for Transcription'
        else:
            status = 'Empty'
        return dict(name=p.name, has_audio=has_audio, has_transcription=has_tr,
                    has_plan=has_plan, img_count=img_count, vid_count=vid_count,
                    has_mp4=has_mp4, status=status)

    def _open_project_folder(self, event=None):
        sel = self.tree.selection()
        if not sel:
            return
        name = self.tree.item(sel[0])['values'][0]
        folder = SCRIPT_DIR / 'projects' / name
        if folder.exists():
            os.startfile(str(folder))

    def _get_selected(self) -> Optional[Path]:
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Warning", "Select a project first")
            return None
        name = self.tree.item(sel[0])['values'][0]
        return SCRIPT_DIR / 'projects' / name

    def _update_status(self):
        n = self.active_tasks
        if n > 0:
            self.status_label.config(text=f"Running: {n} task{'s' if n > 1 else ''}", fg=COLORS['accent'])
            self.progress_bar.start(15)
        else:
            self.status_label.config(text="Ready", fg=COLORS['text_dim'])
            self.progress_bar.stop()

    def _run_in_thread(self, func, *args, task_name=""):
        self.active_tasks += 1
        self.root.after(0, self._update_status)
        self.app.log(f"Started: {task_name}", "INFO", tab="control")
        t_start = time.time()
        def worker():
            try:
                with capture_stdout(self.app.log_queue, "control"):
                    func(*args)
                elapsed = time.time() - t_start
                m, s = divmod(int(elapsed), 60)
                self.app.log(f"Done: {task_name} ({m}m {s}s)", "SUCCESS", tab="control")
            except Exception as e:
                elapsed = time.time() - t_start
                m, s = divmod(int(elapsed), 60)
                self.app.log(f"Error in {task_name} after {m}m {s}s: {e}", "ERROR", tab="control")
            finally:
                self.active_tasks = max(0, self.active_tasks - 1)
                self.root.after(0, self._update_status)
                self.root.after(0, self.refresh_projects)
        threading.Thread(target=worker, daemon=True).start()

    def _run_subprocess_in_thread(self, args_list, cwd=None, task_name="", env=None):
        """Run subprocess with stdout piped to GUI log."""
        self.active_tasks += 1
        self.root.after(0, self._update_status)
        self.app.log(f"Started: {task_name}", "INFO", tab="control")
        t_start = time.time()
        def worker():
            try:
                proc = subprocess.Popen(
                    args_list, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, encoding='utf-8', errors='replace',
                    cwd=cwd or str(SCRIPT_DIR), env=env
                )
                for line in proc.stdout:
                    line = line.rstrip()
                    if not line:
                        continue
                    level = 'INFO'
                    low = line.lower()
                    if any(x in low for x in ['error', 'fail', 'traceback']):
                        level = 'ERROR'
                    elif any(x in low for x in ['[ok]', 'success', 'complete', 'saved']):
                        level = 'SUCCESS'
                    elif any(x in low for x in ['warn', 'skip', 'retry']):
                        level = 'WARNING'
                    self.app.log(line, level, tab="control")
                proc.wait()
                elapsed = time.time() - t_start
                m, s = divmod(int(elapsed), 60)
                if proc.returncode == 0:
                    self.app.log(f"Done: {task_name} ({m}m {s}s)", "SUCCESS", tab="control")
                else:
                    self.app.log(f"Failed: {task_name} (exit {proc.returncode}, {m}m {s}s)", "ERROR", tab="control")
            except Exception as e:
                self.app.log(f"Error in {task_name}: {e}", "ERROR", tab="control")
            finally:
                self.active_tasks = max(0, self.active_tasks - 1)
                self.root.after(0, self._update_status)
                self.root.after(0, self.refresh_projects)
        threading.Thread(target=worker, daemon=True).start()

    # ── Stage Settings Dialog ──────────────────────────────────────
    def _show_stage_dialog(self, title, defaults: dict, on_run):
        """Show a dialog with stage defaults. User can edit or approve as-is.
        defaults = {label: (tk_var_class, default_value, options_or_range), ...}
        on_run(settings_dict) called if user confirms.
        """
        dlg = tk.Toplevel(self.root)
        dlg.title(title)
        dlg.configure(bg=COLORS['bg_dark'])
        dlg.resizable(False, False)
        dlg.transient(self.root)
        dlg.grab_set()

        # Center on parent
        dlg.geometry("+%d+%d" % (self.root.winfo_x() + 200, self.root.winfo_y() + 150))

        ttk.Label(dlg, text=title, style="Header.TLabel").pack(padx=20, pady=(12, 4))

        settings_frame = ttk.Frame(dlg, style="Card.TFrame", padding=12)
        settings_frame.pack(fill=tk.X, padx=12, pady=4)

        vars_map = {}
        for label, (var_cls, default, opts) in defaults.items():
            row = ttk.Frame(settings_frame, style="Card.TFrame")
            row.pack(fill=tk.X, pady=3)
            ttk.Label(row, text=f"{label}:", style="Card.TLabel", width=18).pack(side=tk.LEFT)

            var = var_cls(value=default)
            vars_map[label] = var

            if isinstance(opts, list):
                ttk.Combobox(row, textvariable=var, values=opts, width=16, state='readonly').pack(side=tk.LEFT, padx=4)
            elif isinstance(opts, tuple) and len(opts) == 2:
                tk.Spinbox(row, textvariable=var, from_=opts[0], to=opts[1], width=6,
                           bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=4)
            else:
                ttk.Entry(row, textvariable=var, width=20).pack(side=tk.LEFT, padx=4)

        # Buttons
        btn_row = ttk.Frame(dlg, padding=8)
        btn_row.pack(fill=tk.X)
        result = {'confirmed': False}

        def confirm():
            result['confirmed'] = True
            dlg.destroy()

        def cancel():
            dlg.destroy()

        ttk.Button(btn_row, text="Run", command=confirm, style="Accent.TButton").pack(side=tk.RIGHT, padx=4)
        ttk.Button(btn_row, text="Cancel", command=cancel).pack(side=tk.RIGHT, padx=4)

        dlg.bind('<Return>', lambda e: confirm())
        dlg.bind('<Escape>', lambda e: cancel())
        dlg.wait_window()

        if result['confirmed']:
            settings = {k: v.get() for k, v in vars_map.items()}
            on_run(settings)

    # ── Per-stage runners ──────────────────────────────────────────

    def _run_script_tts(self):
        """Script → Audio: run TTS on a .txt script, put audio in ready_to_go/."""
        script_path = filedialog.askopenfilename(
            title="Select script file (.txt)",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if not script_path:
            return
        script_file = Path(script_path)

        # Copy script to ready_to_go/ so tts_runner.py picks it up
        rtg = SCRIPT_DIR / 'ready_to_go'
        rtg.mkdir(exist_ok=True)
        dst = rtg / script_file.name
        if not dst.exists():
            shutil.copy2(str(script_file), str(dst))
        self.app.log(f"Script copied to ready_to_go/: {script_file.name}", "INFO", tab="control")

        defaults = {
            'TTS service': (tk.StringVar, getattr(config, 'TTS_SERVICE', 'mat3u'), ['mat3u', 'csv666']),
        }

        def do_run(s):
            env = os.environ.copy()
            env['TTS_SERVICE'] = s['TTS service']
            cmd = ['python', str(AGENT_DIR / 'tools' / 'tts_runner.py'), '--mode', 'silent', '--tts-only']
            self._run_subprocess_in_thread(cmd, cwd=str(AGENT_DIR), task_name=f"TTS {script_file.stem}", env=env)

        self._show_stage_dialog(f"Script → Audio — {script_file.name}", defaults, do_run)

    def _run_script_video(self):
        """Script → Video: run Script Director (prose/screenplay) → montage plan + prompts."""
        script_path = filedialog.askopenfilename(
            title="Select script file (.txt)",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if not script_path:
            return
        script_file = Path(script_path)

        style_path = filedialog.askopenfilename(
            title="Select style guide (.txt) — Cancel to skip",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        # style_path may be empty (cancelled) — style guide is optional

        defaults = {
            'Script type': (tk.StringVar, 'prose', ['prose', 'screenplay']),
            'Direction':   (tk.StringVar, '2-pass', ['1-pass', '2-pass']),
            'Clip mode':   (tk.StringVar, 'video', ['video', 'slideshow']),
            'Post action': (tk.StringVar, 'skip', ['skip', 'veo_i2v', 'fastgen_i2v', 't2v', 'components']),
        }

        def do_run(s):
            project_name = script_file.stem
            projects_dir = SCRIPT_DIR / 'projects'
            projects_dir.mkdir(exist_ok=True)
            (projects_dir / project_name).mkdir(exist_ok=True)

            cmd = ['python', str(AGENT_DIR / 'agent.py'), 'script',
                   '--script', str(script_file),
                   '--project', project_name,
                   '--script-type', s['Script type'],
                   '--clip-mode', s['Clip mode'],
                   '--post-action', s['Post action']]
            if style_path:
                cmd += ['--style', style_path]
            if s['Direction'] == '2-pass':
                cmd.append('--two-pass')

            self.app.log(
                f"Script Director: {script_file.name} ({s['Script type']}, {s['Direction']})...",
                "INFO", tab="control"
            )
            self._run_subprocess_in_thread(cmd, cwd=str(AGENT_DIR), task_name=f"ScriptDir {project_name}")

        self._show_stage_dialog(f"Script → Video — {script_file.name}", defaults, do_run)

    def _run_transcribe(self):
        # Always ask for audio file — create project from it
        audio_path = filedialog.askopenfilename(
            title="Select audio file to transcribe",
            filetypes=[("Audio", "*.mp3 *.wav *.flac *.m4a *.aac"), ("All", "*.*")]
        )
        if not audio_path:
            return
        audio_file = Path(audio_path)
        projects_dir = SCRIPT_DIR / 'projects'
        projects_dir.mkdir(exist_ok=True)
        project_name = audio_file.stem
        p = projects_dir / project_name
        p.mkdir(exist_ok=True)
        dst = p / audio_file.name
        if not dst.exists():
            shutil.copy2(str(audio_file), str(dst))
        audio = [dst]
        self.app.log(f"Project: {project_name}", "INFO", tab="control")
        self.refresh_projects()
        for item in self.tree.get_children():
            if self.tree.item(item)['values'][0] == project_name:
                self.tree.selection_set(item)
                self.tree.see(item)
                break

        defaults = {
            'Language': (tk.StringVar, config.ASSEMBLYAI_LANGUAGE_CODE,
                        ['ru', 'en', 'es', 'de', 'fr', 'it', 'pt', 'zh', 'pl']),
            'Speech model': (tk.StringVar, 'universal-3-pro',
                            ['universal-3-pro', 'universal-2']),
            'Segmentation': (tk.StringVar, getattr(config, 'ASSEMBLYAI_SEGMENTATION_MODE', 'sentences'),
                            ['sentences', 'paragraphs', 'words']),
        }

        def do_run(s):
            from modules.transcriber import transcribe_audio
            out = str(p / 'transcription.json')
            os.environ['ASSEMBLYAI_LANGUAGE_CODE'] = s['Language']
            os.environ['ASSEMBLYAI_SEGMENTATION_MODE'] = s['Segmentation']
            self.app.log(f"Transcribing {audio[0].name} ({s['Language']}, {s['Speech model']})...", "INFO", tab="control")
            self._run_in_thread(transcribe_audio, str(audio[0]), out, task_name=f"Transcribe {p.name}")

        self._show_stage_dialog(f"Transcribe — {p.name}", defaults, do_run)

    def _run_direct(self):
        p = self._get_selected()
        if not p:
            return
        tr = p / 'transcription.json'
        if not tr.exists():
            messagebox.showerror("Error", "No transcription.json")
            return
        styles = list(p.glob('*style*')) + list(p.glob('*.txt'))
        style = str(styles[0]) if styles else ''

        defaults = {
            'Two-pass': (tk.StringVar, 'true' if config.GEMINI_TWO_PASS else 'false', ['true', 'false']),
            'Clip mode': (tk.StringVar, 'video', ['video', 'slideshow']),
            'Clip min': (tk.IntVar, config.VIDEO_CLIP_MIN_DURATION, (1, 30)),
            'Clip max': (tk.IntVar, config.VIDEO_CLIP_MAX_DURATION, (2, 60)),
            'Intro zone (s)': (tk.IntVar, getattr(config, 'INTRO_BLOCK_DURATION', 45), (0, 120)),
            'Intro clip min': (tk.IntVar, getattr(config, 'INTRO_CLIP_MIN_DURATION', 0), (0, 30)),
            'Intro clip max': (tk.IntVar, getattr(config, 'INTRO_CLIP_MAX_DURATION', 0), (0, 60)),
        }

        def do_run(s):
            from modules.director import direct_project
            os.environ['GEMINI_TWO_PASS'] = s['Two-pass']
            cm = s['Clip mode']
            if cm == 'video':
                os.environ['VIDEO_CLIP_MIN_DURATION'] = str(s['Clip min'])
                os.environ['VIDEO_CLIP_MAX_DURATION'] = str(s['Clip max'])
            else:
                os.environ['SLIDESHOW_CLIP_MIN_DURATION'] = str(s['Clip min'])
                os.environ['SLIDESHOW_CLIP_MAX_DURATION'] = str(s['Clip max'])
            os.environ['INTRO_BLOCK_DURATION'] = str(s['Intro zone (s)'])
            os.environ['INTRO_CLIP_MIN_DURATION'] = str(s['Intro clip min'])
            os.environ['INTRO_CLIP_MAX_DURATION'] = str(s['Intro clip max'])
            self.app.log(f"Directing {p.name} (two-pass={s['Two-pass']}, {cm} {s['Clip min']}-{s['Clip max']}s)...", "INFO", tab="control")
            self._run_in_thread(direct_project, str(tr), style, str(p), p.name, task_name=f"Direct {p.name}")

        self._show_stage_dialog(f"Direct — {p.name}", defaults, do_run)

    def _fetch_fastgen_quota(self, api_key):
        """Fetch remaining quota for a FastGen API key."""
        try:
            from modules.fastgen import FastGenClient, parse_usage_remaining, parse_usage_threads
            client = FastGenClient(api_key=api_key)
            usage = client.get_usage()
            remaining = parse_usage_remaining(usage)
            threads = parse_usage_threads(usage)
            return remaining, threads
        except Exception:
            return None, '?'

    def _run_imagegen(self):
        p = self._get_selected()
        if not p:
            return

        # Fetch quotas
        main_key = getattr(config, 'FASTGEN_API_KEY', '')
        backup_key = getattr(config, 'FASTGEN_API_KEY_BACKUP', '')
        main_q, main_t = self._fetch_fastgen_quota(main_key) if main_key else (None, '?')
        backup_q, backup_t = self._fetch_fastgen_quota(backup_key) if backup_key else (None, '?')
        mq = main_q if main_q is not None else '?'
        bq = backup_q if backup_q is not None else '?'

        # Custom dialog with dynamic fields
        dlg = tk.Toplevel(self.root)
        dlg.title(f"Image Gen — {p.name}")
        dlg.configure(bg=COLORS['bg_dark'])
        dlg.resizable(False, False)
        dlg.transient(self.root)
        dlg.grab_set()
        dlg.geometry("+%d+%d" % (self.root.winfo_x() + 200, self.root.winfo_y() + 150))

        ttk.Label(dlg, text=f"Image Gen — {p.name}", style="Header.TLabel").pack(padx=20, pady=(12, 4))

        sf = ttk.Frame(dlg, style="Card.TFrame", padding=12)
        sf.pack(fill=tk.X, padx=12, pady=4)

        # Engine selector
        engine_var = tk.StringVar(value='fastgen')
        row = ttk.Frame(sf, style="Card.TFrame"); row.pack(fill=tk.X, pady=3)
        ttk.Label(row, text="Engine:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        engine_cb = ttk.Combobox(row, textvariable=engine_var, values=['fastgen', 'veononstop'], width=16, state='readonly')
        engine_cb.pack(side=tk.LEFT, padx=4)

        # FastGen fields
        fg_frame = ttk.Frame(sf, style="Card.TFrame")

        r1 = ttk.Frame(fg_frame, style="Card.TFrame"); r1.pack(fill=tk.X, pady=3)
        ttk.Label(r1, text="API Key:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        api_key_var = tk.StringVar(value='main')
        ttk.Combobox(r1, textvariable=api_key_var, values=['main', 'backup'], width=16, state='readonly').pack(side=tk.LEFT, padx=4)

        r1q = ttk.Frame(fg_frame, style="Card.TFrame"); r1q.pack(fill=tk.X, pady=1)
        ttk.Label(r1q, text="", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        ttk.Label(r1q, text=f"Main: {mq}/hr, {main_t} thr  |  Backup: {bq}/hr, {backup_t} thr",
                  style="Dim.TLabel").pack(side=tk.LEFT)

        r2 = ttk.Frame(fg_frame, style="Card.TFrame"); r2.pack(fill=tk.X, pady=3)
        ttk.Label(r2, text="Model:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        fg_model_var = tk.StringVar(value=FASTGEN_KEY_TO_NAME.get(config.FASTGEN_MODEL, config.FASTGEN_MODEL))
        ttk.Combobox(r2, textvariable=fg_model_var, values=FASTGEN_DISPLAY, width=16, state='readonly').pack(side=tk.LEFT, padx=4)

        r3 = ttk.Frame(fg_frame, style="Card.TFrame"); r3.pack(fill=tk.X, pady=3)
        ttk.Label(r3, text="Aspect:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        fg_aspect_var = tk.StringVar(value=config.FASTGEN_ASPECT_RATIO)
        ttk.Combobox(r3, textvariable=fg_aspect_var, values=['landscape', 'portrait', 'square'], width=16, state='readonly').pack(side=tk.LEFT, padx=4)

        r4 = ttk.Frame(fg_frame, style="Card.TFrame"); r4.pack(fill=tk.X, pady=3)
        ttk.Label(r4, text="Parallel:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        fg_par_var = tk.IntVar(value=config.FASTGEN_MAX_PARALLEL)
        tk.Spinbox(r4, textvariable=fg_par_var, from_=1, to=20, width=6,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=4)

        # VeoNonStop fields
        veo_frame = ttk.Frame(sf, style="Card.TFrame")

        rv1 = ttk.Frame(veo_frame, style="Card.TFrame"); rv1.pack(fill=tk.X, pady=3)
        ttk.Label(rv1, text="Mode:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        veo_mode_var = tk.StringVar(value='banana')
        ttk.Combobox(rv1, textvariable=veo_mode_var, values=['banana', 'banana+ref', 'imagen'], width=16, state='readonly').pack(side=tk.LEFT, padx=4)

        rv2 = ttk.Frame(veo_frame, style="Card.TFrame")
        ttk.Label(rv2, text="Model:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        veo_model_var = tk.StringVar(value='Banana Pro')
        ttk.Combobox(rv2, textvariable=veo_model_var, values=BANANA_DISPLAY, width=16, state='readonly').pack(side=tk.LEFT, padx=4)

        rv3 = ttk.Frame(veo_frame, style="Card.TFrame"); rv3.pack(fill=tk.X, pady=3)
        ttk.Label(rv3, text="Parallel:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        veo_par_var = tk.IntVar(value=config.VEONONSTOP_MAX_PARALLEL)
        tk.Spinbox(rv3, textvariable=veo_par_var, from_=1, to=24, width=6,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=4)

        # Ref dir row (shown only for banana+ref)
        veo_ref_dir: list = [None]
        rv_ref = ttk.Frame(veo_frame, style="Card.TFrame")
        ttk.Label(rv_ref, text="Ref dir:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        ref_path_lbl = ttk.Label(rv_ref, text="(project/ref/)", style="Dim.TLabel")
        ref_path_lbl.pack(side=tk.LEFT, padx=4, fill=tk.X, expand=True)
        def _browse_veo_ref():
            d = filedialog.askdirectory(title="Select ref images folder", initialdir=str(p))
            if d:
                veo_ref_dir[0] = d
                ref_path_lbl.config(text=Path(d).name)
        ttk.Button(rv_ref, text="Browse…", command=_browse_veo_ref).pack(side=tk.RIGHT, padx=4)

        # Show/hide model and ref rows based on veo mode
        def on_veo_mode_change(*_):
            m = veo_mode_var.get()
            if m == 'imagen':
                rv2.pack_forget()
                rv_ref.pack_forget()
            elif m == 'banana+ref':
                rv2.pack(fill=tk.X, pady=3, after=rv1)
                rv_ref.pack(fill=tk.X, pady=3)
            else:
                rv2.pack(fill=tk.X, pady=3, after=rv1)
                rv_ref.pack_forget()

        veo_mode_var.trace_add('write', on_veo_mode_change)
        on_veo_mode_change()

        # Toggle visibility
        def on_engine_change(*_):
            if engine_var.get() == 'fastgen':
                veo_frame.pack_forget()
                fg_frame.pack(fill=tk.X, pady=4)
            else:
                fg_frame.pack_forget()
                veo_frame.pack(fill=tk.X, pady=4)

        engine_var.trace_add('write', on_engine_change)
        on_engine_change()  # show fastgen by default

        # Buttons
        btn_row = ttk.Frame(dlg, padding=8); btn_row.pack(fill=tk.X)
        result = {'confirmed': False}
        def confirm():
            result['confirmed'] = True
            dlg.destroy()
        ttk.Button(btn_row, text="Run", command=confirm, style="Accent.TButton").pack(side=tk.RIGHT, padx=4)
        ttk.Button(btn_row, text="Cancel", command=dlg.destroy).pack(side=tk.RIGHT, padx=4)
        dlg.bind('<Return>', lambda e: confirm())
        dlg.bind('<Escape>', lambda e: dlg.destroy())
        dlg.wait_window()

        if not result['confirmed']:
            return

        if engine_var.get() == 'fastgen':
            os.environ['FASTGEN_MODEL'] = FASTGEN_NAME_TO_KEY.get(fg_model_var.get(), fg_model_var.get())
            os.environ['FASTGEN_ASPECT_RATIO'] = fg_aspect_var.get()
            os.environ['FASTGEN_MAX_PARALLEL'] = str(fg_par_var.get())
            key_name = api_key_var.get()
            if key_name == 'backup' and backup_key:
                os.environ['FASTGEN_API_KEY'] = backup_key
            elif main_key:
                os.environ['FASTGEN_API_KEY'] = main_key
            from modules.fastgen import generate_all_images
            self.app.log(f"ImageGen (FastGen {fg_model_var.get()}, {key_name}) for {p.name}...", "INFO", tab="control")
            self._run_in_thread(generate_all_images, str(p), task_name=f"ImageGen {p.name}")
        else:
            os.environ['VEONONSTOP_MAX_PARALLEL'] = str(veo_par_var.get())
            os.environ['VEONONSTOP_BANANA_MODEL'] = BANANA_NAME_TO_KEY.get(veo_model_var.get(), 'GEM_PIX_2')
            mode_str = veo_mode_var.get()
            actual_mode = 'banana_ref' if mode_str == 'banana+ref' else mode_str
            ref_d = veo_ref_dir[0]
            from modules.imggen import generate_all_images as veo_gen
            self.app.log(f"ImageGen (VeoNonStop {mode_str}, {veo_model_var.get()}) for {p.name}...", "INFO", tab="control")
            self._run_in_thread(lambda: veo_gen(str(p), mode=actual_mode, ref_dir=ref_d), task_name=f"ImageGen {p.name}")

    def _run_videogen(self):
        p = self._get_selected()
        if not p:
            return

        defaults = {
            'Mode': (tk.StringVar, 'i2v', ['i2v', 't2v', 'components']),
            'Aspect ratio': (tk.StringVar, config.VEONONSTOP_ASPECT_RATIO, ['16:9', '9:16', '1:1']),
            'Parallel': (tk.IntVar, config.VEONONSTOP_MAX_PARALLEL, (1, 24)),
        }

        def do_run(s):
            os.environ['VEONONSTOP_MAX_PARALLEL'] = str(s['Parallel'])
            os.environ['VEONONSTOP_ASPECT_RATIO'] = s['Aspect ratio']
            from modules.veo_video import generate_all_videos
            self.app.log(f"VideoGen ({s['Mode']}, {s['Aspect ratio']}, x{s['Parallel']}) for {p.name}...", "INFO", tab="control")
            self._run_in_thread(generate_all_videos, str(p), task_name=f"VideoGen {p.name}")

        self._show_stage_dialog(f"Video Gen — {p.name}", defaults, do_run)

    def _run_concat(self):
        p = self._get_selected()
        if not p:
            return
        plan = p / 'montage_plan.json'
        if not plan.exists():
            messagebox.showerror("Error", "No montage_plan.json")
            return

        defaults = {
            'Quality':          (tk.StringVar, '720p',   ['720p', '1080p']),
            'Bitrate':          (tk.StringVar, '10M',    ['5M', '8M', '10M', '15M', '20M']),
            'Watermark':        (tk.StringVar, 'as_is',  ['as_is', 'logo', 'blur']),
            'Force AMD':        (tk.StringVar, 'yes',    ['yes', 'no']),
            'Keep VEO Sound':   (tk.StringVar, 'no',     ['no', 'yes']),
            'VEO Audio Inline': (tk.StringVar, 'yes',    ['yes', 'no']),
        }

        def do_run(s):
            cmd = ['python', str(SCRIPT_DIR / 'video_concat.py'),
                    'montage_plan.json', '-o', f'{p.name}.mp4', '-b', s['Bitrate']]
            if s['Force AMD'] == 'yes':
                cmd.append('--force-amd')
            if s['Watermark'] == 'blur':
                cmd.append('--blur-borders')
            if s['Quality'] == '1080p':
                cmd.extend(['-r', '1080'])
            if s['Keep VEO Sound'] == 'yes':
                cmd.append('--keep-veo-sound')
            if s['VEO Audio Inline'] == 'yes':
                cmd.append('--veo-audio-inline')
            self._run_subprocess_in_thread(cmd, cwd=str(p), task_name=f"Concat {p.name}")

        self._show_stage_dialog(f"Concat — {p.name}", defaults, do_run)

    def _run_ytpack(self):
        p = self._get_selected()
        if not p:
            return

        defaults = {
            'Languages': (tk.StringVar, getattr(config, 'YT_PACK_LANGUAGES', 'ru,en'), None),
            'Subtitles': (tk.StringVar, 'true' if getattr(config, 'YT_PACK_SUBTITLES', False) else 'false', ['true', 'false']),
            'Description': (tk.StringVar, 'true' if getattr(config, 'YT_PACK_DESCRIPTION', False) else 'false', ['true', 'false']),
            'Covers': (tk.StringVar, 'true' if getattr(config, 'YT_PACK_COVERS', False) else 'false', ['true', 'false']),
        }

        def do_run(s):
            from modules.yt_packer import run_yt_packer
            os.environ['YT_PACK_LANGUAGES'] = s['Languages']
            os.environ['YT_PACK_SUBTITLES'] = s['Subtitles']
            os.environ['YT_PACK_DESCRIPTION'] = s['Description']
            os.environ['YT_PACK_COVERS'] = s['Covers']
            self.app.log(f"YT Packing {p.name} (langs={s['Languages']})...", "INFO", tab="control")
            self._run_in_thread(run_yt_packer, str(p), task_name=f"YT Pack {p.name}")

        self._show_stage_dialog(f"YT Pack — {p.name}", defaults, do_run)

    def _run_dryrun(self):
        self._run_subprocess_in_thread(
            ['python', str(AGENT_DIR / 'agent.py'), 'dry-run'],
            task_name="Dry-Run")

    def _run_mock(self):
        self._run_subprocess_in_thread(
            ['python', str(AGENT_DIR / 'agent.py'), 'dry-run', '--mock'],
            task_name="Mock Run")


# ════════════════════════════════════════════════════════════════════
# TAB: PROMPTS EDITOR
# ════════════════════════════════════════════════════════════════════

_PROMPT_FILES = [
    ("Director Instruction (pass 2)",   AGENT_DIR / "prompts" / "director_instruction.txt"),
    ("Director Instruction (pass 1)",   AGENT_DIR / "prompts" / "director_instruction_pass1.txt"),
    ("Director Pause Guide",            AGENT_DIR / "prompts" / "director_pause_guide.txt"),
    ("Script Director — Prose",         AGENT_DIR / "prompts" / "script_director_prose.txt"),
    ("Script Director — Screenplay",    AGENT_DIR / "prompts" / "script_director_screenplay.txt"),
    ("Rewrite Prompt (censorship)",     AGENT_DIR / "prompts" / "rewrite_prompt.txt"),
    ("Ref Remix (Grok)",                AGENT_DIR / "prompts" / "ref_remix_prompt.txt"),
    ("i2v Remix (Grok)",                AGENT_DIR / "prompts" / "i2v_remix_prompt.txt"),
    ("YT Packer Prompt",                AGENT_DIR / "prompts" / "yt_packer_prompt.txt"),
]

class PromptsTab:
    """Prompt files editor — view and edit all agent prompt files."""

    def __init__(self, notebook, app: VarAgentGUI):
        self.app = app
        self.frame = ttk.Frame(notebook)
        self._current_path: Optional[Path] = None
        self._modified = False
        self.create_ui()

    def create_ui(self):
        # Top bar
        top = ttk.Frame(self.frame)
        top.pack(fill=tk.X, padx=10, pady=(8, 0))
        self.save_btn = ttk.Button(top, text="Save", command=self._save,
                                   style="Accent.TButton")
        self.save_btn.pack(side=tk.LEFT, padx=(0, 4))
        ttk.Button(top, text="Reload", command=self._reload).pack(side=tk.LEFT, padx=4)
        ttk.Button(top, text="Open Folder", command=self._open_folder).pack(side=tk.LEFT, padx=4)
        self.status_lbl = ttk.Label(top, text="", style="Dim.TLabel")
        self.status_lbl.pack(side=tk.LEFT, padx=10)
        self.file_lbl = ttk.Label(top, text="", style="Dim.TLabel")
        self.file_lbl.pack(side=tk.RIGHT, padx=4)

        # Body: left list + right editor
        body = ttk.Frame(self.frame)
        body.pack(fill=tk.BOTH, expand=True, padx=10, pady=6)

        # Left: prompt file list
        left = ttk.Frame(body, style="Card.TFrame")
        left.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 6))
        ttk.Label(left, text="Prompts", style="Section.TLabel").pack(anchor=tk.W, padx=10, pady=(8, 4))
        self.listbox = tk.Listbox(left, width=28, bg=COLORS['bg_card'], fg=COLORS['text'],
                                   font=FONT_DIM, selectbackground=COLORS['accent'],
                                   selectforeground='#ffffff', relief=tk.FLAT,
                                   borderwidth=0, activestyle='none')
        for label, _ in _PROMPT_FILES:
            self.listbox.insert(tk.END, f"  {label}")
        self.listbox.pack(fill=tk.Y, expand=True, padx=4, pady=(0, 8))
        self.listbox.bind("<<ListboxSelect>>", self._on_select)

        # Right: text editor
        right = ttk.Frame(body, style="Card.TFrame")
        right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        right.rowconfigure(0, weight=1)
        right.columnconfigure(0, weight=1)
        self.text = tk.Text(right, bg=COLORS['bg_input'], fg=COLORS['text'],
                             insertbackground=COLORS['text'], font=FONT_LOG,
                             relief=tk.FLAT, wrap=tk.WORD, padx=10, pady=8,
                             undo=True)
        vsb = ttk.Scrollbar(right, orient=tk.VERTICAL, command=self.text.yview)
        self.text.configure(yscrollcommand=vsb.set)
        self.text.grid(row=0, column=0, sticky='nsew', padx=(6, 0), pady=6)
        vsb.grid(row=0, column=1, sticky='ns', pady=6, padx=(0, 4))
        self.text.bind("<<Modified>>", self._on_text_modified)

        # Select first by default
        self.listbox.selection_set(0)
        self.frame.after(100, lambda: self._load_file(_PROMPT_FILES[0][1]))

    def _on_select(self, event=None):
        sel = self.listbox.curselection()
        if not sel:
            return
        if self._modified and self._current_path:
            if not messagebox.askyesno("Unsaved changes",
                                        f"Discard changes to {self._current_path.name}?"):
                return
        _, path = _PROMPT_FILES[sel[0]]
        self._load_file(path)

    def _load_file(self, path: Path):
        self._current_path = path
        self.text.edit_modified(False)
        self._modified = False
        self.text.delete('1.0', tk.END)
        if path.exists():
            self.text.insert('1.0', path.read_text(encoding='utf-8'))
        else:
            self.text.insert('1.0', f"# File not found: {path}\n")
        self.text.edit_modified(False)
        self.file_lbl.config(text=str(path.relative_to(AGENT_DIR.parent)
                                       if path.is_relative_to(AGENT_DIR.parent) else path))
        self.status_lbl.config(text="")

    def _on_text_modified(self, event=None):
        if self.text.edit_modified():
            self._modified = True
            self.status_lbl.config(text="● unsaved", foreground=COLORS.get('yellow', '#f5c842'))

    def _save(self):
        if not self._current_path:
            return
        content = self.text.get('1.0', 'end-1c')
        self._current_path.write_text(content, encoding='utf-8')
        # Sync to PORTABLE
        portable_path = Path(str(self._current_path).replace('VARAGENT_API', 'VARAGENT_API_PORTABLE'))
        if portable_path.parent.exists():
            portable_path.write_text(content, encoding='utf-8')
        self.text.edit_modified(False)
        self._modified = False
        self.status_lbl.config(text="Saved", foreground=COLORS['green'])
        self.frame.after(3000, lambda: self.status_lbl.config(text=""))

    def _reload(self):
        if self._current_path:
            self._load_file(self._current_path)

    def _open_folder(self):
        folder = AGENT_DIR / "prompts"
        if folder.exists():
            os.startfile(str(folder))


# ════════════════════════════════════════════════════════════════════
# TAB 3: SETTINGS (.env Editor)
# ════════════════════════════════════════════════════════════════════

class SettingsTab:
    """.env editor — view and edit all config values."""

    def __init__(self, notebook, app: VarAgentGUI):
        self.app = app
        self.root = app.root
        self.frame = ttk.Frame(notebook)
        self.env_entries = {}
        self.env_lines = []
        self.create_ui()

    def create_ui(self):
        # Top buttons
        top = ttk.Frame(self.frame)
        top.pack(fill=tk.X, padx=10, pady=(8, 0))
        ttk.Button(top, text="Save .env", command=self._save_env, style="Accent.TButton").pack(side=tk.LEFT, padx=4)
        ttk.Button(top, text="Reload", command=self._load_env_editor).pack(side=tk.LEFT, padx=4)
        self.save_status = ttk.Label(top, text="", style="Dim.TLabel")
        self.save_status.pack(side=tk.LEFT, padx=8)

        # Scrollable two-column layout
        outer = ttk.Frame(self.frame)
        outer.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        canvas = tk.Canvas(outer, bg=COLORS['bg_dark'], highlightthickness=0)
        scrollbar = ttk.Scrollbar(outer, orient=tk.VERTICAL, command=canvas.yview)
        self.scroll_inner = ttk.Frame(canvas, style="TFrame")
        self.scroll_inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        self._canvas_win = canvas.create_window((0, 0), window=self.scroll_inner, anchor=tk.NW)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self._canvas = canvas
        # Stretch inner frame to canvas width
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(self._canvas_win, width=e.width))
        _mw = lambda e: canvas.yview_scroll(-1 * (e.delta // 120), "units")
        canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", _mw))
        canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))

        # Two columns
        self.col_left = ttk.Frame(self.scroll_inner, style="TFrame")
        self.col_left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 4))
        self.col_right = ttk.Frame(self.scroll_inner, style="TFrame")
        self.col_right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(4, 0))

        self.root.after(200, self._load_env_editor)

    def _load_env_editor(self):
        env_path = AGENT_DIR / '.env'
        if not env_path.exists():
            return
        self.env_entries = {}
        self.env_lines = []
        for widget in self.col_left.winfo_children():
            widget.destroy()
        for widget in self.col_right.winfo_children():
            widget.destroy()

        with open(env_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        # Parse into sections
        sections = []
        current_title = "General"
        current_items = []
        for line in lines:
            raw = line.rstrip('\n')
            self.env_lines.append(raw)
            if raw.startswith('# ====') or raw.startswith('# ----'):
                title = raw.strip('# =- ')
                if title:
                    if current_items:
                        sections.append((current_title, current_items))
                    current_title = title
                    current_items = []
            elif '=' in raw and not raw.startswith('#'):
                key, _, val = raw.partition('=')
                current_items.append((key.strip(), val.strip()))
        if current_items:
            sections.append((current_title, current_items))

        # Distribute sections to two columns (left-right by count balance)
        left_count = 0
        right_count = 0
        for title, items in sections:
            if left_count <= right_count:
                col = self.col_left
                left_count += len(items) + 1
            else:
                col = self.col_right
                right_count += len(items) + 1

            card = ttk.Frame(col, style="Card.TFrame", padding=10)
            card.pack(fill=tk.X, pady=4, padx=2)
            ttk.Label(card, text=title, style="Section.TLabel").pack(anchor=tk.W, pady=(0, 4))
            for key, val in items:
                row = ttk.Frame(card, style="Card.TFrame")
                row.pack(fill=tk.X, pady=1)
                ttk.Label(row, text=key, style="Dim.TLabel", width=30).pack(side=tk.LEFT)
                opts = ENV_DROPDOWN_OPTIONS.get(key)
                if opts:
                    entry = ttk.Combobox(row, values=opts, state='normal', font=FONT_DIM)
                    # Match current .env value to a display option (e.g. "GEM_PIX_2" → "GEM_PIX_2 — Banana Pro")
                    matched = next((o for o in opts if o.split(' \u2014')[0].strip() == val), val)
                    entry.set(matched)
                else:
                    show = '•' if 'API_KEY' in key.upper() else ''
                    entry = tk.Entry(row, bg=COLORS['bg_input'], fg=COLORS['text'],
                                     insertbackground=COLORS['text'], relief=tk.FLAT, show=show,
                                     font=FONT_DIM)
                    entry.insert(0, val)
                entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)
                self.env_entries[key] = entry

    def _save_env(self):
        env_path = AGENT_DIR / '.env'
        new_lines = []
        with open(env_path, 'r', encoding='utf-8') as f:
            for line in f:
                raw = line.rstrip('\n')
                if '=' in raw and not raw.startswith('#'):
                    key = raw.split('=', 1)[0].strip()
                    if key in self.env_entries:
                        new_val = self.env_entries[key].get()
                        # Strip display label suffix (e.g. "GEM_PIX_2 — Banana Pro" → "GEM_PIX_2")
                        if ' \u2014 ' in new_val:
                            new_val = new_val.split(' \u2014 ')[0].strip()
                        new_lines.append(f"{key}={new_val}")
                        continue
                new_lines.append(raw)

        with open(env_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(new_lines) + '\n')

        # Reload config
        try:
            from dotenv import load_dotenv
            load_dotenv(str(env_path), override=True)
        except ImportError:
            pass
        importlib.reload(config)
        self.save_status.config(text="Saved + reloaded", foreground=COLORS['green'])
        self.root.after(3000, lambda: self.save_status.config(text=""))
        self.app.log(".env saved and config reloaded", "SUCCESS", tab="control")


# ════════════════════════════════════════════════════════════════════
# TAB 4: VEONONSTOP GENERATOR
# ════════════════════════════════════════════════════════════════════

class VeoGeneratorTab:
    """Standalone VeoNonStop generator — port of 2.py with VeoNonStopClient."""

    def __init__(self, notebook, app: VarAgentGUI):
        self.app = app
        self.root = app.root
        self.frame = ttk.Frame(notebook)
        self.output_dir = get_output_dir()

        # State
        self.api_key = tk.StringVar(value=config.VEONONSTOP_API_KEY or '')
        self.mode = tk.StringVar(value="video_t2v")
        self.aspect_ratio = tk.StringVar(value="16:9")
        self.generation_count = tk.IntVar(value=1)
        self.model_key = tk.StringVar(value="Banana Pro")
        self.thread_count = tk.IntVar(value=min(4, config.VEONONSTOP_MAX_PARALLEL))
        self.max_threads = 24

        self.reference_images = []
        self.video_images = []
        self.single_image = None
        self.single_image_list = []
        self.batch_start_images: list = []   # [{image_base64, mime_type, name}, ...]
        self.batch_end_images: list = []
        self.prompts_list = []
        self.is_generating = False
        self.last_video_result = None
        self.stats = {"success": 0, "failed": 0, "total": 0}
        self.stats_lock = threading.Lock()

        self.create_ui()

    def create_ui(self):
        content = ttk.Frame(self.frame)
        content.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        # LEFT column (fixed width)
        left = ttk.Frame(content)
        left.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 5))

        # RIGHT column
        right = ttk.Frame(content)
        right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self._build_left(left)
        self._build_right(right)

    def _build_left(self, parent):
        # API Key
        card = self.app.create_card(parent, "API Key")
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(fill=tk.X)
        self.api_entry = tk.Entry(row, textvariable=self.api_key, bg=COLORS['bg_input'],
                                  fg=COLORS['text'], insertbackground=COLORS['text'],
                                  relief=tk.FLAT, show='*')
        self.api_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 4))
        ttk.Button(row, text="Show", command=self._toggle_key, width=5).pack(side=tk.LEFT, padx=1)
        ttk.Button(row, text="Account", command=self.check_account, width=8).pack(side=tk.LEFT, padx=1)

        # Mode
        card = self.app.create_card(parent, "Generation Mode")
        modes = [
            ("Text to Video", "video_t2v"),
            ("Image to Video", "video_i2v"),
            ("Text2Video + References", "video_multi"),
            ("Batch Frame", "video_batch"),
            ("Banana (image)", "image_banana"),
            ("IMAGEN 3.5", "image_imagen"),
        ]
        for label, val in modes:
            ttk.Radiobutton(card, text=label, variable=self.mode, value=val,
                            command=self._on_mode_change).pack(anchor=tk.W)

        # Parameters
        card = self.app.create_card(parent, "Parameters")
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(fill=tk.X, pady=2)
        ttk.Label(row, text="Ratio:", style="Card.TLabel").pack(side=tk.LEFT)
        for v in ['16:9', '9:16', '1:1']:
            ttk.Radiobutton(row, text=v, variable=self.aspect_ratio, value=v).pack(side=tk.LEFT, padx=3)
        row2 = ttk.Frame(card, style="Card.TFrame")
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="Count:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row2, textvariable=self.generation_count, from_=1, to=8, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=4)

        # Threads
        card = self.app.create_card(parent, "Threads")
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(fill=tk.X)
        self.thread_label = ttk.Label(row, text=f"Threads: {self.thread_count.get()}", style="Card.TLabel")
        self.thread_label.pack(side=tk.LEFT)
        slider = tk.Scale(row, from_=1, to=self.max_threads, orient=tk.HORIZONTAL,
                          variable=self.thread_count, bg=COLORS['bg_card'], fg=COLORS['text'],
                          highlightbackground=COLORS['bg_card'], troughcolor=COLORS['bg_input'],
                          command=lambda v: self.thread_label.config(text=f"Threads: {v}"))
        slider.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)
        presets = ttk.Frame(card, style="Card.TFrame")
        presets.pack(fill=tk.X, pady=2)
        for n in [1, 4, 8, 12, 24]:
            ttk.Button(presets, text=str(n), width=3,
                       command=lambda x=n: self.thread_count.set(x)).pack(side=tk.LEFT, padx=2)

        # Images (dynamic based on mode)
        card = self.app.create_card(parent, "Images")
        # i2v: single image
        self.single_frame = ttk.Frame(card, style="Card.TFrame")
        self.single_img_label = ttk.Label(self.single_frame, text="No image", style="Dim.TLabel")
        self.single_img_label.pack(side=tk.LEFT)
        ttk.Button(self.single_frame, text="Select", command=self._select_single_image).pack(side=tk.RIGHT)

        # multi: image list
        self.multi_frame = ttk.Frame(card, style="Card.TFrame")
        multi_top = ttk.Frame(self.multi_frame, style="Card.TFrame")
        multi_top.pack(fill=tk.X)
        self.multi_label = ttk.Label(multi_top, text="Images: (0)", style="Dim.TLabel")
        self.multi_label.pack(side=tk.LEFT)
        ttk.Button(multi_top, text="Add", command=self._add_video_image).pack(side=tk.RIGHT, padx=2)
        ttk.Button(multi_top, text="Remove", command=self._remove_selected_video_image).pack(side=tk.RIGHT, padx=2)
        ttk.Button(multi_top, text="Clear", command=self._clear_video_images).pack(side=tk.RIGHT)
        self.multi_listbox = tk.Listbox(self.multi_frame, height=3, bg=COLORS['bg_input'],
                                        fg=COLORS['text'], font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        self.multi_listbox.pack(fill=tk.X, pady=(2, 0))

        # batch: start + end
        self.batch_frame = ttk.Frame(card, style="Card.TFrame")
        # Start images
        row_s = ttk.Frame(self.batch_frame, style="Card.TFrame")
        row_s.pack(fill=tk.X, pady=(0, 2))
        self.start_count_lbl = ttk.Label(row_s, text="Start (0):", style="Dim.TLabel")
        self.start_count_lbl.pack(side=tk.LEFT)
        ttk.Button(row_s, text="Clear", command=lambda: self._clear_batch("start")).pack(side=tk.RIGHT, padx=2)
        ttk.Button(row_s, text="Remove", command=lambda: self._remove_batch_item("start")).pack(side=tk.RIGHT, padx=2)
        ttk.Button(row_s, text="Select", command=lambda: self._select_batch("start")).pack(side=tk.RIGHT, padx=2)
        self.start_listbox = tk.Listbox(self.batch_frame, height=3, bg=COLORS['bg_input'],
                                         fg=COLORS['text'], font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        self.start_listbox.pack(fill=tk.X, pady=(0, 4))
        # End images
        row_e = ttk.Frame(self.batch_frame, style="Card.TFrame")
        row_e.pack(fill=tk.X, pady=(0, 2))
        self.end_count_lbl = ttk.Label(row_e, text="End (0):", style="Dim.TLabel")
        self.end_count_lbl.pack(side=tk.LEFT)
        ttk.Button(row_e, text="Clear", command=lambda: self._clear_batch("end")).pack(side=tk.RIGHT, padx=2)
        ttk.Button(row_e, text="Remove", command=lambda: self._remove_batch_item("end")).pack(side=tk.RIGHT, padx=2)
        ttk.Button(row_e, text="Select", command=lambda: self._select_batch("end")).pack(side=tk.RIGHT, padx=2)
        self.end_listbox = tk.Listbox(self.batch_frame, height=3, bg=COLORS['bg_input'],
                                       fg=COLORS['text'], font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        self.end_listbox.pack(fill=tk.X)
        self.batch_pairs_lbl = ttk.Label(self.batch_frame, text="", style="Dim.TLabel")
        self.batch_pairs_lbl.pack(anchor=tk.W, pady=(2, 0))

        # banana: model + refs
        self.model_frame = ttk.Frame(card, style="Card.TFrame")
        row_m = ttk.Frame(self.model_frame, style="Card.TFrame")
        row_m.pack(fill=tk.X)
        ttk.Label(row_m, text="Model:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Combobox(row_m, textvariable=self.model_key, values=BANANA_DISPLAY,
                     width=12, state='readonly').pack(side=tk.LEFT, padx=4)

        self.ref_frame = ttk.Frame(card, style="Card.TFrame")
        ref_row = ttk.Frame(self.ref_frame, style="Card.TFrame")
        ref_row.pack(fill=tk.X)
        self.ref_count_label = ttk.Label(ref_row, text="Refs: (0)", style="Dim.TLabel")
        self.ref_count_label.pack(side=tk.LEFT)
        ttk.Button(ref_row, text="Add Named", command=self._add_named_reference).pack(side=tk.RIGHT, padx=2)
        ttk.Button(ref_row, text="Load ref/", command=self._load_refs_from_dir).pack(side=tk.RIGHT, padx=2)
        ttk.Button(ref_row, text="Remove", command=self._remove_selected_ref).pack(side=tk.RIGHT, padx=2)
        ttk.Button(ref_row, text="Clear", command=self._clear_references).pack(side=tk.RIGHT)
        self.ref_veo_listbox = tk.Listbox(self.ref_frame, height=3, bg=COLORS['bg_input'],
                                          fg=COLORS['text'], font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        self.ref_veo_listbox.pack(fill=tk.X, pady=(2, 0))

        self._on_mode_change()

    def _build_right(self, parent):
        # Prompts
        card = self.app.create_card(parent, "Prompts")
        btn_row = ttk.Frame(card, style="Card.TFrame")
        btn_row.pack(fill=tk.X, pady=(0, 4))
        ttk.Button(btn_row, text="Load File", command=self._load_prompts_file).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="Clipboard", command=self._load_clipboard).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="Clear", command=self._clear_prompts).pack(side=tk.LEFT, padx=2)
        self.prompts_count_label = ttk.Label(btn_row, text="0 prompts", style="Dim.TLabel")
        self.prompts_count_label.pack(side=tk.RIGHT)
        self.prompt_text = scrolledtext.ScrolledText(card, height=5, bg=COLORS['bg_input'],
                                                     fg=COLORS['text'], font=FONT_LOG,
                                                     insertbackground=COLORS['text'], relief=tk.FLAT)
        self.prompt_text.pack(fill=tk.X)
        self.prompt_text.bind('<KeyRelease>', self._on_prompt_change)

        # Actions + Stats
        card = self.app.create_card(parent, "Actions")
        stats_row = ttk.Frame(card, style="Card.TFrame")
        stats_row.pack(fill=tk.X, pady=2)
        self.stats_success = ttk.Label(stats_row, text="OK: 0", style="Stats.TLabel")
        self.stats_success.pack(side=tk.LEFT, padx=6)
        self.stats_failed = ttk.Label(stats_row, text="Fail: 0", style="Stats.TLabel")
        self.stats_failed.pack(side=tk.LEFT, padx=6)
        self.stats_progress = ttk.Label(stats_row, text="0/0", style="Stats.TLabel")
        self.stats_progress.pack(side=tk.LEFT, padx=6)
        self.active_threads_label = ttk.Label(stats_row, text="0 active", style="Stats.TLabel")
        self.active_threads_label.pack(side=tk.RIGHT, padx=6)

        self.progress_bar = ttk.Progressbar(card, style="Green.Horizontal.TProgressbar",
                                            mode='determinate', length=300)
        self.progress_bar.pack(fill=tk.X, pady=4)

        # Project name row (для Generate All — создаёт папку с датой+именем)
        proj_row = ttk.Frame(card, style="Card.TFrame")
        proj_row.pack(fill=tk.X, pady=(4, 2))
        ttk.Label(proj_row, text="Project name:", style="Dim.TLabel").pack(side=tk.LEFT)
        self.project_name = tk.StringVar(value="")
        ttk.Entry(proj_row, textvariable=self.project_name,
                  style="Dark.TEntry", width=24).pack(side=tk.LEFT, padx=6)

        btn_row = ttk.Frame(card, style="Card.TFrame")
        btn_row.pack(fill=tk.X, pady=4)
        self.generate_btn = ttk.Button(btn_row, text="Генерировать 1", command=self.start_generation,
                                       style="Accent.TButton")
        self.generate_btn.pack(side=tk.LEFT, padx=3)
        self.multithread_btn = ttk.Button(btn_row, text="Генерировать все",
                                          command=self.start_multithread, style="Accent.TButton")
        self.multithread_btn.pack(side=tk.LEFT, padx=3)
        self.stop_btn = ttk.Button(btn_row, text="Stop", command=self.stop_generation,
                                   state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=3)

        btn_row2 = ttk.Frame(card, style="Card.TFrame")
        btn_row2.pack(fill=tk.X, pady=2)
        ttk.Button(btn_row2, text="Upsample 4K", command=self.upsample_video).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_row2, text="Cancel All", command=self.cancel_all).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_row2, text="Open Folder",
                   command=lambda: os.startfile(str(self.output_dir))).pack(side=tk.LEFT, padx=3)

        # Log
        log_card = self.app.create_card(parent, "Log")
        self.log_widget = self.app.create_log_widget(log_card)
        ttk.Button(log_card, text="Clear Log",
                   command=lambda: self.log_widget.delete("1.0", tk.END)).pack(anchor=tk.W, pady=2)

    # ═══════════ MODE SWITCHING ═══════════

    def _on_mode_change(self):
        mode = self.mode.get()
        for f in (self.single_frame, self.multi_frame, self.batch_frame, self.model_frame, self.ref_frame):
            f.pack_forget()
        if mode == "video_i2v":
            self.single_frame.pack(fill=tk.X, pady=4)
        elif mode == "video_multi":
            self.multi_frame.pack(fill=tk.X, pady=4)
        elif mode == "video_batch":
            self.batch_frame.pack(fill=tk.X, pady=4)
        elif mode == "image_banana":
            self.model_frame.pack(fill=tk.X, pady=4)
            self.ref_frame.pack(fill=tk.X, pady=4)

    # ═══════════ IMAGE MANAGEMENT ═══════════

    def _select_single_image(self):
        files = filedialog.askopenfilenames(filetypes=[("Images", "*.png *.jpg *.jpeg *.webp")])
        if not files:
            return
        if len(files) == 1:
            b64, mime = _image_to_base64(files[0])
            self.single_image = {"image_base64": b64, "mime_type": mime}
            self.single_img_label.config(text=Path(files[0]).name[:20])
            self._log(f"Image: {Path(files[0]).name}")
        else:
            # Multiple images → batch i2v (one request per image)
            self.single_image_list = []
            for fp in files:
                b64, mime = _image_to_base64(fp)
                self.single_image_list.append({"image_base64": b64, "mime_type": mime, "name": Path(fp).stem})
            self.single_image = self.single_image_list[0]  # keep compat
            self.single_img_label.config(text=f"{len(files)} images")
            self._log(f"Images for i2v: {len(files)} loaded")

    def _add_video_image(self):
        files = filedialog.askopenfilenames(filetypes=[("Images", "*.png *.jpg *.jpeg *.webp")])
        for fp in files:
            b64, mime = _image_to_base64(fp)
            name = Path(fp).stem
            self.video_images.append({"name": name, "image_base64": b64, "mime_type": mime})
            self._log(f"Added: {name}")
        if files:
            self.multi_listbox.insert(tk.END, name)
            self.multi_listbox.config(height=max(3, min(len(self.video_images), 6)))
            self.multi_label.config(text=f"Images: ({len(self.video_images)})")

    def _remove_selected_video_image(self):
        sel = self.multi_listbox.curselection()
        if sel:
            self.video_images.pop(sel[0])
            self.multi_listbox.delete(sel[0])
            self.multi_listbox.config(height=max(3, min(len(self.video_images), 6)))
            self.multi_label.config(text=f"Images: ({len(self.video_images)})")

    def _clear_video_images(self):
        self.video_images = []
        self.multi_listbox.delete(0, tk.END)
        self.multi_listbox.config(height=3)
        self.multi_label.config(text="Images: (0)")

    def _select_batch(self, which):
        fps = filedialog.askopenfilenames(filetypes=[("Images", "*.png *.jpg *.jpeg *.webp")])
        if not fps:
            return
        # Сортируем по имени файла — порядок пар определяется именем
        fps = sorted(fps, key=lambda p: Path(p).name)
        imgs = []
        for fp in fps:
            b64, mime = _image_to_base64(fp)
            imgs.append({"image_base64": b64, "mime_type": mime, "name": Path(fp).name})
        if which == "start":
            self.batch_start_images = imgs
            self.start_listbox.delete(0, tk.END)
            for img in imgs:
                self.start_listbox.insert(tk.END, img["name"])
            self.start_listbox.config(height=max(3, min(len(imgs), 6)))
            self.start_count_lbl.config(text=f"Start ({len(imgs)}):")
        else:
            self.batch_end_images = imgs
            self.end_listbox.delete(0, tk.END)
            for img in imgs:
                self.end_listbox.insert(tk.END, img["name"])
            self.end_listbox.config(height=max(3, min(len(imgs), 6)))
            self.end_count_lbl.config(text=f"End ({len(imgs)}):")
        self._update_batch_pairs_lbl()

    def _remove_batch_item(self, which):
        lb = self.start_listbox if which == "start" else self.end_listbox
        imgs = self.batch_start_images if which == "start" else self.batch_end_images
        sel = lb.curselection()
        if sel:
            imgs.pop(sel[0])
            lb.delete(sel[0])
            lb.config(height=max(3, min(len(imgs), 6)))
            lbl = self.start_count_lbl if which == "start" else self.end_count_lbl
            lbl.config(text=f"{'Start' if which == 'start' else 'End'} ({len(imgs)}):")
            self._update_batch_pairs_lbl()

    def _clear_batch(self, which):
        if which == "start":
            self.batch_start_images = []
            self.start_listbox.delete(0, tk.END)
            self.start_count_lbl.config(text="Start (0):")
        else:
            self.batch_end_images = []
            self.end_listbox.delete(0, tk.END)
            self.end_count_lbl.config(text="End (0):")
        self._update_batch_pairs_lbl()

    def _update_batch_pairs_lbl(self):
        ns, ne = len(self.batch_start_images), len(self.batch_end_images)
        if ns == 0 and ne == 0:
            self.batch_pairs_lbl.config(text="")
        else:
            pairs = min(ns, ne)
            warn = "  ⚠ unequal!" if ns != ne else ""
            self.batch_pairs_lbl.config(text=f"Pairs: {pairs}{warn}")

    def _add_named_reference(self):
        files = filedialog.askopenfilenames(filetypes=[("Images", "*.png *.jpg *.jpeg *.webp")])
        for fp in files:
            name = Path(fp).stem
            b64, mime = _image_to_base64(fp)
            self.reference_images.append({"name": name, "image_base64": b64, "mime_type": mime})
            self._log(f"Reference added: {name}")
        if files:
            self._refresh_ref_list()

    def _load_refs_from_dir(self):
        dirpath = filedialog.askdirectory(initialdir=str(SCRIPT_DIR / 'projects'))
        if dirpath:
            ref_dir = Path(dirpath) / 'ref' if (Path(dirpath) / 'ref').exists() else Path(dirpath)
            from modules.veononstop import _load_ref_images
            refs = _load_ref_images(str(ref_dir))
            if refs:
                self.reference_images = refs
                self._refresh_ref_list()
                self._log(f"Loaded {len(refs)} refs from {ref_dir}")
            else:
                messagebox.showwarning("Warning", f"No images found in {ref_dir}")

    def _clear_references(self):
        self.reference_images = []
        self._refresh_ref_list()

    def _refresh_ref_list(self):
        self.ref_veo_listbox.delete(0, tk.END)
        self.ref_count_label.config(text=f"Refs: ({len(self.reference_images)})")
        for ref in self.reference_images:
            self.ref_veo_listbox.insert(tk.END, ref['name'])
        self.ref_veo_listbox.config(height=max(3, min(len(self.reference_images), 6)))

    def _remove_selected_ref(self):
        sel = self.ref_veo_listbox.curselection()
        if sel:
            self.reference_images.pop(sel[0])
            self._refresh_ref_list()

    def _remove_ref(self, idx):
        self.reference_images.pop(idx)
        self._refresh_ref_list()

    def _rename_ref(self, idx):
        old_name = self.reference_images[idx]['name']
        new_name = simpledialog.askstring("Rename", "New name:", initialvalue=old_name)
        if new_name:
            self.reference_images[idx]['name'] = new_name
            self._refresh_ref_list()

    # ═══════════ PROMPTS ═══════════

    def _on_prompt_change(self, event=None):
        text = self.prompt_text.get("1.0", tk.END).strip()
        self.prompts_list = [l.strip() for l in text.split("\n") if l.strip()]
        self.prompts_count_label.config(text=f"{len(self.prompts_list)} prompts")

    def _load_prompts_file(self):
        fp = filedialog.askopenfilename(filetypes=[("Text", "*.txt")])
        if fp:
            with open(fp, 'r', encoding='utf-8') as f:
                self.prompt_text.delete("1.0", tk.END)
                self.prompt_text.insert("1.0", f.read())
            self._on_prompt_change()

    def _load_clipboard(self):
        try:
            text = self.root.clipboard_get()
            self.prompt_text.insert("1.0", text)
            self._on_prompt_change()
        except tk.TclError:
            pass

    def _clear_prompts(self):
        self.prompt_text.delete("1.0", tk.END)
        self.prompts_list = []
        self.prompts_count_label.config(text="0 prompts")

    # ═══════════ LOGGING ═══════════

    def _log(self, msg, level="INFO", tid=None):
        self.app.log(msg, level, tid, tab="veo")

    def _update_stats(self):
        with self.stats_lock:
            s, f = self.stats['success'], self.stats['failed']
            t = self.stats['total']
            done = s + f
        self.root.after(0, lambda: self.stats_success.config(text=f"OK: {s}"))
        self.root.after(0, lambda: self.stats_failed.config(text=f"Fail: {f}"))
        self.root.after(0, lambda: self.stats_progress.config(text=f"{done}/{t}"))
        if t > 0:
            self.root.after(0, lambda: self.progress_bar.config(value=(done / t) * 100))

    def _reset_stats(self):
        with self.stats_lock:
            self.stats = {"success": 0, "failed": 0, "total": 0}
        self._update_stats()
        self.progress_bar.config(value=0)

    def _reset_ui(self):
        self.generate_btn.config(state=tk.NORMAL)
        self.multithread_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        self.progress_bar.stop()
        self.active_threads_label.config(text="0 active")

    # ═══════════ API ═══════════

    def _get_headers(self):
        return {"X-API-Key": self.api_key.get().strip(), "Content-Type": "application/json"}

    def _toggle_key(self):
        self.api_entry.config(show="" if self.api_entry.cget('show') == '*' else "*")

    def check_account(self):
        key = self.api_key.get().strip()
        if not key:
            messagebox.showerror("Error", "Enter API key")
            return
        try:
            resp = requests.get(f"{BASE_URL}/account/info", headers=self._get_headers(), timeout=10)
            data = resp.json()
            if data.get("success"):
                info = data['data']
                plan = info.get('plan', '?')
                slots = info.get('concurrent_tasks', '?')
                expires = info.get('expires_at', '?')
                self.thread_count.set(min(int(slots) if isinstance(slots, int) else 4, self.max_threads))
                messagebox.showinfo("Account", f"Plan: {plan}\nSlots: {slots}\nExpires: {expires}")
            else:
                messagebox.showerror("Error", data.get("error", "Unknown"))
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def cancel_all(self):
        if not messagebox.askyesno("Cancel All", "Cancel all active tasks on server?"):
            return
        try:
            resp = requests.post(f"{BASE_URL}/video/cancel-all", headers=self._get_headers(), timeout=30)
            data = resp.json()
            cancelled = data.get("data", {}).get("cancelled_count", 0)
            self._log(f"Cancelled {cancelled} tasks", "SUCCESS")
        except Exception as e:
            self._log(f"Cancel error: {e}", "ERROR")

    # ═══════════ GENERATION ═══════════

    def start_generation(self):
        if self.is_generating:
            return
        key = self.api_key.get().strip()
        if not key:
            messagebox.showerror("Error", "Enter API key")
            return
        prompt = self.prompt_text.get("1.0", tk.END).strip()
        if not prompt:
            messagebox.showerror("Error", "Enter prompt")
            return
        first = prompt.split("\n")[0].strip()
        self.is_generating = True
        self.generate_btn.config(state=tk.DISABLED)
        self.multithread_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.progress_bar.config(mode='indeterminate')
        self.progress_bar.start()

        def worker():
            try:
                self._generate_single(first)
                self._log("Done!", "SUCCESS")
            except Exception as e:
                self._log(f"Error: {e}", "ERROR")
            finally:
                self.is_generating = False
                self.root.after(0, self._reset_ui)

        threading.Thread(target=worker, daemon=True).start()

    def start_multithread(self):
        if self.is_generating:
            return
        if not self.api_key.get().strip():
            messagebox.showerror("Error", "Enter API key")
            return
        self._on_prompt_change()
        tc = self.thread_count.get()

        # Batch Frame: итерируем по парам изображений, промпты цикличны
        if self.mode.get() == "video_batch":
            ns, ne = len(self.batch_start_images), len(self.batch_end_images)
            pc = min(ns, ne)
            if pc == 0:
                messagebox.showerror("Error", "Select start and end images")
                return
            if not self.prompts_list:
                messagebox.showerror("Error", "Enter at least one prompt")
                return
        else:
            if not self.prompts_list:
                messagebox.showerror("Error", "No prompts")
                return
            pc = len(self.prompts_list)
            if pc == 1:
                self.start_generation()
                return

        if not messagebox.askyesno("Confirm", f"Generate {pc} items with {tc} threads?"):
            return

        # Создаём папку проекта: veononstop_output/YYYYMMDD_HHMMSS[_name]/
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        name_part = self.project_name.get().strip()
        folder_name = f"{ts}_{name_part}" if name_part else ts
        # Очищаем от символов, недопустимых в именах папок
        folder_name = "".join(c for c in folder_name if c not in r'\/:*?"<>|')
        session_dir = get_output_dir() / folder_name
        session_dir.mkdir(parents=True, exist_ok=True)
        self.output_dir = session_dir

        self.is_generating = True
        self.generate_btn.config(state=tk.DISABLED)
        self.multithread_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.progress_bar.config(mode='determinate')
        self._reset_stats()
        with self.stats_lock:
            self.stats['total'] = pc
        self._update_stats()
        self._log(f"Output folder: {session_dir.name}", "INFO")

        threading.Thread(target=self._multithread_worker, daemon=True).start()

    def _multithread_worker(self):
        tc = self.thread_count.get()
        is_batch_frame = self.mode.get() == "video_batch"

        if is_batch_frame:
            # Итерируем по парам, промпты цикличны
            ns, ne = len(self.batch_start_images), len(self.batch_end_images)
            pairs = list(zip(self.batch_start_images[:min(ns, ne)],
                             self.batch_end_images[:min(ns, ne)]))
            prompts = self.prompts_list.copy()
            tasks = [(i, pairs[i][0], pairs[i][1], prompts[i % len(prompts)])
                     for i in range(len(pairs))]
            self._log(f"Batch Frame: {len(tasks)} pairs, {tc} threads", "INFO")
        else:
            prompts = self.prompts_list.copy()
            tasks = None
            self._log(f"Starting {len(prompts)} tasks with {tc} threads", "INFO")

        active = [0]
        active_lock = threading.Lock()

        def update_active(delta):
            with active_lock:
                active[0] += delta
                c = active[0]
            self.root.after(0, lambda: self.active_threads_label.config(text=f"{c} active"))

        def process(args):
            tid = threading.current_thread().name.split('_')[-1]
            if not self.is_generating:
                return False
            update_active(1)
            try:
                if is_batch_frame:
                    idx, s_img, e_img, prompt = args
                    self._log(f"Pair {idx+1}: {s_img['name']} → {e_img['name']}", "INFO", tid)
                    self._video_batch(prompt, tid, start_img=s_img, end_img=e_img)
                else:
                    idx, prompt = args
                    self._log(f"Start: {prompt[:40]}...", "INFO", tid)
                    self._generate_single(prompt, tid)
                with self.stats_lock:
                    self.stats['success'] += 1
                self._update_stats()
                return True
            except Exception as e:
                with self.stats_lock:
                    self.stats['failed'] += 1
                self._update_stats()
                self._log(f"Failed: {str(e)[:60]}", "ERROR", tid)
                return False
            finally:
                update_active(-1)

        if is_batch_frame:
            task_args = tasks
        else:
            task_args = [(i, p) for i, p in enumerate(prompts)]

        with ThreadPoolExecutor(max_workers=tc, thread_name_prefix="Gen") as exe:
            futures = {exe.submit(process, a): a for a in task_args}
            for f in as_completed(futures):
                if not self.is_generating:
                    exe.shutdown(wait=False, cancel_futures=True)
                    break

        with self.stats_lock:
            s, f, t = self.stats['success'], self.stats['failed'], self.stats['total']
        self._log(f"Done: {s} ok, {f} failed, {t} total", "SUCCESS")
        self.is_generating = False
        self.root.after(0, self._reset_ui)

    def _generate_single(self, prompt, tid=None):
        mode = self.mode.get()
        if mode == "video_t2v":
            self._video_t2v(prompt, tid)
        elif mode == "video_i2v":
            self._video_i2v(prompt, tid)
        elif mode == "video_multi":
            self._video_multi(prompt, tid)
        elif mode == "video_batch":
            self._video_batch(prompt, tid)
        elif mode == "image_banana":
            self._image_banana(prompt, tid)
        elif mode == "image_imagen":
            self._image_imagen(prompt, tid)

    def stop_generation(self):
        self.is_generating = False
        self._log("Stopping...", "WARNING")
        self._reset_ui()

    # ═══════════ VIDEO MODES ═══════════

    def _video_t2v(self, prompt, tid=None):
        self._log("Text to Video...", "INFO", tid)
        payload = {"prompt": prompt, "aspect_ratio": self.aspect_ratio.get(),
                   "count": self.generation_count.get()}
        self._submit_video("/video/text-to-video", payload, tid)

    def _video_i2v(self, prompt, tid=None):
        if not self.single_image:
            raise Exception("Select image first")
        img_list = getattr(self, 'single_image_list', None)
        if img_list and len(img_list) > 1:
            self._log(f"Batch i2v: {len(img_list)} images...", "INFO", tid)
            for i, img in enumerate(img_list):
                self._log(f"  i2v [{i+1}/{len(img_list)}] {img.get('name', '')}...", "INFO", tid)
                payload = {"prompt": prompt, "image_base64": img["image_base64"],
                           "mime_type": img["mime_type"],
                           "aspect_ratio": self.aspect_ratio.get(), "count": self.generation_count.get()}
                self._submit_video("/video/image-to-video", payload, tid)
        else:
            self._log("Image to Video...", "INFO", tid)
            payload = {"prompt": prompt, "image_base64": self.single_image["image_base64"],
                       "mime_type": self.single_image["mime_type"],
                       "aspect_ratio": self.aspect_ratio.get(), "count": self.generation_count.get()}
            self._submit_video("/video/image-to-video", payload, tid)

    def _video_multi(self, prompt, tid=None):
        if not self.video_images:
            raise Exception("Add images first")
        self._log(f"Multi-Image ({len(self.video_images)})...", "INFO", tid)
        payload = {"prompt": prompt, "images": self.video_images,
                   "aspect_ratio": self.aspect_ratio.get(), "count": self.generation_count.get()}
        self._submit_video("/video/multi-image-to-video", payload, tid)

    def _video_batch(self, prompt, tid=None, start_img=None, end_img=None):
        s = start_img or (self.batch_start_images[0] if self.batch_start_images else None)
        e = end_img or (self.batch_end_images[0] if self.batch_end_images else None)
        if not s or not e:
            raise Exception("Select start and end images")
        self._log(f"Batch Frame: {s['name']} → {e['name']}", "INFO", tid)
        payload = {"prompt": prompt, "start_image_base64": s["image_base64"],
                   "end_image_base64": e["image_base64"],
                   "aspect_ratio": self.aspect_ratio.get(), "count": self.generation_count.get()}
        self._submit_video("/video/batch-frame", payload, tid)

    def _submit_video(self, endpoint, payload, tid=None):
        resp = requests.post(f"{BASE_URL}{endpoint}", json=payload,
                             headers=self._get_headers(), timeout=REQUEST_TIMEOUT)
        data = resp.json()
        if not data.get("success"):
            raise Exception(data.get("error", "Unknown error"))
        task_id = data.get("data", {}).get("task_id")
        if not task_id:
            raise Exception("No task_id")
        self._log(f"Task: {task_id[:20]}...", "SUCCESS", tid)
        self._poll_video(task_id, tid)

    def _poll_video(self, task_id, tid=None):
        while self.is_generating:
            try:
                resp = requests.get(f"{BASE_URL}/video/status/{task_id}",
                                    headers=self._get_headers(), timeout=30)
                result = resp.json().get("data", {})
                status = result.get("status", "unknown")
                if status == "completed":
                    self.last_video_result = result
                    self._download_videos(result, tid)
                    return
                elif status in ("failed", "error"):
                    raise Exception(result.get("error", "Failed"))
                time.sleep(VIDEO_POLL_INTERVAL)
            except Exception as e:
                if "failed" in str(e).lower():
                    raise
                time.sleep(VIDEO_POLL_INTERVAL)

    def _download_videos(self, result, tid=None):
        videos = result.get("videos", [])
        self.output_dir.mkdir(parents=True, exist_ok=True)
        for i, v in enumerate(videos):
            url = v.get("fifeUrl")
            if url:
                try:
                    r = requests.get(url, timeout=120)
                    fn = self.output_dir / f"video_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}_{i+1}.mp4"
                    fn.write_bytes(r.content)
                    self._log(f"Saved: {fn.name}", "SUCCESS", tid)
                except Exception as e:
                    self._log(f"Download error: {e}", "ERROR", tid)

    # ═══════════ IMAGE MODES ═══════════

    def _image_banana(self, prompt, tid=None):
        display = self.model_key.get()
        api_key = BANANA_NAME_TO_KEY.get(display, display)
        self._log(f"Banana ({display})...", "INFO", tid)
        payload = {"prompt": prompt, "aspect_ratio": self.aspect_ratio.get(),
                   "num_images": self.generation_count.get(), "model_key": api_key}
        if self.reference_images:
            payload["reference_images"] = self.reference_images
        resp = requests.post(f"{BASE_URL}/image/banana/generate", json=payload,
                             headers=self._get_headers(), timeout=REQUEST_TIMEOUT)
        data = resp.json()
        if not data.get("success"):
            raise Exception(data.get("error", "Unknown error"))
        media = data.get("data", {}).get("media", [])
        self.output_dir.mkdir(parents=True, exist_ok=True)
        for i, m in enumerate(media):
            url = m.get("fifeUrl")
            if url:
                try:
                    r = requests.get(url, timeout=60)
                    fn = self.output_dir / f"banana_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}_{i+1}.png"
                    fn.write_bytes(r.content)
                    self._log(f"Saved: {fn.name}", "SUCCESS", tid)
                except Exception as e:
                    self._log(f"Error: {e}", "ERROR", tid)

    def _image_imagen(self, prompt, tid=None):
        self._log("IMAGEN 3.5...", "INFO", tid)
        payload = {"prompt": prompt, "aspect_ratio": self.aspect_ratio.get()}
        resp = requests.post(f"{BASE_URL}/image/generate", json=payload,
                             headers=self._get_headers(), timeout=REQUEST_TIMEOUT)
        data = resp.json()
        if not data.get("success"):
            raise Exception(data.get("error", "Unknown error"))
        media_id = data.get("data", {}).get("mediaGenerationId")
        if media_id:
            self._log(f"ID: {media_id[:30]}...", "SUCCESS", tid)

    # ═══════════ UPSAMPLE ═══════════

    def upsample_video(self):
        if not self.last_video_result:
            messagebox.showwarning("Warning", "Generate video first")
            return
        videos = self.last_video_result.get("videos", [])
        if not videos:
            return
        media_id = videos[0].get("mediaGenerationId")
        if not media_id:
            messagebox.showerror("Error", "No mediaGenerationId")
            return
        self.is_generating = True
        self.generate_btn.config(state=tk.DISABLED)
        self.progress_bar.config(mode='indeterminate')
        self.progress_bar.start()

        def do_upsample():
            try:
                self._log("Upsampling to 4K...", "INFO")
                payload = {"media_generation_id": media_id, "aspect_ratio": self.aspect_ratio.get()}
                resp = requests.post(f"{BASE_URL}/video/upsample", json=payload,
                                     headers=self._get_headers(), timeout=REQUEST_TIMEOUT)
                data = resp.json()
                if data.get("success"):
                    tid = data.get("data", {}).get("task_id")
                    self._poll_video(tid)
                    self._log("Upsample done!", "SUCCESS")
                else:
                    raise Exception(data.get("error", "Failed"))
            except Exception as e:
                self._log(f"Upsample error: {e}", "ERROR")
            finally:
                self.is_generating = False
                self.root.after(0, self._reset_ui)

        threading.Thread(target=do_upsample, daemon=True).start()


# ════════════════════════════════════════════════════════════════════
# TAB: DONATE
# ════════════════════════════════════════════════════════════════════

class DonateTab:
    def __init__(self, notebook, app: 'VarAgentGUI'):
        self.app = app
        self.frame = ttk.Frame(notebook)
        self._build()

    def _build(self):
        outer = ttk.Frame(self.frame)
        outer.pack(expand=True)  # center vertically

        card = ttk.Frame(outer, style="Card.TFrame", padding=32)
        card.pack(padx=40, pady=40)

        # Header text
        lines = [
            "Пока Вар ещё на пути к первым миллионам на YouTube,",
            "вы можете сказать спасибо Вару,",
            "если программа оказалась вам полезной,",
            "по реквизитам ниже:",
        ]
        for line in lines:
            ttk.Label(card, text=line, style="Card.TLabel",
                      font=("Segoe UI", 11)).pack(anchor=tk.W, pady=1)

        ttk.Separator(card, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=16)

        def _card_row(icon, label, action_text, action):
            row = ttk.Frame(card, style="Card.TFrame")
            row.pack(fill=tk.X, pady=6)
            ttk.Label(row, text=icon, font=("Segoe UI", 16), style="Card.TLabel").pack(side=tk.LEFT, padx=(0, 10))
            ttk.Label(row, text=label, style="Card.TLabel",
                      font=("Segoe UI", 12)).pack(side=tk.LEFT, expand=True, anchor=tk.W)
            btn = ttk.Button(row, text=action_text, command=action)
            btn.pack(side=tk.RIGHT, padx=(12, 0))

        CARD_NUM = "5599002019861089"
        def _copy_card():
            self.frame.clipboard_clear()
            self.frame.clipboard_append(CARD_NUM)
            self.frame.update()

        def _open(url):
            import webbrowser
            webbrowser.open(url)

        _card_row("\u20BD", f"Карта  {CARD_NUM}", "Скопировать", _copy_card)
        _card_row("\u20BD", "ЮMoney", "Открыть",
                  lambda: _open("https://yoomoney.ru/to/410017958835828"))
        _card_row("$ \u20AC \u20BF", "DeStream (USD / EUR / BTC)",
                  "Открыть", lambda: _open("https://destream.net/live/VARGART/don"))

        ttk.Separator(card, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=16)

        _card_row("\u2708", "Написать Вару",
                  "Telegram", lambda: _open("https://t.me/vargartor"))


# ════════════════════════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════════════════════════

def main():
    root = tk.Tk()
    app = VarAgentGUI(root)
    root.mainloop()


if __name__ == '__main__':
    main()
