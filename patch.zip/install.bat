@echo off
setlocal
cd /d "%~dp0"

set "PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"

echo.
echo ================================================================================
echo  SCENAGENT RTG - AUTO INSTALLER
echo ================================================================================
echo.

REM ============================================================================
REM 1. PYTHON
REM ============================================================================
echo [1/4] Python 3.11...

if exist "%PYTHON_EXE%" (
    echo  [OK] Python uzhe ustanovlen: %PYTHON_EXE%
    goto :pip_section
)

echo  Ustanavlivaem Python 3.11 cherez winget...
winget install --id Python.Python.3.11 --source winget --exact --silent --accept-package-agreements --accept-source-agreements

if exist "%PYTHON_EXE%" goto :pip_section

echo  winget ne smog. Skachivaem installer s python.org...
curl -L --progress-bar -o "%TEMP%\py_installer.exe" "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe"
if not exist "%TEMP%\py_installer.exe" (
    echo  [ERROR] Ne udalos skachat installer.
    pause
    exit /b 1
)
"%TEMP%\py_installer.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_test=0
del "%TEMP%\py_installer.exe" >nul 2>&1

if not exist "%PYTHON_EXE%" (
    echo  [ERROR] Python ne ustanovlen v %PYTHON_EXE%
    echo  Ustanovite vruchnuyu: https://www.python.org/downloads/
    pause
    exit /b 1
)
echo  [OK] Python ustanovlen.

:pip_section
REM ============================================================================
REM 2. PIP
REM ============================================================================
echo.
echo [2/4] pip...

"%PYTHON_EXE%" -m pip --version >nul 2>&1
if not errorlevel 1 (
    echo  [OK] pip dostupno
    goto :packages_section
)

echo  pip ne nayden. Ustanavlivaem cherez ensurepip...
"%PYTHON_EXE%" -m ensurepip --upgrade
if errorlevel 1 (
    echo  [ERROR] ensurepip ne smog.
    pause
    exit /b 1
)
echo  [OK] pip ustanovlen.

:packages_section
REM ============================================================================
REM 3. PYTHON PAKETY
REM ============================================================================
echo.
echo [3/4] Python pakety...
echo.
echo  Pakety: assemblyai, google-genai, python-dotenv, tqdm, requests, httpx,
echo          pydantic, colorama, Pillow, PyJWT, tkinterdnd2
echo.

"%PYTHON_EXE%" -c "import assemblyai, google.genai, dotenv, tqdm, requests, httpx, pydantic, colorama, PIL, jwt, tkinterdnd2" 2>nul
if not errorlevel 1 (
    echo  [OK] Vse pakety uzhe ustanovleny
    goto :ffmpeg_section
)

"%PYTHON_EXE%" -m pip install --upgrade pip --trusted-host pypi.org --trusted-host files.pythonhosted.org

REM Ustanavlivaem iz requirements.txt (edinyy istochnik pravdy). Ranshe byl
REM zahardkozhennyy spisok paketov, kotoryy otstaval ot requirements.txt -
REM napr. rookiepy/browser-cookie3 (Suno cookie auth) ne stavilis' u Windows-
REM yuzerov, i modul' muzyki padal. Teper' - vsegda polnyy requirements.txt.
if exist "agent\requirements.txt" (
    "%PYTHON_EXE%" -m pip install -r "agent\requirements.txt" ^
        --trusted-host pypi.org ^
        --trusted-host files.pythonhosted.org ^
        --default-timeout=120 ^
        --retries 5 ^
        --prefer-binary
) else (
    echo  [WARN] agent\requirements.txt ne nayden - stavim bazovyy spisok.
    "%PYTHON_EXE%" -m pip install ^
        assemblyai ^
        google-genai ^
        python-dotenv ^
        tqdm ^
        requests ^
        httpx ^
        pydantic ^
        colorama ^
        Pillow ^
        PyJWT ^
        tkinterdnd2 ^
        rookiepy ^
        browser-cookie3 ^
        --trusted-host pypi.org ^
        --trusted-host files.pythonhosted.org ^
        --default-timeout=120 ^
        --retries 5 ^
        --prefer-binary
)

if errorlevel 1 (
    echo.
    echo  [ERROR] Oshibka ustanovki paketov.
    echo  Proverite internet/VPN/antivirus.
    pause
    exit /b 1
)
echo  [OK] Pakety ustanovleny.

:ffmpeg_section
REM ============================================================================
REM 4. FFMPEG
REM ============================================================================
echo.
echo [4/4] FFmpeg...

ffmpeg -version >nul 2>&1
if not errorlevel 1 (
    echo  [OK] FFmpeg uzhe est
    goto :env_section
)

echo  FFmpeg ne nayden. Zapuskaem install_ffmpeg.bat...
if exist "%~dp0install_ffmpeg.bat" (
    call "%~dp0install_ffmpeg.bat" /nopause
) else (
    echo  [ERROR] install_ffmpeg.bat ne nayden.
)
ffmpeg -version >nul 2>&1
if errorlevel 1 (
    echo  [WARN] FFmpeg poka ne dostupen v PATH.
    echo  [INFO] Perezapustite terminal ili zapustite install_ffmpeg.bat vruchnuyu.
) else (
    echo  [OK] FFmpeg ustanovlen i dostupen.
)

:env_section
REM ============================================================================
REM .ENV
REM ============================================================================
echo.
echo ================================================================================
echo  Konfiguracziya (.env)...
echo ================================================================================

if not exist "agent\.env" (
    if exist "agent\.env.example" (
        copy "agent\.env.example" "agent\.env" >nul
        echo  [OK] Sozdan agent\.env iz shablona
        echo.
        echo  [!!!] TREBUYUTSYA API KLYUCHI! Otkrojte agent\.env i zapolnite:
        echo    ASSEMBLYAI_API_KEY  = https://www.assemblyai.com/app/
        echo    GEMINI_API_KEY      = https://aistudio.google.com/app/apikey
        echo    FASTGEN_API_KEY     = https://fast-gen.ai
    ) else (
        echo  [WARN] agent\.env.example ne nayden.
    )
) else (
    echo  [OK] agent\.env uzhe sushchestvuet
)

REM ============================================================================
REM ITOG
REM ============================================================================
echo.
echo ================================================================================
echo  USTANOVKA ZAVERSHENA
echo ================================================================================
echo.
echo  Sleduyushchie shagi:
echo  1. Otkrojte agent\.env i ukazite API klyuchi
echo  2. Polozhite audiofayl v ready_to_go\
echo  3. Zapustite varagent.bat
echo.
pause
