"""Auto Visual Story analyze orchestrator."""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

import config
from modules import chat_client
from modules.visual_story_context import (
    ContextWindowBuilder, materialize_scenes, normalize_words, write_context_packets,
)
from modules.visual_story_validator import validate_scenes, validate_visual_plans


def _json(raw: str) -> dict[str, Any]:
    text = (raw or "").strip()
    match = re.search(r"```(?:json)?\s*(.*?)```", text, re.S)
    if match:
        text = match.group(1).strip()
    try:
        return json.loads(text)
    except ValueError:
        start, end = text.find("{"), text.rfind("}")
        if start >= 0 and end > start:
            return json.loads(text[start:end + 1])
        raise


def _provider_model(provider: str | None, model: str | None) -> tuple[str, str]:
    provider = (provider or getattr(config, "GPT_PROVIDER", "cliproxy")).strip().lower()
    defaults = {
        "cliproxy": getattr(config, "CLIPROXY_MODEL", ""),
        "deepseek": getattr(config, "DEEPSEEK_MODEL", ""),
        "openrouter": getattr(config, "OPENROUTER_MODEL", ""),
        "meta_muse": getattr(config, "META_MUSE_MODEL", ""),
        "claude_api": getattr(config, "CLAUDE_API_MODEL", ""),
        "codex_reseller": getattr(config, "CODEX_RESELLER_MODEL", ""),
        "gpt_nexus": getattr(config, "GPT_NEXUS_MODEL", ""),
    }
    return provider, (model or defaults.get(provider) or "").strip()


def _call(provider: str, model: str, prompt: str) -> dict[str, Any]:
    return _json(chat_client.chat_completion(
        provider, model, [{"role": "user", "content": prompt}],
        json_mode=True, timeout=getattr(config, "GPT_DIRECTOR_TIMEOUT", 600),
    ))


def _mock_scenes(words: list[dict[str, Any]], target: float) -> dict[str, Any]:
    scenes, start = [], 0
    while start < len(words):
        end = start
        while end + 1 < len(words) and words[end]["end"] - words[start]["start"] < target:
            end += 1
        scenes.append({
            "word_start_index": start, "word_end_index": end,
            "scene_role": "event", "description": "Mock semantic scene",
            "chapter_id": "chapter_1", "entities": [],
        })
        start = end + 1
    return {"narrative_map": {"chapters": [{"id": "chapter_1", "summary": "Mock chapter"}]},
            "scenes": scenes}


def _mock_plans(packets: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [{
        "scene_id": packet["scene_id"],
        "visual_strategy": "new_search",
        "visual_intent": packet["current_scene_text"],
        "search_query": " ".join(packet["current_scene_text"].split()[:6]),
        "fallback_queries": [],
        "preferred_source": "epf",
        "negative_constraints": [],
        "confidence": 0.5,
        "reason": "mock",
    } for packet in packets]


def analyze_project(
    project_dir: str | Path, *, provider: str | None = None, model: str | None = None,
    before: int = 3, after: int = 2, history: int = 4, mock: bool = False,
) -> dict[str, Any]:
    project = Path(project_dir).resolve()
    transcription = json.loads((project / "transcription.json").read_text(encoding="utf-8-sig"))
    words = normalize_words(transcription)
    audio_duration = float(transcription.get("audioDuration") or words[-1]["end"])
    (project / "transcription_words.json").write_text(json.dumps({
        "audioDuration": audio_duration, "language": transcription.get("language"),
        "words": words,
    }, ensure_ascii=False, indent=2), encoding="utf-8")

    if mock:
        raw_plan = _mock_scenes(words, float(getattr(config, "VISUAL_STORY_TARGET_SCENE_DURATION", 5)))
        provider_name, model_name = "mock", "deterministic"
    else:
        provider_name, model_name = _provider_model(provider, model)
        template = (Path(__file__).parents[1] / "prompts" / "visual_story_scene_plan.txt").read_text(encoding="utf-8")
        raw_plan = _call(provider_name, model_name, template.replace(
            "{{WORDS_JSON}}", json.dumps(words, ensure_ascii=False)))
    scenes = materialize_scenes(words, raw_plan.get("scenes") or [], audio_duration)
    validate_scenes(scenes, len(words), audio_duration)
    narrative_map = raw_plan.get("narrative_map") or {"chapters": []}
    story_plan = {"version": 1, "audioDuration": audio_duration, "clips": scenes}
    (project / "visual_story_plan.json").write_text(
        json.dumps(story_plan, ensure_ascii=False, indent=2), encoding="utf-8")
    (project / "narrative_map.json").write_text(
        json.dumps(narrative_map, ensure_ascii=False, indent=2), encoding="utf-8")

    packets = ContextWindowBuilder(before, after, history).build_all(scenes, narrative_map)
    write_context_packets(project, packets)
    if mock:
        plans = _mock_plans(packets)
    else:
        template = (Path(__file__).parents[1] / "prompts" / "visual_story_query_creator.txt").read_text(encoding="utf-8")
        plans = (_call(provider_name, model_name, template.replace(
            "{{CONTEXT_PACKETS_JSON}}", json.dumps(packets, ensure_ascii=False))).get("plans") or [])
    validate_visual_plans(plans, len(scenes))
    (project / "visual_plans.json").write_text(
        json.dumps({"version": 1, "plans": plans}, ensure_ascii=False, indent=2), encoding="utf-8")
    state = {
        "version": 1, "mode": "auto_visual_story", "step": "analyze",
        "status": "completed", "provider": provider_name, "model": model_name,
        "scenes": len(scenes), "artifacts": [
            "transcription_words.json", "narrative_map.json", "visual_story_plan.json",
            "context_packets", "visual_plans.json",
        ],
    }
    (project / "visual_story_state.json").write_text(
        json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    return state
