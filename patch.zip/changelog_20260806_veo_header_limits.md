# VeoNonStop header limits - 2026-08-06

- Added a separate compact header indicator for every configured VeoNonStop
  API key slot (1-4).
- Active keys show remaining image quota and the time until quota reset.
- Expired, revoked, invalid and temporarily unavailable keys have distinct
  visible states.
- Hovering a key shows plan, concurrent task limit, image usage, video usage,
  reset time and key expiration.
- Temporary VeoNonStop 503/timeouts keep the last successful value and mark it
  stale instead of replacing it with a false invalid-key status.
- The shared header Refresh button now refreshes GPT quota, reseller balances
  and every configured VeoNonStop key.
- Added a `Banana quota` block inside Pipeline -> Image Generation.
- The block shows `image_remaining / image_limit` and reset time for every
  configured key, using the same cached monitor data as the header.
- Fixed Veo key slot labels that previously displayed `?/24` or `?/12`.
- Slot labels now use `active_tasks`, `queued_tasks` and
  `max_concurrent_tasks` when the server returns them, for example
  `2/24 +3q`.
- The current VeoNonStop `/account/usage` response returns quota counters but
  omits live concurrency counters. In that case the GUI now shows the honest
  `slots n/a/24` form instead of inventing zero or printing question marks.
- Audited Image Generation provider routing: there is currently no true
  FastGen + VeoNonStop `Both` mode. Existing `Both` values cover video engines
  or multiple keys of one provider. A future image-provider `Both` mode needs
  explicit output ownership/scheduling so providers cannot overwrite the same
  files in `generated/`.
- Added parser/formatting regression tests.
