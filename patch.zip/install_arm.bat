@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo ================================================================================
echo  SCENAGENT RTG - AUTO INSTALLER (ARM64 Windows)
echo ================================================================================
echo.
echo  Etot installer dlya Windows na ARM protsessore (Snapdragon, Surface Pro X i td.)
echo  On ustanovit x64-versiyu Python kotoraya rabotaet cherez emulyatsiyu.
echo.

set "NEED_RESTART=0"
set "PYTHON_CMD=python"

REM ============================================================================
REM 1. PYTHON (x64 dlya ARM64 Windows)
REM ============================================================================
echo [1/4] Python (x64 for ARM)...

REM --- Proverka: mozhet uzhe est python ---
python --version >nul 2>&1
if not errorlevel 1 (
    for /f "tokens=2" %%v in ('python --version 2^>^&1') do set PYVER=%%v
    echo  [OK] Python !PYVER! uzhe ustanovlen
    goto :python_version_check
)

py --version >nul 2>&1
if not errorlevel 1 (
    for /f "tokens=2" %%v in ('py --version 2^>^&1') do set PYVER=%%v
    set "PYTHON_CMD=py"
    echo  [OK] Python !PYVER! uzhe ustanovlen
    goto :python_version_check
)

goto :install_python_x64

:python_version_check
for /f "tokens=1,2 delims=." %%a in ("!PYVER!") do (
    set "PY_MAJOR=%%a"
    set "PY_MINOR=%%b"
)
if !PY_MAJOR! LSS 3 goto :install_python_x64
if !PY_MAJOR! EQU 3 if !PY_MINOR! LSS 10 goto :install_python_x64
goto :pip_check

:install_python_x64
echo.
echo  Skachivayem Python 3.11 x64 (ne ARM!) dlya sovmestimosti...
echo  (x64 Python rabotaet na ARM Windows cherez emulyatsiyu)
echo.

REM --- Skachivayem x64 installer (NE arm64!) ---
curl -L --progress-bar -o "%TEMP%\py_installer_x64.exe" "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe"
if errorlevel 1 (
    echo.
    echo  [ERROR] Ne udalos skachat Python installer.
    echo  Provertte internet. Esli python.org nedostupen - vkluchite VPN.
    echo  Ili skachajte vruchnuyu (TOLKO x64, NE arm64!):
    echo    https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe
    echo  Pri ustanovke otmette "Add python.exe to PATH"!
    pause
    exit /b 1
)

echo  Ustanavlivaem Python 3.11 x64...
"%TEMP%\py_installer_x64.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_test=0
del "%TEMP%\py_installer_x64.exe" >nul 2>&1

REM --- Obnovlyaem PATH ---
echo  Obnovlyaem PATH...
for /f "usebackq delims=" %%P in (`powershell -NoProfile -Command "[Environment]::GetEnvironmentVariable('PATH','Machine') + ';' + [Environment]::GetEnvironmentVariable('PATH','User')"`) do set "PATH=%%P"

python --version >nul 2>&1
if not errorlevel 1 (
    for /f "tokens=2" %%v in ('python --version 2^>^&1') do set PYVER=%%v
    echo  [OK] Python !PYVER! x64 ustanovlen
    goto :pip_check
)

REM --- Poisk po izvestnym putyam ---
echo  Ishchem python.exe...
set "PYTHON_CMD="
for %%V in (314 313 312 311 310) do (
    if exist "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe" (
        set "PYTHON_CMD=%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe"
        goto :python_found
    )
)
for %%V in (314 313 312 311) do (
    if exist "C:\Python%%V\python.exe" (
        set "PYTHON_CMD=C:\Python%%V\python.exe"
        goto :python_found
    )
)
for %%V in (314 313 311) do (
    if exist "C:\Program Files\Python%%V\python.exe" (
        set "PYTHON_CMD=C:\Program Files\Python%%V\python.exe"
        goto :python_found
    )
)

echo  [ERROR] Python ustanovlen no ne nayden. Perezapustite terminal i zapustite snova.
pause
exit /b 1

:python_found
echo  [OK] Python nayden: !PYTHON_CMD!

:pip_check
REM ============================================================================
REM 2. PIP
REM ============================================================================
echo.
echo [2/4] pip...

"!PYTHON_CMD!" -m pip --version >nul 2>&1
if not errorlevel 1 (
    echo  [OK] pip dostupno
    goto :packages
)

echo  pip ne nayden. Ustanavlivaem...
"!PYTHON_CMD!" -m ensurepip --upgrade
if errorlevel 1 (
    echo  [ERROR] ensurepip ne smog ustanovit pip!
    pause
    exit /b 1
)
echo  [OK] pip ustanovlen

:packages
REM ============================================================================
REM 3. PYTHON PAKETY
REM ============================================================================
echo.
echo [3/4] Python pakety...
echo.

"!PYTHON_CMD!" -m pip install --upgrade pip --trusted-host pypi.org --trusted-host files.pythonhosted.org

echo.
echo  Ustanavlivaem pakety...
echo.

"!PYTHON_CMD!" -c "import assemblyai, google.genai, dotenv, tqdm, httpx, pydantic, colorama" 2>nul
if not errorlevel 1 (
    echo  [OK] Vse pakety uzhe ustanovleny
    goto :ffmpeg_section
)

"!PYTHON_CMD!" -m pip install assemblyai google-genai python-dotenv tqdm httpx pydantic colorama ^
    --trusted-host pypi.org ^
    --trusted-host files.pythonhosted.org

if errorlevel 1 (
    echo.
    echo  [ERROR] Oshibka ustanovki paketov!
    echo  Proverite internet. Esli ne pomogaet - vkluchite VPN.
    pause
    exit /b 1
)
echo.
echo  [OK] Vse pakety ustanovleny

:ffmpeg_section
REM ============================================================================
REM 4. FFMPEG (ARM64 native est v winget)
REM ============================================================================
echo.
echo [4/4] FFmpeg...

ffmpeg -version >nul 2>&1
if not errorlevel 1 (
    echo  [OK] FFmpeg uzhe est
    goto :ffmpeg_ok
)

echo  FFmpeg ne nayden. Ustanavlivaem...

winget --version >nul 2>&1
if not errorlevel 1 (
    echo  [winget] Ustanavlivaem Gyan.FFmpeg...
    winget install --id Gyan.FFmpeg --silent --accept-package-agreements --accept-source-agreements
    for /f "usebackq delims=" %%P in (`powershell -NoProfile -Command "[Environment]::GetEnvironmentVariable('PATH','Machine') + ';' + [Environment]::GetEnvironmentVariable('PATH','User')"`) do set "PATH=%%P"
    ffmpeg -version >nul 2>&1
    if not errorlevel 1 (
        echo  [OK] FFmpeg ustanovlen
        goto :ffmpeg_ok
    )
    echo  FFmpeg ustanovlen. Perezapustite terminal esli ne rabotaet.
    set "NEED_RESTART=1"
    goto :ffmpeg_ok
)

choco --version >nul 2>&1
if not errorlevel 1 (
    echo  [choco] Ustanavlivaem FFmpeg...
    choco install ffmpeg -y
    timeout /t 3 /nobreak >nul
    ffmpeg -version >nul 2>&1
    if not errorlevel 1 (
        echo  [OK] FFmpeg ustanovlen
        goto :ffmpeg_ok
    )
    set "NEED_RESTART=1"
    goto :ffmpeg_ok
)

echo  winget i choco ne naydeny.
echo  Zapustite install_ffmpeg.bat ili ustanovite vruchnuyu: winget install Gyan.FFmpeg
set "NEED_RESTART=1"
pause

:ffmpeg_ok

REM ============================================================================
REM .ENV
REM ============================================================================
echo.
echo ================================================================================
echo  Konfiguracziya (.env)...
echo ================================================================================

if not exist "agent\.env" (
    if exist "agent\.env.example" (
        copy "agent\.env.example" "agent\.env" >nul
        echo  [OK] Sozdan agent\.env iz shablona
        echo.
        echo  [!!!] TREBUYUTSYA API KLYUCHI!
        echo  Otkrojte fayl  agent\.env  i zapolnite:
        echo.
        echo    ASSEMBLYAI_API_KEY  = poluchit: https://www.assemblyai.com/app/
        echo    GEMINI_API_KEY      = poluchit: https://aistudio.google.com/app/apikey
        echo    FASTGEN_API_KEY     = poluchit: https://fast-gen.ai
        echo.
    ) else (
        echo  [WARN] agent\.env.example ne nayden. Sozdajte agent\.env vruchnuyu.
    )
) else (
    echo  [OK] agent\.env uzhe sushchestvuet
)

REM ============================================================================
REM ITOG
REM ============================================================================
echo.
echo ================================================================================
echo  USTANOVKA ZAVERSHENA! (ARM64 Windows)
echo ================================================================================
echo.

if "!NEED_RESTART!"=="1" (
    echo  [!] Perezapustite terminal pered ispolzovaniem!
    echo.
)

echo  Sleduyushchie shagi:
echo.
echo  1. Otkrojte agent\.env i ukazite API klyuchi
echo  2. Polozhite audiofayl v papku  ready_to_go\
echo  3. Dobavte style guide (nazvanie: proekt.txt)
echo  4. Zapustite: run_stage1_simple.bat
echo.
echo ================================================================================
echo.
pause
