@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

REM ============================================================================
REM RUN_STAGE2_AUTO.BAT - Автоматическая склейка всех проектов
REM ============================================================================
REM
REM ЧТО ДЕЛАЕТ:
REM 1. Проверяет все проекты в папке projects
REM 2. Для каждого проекта запускает склейку
REM 3. Автоматически удаляет temp_processed (НЕ спрашивает!)
REM
REM ИСПОЛЬЗОВАНИЕ:
REM   run_stage2_auto.bat [fast|1080p]
REM
REM ПАРАМЕТРЫ:
REM   fast    - Быстрая склейка (по умолчанию)
REM   1080p   - Склейка с перекодированием в 1080p
REM ============================================================================

echo.
echo ================================================================================
echo АВТОМАТИЧЕСКАЯ СКЛЕЙКА ВСЕХ ПРОЕКТОВ (АВТОМАТИЧЕСКИЙ РЕЖИМ)
echo ================================================================================
echo.

REM Определение режима
set MODE=%1
if "%MODE%"=="" set MODE=fast

if "%MODE%"=="fast" goto :mode_fast
if "%MODE%"=="1080p" goto :mode_1080p
echo.
echo ❌ Неверный параметр!
echo    Использование: run_stage2_auto.bat [fast^|1080p]
echo    fast  - быстрая склейка ^(по умолчанию^)
echo    1080p - склейка с перекодированием
echo.
pause
exit /b 1

:mode_fast
echo    Режим: БЫСТРАЯ СКЛЕЙКА ^(без перекодирования^)
set BATCH_FILE=process_fast.bat
goto :mode_done

:mode_1080p
echo    Режим: СКЛЕЙКА 1080p ^(с перекодированием^)
set BATCH_FILE=process_1080p.bat

:mode_done

echo.

REM Переход в папку projects
cd projects

REM Проверка наличия папок проектов
set PROJECT_COUNT=0
for /d %%p in (*) do set /a PROJECT_COUNT+=1

if %PROJECT_COUNT% EQU 0 (
    echo.
    echo ❌ Нет проектов в папке projects!
    echo.
    pause
    exit /b 1
)

echo    Найдено проектов: %PROJECT_COUNT%
echo.

REM Запуск для каждого проекта
set SUCCESS_COUNT=0
set ERROR_COUNT=0

for /d %%p in (*) do (
    echo.
    echo ================================================================================
    echo ПРОЕКТ: %%p
    echo ================================================================================
    echo.
    
    REM Проверка montage_plan.json
    if exist "%%p\montage_plan.json" (
        echo    montage_plan.json [OK]
    ) else (
        echo    ❌ montage_plan.json не найден!
        echo       Запустите сначала run_stage1.bat
        set /a ERROR_COUNT+=1
        goto :next_project
    )
    
    REM Проверка аудиофайла
    if exist "%%p\%%p.wav" (
        echo    Аудиофайл [OK]
    ) else (
        echo    ❌ Аудиофайл не найден!
        set /a ERROR_COUNT+=1
        goto :next_project
    )
    
    REM Проверка видеофрагментов
    set HAS_VIDEO=0
    for %%f in ("%%p"\*.mp4) do (
        if not "%%~nxf"=="result.mp4" set HAS_VIDEO=1
    )
    
    if !HAS_VIDEO! EQU 0 (
        echo    ❌ Видеофрагменты не найдены!
        echo       Сгенерируйте видео в Veo3 и скачайте в папку проекта.
        set /a ERROR_COUNT+=1
        goto :next_project
    )
    
    echo    Видеофрагменты [OK]
    echo.
    echo    Запуск склейки...
    echo.
    
    REM Запуск склейки
    cd "%%p"
    call %BATCH_FILE%
    
    if errorlevel 1 (
        cd ..
        echo.
        echo    ❌ Ошибка склейки для %%p!
        set /a ERROR_COUNT+=1
    ) else (
        cd ..
        echo.
        echo    ✅ %%p завершен успешно!
        set /a SUCCESS_COUNT+=1
    )
    
    :next_project
)

REM ============================================================================
REM ИТОГИ
REM ============================================================================

echo.
echo ================================================================================
echo ИТОГИ АВТОМАТИЧЕСКОЙ СКЛЕЙКИ
echo ================================================================================
echo.
echo    Всего проектов: %PROJECT_COUNT%
echo    ✅ Успешно: %SUCCESS_COUNT%
echo    ❌ Ошибки: %ERROR_COUNT%
echo.

if %ERROR_COUNT% GTR 0 (
    echo    ⚠️  Некоторые проекты завершились с ошибками!
    echo.
) else (
    echo    ✅ Все проекты успешно склеены!
    echo.
    echo    РЕЗУЛЬТАТЫ:
    echo    • result.mp4 - в папках проектов (в корне!)
    echo    • result_original_audio.wav - в папках проектов (в корне!)
    echo    • Фрагменты Veo3 - в папках FLOW_*/veo3_fragments/
    echo.
)

echo ================================================================================
pause
