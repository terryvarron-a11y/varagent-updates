import os

files = [
    r'l:\_комбайн\режиссер_сцен\SCENAGENT_RTG\Var_Agent\1_silentstart.bat',
    r'l:\_комбайн\режиссер_сцен\SCENAGENT_RTG\Var_Agent\1_interactivestart.bat',
]
for path in files:
    data = open(path, 'rb').read()
    fixed = data.replace(b'\r\n', b'\n').replace(b'\n', b'\r\n')
    open(path, 'wb').write(fixed)
    print('Fixed CRLF: ' + os.path.basename(path))
