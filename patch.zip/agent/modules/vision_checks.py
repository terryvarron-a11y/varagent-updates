"""
vision_checks.py — Gemini Vision content scans for remix safety.

Runs before passing an image to any remixer (Grok or KieAI).
Each check function returns (found: bool, prompt_addition: str).
All functions are fail-safe: return (False, '') on error or missing API key.

Public API:
    check_minor_text(image_path)      — text mentioning minors/underage
    check_minor_visual(image_path)    — children/teenagers visible in scene
    check_violence(image_path)        — weapons/blood/gore/explicit violence
    check_prominent_person(image_path)— frontal face as main subject
    run_all_checks(image_path)        — all 4 checks, returns (flags_dict, combined_addition)
"""

import base64
import logging
from pathlib import Path

import config

# ──────────────────────────────────────────────────────────────────────────────
# Console colours
# ──────────────────────────────────────────────────────────────────────────────
_YELLOW = '\033[33m'
_RESET  = '\033[0m'


# ──────────────────────────────────────────────────────────────────────────────
# Internal helper
# ──────────────────────────────────────────────────────────────────────────────

def _gemini_vision_query(image_path: str, prompt: str) -> str:
    """
    Send image + prompt to Gemini Vision (model from config.VISION_CHECK_MODEL).
    Uses config.VISION_API_KEY (free-tier key, fallback to GEMINI_API_KEY).
    Returns uppercased response text, or '' on error / missing key.
    """
    if not config.VISION_API_KEY:
        return ''
    try:
        from google import genai as _genai
    except ImportError:
        logging.warning("vision_checks: google-genai not installed — scan skipped")
        return ''
    try:
        ext = image_path.lower().rsplit('.', 1)[-1]
        mime = {
            'jpg': 'image/jpeg', 'jpeg': 'image/jpeg',
            'png': 'image/png',  'webp': 'image/webp',
        }.get(ext, 'image/jpeg')
        with open(image_path, 'rb') as f:
            b64 = base64.b64encode(f.read()).decode()
        client = _genai.Client(api_key=config.VISION_API_KEY)
        response = client.models.generate_content(
            model=config.VISION_CHECK_MODEL,
            contents=[{'parts': [
                {'inline_data': {'mime_type': mime, 'data': b64}},
                {'text': prompt},
            ]}],
        )
        return (response.text or '').strip().upper()
    except Exception as e:
        logging.warning(f"vision_checks: Gemini query failed ({e})")
        return ''


# ──────────────────────────────────────────────────────────────────────────────
# Public check functions
# ──────────────────────────────────────────────────────────────────────────────

def check_minor_text(image_path: str) -> 'tuple[bool, str]':
    """
    Detect text in the image referencing minors (age numbers, 'teenager',
    'подросток', 'несовершеннолетний', etc.).
    Returns (found, prompt_addition).
    """
    prompt = (
        "Look at this image carefully. Does it contain any visible text, captions, "
        "watermarks, or overlaid words? If yes — does any of that text mention age "
        "(e.g. '13 years', '14 лет', 'тебе 13'), minors, underage, teenager, "
        "подросток, несовершеннолетний, or similar? "
        "Answer with exactly one word: YES or NO."
    )
    answer = _gemini_vision_query(image_path, prompt)
    found = 'YES' in answer
    if found:
        logging.warning(
            f"vision_checks: minor-related text in {Path(image_path).name} "
            "— erase instruction added to remix prompt"
        )
        print(
            f"  {_YELLOW}[VISION CHECK]{_RESET} minor text detected in "
            f"{Path(image_path).name} — adding erase instruction"
        )
        return True, " Remove all text overlays, captions and watermarks from the image."
    logging.debug(f"vision_checks: no minor text in {Path(image_path).name}")
    return False, ''


def check_minor_visual(image_path: str) -> 'tuple[bool, str]':
    """
    Detect children or teenagers visually in the scene (not via text — actual people).
    Returns (found, prompt_addition).
    """
    prompt = (
        "Look at this image carefully. Are there any children or teenagers "
        "(people who visually appear to be under 18 years old) present in the scene? "
        "Do not consider text or watermarks — only the actual people visible. "
        "Answer with exactly one word: YES or NO."
    )
    answer = _gemini_vision_query(image_path, prompt)
    found = 'YES' in answer
    if found:
        logging.warning(
            f"vision_checks: minors detected visually in {Path(image_path).name} "
            "— back-facing instruction added to remix prompt"
        )
        print(
            f"  {_YELLOW}[VISION CHECK]{_RESET} minors detected in "
            f"{Path(image_path).name} — enforcing back-facing"
        )
        return True, (
            " OVERRIDE: Every child and teenager in this scene must be rotated"
            " to face completely away from the camera."
            " Show only their back — no face, no front body visible."
            " This applies to every minor in the frame without exception."
            " Additionally, pull the camera far back to show a wide environmental shot —"
            " people should appear small in the frame, not close-up or centered."
        )
    logging.debug(f"vision_checks: no minors visually in {Path(image_path).name}")
    return False, ''


def check_violence(image_path: str) -> 'tuple[bool, str]':
    """
    Detect weapons, blood, gore, or explicit physical violence in the scene.
    Returns (found, prompt_addition).
    """
    prompt = (
        "Look at this image carefully. Does the scene contain any of the following: "
        "firearms, knives, swords, or other weapons; blood, wounds, or gore; "
        "or explicit physical violence / fighting? "
        "Answer with exactly one word: YES or NO."
    )
    answer = _gemini_vision_query(image_path, prompt)
    found = 'YES' in answer
    if found:
        logging.warning(
            f"vision_checks: violence/weapons detected in {Path(image_path).name} "
            "— sanitize instruction added to remix prompt"
        )
        print(
            f"  {_YELLOW}[VISION CHECK]{_RESET} violence/weapons detected in "
            f"{Path(image_path).name} — adding sanitize instruction"
        )
        return True, (
            " Remove all weapons, blood, gore and explicit violence from the scene."
            " Replace any weapons with neutral objects. Preserve the composition and mood."
        )
    logging.debug(f"vision_checks: no violence in {Path(image_path).name}")
    return False, ''


def check_prominent_person(image_path: str) -> 'tuple[bool, str]':
    """
    Detect a person whose face is prominently visible looking directly into the camera
    (full frontal / anface). If found, instructs remixer to turn to profile or 3/4 view.
    Returns (found, prompt_addition).
    """
    prompt = (
        "Look at this image carefully. Is there a person whose face is prominently "
        "visible and looking directly into the camera — full frontal face, "
        "anface view — as the main or central subject? "
        "A prominent face means it is large, centred, or clearly the focal point. "
        "Answer with exactly one word: YES or NO."
    )
    answer = _gemini_vision_query(image_path, prompt)
    found = 'YES' in answer
    if found:
        logging.warning(
            f"vision_checks: prominent frontal face in {Path(image_path).name} "
            "— profile instruction added to remix prompt"
        )
        print(
            f"  {_YELLOW}[VISION CHECK]{_RESET} prominent frontal face in "
            f"{Path(image_path).name} — adding profile instruction"
        )
        return True, (
            " Rotate the main person's head and body to a side profile or 3/4 view."
            " The face must NOT look directly into the camera."
            " Show the person from a side angle, 45-degree, or three-quarter perspective."
        )
    logging.debug(f"vision_checks: no prominent frontal face in {Path(image_path).name}")
    return False, ''


# ──────────────────────────────────────────────────────────────────────────────
# Batch runner
# ──────────────────────────────────────────────────────────────────────────────

def run_all_checks(image_path: str) -> 'tuple[dict, str]':
    """
    Run all 4 vision checks on image_path.

    Returns:
        flags   — dict with keys: 'minor_text', 'minor_visual', 'violence', 'prominent_person'
        addition — combined prompt suffix string (space-joined, ready to append)
    """
    flags = {}
    additions = []

    for key, fn in (
        ('minor_text',       check_minor_text),
        ('minor_visual',     check_minor_visual),
        ('violence',         check_violence),
        ('prominent_person', check_prominent_person),
    ):
        found, add = fn(image_path)
        flags[key] = found
        if add:
            additions.append(add)

    return flags, ''.join(additions)
