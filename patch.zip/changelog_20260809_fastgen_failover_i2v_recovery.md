# FastGen key routing and i2v recovery - 2026-08-09

## Step 1 - Log audit

- Confirmed that the affected run received `ImgKey: 2`.
- Confirmed that FastGen Key2 returned `AUTH.LICENSE_EXPIRED` for all clips.
- Confirmed that the old pre-concat fallback hardcoded Key1, generated still images,
  and then ended without returning those images to Veo i2v.

## Step 2 - Complete per-file settings snapshot

- Every queue item passes its complete saved settings dictionary directly to the
  batch runner.
- The worker uses an immutable snapshot-bound settings view. Existing
  `self.<setting>.get()` calls resolve to the current file's frozen value instead
  of reading a live Tk variable from the background thread.
- The snapshot includes all public pipeline Tk settings, hidden Flow Ultra
  selectors, application-level chain settings, SG/logo/prompt paths, reference
  lists, and per-file SG/ref/logo mappings.
- FastGen key selection is normalized in the snapshot and stores both the
  selection (`main`, `backup`, `key3`, `key4`, `both`) and resolved slot
  (`1`, `2`, `3`, `4`, `all`).
- Queue execution never writes a task snapshot back into Tk. The GUI remains
  untouched while starred snapshots go directly to the worker.
- Unstarred queue items capture the live GUI in the Tk thread at the exact moment
  they become the next task. Starred items always use the manually saved snapshot.
- Live-added files follow the same rule, and queue selection plus snapshot capture
  is atomic in the Tk thread.
- Pipeline logs include the settings source, FastGen selection, and resolved slot.

## Step 3 - FastGen auth failover

- Removed the one-way Main-to-Backup license failover.
- A dead FastGen key now stops the current cycle immediately.
- The dead slot is disabled and pending clips continue on another configured key.
- This works in both directions, including Key2-to-Key1, and with multi-key mode.

## Step 4 - Pre-concat static fallback

- Image fallback uses the selected FastGen slot instead of hardcoded Key1.
- Pre-concat fallback images remain static and are never automatically sent to Veo.
- Images from Real Photo, stock, regular ImgGen, and Veo static fallback are all
  treated as finished media for concat.
- Static images already present in `vid_img/` are recognized as finished media.
- Only the normal video-generation stage decides whether an image is sent to Veo.

## Verification

- `python -m py_compile varagent.py agent/agent.py agent/modules/fastgen.py`
- Snapshot mapping test: `main -> 1`, `backup -> 2`, `both -> all`.
- Three-item queue test: `main -> backup -> main` launched as slots `1 -> 2 -> 1`.
- Complete snapshot capture test includes hidden Flow Ultra, chain, SG/logo/prompt,
  and reference settings.
- Simulated auth failure test: `Key2 (license dead) -> Key1 -> generated`.
- Pre-concat static-media test:
  `fallback image generated -> zero automatic Veo calls`.

## Step 5 - Tk portable sync

- Created portable backup:
  `_codex_backups/publish_snapshot_fastgen_20260809_170146`.
- Synced the queue snapshot, FastGen auth failover, and static pre-concat changes.
- Deliberately excluded the experimental Extreme Picture Finder bridge and its
  `config.py`, `real_photo.py`, `updater.py`, CLI, GUI, and tool changes.
- Verified identical FastGen module hashes and matching queue behavior in dev and
  portable.

## Step 6 - Tk portable publish

- Published full Tk portable release `v2026.08.09.1719`.
- Verified public `version.json` and `patch.zip` agree on SHA-256:
  `0e790ac95d18fe145e6413450853e22d43dbd2747becfea30b41663b36a63057`.
- Audited all 242 files in the public archive: no personal API-key patterns and
  no Extreme Picture Finder bridge code were found.

## Step 7 - Snapshot proxy runtime hotfix

- Fixed a runtime regression from `v2026.08.09.1719`: the snapshot proxy rebound
  `staticmethod` descriptors as instance methods, causing
  `_normalize_fastgen_key_selection()` to receive an extra argument.
- Descriptor lookup now uses `inspect.getattr_static`, preserving correct binding
  for instance methods, static methods, class methods, and properties.
- Replaced FastGen-only queue logging with a snapshot launch summary covering
  start point, direction, clip mode, ImgGen, video mode/engine, ratio, workers,
  and relevant key selection.
- A `t2v` run with ImgGen disabled no longer reports unrelated FastGen settings.
- Added `test_snapshot_proxy_runtime.py` to reproduce the real proxy route and
  verify the `t2v` summary. The dev-only test is excluded from portable.
- Created pre-hotfix backups:
  `_codex_backups/snapshot_proxy_hotfix_20260809_174050`.
