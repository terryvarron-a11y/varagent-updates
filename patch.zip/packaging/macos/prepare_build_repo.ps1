param(
    [Parameter(Mandatory = $true)]
    [string]$Destination,
    [string]$SourceRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
)

$ErrorActionPreference = 'Stop'
$source = (Resolve-Path -LiteralPath $SourceRoot).Path
$dest = [IO.Path]::GetFullPath($Destination)
if ($dest -eq $source -or $dest.StartsWith($source + [IO.Path]::DirectorySeparatorChar)) {
    throw "Destination must be outside the source tree: $dest"
}

New-Item -ItemType Directory -Path $dest -Force | Out-Null
$payload = Join-Path $dest 'payload'
New-Item -ItemType Directory -Path $payload -Force | Out-Null

$rootFiles = @(
    '.env.example',
    'api-1.json',
    'check_and_fix.command',
    'check_install.command',
    'emergency_update.command',
    'emergency_update.py',
    'fix_macos.command',
    'fix_ssl_mac.command',
    'fix_tkinter.command',
    'install.command',
    'install_colorama.command',
    'install_ffmpeg.command',
    'install_mac.command',
    'photo_concat.py',
    'project_init.py',
    'publisher.py',
    'README.md',
    'README_MACOS.md',
    'unlock_mac.py',
    'update.command',
    'usatayai_bridge.py',
    'varagent.command',
    'varagent.py',
    'variable_concat.py',
    'video_concat.py'
)

foreach ($name in $rootFiles) {
    $item = Join-Path $source $name
    if (Test-Path -LiteralPath $item -PathType Leaf) {
        Copy-Item -LiteralPath $item -Destination (Join-Path $payload $name)
    }
}

$allowedDirs = @(
    'agent', 'APPS', 'audio_tools', 'docs', 'modes', 'prompts_other',
    'Scenarium', 'supabase', 'themes', 'tools', 'to_masterremix',
    'youtube_gui_downloader'
)
$excludedDirNames = @(
    '.git', '.pytest_cache', '__pycache__', 'logs', 'temp', 'projects',
    '_test_chat_api', '_backup_20260314_', '_backup_20260405_pre_gpt_director',
    '_backup_cinai_20260813', '_backup_cinai_full_20260813_231123',
    '_backup_gpt_nexus_20260814_032812'
)

foreach ($dirName in $allowedDirs) {
    $dir = Join-Path $source $dirName
    if (-not (Test-Path -LiteralPath $dir -PathType Container)) { continue }
    Get-ChildItem -LiteralPath $dir -Recurse -File -Force | ForEach-Object {
        $relative = $_.FullName.Substring($source.Length).TrimStart('\', '/')
        $segments = $relative -split '[\\/]'
        if ($segments | Where-Object { $excludedDirNames -contains $_ -or $_ -like '_backup*' }) { return }
        if ($_.Name -match '(^test_.*\.py$|\.bak(?:_|$)|\.backup(?:_|$)|\.predrefactor|\.premig|\.broken|\.pyc$|\.log$|^\.env$|^cost_log\.json$|\.exe$|\.dll$|\.bat$|\.zip$|\.rar$)') { return }
        $target = Join-Path $payload $relative
        New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force | Out-Null
        Copy-Item -LiteralPath $_.FullName -Destination $target
    }
}

foreach ($runtimeDir in @('projects', 'pipeline_queue', 'ready_to_go', 'chat_sessions', 'veononstop_output', 'voice_samples')) {
    New-Item -ItemType Directory -Path (Join-Path $payload $runtimeDir) -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $payload "$runtimeDir\.keep") -Value '' -Encoding ascii
}

$packagingTarget = Join-Path $dest 'packaging\macos'
New-Item -ItemType Directory -Path $packagingTarget -Force | Out-Null
Copy-Item -Path (Join-Path $source 'packaging\macos\*.sh') -Destination $packagingTarget

$workflowSource = Join-Path $source '.github\workflows\build-macos.yml'
$workflowTarget = Join-Path $dest '.github\workflows'
New-Item -ItemType Directory -Path $workflowTarget -Force | Out-Null
Copy-Item -LiteralPath $workflowSource -Destination $workflowTarget

$forbidden = Get-ChildItem -LiteralPath $dest -Recurse -File -Force | Where-Object {
    $_.Name -eq '.env' -or $_.Extension -in @('.exe', '.dll', '.bat', '.rar')
}
if ($forbidden) {
    throw "Forbidden files entered build staging: $($forbidden.FullName -join ', ')"
}

$files = Get-ChildItem -LiteralPath $payload -Recurse -File
$size = ($files | Measure-Object Length -Sum).Sum
Write-Host ("Prepared {0} files, {1:N1} MB at {2}" -f $files.Count, ($size / 1MB), $dest)
