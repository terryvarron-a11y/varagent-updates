# Non-AI image source mode

## What changed

- Added the GUI checkbox `Non-AI sources only`.
- Added three allocation fields:
  - `NON_AI_REAL_PHOTO_PERCENT`
  - `NON_AI_INFOGRAPHIC_PERCENT`
  - `NON_AI_STOCK_PERCENT`
- Percentages are normalized over enabled stages only. For example, with
  Real Photo and Stock enabled and values `50/25/25`, the effective split is
  `Real Photo 67% / Stock 33%`.
- Pass 1 receives an explicit directive to mark every clip.
- A deterministic post-parse allocator is the final authority and writes
  `image_source_policy` into `montage_plan.json`.
- The ordinary ImageGen and VideoGen post-action is forced to `skip`.
- Real Photo and Stock intro gates are bypassed in this mode, because removing a
  marker would incorrectly reopen an AI route.
- Real Photo and Stock wait for their configured stage deadlines instead of
  using the normal short AI-fallback grace period.
- Missing non-AI media remains marked as pending and is never sent to
  FastGen, VeoNonStop, CinAI, or Flow Ultra by the pre-concat fallback.

## Important behavior

At least one of Real Photo, Infographic, or Stock must be enabled, and their
configured percentages must contain a positive total. The allocator uses the
largest-remainder method, so integer clip counts always add up to the total
number of clips.

Infographic remains a separate static-image route. It is allowed in this mode
when the user enables it; ordinary scene-image/video generation is the part
that is disabled.

## Files

- `agent/modules/non_ai_image_policy.py`
- `agent/modules/director.py`
- `agent/modules/gpt_director.py`
- `agent/modules/chat_director.py`
- `agent/modules/clip_sources.py`
- `agent/modules/real_photo.py`
- `agent/agent.py`
- `agent/config.py`
- `varagent.py`
