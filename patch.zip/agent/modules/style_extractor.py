"""
Style Extractor — НЕЙРО-выделение повторяющихся блоков из стайлгайда.

В отличие от питон-регекса (gpt_director.extract_style_block / extract_negative_block),
который ищет блоки по СТРОГИМ ЯКОРЯМ ("...VERBATIM..." + ```code```), здесь модель
СЕМАНТИЧЕСКИ определяет, какой блок СТИЛЯ и какой блок НЕГАТИВА должны одинаково
повторяться в каждом промпте сцены — без опоры на фразы-якоря. Работает на любом
стайлгайде, где у разных юзеров блоки названы/оформлены по-разному.

Один дешёвый вызов на проект. Результат кэшируется в style_blocks.json.
"""
from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Optional, Dict

import config


_EXTRACT_PROMPT = """You are given a VISUAL STYLE GUIDE for an AI image/video pipeline.
The guide instructs a director to write ONE prompt per scene. In each generated prompt,
some content is UNIQUE per scene (camera angle, action, subjects, chosen light, mood)
and some content is a FIXED block that is appended IDENTICALLY (verbatim) to EVERY prompt:
the visual STYLE block and the NEGATIVE-prompt block.

Your task: read the style guide and determine, BY MEANING (not by looking for any marker
phrase), the two fixed blocks that should be appended unchanged to the end of EVERY scene
prompt:
1. style_block — the recurring visual style / render / palette / film-look description
   that every prompt shares.
2. negative_block — the recurring negative prompt (things to avoid / forbidden), including
   any fixed ending clause that always closes the prompt.

Rules:
- Return the text EXACTLY as it must be appended (verbatim, ready to concatenate).
- Do NOT invent or summarize — lift the actual recurring wording from the guide.
- Do NOT include the per-scene parts (camera/action/subjects/light) — only the fixed blocks.
- If a block genuinely does not exist in this guide, return an empty string for it.

Return STRICT JSON only, no markdown, no commentary:
{"style_block": "<verbatim style text or empty>", "negative_block": "<verbatim negative text or empty>"}

STYLE GUIDE:
---
%s
---
Return ONLY the JSON object."""


def _parse(text: str) -> Dict[str, str]:
    text = (text or '').strip()
    if not text:
        return {}
    def _norm(d):
        if not isinstance(d, dict):
            return {}
        return {
            'style_block': str(d.get('style_block', '') or '').strip(),
            'negative_block': str(d.get('negative_block', '') or '').strip(),
        }
    try:
        return _norm(json.loads(text))
    except json.JSONDecodeError:
        pass
    s, e = text.find('{'), text.rfind('}')
    if s >= 0 and e > s:
        try:
            return _norm(json.loads(text[s:e + 1]))
        except json.JSONDecodeError:
            pass
    return {}


def extract_style_blocks_via_llm(
    style_guide: str,
    backend: str,
    model_name: Optional[str] = None,
) -> Dict[str, str]:
    """Семантически выделяет {style_block, negative_block} из стайлгайда через LLM.

    backend: 'deepseek' | 'openrouter' (chat) | 'gemini' | 'claude_api'/'anthropic'.
             ('gpt'/'claude_code' не поддержаны для дешёвого выделения — вернёт {},
              вызывающий код упадёт на питон-регекс.)
    Возвращает {} при ошибке/неподдерживаемом backend → fallback на regex.
    """
    if not style_guide:
        return {}
    backend = (backend or '').strip().lower()
    prompt = _EXTRACT_PROMPT % style_guide

    try:
        if backend in ('deepseek', 'openrouter'):
            from modules import chat_client
            model = model_name or (config.DEEPSEEK_MODEL if backend == 'deepseek'
                                   else config.OPENROUTER_MODEL)
            raw = chat_client.chat_completion(
                backend, model, [{"role": "user", "content": prompt}],
                max_tokens=8000, reasoning_level='off', web=False,
                json_mode=True, timeout=180,
            )
            return _parse(raw)

        if backend == 'gemini':
            from google import genai
            client = genai.Client(api_key=config.GEMINI_API_KEY)
            resp = client.models.generate_content(
                model=model_name or config.GEMINI_MODEL, contents=prompt)
            return _parse(getattr(resp, 'text', '') or '')

        if backend in ('claude_api', 'anthropic'):
            from modules.claude_api_runner import ClaudeApiRunner
            runner = ClaudeApiRunner(model_name=model_name)
            out = runner.complete(prompt, label='Style Extract', temperature=0.1,
                                  max_tokens=8000)
            text = out[0] if isinstance(out, (tuple, list)) else out
            return _parse(text)

    except Exception as e:
        logging.warning(f"Style extract via {backend} failed: {e}")
        return {}

    logging.info(f"Style extract: backend '{backend}' не поддержан для нейро-выделения")
    return {}


def _pick_extract_backend() -> str:
    """Авто-выбор дешёвого backend для выделения по доступному ключу."""
    b = (getattr(config, 'STYLE_EXTRACT_BACKEND', '') or '').strip().lower()
    if b:
        return b
    if getattr(config, 'DEEPSEEK_API_KEY', ''):
        return 'deepseek'
    if getattr(config, 'OPENROUTER_API_KEY', ''):
        return 'openrouter'
    if getattr(config, 'CLAUDE_API_KEY', '') or getattr(config, 'ANTHROPIC_API_KEY', ''):
        return 'claude_api'
    return 'gemini'


def _regex_blocks(style_guide: str) -> Dict[str, str]:
    """Питон-регекс по якорям (lazy import gpt_director, чтобы не плодить цикл)."""
    from modules.gpt_director import extract_style_block, extract_negative_block
    return {
        'style_block': extract_style_block(style_guide) or '',
        'negative_block': extract_negative_block(style_guide) or '',
    }


def resolve_style_blocks(style_guide: str, output_dir) -> Dict[str, str]:
    """Возвращает {style_block, negative_block} с приоритетом и кэшем style_blocks.json.

    Логика по config.STYLE_EXTRACT_MODE:
      neuro → нейро-выделение (fallback на regex при пустом результате)
      regex → питон по якорям
      off   → {} (модель пишет блоки сама)
    Результат кэшируется в <output_dir>/style_blocks.json (не дёргать нейру повторно;
    юзер может вручную поправить файл). Кэш имеет приоритет над любым режимом.
    """
    cache = Path(output_dir) / 'style_blocks.json'
    if cache.exists():
        try:
            data = json.loads(cache.read_text(encoding='utf-8-sig'))
            if isinstance(data, dict):
                return {'style_block': str(data.get('style_block', '') or ''),
                        'negative_block': str(data.get('negative_block', '') or '')}
        except Exception:
            pass

    mode = (getattr(config, 'STYLE_EXTRACT_MODE', 'neuro') or 'neuro').strip().lower()
    if mode == 'off':
        return {}

    result: Dict[str, str] = {'style_block': '', 'negative_block': ''}
    if mode == 'neuro':
        backend = _pick_extract_backend()
        model = getattr(config, 'STYLE_EXTRACT_MODEL', '') or None
        print(f"   🧠 Style Extract (нейро, {backend}): выделяю style/negative блоки из стайлгайда...")
        r = extract_style_blocks_via_llm(style_guide, backend, model)
        if r and (r.get('style_block') or r.get('negative_block')):
            result = r
        else:
            print("   ↩️  Нейро-выделение пусто — fallback на питон-регекс по якорям")
            result = _regex_blocks(style_guide)
    else:  # regex
        result = _regex_blocks(style_guide)

    if result.get('style_block') or result.get('negative_block'):
        try:
            cache.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        except Exception as _e:
            logging.warning(f"style_blocks.json write failed: {_e}")
        # печать отдельно — эмодзи/charmap на Windows-консоли не должны маскировать запись
        try:
            print(f"   style_blocks.json: style={len(result.get('style_block','').split())} words, "
                  f"negative={len(result.get('negative_block','').split())} words (editable by hand)")
        except Exception:
            pass
    return result
