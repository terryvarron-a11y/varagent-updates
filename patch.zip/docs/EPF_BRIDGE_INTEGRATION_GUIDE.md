# EPF Bridge Integration Guide

See the full provider-neutral integration guide in the development copy:

[EPF_BRIDGE_INTEGRATION_GUIDE.md](../../VARAGENT_API/docs/EPF_BRIDGE_INTEGRATION_GUIDE.md)

The guide covers EPF's Windows-only role, native `.epr` jobs, the
`update SearchFileName=...` launch contract, candidate validation, vision
selection, replacement of generated placeholders, deadlines, fallback states,
licensing metadata, and a generic CLI/API shape.
