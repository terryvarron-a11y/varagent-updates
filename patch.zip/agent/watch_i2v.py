"""
watch_i2v.py — Watch generated/ and animate images as they appear via VeoNonStop i2v.

Run in parallel with FastGen to animate images without waiting for all to finish.
Supports dual-key and single-prompt / per-clip prompt modes.
"""
import sys
# Force UTF-8 output before colorama wraps stdout (avoids cp1251 crash on Cyrillic/NFD paths)
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
if hasattr(sys.stderr, 'reconfigure'):
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')
import shutil
import time
import json
import signal
import logging
import argparse
import threading
from pathlib import Path
from typing import Optional, Dict, Set, List
from concurrent.futures import ThreadPoolExecutor

# Add agent dir to path
sys.path.insert(0, str(Path(__file__).parent))

import config
from extract_prompt import find_prompts_file, extract_all_prompts
from modules.veononstop import VeoNonStopClient
from modules.veo_video import _process_single_clip, _shutdown_requested, _kieai_image_remix
import modules.veo_video as _vv

IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.webp'}
MIN_FILE_SIZE    = 5_000   # bytes
FILE_STABLE_SECS = 3       # seconds without modification = file complete

_YELLOW = '\033[33m'
_GREEN  = '\033[32m'
_RED    = '\033[31m'
_RESET  = '\033[0m'


def _find_image(generated_dir: Path, cid: int) -> Optional[str]:
    for ext in IMAGE_EXTENSIONS:
        p = generated_dir / f"{cid:03d}{ext}"
        if p.exists() and p.stat().st_size > MIN_FILE_SIZE:
            return str(p)
    return None


def _is_stable(image_path: str) -> bool:
    age = time.time() - Path(image_path).stat().st_mtime
    return age >= FILE_STABLE_SECS


def _has_video(vid_img_dir: Path, cid: int) -> bool:
    p = vid_img_dir / f"{cid:03d}.mp4"
    return p.exists() and p.stat().st_size > 1000


def _init_client(api_key: Optional[str], max_parallel: int, label: str, no_cancel: bool = False):
    """Create client, cancel zombies, cap by concurrent_tasks, return (client, mp, sem)."""
    client = VeoNonStopClient(api_key=api_key)
    # Отменяем зомби-задачи от предыдущих прогонов
    # no_cancel=True пропускает (когда параллельно идёт другая генерация)
    if no_cancel:
        print(f"  [{label}] --no-cancel: skipping zombie task cleanup.")
    else:
        try:
            n = client.cancel_all_tasks()
            if n:
                print(f"  [{label}] Cancelled {n} zombie task(s). Waiting 3s...")
                time.sleep(3)
            else:
                print(f"  [{label}] No zombie tasks.")
        except Exception as e:
            print(f"  [{label}] cancel_all_tasks failed: {e}")
    try:
        account = client.get_account_info()
        ct = account.get('concurrent_tasks', max_parallel)
        mp = min(max_parallel, ct)
        print(f"  [{label}] Plan: {account.get('plan','?')} | concurrent_tasks: {ct} | using: {mp}")
        logging.info(f"{label}: plan={account.get('plan')}, concurrent_tasks={ct}, mp={mp}")
    except Exception as e:
        mp = max_parallel
        logging.warning(f"{label}: could not get account info: {e}")
    sem = threading.Semaphore(max(1, mp // 3))
    return client, mp, sem


def main():
    parser = argparse.ArgumentParser(description='Watch generated/ and animate with i2v')
    parser.add_argument('--project',  required=True, help='Project name or full path')
    parser.add_argument('--parallel', type=int, default=None)
    parser.add_argument('--aspect',   default=None)
    parser.add_argument('--poll',     type=int, default=15, help='Poll interval seconds')
    parser.add_argument('--api-key',  default=None, help='VeoNonStop API key (overrides .env)')
    parser.add_argument('--key-slot', default='both', choices=['1', '2', 'both'],
                        help='Which API key to use: 1=Key1 only, 2=Key2 only, both=dual (default)')
    parser.add_argument('--no-cancel', action='store_true', default=False,
                        help='Skip cancel-all-tasks on startup (use when another generation runs in parallel)')
    parser.add_argument('--single-prompt', action='store_true',
                        help='Use single_prompt.txt from project dir for all clips')
    args = parser.parse_args()

    # --- Resolve project path ---
    agent_dir    = Path(__file__).parent
    project_root = agent_dir.parent / 'projects'
    project_path = Path(args.project) if Path(args.project).is_absolute() \
                   else project_root / args.project

    if not project_path.exists():
        print(f"[ERROR] Project not found: {project_path}")
        sys.exit(1)

    generated_dir = project_path / 'generated'
    vid_img_dir   = project_path / 'vid_img'
    vid_img_dir.mkdir(exist_ok=True)

    # --- Logging ---
    log_ts   = time.strftime('%Y%m%d_%H%M%S')
    log_path = project_path / f'watch_i2v_{log_ts}.log'
    logging.basicConfig(
        level=logging.INFO,
        handlers=[logging.FileHandler(str(log_path), encoding='utf-8')],
        format='%(asctime)s | %(levelname)-8s | %(message)s',
    )
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    logging.getLogger('requests').setLevel(logging.WARNING)

    # --- Load montage_plan ---
    plan_path = project_path / 'montage_plan.json'
    if not plan_path.exists():
        print(f"[ERROR] montage_plan.json not found in {project_path}")
        sys.exit(1)
    with open(plan_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    plan         = data.get('montage_plan', data)
    all_clip_ids = [c['id'] for c in plan.get('clips', [])]
    if not all_clip_ids:
        print("[ERROR] No clips in montage_plan.json")
        sys.exit(1)

    # --- Load prompts ---
    prompts_map: Dict[int, str] = {}
    single_prompt_mode = args.single_prompt

    if single_prompt_mode:
        sp_path = project_path / 'single_prompt.txt'
        if not sp_path.exists():
            print(f"[ERROR] single_prompt.txt not found in {project_path}")
            sys.exit(1)
        single_prompt_text = sp_path.read_text(encoding='utf-8').strip()
        if not single_prompt_text:
            print(f"[ERROR] single_prompt.txt is empty")
            sys.exit(1)
        for cid in all_clip_ids:
            prompts_map[cid] = single_prompt_text
        print(f"  Prompt mode: SINGLE — \"{single_prompt_text[:80]}{'...' if len(single_prompt_text)>80 else ''}\"")
    else:
        prompts_file = find_prompts_file(str(project_path))
        if prompts_file:
            prompts_map = extract_all_prompts(prompts_file)
            print(f"  Prompt mode: PER-CLIP — {len(prompts_map)} prompts from {Path(prompts_file).name}")
        else:
            print("  [WARN] Prompts file not found — using empty prompts")

    # --- Init clients ---
    max_parallel = args.parallel or config.VEONONSTOP_MAX_PARALLEL

    clients_cfg: List[Dict] = []

    client1, mp1, sem1 = _init_client(args.api_key, max_parallel, 'Key1', no_cancel=args.no_cancel)
    clients_cfg.append({'client': client1, 'mp': mp1, 'sem': sem1, 'label': 'Key1'})

    if config.VEONONSTOP_API_KEY_2:
        mp2_default = config.VEONONSTOP_MAX_PARALLEL_2
        client2, mp2, sem2 = _init_client(config.VEONONSTOP_API_KEY_2, mp2_default, 'Key2', no_cancel=args.no_cancel)
        clients_cfg.append({'client': client2, 'mp': mp2, 'sem': sem2, 'label': 'Key2'})

    # --- Key slot filter ---
    if args.key_slot == '1':
        clients_cfg = [c for c in clients_cfg if c['label'] == 'Key1']
        print(f"  Key slot: Key1 only")
    elif args.key_slot == '2':
        clients_cfg = [c for c in clients_cfg if c['label'] == 'Key2']
        if not clients_cfg:
            print("[ERROR] Key2 not configured (VEONONSTOP_API_KEY_2 not set in .env)")
            sys.exit(1)
        print(f"  Key slot: Key2 only")
    else:
        print(f"  Key slot: both")

    total_parallel = sum(cfg['mp'] for cfg in clients_cfg)

    # Disable global semaphore — each cfg has its own
    _vv._submit_semaphore = None

    aspect = args.aspect or config.VEONONSTOP_ASPECT_RATIO

    # --- Worker ID tracking ---
    _worker_counter = {'next': 0}
    _worker_lock    = threading.Lock()
    _worker_map: Dict[int, int] = {}

    def _get_worker_id() -> int:
        tid = threading.get_ident()
        with _worker_lock:
            if tid not in _worker_map:
                _worker_map[tid] = _worker_counter['next']
                _worker_counter['next'] += 1
            return _worker_map[tid]

    # --- Ctrl+C handler ---
    _original_sigint = signal.getsignal(signal.SIGINT)

    def _graceful_shutdown(signum, frame):
        if _shutdown_requested.is_set():
            print(f"\n\n  {_RED}[FORCE QUIT]{_RESET} Second Ctrl+C — exiting!")
            signal.signal(signal.SIGINT, _original_sigint)
            raise KeyboardInterrupt
        _shutdown_requested.set()
        print(f"\n\n  {_YELLOW}[SHUTDOWN]{_RESET} Ctrl+C — cancelling tasks...")
        for cfg in clients_cfg:
            try:
                n = cfg['client'].cancel_all_tasks()
                print(f"  {_YELLOW}[SHUTDOWN]{_RESET} [{cfg['label']}] cancelled {n} task(s)")
            except Exception as e:
                print(f"  {_YELLOW}[SHUTDOWN]{_RESET} [{cfg['label']}] cancel failed: {e}")

    signal.signal(signal.SIGINT, _graceful_shutdown)

    # --- Print summary ---
    print(f"\n{'='*60}")
    print(f"  PARALLEL I2V WATCHER")
    print(f"{'='*60}")
    print(f"  Project:  {project_path.name}")
    print(f"  Watch:    {generated_dir}")
    print(f"  Output:   {vid_img_dir}")
    print(f"  Clips:    {len(all_clip_ids)}")
    print(f"  Parallel: {total_parallel}" + (f" ({'+'.join(str(c['mp']) for c in clients_cfg)} keys)" if len(clients_cfg) > 1 else ""))
    print(f"  Aspect:   {aspect}")
    print(f"  Poll:     every {args.poll}s")
    print(f"  Log:      {log_path.name}")
    print(f"{'='*60}")
    print(f"\n  Waiting for images in generated/ ...\n  (Ctrl+C to stop)\n")

    submitted: Set[int] = set()
    active_futures: Dict = {}   # future -> cid
    _ok_durations: List[float] = []  # для расчёта среднего времени
    clip_retries: Dict[int, int] = {}     # cid -> plain retry count
    clip_remixed_img: Dict[int, str] = {} # cid -> remixed image path (replaces original on submit)
    clip_remixed: Set[int] = set()        # cids that already went through Kie.ai remix
    clip_static_done: Set[int] = set()    # cids that got static fallback (image copied to vid_img/)
    clip_remix_pending: Set[int] = set()  # cids queued for proactive Kie.ai remix (invalid_argument)
    MAX_CLIP_RETRIES = 3

    # Pre-mark already done
    for cid in all_clip_ids:
        if _has_video(vid_img_dir, cid):
            submitted.add(cid)
    if submitted:
        print(f"  Already done: {len(submitted)} clips (skipping)")

    with ThreadPoolExecutor(max_workers=total_parallel) as executor:
        try:
            while not _shutdown_requested.is_set():

                # --- Collect completed futures ---
                done_futs = [f for f in list(active_futures) if f.done()]
                for fut in done_futs:
                    cid = active_futures.pop(fut)
                    try:
                        r      = fut.result()
                        status = r.get('status', '?')
                        icon   = '+' if status == 'ok' else 'X'
                        dur    = r.get('duration_sec', 0)
                        key    = r.get('key_label', '')
                        if status == 'ok' and dur > 0:
                            _ok_durations.append(dur)
                        avg_str = f'  avg={sum(_ok_durations)/len(_ok_durations):.0f}s/{len(_ok_durations)}' if _ok_durations else ''
                        key_str = f' [{key}]' if key else ''
                        _done_color = _GREEN if status == 'ok' else _YELLOW
                        print(f"  {_done_color}[DONE]{_RESET} #{cid:03d} [{icon}]{key_str} {status}  ({dur:.0f}s){avg_str}")
                        logging.info(f"Clip #{cid}: {status} [{key}] ({dur:.0f}s){avg_str}")
                        # Static fallback: status='ok' but no .mp4 — image was copied instead
                        if status == 'ok' and not _has_video(vid_img_dir, cid):
                            clip_static_done.add(cid)
                            logging.info(f"Clip #{cid}: static fallback detected — added to clip_static_done")
                        # Proactive remix: invalid_argument + retries exhausted → queue remix now
                        if (status != 'ok'
                                and r.get('errors', {}).get('invalid_argument', 0) > 0
                                and clip_retries.get(cid, 0) >= MAX_CLIP_RETRIES
                                and cid not in clip_remixed
                                and cid not in clip_remix_pending):
                            clip_remix_pending.add(cid)
                            logging.warning(f"Clip #{cid}: invalid_argument exhausted retries — queued for proactive Kie.ai remix")
                    except Exception as e:
                        print(f"  {_RED}[DONE]{_RESET} #{cid:03d} [X] error: {e}")
                        logging.error(f"Clip #{cid}: exception: {e}")

                # --- Proactive retry: re-queue failed clips if retries not exhausted ---
                _in_flight_cids = set(active_futures.values())
                for cid in all_clip_ids:
                    if (cid in submitted
                            and cid not in _in_flight_cids
                            and cid not in clip_static_done
                            and not _has_video(vid_img_dir, cid)
                            and clip_retries.get(cid, 0) < MAX_CLIP_RETRIES
                            and bool(clip_remixed_img.get(cid) or _find_image(generated_dir, cid))):
                        clip_retries[cid] = clip_retries.get(cid, 0) + 1
                        submitted.discard(cid)
                        print(f"  {_YELLOW}[RETRY]{_RESET} #{cid:03d}: re-queuing (attempt {clip_retries[cid]}/{MAX_CLIP_RETRIES})")
                        logging.warning(f"Watch i2v: re-queuing clip #{cid} attempt {clip_retries[cid]}/{MAX_CLIP_RETRIES}")

                # --- Proactive Kie.ai remix for invalid_argument clips ---
                if clip_remix_pending:
                    _in_flight_cids_now = set(active_futures.values())
                    for cid in list(clip_remix_pending):
                        if cid in _in_flight_cids_now:
                            continue  # still running, wait
                        clip_remix_pending.discard(cid)
                        orig_img = _find_image(generated_dir, cid)
                        if not orig_img:
                            clip_static_done.add(cid)
                            continue
                        print(f"  {_YELLOW}[WATCH REMIX]{_RESET} #{cid:03d}: invalid_argument exhausted — remixing via Kie.ai...")
                        logging.warning(f"Watch i2v: proactive Kie.ai remix #{cid} (invalid_argument)")
                        _remixed_path = _kieai_image_remix(orig_img, cid, vid_img_dir)
                        if _remixed_path:
                            clip_remixed_img[cid] = _remixed_path
                            clip_remixed.add(cid)
                            clip_retries[cid] = 0
                            submitted.discard(cid)
                            logging.info(f"Clip #{cid}: proactive remix OK -> {_remixed_path}, retries reset")
                        else:
                            clip_remixed.add(cid)
                            ext = Path(orig_img).suffix
                            dest = vid_img_dir / f"{cid:03d}{ext}"
                            try:
                                shutil.copy(orig_img, str(dest))
                                clip_static_done.add(cid)
                                print(f"  {_YELLOW}[STATIC]{_RESET} #{cid:03d}: remix failed — static fallback")
                                logging.warning(f"Clip #{cid}: proactive remix failed, static fallback -> {dest.name}")
                            except Exception as _fe:
                                logging.error(f"Clip #{cid}: static fallback copy failed: {_fe}")
                                clip_static_done.add(cid)

                # --- Check for new images ---
                for cid in all_clip_ids:
                    if cid in submitted or cid in clip_static_done or _shutdown_requested.is_set():
                        continue
                    if _has_video(vid_img_dir, cid):
                        submitted.add(cid)
                        continue
                    # Use remixed image if available, otherwise look in generated/
                    _remixed = clip_remixed_img.get(cid)
                    if _remixed and Path(_remixed).exists():
                        img = _remixed
                    else:
                        img = _find_image(generated_dir, cid)
                    if img and _is_stable(img):
                        prompt = prompts_map.get(cid, '')
                        # Worker-assignment: клиент определяется ВНУТРИ воркера по worker_id
                        fut = executor.submit(
                            _process_single_clip,
                            client=None,
                            clip_id=cid,
                            prompt=prompt,
                            mode='i2v',
                            image_path=img,
                            ref_dir=None,
                            output_dir=vid_img_dir,
                            aspect_ratio=aspect,
                            worker_id_fn=_get_worker_id,
                            single_prompt_mode=single_prompt_mode,
                            clients_cfg_list=clients_cfg,
                        )
                        active_futures[fut] = cid
                        submitted.add(cid)
                        sz_kb = Path(img).stat().st_size // 1024
                        print(f"  {_YELLOW}[NEW]{_RESET} #{cid:03d} ({sz_kb}KB) → i2v...")
                        logging.info(f"Clip #{cid}: submitted from {Path(img).name}")

                # --- Status line ---
                done_count = sum(1 for cid in all_clip_ids if _has_video(vid_img_dir, cid))
                in_flight  = len(active_futures)
                waiting    = len([cid for cid in all_clip_ids
                                  if cid not in submitted
                                  and cid not in clip_static_done
                                  and not _has_video(vid_img_dir, cid)])
                static_n   = len(clip_static_done)
                static_sfx = f'  static={static_n}' if static_n else ''
                print(f"  [STATUS] done={done_count}/{len(all_clip_ids)}{static_sfx}  in-flight={in_flight}  waiting-for-image={waiting}")

                # --- Exit conditions ---
                if done_count + len(clip_static_done) >= len(all_clip_ids) and in_flight == 0:
                    print(f"\n  {_GREEN}[WATCH]{_RESET} All {len(all_clip_ids)} clips complete!")
                    break

                if waiting == 0 and in_flight == 0 and len(submitted) + len(clip_static_done) >= len(all_clip_ids):
                    failed_ids = [cid for cid in all_clip_ids
                                  if not _has_video(vid_img_dir, cid) and cid not in clip_static_done]
                    if not failed_ids:
                        print(f"\n  {_GREEN}[WATCH]{_RESET} All submitted and completed!")
                        break

                    # --- Level 2: Kie.ai remix for clips not yet remixed ---
                    # (Level 1 plain retries are handled proactively every cycle above)
                    remix_candidates = [
                        cid for cid in failed_ids
                        if cid not in clip_remixed
                        and bool(_find_image(generated_dir, cid))
                    ]
                    if remix_candidates:
                        print(f"\n  {_YELLOW}[WATCH REMIX]{_RESET} {len(remix_candidates)} clip(s) failed after {MAX_CLIP_RETRIES} retries — applying Kie.ai remix (vision check included)...")
                        logging.warning(f"Watch i2v: Kie.ai remix for: {remix_candidates}")
                        for cid in remix_candidates:
                            orig_img = _find_image(generated_dir, cid)
                            print(f"  {_YELLOW}[WATCH REMIX]{_RESET} #{cid:03d}: remixing via Kie.ai...")
                            _remixed_path = _kieai_image_remix(orig_img, cid, vid_img_dir)
                            if _remixed_path:
                                clip_remixed_img[cid] = _remixed_path
                                clip_remixed.add(cid)
                                clip_retries[cid] = 0
                                submitted.discard(cid)
                                logging.info(f"Clip #{cid}: Kie.ai remix OK -> {_remixed_path}, retries reset")
                            else:
                                # Remix itself failed — static fallback immediately
                                clip_remixed.add(cid)
                                ext = Path(orig_img).suffix
                                dest = vid_img_dir / f"{cid:03d}{ext}"
                                try:
                                    shutil.copy(orig_img, str(dest))
                                    clip_static_done.add(cid)
                                    print(f"  {_YELLOW}[STATIC]{_RESET} #{cid:03d}: remix failed — copied original image to vid_img/")
                                    logging.warning(f"Clip #{cid}: remix failed, static fallback -> {dest.name}")
                                except Exception as _fe:
                                    logging.error(f"Clip #{cid}: static fallback copy failed: {_fe}")
                                    clip_static_done.add(cid)
                        # don't break — loop re-submits remixed ones
                        continue

                    # --- Level 3: static fallback (remix exhausted, still failing) ---
                    still_failed = [cid for cid in failed_ids if cid not in clip_static_done]
                    if still_failed:
                        print(f"\n  {_YELLOW}[WATCH STATIC]{_RESET} {len(still_failed)} clip(s) exhausted all recovery — static image fallback...")
                        logging.warning(f"Watch i2v: static fallback for: {still_failed}")
                        for cid in still_failed:
                            _src = clip_remixed_img.get(cid) or _find_image(generated_dir, cid)
                            if _src and Path(_src).exists():
                                ext = Path(_src).suffix
                                dest = vid_img_dir / f"{cid:03d}{ext}"
                                try:
                                    shutil.copy(_src, str(dest))
                                    clip_static_done.add(cid)
                                    print(f"  {_YELLOW}[STATIC]{_RESET} #{cid:03d}: copied to vid_img/")
                                    logging.warning(f"Clip #{cid}: static fallback -> {dest.name}")
                                except Exception as _fe:
                                    logging.error(f"Clip #{cid}: static fallback copy failed: {_fe}")
                            clip_static_done.add(cid)
                    break

                time.sleep(args.poll)

        except KeyboardInterrupt:
            print("\n  [WATCH] Interrupted.")

    done_count = sum(1 for cid in all_clip_ids if _has_video(vid_img_dir, cid))
    failed_ids = [cid for cid in all_clip_ids
                  if not _has_video(vid_img_dir, cid) and cid not in clip_static_done]
    print(f"\n{'='*60}")
    print(f"  WATCH I2V DONE")
    print(f"  Animated: {done_count}/{len(all_clip_ids)}")
    if clip_static_done:
        print(f"  Static fallback: {sorted(clip_static_done)}")
    if failed_ids:
        print(f"  FAILED clips: {failed_ids}")
    print(f"{'='*60}")
    logging.info(f"Watch i2v finished: {done_count}/{len(all_clip_ids)} done, static={sorted(clip_static_done)}, failed: {failed_ids}")
    signal.signal(signal.SIGINT, _original_sigint)


if __name__ == '__main__':
    main()
