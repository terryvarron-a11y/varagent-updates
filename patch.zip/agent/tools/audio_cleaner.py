#!/usr/bin/env python3
"""
audio_cleaner.py — MMM (Melodic Metadata Massacrer) wrapper.

Wraps: https://github.com/geeknik/mmm
(Successor to the deprecated ai-audio-fingerprint-remover)

Installs via git clone into tools/_mmm_repo/, then pip install -e _mmm_repo/.
Registers the `mmm` CLI entry point in the current Python environment.

CLI:
    python audio_cleaner.py <input_path> [--level moderate] [--inplace]
    python audio_cleaner.py --install

    --level    gentle | moderate | aggressive | extreme  (default: moderate)
               gentle     -> obliterate (basic)
               moderate   -> obliterate --turbo
               aggressive -> obliterate --turbo --paranoid
               extreme    -> obliterate --turbo --paranoid
    --inplace  overwrite input file (backs up original as <stem>_original<ext>)
               without flag: saves as <stem>_clean<ext> alongside input

Logging:
    All output prefixed with [audio_cleaner].
    Prints [OK] ... on success -- parsed by varagent.py pipeline as SUCCESS.
"""

import sys
import os
import argparse
import shutil
import subprocess
from pathlib import Path

# -- Repo config ---------------------------------------------------------------
REPO_URL  = "https://github.com/geeknik/mmm.git"
REPO_DIR  = Path(__file__).parent / "_mmm_repo"
_SENTINEL = REPO_DIR / ".installed"

# Level -> mmm flags mapping
_LEVEL_FLAGS = {
    "gentle":     [],
    "moderate":   ["--turbo"],
    "aggressive": ["--turbo", "--paranoid"],
    "extreme":    ["--turbo", "--paranoid"],
}


# -- Helpers -------------------------------------------------------------------

def _log(msg: str) -> None:
    print(f"[audio_cleaner] {msg}", flush=True)


def _has_git() -> bool:
    return shutil.which("git") is not None


def _mmm_exe() -> str | None:
    """Find the mmm executable installed by pip."""
    exe = shutil.which("mmm")
    if exe:
        return exe
    # Fallback: Scripts dir next to sys.executable (Windows)
    candidates = [
        Path(sys.executable).parent / "Scripts" / "mmm.exe",
        Path(sys.executable).parent / "Scripts" / "mmm",
        Path(sys.executable).parent / "mmm.exe",
        Path(sys.executable).parent / "mmm",
    ]
    for c in candidates:
        if c.exists():
            return str(c)
    return None


def _ensure_tool() -> None:
    """Clone the repo and install mmm if not already done."""
    if _SENTINEL.exists():
        return  # already installed

    if not _has_git():
        _log("ERROR: git not found. Install git and retry.")
        sys.exit(2)

    if not REPO_DIR.exists() or not any(REPO_DIR.iterdir()):
        _log("Cloning mmm repo from GitHub (first time only)...")
        _log(f"  -> {REPO_URL}")
        result = subprocess.run(
            ["git", "clone", "--depth=1", REPO_URL, str(REPO_DIR)],
            capture_output=True, text=True, encoding="utf-8", errors="replace"
        )
        if result.returncode != 0:
            _log(f"ERROR: git clone failed: {result.stderr.strip()}")
            sys.exit(2)
        _log("Cloned OK.")

    _log("Installing mmm package (first time only)...")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "-e", str(REPO_DIR), "--quiet"],
        capture_output=True, text=True, encoding="utf-8", errors="replace"
    )
    if result.returncode != 0:
        _log(f"ERROR: pip install failed: {result.stderr.strip()}")
        sys.exit(2)
    _SENTINEL.touch()
    _log("mmm installed OK.")


# -- Main ----------------------------------------------------------------------

def main() -> None:
    if '--install' in sys.argv:
        _ensure_tool()
        _log("[OK] Audio cleaner installed successfully")
        sys.exit(0)

    parser = argparse.ArgumentParser(
        description="Remove AI fingerprints from audio files (MMM)"
    )
    parser.add_argument("input_path", help="Input audio file (.mp3/.wav)")
    parser.add_argument(
        "--level",
        choices=["gentle", "moderate", "aggressive", "extreme"],
        default="moderate",
        help="Processing intensity (default: moderate)",
    )
    parser.add_argument(
        "--inplace",
        action="store_true",
        help="Overwrite input file (original backed up as <stem>_original<ext>)",
    )
    args = parser.parse_args()

    inp = Path(args.input_path)
    if not inp.exists():
        _log(f"ERROR: File not found: {inp}")
        sys.exit(1)

    _ensure_tool()

    mmm = _mmm_exe()
    if not mmm:
        _log("ERROR: mmm executable not found after install. Try reinstalling.")
        sys.exit(2)

    # Determine output path
    if args.inplace:
        backup = inp.with_name(inp.stem + "_original" + inp.suffix)
        shutil.copy2(str(inp), str(backup))
        _log(f"Backup saved: {backup.name}")
        out = inp.with_name(inp.stem + "_mmm_tmp" + inp.suffix)
    else:
        out = inp.with_name(inp.stem + "_clean" + inp.suffix)

    _log(f"Processing: {inp.name} -> {out.name}  level={args.level}")

    extra_flags = _LEVEL_FLAGS.get(args.level, ["--turbo"])
    cmd = [mmm, "obliterate", str(inp)] + extra_flags + ["-o", str(out)]

    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    for line in proc.stdout:
        line = line.rstrip()
        if line:
            _log(line)
    proc.wait()

    if proc.returncode != 0:
        _log(f"ERROR: mmm exited with code {proc.returncode}")
        if args.inplace and out.exists():
            out.unlink()
        sys.exit(proc.returncode)

    if args.inplace:
        shutil.move(str(out), str(inp))

    final = inp if args.inplace else out
    _log(f"[OK] Audio fingerprint removed: {final.name}")


if __name__ == "__main__":
    main()
