"""
GPT Director через Codex CLI.
Drop-in замена GeminiDirector — тот же интерфейс analyze().
"""
from __future__ import annotations

import json
import logging
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Optional, Dict, Any
from datetime import datetime

import config
from modules.validator import validate_montage_plan_json, check_clip_id_sequence


class GptDirector:
    """Режиссёрский анализ через GPT (Codex CLI)"""

    def __init__(self, model_name: Optional[str] = None):
        self.model_name = model_name or config.GPT_MODEL
        self.codex_exe = Path(config.CODEX_EXE_PATH)
        self.schemas_dir = Path(__file__).parent.parent / 'schemas'
        self.prompts_dir = Path(__file__).parent.parent / 'prompts'
        self.timeout = config.GPT_DIRECTOR_TIMEOUT

        if not config.CODEX_EXE_PATH or not self.codex_exe.is_file():
            raise FileNotFoundError(f"Codex CLI не найден: {self.codex_exe}")

    # =========================================================================
    # ГЛАВНЫЙ МЕТОД — тот же интерфейс что у GeminiDirector
    # =========================================================================

    def analyze(
        self,
        transcription_path: str,
        style_guide_path: str,
        output_dir: str,
        project_name: str = "Untitled",
        two_pass: bool = False,
        prompts_only: bool = False,
        resume_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        output_dir = Path(output_dir)
        transcription_path = Path(transcription_path)
        style_guide_path = Path(style_guide_path)

        # Загрузить транскрипцию
        transcription = json.loads(transcription_path.read_text(encoding='utf-8-sig'))
        audio_duration = transcription.get('audioDuration', 0)
        style_guide = style_guide_path.read_text(encoding='utf-8-sig')

        results = {}

        if prompts_only:
            mp_path = output_dir / 'montage_plan.json'
            if not mp_path.exists():
                raise FileNotFoundError(f"montage_plan.json не найден: {mp_path}")
            montage_plan = json.loads(mp_path.read_text(encoding='utf-8-sig'))
        else:
            # === PASS 1 — montage_plan.json ===
            montage_plan, mp_path = self._run_pass1(
                transcription_path, style_guide_path,
                output_dir, project_name, audio_duration, transcription
            )

        results['montage_plan'] = str(mp_path)
        results['num_clips'] = len(montage_plan.get('clips', []))

        # === PASS 2 — prompts ===
        # GPT через Codex всегда работает в two-pass режиме (два отдельных exec вызова)
        prompts_path, num_prompts = self._run_pass2(
            mp_path, transcription_path, style_guide_path,
            output_dir, project_name, montage_plan,
            resume_path=resume_path
        )
        if num_prompts == 0:
            raise RuntimeError(
                f"GPT Pass 2 вернул 0 промптов — файл пустой или Codex не записал. "
                f"Пайплайн остановлен. Перезапустите с режимом 'Prompts only'."
            )
        results['prompts'] = str(prompts_path) if prompts_path else None
        results['num_prompts'] = num_prompts
        results['cost'] = {
            'total_cost': 0,
            'input_tokens': 0,
            'output_tokens': 0,
            'note': 'GPT via ChatGPT subscription'
        }
        return results

    # =========================================================================
    # CODEX SUBPROCESS WRAPPER
    # =========================================================================

    def _run_codex(
        self,
        task_prompt: str,
        schema_file: str,
        result_file: Path,
        working_dir: Path,
    ) -> dict:
        """
        Запуск codex exec и чтение control JSON.
        Возвращает распарсенный control dict.
        """
        schema_path = self.schemas_dir / schema_file

        if not schema_path.exists():
            raise FileNotFoundError(f"Schema не найдена: {schema_path}")

        # Удалить предыдущий result если есть
        if result_file.exists():
            result_file.unlink()

        # Write task prompt to file to avoid Windows MAX_PATH / cmd length limits
        task_file = working_dir / f'_codex_{schema_file.replace(".json", "")}_task.md'
        task_file.write_text(task_prompt, encoding='utf-8')
        short_prompt = f"Read and follow ALL instructions from this file: {task_file.as_posix()}"

        cmd = [
            str(self.codex_exe), 'exec',
            short_prompt,
            '--output-schema', str(schema_path),
            '--output-last-message', str(result_file),
            '--dangerously-bypass-approvals-and-sandbox',
            '--skip-git-repo-check',
            '-m', self.model_name,
            '-C', str(working_dir),
        ]

        logging.info(f"Codex exec: model={self.model_name} schema={schema_file} cwd={working_dir}")
        t0 = time.time()

        # Run with real-time output streaming
        _stdout_lines = []
        _stderr_lines = []
        _returncode = [None]
        _done = threading.Event()
        _last_activity = [t0]

        def _exec():
            try:
                p = subprocess.Popen(
                    cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    text=True, encoding='utf-8', errors='replace',
                )
                # Read stdout in background thread
                def _read_stderr():
                    for line in p.stderr:
                        _stderr_lines.append(line.rstrip())
                        _last_activity[0] = time.time()
                serr_t = threading.Thread(target=_read_stderr, daemon=True)
                serr_t.start()

                for line in p.stdout:
                    line = line.rstrip()
                    if line:
                        _stdout_lines.append(line)
                        _last_activity[0] = time.time()
                        # Show Codex tool calls / file writes in real-time
                        ll = line.lower()
                        if any(k in ll for k in ('write', 'read', 'wrote', 'append', 'file', 'prompt')):
                            sys.stdout.write(f'\r   📝 {line[:100]:<100}\n')
                            sys.stdout.flush()

                p.wait(timeout=self.timeout)
                serr_t.join(timeout=5)
                _returncode[0] = p.returncode
            except subprocess.TimeoutExpired:
                p.kill()
                _returncode[0] = -1
            except Exception as e:
                _stderr_lines.append(str(e))
                _returncode[0] = -1
            finally:
                _done.set()

        thread = threading.Thread(target=_exec, daemon=True)
        thread.start()

        # Progress monitor — спиннер каждую секунду (GUI перехватывает в нижний лейбл)
        _last_size = 0
        _last_prompts = 0
        _monitor_file = None
        _spinner_chars = '⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
        _spin_i = 0

        while not _done.is_set():
            elapsed = time.time() - t0
            mins = int(elapsed) // 60
            secs = int(elapsed) % 60
            time_str = f"{mins}м {secs:02d}с" if mins > 0 else f"{secs}с"

            # Re-scan for prompts file periodically (Pass 1 не пишет промпты, но на всякий)
            if not _monitor_file:
                _mf = list(working_dir.glob('*_prompts_*.txt'))
                if _mf:
                    _monitor_file = max(_mf, key=lambda f: f.stat().st_mtime)

            if _monitor_file and _monitor_file.exists():
                try:
                    sz = _monitor_file.stat().st_size
                    if sz != _last_size:
                        _last_size = sz
                        txt = _monitor_file.read_text(encoding='utf-8-sig', errors='replace')
                        n = len([p for p in txt.strip().split('\n\n') if p.strip()])
                        if n != _last_prompts:
                            _last_prompts = n
                except Exception:
                    pass

            # Спиннер каждую секунду
            spin = _spinner_chars[_spin_i % len(_spinner_chars)]
            _spin_i += 1
            idle = time.time() - _last_activity[0]
            idle_warn = f" idle {int(idle)}s" if idle > 60 else ""
            extra = f" | {_last_prompts} prompts" if _last_prompts > 0 else ""
            sys.stdout.write(f'\r{spin} GPT Pass1: {time_str}{extra}{idle_warn}   \n')
            sys.stdout.flush()

            _done.wait(1)

            # Hard timeout
            if elapsed > self.timeout:
                print(f"   ⏰ GPT timeout ({self.timeout}s)")
                logging.error(f"Codex timeout after {self.timeout}s")
                raise RuntimeError(f"Codex timeout after {self.timeout}s")

        elapsed = time.time() - t0
        mins = int(elapsed) // 60
        secs = int(elapsed) % 60
        time_str = f"{mins}м {secs:02d}с" if mins > 0 else f"{secs}с"

        if _returncode[0] == -1 and not _stdout_lines:
            sys.stdout.write(f'\r   ⏰ GPT timeout ({self.timeout}s)              \n')
            sys.stdout.flush()
            logging.error(f"Codex timeout after {self.timeout}s")
            raise RuntimeError(f"Codex timeout after {self.timeout}s")

        sys.stdout.write(f'\r   ✅ GPT — готово за {time_str}              \n')
        sys.stdout.flush()

        proc_stdout = '\n'.join(_stdout_lines)
        proc_stderr = '\n'.join(_stderr_lines)

        logging.info(f"Codex finished in {elapsed:.1f}s, exit_code={_returncode[0]}")

        # Извлечь tokens used из stderr/stdout
        for line in (proc_stderr).split('\n') + (proc_stdout).split('\n'):
            if 'tokens used' in line.lower():
                logging.info(f"Codex tokens: {line.strip()}")
                print(f"   📊 {line.strip()}")

        if _returncode[0] != 0:
            logging.error(f"Codex stderr (last 2000): {proc_stderr[-2000:]}")

        if not result_file.exists():
            raise RuntimeError(
                f"Codex не создал {result_file.name} "
                f"(exit {_returncode[0]}): {proc_stderr[:500]}"
            )

        raw = result_file.read_text(encoding='utf-8-sig').strip()
        try:
            control = json.loads(raw)
        except json.JSONDecodeError as e:
            logging.error(f"Invalid JSON in {result_file}: {raw[:500]}")
            raise RuntimeError(f"Codex вернул невалидный JSON: {e}")

        logging.info(f"Codex control: {json.dumps(control, ensure_ascii=False)}")
        print(f"   ⏱  Codex: {elapsed:.0f}s, model={self.model_name}")
        return control

    # =========================================================================
    # PASS 2 — FILE MONITORING + TRIVIAL CONTROL SCHEMA
    # =========================================================================

    def _run_codex_pass2(
        self,
        task_prompt: str,
        prompts_path: Path,
        n_clips: int,
        working_dir: Path,
        prompts_offset: int = 0,
        session_id: str = None,
        total_clips: int = 0,
        global_start: float = None,
        codex_home: Path = None,
        silent: bool = False,
        keep_ids: bool = False,
        rate_limit_reported: threading.Event = None,
        rate_limit_info: list = None,
    ) -> tuple:
        """
        Запуск codex для Pass 2 — JSON stdout mode.
        GPT возвращает {"prompts":["p1","p2",...]} в stdout (через --output-last-message).
        Мы парсим JSON и сами записываем в prompts_path (append).
        0 tool calls = 0 context growth = быстро.

        При resume: codex exec resume SESSION_ID — контекст в сессии.
        Fallback: если resume не работает — полный exec с текущего cursor.

        Returns: (total_prompts_in_file, session_id)
        """
        result_file = working_dir / f'_codex_pass2_control_{prompts_path.stem}.json'
        if result_file.exists():
            result_file.unlink()

        # Save task prompt to file for debugging, but deliver via stdin (no file read tool calls)
        task_file = working_dir / f'_codex_pass2_task_{prompts_path.stem}.md'
        task_file.write_text(task_prompt, encoding='utf-8')

        if session_id:
            cmd = [
                str(self.codex_exe), 'exec', 'resume',
                session_id,
                '-',  # read prompt from stdin
                '--output-last-message', str(result_file),
                '--dangerously-bypass-approvals-and-sandbox',
                '--skip-git-repo-check',
                '-m', self.model_name,
            ]
            logging.info(f"Codex Pass2 RESUME: session={session_id[:16]}..., expect={n_clips} prompts")
        else:
            cmd = [
                str(self.codex_exe), 'exec',
                '-',  # read prompt from stdin
                '--output-last-message', str(result_file),
                '--dangerously-bypass-approvals-and-sandbox',
                '--skip-git-repo-check',
                '-m', self.model_name,
                '-C', str(working_dir),
            ]
            logging.info(f"Codex Pass2: model={self.model_name}, expect={n_clips} prompts, cwd={working_dir}")

        t0 = time.time()
        _stdout_lines = []
        _stderr_lines = []
        _last_activity = [t0]  # updated on any stdout/stderr line

        _env = None
        if codex_home is not None:
            _env = os.environ.copy()
            _env['CODEX_HOME'] = str(codex_home)
        p = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            stdin=subprocess.PIPE,
            text=True, encoding='utf-8', errors='replace',
            env=_env,
        )
        # Deliver prompt via stdin — no file read tool calls
        p.stdin.write(task_prompt)
        p.stdin.close()
        def _drain(src, dst):
            for line in src:
                dst.append(line.rstrip())
                _last_activity[0] = time.time()
        threading.Thread(target=_drain, args=(p.stdout, _stdout_lines), daemon=True).start()
        threading.Thread(target=_drain, args=(p.stderr, _stderr_lines), daemon=True).start()

        # --- Session JSONL monitoring ---
        _session_file = None
        _last_session_size = 0
        _last_session_activity = t0  # updated when session file grows
        _last_token_log_time = 0.0
        _last_logged_input_tokens = 0
        _TOKEN_LOG_INTERVAL = 30
        _spinner_chars = '⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
        _spin_i = 0
        _detected_prompts = 0

        # For resume chunks: record session file size BEFORE this chunk starts,
        # so _read_session_info skips old events from previous chunks.
        _session_start_size = 0
        if session_id:
            try:
                today = datetime.now()
                _sd = Path.home() / '.codex' / 'sessions' / str(today.year) / f'{today.month:02d}' / f'{today.day:02d}'
                _sf_candidates = list(_sd.glob(f'*{session_id[:16]}*.jsonl')) if _sd.exists() else []
                if _sf_candidates:
                    _session_start_size = _sf_candidates[0].stat().st_size
                    logging.info(f"Pass2 resume: session JSONL start_offset={_session_start_size} bytes")
            except Exception:
                pass

        def _find_session_file():
            try:
                today = datetime.now()
                sd = Path.home() / '.codex' / 'sessions' / str(today.year) / f'{today.month:02d}' / f'{today.day:02d}'
                if not sd.exists():
                    return None
                cc = [f for f in sd.glob('rollout-*.jsonl') if f.stat().st_mtime >= t0 - 5]
                return max(cc, key=lambda f: f.stat().st_mtime) if cc else None
            except Exception:
                return None

        def _read_session_info(sf: Path):
            """Read token count and prompt count from session JSONL.
            For resume chunks, reads only bytes after _session_start_size to skip
            agent_message events from previous chunks (avoids double-counting in display)."""
            inp, out, n_prompts = 0, 0, 0
            try:
                if _session_start_size > 0:
                    with open(sf, 'rb') as _f:
                        _f.seek(_session_start_size)
                        _content = _f.read().decode('utf-8', errors='replace')
                else:
                    _content = sf.read_text(encoding='utf-8-sig', errors='replace')
                for line in reversed(_content.strip().split('\n')):
                    try:
                        ev = json.loads(line)
                        if ev.get('type') == 'event_msg':
                            pl = ev.get('payload', {})
                            if pl.get('type') == 'token_count' and inp == 0:
                                u = pl.get('info', {}).get('total_token_usage', {})
                                inp, out = u.get('input_tokens', 0), u.get('output_tokens', 0)
                            elif pl.get('type') == 'agent_message' and n_prompts == 0:
                                msg = pl.get('message', '')
                                if '"prompts"' in msg:
                                    try:
                                        d = json.loads(msg)
                                        n_prompts = len(d.get('prompts', []))
                                    except Exception:
                                        pass
                        if inp > 0 and n_prompts > 0:
                            break
                    except Exception:
                        pass
            except Exception:
                pass
            return inp, out, n_prompts

        # --- Main wait loop ---
        while True:
            elapsed = time.time() - t0
            mins, secs = int(elapsed) // 60, int(elapsed) % 60
            time_str = f"{mins}м {secs:02d}с" if mins else f"{secs}с"

            # Session monitoring
            now = time.time()
            if _session_file is None and now - t0 > 3:
                _session_file = _find_session_file()
            if _session_file and _session_file.exists():
                try:
                    sz = _session_file.stat().st_size
                    if sz != _last_session_size:
                        _last_session_size = sz
                        _last_session_activity = now
                except Exception:
                    pass
            if _session_file and now - _last_token_log_time >= _TOKEN_LOG_INTERVAL:
                inp, out, np = _read_session_info(_session_file)
                if np > 0:
                    _detected_prompts = np
                if inp > 0 and inp != _last_logged_input_tokens:
                    _last_logged_input_tokens = inp
                    print(f"   🔢 GPT токены: {inp:,} input / {out:,} output")
                _last_token_log_time = now

            # Spinner
            if not silent:
                spin = _spinner_chars[_spin_i % len(_spinner_chars)]
                _spin_i += 1
                _display_total = total_clips if total_clips > 0 else n_clips
                _display_done = prompts_offset + _detected_prompts
                extra = f" | {_display_done}/{_display_total} промптов" if _detected_prompts > 0 else ""
                if global_start is not None and global_start != t0:
                    g_el = time.time() - global_start
                    g_mins, g_secs = int(g_el) // 60, int(g_el) % 60
                    g_str = f"{g_mins}м {g_secs:02d}с" if g_mins > 0 else f"{g_secs}с"
                    timer_str = f"чанк {time_str} | итого {g_str}"
                else:
                    timer_str = time_str
                sys.stdout.write(f'\r{spin} GPT Pass2: {timer_str}{extra}   \n')
                sys.stdout.flush()

            if p.poll() is not None:
                break
            if elapsed > self.timeout:
                p.kill()
                logging.warning(f"Pass2 timeout ({self.timeout}s)")
                print(f"   ⏰ Таймаут {self.timeout}s")
                break
            time.sleep(1)

        elapsed = time.time() - t0
        mins, secs = int(elapsed) // 60, int(elapsed) % 60
        if not silent:
            print(f"   ⏱  Codex Pass2: {mins}м {secs:02d}с")

        # --- Parse JSON from result file ---
        prompts_list = []
        if result_file.exists():
            raw = result_file.read_text(encoding='utf-8', errors='replace').strip()
            # Try parse as JSON with "prompts" key
            try:
                data = json.loads(raw)
                prompts_list = data.get('prompts', [])
            except json.JSONDecodeError:
                # Maybe raw text with prompts separated by \n\n
                logging.warning(f"Pass2: result is not JSON, trying text parse")
                prompts_list = [p.strip() for p in raw.split('\n\n') if p.strip()]

        if not prompts_list:
            # Parse stderr for known error patterns and surface them to user
            _is_limit_error = False
            _limit_reset_time = None
            _first_limit_line = None
            for _line in _stderr_lines:
                _ll = _line.strip()
                if not _ll:
                    continue
                if 'usage limit' in _ll.lower() or 'rate limit' in _ll.lower():
                    if not _is_limit_error:  # dedup: print only once
                        _is_limit_error = True
                        _first_limit_line = _ll
                        _try_again = re.search(r'try again at (.+?)\.?\s*$', _ll, re.IGNORECASE)
                        if _try_again:
                            _limit_reset_time = _try_again.group(1).strip()
                elif _ll.startswith('ERROR:') or _ll.startswith('error:'):
                    print(f"   ❌ Codex: {_ll}")
            if _is_limit_error:
                # Dedup: first chunk to detect sets the event and stores reset_time
                _already_reported = rate_limit_reported is not None and rate_limit_reported.is_set()
                if not _already_reported:
                    if rate_limit_reported is not None:
                        rate_limit_reported.set()
                    # Store reset_time for deferred printing AFTER all chunks finish
                    if rate_limit_info is not None and not rate_limit_info:
                        rate_limit_info.append(_limit_reset_time)
                return prompts_offset, session_id, None  # None = fatal, не делать ретраи
            else:
                logging.warning(f"Pass2: no prompts in result. rc={p.returncode}")
                print(f"   ⚠️  GPT не вернул промпты (rc={p.returncode})")
            # Fallback: check if session has agent_message with prompts
            if _session_file:
                _, _, np = _read_session_info(_session_file)
                if np > 0:
                    # Extract from session
                    try:
                        for line in reversed(_session_file.read_text(encoding='utf-8', errors='replace').strip().split('\n')):
                            ev = json.loads(line)
                            if ev.get('type') == 'event_msg' and ev.get('payload', {}).get('type') == 'agent_message':
                                msg = ev['payload']['message']
                                d = json.loads(msg)
                                prompts_list = d.get('prompts', [])
                                if prompts_list:
                                    logging.info(f"Pass2: recovered {len(prompts_list)} prompts from session JSONL")
                                    print(f"   ↩️  Восстановлено {len(prompts_list)} промптов из сессии")
                                    break
                    except Exception:
                        pass

        if not prompts_list:
            return prompts_offset, session_id, set()  # retry

        # Transcript pollution check
        _vo_count = sum(1 for p in prompts_list if p.strip().startswith('VOICEOVER:') or p.strip().startswith('[CLIP '))
        if _vo_count > len(prompts_list) * 0.3:
            logging.error(f"Pass2: {_vo_count}/{len(prompts_list)} VOICEOVER blocks — pollution")
            print(f"   ❌ Транскрипция вместо промптов ({_vo_count} VOICEOVER блоков)")
            return prompts_offset, session_id, set()

        # Strip [CLIP N] or [N] prefixes that GPT wrote, track which clip IDs were returned
        _id_re = re.compile(r'^\[(?:CLIP\s+)?(\d+)\]\s*')
        _found_ids: set = set()
        _id_pairs: list = []  # [(clip_id_or_None, stripped_prompt), ...]
        for _p in prompts_list:
            _m = _id_re.match(_p.strip())
            if _m:
                _cid = int(_m.group(1))
                _found_ids.add(_cid)
                _id_pairs.append((_cid, _id_re.sub('', _p.strip(), count=1).strip()))
            else:
                _id_pairs.append((None, _p.strip()))
        prompts_list = [_p for _, _p in _id_pairs]

        # Trim to expected count (GPT sometimes returns more than requested)
        if len(prompts_list) > n_clips:
            logging.info(f"Pass2: trimming {len(prompts_list)} → {n_clips} prompts")
            prompts_list = prompts_list[:n_clips]
            _id_pairs = _id_pairs[:n_clips]

        # Append to prompts file
        existing = ''
        if prompts_path.exists() and prompts_path.stat().st_size > 0:
            existing = prompts_path.read_text(encoding='utf-8', errors='replace').rstrip()
        if keep_ids:
            # Write [N] prefixed prompts so parallel merge can sort by clip ID
            new_block = '\n\n'.join(
                f'[{_cid}] {_p}' if _cid is not None else _p
                for _cid, _p in _id_pairs if _p.strip()
            )
        else:
            new_block = '\n\n'.join(p.strip() for p in prompts_list if p.strip())
        if existing:
            combined = existing + '\n\n' + new_block
        else:
            combined = new_block
        prompts_path.write_text(combined, encoding='utf-8')

        total_count = prompts_offset + len(prompts_list)

        # Extract session ID
        _found_session_id = session_id
        if not _found_session_id:
            logging.info(f"Session ID not in result file, searching ~/.codex/sessions/")
            _found_session_id = self._find_latest_session_id(t0)
            if not _found_session_id:
                logging.info(f"Could not find session ID from Codex session file")
            else:
                logging.info(f"Found session ID from JSONL: {_found_session_id[:30]}")

        written = len(prompts_list)
        _chars = len(combined)
        _est_tokens = _chars // 3
        _ids_info = f", IDs={sorted(_found_ids)[:5]}{'...' if len(_found_ids) > 5 else ''}" if _found_ids else ""
        print(f"   → Записано: {written}, всего: {total_count}/{prompts_offset + n_clips}{_ids_info}")
        print(f"   📊 Output: {_chars:,} chars ≈ {_est_tokens:,} tokens ({prompts_path.stat().st_size:,} bytes)")
        print(f"   🔑 Output session_id: {_found_session_id[:20] if _found_session_id else 'NONE'}")

        logging.info(f"Codex Pass2 done: {written} new, {total_count} total, ids={len(_found_ids)}, elapsed={elapsed:.1f}s, session={_found_session_id[:30] if _found_session_id else 'none'}")
        return total_count, _found_session_id, _found_ids

    def _find_latest_session_id(self, after_ts: float) -> Optional[str]:
        """Find Codex session ID from JSONL file created after after_ts."""
        try:
            today = datetime.now()
            session_dir = Path.home() / '.codex' / 'sessions' / str(today.year) / f'{today.month:02d}' / f'{today.day:02d}'
            logging.info(f"[DEBUG] Session dir: {session_dir}")
            logging.info(f"[DEBUG] Dir exists: {session_dir.exists()}")

            if not session_dir.exists():
                logging.info(f"[DEBUG] Session dir does not exist!")
                return None

            all_files = list(session_dir.glob('rollout-*.jsonl'))
            logging.info(f"[DEBUG] Found {len(all_files)} rollout files in dir")

            candidates = [
                f for f in all_files
                if f.stat().st_mtime >= after_ts - 5
            ]
            logging.info(f"[DEBUG] Candidates with mtime>={after_ts-5}: {len(candidates)}")
            for c in candidates:
                logging.info(f"[DEBUG]   - {c.name}: mtime={c.stat().st_mtime}")

            if not candidates:
                logging.info(f"[DEBUG] No candidates found in time range")
                return None

            latest = max(candidates, key=lambda f: f.stat().st_mtime)
            logging.info(f"[DEBUG] Latest file: {latest.name}")

            # Read first line to get session ID
            content = latest.read_text(encoding='utf-8', errors='replace')
            first_line = content.split('\n')[0]
            logging.info(f"[DEBUG] First line length: {len(first_line)}")

            meta = json.loads(first_line)
            sid = meta.get('payload', {}).get('id')
            logging.info(f"[DEBUG] Parsed session ID: {sid}")

            if sid:
                logging.info(f"Found Codex session: {sid}")
            return sid
        except Exception as e:
            logging.warning(f"Could not find Codex session ID: {e}")
            import traceback
            logging.warning(f"[DEBUG] Exception traceback: {traceback.format_exc()}")
            return None

    # =========================================================================
    # PASS 1 — MONTAGE PLAN
    # =========================================================================

    def _run_pass1(
        self,
        transcription_path: Path,
        style_guide_path: Path,
        output_dir: Path,
        project_name: str,
        audio_duration: float,
        transcription: dict,
    ) -> tuple:
        """
        Pass 1: транскрипция + стайлгайд → montage_plan.json.
        Один exec вызов.
        """
        mp_path = output_dir / 'montage_plan.json'
        result_file = output_dir / '_codex_pass1_control.json'

        # Загрузить системную инструкцию
        sys_instr_path = self.prompts_dir / 'director_instruction_pass1.txt'
        pause_guide_path = self.prompts_dir / 'director_pause_guide.txt'

        task_prompt = self._build_pass1_prompt(
            transcription_path, style_guide_path, sys_instr_path,
            pause_guide_path, mp_path, project_name, audio_duration
        )

        print(f"\n🎬 GPT Pass 1: создание монтажного плана...")
        print(f"   Модель: {self.model_name}")
        print(f"   Аудио: {audio_duration:.0f}с ({audio_duration/60:.1f} мин)")

        control = self._run_codex(task_prompt, 'pass1_control.json', result_file, output_dir)

        if control.get('status') != 'ok':
            raise RuntimeError(f"GPT Pass 1 failed: {control.get('error_message', 'unknown')}")

        # Прочитать и провалидировать montage_plan.json
        actual_mp_path = Path(control.get('montage_plan_path', str(mp_path)))
        if not actual_mp_path.exists():
            actual_mp_path = mp_path

        if not actual_mp_path.exists():
            raise RuntimeError(f"montage_plan.json не создан: {actual_mp_path}")

        montage_plan = json.loads(actual_mp_path.read_text(encoding='utf-8-sig'))

        # Нормализация обёртки
        if 'montage_plan' in montage_plan and 'clips' in montage_plan['montage_plan']:
            montage_plan = montage_plan['montage_plan']

        # Валидация через существующий валидатор
        is_valid, errors = validate_montage_plan_json(montage_plan, audio_duration)
        if not is_valid:
            logging.warning(f"GPT montage plan validation: {errors}")
            print(f"   ⚠️  Валидация: {len(errors)} замечаний (авто-коррекция)")
        else:
            print(f"   ✅ Валидация монтажного плана — OK")

        # Проверка ID последовательности
        id_problems = check_clip_id_sequence(montage_plan.get('clips', []))
        if id_problems:
            logging.warning(f"GPT montage plan ID issues: {id_problems}")
            print(f"   ⚠️  ID последовательность: {len(id_problems)} проблем (авто-коррекция)")
            # Авто-коррекция: перенумерация 1..N
            for i, clip in enumerate(montage_plan.get('clips', [])):
                clip['id'] = i + 1
                clip['file'] = f"{i + 1}.mp4"

        # Перезаписать нормализованный план
        mp_path.write_text(
            json.dumps(montage_plan, indent=2, ensure_ascii=False),
            encoding='utf-8'
        )

        clips = montage_plan.get('clips', [])
        _mp_chars = len(mp_path.read_text(encoding='utf-8'))
        print(f"   ✅ Монтажный план: {len(clips)} клипов, {audio_duration:.0f}с")
        print(f"   📊 Plan output: {_mp_chars:,} chars ≈ {_mp_chars // 3:,} tokens")
        return montage_plan, mp_path

    def _build_pass1_prompt(
        self,
        transcription_path: Path,
        style_guide_path: Path,
        sys_instr_path: Path,
        pause_guide_path: Path,
        mp_path: Path,
        project_name: str,
        audio_duration: float,
    ) -> str:
        """Сборка промпта для Pass 1."""
        t_path = transcription_path.as_posix()
        sg_path = style_guide_path.as_posix()
        si_path = sys_instr_path.as_posix()
        pg_path = pause_guide_path.as_posix()
        out_path = mp_path.as_posix()

        clip_min = config.ACTIVE_CLIP_MIN_DURATION
        clip_max = config.ACTIVE_CLIP_MAX_DURATION
        intro_min = config.get_intro_clip_min()
        intro_max = config.get_intro_clip_max()
        intro_block = config.INTRO_BLOCK_DURATION

        return f"""You are a film director creating a montage plan for a documentary.

## SYSTEM INSTRUCTION
Read the director instruction file: {si_path}
Also read the pause guide: {pg_path}

When reading the instruction, apply these substitutions:
- {{clip_min_dur}} = {clip_min}
- {{clip_max_dur}} = {clip_max}
- {{clip_intro_min_dur}} = {intro_min}
- {{clip_intro_max_dur}} = {intro_max}
- {{intro_block_dur}} = {intro_block}

## STYLE GUIDE
Read the style guide file: {sg_path}

## TRANSCRIPTION
Read the transcription file: {t_path}

## PROJECT
Name: {project_name}
Audio duration: {audio_duration:.2f} seconds

## TASK
1. Read ALL files listed above
2. Generate a montage plan following the director instruction rules
3. Write the result as JSON to: {out_path}

The JSON must have this structure:
{{
  "montage_plan": {{
    "audioDuration": {audio_duration:.2f},
    "clips": [
      {{"id": 1, "file": "1.mp4", "startTime": 0.0, "endTime": 7.8}},
      {{"id": 2, "file": "2.mp4", "startTime": 7.8, "endTime": 14.2}},
      ...
    ]
  }}
}}

Rules:
- Each clip duration: {clip_min}–{clip_max} seconds
- Clips must be continuous (no gaps): clip N endTime = clip N+1 startTime
- First clip startTime = 0.0
- Last clip endTime must equal audioDuration ({audio_duration:.2f})
- IDs sequential: 1, 2, 3, ...
- File format: "{{id}}.mp4"

Write the JSON file and then report your status in your final response."""

    # =========================================================================
    # PASS 2 — PROMPTS
    # =========================================================================

    def _run_pass2(
        self,
        mp_path: Path,
        transcription_path: Path,
        style_guide_path: Path,
        output_dir: Path,
        project_name: str,
        montage_plan: dict,
        resume_path: Optional[str] = None,
    ) -> tuple:
        """
        Pass 2: montage_plan + стайлгайд → промпты per clip.
        Возвращает (prompts_path, num_prompts).
        """
        clips = montage_plan.get('clips', [])
        total_clips = len(clips)
        if total_clips == 0:
            print("   ❌ Монтажный план пуст — нечего промптировать")
            return None, 0

        chunk_size = config.GPT_PASS2_CHUNK_SIZE or total_clips

        timestamp = datetime.now().strftime('%Y%m%d_%H%M')
        prompts_path = output_dir / f'{project_name}_prompts_{timestamp}.txt'
        total_prompts = 0
        cursor = 0
        chunk_idx = 0
        _chunk_retries = 0
        _MAX_CHUNK_RETRIES = 3

        # Load transcription fragments for clip cards
        transcription = json.loads(transcription_path.read_text(encoding='utf-8-sig'))
        fragments = transcription.get('transcription', [])

        # Resume: подсчитать существующие промпты
        if resume_path:
            rp = Path(resume_path)
            if rp.exists():
                prompts_path = rp
                existing = rp.read_text(encoding='utf-8').strip().split('\n\n')
                total_prompts = len([p for p in existing if p.strip()])
                cursor = total_prompts
                print(f"   ↩️  Resume: {total_prompts} промптов уже есть, продолжаем с клипа {cursor + 1}")

        _pass2_session_id = None  # Codex session ID for resume between chunks
        _pass2_total_start = time.time()

        # --- Параллельный режим Pass 2 (GPT_PASS2_PARALLEL > 1) ---
        _parallel = getattr(config, 'GPT_PASS2_PARALLEL', 1)
        if _parallel > 1 and total_clips > chunk_size:
            # Предварительная сборка всех чанков
            _initial_prev_sample = ""
            if prompts_path.exists() and total_prompts > 0:
                _ex = prompts_path.read_text(encoding='utf-8').strip().split('\n\n')
                _initial_prev_sample = '\n\n'.join([p for p in _ex if p.strip()][-5:])

            _chunks_to_run = []
            _cur = cursor
            while _cur < total_clips:
                _ce = min(_cur + chunk_size, total_clips)
                _cclips = clips[_cur:_ce]
                _fid = _cclips[0]['id']
                _tid = _cclips[-1]['id']
                _nc = len(_cclips)
                _cards = []
                for _c in _cclips:
                    _cs, _cend = _c.get('startTime', 0), _c.get('endTime', 0)
                    _txts = [f['text'] for f in fragments if f.get('start', 0) < _cend and f.get('end', 0) > _cs]
                    _cards.append(f"[CLIP {_c['id']}] {_cs:.1f}–{_cend:.1f}s\nVOICEOVER: {' '.join(_txts).strip() or '(pause)'}")
                _pp = ""
                if _cur > 0:
                    _pp_lines = []
                    for _pc in clips[max(0, _cur - 5):_cur]:
                        _cs, _cend = _pc.get('startTime', 0), _pc.get('endTime', 0)
                        _txts = [f['text'] for f in fragments if f.get('start', 0) < _cend and f.get('end', 0) > _cs]
                        _pp_lines.append(f"Clip {_pc['id']} ({_cs:.1f}-{_cend:.1f}s): {' '.join(_txts).strip()}")
                    _pp = '\n'.join(_pp_lines)
                _tp = self._build_pass2_prompt(
                    style_guide_path, prompts_path,
                    '\n\n'.join(_cards), _fid, _tid, _nc, total_clips,
                    _initial_prev_sample, _pp, total_prompts > 0 or _cur > 0
                )
                _chunks_to_run.append({
                    'idx': len(_chunks_to_run), 'from_id': _fid, 'to_id': _tid,
                    'n_clips': _nc, 'task_prompt': _tp, 'clips': _cclips,
                    'clip_start': _cur,
                })
                _cur = _ce

            _nch = len(_chunks_to_run)
            print(f"\n🚀 Pass 2 параллельный режим ({_nch} потоков): {_nch} чанков")

            _MAX_PAR_RETRIES = 3
            _rate_limit_evt = threading.Event()   # shared across all parallel chunks
            _rate_limit_info = []                  # [reset_time_str|None] — filled by first chunk

            def _run_one_parallel(cd):
                import shutil as _shutil
                _i = cd['idx']
                _ich = len(cd['task_prompt'])
                print(f"\n✍️  GPT Pass 2: генерация промптов (клипы {cd['from_id']}–{cd['to_id']})...")
                print(f"   📊 Input: {_ich:,} chars ≈ {_ich // 3:,} tokens")
                print(f"   🔑 Input session_id: NONE (fresh exec, parallel {_i + 1}/{_nch})")
                _tmp = output_dir / f'_tmp_p2_{_i}_{prompts_path.stem}.txt'

                def _run_chunk(task_p, n_clips, offset):
                    _ch = Path(tempfile.mkdtemp(prefix=f'codex_p2_{_i}_'))
                    _codex_src = Path.home() / '.codex'
                    for _cf in ['auth.json', 'config.toml']:
                        _src = _codex_src / _cf
                        if _src.exists():
                            _shutil.copy2(str(_src), str(_ch / _cf))
                    try:
                        return self._run_codex_pass2(
                            task_p, _tmp, n_clips, output_dir,
                            prompts_offset=offset, session_id=None,
                            total_clips=total_clips, global_start=_pass2_total_start,
                            codex_home=_ch, silent=True, keep_ids=True,
                            rate_limit_reported=_rate_limit_evt,
                            rate_limit_info=_rate_limit_info,
                        )
                    finally:
                        _shutil.rmtree(str(_ch), ignore_errors=True)

                # Initial run — track which clip IDs were returned
                _ft, _, _found_ids = _run_chunk(cd['task_prompt'], cd['n_clips'], 0)
                _expected_ids = {c['id'] for c in cd['clips']}
                _retries = 0

                # None = fatal error (rate limit etc) — не ретраим
                if _found_ids is None:
                    return _i, 0, _tmp

                # Retry loop: 0 prompts → retry whole chunk; partial → retry EXACT missing clips
                while _found_ids < _expected_ids and _retries < _MAX_PAR_RETRIES:
                    _retries += 1
                    _missing_ids = _expected_ids - _found_ids
                    _missing = len(_missing_ids)

                    if not _found_ids:
                        # Complete failure — retry whole chunk
                        print(f"   🔄 Чанк {_i+1}: 0 промптов — ретрай {_retries}/{_MAX_PAR_RETRIES}...")
                        time.sleep(5)
                        _ft, _, _new_ids = _run_chunk(cd['task_prompt'], cd['n_clips'], 0)
                        if _new_ids is None:
                            break  # rate limit — стоп
                        _found_ids |= _new_ids
                    else:
                        # Partial: build prompt for EXACT missing clips (by ID, not positional)
                        _rem_clips = [c for c in cd['clips'] if c['id'] in _missing_ids]
                        _rem_start = cd['clip_start'] + len(_found_ids)
                        print(f"   🔄 Чанк {_i+1}: {len(_found_ids)}/{cd['n_clips']} — досылаем {_missing} клипов (IDs: {sorted(_missing_ids)[:5]}{'...' if _missing > 5 else ''}) ретрай {_retries}/{_MAX_PAR_RETRIES}...")
                        _cards = []
                        for _c in _rem_clips:
                            _cs, _cend = _c.get('startTime', 0), _c.get('endTime', 0)
                            _txts = [f['text'] for f in fragments if f.get('start', 0) < _cend and f.get('end', 0) > _cs]
                            _cards.append(f"[CLIP {_c['id']}] {_cs:.1f}–{_cend:.1f}s\nVOICEOVER: {' '.join(_txts).strip() or '(pause)'}")
                        _pp_lines = []
                        for _pc in clips[max(0, _rem_start - 5):_rem_start]:
                            _cs2, _cend2 = _pc.get('startTime', 0), _pc.get('endTime', 0)
                            _txts2 = [f['text'] for f in fragments if f.get('start', 0) < _cend2 and f.get('end', 0) > _cs2]
                            _pp_lines.append(f"Clip {_pc['id']} ({_cs2:.1f}-{_cend2:.1f}s): {' '.join(_txts2).strip()}")
                        _rem_tp = self._build_pass2_prompt(
                            style_guide_path, prompts_path,
                            '\n\n'.join(_cards), _rem_clips[0]['id'], _rem_clips[-1]['id'],
                            _missing, total_clips,
                            '', '\n'.join(_pp_lines), True,
                        )
                        _new_ft, _, _new_ids = _run_chunk(_rem_tp, _missing, len(_found_ids))
                        if _new_ids is None:
                            break  # rate limit — стоп
                        _found_ids |= _new_ids
                        if not _new_ids:
                            time.sleep(5)

                _ft = len(_found_ids)
                if _ft < cd['n_clips']:
                    print(f"   ⚠️  Чанк {_i+1}: {_ft}/{cd['n_clips']} после {_MAX_PAR_RETRIES} ретраев (пропущены IDs: {sorted(_expected_ids - _found_ids)})")

                # Reorder _tmp by clip order (retries may have appended out-of-order)
                # Parse [N] prefixed prompts, sort by cd['clips'] order, strip IDs
                if _tmp.exists() and _ft > 0:
                    _id_re2 = re.compile(r'^\[(\d+)\]\s*')
                    _id_map2 = {}
                    for _blk in _tmp.read_text(encoding='utf-8').split('\n\n'):
                        _blk = _blk.strip()
                        if not _blk:
                            continue
                        _m2 = _id_re2.match(_blk)
                        if _m2:
                            _id_map2[int(_m2.group(1))] = _id_re2.sub('', _blk, count=1).strip()
                        else:
                            pass  # no ID — skip (shouldn't happen in keep_ids mode)
                    _ordered = [_id_map2[c['id']] for c in cd['clips'] if c['id'] in _id_map2]
                    _tmp.write_text('\n\n'.join(_ordered), encoding='utf-8')
                    _ft = len(_ordered)

                return _i, _ft, _tmp

            _par_done = [0]
            _par_stop = [False]
            _spin_chars = '⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'

            def _bottom_spin():
                _si = 0
                while not _par_stop[0]:
                    el = time.time() - _pass2_total_start
                    mins_, secs_ = int(el) // 60, int(el) % 60
                    t_str = f"{mins_}м {secs_:02d}с" if mins_ > 0 else f"{secs_}с"
                    spin_ = _spin_chars[_si % len(_spin_chars)]
                    _si += 1
                    sys.stdout.write(f'\r{spin_} GPT Pass2 [{_par_done[0]}/{_nch} чанков]: итого {t_str}   \n')
                    sys.stdout.flush()
                    time.sleep(1)

            _spin_t = threading.Thread(target=_bottom_spin, daemon=True)
            _spin_t.start()

            _par_results = []
            with ThreadPoolExecutor(max_workers=_nch) as _pool:
                _futs = {_pool.submit(_run_one_parallel, cd): cd['idx'] for cd in _chunks_to_run}
                for _fut in as_completed(_futs):
                    _ri, _rft, _rtp = _fut.result()
                    _par_results.append((_ri, _rft, _rtp))
                    _par_done[0] += 1
                    print(f"   ✅ Чанк {_ri + 1}/{_nch} завершён: {_rft} промптов")

            _par_stop[0] = True
            _spin_t.join(timeout=2)

            # Print rate limit message AFTER all chunk completions (deferred from threads)
            if _rate_limit_evt.is_set():
                _reset_t = _rate_limit_info[0] if _rate_limit_info else None
                if _reset_t:
                    print(f"   ⏳ Лимит GPT вашего тарифа исчерпан — лимит обновится в {_reset_t}. Дождитесь и запустите заново")
                else:
                    print(f"   ⏳ Лимит GPT вашего тарифа исчерпан. Дождитесь обновления и запустите заново")
                logging.warning(f"Pass2: rate/usage limit hit, reset_time={_reset_t}")

            _par_results.sort(key=lambda x: x[0])
            _all_prompts = []
            for _ri, _rft, _rtp in _par_results:
                if Path(_rtp).exists():
                    _rc = Path(_rtp).read_text(encoding='utf-8').strip()
                    _all_prompts.extend([p.strip() for p in _rc.split('\n\n') if p.strip()])
                    try:
                        Path(_rtp).unlink()
                    except Exception:
                        pass
            prompts_path.write_text('\n\n'.join(_all_prompts), encoding='utf-8')
            total_prompts = len(_all_prompts)
            cursor = total_clips  # пропускаем sequential while loop ниже

        # --- Sequential fallback (GPT_PASS2_PARALLEL=1 или один чанк) ---
        while cursor < total_clips:
            chunk_end = min(cursor + chunk_size, total_clips)
            chunk_clips = clips[cursor:chunk_end]
            from_id = chunk_clips[0]['id']
            to_id = chunk_clips[-1]['id']
            n_clips = len(chunk_clips)

            # Build clip cards with voiceover text (like Gemini)
            clip_cards = []
            for clip in chunk_clips:
                cs = clip.get('startTime', 0)
                ce = clip.get('endTime', 0)
                texts = [f['text'] for f in fragments
                         if f.get('start', 0) < ce and f.get('end', 0) > cs]
                text = ' '.join(texts).strip() or '(pause)'
                clip_cards.append(
                    f"[CLIP {clip['id']}] {cs:.1f}–{ce:.1f}s\n"
                    f"VOICEOVER: {text}"
                )
            clip_block = '\n\n'.join(clip_cards)

            # Previous plot context (last 5 clips before this chunk)
            prev_plot = ""
            if cursor > 0:
                prev_start = max(0, cursor - 5)
                plot_lines = []
                for c in clips[prev_start:cursor]:
                    cs, ce = c.get('startTime', 0), c.get('endTime', 0)
                    texts = [f['text'] for f in fragments
                             if f.get('start', 0) < ce and f.get('end', 0) > cs]
                    plot_lines.append(f"Clip {c['id']} ({cs:.1f}-{ce:.1f}s): {' '.join(texts).strip()}")
                prev_plot = '\n'.join(plot_lines)

            # Контекст предыдущих промптов
            prev_sample = ""
            if prompts_path.exists() and total_prompts > 0:
                existing = prompts_path.read_text(encoding='utf-8').strip().split('\n\n')
                prev_sample = '\n\n'.join(existing[-5:])

            # Always full prompt — no session resume (testing: fresh exec per chunk)
            task_prompt = self._build_pass2_prompt(
                style_guide_path, prompts_path,
                clip_block, from_id, to_id, n_clips, total_clips,
                prev_sample, prev_plot, total_prompts > 0
            )

            chunk_label = f" (клипы {from_id}–{to_id})" if total_clips > chunk_size else ""
            print(f"\n✍️  GPT Pass 2: генерация промптов{chunk_label}...")
            _input_chars = len(task_prompt)
            print(f"   📊 Input: {_input_chars:,} chars ≈ {_input_chars // 3:,} tokens")
            print(f"   🔑 Input session_id: NONE (fresh exec, no resume)")
            logging.info(f"Pass2 chunk {chunk_idx+1}: clips {from_id}-{to_id}, input_session=NONE (no-resume mode)")

            # Бэкап существующего контента — защита от перезаписи Codex
            _backup_content = None
            if total_prompts > 0 and prompts_path.exists():
                _backup_content = prompts_path.read_text(encoding='utf-8')

            file_total, _session_id, _ = self._run_codex_pass2(
                task_prompt, prompts_path, n_clips, output_dir,
                prompts_offset=total_prompts,
                session_id=None,  # no resume — fresh exec every chunk
                total_clips=total_clips,
                global_start=_pass2_total_start,
            )
            # Log session created (for debug only — not reused)
            if _session_id:
                logging.info(f"Pass2 chunk {chunk_idx+1} session: {_session_id[:30]} (not reused)")

            # Copy raw Codex session JSONL to project raw_gpt/ folder
            if _session_id:
                try:
                    _raw_dir = output_dir / 'raw_gpt'
                    _raw_dir.mkdir(exist_ok=True)
                    _today = datetime.now()
                    _sess_dir = Path.home() / '.codex' / 'sessions' / str(_today.year) / f'{_today.month:02d}' / f'{_today.day:02d}'
                    _sess_files = list(_sess_dir.glob(f'*{_session_id[:16]}*.jsonl')) if _sess_dir.exists() else []
                    if not _sess_files:
                        _sess_files = sorted([f for f in _sess_dir.glob('rollout-*.jsonl') if f.stat().st_mtime >= _pass2_total_start - 5], key=lambda f: f.stat().st_mtime)
                        _sess_files = _sess_files[-1:] if _sess_files else []
                    for _sf in _sess_files:
                        _dst = _raw_dir / f'pass2_chunk{chunk_idx}_{_sf.name}'
                        shutil.copy2(str(_sf), str(_dst))
                        logging.info(f"Raw GPT session copied: {_dst.name}")
                        print(f"   📁 Raw session → raw_gpt/{_dst.name}")
                except Exception as _e:
                    logging.warning(f"Could not copy raw session: {_e}")

            # Проверка: Codex не перезаписал предыдущие промпты
            if _backup_content is not None and prompts_path.exists():
                current = prompts_path.read_text(encoding='utf-8')
                _backup_start = _backup_content[:120].strip()
                if _backup_start and not current.startswith(_backup_start[:80]):
                    # Codex перезаписал файл — восстанавливаем
                    merged = _backup_content.rstrip() + '\n\n' + current.strip()
                    prompts_path.write_text(merged, encoding='utf-8')
                    file_total = len([p for p in merged.split('\n\n') if p.strip()])
                    logging.warning(f"Pass2: Codex overwrote file! Restored {total_prompts} prev + appended new → {file_total} total")
                    print(f"   ⚠️  Codex перезаписал файл — восстановлено {file_total} промптов")

            written = file_total - total_prompts  # добавлено в этом чанке
            chunk_idx += 1

            # Output stats (cap display at total_clips to avoid confusion)
            _disp_total = min(file_total, total_clips)
            _disp_written = min(written, n_clips)
            if prompts_path.exists():
                _fsize = prompts_path.stat().st_size
                _chars = len(prompts_path.read_text(encoding='utf-8'))
                _est_tokens = _chars // 3
                print(f"   → Записано: {_disp_written}, всего: {_disp_total}/{total_clips}")
                print(f"   📊 Output: {_chars:,} chars ≈ {_est_tokens:,} tokens ({_fsize:,} bytes)")
            else:
                print(f"   → Записано: {_disp_written}, всего: {_disp_total}/{total_clips}")

            total_prompts = file_total

            if written < n_clips:
                if written == 0:
                    _chunk_retries += 1
                    if _chunk_retries > _MAX_CHUNK_RETRIES:
                        logging.warning(f"Pass2: no progress after {_MAX_CHUNK_RETRIES} retries ({total_prompts}/{total_clips}) — stopping")
                        print(f"   ❌ {_MAX_CHUNK_RETRIES} попыток без прогресса — останавливаюсь")
                        break
                    logging.warning(f"Pass2: no progress ({total_prompts}/{total_clips}) — retry {_chunk_retries}/{_MAX_CHUNK_RETRIES}")
                    print(f"   🔄 0 промптов — ретрай чанка ({_chunk_retries}/{_MAX_CHUNK_RETRIES})...")
                    time.sleep(5)
                    continue
                # Частичная запись (таймаут?) — продолжаем со следующего клипа
                logging.warning(f"Pass2 partial chunk: {written}/{n_clips}, resuming from clip {total_prompts + 1}")
                print(f"   ⚡ Частичная запись {written}/{n_clips} — продолжаем с клипа {total_prompts + 1}")
                cursor = total_prompts
                continue

            _chunk_retries = 0  # успешный чанк — сброс ретраев
            cursor = chunk_end

            if chunk_end >= total_clips:
                break

        # Финальная валидация
        if prompts_path.exists():
            actual = prompts_path.read_text(encoding='utf-8').strip().split('\n\n')
            actual_count = len([p for p in actual if p.strip()])
            if actual_count != total_prompts:
                logging.warning(f"Prompts count mismatch: control={total_prompts}, file={actual_count}")
                total_prompts = actual_count

            # Trim если больше чем клипов
            if total_prompts > total_clips:
                logging.warning(f"Overprompt: {total_prompts}>{total_clips}, trimming")
                all_p = [p for p in actual if p.strip()]
                prompts_path.write_text(
                    '\n\n'.join(all_p[:total_clips]),
                    encoding='utf-8'
                )
                total_prompts = total_clips

        _pass2_elapsed = time.time() - _pass2_total_start
        _p2m, _p2s = int(_pass2_elapsed) // 60, int(_pass2_elapsed) % 60
        print(f"\n✅ GPT Pass 2 завершён: {total_prompts}/{total_clips} промптов ({_p2m}м {_p2s:02d}с)")
        return prompts_path if total_prompts > 0 else None, total_prompts

    def _build_pass2_prompt(
        self,
        style_guide_path: Path,
        prompts_path: Path,
        clip_block: str,
        from_id: int,
        to_id: int,
        n_clips: int,
        total_clips: int,
        prev_sample: str,
        prev_plot: str,
        append_mode: bool,
    ) -> str:
        """Сборка промпта для Pass 2 с clip cards (как Gemini)."""
        # Read style guide inline — avoids Codex file read tool calls
        try:
            _sg_text = style_guide_path.read_text(encoding='utf-8', errors='replace')
        except Exception:
            _sg_text = f"(could not read style guide: {style_guide_path})"

        prev_section = ""
        if prev_sample:
            prev_section = f"""
## PREVIOUS PROMPTS (for style consistency — continue in the same format)
{prev_sample}
"""
        plot_section = ""
        if prev_plot:
            plot_section = f"""
## PREVIOUS SCENE CONTEXT (what was just visualized)
{prev_plot}
"""

        return f"""You are a film director writing visual prompts for image generation.

## STYLE GUIDE
{_sg_text}
{plot_section}{prev_section}
## CLIPS TO PROCESS ({n_clips} clips, {from_id}–{to_id} out of {total_clips} total)

{clip_block}

## TASK
Write one visual image-generation prompt per clip. You are writing prompts for an AI image generator (Banana/Imagen/DALL-E class). The generator does NOT understand narrative text — it needs a precise visual description of a single frozen frame.

⚠️ CRITICAL: DO NOT copy, quote, paraphrase, or embed the voiceover text into the prompt. DO NOT write "visualize this narrated moment:" followed by the script text. The voiceover tells you WHAT IS HAPPENING — your job is to describe WHAT THE CAMERA SEES as a detailed visual composition for an AI image generator.

The image generator does NOT understand narrative text, foreign languages, or abstract concepts. It ONLY understands concrete visual descriptions in English: objects, people, lighting, textures, colors, composition.

## PROMPT STRUCTURE

Each prompt MUST follow this block structure as ONE continuous line:

`[PERIOD, YEAR] [LOCATION] [CAMERA ANGLE]: [PRIMARY SUBJECT — appearance, posture, clothing, expression, action] [SUBJECT MOOD — emotion visible in body language] [SECONDARY ELEMENTS — other people, objects, props in frame] [SCENE INTERACTION — what is happening between elements] [LIGHTING & ATMOSPHERE] [STYLE from style guide] [NEGATIVE PROMPT from style guide]`

### BLOCK-BY-BLOCK GUIDE:

1. **PERIOD & SETTING** — historical era, year range, geographic region (e.g. "Colonial Caribbean, 1695", "Viking-era North Atlantic, 900 AD")
2. **LOCATION** — specific place, not generic (e.g. "cramped below-deck chart room of a weathered brig, salt-stained oak walls, low ceiling with hanging lanterns" — NOT just "a ship")
3. **CAMERA ANGLE** — from style guide rotation: wide → medium → close-up → cycle
4. **PRIMARY SUBJECT** — who/what is center-frame. Describe VISUALLY: age, build, skin, clothing fabric, hair, facial expression, hand position, posture, specific action (e.g. "a gaunt 40-year-old navigator in a salt-crusted linen coat, squinting through a brass cross-staff aimed at Polaris, deep sun-creases around his eyes")
5. **SUBJECT MOOD & INTENT** — emotion shown through VISIBLE body language (e.g. "tense concentration, jaw clenched, knuckles white on the instrument" — NOT "he feels worried")
6. **SECONDARY ELEMENTS** — other people, objects, props visible (e.g. "two sleeping crew members in rope hammocks behind him, a tallow candle guttering on the chart table, an unrolled parchment map weighted down with a compass")
7. **SCENE INTERACTION** — the core visual action or tension between elements (e.g. "his finger traces a line on the map while his eyes dart between the star and the horizon")
8. **LIGHTING & ATMOSPHERE** — light source, color temperature, mood (e.g. "cold silver starlight from above mixing with warm amber lantern glow from below, sea mist diffusing the edges")
9. **STYLE** — from style guide: photorealistic, textures, depth of field, composition
10. **NEGATIVE PROMPT** — from style guide: what to avoid

### GOOD EXAMPLE:
```
Colonial Caribbean, 1695. Cramped below-deck chart room of a weathered pirate brig, salt-stained oak planks, low ceiling with a swinging oil lantern. Close-up shot. A gaunt 40-year-old navigator in a threadbare linen shirt, deep sun-creases around squinting eyes, calloused fingers gripping a brass divider against a yellowed parchment sea chart. Intense focus, lips pressed thin, brow furrowed — a man calculating whether 200 lives survive tomorrow. Behind him: a half-empty hourglass, a knotted rope log-line coiled on a nail, a crude wooden cross-staff leaning against the bulkhead. His divider tip rests on an ink-drawn coastline while his gaze measures the distance to a question mark labeled "aquí hay monstruos." Warm amber lantern glow from above, cool blue moonlight leaking through a deck seam, cigarette-thick dust motes in the light shaft. Photorealistic prestige-TV composition, tactile salt-worn surfaces, shallow depth of field on the divider tip. No modern instruments, no GPS, no clean surfaces, no fantasy elements, single full-frame continuous camera view edge-to-edge
```

### BAD EXAMPLE (DO NOT DO THIS):
```
Cinematic scene, visualize only this narrated moment: Imagina que es medianoche. El barco cruje bajo tus pies. ❌ THIS IS SCRIPT TEXT, NOT A VISUAL PROMPT
```

## DIVERSITY RULES:
- Each prompt MUST show a DIFFERENT visual composition — change location, subject, framing, or action
- NEVER repeat the same establishing shot for consecutive clips
- If 3 consecutive clips discuss the same topic, show it from 3 different angles: environment → character → object detail
- Vary between: landscape/environment, character portrait, object close-up, action moment, atmospheric wide
- Every prompt must be >50 words of visual description (not counting negative prompt)
- NO "Narration:" tags, NO voiceover text, NO script quotes, NO comments about duration

LANGUAGE: Write ALL prompts in English regardless of voiceover language.

⚠️ SEQUENTIAL PROCESSING — MANDATORY:
Process each [CLIP] block in the EXACT order listed above. For each one, read its VOICEOVER, then write ONE prompt that visually illustrates what that voiceover describes. Do NOT reorganize, group, or batch prompts by topic, era, or style guide section. The style guide is a LOOKUP REFERENCE for visual treatment — not a generation plan.

STRICT OUTPUT RULES:
- Each prompt = ONE continuous line, no line breaks inside the prompt
- Prompts separated by ONE blank line between them
- Exactly {n_clips} prompts, one per clip
- Each prompt MUST start with the clip header copied from input, e.g. [CLIP 47] (exactly as written in the [CLIP N] header above)
- Camera angle rotation: wide → medium → close-up → wide (cycle)
- Each prompt must end with: "single full-frame continuous camera view edge-to-edge"

⚠️ CRITICAL OUTPUT INSTRUCTION:
Do NOT create files. Do NOT run shell commands.
Return your answer as a STRICT JSON object without markdown:
{{"prompts":["[CLIP {from_id}] prompt text","[CLIP next_id] prompt text",...,"[CLIP {to_id}] prompt text"]}}
The "prompts" array must have exactly {n_clips} non-empty strings. Each element MUST start with [CLIP N] matching the input clip header."""


# =========================================================================
# Wrapper function — аналог direct_project() для GptDirector
# =========================================================================

def gpt_direct_project(
    transcription_path: str,
    style_guide_path: str,
    output_dir: str,
    project_name: str = "Untitled",
    model_name: Optional[str] = None,
    two_pass: bool = False,
    prompts_only: bool = False,
    resume_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Wrapper: создаёт GptDirector и запускает analyze()."""
    director = GptDirector(model_name=model_name)
    return director.analyze(
        transcription_path, style_guide_path, output_dir, project_name,
        two_pass=two_pass, prompts_only=prompts_only, resume_path=resume_path,
    )
