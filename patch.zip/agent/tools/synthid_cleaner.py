#!/usr/bin/env python3
"""
synthid_cleaner.py — Google SynthID watermark removal wrapper.

Wraps: https://github.com/aloshdenny/reverse-SynthID
Source: src/extraction/synthid_bypass.py

TWO USAGE MODES:

1. CLI — Control Panel standalone (processes entire folder):
       python synthid_cleaner.py <images_dir> [--strength moderate] [--version v1]
   Prints PROGRESS:N/TOTAL on each processed image.

2. Importable — inflight hook from imggen.py / fastgen.py worker threads:
       from tools.synthid_cleaner import clean_single_image
       ok = clean_single_image(path, strength='moderate', version='v1')
   Synchronous, runs in calling thread (one per image concurrently).
   Returns True on success, False on failure (never raises).

Logging:
    CLI mode: prints [SynthID] ... + PROGRESS:N/TOTAL
    Function mode: prints [SynthID] <filename>: OK/FAILED with flush=True
    Both go to stdout of the calling process (piped to varagent.py log).
"""

import sys
import os
import argparse
import shutil
import subprocess
import urllib.request
from pathlib import Path

# ── Tool download config ──────────────────────────────────────────────────────
_BASE_URL  = "https://raw.githubusercontent.com/aloshdenny/reverse-SynthID/main/src/extraction/"
TOOL_LOCAL = Path(__file__).parent / "_synthid_bypass.py"

# local name → remote filename in src/extraction/
_REQUIRED_FILES = {
    "_synthid_bypass.py":   "synthid_bypass.py",
    "robust_extractor.py":  "robust_extractor.py",
}

# pip package name -> import name
DEPS_MAP = {
    "numpy":          "numpy",
    "scipy":          "scipy",
    "opencv-python":  "cv2",
    "PyWavelets":     "pywt",
    "scikit-learn":   "sklearn",
    "Pillow":         "PIL",
    "tqdm":           "tqdm",
}


# ── Helpers ───────────────────────────────────────────────────────────────────

def _log(msg: str) -> None:
    print(f"[SynthID] {msg}", flush=True)


def _ensure_deps() -> None:
    missing = []
    for pkg, import_name in DEPS_MAP.items():
        try:
            __import__(import_name)
        except ImportError:
            missing.append(pkg)
    if not missing:
        return
    _log(f"Installing missing deps: {' '.join(missing)}")
    subprocess.run(
        [sys.executable, "-m", "pip", "install", "--quiet"] + missing,
        check=False,
    )
    for pkg, import_name in DEPS_MAP.items():
        if pkg in missing:
            try:
                __import__(import_name)
            except ImportError:
                _log(f"ERROR: Could not install {pkg}. Run: pip install {pkg}")
                # Don't sys.exit here — called from worker threads; just return
                return


def _ensure_tool() -> bool:
    """Download all required repo files. Returns True if all available."""
    tools_dir = Path(__file__).parent
    missing = {
        local: remote
        for local, remote in _REQUIRED_FILES.items()
        if not (tools_dir / local).exists()
    }
    if not missing:
        return True
    _log(f"Downloading {len(missing)} file(s) from GitHub...")
    for local_name, remote_name in missing.items():
        url = _BASE_URL + remote_name
        dest = tools_dir / local_name
        _log(f"  -> {remote_name}")
        try:
            urllib.request.urlretrieve(url, str(dest))
            _log(f"     OK: {local_name}")
        except Exception as e:
            _log(f"ERROR: Could not download {remote_name}: {e}")
            return False
    return True


# ── Core single-image function (importable) ───────────────────────────────────

def clean_single_image(
    file_path: str,
    strength: str = "moderate",
    version: str = "v1",
) -> bool:
    """
    Remove SynthID watermark from a single image file in-place.

    Called from imggen.py / fastgen.py worker threads immediately after
    each image is saved to generated/. Synchronous — blocks only the
    calling thread. Safe to call concurrently from multiple threads.

    Args:
        file_path: Absolute path to the image file (.jpg/.png)
        strength:  'gentle' | 'moderate' | 'aggressive' | 'extreme'
        version:   'v1' | 'v2' | 'v3'

    Returns:
        True on success (original backed up, file replaced with clean version)
        False on any failure (original preserved, no modification)
    """
    p = Path(file_path)
    if not p.exists():
        _log(f"WARNING: file not found: {p.name}")
        return False

    if not _ensure_tool():
        return False

    tmp_out = p.with_name(p.stem + "_synthid_tmp" + p.suffix)
    orig_bak = p.with_name(p.stem + "_synthid_orig" + p.suffix)

    try:
        result = subprocess.run(
            [
                sys.executable, str(TOOL_LOCAL),
                "bypass", str(p), str(tmp_out),
                "--version", version,
                "--strength", strength,
                "--no-verify",
            ],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )

        if result.returncode != 0 or not tmp_out.exists():
            # Log any error output for diagnosis
            err = (result.stderr or result.stdout or "").strip()
            if err:
                _log(f"WARNING: {p.name}: {err[:120]}")
            # Clean up temp if it exists
            if tmp_out.exists():
                tmp_out.unlink()
            return False

        # Back up original, replace with cleaned version
        shutil.copy2(str(p), str(orig_bak))
        shutil.move(str(tmp_out), str(p))
        return True

    except Exception as e:
        _log(f"WARNING: exception processing {p.name}: {e}")
        if tmp_out.exists():
            try:
                tmp_out.unlink()
            except Exception:
                pass
        return False


# ── CLI mode (Control Panel standalone) ──────────────────────────────────────

def main() -> None:
    # Quick install-only mode (no folder needed)
    if '--install' in sys.argv:
        _ensure_deps()
        _ensure_tool()
        _log("[OK] SynthID remover installed successfully")
        sys.exit(0)

    parser = argparse.ArgumentParser(
        description="Remove SynthID watermarks from all images in a folder"
    )
    parser.add_argument("images_dir", help="Folder containing .jpg/.png images")
    parser.add_argument(
        "--strength",
        choices=["gentle", "moderate", "aggressive", "extreme"],
        default="moderate",
        help="Removal strength (default: moderate)",
    )
    parser.add_argument(
        "--version",
        choices=["v1", "v2", "v3"],
        default="v1",
        help="Bypass algorithm version (default: v1, no codebook needed)",
    )
    args = parser.parse_args()

    images_dir = Path(args.images_dir)
    if not images_dir.is_dir():
        print(f"[SynthID] ERROR: Not a directory: {images_dir}", flush=True)
        sys.exit(1)

    _ensure_deps()

    # Collect images (skip backups/temps from previous runs)
    images = sorted(
        f for f in (list(images_dir.glob("*.jpg")) + list(images_dir.glob("*.png")))
        if "_synthid_orig" not in f.name and "_synthid_tmp" not in f.name
    )

    if not images:
        _log("No images to process.")
        print("[OK] SynthID: nothing to clean.", flush=True)
        sys.exit(0)

    total = len(images)
    _log(f"Processing {total} images  strength={args.strength}  version={args.version}")
    print(f"PROGRESS:0/{total}", flush=True)

    ok_count = 0
    fail_count = 0

    for i, img in enumerate(images, 1):
        success = clean_single_image(str(img), strength=args.strength, version=args.version)
        status = "OK" if success else "FAILED"
        _log(f"{img.name}: {status}")
        if success:
            ok_count += 1
        else:
            fail_count += 1
        print(f"PROGRESS:{i}/{total}", flush=True)

    _log(f"Done: {ok_count} cleaned, {fail_count} failed")
    print(f"[OK] SynthID removal complete: {ok_count}/{total} images processed", flush=True)

    if fail_count > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
