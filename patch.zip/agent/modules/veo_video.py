"""
VeoNonStop veo_video — batch-генерация видео (этап 3.5 пайплайна)

Режимы:
  i2v        — image-to-video: оживление картинок из generated/
  t2v        — text-to-video: видео прямо из промптов (без картинок)
  components — multi-image-to-video: видео из промптов + референсы из ref/

Результат: vid_img/{id:03d}.mp4  (далее video_concat ретаймит по montage_plan)
"""

import sys
import json
import time
import random
import logging
import shutil

IS_PIPE = not sys.stdout.isatty()  # True когда запущен как subprocess (pipeline mode)
import threading
import requests
from pathlib import Path
from typing import Optional, Dict, List, Any
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED, as_completed

# Ensure agent/ and agent/modules/ dirs are on sys.path
_agent_dir = str(Path(__file__).resolve().parent.parent)
_modules_dir = str(Path(__file__).resolve().parent)
if _agent_dir not in sys.path:
    sys.path.insert(0, _agent_dir)
if _modules_dir not in sys.path:
    sys.path.insert(0, _modules_dir)

from tqdm import tqdm
import colorama
from remix import remix_ref, remix_i2v
from colorama import Fore, Style

colorama.init(autoreset=True)

_YELLOW = Fore.YELLOW
_RED    = Fore.RED
_GREEN  = Fore.GREEN
_CYAN   = Fore.CYAN
_RESET  = Style.RESET_ALL

# ======================================================================
# Soft-start (защита от одновременного старта всех воркеров) — УДАЛЕНО
# ======================================================================
# Теперь как у юзера (2.py) — отправляем задачи сразу без stagger
_HUNG_TASK_TIMEOUT = 300  # секунд в session_init/uploading до cancel + retry

_started_workers: set = set()   # воркеры, уже прошедшие первый стаггер
_started_workers_lock = threading.Lock()


# ======================================================================
# Graceful shutdown (Ctrl+C)
# ======================================================================
# Флаг: воркеры проверяют перед каждым submit/poll
_shutdown_requested = threading.Event()
# Текущие task_id в полёте — для cancel через API
_inflight_tasks: Dict[int, str] = {}  # clip_id -> task_id
_inflight_lock = threading.Lock()
# Путь к active_tasks.json — устанавливается в generate_all_videos()
_active_tasks_path: Optional[Path] = None
# Submit semaphore: ограничивает одновременные POST-запросы (submit), poll/download без ограничений
_submit_semaphore: Optional[threading.Semaphore] = None
# Active clients list for external stop (Control Panel Stop button)
_active_clients: list = []
# Текущий max_parallel — для slot-wait при slots_full retry
_max_parallel_global: int = 0
# Per-key inflight: label -> set of clip_ids (для dual-key slot-wait по каждому ключу отдельно)
_inflight_by_key: Dict[str, set] = {}
_inflight_by_key_lock = threading.Lock()
# Per-key max_parallel: label -> int
_max_parallel_by_key: Dict[str, int] = {}


def _save_active_tasks() -> None:
    """Записывает _inflight_tasks в active_tasks.json. Вызывать под _inflight_lock."""
    if _active_tasks_path is None:
        return
    try:
        _active_tasks_path.write_text(
            json.dumps(_inflight_tasks, ensure_ascii=False), encoding='utf-8'
        )
    except Exception:
        pass

import config
from extract_prompt import extract_all_prompts, find_prompts_file
from veononstop import (
    VeoNonStopClient,
    VeoNonStopError,
    VeoNonStopTimeoutError,
    VeoNonStopGenerationError,
    VeoNonStopRateLimitError,
    VeoNonStopHungError,
    IMAGE_EXTENSIONS,
    _load_ref_images,
)
from fastgen import FastGenClient


# ======================================================================
# Классификация ошибок
# ======================================================================

_ERROR_PATTERNS = [
    ('invalid_argument', ['invalid argument']),
    ('status_failed',    ['media_generation_status_failed']),
    ('recaptcha',        ['recaptcha', 'forbidden']),
    ('slots_full',       ['cookie slots full', 'slots full']),
    ('ratelimit',        ['rate limit', '429']),
    ('timeout',          ['timeout', 'timed out']),
    ('censored',         ['censor', 'policy', 'safety']),
    ('person',           ['person', 'prominent']),
]


def _count_error(error_counts: dict, error_msg: str) -> str:
    """
    Классифицирует ошибку по тексту и инкрементирует счётчик.
    Returns: ключ категории
    """
    msg_lower = error_msg.lower()
    for key, patterns in _ERROR_PATTERNS:
        if any(p in msg_lower for p in patterns):
            error_counts[key] = error_counts.get(key, 0) + 1
            return key
    # Неизвестная ошибка — первые 30 символов
    short = error_msg[:30].replace(' ', '_').lower()
    error_counts[short] = error_counts.get(short, 0) + 1
    return short


# ======================================================================
# Детекторы цензуры VeoNonStop
# ======================================================================

def _is_content_policy_error(error_msg: str) -> bool:
    """Цензура по содержанию промпта (насилие, нагота и т.п.)"""
    msg = error_msg.lower()
    return any(p in msg for p in [
        'content policy', 'policy violation', 'safety filter',
        'blocked by safety', 'harmful content', 'unsafe content',
        'violates', 'not allowed', 'prohibited', 'moderation',
        # VeoNonStop API error codes
        'public_error_danger_filter',
        'public_error_unsafe_generation',
        'public_error_audio_filtered',
        'public_error_ip_input_image',
    ])


def _is_prominent_person_error(error_msg: str) -> bool:
    """Цензура из-за упоминания известной личности по имени"""
    msg = error_msg.lower()
    return any(p in msg for p in [
        'prominent people', 'well-known individuals', 'known individuals',
        'celebrity', 'public figure', 'real person', 'named individual',
        'person by name',
        # VeoNonStop API error codes
        'prominent_people_filter',
    ])


def _gemini_rewrite(original_prompt: str, for_person: bool = False) -> str:
    """
    Rewrite a blocked prompt via Gemini API.
    for_person arg kept for call-site compatibility but ignored — unified prompt handles both cases.
    Instruction loaded from agent/prompts/rewrite_prompt.txt (user-editable).
    """
    from gemini_rewrite import rewrite_prompt as _gr
    return _gr(original_prompt)


# ======================================================================
# Генерация одного клипа
# ======================================================================

class ShutdownRequested(Exception):
    """Raised when graceful shutdown is requested (Ctrl+C)."""
    pass


def _submit_and_download(
    client: VeoNonStopClient,
    clip_id: int,
    prompt: str,
    mode: str,
    image_path: Optional[str],
    ref_dir: Optional[str],
    output_path: Path,
    aspect_ratio: Optional[str],
    end_image_path: Optional[str] = None,
    submit_sem=None,
    key_label: str = 'Key1',
) -> tuple:
    """
    Один цикл submit → poll → download.
    Возвращает (task_id, t_upload_sec, t_gen_sec, t_dl_sec).
    Бросает исключения при любой ошибке.
    """
    import random

    # Проверка shutdown ПЕРЕД ожиданием слота
    if _shutdown_requested.is_set():
        raise ShutdownRequested(f"Clip #{clip_id}: shutdown before submit")

    try:
        # Микроджиттер: слегка разносим POST-запросы при старте/ретраях
        jitter = random.uniform(0.5, 1.5)
        time.sleep(jitter)

        # Submit semaphore: только N воркеров одновременно шлют POST, остальные ждут
        _sem = submit_sem if submit_sem is not None else _submit_semaphore
        if _sem is not None:
            _sem.acquire()
        try:
            t_upload_start = time.time()
            if mode == 'i2v':
                if not image_path or not Path(image_path).exists():
                    raise FileNotFoundError(f"Image not found: {image_path}")
                task_id = client.submit_image_to_video(
                    image_path=image_path,
                    prompt=prompt,
                    aspect_ratio=aspect_ratio,
                )
            elif mode == 't2v':
                task_id = client.submit_text_to_video(
                    prompt=prompt,
                    aspect_ratio=aspect_ratio,
                )
            elif mode == 'components':
                if not ref_dir:
                    raise ValueError("ref_dir required for components mode")
                task_id = client.submit_multi_image_to_video_from_ref_dir(
                    ref_dir=ref_dir,
                    prompt=prompt,
                    aspect_ratio=aspect_ratio,
                )
            elif mode == 'batch_frame':
                if not image_path or not Path(image_path).exists():
                    raise FileNotFoundError(f"Start image not found: {image_path}")
                # end_image fallback: если конца нет — используем start (zoom/motion effect)
                end_path = end_image_path if (end_image_path and Path(end_image_path).exists()) else image_path
                task_id = client.submit_batch_frame(
                    start_image_path=image_path,
                    end_image_path=end_path,
                    prompt=prompt,
                    aspect_ratio=aspect_ratio,
                )
            else:
                raise ValueError(f"Unknown mode: {mode}")
            t_upload = round(time.time() - t_upload_start, 1)
        finally:
            if _sem is not None:
                _sem.release()

        logging.info(f"Clip #{clip_id}: submitted ({mode}) -> taskId={task_id}")

        # Регистрируем task_id для возможного cancel + per-key inflight
        with _inflight_lock:
            _inflight_tasks[clip_id] = task_id
            _save_active_tasks()
        with _inflight_by_key_lock:
            if key_label not in _inflight_by_key:
                _inflight_by_key[key_label] = set()
            _inflight_by_key[key_label].add(clip_id)

        try:
            # Проверка shutdown ПОСЛЕ submit (можем ещё cancel)
            if _shutdown_requested.is_set():
                client.cancel_task(task_id)
                raise ShutdownRequested(f"Clip #{clip_id}: shutdown after submit, task cancelled")

            t_gen_start = time.time()
            try:
                _poll_data = client.poll_video_status(task_id, hung_timeout=_HUNG_TASK_TIMEOUT)
            except VeoNonStopHungError:
                # Таск завис в session_init/uploading >2мин — отменяем и бросаем выше
                logging.warning(f"Clip #{clip_id}: task {task_id} hung >{_HUNG_TASK_TIMEOUT}s, cancelling")
                client.cancel_task(task_id)
                raise
            t_gen = round(time.time() - t_gen_start, 1)

            # Extract mediaGenerationId for video upscale
            _media_gen_id = None
            if _poll_data and isinstance(_poll_data, dict):
                _vids = _poll_data.get('videos', [])
                if _vids and isinstance(_vids, list):
                    _media_gen_id = _vids[0].get('mediaGenerationId')
                if not _media_gen_id:
                    _media_gen_id = _poll_data.get('mediaGenerationId')

            # Проверка shutdown ПОСЛЕ poll (видео готово — скачиваем)
            if _shutdown_requested.is_set():
                logging.info(f"Clip #{clip_id}: shutdown requested but video ready, downloading...")

            t_dl_start = time.time()
            client.download_video(task_id, str(output_path))
            t_dl = round(time.time() - t_dl_start, 1)

            return task_id, t_upload, t_gen, t_dl, _media_gen_id
        finally:
            with _inflight_lock:
                _inflight_tasks.pop(clip_id, None)
                _save_active_tasks()
            with _inflight_by_key_lock:
                _inflight_by_key.get(key_label, set()).discard(clip_id)
    except Exception:
        raise


def _wait_for_slot(clip_id: int, tag: str, phase_label: str, count: int, key_label: str = '') -> None:
    """Ждёт пока inflight < max_parallel для данного ключа (или общий), потом 5s буфер."""
    # Выбираем per-key или общий счётчик
    if key_label and key_label in _max_parallel_by_key:
        mp = _max_parallel_by_key[key_label]
        def get_inflight():
            with _inflight_by_key_lock:
                return len(_inflight_by_key.get(key_label, set()))
    else:
        mp = _max_parallel_global
        def get_inflight():
            with _inflight_lock:
                return len(_inflight_tasks)
    if mp <= 0:
        time.sleep(15)
        return
    t_start = time.time()
    deadline = t_start + 120  # не ждём вечно
    while time.time() < deadline:
        if get_inflight() < mp:
            break
        time.sleep(3)
    waited = round(time.time() - t_start, 1)
    time.sleep(5)  # буфер после освобождения
    inflight_now = get_inflight()
    logging.warning(f"Clip #{clip_id} {tag} [{phase_label}]: slots full ({count}/10), waited {waited:.0f}s, inflight={inflight_now}/{mp}")
    print(f"\n  {_YELLOW}[SLOTS FULL]{_RESET} #{clip_id} {tag}: ({count}/10) waited {waited:.0f}s, inflight={inflight_now}/{mp}")


def _run_phase(
    client: VeoNonStopClient,
    clip_id: int,
    prompt: str,
    mode: str,
    image_path: Optional[str],
    ref_dir: Optional[str],
    output_path: Path,
    aspect_ratio: Optional[str],
    max_retries: int,
    phase_label: str,
    worker_id: int = 0,
    clip_start_time: str = '',
    end_image_path: Optional[str] = None,
    submit_sem=None,
    key_label: str = 'Key1',
) -> Dict[str, Any]:
    """
    Одна фаза: до max_retries попыток.
    Returns:
        {
            'ok': True/False,
            'task_id': str (if ok),
            'elapsed': float,           # суммарное время фазы
            'upload_sec': float,        # время POST-запроса (отправка)
            'gen_sec': float,           # время poll (генерация на сервере)
            'dl_sec': float,            # время скачивания
            'retries': int,             # количество ретраев (attempts - 1)
            'retry_time': float,        # время на ретраи
            'error_counts': dict,       # ошибки по типам
            'error': str,               # текст ошибки (если failed)
            'censored': bool,           # если цензура
            'prominent_person': bool,   # если известная личность
        }
    """
    censored = False
    prominent_person = False
    last_error = ''
    status_failed_count = 0        # счётчик MEDIA_GENERATION_STATUS_FAILED суммарно (не подряд)
    invalid_arg_count = 0          # счётчик "invalid argument" подряд
    slots_full_count = 0           # счётчик slots_full (макс 10, не тратит попытку)
    ratelimit_count = 0            # счётчик ratelimit 429 (макс 10, не тратит попытку)
    recaptcha_retry_count = 0      # счётчик reCAPTCHA (макс 5, не тратит попытку)
    error_counts: Dict[str, int] = {}
    retry_time = 0.0
    total_elapsed = 0.0

    tag = f"[W{worker_id}]"

    attempt = 0
    while attempt < max_retries:
        attempt += 1
        try:
            start = time.time()
            task_id, t_upload, t_gen, t_dl, _media_gen_id = _submit_and_download(
                client, clip_id, prompt, mode, image_path, ref_dir, output_path, aspect_ratio,
                end_image_path=end_image_path,
                submit_sem=submit_sem,
                key_label=key_label,
            )
            elapsed = round(time.time() - start, 1)
            retries = attempt - 1
            return {
                'ok': True, 'task_id': task_id, 'elapsed': elapsed,
                'upload_sec': t_upload, 'gen_sec': t_gen, 'dl_sec': t_dl,
                'retries': retries, 'retry_time': round(retry_time, 1),
                'error_counts': error_counts,
                'error': '', 'censored': False, 'prominent_person': False,
                'media_generation_id': _media_gen_id,
            }

        except VeoNonStopRateLimitError:
            ratelimit_count += 1
            _rl_wait = 10 + random.uniform(1, 5)
            msg = f"#{clip_id} {tag} [{phase_label}] attempt {attempt}: rate limit ({ratelimit_count}/10), waiting {_rl_wait:.1f}s..."
            logging.warning(msg)
            print(f"\n  {_YELLOW}[RATELIMIT]{_RESET} {msg}")
            _count_error(error_counts, 'rate limit 429')
            if ratelimit_count >= 10:
                logging.error(f"Clip #{clip_id} {tag} [{phase_label}]: ratelimit 10x — giving up")
                print(f"\n  {_RED}[RATELIMIT]{_RESET} #{clip_id} {tag}: 10 retries exhausted — failed")
                break
            time.sleep(_rl_wait)
            attempt -= 1  # не считается за попытку

        except VeoNonStopHungError as e:
            # Таск завис в session_init/uploading >2мин — cancel уже сделан в _submit_and_download
            attempt_elapsed = time.time() - start
            retry_time += attempt_elapsed
            last_error = str(e)
            _count_error(error_counts, 'hung')
            logging.warning(f"Clip #{clip_id} {tag} [{phase_label}] attempt {attempt}/{max_retries}: HUNG — {e}")
            print(f"\n  {_YELLOW}[HUNG]{_RESET}  #{clip_id} {tag} [{phase_label}] attempt {attempt}/{max_retries}: task stuck >2min, cancelled, retrying...")
            # Небольшая пауза перед ретраем
            time.sleep(10)

        except VeoNonStopGenerationError as e:
            attempt_elapsed = time.time() - start
            retry_time += attempt_elapsed
            last_error = str(e)
            _count_error(error_counts, last_error)
            err_lower = last_error.lower()

            # reCAPTCHA — временная авторизационная ошибка, не тратим попытку, макс 5 раз
            if 'recaptcha' in err_lower:
                recaptcha_retry_count += 1
                if recaptcha_retry_count > 5:
                    logging.error(f"Clip #{clip_id} {tag} [{phase_label}]: reCAPTCHA 5x — giving up")
                    print(f"\n  {_RED}[RECAPTCHA]{_RESET} #{clip_id} {tag}: 5 retries exhausted — failed")
                    break
                logging.warning(f"Clip #{clip_id} {tag} [{phase_label}]: reCAPTCHA — retrying in 30s (not counted as attempt)")
                print(f"\n  {_YELLOW}[RECAPTCHA]{_RESET} #{clip_id} {tag}: reCAPTCHA error — retrying in 30s...")
                time.sleep(10)
                attempt -= 1  # не тратим попытку
                continue

            # Cookie slots full — ждём освобождения реального слота, не тратим попытку, макс 10 раз
            if 'cookie slots full' in err_lower or 'slots full' in err_lower:
                slots_full_count += 1
                _count_error(error_counts, 'slots_full')
                if slots_full_count > 10:
                    logging.error(f"Clip #{clip_id} {tag} [{phase_label}]: slots full 10x — giving up")
                    print(f"\n  {_RED}[SLOTS FULL]{_RESET} #{clip_id} {tag}: 10 retries exhausted — failed")
                    break
                # Ждём пока реально освободится слот (inflight < max_parallel)
                _wait_for_slot(clip_id, tag, phase_label, slots_full_count, key_label=key_label)
                attempt -= 1  # не тратим попытку
                continue

            # "Cancelled by user (cancel-all)" — внешний cancel_all (новый watcher при старте).
            # Не тратим попытку — задача была жива, просто убита извне.
            if 'cancelled by user' in err_lower:
                logging.warning(f"Clip #{clip_id} {tag} [{phase_label}] attempt {attempt}: cancelled by cancel-all — retrying (not counted)")
                print(f"\n  {_YELLOW}[CANCELLED]{_RESET} #{clip_id} {tag}: task cancelled by cancel-all — retrying...")
                attempt -= 1
                time.sleep(5)
                continue

            # Проверяем тип цензуры
            if _is_prominent_person_error(last_error):
                prominent_person = True
                logging.warning(f"Clip #{clip_id} {tag} [{phase_label}]: PROMINENT PERSON — will rewrite")
                print(f"\n  {_RED}[PERSON NAME]{_RESET} #{clip_id} {tag}: prompt mentions a famous person — will rewrite with appearance description")
                break  # нет смысла ретраить
            elif _is_content_policy_error(last_error):
                censored = True
                logging.warning(f"Clip #{clip_id} {tag} [{phase_label}] attempt {attempt}: CENSORED — {e}")
                print(f"\n  {_RED}[CENSORED]{_RESET} #{clip_id} {tag} [{phase_label}] attempt {attempt}/{max_retries}")
                break  # нет смысла ретраить с тем же промптом

            # Считаем MEDIA_GENERATION_STATUS_FAILED суммарно (не подряд)
            if 'media_generation_status_failed' in err_lower:
                status_failed_count += 1
                _sf_threshold = max_retries  # порог = max_retries, чтобы не превысить счётчик попыток
                if status_failed_count >= _sf_threshold:
                    censored = True
                    logging.warning(f"Clip #{clip_id} {tag} [{phase_label}]: {status_failed_count}x STATUS_FAILED total — treating as hidden censorship, will rewrite")
                    print(f"\n  {_RED}[HIDDEN CENSOR?]{_RESET} #{clip_id} {tag}: {status_failed_count}x STATUS_FAILED total — treating as censorship, will rewrite prompt")
                    break
                # Паузы: 5с, 10с, 15с
                _sf_delay = status_failed_count * 5
                logging.info(f"Clip #{clip_id} {tag} [{phase_label}]: STATUS_FAILED ({status_failed_count}/{_sf_threshold}) — retrying in {_sf_delay}s")
                print(f"\n  {_YELLOW}[STATUS_FAILED]{_RESET} #{clip_id} {tag}: ({status_failed_count}/{_sf_threshold}) — retrying in {_sf_delay}s...")
                time.sleep(_sf_delay)
                continue

            # "invalid argument" — Google Veo маскирует цензуру реальных людей
            # под этой generic ошибкой. 1 раз = сразу person rewrite
            if 'invalid argument' in err_lower:
                prominent_person = True
                logging.warning(f"Clip #{clip_id} {tag} [{phase_label}]: 'invalid argument' — treating as person censorship, will rewrite")
                print(f"\n  {_RED}[INVALID ARG → PERSON?]{_RESET} #{clip_id} {tag}: 'invalid argument' — likely person name, will rewrite")
                break

            logging.error(f"Clip #{clip_id} {tag} [{phase_label}] attempt {attempt}/{max_retries}: generation error — {e}")
            print(f"\n  {_RED}[FAILED]{_RESET}  #{clip_id} {tag} [{phase_label}] {attempt}/{max_retries}: {e}")
            if attempt < max_retries:
                delay = min(10 * attempt, 60)
                time.sleep(delay)

        except VeoNonStopTimeoutError as e:
            attempt_elapsed = time.time() - start
            retry_time += attempt_elapsed
            last_error = str(e)
            _count_error(error_counts, last_error)
            logging.warning(f"Clip #{clip_id} {tag} [{phase_label}] attempt {attempt}/{max_retries}: timeout")
            print(f"\n  {_YELLOW}[TIMEOUT]{_RESET} #{clip_id} {tag} [{phase_label}] {attempt}/{max_retries}")
            if attempt < max_retries:
                delay = min(10 * attempt, 60)
                print(f"  {_YELLOW}[RETRY]{_RESET}   waiting {delay}s...")
                time.sleep(delay)

        except ShutdownRequested:
            raise  # пробрасываем наверх — не ловим как обычную ошибку

        except Exception as e:
            attempt_elapsed = time.time() - start
            retry_time += attempt_elapsed
            last_error = str(e)
            _count_error(error_counts, last_error)
            err_lower_ex = last_error.lower()
            # Slots full может прийти сюда если VeoNonStopGenerationError не поймался (module identity)
            if 'cookie slots full' in err_lower_ex or 'slots full' in err_lower_ex:
                slots_full_count += 1
                _count_error(error_counts, 'slots_full')
                if slots_full_count > 10:
                    logging.error(f"Clip #{clip_id} {tag} [{phase_label}]: slots full 10x — giving up")
                    print(f"\n  {_RED}[SLOTS FULL]{_RESET} #{clip_id} {tag}: 10 retries exhausted — failed")
                    break
                _wait_for_slot(clip_id, tag, phase_label, slots_full_count, key_label=key_label)
                attempt -= 1
                continue
            # Cancelled by user (cancel-all) — module identity path
            if 'cancelled by user' in err_lower_ex:
                logging.warning(f"Clip #{clip_id} {tag} [{phase_label}] attempt {attempt}: cancelled by cancel-all (Exception path) — retrying")
                print(f"\n  {_YELLOW}[CANCELLED]{_RESET} #{clip_id} {tag}: task cancelled by cancel-all — retrying...")
                attempt -= 1
                time.sleep(5)
                continue
            # Module identity fallback: STATUS_FAILED суммарно (не подряд)
            if 'media_generation_status_failed' in err_lower_ex:
                status_failed_count += 1
                _sf_threshold = max_retries
                if status_failed_count >= _sf_threshold:
                    censored = True
                    logging.warning(f"Clip #{clip_id} {tag} [{phase_label}]: {status_failed_count}x STATUS_FAILED total — treating as hidden censorship")
                    print(f"\n  {_RED}[HIDDEN CENSOR?]{_RESET} #{clip_id} {tag}: {status_failed_count}x STATUS_FAILED total — treating as censorship, will rewrite prompt")
                    break
                _sf_delay = status_failed_count * 5
                logging.info(f"Clip #{clip_id} {tag} [{phase_label}]: STATUS_FAILED ({status_failed_count}/{_sf_threshold}) — retrying in {_sf_delay}s")
                print(f"\n  {_YELLOW}[STATUS_FAILED]{_RESET} #{clip_id} {tag}: ({status_failed_count}/{_sf_threshold}) — retrying in {_sf_delay}s...")
                time.sleep(_sf_delay)
                continue
            # "invalid argument" — 1 раз = person censorship
            if 'invalid argument' in err_lower_ex:
                prominent_person = True
                logging.warning(f"Clip #{clip_id} {tag} [{phase_label}]: 'invalid argument' (Exception path) — treating as person censorship")
                print(f"\n  {_RED}[INVALID ARG → PERSON?]{_RESET} #{clip_id} {tag}: 'invalid argument' — likely person name, will rewrite")
                break
            logging.error(f"Clip #{clip_id} {tag} [{phase_label}] attempt {attempt}/{max_retries}: {e}")
            print(f"\n  {_YELLOW}[ERROR]{_RESET}   #{clip_id} {tag} [{phase_label}] {attempt}/{max_retries}: {e}")
            if attempt < max_retries:
                delay = min(10 * attempt, 60)
                time.sleep(delay)

    return {
        'ok': False,
        'elapsed': round(retry_time, 1),
        'retries': attempt,
        'retry_time': round(retry_time, 1),
        'error_counts': error_counts,
        'error': last_error,
        'censored': censored,
        'prominent_person': prominent_person,
    }


def _kieai_image_remix(image_path: str, clip_id: int, output_dir: Path) -> Optional[str]:
    """
    Ремикс изображения через настроенный движок (Grok или Kie.ai).
    Используется когда VeoNonStop цензурирует клип — проблема в изображении.
    Промпт берётся из i2v_remix_prompt.txt.

    Результат сохраняется в project/remixed/ (не в vid_img/) — остаётся навсегда
    чтобы пользователь мог просмотреть ремиксы.

    Returns:
        Путь к ремикснутому изображению или None при ошибке.
    """
    import config as _cfg
    _engine = _cfg.REMIX_ENGINE.upper()
    try:
        remixed_dir = output_dir.parent / 'remixed'
        remixed_dir.mkdir(exist_ok=True)
        remix_path = remixed_dir / f"{clip_id:03d}_kieai_remix.png"
        log_path = str(output_dir.parent / 'remix_debug.log')
        remix_i2v(image_path, str(remix_path), log_path=log_path)
        logging.info(f"Clip #{clip_id}: {_engine} i2v remix saved -> remixed/{remix_path.name}")
        return str(remix_path)
    except Exception as e:
        logging.warning(f"Clip #{clip_id}: {_engine} i2v remix failed — {e}")
        return None


def _process_single_clip(
    client,   # VeoNonStopClient or None (None when clients_cfg_list provided)
    clip_id: int,
    prompt: str,
    mode: str,
    image_path: Optional[str],
    ref_dir: Optional[str],
    output_dir: Path,
    aspect_ratio: Optional[str] = None,
    max_retries: int = None,
    worker_id_fn=None,
    single_prompt_mode: bool = False,
    end_image_path: Optional[str] = None,
    submit_sem=None,
    clients_cfg_list=None,  # if provided: worker-assignment — client/sem/stagger by worker_id
    ok_run: Optional[dict] = None,  # shared thread-safe stats for running avg: {'n':0,'total':0.0,'lock':Lock}
) -> Dict[str, Any]:
    """
    Генерация одного видеоклипа с двухфазной логикой:

    Фаза 1: до max_retries попыток с оригинальным промптом.
    При цензуре/известной личности → rewrite промпта через FastGen Prompt API.
    Фаза 2: до max_retries попыток с переписанным промптом.

    Returns:
        {'id': int, 'status': 'ok'|'error'|'censored', 'file': str|None,
         'error': str|None, 'duration_sec': float, 'task_id': str|None,
         'rewritten': bool, 'phase': int,
         'worker_id': int, 'retries': int, 'retry_time': float,
         'error_counts': dict}
    """
    if max_retries is None:
        max_retries = config.VEONONSTOP_MAX_RETRIES
    # worker_id определяется ВНУТРИ воркера (в потоке ThreadPool)
    worker_id = worker_id_fn() if worker_id_fn else 0
    clip_start_time = datetime.now().strftime('%H:%M:%S')
    clip_start_ts = time.time()
    tag = f"[W{worker_id}]"

    result = {
        'id': clip_id,
        'status': 'error',
        'file': None,
        'error': None,
        'duration_sec': 0,
        'task_id': None,
        'rewritten': False,
        'phase': 1,
        'worker_id': worker_id,
        'key_label': 'Key1',
        'retries': 0,
        'retry_time': 0.0,
        'error_counts': {},
        'upload_sec': 0.0,
        'gen_sec': 0.0,
        'dl_sec': 0.0,
        'media_generation_id': None,
    }

    output_path = output_dir / f"{clip_id:03d}.mp4"

    # ── Проверка shutdown ─────────────────────────────────────────────
    if _shutdown_requested.is_set():
        result['status'] = 'error'
        result['error'] = 'shutdown requested'
        return result

    # ── Worker-assignment: определяем client/sem по worker_id (если dual-key) ──
    _key_label = 'Key1'
    if clients_cfg_list:
        cumulative = 0
        _selected_cfg = clients_cfg_list[-1]
        _group_start = 0
        for _cfg in clients_cfg_list:
            if worker_id < cumulative + _cfg['mp']:
                _selected_cfg = _cfg
                _group_start = cumulative
                break
            cumulative += _cfg['mp']
        client = _selected_cfg['client']
        submit_sem = _selected_cfg['sem']
        _key_label = _selected_cfg['label']
        _local_worker_id = worker_id - _group_start
    else:
        _local_worker_id = worker_id

    # Обновляем result['key_label'] после определения ключа
    result['key_label'] = _key_label

    # ── Stagger: только при ПЕРВОМ запуске воркера (разброс старта первой волны) ──
    # При dual-key — stagger по локальному ID внутри группы (обе группы стартуют параллельно)
    tag = f"[W{worker_id}/{_key_label}]"
    with _started_workers_lock:
        is_first_run = worker_id not in _started_workers
        _started_workers.add(worker_id)
    if is_first_run:
        stagger = _local_worker_id * config.VEONONSTOP_REQUEST_DELAY
    else:
        stagger = 1.0
    jitter = random.uniform(0.5, 1.5)
    total_delay = stagger + jitter
    logging.info(f"Clip #{clip_id} {tag}: stagger {stagger}s + jitter {jitter:.1f}s (first={is_first_run})")
    print(f"  {_YELLOW}[START]{_RESET}  #{clip_id} {tag}: launching in {total_delay:.1f}s...")
    time.sleep(total_delay)

    # ── Фаза 1: оригинальный промпт ──────────────────────────────────
    try:
        phase1 = _run_phase(
            client, clip_id, prompt, mode, image_path, ref_dir,
            output_path, aspect_ratio, max_retries, 'phase1',
            worker_id=worker_id, clip_start_time=clip_start_time,
            end_image_path=end_image_path,
            submit_sem=submit_sem,
            key_label=_key_label,
        )
    except ShutdownRequested:
        result['status'] = 'error'
        result['error'] = 'shutdown requested'
        result['duration_sec'] = round(time.time() - clip_start_ts, 1)
        logging.info(f"Clip #{clip_id} {tag}: shutdown during phase1")
        return result

    if phase1['ok']:
        elapsed = phase1['elapsed']
        t_up = phase1.get('upload_sec', 0.0)
        t_gen = phase1.get('gen_sec', 0.0)
        t_dl = phase1.get('dl_sec', 0.0)
        retries = phase1['retries']
        retry_time = phase1['retry_time']
        error_counts = phase1['error_counts']
        result.update({
            'status': 'ok', 'file': str(output_path),
            'duration_sec': elapsed, 'task_id': phase1['task_id'], 'phase': 1,
            'retries': retries, 'retry_time': retry_time, 'error_counts': error_counts,
            'upload_sec': t_up, 'gen_sec': t_gen, 'dl_sec': t_dl,
            'media_generation_id': phase1.get('media_generation_id'),
        })
        # Формат лога по LOGGING_REQUIREMENTS
        log_line = f"Clip #{clip_id} {tag}: OK phase1 (total={elapsed}s | upload={t_up}s | gen={t_gen}s | dl={t_dl}s"
        if retries > 0:
            log_line += f" | retries={retries} retry_time={retry_time}s errors={error_counts}"
        log_line += ")"
        print(f"  {_GREEN}[OK]{_RESET} {log_line}")
        logging.info(log_line)
        if ok_run is not None:
            with ok_run['lock']:
                ok_run['n'] += 1
                ok_run['total'] += elapsed
                _avg = ok_run['total'] / ok_run['n']
                _n   = ok_run['n']
            _wall = time.time() - ok_run['wall_start']
            _wall_cpm = _n / (_wall / 60) if _wall > 0 else 0
            _wall_spc = 60.0 / _wall_cpm if _wall_cpm > 0 else 0
            print(f"  {_CYAN}[SPEED]{_RESET} worker avg={_avg:.0f}s/clip  |  pool {_wall_spc:.1f}s/clip ({_wall_cpm:.1f} clip/min)")
        return result

    # ── Rewrite промпта только при цензуре / публичной личности ──────
    is_person = phase1.get('prominent_person', False)
    is_censored = phase1.get('censored', False)

    # Обычная техническая ошибка — rewrite не поможет, сразу error
    if not is_person and not is_censored:
        elapsed = round(time.time() - clip_start_ts, 1)
        retries = phase1['retries']
        retry_time = phase1['retry_time']
        error_counts = phase1['error_counts']
        result.update({
            'status': 'error', 'error': phase1.get('error'),
            'duration_sec': elapsed,
            'retries': retries, 'retry_time': retry_time, 'error_counts': error_counts,
        })
        log_line = f"Clip #{clip_id} {tag}: FAILED phase1 ({elapsed}s gen time) retries={retries} retry_time={retry_time}s errors={error_counts}: {phase1.get('error', '')[:100]}"
        logging.error(log_line)
        print(f"  {_YELLOW}[FAILED]{_RESET} {log_line}")
        return result

    # ── Phase 2: multi-cycle retry (Kie.ai remix + prompt rewrite) ──────────

    result['phase'] = 2
    combined_errors: Dict[str, int] = {}
    for k, v in phase1.get('error_counts', {}).items():
        combined_errors[k] = combined_errors.get(k, 0) + v
    total_retries = phase1.get('retries', 0)
    total_retry_time = phase1.get('retry_time', 0.0)

    _MINIMALISTIC_PROMPT = (
        "Animate a frame in a very minimalistic way without changing the logic of the scene."
    )

    def _accumulate(ph: dict) -> None:
        nonlocal total_retries, total_retry_time
        for k, v in ph.get('error_counts', {}).items():
            combined_errors[k] = combined_errors.get(k, 0) + v
        total_retries += ph.get('retries', 0)
        total_retry_time += ph.get('retry_time', 0.0)

    def _ok_return(phase_result: dict, suffix: str = '') -> dict:
        elapsed = round(time.time() - clip_start_ts, 1)
        t_up = phase_result.get('upload_sec', 0.0)
        t_gen = phase_result.get('gen_sec', 0.0)
        t_dl  = phase_result.get('dl_sec', 0.0)
        result.update({
            'status': 'ok', 'file': str(output_path),
            'duration_sec': elapsed, 'task_id': phase_result['task_id'], 'phase': 2,
            'retries': total_retries, 'retry_time': round(total_retry_time, 1),
            'error_counts': combined_errors,
            'upload_sec': t_up, 'gen_sec': t_gen, 'dl_sec': t_dl,
            'media_generation_id': phase_result.get('media_generation_id'),
        })
        log_line = (
            f"Clip #{clip_id} {tag}: OK phase2 (total={elapsed}s | "
            f"upload={t_up}s | gen={t_gen}s | dl={t_dl}s{suffix}"
        )
        if total_retries > 0:
            log_line += f" | retries={total_retries} retry_time={round(total_retry_time,1)}s errors={combined_errors}"
        log_line += ")"
        print(f"  {_GREEN}[OK]{_RESET} {log_line}")
        logging.info(log_line)
        if ok_run is not None:
            with ok_run['lock']:
                ok_run['n'] += 1
                ok_run['total'] += elapsed
                _avg = ok_run['total'] / ok_run['n']
                _n   = ok_run['n']
            _wall = time.time() - ok_run['wall_start']
            _wall_cpm = _n / (_wall / 60) if _wall > 0 else 0
            _wall_spc = 60.0 / _wall_cpm if _wall_cpm > 0 else 0
            print(f"  {_CYAN}[SPEED]{_RESET} worker avg={_avg:.0f}s/clip  |  pool {_wall_spc:.1f}s/clip ({_wall_cpm:.1f} clip/min)")
        return result

    def _static_fallback() -> dict:
        """Статический фелбек: для i2v копирует оригинал, для t2v генерит картинку через Banana."""
        if image_path is None:
            # T2V: нет картинки — генерируем через Banana и кладём в vid_img/
            dest = output_dir / f"{clip_id:03d}.jpg"
            try:
                client.generate_banana(prompt, str(dest), aspect_ratio=aspect_ratio)
                elapsed = round(time.time() - clip_start_ts, 1)
                log_line = f"Clip #{clip_id} {tag}: T2V STATIC FALLBACK — banana image generated -> vid_img/ ({elapsed}s)"
                print(f"  {_YELLOW}[STATIC T2V]{_RESET} {log_line}")
                logging.warning(log_line)
                result.update({
                    'status': 'ok', 'file': str(dest),
                    'duration_sec': elapsed, 'task_id': None, 'phase': 2,
                    'retries': total_retries, 'retry_time': round(total_retry_time, 1),
                    'error_counts': combined_errors,
                })
            except Exception as _fe:
                logging.error(f"Clip #{clip_id}: T2V static fallback (banana) failed ({_fe})")
                elapsed = round(time.time() - clip_start_ts, 1)
                result.update({
                    'status': 'error', 'error': f't2v static fallback failed: {_fe}',
                    'duration_sec': elapsed, 'retries': total_retries,
                    'retry_time': round(total_retry_time, 1), 'error_counts': combined_errors,
                })
            return result

        # i2v / components: копируем оригинальную картинку
        ext = Path(image_path).suffix
        dest = output_dir / f"{clip_id:03d}{ext}"
        try:
            shutil.copy(image_path, str(dest))
            elapsed = round(time.time() - clip_start_ts, 1)
            log_line = f"Clip #{clip_id} {tag}: STATIC FALLBACK — copied original image to vid_img/ ({elapsed}s)"
            print(f"  {_YELLOW}[STATIC]{_RESET} {log_line}")
            logging.warning(log_line)
            result.update({
                'status': 'ok', 'file': str(dest),
                'duration_sec': elapsed, 'task_id': None, 'phase': 2,
                'retries': total_retries, 'retry_time': round(total_retry_time, 1),
                'error_counts': combined_errors,
            })
        except Exception as _fe:
            logging.error(f"Clip #{clip_id}: static fallback copy failed ({_fe})")
            elapsed = round(time.time() - clip_start_ts, 1)
            result.update({
                'status': 'error', 'error': f'static fallback failed: {_fe}',
                'duration_sec': elapsed, 'retries': total_retries,
                'retry_time': round(total_retry_time, 1), 'error_counts': combined_errors,
            })
        return result

    def _phase2_attempt(use_prompt: str, use_image: Optional[str], label: str,
                        override_ref_dir: Optional[str] = None) -> dict:
        effective_rd = override_ref_dir if override_ref_dir is not None else ref_dir
        return _run_phase(
            client, clip_id, use_prompt, mode, use_image, effective_rd,
            output_path, aspect_ratio, max_retries, label,
            worker_id=worker_id, clip_start_time=clip_start_time,
            end_image_path=end_image_path,
            submit_sem=submit_sem,
            key_label=_key_label,
        )

    def _binary_search_blocked_refs(ref_files: list) -> list:
        """
        Бинарный поиск блокирующих рефов через VeoNonStop.
        Возвращает список Path-объектов заблокированных рефов.
        Каждый тест — реальный VeoNonStop-вызов (последний резерв после 5 реврайтов).
        """
        import tempfile
        import shutil as _shutil
        if not ref_files:
            return []
        if len(ref_files) == 1:
            tmp = tempfile.mkdtemp(prefix=f'veo_bs_{clip_id}_')
            try:
                _shutil.copy2(str(ref_files[0]), tmp)
                _ph = _phase2_attempt(prompt, None, f'bsearch_{ref_files[0].stem}',
                                      override_ref_dir=tmp)
                _accumulate(_ph)
                return [ref_files[0]] if _ph.get('censored') else []
            except ShutdownRequested:
                raise
            except Exception as _e:
                logging.warning(f"Clip #{clip_id}: bsearch test failed for {ref_files[0].name}: {_e}")
                return []
            finally:
                _shutil.rmtree(tmp, ignore_errors=True)
        mid = len(ref_files) // 2
        bad: list = []
        for half, lbl in ((ref_files[:mid], 'L'), (ref_files[mid:], 'R')):
            tmp = tempfile.mkdtemp(prefix=f'veo_bs_{clip_id}_')
            try:
                for f in half:
                    _shutil.copy2(str(f), tmp)
                _ph = _phase2_attempt(prompt, None, f'bsearch_{lbl}', override_ref_dir=tmp)
                _accumulate(_ph)
                if _ph.get('censored'):
                    bad.extend(_binary_search_blocked_refs(half))
            except ShutdownRequested:
                raise
            except Exception as _e:
                logging.warning(f"Clip #{clip_id}: bsearch half {lbl} failed: {_e}")
            finally:
                _shutil.rmtree(tmp, ignore_errors=True)
        return bad

    # ── FAST_CENSOR: ultrafast → сразу static fallback ──
    _fast_censor = config.VEONONSTOP_FAST_CENSOR
    if _fast_censor == 'ultrafast':
        logging.info(f"Clip #{clip_id} {tag}: FAST_CENSOR=ultrafast — skipping chain, static fallback")
        print(f"  {_YELLOW}[ULTRAFAST]{_RESET} #{clip_id} {tag}: skipping rewrite/remix chain → static fallback")
        return _static_fallback()

    # ── Single-prompt + i2v: проблема в изображении → 3 цикла Kie.ai remix ──
    if single_prompt_mode and mode == 'i2v' and image_path:
        _remix_engine_label = config.REMIX_ENGINE.upper()
        for _remix_n in range(1, 4):
            print(f"  {_RED}[IMG REMIX #{_remix_n}/3]{_RESET} #{clip_id} {tag}: remixing image via {_remix_engine_label}...")
            logging.info(f"Clip #{clip_id} {tag}: single-prompt i2v censorship — {_remix_engine_label} remix cycle {_remix_n}/3")
            _remixed = _kieai_image_remix(image_path, clip_id, output_dir)
            _use_img = _remixed if _remixed else image_path
            try:
                _ph = _phase2_attempt(prompt, _use_img, f'phase2_remix{_remix_n}')
            except ShutdownRequested:
                result['status'] = 'error'
                result['error'] = 'shutdown requested'
                result['duration_sec'] = round(time.time() - clip_start_ts, 1)
                logging.info(f"Clip #{clip_id} {tag}: shutdown during phase2 remix {_remix_n}")
                return result
            _accumulate(_ph)
            result['rewritten'] = True
            if _ph['ok']:
                return _ok_return(_ph, f' (img remix #{_remix_n})')
            # Любой результат (цензура или техн. ошибка) — переходим к следующему ремиксу
        # Все 3 ремикса не помогли — статический кадр-фелбек.
        return _static_fallback()

    # ── Per-clip промпт режим: 2 реврайта → 2 ремикса → минималистик → статик ──
    else:
        # Шаг 1-2: Gemini реврайты (2 шт.)
        for _rw_n in range(1, 3):
            _lbl = 'PERSON REWRITE' if is_person else 'REWRITE'
            print(f"  {_RED}[{_lbl} #{_rw_n}/2]{_RESET} #{clip_id} {tag}: rewriting prompt...")
            logging.info(f"Clip #{clip_id} {tag}: prompt rewrite #{_rw_n}/2 (for_person={is_person})")
            try:
                _rw_prompt = _gemini_rewrite(prompt, for_person=is_person)
            except Exception as _e:
                logging.warning(f"Clip #{clip_id} {tag}: rewrite #{_rw_n} failed ({_e}), using original")
                _rw_prompt = prompt
            _use_prompt = _rw_prompt if (_rw_prompt and _rw_prompt != prompt) else prompt
            try:
                _ph = _phase2_attempt(_use_prompt, image_path, f'phase2_rw{_rw_n}')
            except ShutdownRequested:
                result['status'] = 'error'
                result['error'] = 'shutdown requested'
                result['duration_sec'] = round(time.time() - clip_start_ts, 1)
                logging.info(f"Clip #{clip_id} {tag}: shutdown during phase2 rewrite {_rw_n}")
                return result
            _accumulate(_ph)
            result['rewritten'] = True
            if _ph['ok']:
                return _ok_return(_ph, f' (rewrite #{_rw_n})')
            # Любой результат (цензура или техн. ошибка) — переходим к следующему шагу

        # FAST_CENSOR: after_rewrites → static fallback после реврайтов
        if _fast_censor == 'after_rewrites':
            logging.info(f"Clip #{clip_id} {tag}: FAST_CENSOR=after_rewrites — skipping remixes, static fallback")
            print(f"  {_YELLOW}[FAST CENSOR]{_RESET} #{clip_id} {tag}: after_rewrites — skipping remixes → static fallback")
            return _static_fallback()

        # Шаг 3-4: Kie.ai/Grok ремиксы (2 шт.) — только для i2v с картинкой
        if mode == 'i2v' and image_path:
            _remix_engine_label = config.REMIX_ENGINE.upper()
            for _remix_n in range(1, 3):
                print(f"  {_RED}[IMG REMIX #{_remix_n}/2]{_RESET} #{clip_id} {tag}: remixing original image via {_remix_engine_label}...")
                logging.info(f"Clip #{clip_id} {tag}: post-rewrite {_remix_engine_label} remix cycle {_remix_n}/2")
                _remixed = _kieai_image_remix(image_path, clip_id, output_dir)
                _use_img = _remixed if _remixed else image_path
                try:
                    _ph = _phase2_attempt(prompt, _use_img, f'phase2_remix{_remix_n}')
                except ShutdownRequested:
                    result['status'] = 'error'
                    result['error'] = 'shutdown requested'
                    result['duration_sec'] = round(time.time() - clip_start_ts, 1)
                    return result
                _accumulate(_ph)
                if _ph['ok']:
                    return _ok_return(_ph, f' (img remix #{_remix_n})')
                # Любой результат — переходим к следующему шагу

            # Шаг 5: Минималистик + ремикс
            print(f"  {_RED}[MINIMALISTIC]{_RESET} #{clip_id} {tag}: final attempt with minimalistic prompt + {config.REMIX_ENGINE.upper()} remix...")
            logging.info(f"Clip #{clip_id} {tag}: minimalistic final attempt")
            _remixed = _kieai_image_remix(image_path, clip_id, output_dir)
            _use_img = _remixed if _remixed else image_path
            try:
                _ph = _phase2_attempt(_MINIMALISTIC_PROMPT, _use_img, 'phase2_minimalistic')
            except ShutdownRequested:
                result['status'] = 'error'
                result['error'] = 'shutdown requested'
                result['duration_sec'] = round(time.time() - clip_start_ts, 1)
                return result
            _accumulate(_ph)
            if _ph['ok']:
                return _ok_return(_ph, ' (minimalistic)')

        # Components mode: бинарный поиск блокирующего рефа вместо ремиксов
        if mode == 'components' and ref_dir:
            print(f"  {_RED}[COMPONENTS BSEARCH]{_RESET} #{clip_id} {tag}: rewrites exhausted — searching for blocked ref...")
            logging.info(f"Clip #{clip_id} {tag}: components — binary searching for blocked refs in {ref_dir}")
            ref_path = Path(ref_dir)
            _ref_files = sorted(
                [f for f in ref_path.iterdir()
                 if f.is_file() and f.suffix.lower() in IMAGE_EXTENSIONS],
                key=lambda p: p.name.lower()
            )
            try:
                _bad_refs = _binary_search_blocked_refs(_ref_files)
            except ShutdownRequested:
                result['status'] = 'error'
                result['error'] = 'shutdown requested'
                result['duration_sec'] = round(time.time() - clip_start_ts, 1)
                return result
            if _bad_refs:
                _bad_names = [f.name for f in _bad_refs]
                print(f"  {_RED}[BSEARCH]{_RESET} #{clip_id} {tag}: blocking refs: {_bad_names} — remixing in-place...")
                logging.warning(f"Clip #{clip_id} {tag}: blocking refs found: {_bad_names}")
                for _bad_f in _bad_refs:
                    try:
                        remix_ref(str(_bad_f), str(_bad_f))
                        logging.info(f"Clip #{clip_id}: kieai remixed {_bad_f.name} in-place")
                    except Exception as _rem_err:
                        logging.error(f"Clip #{clip_id}: kieai remix failed for {_bad_f.name}: {_rem_err}")
                        print(f"  {_RED}[BSEARCH]{_RESET} #{clip_id}: remix failed for {_bad_f.name}: {_rem_err}")
                print(f"  {_YELLOW}[COMPONENTS RETRY]{_RESET} #{clip_id} {tag}: retrying with remixed refs...")
                logging.info(f"Clip #{clip_id} {tag}: retrying components after ref remix")
                try:
                    _ph = _phase2_attempt(prompt, None, 'phase2_comp_postremix')
                except ShutdownRequested:
                    result['status'] = 'error'
                    result['error'] = 'shutdown requested'
                    result['duration_sec'] = round(time.time() - clip_start_ts, 1)
                    return result
                _accumulate(_ph)
                if _ph['ok']:
                    return _ok_return(_ph, ' (components ref remix)')
            else:
                print(f"  {_YELLOW}[BSEARCH]{_RESET} #{clip_id} {tag}: no blocking refs isolated — cannot recover")
                logging.warning(f"Clip #{clip_id} {tag}: binary search found no blocking refs")

        # Шаг 6: static fallback — цепочка исчерпана
        return _static_fallback()


# ======================================================================
# Основная функция: batch-генерация видео
# ======================================================================

def generate_all_videos(
    project_dir: str,
    mode: str = 'i2v',
    max_parallel: Optional[int] = None,
    clip_ids: Optional[List[int]] = None,
    single_prompt: Optional[str] = None,
    aspect_ratio: Optional[str] = None,
    ref_dir: Optional[str] = None,
    silent: bool = False,
    no_cancel: bool = False,
    active_keys: Optional[List[int]] = None,
    upscale_video: bool = False,
) -> Dict[str, Any]:
    """
    Batch-генерация видеоклипов через VeoNonStop.

    Args:
        project_dir:    Путь к папке проекта
        mode:           'i2v' | 't2v' | 'components' | 'batch_frame'
        max_parallel:   Макс. параллельных задач (из config если None)
        clip_ids:       Список ID клипов (если None — все из montage_plan)
        single_prompt:  Один промпт на все клипы (если None — per-clip из prompts.txt)
        aspect_ratio:   Соотношение сторон
        ref_dir:        Папка с референсами (для components). Если None — PROJECT/ref/
        silent:         Авто-режим (без интерактивных вопросов):
                        до 5 авто-циклов ретрая упавших клипов
        active_keys:    Список 1-based индексов ключей [1], [1,2], [1,2,3,4] и т.д.

    Returns:
        Сводка генерации
    """
    project_path = Path(project_dir)
    max_parallel = max_parallel or config.VEONONSTOP_MAX_PARALLEL

    _KEY_DEFS = [
        (config.VEONONSTOP_API_KEY,   config.VEONONSTOP_MAX_PARALLEL,   config.VEONONSTOP_KEY1_NAME or 'Key1'),
        (config.VEONONSTOP_API_KEY_2, config.VEONONSTOP_MAX_PARALLEL_2, config.VEONONSTOP_KEY2_NAME or 'Key2'),
        (config.VEONONSTOP_API_KEY_3, config.VEONONSTOP_MAX_PARALLEL_3, config.VEONONSTOP_KEY3_NAME or 'Key3'),
        (config.VEONONSTOP_API_KEY_4, config.VEONONSTOP_MAX_PARALLEL_4, config.VEONONSTOP_KEY4_NAME or 'Key4'),
    ]
    _active_keys = active_keys if active_keys else [1]

    # Подавить DEBUG-спам от urllib3/requests
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    logging.getLogger('requests').setLevel(logging.WARNING)

    # Лог-файл
    log_ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    gen_log_path = project_path / f'veo_video_{log_ts}.log'
    file_handler = logging.FileHandler(str(gen_log_path), encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(logging.Formatter('%(asctime)s | %(levelname)-8s | %(message)s'))
    logging.getLogger().addHandler(file_handler)
    logging.info(f"=== VeoNonStop img2video started for {project_path.name} (mode={mode}) ===")

    print("\n" + "=" * 60)
    print(f"  IMG2VIDEO: VeoNonStop ({mode.upper()})")
    print("=" * 60)
    print(f"  Log: {gen_log_path}")

    # ------------------------------------------------------------------
    # 1. Чтение montage_plan.json (определяет список clip_id)
    # ------------------------------------------------------------------
    montage_plan_path = project_path / 'montage_plan.json'
    if not montage_plan_path.exists():
        raise FileNotFoundError(f"montage_plan.json not found in {project_path}")

    with open(montage_plan_path, 'r', encoding='utf-8') as f:
        montage_data = json.load(f)

    # Handle both {"montage_plan": {"clips": [...]}} and {"clips": [...]}
    if 'montage_plan' in montage_data:
        montage_plan = montage_data['montage_plan']
    else:
        montage_plan = montage_data

    clips = montage_plan.get('clips', [])
    all_clip_ids = [c['id'] for c in clips]

    if clip_ids:
        all_clip_ids = [cid for cid in all_clip_ids if cid in clip_ids]

    print(f"  Total clips: {len(all_clip_ids)}")

    # ------------------------------------------------------------------
    # 2. Чтение промптов
    # ------------------------------------------------------------------
    prompts_map: Dict[int, str] = {}

    if single_prompt:
        if single_prompt == 'default':
            # Взять первый промпт из prompts.txt для всех клипов
            prompts_file = find_prompts_file(str(project_path))
            if not prompts_file:
                raise FileNotFoundError(
                    f"Prompts file not found in {project_path} "
                    f"(expected *_prompts_*.txt)"
                )
            all_prompts = extract_all_prompts(prompts_file)
            if all_prompts:
                first_prompt = list(all_prompts.values())[0]
                for cid in all_clip_ids:
                    prompts_map[cid] = first_prompt
                print(f"  Prompt mode: single prompt (first from {Path(prompts_file).name}) for all clips")
                logging.info(f"Prompts file: {prompts_file}")
            else:
                raise ValueError("No prompts found in prompts.txt")
        else:
            # Один промпт на все (передан явно)
            for cid in all_clip_ids:
                prompts_map[cid] = single_prompt
            print(f"  Prompt mode: single prompt for all clips")
    else:
        # Per-clip из prompts.txt
        prompts_file = find_prompts_file(str(project_path))
        if not prompts_file:
            raise FileNotFoundError(
                f"Prompts file not found in {project_path} "
                f"(expected *_prompts_*.txt)"
            )
        all_prompts = extract_all_prompts(prompts_file)
        for cid in all_clip_ids:
            if cid in all_prompts:
                prompts_map[cid] = all_prompts[cid]
            else:
                logging.warning(f"Clip #{cid}: no prompt found, skipping")
        print(f"  Prompt mode: per-clip from {Path(prompts_file).name}")
        print(f"  Prompts loaded: {len(prompts_map)}")
        logging.info(f"Prompts file: {prompts_file}")

    if not prompts_map:
        raise ValueError("No prompts available for generation")

    # ------------------------------------------------------------------
    # 3. Подготовка путей
    # ------------------------------------------------------------------
    output_dir = project_path / 'vid_img'
    output_dir.mkdir(exist_ok=True)

    generated_dir = project_path / 'generated'
    effective_ref_dir = ref_dir or str(project_path / 'ref')

    # Пропуск уже готовых
    skipped = []
    pending_ids = []
    for cid in sorted(prompts_map.keys()):
        mp4_path = output_dir / f"{cid:03d}.mp4"
        if mp4_path.exists() and mp4_path.stat().st_size > 1000:
            skipped.append(cid)
        else:
            pending_ids.append(cid)

    if skipped:
        print(f"  Skipped (already exist): {len(skipped)}")
    print(f"  To generate: {len(pending_ids)}")

    if not pending_ids:
        print("  All videos already exist. Nothing to generate.")
        return {'generated': len(skipped), 'failed': 0, 'results': []}

    # Проверка generated/ для i2v и batch_frame
    def _find_image(cid: int) -> Optional[str]:
        for ext in ('.png', '.jpg', '.jpeg', '.webp'):
            p = generated_dir / f"{cid:03d}{ext}"
            if p.exists():
                return str(p)
        return None

    if mode in ('i2v', 'batch_frame'):
        missing_images = [cid for cid in pending_ids if not _find_image(cid)]
        if missing_images:
            print(f"\n  {_RED}WARNING:{_RESET} {len(missing_images)} images missing in generated/:")
            print(f"  IDs: {', '.join(map(str, missing_images[:20]))}")
            print(f"  These clips will be skipped in {mode} mode.")
            pending_ids = [cid for cid in pending_ids if cid not in missing_images]

    # Для batch_frame: строим карту end_image (клип N → изображение клипа N+1)
    end_image_map: Dict[int, str] = {}
    if mode == 'batch_frame':
        ordered = sorted(pending_ids)
        for i, cid in enumerate(ordered):
            next_cid = ordered[i + 1] if i + 1 < len(ordered) else cid
            img = _find_image(next_cid) or _find_image(cid)
            if img:
                end_image_map[cid] = img
        print(f"  Batch-frame pairs built: {len(end_image_map)}")

    # Проверка ref/ для components
    if mode == 'components':
        ref_path = Path(effective_ref_dir)
        if not ref_path.exists() or not any(
            f.suffix.lower() in IMAGE_EXTENSIONS
            for f in ref_path.iterdir() if f.is_file()
        ):
            raise FileNotFoundError(
                f"No reference images found in {effective_ref_dir}. "
                f"Components mode requires ref/ folder with images."
            )
        ref_count = sum(1 for f in ref_path.iterdir()
                        if f.is_file() and f.suffix.lower() in IMAGE_EXTENSIONS)
        print(f"  References: {ref_count} images in {ref_path}")

        # ── Предполётная проверка рефов через VeoNonStop Banana Pro ──
        _skip_pf = os.environ.get('VARAGENT_SKIP_PREFLIGHT', '0') == '1'
        if _skip_pf:
            print(f"  [PREFLIGHT] Skipped (user disabled)")
            logging.info("PREFLIGHT components: skipped by user (VARAGENT_SKIP_PREFLIGHT=1)")
        elif config.FASTGEN_PREFLIGHT_REFS and config.REMIX_AVAILABLE:
            import tempfile, os as _os
            print(f"  [PREFLIGHT] Testing components refs via VeoNonStop Banana...")
            logging.info("PREFLIGHT components: testing refs via VeoNonStop Banana")
            try:
                _pf_client = VeoNonStopClient(api_key=_KEY_DEFS[_active_keys[0] - 1][0])
                _pf_aspect = config.VEONONSTOP_ASPECT_RATIO
                _pf_refs = _load_ref_images(effective_ref_dir)
                _pf_test_num = [0]

                _PF_NET_KW = ['connection', 'reset', 'aborted', 'timeout', 'refused', 'network', 'socket',
                             '503', '502', '429', '500', 'service unavailable', 'bad gateway',
                             'too many requests', 'internal server error']
                _CENS_KW = ['invalid argument', 'safety', 'blocked', 'censored',
                            'harmful', 'policy', 'prohibited', 'violat',
                            'prominent person', 'dangerous', 'inappropriate']

                def _pf_is_cens(s):
                    lo = s.lower()
                    return any(k in lo for k in _CENS_KW)

                def _pf_is_net(s):
                    lo = s.lower()
                    return any(k in lo for k in _PF_NET_KW)

                _pf_last_fail_reason = [None]  # 'network' | 'censorship' | 'unknown'

                def _pf_banana_ok(refs_subset, label='', _retries=3):
                    if not refs_subset:
                        return True
                    _pf_test_num[0] += 1
                    tag = f"[{_pf_test_num[0]}]" if not label else f"[{_pf_test_num[0]}] {label}"
                    desc = f"  [PREFLIGHT] {tag} {len(refs_subset)} ref(s)"
                    for attempt in range(1, _retries + 2):
                        _exc: list = [None]
                        _t0 = [time.time()]
                        try:
                            with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmp:
                                tmp_path = tmp.name
                        except Exception:
                            return True

                        def _run():
                            try:
                                _pf_client.generate_banana(
                                    "abstract cinematic background, no people",
                                    output_path=tmp_path,
                                    aspect_ratio=_pf_aspect,
                                    reference_images=refs_subset,
                                )
                            except Exception as e:
                                _exc[0] = e
                            finally:
                                if _os.path.exists(tmp_path):
                                    try:
                                        _os.unlink(tmp_path)
                                    except Exception:
                                        pass

                        retry_label = desc if attempt == 1 else f"{desc} [retry {attempt-1}/{_retries}]"
                        t = threading.Thread(target=_run, daemon=True)
                        t.start()
                        with tqdm(total=150, desc=retry_label, unit="s",
                                  bar_format="{desc}: {bar}| {n:.0f}/{total}s", leave=False) as pbar:
                            while t.is_alive():
                                time.sleep(1)
                                pbar.update(1)
                        t.join()
                        elapsed = int(time.time() - _t0[0])
                        if _exc[0] is None:
                            names = ', '.join(r.get('name', '?') for r in refs_subset)
                            print(f"  {_GREEN}[PREFLIGHT]{_RESET} {tag} {len(refs_subset)} ref(s): {names} -> OK ({elapsed}s)", flush=True)
                            logging.info(f"PREFLIGHT components [{tag}]: OK")
                            return True
                        err_str = str(_exc[0])
                        if _pf_is_cens(err_str):
                            names = ', '.join(r.get('name', '?') for r in refs_subset)
                            print(f"  {_RED}[PREFLIGHT]{_RESET} {tag} {len(refs_subset)} ref(s): {names} -> BLOCKED ({elapsed}s)", flush=True)
                            logging.warning(f"PREFLIGHT components [{tag}]: BLOCKED — {_exc[0]}")
                            _pf_last_fail_reason[0] = 'censorship'
                            return False
                        if _pf_is_net(err_str) and attempt <= _retries:
                            wait = 15 * attempt
                            print(f"  {_YELLOW}[PREFLIGHT]{_RESET} {tag}: network error (attempt {attempt}) — {err_str[:80]}", flush=True)
                            time.sleep(wait)
                            continue
                        print(f"  {_RED}[PREFLIGHT]{_RESET} {tag}: error ({elapsed}s): {err_str[:120]}", flush=True)
                        logging.error(f"PREFLIGHT components [{tag}]: unrecognized error — {_exc[0]}")
                        _pf_last_fail_reason[0] = 'unknown'
                        return False
                    # all retries exhausted on network errors
                    print(f"  {_RED}[PREFLIGHT]{_RESET} {tag}: API unreachable after {_retries} retries", flush=True)
                    logging.error(f"PREFLIGHT components [{tag}]: API unreachable after {_retries} retries")
                    _pf_last_fail_reason[0] = 'network'
                    return False

                _pf_all_ok = _pf_banana_ok(_pf_refs, label='ALL') if _pf_refs else True
                if not _pf_all_ok and _pf_last_fail_reason[0] in ('network', 'unknown'):
                    # Banana API is down but components uses VeoNonStop — skip preflight, try anyway
                    print(f"  {_YELLOW}[PREFLIGHT]{_RESET} Banana API unavailable — skipping preflight (components uses VeoNonStop, not Banana)")
                    logging.warning("PREFLIGHT components: Banana API down, skipping — components will try VeoNonStop directly")
                elif not _pf_all_ok and _pf_last_fail_reason[0] == 'censorship':
                    print(f"  {_RED}[PREFLIGHT]{_RESET} BLOCKED — binary search for bad ref(s)...")
                    logging.warning("PREFLIGHT components: BLOCKED — isolating via binary search")

                    def _pf_isolate(refs_list, offset=0):
                        if not refs_list:
                            return []
                        if len(refs_list) == 1:
                            lbl = f"single: {refs_list[0].get('name', '?')}"
                            return [offset] if not _pf_banana_ok(refs_list, label=lbl) else []
                        mid = len(refs_list) // 2
                        bad = []
                        if not _pf_banana_ok(refs_list[:mid], label=f"left {offset+1}-{offset+mid}"):
                            bad.extend(_pf_isolate(refs_list[:mid], offset))
                        if not _pf_banana_ok(refs_list[mid:], label=f"right {offset+mid+1}-{offset+len(refs_list)}"):
                            bad.extend(_pf_isolate(refs_list[mid:], offset + mid))
                        return bad

                    bad_idxs = _pf_isolate(_pf_refs)
                    bad_names = [_pf_refs[i].get('name', f'ref_{i}') for i in bad_idxs]
                    print(f"  {_RED}[PREFLIGHT]{_RESET} Bad refs: {bad_names}")
                    logging.warning(f"PREFLIGHT components: bad refs: {bad_names}")

                    remixed_any = False
                    for idx in bad_idxs:
                        ref_name = _pf_refs[idx].get('name', '')
                        orig_file = None
                        for ext in ('.jpg', '.jpeg', '.png', '.webp'):
                            candidate = ref_path / (ref_name + ext)
                            if candidate.exists():
                                orig_file = candidate
                                break
                        if orig_file is None:
                            logging.warning(f"PREFLIGHT components: file not found for ref '{ref_name}'")
                            print(f"  {_YELLOW}[PREFLIGHT]{_RESET} File not found for ref '{ref_name}' — skipping remix")
                            continue
                        try:
                            remix_ref(str(orig_file), str(orig_file))
                            remixed_any = True
                            logging.info(f"PREFLIGHT components: {config.REMIX_ENGINE.upper()} remixed {orig_file.name} in-place")
                        except Exception as e:
                            logging.error(f"PREFLIGHT components: {config.REMIX_ENGINE.upper()} remix failed for {orig_file.name}: {e}")
                            print(f"  {_RED}[PREFLIGHT]{_RESET} {config.REMIX_ENGINE.upper()} remix failed for {orig_file.name}: {e}")

                    if remixed_any:
                        print(f"  {_YELLOW}[PREFLIGHT]{_RESET} Re-testing with remixed refs...")
                        _pf_refs = _load_ref_images(effective_ref_dir)
                        if not _pf_banana_ok(_pf_refs, label='ALL (remixed)'):
                            logging.error(f"PREFLIGHT components: still blocked after {config.REMIX_ENGINE.upper()} remix — stopping")
                            raise RuntimeError(
                                f"PREFLIGHT FAILED: components refs blocked even after {config.REMIX_ENGINE.upper()} remix.\n"
                                "Fix: replace blocked ref images manually."
                            )
                        else:
                            print(f"  {_GREEN}[PREFLIGHT]{_RESET} OK after {config.REMIX_ENGINE.upper()} remix — continuing with remixed refs")
                            logging.info(f"PREFLIGHT components: OK after {config.REMIX_ENGINE.upper()} remix")
                    else:
                        logging.error(f"PREFLIGHT components: no refs remixed ({config.REMIX_ENGINE.upper()} unavailable?) — stopping")
                        raise RuntimeError(
                            f"PREFLIGHT FAILED: components refs blocked and {config.REMIX_ENGINE.upper()} remix unavailable.\n"
                            "Fix: check REMIX_ENGINE API key (KIE_AI_API_KEY or XAI_API_KEY) in .env."
                        )
                else:
                    logging.info("PREFLIGHT components: refs OK")

            except RuntimeError:
                raise
            except Exception as e:
                logging.error(f"PREFLIGHT components: failed: {e}")
                print(f"  {_RED}[PREFLIGHT]{_RESET} Failed: {e}")
                raise RuntimeError(f"PREFLIGHT FAILED: {e}. VeoNonStop API may be down.")

    # ------------------------------------------------------------------
    # 4. Инициализация клиента + сброс зомби-тасков + семафор
    # ------------------------------------------------------------------
    global _active_tasks_path
    _active_tasks_path = Path(__file__).parent.parent / 'active_tasks.json'

    # ------------------------------------------------------------------
    # Multi-key init: loop over active_keys, create client per key
    # ------------------------------------------------------------------
    clients_cfg = []
    _any_cancelled = False
    for idx in _active_keys:
        key, mp_cfg, label = _KEY_DEFS[idx - 1]
        if not key:
            continue
        c = VeoNonStopClient(api_key=key)
        if no_cancel:
            print(f"\n  {_YELLOW}[CLEANUP]{_RESET} [{label}] --no-cancel: skipping zombie task cleanup.")
            logging.info(f"Startup cancel-all skipped for {label} (--no-cancel)")
        else:
            print(f"\n  {_YELLOW}[CLEANUP]{_RESET} [{label}] Cancelling zombie tasks...")
            cancelled = c.cancel_all_tasks()
            if cancelled > 0:
                print(f"  {_YELLOW}[CLEANUP]{_RESET} [{label}] Cancelled {cancelled} zombie task(s).")
                logging.info(f"Startup cancel-all {label}: cancelled {cancelled} tasks")
                _any_cancelled = True
            else:
                print(f"  {_YELLOW}[CLEANUP]{_RESET} [{label}] No active tasks found.")
        try:
            acc = c.get_account_info()
            ct = acc.get('concurrent_tasks', mp_cfg)
            mp = min(mp_cfg, ct)
            print(f"  [{label}] Plan: {acc.get('plan', '?')} | concurrent_tasks: {ct} | using: {mp}")
            logging.info(f"Account {label}: plan={acc.get('plan')}, concurrent_tasks={ct}, mp={mp}")
        except Exception as e:
            mp = mp_cfg
            logging.warning(f"Could not get account info ({label}): {e}")
        sem = threading.Semaphore(max(1, mp // 3))
        clients_cfg.append({'client': c, 'mp': mp, 'sem': sem, 'label': label})

    if _any_cancelled:
        print(f"  {_YELLOW}[CLEANUP]{_RESET} Waiting 3s for server to release slots...")
        time.sleep(3)
    _active_tasks_path.unlink(missing_ok=True)

    if not clients_cfg:
        raise ValueError("None of the specified VeoNonStop keys are configured in .env")

    # Expose clients for external stop (Control Panel Stop button)
    _active_clients.clear()
    _active_clients.extend(cfg['client'] for cfg in clients_cfg)

    max_parallel = sum(cfg['mp'] for cfg in clients_cfg)

    global _submit_semaphore
    _submit_semaphore = None
    for cfg in clients_cfg:
        slots = max(1, cfg['mp'] // 3)
        print(f"  [{cfg['label']}] Submit semaphore: {slots} concurrent submits ({cfg['mp']} // 3)")

    print(f"\n  Mode: {mode.upper()}")
    print(f"  Aspect ratio: {aspect_ratio or config.VEONONSTOP_ASPECT_RATIO}")
    print(f"  Parallel workers: {max_parallel}")
    print("=" * 60)

    # ------------------------------------------------------------------
    # 5. Генерация с retry-loop
    # ------------------------------------------------------------------
    global _max_parallel_global, _max_parallel_by_key, _inflight_by_key
    _max_parallel_global = max_parallel
    # Per-key max_parallel (для dual-key slot-wait)
    if clients_cfg:
        _max_parallel_by_key = {cfg['label']: cfg['mp'] for cfg in clients_cfg}
        _inflight_by_key = {cfg['label']: set() for cfg in clients_cfg}
    else:
        _max_parallel_by_key = {'Key1': max_parallel}
        _inflight_by_key = {'Key1': set()}
    accumulated_ok: Dict[int, Dict] = {}
    all_clip_results: List[Dict] = []  # ВСЕ результаты для статистики
    pending_prompts = {cid: prompts_map[cid] for cid in pending_ids}
    _tech_fail_cycles: Dict[int, int] = {}  # clip_id -> кол-во подряд циклов с техн. ошибкой в Phase1

    # worker_id counter — потокобезопасный
    _worker_counter = {'next': 0}
    _worker_lock = threading.Lock()
    _worker_map: Dict[int, int] = {}  # thread_id -> worker_id

    def _get_worker_id() -> int:
        tid = threading.get_ident()
        with _worker_lock:
            if tid not in _worker_map:
                _worker_map[tid] = _worker_counter['next']
                _worker_counter['next'] += 1
            return _worker_map[tid]

    cycle_num = 0
    start_total = time.time()
    was_interrupted = False

    # ── Graceful shutdown handler ─────────────────────────────────────
    import signal

    _original_sigint = signal.getsignal(signal.SIGINT)

    def _graceful_shutdown(signum, frame):
        """Ctrl+C handler: ставим флаг + отменяем in-flight задачи."""
        if _shutdown_requested.is_set():
            # Второй Ctrl+C — жёсткий выход
            print(f"\n\n  {_RED}[FORCE QUIT]{_RESET} Second Ctrl+C — exiting immediately!")
            signal.signal(signal.SIGINT, _original_sigint)
            raise KeyboardInterrupt
        _shutdown_requested.set()
        print(f"\n\n  {_YELLOW}{'='*60}{_RESET}")
        print(f"  {_YELLOW}[SHUTDOWN]{_RESET} Ctrl+C received! Graceful shutdown...")
        print(f"  {_YELLOW}[SHUTDOWN]{_RESET} No new tasks will be submitted.")
        print(f"  {_YELLOW}[SHUTDOWN]{_RESET} Cancelling in-flight tasks via API...")

        # Cancel all tasks for all clients (cancel_all_tasks per key)
        total_cancelled = 0
        for cfg in clients_cfg:
            try:
                n = cfg['client'].cancel_all_tasks()
                total_cancelled += n
                print(f"  {_YELLOW}[SHUTDOWN]{_RESET} [{cfg['label']}] cancelled {n} task(s) on server")
            except Exception as e:
                print(f"  {_YELLOW}[SHUTDOWN]{_RESET} [{cfg['label']}] cancel failed: {e}")

        print(f"  {_YELLOW}[SHUTDOWN]{_RESET} Total cancelled: {total_cancelled} tasks.")
        print(f"  {_YELLOW}[SHUTDOWN]{_RESET} Waiting for workers to finish...")
        print(f"  {_YELLOW}[SHUTDOWN]{_RESET} (Press Ctrl+C again for force quit)")
        print(f"  {_YELLOW}{'='*60}{_RESET}\n")

    if threading.current_thread() is threading.main_thread():
        signal.signal(signal.SIGINT, _graceful_shutdown)

    # Shared running-average stats across all cycles (thread-safe)
    _ok_run = {'n': 0, 'total': 0.0, 'lock': threading.Lock(), 'wall_start': time.time()}

    try:
        while True:
            if _shutdown_requested.is_set():
                was_interrupted = True
                break

            cycle_num += 1
            cycle_ids = sorted(pending_prompts.keys())
            print(f"\n  [Cycle {cycle_num}] Generating {len(cycle_ids)} videos...")

            cycle_results: List[Dict] = []

            # ── Порционная подача задач в ThreadPool ──────────────────────
            # НЕ сабмитим все 700 сразу. Держим в полёте max_parallel задач,
            # новую подаём только когда предыдущая завершилась.
            # Reset worker map and stagger tracking for new cycle
            with _worker_lock:
                _worker_map.clear()
                _worker_counter['next'] = 0
            with _started_workers_lock:
                _started_workers.clear()

            with ThreadPoolExecutor(max_workers=max_parallel) as executor:
                task_queue = list(cycle_ids)  # копия для потребления
                active_futures: Dict = {}    # future -> clip_id

                def _submit_one():
                    """Подать одну задачу из очереди, если есть."""
                    if not task_queue or _shutdown_requested.is_set():
                        return
                    cid = task_queue.pop(0)
                    image_path = None
                    if mode in ('i2v', 'batch_frame'):
                        image_path = _find_image(cid)
                    # Worker-assignment: клиент определяется ВНУТРИ воркера по worker_id
                    fut = executor.submit(
                        _process_single_clip,
                        client=None,
                        clip_id=cid,
                        prompt=pending_prompts[cid],
                        mode=mode,
                        image_path=image_path,
                        ref_dir=effective_ref_dir if mode == 'components' else None,
                        output_dir=output_dir,
                        aspect_ratio=aspect_ratio,
                        worker_id_fn=_get_worker_id,
                        single_prompt_mode=bool(single_prompt),
                        end_image_path=end_image_map.get(cid) if mode == 'batch_frame' else None,
                        clients_cfg_list=clients_cfg,
                        ok_run=_ok_run,
                    )
                    active_futures[fut] = cid

                # Начальная порция — max_parallel задач
                for _ in range(min(max_parallel, len(task_queue))):
                    _submit_one()

                _cycle_ok_durs = []
                _cycle_total = len(cycle_ids)
                _cycle_done = 0
                if IS_PIPE:
                    print(f"  Cycle {cycle_num}: 0/{_cycle_total} clips", flush=True)
                _tqdm_ctx = tqdm(total=_cycle_total, desc=f"  Cycle {cycle_num}", unit="clip", smoothing=0) if not IS_PIPE else None
                while active_futures:
                    # Ждём завершения ПЕРВОГО из текущих (timeout=2s для responsiveness)
                    done, _ = wait(active_futures.keys(), timeout=2, return_when=FIRST_COMPLETED)

                    if not done:
                        # Timeout — проверяем shutdown
                        if _shutdown_requested.is_set():
                            # Drain: ждём все оставшиеся futures
                            if _tqdm_ctx:
                                _tqdm_ctx.set_postfix_str("shutting down...")
                            remaining = list(active_futures.keys())
                            for fut in remaining:
                                try:
                                    clip_result = fut.result(timeout=300)
                                    cid = active_futures.pop(fut)
                                    cycle_results.append(clip_result)
                                except Exception:
                                    cid = active_futures.pop(fut)
                                    cycle_results.append({
                                        'id': cid, 'status': 'error',
                                        'error': 'shutdown', 'file': None,
                                        'task_id': None, 'duration_sec': 0,
                                        'worker_id': -1, 'retries': 0,
                                        'retry_time': 0, 'error_counts': {},
                                        'rewritten': False,
                                    })
                                _cycle_done += 1
                                if _tqdm_ctx:
                                    _tqdm_ctx.update(1)
                                if IS_PIPE:
                                    print(f"PROGRESS:{_cycle_done}/{_cycle_total}", flush=True)
                            break
                        continue

                    for future in done:
                        cid = active_futures.pop(future)
                        try:
                            clip_result = future.result()
                            cycle_results.append(clip_result)
                            icon = '+' if clip_result['status'] == 'ok' else 'X'
                            dur = clip_result.get('duration_sec', 0)
                            if clip_result['status'] == 'ok' and dur > 0:
                                _cycle_ok_durs.append(dur)
                            if _tqdm_ctx:
                                avg_s = f" avg={sum(_cycle_ok_durs)/len(_cycle_ok_durs):.0f}s" if _cycle_ok_durs else ""
                                _tqdm_ctx.set_postfix_str(f"#{cid}: {icon}{avg_s}")
                        except Exception as e:
                            cycle_results.append({
                                'id': cid, 'status': 'error', 'error': str(e),
                                'file': None, 'task_id': None, 'duration_sec': 0,
                                'worker_id': -1, 'retries': 0, 'retry_time': 0,
                                'error_counts': {}, 'rewritten': False,
                            })
                            if _tqdm_ctx:
                                _tqdm_ctx.set_postfix_str(f"#{cid}: X")
                        _cycle_done += 1
                        if _tqdm_ctx:
                            _tqdm_ctx.update(1)
                        if IS_PIPE:
                            print(f"PROGRESS:{_cycle_done}/{_cycle_total}", flush=True)

                        # Подаём следующую задачу (если нет shutdown)
                        if not _shutdown_requested.is_set():
                            _submit_one()
                if _tqdm_ctx:
                    _tqdm_ctx.close()

            # Разбор результатов
            all_clip_results.extend(cycle_results)
            for r in cycle_results:
                cid = r['id']
                if r['status'] == 'ok':
                    accumulated_ok[cid] = r
                    pending_prompts.pop(cid, None)
                    _tech_fail_cycles.pop(cid, None)
                else:
                    # Трекаем подряд идущие циклы с техн. ошибкой (Phase1)
                    _tech_fail_cycles[cid] = _tech_fail_cycles.get(cid, 0) + 1
                    if _tech_fail_cycles[cid] >= 2:
                        # 2 цикла подряд техн. ошибка — static fallback
                        _img_path = _find_image(cid)
                        if _img_path and Path(_img_path).is_file():
                            _ext = Path(_img_path).suffix
                            _dest = output_dir / f"{cid:03d}{_ext}"
                            try:
                                shutil.copy(_img_path, str(_dest))
                                logging.warning(f"Clip #{cid}: 2 cycles tech error — static fallback (copied image)")
                                print(f"  {_YELLOW}[STATIC]{_RESET} #{cid}: 2 cycles of tech errors — static fallback")
                                accumulated_ok[cid] = {'id': cid, 'status': 'ok', 'file': str(_dest)}
                                pending_prompts.pop(cid, None)
                            except Exception as _cpe:
                                logging.error(f"Clip #{cid}: static fallback copy failed: {_cpe}")
                        else:
                            logging.warning(f"Clip #{cid}: 2 cycles tech error — no image for static fallback")
                            print(f"  {_YELLOW}[GIVE UP]{_RESET} #{cid}: 2 cycles of tech errors, no image available")
                            pending_prompts.pop(cid, None)

            cycle_ok = sum(1 for r in cycle_results if r['status'] == 'ok')
            failed_ids = sorted(pending_prompts.keys())

            print(f"\n  [Cycle {cycle_num}] OK: {cycle_ok},  still missing: {len(failed_ids)}")

            if not failed_ids:
                break

            if _shutdown_requested.is_set():
                was_interrupted = True
                break

            # ── Silent mode: авто-ретрай до N циклов ─────────────
            if silent:
                _max_cycles = config.VEONONSTOP_MAX_SILENT_CYCLES
                if cycle_num < _max_cycles:
                    print(f"\n  {_YELLOW}[SILENT]{_RESET} {len(failed_ids)} clips failed, auto-retrying (cycle {cycle_num + 1}/{_max_cycles})...")
                    logging.info(f"Silent mode: {len(failed_ids)} failed after cycle {cycle_num}, auto-retrying ({cycle_num + 1}/{_max_cycles})")
                    continue
                else:
                    print(f"\n  {_YELLOW}[SILENT]{_RESET} {len(failed_ids)} clips still failed after {cycle_num} cycles. Giving up.")
                    logging.warning(f"Silent mode: {len(failed_ids)} failed after {cycle_num} cycles (max {_max_cycles}), stopping")
                    break

            # ── Interactive mode: спрашиваем юзера ────────────────
            print("\n" + "=" * 60)
            print(f"  {_RED}MISSING CLIPS ({len(failed_ids)} total):{_RESET}")
            for cid in failed_ids:
                last_r = next((r for r in reversed(cycle_results) if r['id'] == cid), None)
                err = (last_r.get('error', '') if last_r else '')[:80]
                print(f"  #{cid:03d}: {err}")
            print("=" * 60)

            print(f"\n  {_YELLOW}What would you like to do?{_RESET}")
            print(f"    [1] Retry missing clips ({len(failed_ids)})")
            print(f"    [2] Finish — skip failed clips")
            print()

            while True:
                choice = input("  Select [1/2]: ").strip()
                if choice == '1':
                    break
                elif choice == '2':
                    failed_ids = []
                    break
                print("  Enter 1 or 2")

            if not failed_ids or choice == '2':
                break

    finally:
        # Восстанавливаем оригинальный signal handler
        if threading.current_thread() is threading.main_thread():
            signal.signal(signal.SIGINT, _original_sigint)
        _shutdown_requested.clear()
        with _inflight_lock:
            _inflight_tasks.clear()
        if _active_tasks_path is not None:
            _active_tasks_path.unlink(missing_ok=True)

    if was_interrupted:
        print(f"\n  {_YELLOW}[SHUTDOWN]{_RESET} Generation interrupted by user (Ctrl+C).")
        print(f"  {_YELLOW}[SHUTDOWN]{_RESET} Partial results saved. Already generated videos are in vid_img/.")

    # ------------------------------------------------------------------
    # 5b. Video upscale pass (optional)
    # ------------------------------------------------------------------
    _upscale_ok = 0
    _upscale_fail = 0
    if upscale_video and accumulated_ok and not was_interrupted:
        _ups_candidates = [
            (cid, r) for cid, r in accumulated_ok.items()
            if r.get('media_generation_id')
        ]
        if _ups_candidates:
            print(f"\n{'='*60}")
            print(f"  VIDEO UPSCALE (1080p): {len(_ups_candidates)} clips")
            print(f"{'='*60}\n")

            def _upscale_one_video(_cid, _r):
                _mgid = _r['media_generation_id']
                _out = output_dir / f"{_cid:03d}.mp4"
                _cl = clients_cfg[_cid % len(clients_cfg)]['client']
                try:
                    _ups_tid = _cl.submit_upsample_video(
                        media_generation_id=_mgid,
                        aspect_ratio=aspect_ratio,
                    )
                    _cl.poll_video_status(_ups_tid)
                    _cl.download_video(_ups_tid, str(_out))
                    return True
                except Exception as _ue:
                    logging.warning(f"Clip #{_cid}: video upscale failed: {_ue}")
                    return False

            _ups_par = min(max_parallel, len(_ups_candidates))
            with ThreadPoolExecutor(max_workers=_ups_par) as _ups_exec:
                _ups_futs = {_ups_exec.submit(_upscale_one_video, c, r): c for c, r in _ups_candidates}
                _ups_tqdm = tqdm(total=len(_ups_futs), desc="  Upscaling", unit="clip") if not IS_PIPE else None
                for _f in as_completed(_ups_futs):
                    _c = _ups_futs[_f]
                    try:
                        if _f.result():
                            _upscale_ok += 1
                            print(f"  {_GREEN}[UPSCALE]{_RESET} #{_c}: OK")
                        else:
                            _upscale_fail += 1
                            print(f"  {_YELLOW}[UPSCALE]{_RESET} #{_c}: failed (kept original)")
                    except Exception:
                        _upscale_fail += 1
                    if _ups_tqdm:
                        _ups_tqdm.update(1)
                if _ups_tqdm:
                    _ups_tqdm.close()
            print(f"\n  Video upscale: {_upscale_ok} OK, {_upscale_fail} failed")
        elif upscale_video:
            print(f"\n  {_YELLOW}[UPSCALE]{_RESET} No clips have media_generation_id — skipping upscale")

    # ------------------------------------------------------------------
    # 6. Финальная статистика (по LOGGING_REQUIREMENTS)
    # ------------------------------------------------------------------
    elapsed_total = round(time.time() - start_total, 1)
    total_ok = len(accumulated_ok)
    total_failed = len(pending_prompts)
    total_clips = total_ok + total_failed

    # Время
    ok_results = [r for r in all_clip_results if r['status'] == 'ok']
    ok_durations = [r.get('duration_sec', 0) for r in ok_results]
    clean_durations = [r.get('duration_sec', 0) for r in ok_results if r.get('retries', 0) == 0]

    avg_time_per_clip = round(sum(ok_durations) / len(ok_durations), 1) if ok_durations else 0
    avg_time_clean = round(sum(clean_durations) / len(clean_durations), 1) if clean_durations else 0

    total_upload_sec = round(sum(r.get('upload_sec', 0) for r in ok_results), 1)
    total_gen_sec    = round(sum(r.get('gen_sec', 0)    for r in ok_results), 1)
    total_dl_sec     = round(sum(r.get('dl_sec', 0)     for r in ok_results), 1)

    # Ретраи
    total_retries = sum(r.get('retries', 0) for r in all_clip_results)
    total_retry_time = round(sum(r.get('retry_time', 0) for r in all_clip_results), 1)
    total_rewrites = sum(1 for r in all_clip_results if r.get('rewritten'))

    # Worker stats
    worker_stats: Dict[int, Dict] = {}
    for r in all_clip_results:
        wid = r.get('worker_id', -1)
        if wid not in worker_stats:
            worker_stats[wid] = {'ok': 0, 'failed': 0, 'total': 0,
                                  'upload_sec': 0.0, 'gen_sec': 0.0, 'dl_sec': 0.0}
        worker_stats[wid]['total'] += 1
        if r['status'] == 'ok':
            worker_stats[wid]['ok'] += 1
            worker_stats[wid]['upload_sec'] += r.get('upload_sec', 0.0)
            worker_stats[wid]['gen_sec']    += r.get('gen_sec', 0.0)
            worker_stats[wid]['dl_sec']     += r.get('dl_sec', 0.0)
        else:
            worker_stats[wid]['failed'] += 1

    # Errors by type
    error_totals: Dict[str, int] = {}
    for r in all_clip_results:
        for k, v in r.get('error_counts', {}).items():
            error_totals[k] = error_totals.get(k, 0) + v

    # Print
    print("\n" + "=" * 80)
    print(f"  IMG2VIDEO COMPLETE")
    print(f"  Generated: {total_ok}")
    print(f"  Failed:    {total_failed}")
    print(f"  Total:     {total_clips}")
    print(f"  Skipped:   {len(skipped)}")
    print(f"  Total run time: {elapsed_total}s ({elapsed_total/60:.1f} min)")
    print(f"  Output: {output_dir}")
    print()
    print(f"  [TIME STATS]")
    print(f"  Avg time per clip (all ok): {avg_time_per_clip}s")
    print(f"  Avg time per clip (clean, no retries): {avg_time_clean}s")
    print(f"  Total upload time (sum):  {total_upload_sec}s")
    print(f"  Total gen time (sum):     {total_gen_sec}s")
    print(f"  Total download time (sum):{total_dl_sec}s")
    print()
    print(f"  [RETRY STATS]")
    print(f"  Total retries: {total_retries}")
    print(f"  Total retry time: {total_retry_time}s")
    print(f"  Rewrites: {total_rewrites}")
    print()
    print(f"  [WORKER STATS]")
    for wid in sorted(worker_stats.keys()):
        ws = worker_stats[wid]
        print(f"    Worker {wid}: {ws['ok']}/{ws['total']} ok ({ws['failed']} failed)"
              f" | upload={ws['upload_sec']:.1f}s gen={ws['gen_sec']:.1f}s dl={ws['dl_sec']:.1f}s")

    if error_totals:
        print()
        print(f"  [ERRORS BY TYPE]")
        for etype, cnt in sorted(error_totals.items(), key=lambda x: -x[1]):
            print(f"    {etype}: {cnt}")

    print("=" * 80)

    # Log to file too
    logging.info(f"=== img2video complete: {total_ok} ok, {total_failed} failed, {elapsed_total}s ===")
    logging.info(f"  Avg time (all ok): {avg_time_per_clip}s, clean: {avg_time_clean}s")
    logging.info(f"  Total upload: {total_upload_sec}s, gen: {total_gen_sec}s, dl: {total_dl_sec}s")
    logging.info(f"  Total retries: {total_retries}, retry time: {total_retry_time}s, rewrites: {total_rewrites}")
    for wid in sorted(worker_stats.keys()):
        ws = worker_stats[wid]
        logging.info(f"  Worker {wid}: {ws['ok']}/{ws['total']} ok ({ws['failed']} failed)"
                     f" | upload={ws['upload_sec']:.1f}s gen={ws['gen_sec']:.1f}s dl={ws['dl_sec']:.1f}s")
    if error_totals:
        logging.info(f"  Errors by type: {error_totals}")

    # Удаляем file handler
    logging.getLogger().removeHandler(file_handler)
    file_handler.close()

    return {
        'generated': total_ok,
        'failed': total_failed,
        'skipped': len(skipped),
        'elapsed_sec': elapsed_total,
        'results': list(accumulated_ok.values()),
        'avg_time': avg_time_per_clip,
        'avg_time_clean': avg_time_clean,
        'total_retries': total_retries,
        'total_retry_time': total_retry_time,
        'total_rewrites': total_rewrites,
        'worker_stats': worker_stats,
        'error_totals': error_totals,
    }


# ======================================================================
# CLI
# ======================================================================

if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='VeoNonStop img2video batch generator')
    parser.add_argument('--dir', required=True, help='Project directory')
    parser.add_argument('--mode', choices=['i2v', 't2v', 'components'], default='i2v')
    parser.add_argument('--parallel', type=int, default=None)
    parser.add_argument('--ratio', default=None, help='Aspect ratio (16:9, 9:16, 1:1)')
    parser.add_argument('--prompt', default=None, help='Single prompt for all clips')
    parser.add_argument('--ids', default=None, help='Comma-separated clip IDs (e.g. 1,5,10)')
    parser.add_argument('--ref-dir', default=None, help='Reference images directory')
    parser.add_argument('--silent', action='store_true', help='Silent mode: auto-retry up to 5 cycles')

    args = parser.parse_args()

    clip_ids = None
    if args.ids:
        clip_ids = [int(x.strip()) for x in args.ids.split(',')]

    logging.basicConfig(level=logging.DEBUG, format=config.LOG_FORMAT)

    try:
        result = generate_all_videos(
            project_dir=args.dir,
            mode=args.mode,
            max_parallel=args.parallel,
            clip_ids=clip_ids,
            single_prompt=args.prompt,
            aspect_ratio=args.ratio,
            ref_dir=args.ref_dir,
            silent=args.silent,
        )
        sys.exit(0 if result['failed'] == 0 else 1)
    except Exception as e:
        print(f"\n  {_RED}ERROR:{_RESET} {e}")
        logging.exception("img2video failed")
        sys.exit(1)
