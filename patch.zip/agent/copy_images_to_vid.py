"""
copy_images_to_vid.py — Copy missing fragment images from generated/ to vid_img/.

Reads missing_fragments.txt, finds matching image in generated/, copies to vid_img/.
video_concat.py handles images natively (Ken Burns zoom), so no FFmpeg needed here.

Exit codes:
  0 — all missing IDs found and copied
  1 — some IDs not found in generated/ (still missing)
"""
import sys
import shutil
from pathlib import Path

missing_file = Path('missing_fragments.txt')
if not missing_file.exists():
    print('[OK] missing_fragments.txt not found — nothing to do')
    sys.exit(0)

ids_text = missing_file.read_text(encoding='utf-8').strip()
if not ids_text:
    print('[OK] No missing fragments')
    sys.exit(0)

missing_ids = ids_text.split()
generated = Path('generated')
vid_img = Path('vid_img')
vid_img.mkdir(exist_ok=True)

IMAGE_EXTS = ('png', 'jpg', 'jpeg', 'webp')
copied = []
not_found = []

for id_str in missing_ids:
    cid = int(id_str)
    src = None
    for fmt in (f'{cid:03d}', str(cid)):
        for ext in IMAGE_EXTS:
            candidate = generated / f'{fmt}.{ext}'
            if candidate.exists():
                src = candidate
                break
        if src:
            break
    if src:
        dst = vid_img / f'{cid:03d}{src.suffix}'
        shutil.copy2(src, dst)
        copied.append(id_str)
        print(f'  [COPY] #{cid:03d}  {src.name}  ->  {dst.name}')
    else:
        not_found.append(id_str)
        print(f'  [SKIP] #{cid:03d}  not found in generated/')

print()
print(f'  Copied: {len(copied)}    Not found: {len(not_found)}')
if not_found:
    print(f'  Still missing: {" ".join(not_found)}')
    sys.exit(1)
sys.exit(0)
