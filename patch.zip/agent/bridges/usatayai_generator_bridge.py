#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
usatayai_generator_bridge.py
Stable optional generator handoff for VAR agent -> Usataya Lentyayka.

Used only when VAR agent receives env:
    USATAYAI_GENERATOR_BRIDGE_MANIFEST=/path/to/manifest.json

The VAR agent calls this script instead of native generation. This script is
intentionally generic: it can either run an external command supplied by the
host app or import already generated clips/images into project/vid_img.

Minimal manifest examples:

1) Copy already generated clips:
{
  "source_dir": "/path/to/generated_clips"
}

2) Run external generator, then copy its output:
{
  "command": ["python", "/path/to/host_generator.py", "--project", "{project}", "--action", "{action}"],
  "source_dir": "/path/to/generated_clips"
}

3) Wait for host app to finish asynchronously:
{
  "source_dir": "/path/to/generated_clips",
  "wait_done_file": "/path/to/done.flag",
  "timeout_sec": 86400
}
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

MEDIA_EXTS = {".mp4", ".mov", ".mkv", ".avi", ".png", ".jpg", ".jpeg", ".webp"}


def log(msg: str) -> None:
    print(f"[USATAYAI-GENERATOR-BRIDGE] {msg}", flush=True)


def load_manifest(path: Path) -> Dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"manifest not found: {path}")
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict):
        raise ValueError("manifest must be a JSON object")
    return data


def _as_path(value: Any) -> Optional[Path]:
    if value is None:
        return None
    s = str(value).strip()
    if not s:
        return None
    return Path(s).expanduser()


def numeric_id_from_name(path: Path) -> Optional[int]:
    # Prefer pure numeric stems like 001.mp4; fallback to first numeric group.
    if re.fullmatch(r"\d{1,4}", path.stem):
        return int(path.stem)
    m = re.search(r"(?<!\d)(\d{1,4})(?!\d)", path.stem)
    return int(m.group(1)) if m else None


def iter_media_files(src_dir: Path) -> Iterable[Path]:
    if not src_dir.exists():
        return []
    return sorted(
        p for p in src_dir.iterdir()
        if p.is_file() and not p.name.startswith("._") and p.suffix.lower() in MEDIA_EXTS
    )


def import_generated_files(source_dir: Path, project_dir: Path) -> int:
    """Copy external generated clips/images into VAR project/vid_img/NNN.ext."""
    source_dir = source_dir.expanduser().resolve()
    project_dir = project_dir.expanduser().resolve()
    dest_dir = project_dir / "vid_img"
    dest_dir.mkdir(parents=True, exist_ok=True)

    files = list(iter_media_files(source_dir))
    if not files:
        raise FileNotFoundError(f"no generated media found in source_dir: {source_dir}")

    copied = 0
    for src in files:
        cid = numeric_id_from_name(src)
        if cid is None:
            log(f"skip non-numbered file: {src.name}")
            continue
        dest = dest_dir / f"{cid:03d}{src.suffix.lower()}"
        shutil.copy2(str(src), str(dest))
        copied += 1
        log(f"import: {src.name} -> {dest.relative_to(project_dir)}")

    if copied <= 0:
        raise RuntimeError(f"media exists in {source_dir}, but no numeric clip ids were found")
    return copied


def format_command(command: Any, values: Dict[str, str]) -> List[str]:
    if isinstance(command, str):
        # shell=True is intentionally avoided. For strings we do a simple split.
        import shlex
        parts = shlex.split(command)
    elif isinstance(command, list):
        parts = [str(x) for x in command]
    else:
        raise ValueError("manifest command must be a string or a list")
    return [p.format(**values) for p in parts]


def run_external_command(manifest: Dict[str, Any], values: Dict[str, str]) -> None:
    command = manifest.get("command") or manifest.get("generator_command")
    if not command:
        return
    cmd = format_command(command, values)
    cwd = _as_path(manifest.get("cwd")) or Path(values["project"])
    env = dict(os.environ)
    env.update({
        "USATAYAI_VAR_PROJECT": values["project"],
        "USATAYAI_VAR_ACTION": values["action"],
        "USATAYAI_VAR_PROMPT_MODE": values["prompt_mode"],
        "USATAYAI_GENERATOR_MANIFEST": values["manifest"],
    })
    extra_env = manifest.get("env")
    if isinstance(extra_env, dict):
        env.update({str(k): str(v) for k, v in extra_env.items()})
    log("run external command: " + " ".join(cmd))
    proc = subprocess.Popen(
        cmd,
        cwd=str(cwd),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    try:
        assert proc.stdout is not None
        for line in proc.stdout:
            line = line.rstrip("\n\r")
            if line:
                print(line, flush=True)
    finally:
        rc = proc.wait()
    if rc != 0:
        raise RuntimeError(f"external generator command failed with code {rc}")


def wait_done_file(manifest: Dict[str, Any]) -> None:
    done = _as_path(manifest.get("wait_done_file") or manifest.get("done_file"))
    if not done:
        return
    timeout = float(manifest.get("timeout_sec") or manifest.get("timeout") or 86400)
    poll = max(1.0, float(manifest.get("poll_interval_sec") or 3))
    started = time.time()
    log(f"waiting done file: {done}")
    while True:
        if done.exists():
            log("done file detected")
            return
        if time.time() - started > timeout:
            raise TimeoutError(f"timeout waiting done file: {done}")
        time.sleep(poll)


def resolve_source_dir(manifest: Dict[str, Any], project_dir: Path) -> Optional[Path]:
    for key in ("source_dir", "clips_dir", "generated_clips_dir", "output_dir"):
        p = _as_path(manifest.get(key))
        if p:
            return p
    # Common fallback: host may generate directly into project/vid_img.
    vid_img = project_dir / "vid_img"
    if vid_img.exists() and list(iter_media_files(vid_img)):
        return vid_img
    return None


def main() -> int:
    ap = argparse.ArgumentParser(description="USATAYAI optional external generator bridge for VAR")
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--project", required=True)
    ap.add_argument("--action", default="")
    ap.add_argument("--prompt-mode", default="single")
    args = ap.parse_args()

    manifest_path = Path(args.manifest).expanduser().resolve()
    project_dir = Path(args.project).expanduser().resolve()
    manifest = load_manifest(manifest_path)
    values = {
        "manifest": str(manifest_path),
        "project": str(project_dir),
        "action": str(args.action or ""),
        "prompt_mode": str(args.prompt_mode or "single"),
    }

    log(f"manifest: {manifest_path}")
    log(f"project: {project_dir}")
    log(f"action: {args.action} | prompt_mode: {args.prompt_mode}")

    run_external_command(manifest, values)
    wait_done_file(manifest)

    source_dir = resolve_source_dir(manifest, project_dir)
    if not source_dir:
        # If command generated directly into vid_img, this is still OK.
        vid_img = project_dir / "vid_img"
        if vid_img.exists() and list(iter_media_files(vid_img)):
            log(f"vid_img already contains media: {vid_img}")
            print(f"RESULT_VID_IMG:{vid_img}", flush=True)
            return 0
        raise FileNotFoundError("manifest must provide source_dir/clips_dir/output_dir or generate files into project/vid_img")

    copied = import_generated_files(source_dir, project_dir)
    log(f"done: imported {copied} file(s) into vid_img")
    print(f"RESULT_VID_IMG:{project_dir / 'vid_img'}", flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        log(f"FATAL: {exc}")
        raise
