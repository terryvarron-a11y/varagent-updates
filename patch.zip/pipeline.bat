@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0"

REM ============================================================================
REM LOGGING SETUP - redirect all output to log file
REM ============================================================================
set "LOG_DIR=%~dp0projects\_logs"
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"
set "LOG_FILE=%LOG_DIR%\pipeline_%DATE:~-4,4%%DATE:~-7,2%%DATE:~-10,2%_%TIME:~0,2%%TIME:~3,2%%TIME:~6,2%.log"
set "LOG_FILE=%LOG_FILE: =0%"

echo Logging to: %LOG_FILE%
(
echo.
echo ================================================================================
echo PIPELINE LOG - %DATE% %TIME%
echo ================================================================================
echo.
) >> "%LOG_FILE%"

REM Helper to echo to both console and log
set "ECHO=echo & echo >> "%LOG_FILE%""

set "ENV_FILE=%~dp0agent\.env"

REM ============================================================================
REM READ DEFAULTS FROM .ENV
REM ============================================================================

set "LANG=ru"
set "GEMINI_TWO_PASS_VAL=false"
set "CLIP_MODE=video"
set "CLIP_MIN=4"
set "CLIP_MAX=8"
set "FASTGEN_MODEL_VAL=GEMINI"
set "FASTGEN_ASPECT_VAL=landscape"
set "FASTGEN_PARALLEL_VAL=10"
set "VEO_RATIO=16:9"
set "VEO_PARALLEL=12"
set "TTS_SERVICE_VAL=mat3u"
set "TTS_MODEL_VAL=eleven_multilingual_v2"
set "TTS_SPLIT_VAL=smart"

for /f "usebackq tokens=1,* delims==" %%A in ("%ENV_FILE%") do (
    set "KEY=%%A"
    set "VAL=%%B"
    set "KEY=!KEY: =!"
    if "!KEY!"=="ASSEMBLYAI_LANGUAGE_CODE"   set "LANG=!VAL!"
    if "!KEY!"=="GEMINI_TWO_PASS"            set "GEMINI_TWO_PASS_VAL=!VAL!"
    if "!KEY!"=="VIDEO_CLIP_MIN_DURATION"    set "CLIP_MIN=!VAL!"
    if "!KEY!"=="VIDEO_CLIP_MAX_DURATION"    set "CLIP_MAX=!VAL!"
    if "!KEY!"=="FASTGEN_MODEL"              set "FASTGEN_MODEL_VAL=!VAL!"
    if "!KEY!"=="FASTGEN_ASPECT_RATIO"       set "FASTGEN_ASPECT_VAL=!VAL!"
    if "!KEY!"=="FASTGEN_MAX_PARALLEL"       set "FASTGEN_PARALLEL_VAL=!VAL!"
    if "!KEY!"=="VEONONSTOP_ASPECT_RATIO"    set "VEO_RATIO=!VAL!"
    if "!KEY!"=="VEONONSTOP_MAX_PARALLEL"    set "VEO_PARALLEL=!VAL!"
    if "!KEY!"=="TTS_SERVICE"                set "TTS_SERVICE_VAL=!VAL!"
    if "!KEY!"=="TTS_MAT3U_MODEL_ID"         set "TTS_MODEL_VAL=!VAL!"
    if "!KEY!"=="TTS_MAT3U_SPLIT_TYPE"       set "TTS_SPLIT_VAL=!VAL!"
)

REM Derive direction mode label
set "DIR_MODE=1-pass"
if /i "!GEMINI_TWO_PASS_VAL!"=="true" set "DIR_MODE=2-pass"

REM ============================================================================
REM 1. START POINT
REM ============================================================================

echo  Where to start?
echo    [1] From script (.txt in pipeline_queue) - TTS then full pipeline
echo    [2] From audio  (.mp3/.wav in pipeline_queue) - skip TTS
echo.
set "START_POINT=2"
set /p "START_POINT=  Select [1/2, Enter=2]: "
if "!START_POINT!"=="" set "START_POINT=2"

REM ============================================================================
REM 2. TTS SETTINGS (only if starting from script)
REM ============================================================================

if "!START_POINT!"=="1" (
    echo.
    echo  --- TTS ---
    echo  Defaults: service=!TTS_SERVICE_VAL!  model=!TTS_MODEL_VAL!  split=!TTS_SPLIT_VAL!
    set "TTS_CHANGE="
    set /p "TTS_CHANGE=  Accept? [Enter=ok / 2=change]: "
    if "!TTS_CHANGE!"=="2" (
        echo.
        echo  TTS service:
        echo    [1] mat3u  - ElevenLabs via mat3u.com
        echo    [2] csv666 - voiceapi.csv666.ru
        set "TTS_SVC_SEL="
        set /p "TTS_SVC_SEL=  Select [1/2, Enter=!TTS_SERVICE_VAL!]: "
        if "!TTS_SVC_SEL!"=="2" set "TTS_SERVICE_VAL=csv666"
        if "!TTS_SVC_SEL!"=="1" set "TTS_SERVICE_VAL=mat3u"
        echo.
        echo  Model:
        echo    [1] eleven_multilingual_v2  [2] eleven_v3  [3] eleven_turbo_v2_5
        echo    [4] eleven_turbo_v2  [5] eleven_flash_v2_5  [6] eleven_flash_v2
        set "TTS_MDL_SEL="
        set /p "TTS_MDL_SEL=  Select [1-6, Enter=keep !TTS_MODEL_VAL!]: "
        if "!TTS_MDL_SEL!"=="1" set "TTS_MODEL_VAL=eleven_multilingual_v2"
        if "!TTS_MDL_SEL!"=="2" set "TTS_MODEL_VAL=eleven_v3"
        if "!TTS_MDL_SEL!"=="3" set "TTS_MODEL_VAL=eleven_turbo_v2_5"
        if "!TTS_MDL_SEL!"=="4" set "TTS_MODEL_VAL=eleven_turbo_v2"
        if "!TTS_MDL_SEL!"=="5" set "TTS_MODEL_VAL=eleven_flash_v2_5"
        if "!TTS_MDL_SEL!"=="6" set "TTS_MODEL_VAL=eleven_flash_v2"
        echo.
        echo  Split type:
        echo    [1] smart  [2] sentences  [3] paragraphs  [4] max_length
        set "TTS_SPL_SEL="
        set /p "TTS_SPL_SEL=  Select [1-4, Enter=keep !TTS_SPLIT_VAL!]: "
        if "!TTS_SPL_SEL!"=="1" set "TTS_SPLIT_VAL=smart"
        if "!TTS_SPL_SEL!"=="2" set "TTS_SPLIT_VAL=sentences"
        if "!TTS_SPL_SEL!"=="3" set "TTS_SPLIT_VAL=paragraphs"
        if "!TTS_SPL_SEL!"=="4" set "TTS_SPLIT_VAL=max_length"
    )
)

REM ============================================================================
REM 3. TRANSCRIPTION + DIRECTION
REM ============================================================================

echo.
echo  --- TRANSCRIPTION + DIRECTION ---
echo  Defaults: lang=!LANG!  mode=!DIR_MODE!  clips=!CLIP_MODE!  duration=!CLIP_MIN!-!CLIP_MAX!s
set "TD_CHANGE="
set /p "TD_CHANGE=  Accept? [Enter=ok / 2=change]: "
if "!TD_CHANGE!"=="2" (
    echo.
    echo  Language:
    echo    [1] ru  [2] en  [3] es  [4] de  [5] fr  [6] it  [7] pt  [8] zh  [9] pl
    set "LANG_SEL="
    set /p "LANG_SEL=  Select [1-9, Enter=keep !LANG!]: "
    if "!LANG_SEL!"=="1" set "LANG=ru"
    if "!LANG_SEL!"=="2" set "LANG=en"
    if "!LANG_SEL!"=="3" set "LANG=es"
    if "!LANG_SEL!"=="4" set "LANG=de"
    if "!LANG_SEL!"=="5" set "LANG=fr"
    if "!LANG_SEL!"=="6" set "LANG=it"
    if "!LANG_SEL!"=="7" set "LANG=pt"
    if "!LANG_SEL!"=="8" set "LANG=zh"
    if "!LANG_SEL!"=="9" set "LANG=pl"
    echo.
    echo  Direction mode:
    echo    [1] 1-pass ^(fast, up to ~200 clips^)
    echo    [2] 2-pass ^(better quality, chunked, 200+ clips^)
    set "DM_SEL="
    set /p "DM_SEL=  Select [1/2, Enter=keep !DIR_MODE!]: "
    if "!DM_SEL!"=="1" ( set "DIR_MODE=1-pass" & set "GEMINI_TWO_PASS_VAL=false" )
    if "!DM_SEL!"=="2" ( set "DIR_MODE=2-pass" & set "GEMINI_TWO_PASS_VAL=true" )
    echo.
    echo  Clip type:
    echo    [1] video     ^(Veo3 fragments, !CLIP_MIN!-!CLIP_MAX!s^)
    echo    [2] slideshow ^(static images, 2-7s^)
    set "CM_SEL="
    set /p "CM_SEL=  Select [1/2, Enter=keep !CLIP_MODE!]: "
    if "!CM_SEL!"=="2" set "CLIP_MODE=slideshow"
    if "!CM_SEL!"=="1" set "CLIP_MODE=video"
    echo.
    set /p "CLIP_MIN=  Min clip duration [Enter=!CLIP_MIN!]: "
    set /p "CLIP_MAX=  Max clip duration [Enter=!CLIP_MAX!]: "
)

REM ============================================================================
REM 4. IMAGE GENERATION
REM ============================================================================

echo.
echo  --- IMAGE GENERATION ---
echo    [1] FastGen    (Gemini/GemPix/Grok/Narwhal)
echo    [2] VeoNonStop (Imagen/Banana)
echo    [3] Skip       (for text-to-video, no images needed)
echo.
set "IMG_GEN=1"
set /p "IMG_GEN=  Select [1/2/3, Enter=1]: "
if "!IMG_GEN!"=="" set "IMG_GEN=1"

set "VEO_IMGGEN_MODE=banana"

if "!IMG_GEN!"=="1" (
    echo.
    echo  --- FastGen settings ---
    echo  Defaults: model=!FASTGEN_MODEL_VAL!  aspect=!FASTGEN_ASPECT_VAL!  parallel=!FASTGEN_PARALLEL_VAL!
    set "FG_CHANGE="
    set /p "FG_CHANGE=  Accept? [Enter=ok / 2=change]: "
    if "!FG_CHANGE!"=="2" (
        echo.
        echo  FastGen model:
        echo    [1] GEMINI     [2] GEM_PIX_2  [3] GEM_PIX
        echo    [4] GROK       [5] NARWHAL    [6] IMAGEN_3_5
        set "FGM_SEL="
        set /p "FGM_SEL=  Select [1-6, Enter=keep !FASTGEN_MODEL_VAL!]: "
        if "!FGM_SEL!"=="1" set "FASTGEN_MODEL_VAL=GEMINI"
        if "!FGM_SEL!"=="2" set "FASTGEN_MODEL_VAL=GEM_PIX_2"
        if "!FGM_SEL!"=="3" set "FASTGEN_MODEL_VAL=GEM_PIX"
        if "!FGM_SEL!"=="4" set "FASTGEN_MODEL_VAL=GROK"
        if "!FGM_SEL!"=="5" set "FASTGEN_MODEL_VAL=NARWHAL"
        if "!FGM_SEL!"=="6" set "FASTGEN_MODEL_VAL=IMAGEN_3_5"
        echo.
        echo  Aspect ratio:
        echo    [1] landscape  [2] portrait  [3] square
        set "FGA_SEL="
        set /p "FGA_SEL=  Select [1-3, Enter=keep !FASTGEN_ASPECT_VAL!]: "
        if "!FGA_SEL!"=="1" set "FASTGEN_ASPECT_VAL=landscape"
        if "!FGA_SEL!"=="2" set "FASTGEN_ASPECT_VAL=portrait"
        if "!FGA_SEL!"=="3" set "FASTGEN_ASPECT_VAL=square"
        echo.
        set /p "FASTGEN_PARALLEL_VAL=  Parallel workers [Enter=!FASTGEN_PARALLEL_VAL!]: "
    )
)

if "!IMG_GEN!"=="2" (
    echo.
    echo  --- VeoNonStop image model ---
    echo    [1] Banana Pro
    echo    [2] Banana Pro + style-reference ^(iz ref/^)
    echo    [3] Imagen 3.5
    echo.
    set "VIM_SEL=1"
    set /p "VIM_SEL=  Select [1/2/3, Enter=1]: "
    if "!VIM_SEL!"=="" set "VIM_SEL=1"
    if "!VIM_SEL!"=="1" set "VEO_IMGGEN_MODE=banana"
    if "!VIM_SEL!"=="2" set "VEO_IMGGEN_MODE=banana_ref"
    if "!VIM_SEL!"=="3" set "VEO_IMGGEN_MODE=imagen"
)

REM ============================================================================
REM 5. VIDEO GENERATION
REM ============================================================================

echo.
echo  --- VIDEO GENERATION ---

set "POST_ACTION=skip"
set "PROMPT_MODE=single"

if "!IMG_GEN!"=="3" (
    echo    [1] Text-to-video ^(t2v^)
    echo    [2] Text-to-video + references ^(t2v + ref/^)
    echo.
    set "VG_SEL=1"
    set /p "VG_SEL=  Select [1/2, Enter=1]: "
    if "!VG_SEL!"=="" set "VG_SEL=1"
    if "!VG_SEL!"=="1" set "POST_ACTION=t2v"
    if "!VG_SEL!"=="2" set "POST_ACTION=components"
) else (
    echo  Mode: image-to-video ^(i2v^) - animate generated images
    if "!IMG_GEN!"=="1" set "POST_ACTION=fastgen_i2v"
    if "!IMG_GEN!"=="2" set "POST_ACTION=veo_i2v"
    
    echo.
    echo  Prompt mode:
    echo    [1] Single prompt for all clips ^(default - faster, consistent style^)
    echo    [2] Per-clip prompts from prompts.txt ^(original Gemini prompts^)
    echo.
    set "PROMPT_SEL=1"
    set /p "PROMPT_SEL=  Select [1/2, Enter=1]: "
    if "!PROMPT_SEL!"=="" set "PROMPT_SEL=1"
    if "!PROMPT_SEL!"=="1" set "PROMPT_MODE=single"
    if "!PROMPT_SEL!"=="2" set "PROMPT_MODE=perclip"
)

echo.
echo  --- Video settings ---
echo  Defaults: ratio=!VEO_RATIO!  parallel=!VEO_PARALLEL! prompts=!PROMPT_MODE!
set "VG_CHANGE="
set /p "VG_CHANGE=  Accept? [Enter=ok / 2=change]: "
if "!VG_CHANGE!"=="2" (
    echo.
    echo  Aspect ratio:
    echo    [1] 16:9  [2] 9:16  [3] 1:1
    set "VR_SEL="
    set /p "VR_SEL=  Select [1-3, Enter=keep !VEO_RATIO!]: "
    if "!VR_SEL!"=="1" set "VEO_RATIO=16:9"
    if "!VR_SEL!"=="2" set "VEO_RATIO=9:16"
    if "!VR_SEL!"=="3" set "VEO_RATIO=1:1"
    echo.
    set /p "VEO_PARALLEL=  Parallel workers [Enter=!VEO_PARALLEL!]: "
    echo.
    echo  Prompt mode:
    echo    [1] Single prompt for all clips
    echo    [2] Per-clip prompts from prompts.txt
    echo.
    set "PROMPT_SEL=1"
    set /p "PROMPT_SEL=  Select [1/2, Enter=1]: "
    if "!PROMPT_SEL!"=="" set "PROMPT_SEL=1"
    if "!PROMPT_SEL!"=="1" set "PROMPT_MODE=single"
    if "!PROMPT_SEL!"=="2" set "PROMPT_MODE=perclip"
)

REM ============================================================================
REM 6. RENDER & CONCAT SETTINGS
REM ============================================================================

echo.
echo  --- RENDER READY VIDEO ---
echo  Defaults: 720p fast, watermark=as is, keep=no
set "RC_CHANGE="
set /p "RC_CHANGE=  Accept? [Enter=ok / 2=change]: "
if "!RC_CHANGE!"=="2" (
    echo.
    echo  Render mode:
    echo    [1] 720p без перекода, быстро ^(default^)
    echo    [2] 1080p с перекодом
    echo.
    set "RENDER_MODE=1"
    set /p "RENDER_MODE=  Select [1/2, Enter=1]: "
    if "!RENDER_MODE!"=="" set "RENDER_MODE=1"

    echo.
    echo  Watermark:
    echo    [1] Оставить как есть ^(default^)
    echo    [2] Закрыть логотипом ^(положите logo.png в корень проекта^)
    echo    [3] Закрыть шторами ^(blur borders^)
    echo.
    set "WATERMARK_MODE=1"
    set /p "WATERMARK_MODE=  Select [1/2/3, Enter=1]: "
    if "!WATERMARK_MODE!"=="" set "WATERMARK_MODE=1"

    echo.
    echo  Keep retiming files:
    echo    [1] Да, оставить ^(temp_processed/^)
    echo    [2] Нет, удалить после склейки ^(default^)
    echo.
    set "KEEP_FILES=2"
    set /p "KEEP_FILES=  Select [1/2, Enter=2]: "
    if "!KEEP_FILES!"=="" set "KEEP_FILES=2"
) else (
    REM Defaults
    set "RENDER_MODE=1"
    set "WATERMARK_MODE=1"
    set "KEEP_FILES=2"
)

REM Set values based on selection
set "RENDER_DESC=720p fast"
set "CONCAT_FLAGS=--force-amd --veo-audio-inline"
if "!RENDER_MODE!"=="2" (
    set "RENDER_DESC=1080p re-encode"
    set "CONCAT_FLAGS=--force-amd --force-reprocess --veo-audio-inline"
)

set "WATERMARK_DESC=as is"
set "LOGO_FLAG="
set "BLUR_FLAG="
if "!WATERMARK_MODE!"=="2" (
    set "WATERMARK_DESC=logo overlay"
    set "LOGO_FLAG=--logo logo.png"
)
if "!WATERMARK_MODE!"=="3" (
    set "WATERMARK_DESC=blur borders"
    set "BLUR_FLAG=--blur-borders"
)

set "KEEP_DESC=no"
set "NO_CLEANUP_FLAG="
if "!KEEP_FILES!"=="1" (
    set "KEEP_DESC=yes"
    set "NO_CLEANUP_FLAG=--no-cleanup"
)

REM Build full concat flags
set "FULL_CONCAT_FLAGS=!CONCAT_FLAGS!"
if "!LOGO_FLAG!" neq "" set "FULL_CONCAT_FLAGS=!FULL_CONCAT_FLAGS! !LOGO_FLAG!"
if "!BLUR_FLAG!" neq "" set "FULL_CONCAT_FLAGS=!FULL_CONCAT_FLAGS! !BLUR_FLAG!"
if "!NO_CLEANUP_FLAG!" neq "" set "FULL_CONCAT_FLAGS=!FULL_CONCAT_FLAGS! !NO_CLEANUP_FLAG!"

set "CONCAT_DESC=!RENDER_DESC!, watermark=!WATERMARK_DESC!, keep=!KEEP_DESC!"

REM ============================================================================
REM 7. SUMMARY
REM ============================================================================

echo.
echo ================================================================================
echo  PIPELINE SUMMARY
echo ================================================================================
echo.

if "!START_POINT!"=="1" (
    set "START_DESC=From script ^(TTS: !TTS_SERVICE_VAL! / !TTS_MODEL_VAL!^)"
) else (
    set "START_DESC=From audio ^(skip TTS^)"
)

if "!IMG_GEN!"=="1" set "IMG_DESC=FastGen (!FASTGEN_MODEL_VAL!, !FASTGEN_ASPECT_VAL!, x!FASTGEN_PARALLEL_VAL!)"
if "!IMG_GEN!"=="2" set "IMG_DESC=VeoNonStop images (!VEO_IMGGEN_MODE!)"
if "!IMG_GEN!"=="3" set "IMG_DESC=Skip (t2v mode)"

if "!POST_ACTION!"=="fastgen_i2v" set "VID_DESC=FastGen images + i2v"
if "!POST_ACTION!"=="veo_i2v" set "VID_DESC=VeoNonStop images + i2v"
if "!POST_ACTION!"=="t2v" set "VID_DESC=Text-to-video (t2v)"
if "!POST_ACTION!"=="components" set "VID_DESC=Text-to-video + refs (components)"

set "PROMPT_DESC="
if "!PROMPT_MODE!"=="single" set "PROMPT_DESC= (single prompt)"
if "!PROMPT_MODE!"=="perclip" set "PROMPT_DESC= (per-clip)"

echo  Start:       !START_DESC!
echo  Language:    !LANG!
echo  Direction:   !DIR_MODE!
echo  Clips:       !CLIP_MODE! (!CLIP_MIN!-!CLIP_MAX!s)
echo  Image gen:   !IMG_DESC!
echo  Video gen:   !VID_DESC!!PROMPT_DESC! (ratio=!VEO_RATIO!, x!VEO_PARALLEL!)
echo  Render:      !RENDER_DESC!
echo  Watermark:   !WATERMARK_DESC!
echo  Keep files:  !KEEP_DESC!
echo  Prompts:     !PROMPT_MODE!
echo.
echo ================================================================================

set "CONFIRM=1"
set /p "CONFIRM=  Start pipeline? [Enter=start / 2=cancel]: "
if "!CONFIRM!"=="2" (
    echo  Cancelled.
    pause
    exit /b
)

REM ============================================================================
REM SET ENV VARS (override .env defaults for Python)
REM ============================================================================

set "ASSEMBLYAI_LANGUAGE_CODE=!LANG!"
set "GEMINI_TWO_PASS=!GEMINI_TWO_PASS_VAL!"
set "VIDEO_CLIP_MIN_DURATION=!CLIP_MIN!"
set "VIDEO_CLIP_MAX_DURATION=!CLIP_MAX!"
set "FASTGEN_MODEL=!FASTGEN_MODEL_VAL!"
set "FASTGEN_ASPECT_RATIO=!FASTGEN_ASPECT_VAL!"
set "FASTGEN_MAX_PARALLEL=!FASTGEN_PARALLEL_VAL!"
set "VEONONSTOP_ASPECT_RATIO=!VEO_RATIO!"
set "VEONONSTOP_MAX_PARALLEL=!VEO_PARALLEL!"
set "VEONONSTOP_IMGGEN_MODE=!VEO_IMGGEN_MODE!"
set "TTS_SERVICE=!TTS_SERVICE_VAL!"
set "TTS_MAT3U_MODEL_ID=!TTS_MODEL_VAL!"
set "TTS_MAT3U_SPLIT_TYPE=!TTS_SPLIT_VAL!"

REM ============================================================================
REM EXECUTE PIPELINE
REM ============================================================================

echo.
echo ================================================================================
echo  STARTING PIPELINE...
echo ================================================================================
echo.
echo [EXECUTE] Starting pipeline at %DATE% %TIME% >> "%LOG_FILE%"

set "TWO_PASS_FLAG="
if /i "!GEMINI_TWO_PASS_VAL!"=="true" set "TWO_PASS_FLAG=--two-pass"

set "PROMPT_MODE_FLAG="
if "!PROMPT_MODE!"=="perclip" set "PROMPT_MODE_FLAG=--prompt-mode perclip"

if "!START_POINT!"=="1" (
    echo  [Stage 0] TTS + full pipeline...
    echo [STAGE 0] TTS + pipeline >> "%LOG_FILE%"
    echo.
    python "agent\tools\tts_runner.py" --mode silent --clip-mode !CLIP_MODE! --post-action !POST_ACTION! !PROMPT_MODE_FLAG!
) else (
    echo  [Stage 1+] Transcription + Direction + Generation...
    echo [STAGE 1+] Transcription + Direction + Generation >> "%LOG_FILE%"
    echo.
    python "agent\agent.py" process --run --language !LANG! !TWO_PASS_FLAG! --clip-mode !CLIP_MODE! --clip-min !CLIP_MIN! --clip-max !CLIP_MAX! --post-action !POST_ACTION! !PROMPT_MODE_FLAG!
)

if errorlevel 1 (
    echo.
    echo  [ERROR] Pipeline stages failed!
    echo [ERROR] Pipeline failed >> "%LOG_FILE%"
    pause
    exit /b 1
)

REM ============================================================================
REM CHECK FOR FAILED CLIPS — pause before concat if incomplete
REM ============================================================================

set "HAS_FAILURES=0"
for /d %%P in (projects\*) do (
    if exist "%%P\has_failed_clips.flag" (
        set "HAS_FAILURES=1"
        echo.
        echo ================================================================================
        echo  WARNING: Project %%~nxP has failed clips!
        echo ================================================================================
        if exist "%%P\failed_prompts.txt" (
            type "%%P\failed_prompts.txt"
        )
        echo.
        echo  Some images/videos were not generated after all retry cycles.
        echo  You can manually generate the missing files and place them in:
        echo    %%P\generated\    ^(images: NNN.png^)
        echo    %%P\vid_img\      ^(videos: NNN.mp4^)
        echo.
    )
)

if "!HAS_FAILURES!"=="1" (
    echo ================================================================================
    echo  Pipeline paused. Add missing files manually, then continue.
    echo ================================================================================
    echo.
    echo    [1] Continue to concat ^(I added the missing files^)
    echo    [2] Continue to concat ^(skip missing, concat what we have^)
    echo    [3] Abort pipeline
    echo.
    set "FAIL_CHOICE=0"
    set /p "FAIL_CHOICE=  Select [1/2/3]: "
    if "!FAIL_CHOICE!"=="3" (
        echo  Aborted.
        pause
        exit /b 1
    )
    REM Cleanup flag files so they don't block next run
    for /d %%P in (projects\*) do (
        if exist "%%P\has_failed_clips.flag" del "%%P\has_failed_clips.flag"
    )
)

REM ============================================================================
REM AUTO-CONCAT: run video_concat for each project with vid_img/
REM ============================================================================

echo.
echo ================================================================================
echo  AUTO-CONCAT: assembling final videos...
echo ================================================================================
echo.
echo [AUTO-CONCAT] Starting >> "%LOG_FILE%"
echo.
echo  Run auto-concat for all projects with vid_img/?
echo    [1] Yes - concat all projects ^(default^)
echo    [2] No - skip concat, do manually later
echo.
set "AUTO_CONCAT=1"
set /p "AUTO_CONCAT=  Select [1/2, Enter=1]: "
if "!AUTO_CONCAT!"=="" set "AUTO_CONCAT=1"

if "!AUTO_CONCAT!"=="2" (
    echo  Skipping auto-concat.
    goto :DONE_SECTION
)

set "CONCAT_COUNT=0"

for /d %%P in (projects\*) do (
    if exist "%%P\vid_img" (
        set "HAS_MP4=0"
        for %%F in ("%%P\*.mp4") do set "HAS_MP4=1"
        if "!HAS_MP4!"=="0" (
            if exist "%%P\montage_plan.json" (
                echo  [CONCAT] %%~nxP...
                pushd "%%P"
                python "..\..\video_concat.py" montage_plan.json -o "%%~nxP.mp4" -b 10M !FULL_CONCAT_FLAGS!
                if errorlevel 1 (
                    echo  [WARN] Concat failed for %%~nxP
                ) else (
                    echo  [OK] %%~nxP.mp4
                    set /a CONCAT_COUNT+=1
                )
                popd
            )
        ) else (
            echo  [SKIP] %%~nxP - mp4 already exists
        )
    )
)

echo.
echo  Concat results: !CONCAT_COUNT! video(s) assembled.
echo [CONCAT] Completed: !CONCAT_COUNT! videos >> "%LOG_FILE%"

:DONE_SECTION
REM ============================================================================
REM DONE
REM ============================================================================

echo.
echo ================================================================================
echo  PIPELINE COMPLETE!
echo ================================================================================
echo.
echo  Results in projects\ folders:
echo    - montage_plan.json   (montage plan)
echo    - *_prompts_*.txt     (image/video prompts)
echo    - generated\          (images)
echo    - vid_img\            (video fragments)
echo    - *.mp4               (final video)
echo.

echo [PIPELINE COMPLETE] >> "%LOG_FILE%"
echo ================================================================================ >> "%LOG_FILE%"

REM Show log file location
echo Log saved to: %LOG_FILE%
echo. >> "%LOG_FILE%"
echo ================================================================================ >> "%LOG_FILE%"
echo PIPELINE COMPLETE >> "%LOG_FILE%"
echo ================================================================================ >> "%LOG_FILE%"

pause
goto :EOF
