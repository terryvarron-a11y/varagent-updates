"""
detect_ref_mode.py - print auto-detected ref mode for a project
Usage: python detect_ref_mode.py <project_name>
Output (stdout): flow / whisk / ask / none
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from modules.fastgen import scan_references, detect_reference_mode

if len(sys.argv) < 2:
    print("none")
    sys.exit(0)

project_name = sys.argv[1]
base_dir = Path(__file__).parent.parent
project_dir = base_dir / 'projects' / project_name

refs = scan_references(str(project_dir))
mode = detect_reference_mode(refs)
print(mode if mode else "none")
