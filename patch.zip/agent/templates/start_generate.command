#!/bin/bash
# START_GENERATE.COMMAND - FastGen image generation (macOS - double click)
# Run: double-click this file in Finder

PROJECT_NAME="{project_name}"
DEFAULT_MODEL="{default_model}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
AGENT_DIR="$(cd "$SCRIPT_DIR/../../agent" && pwd)"

# Auto-set execute permissions
chmod +x *.command *.sh 2>/dev/null
[ -f "$SCRIPT_DIR/.venv/bin/activate" ] && source "$SCRIPT_DIR/.venv/bin/activate"

# Open Terminal.app for interactive mode
if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e "tell app \"Terminal\" to do script \"cd '$SCRIPT_DIR' && exec '$0'\""
    exit 0
fi

clear

echo ""
echo "================================================================================"
echo " STAGE 3: IMAGE GENERATION (FastGen)"
echo " Project: $PROJECT_NAME"
echo "================================================================================"
echo ""

# ============================================================================
# ENGINE SELECTION
# ============================================================================

echo " Default engine (from .env): $DEFAULT_MODEL"
echo ""
echo " Select engine:"
echo "   [1] NANO PRO FLOW    GEM_PIX_2   - best quality, Flow API"
echo "   [2] NANO BANANA 2    NARWHAL     - Nano Banana 2, Flow API v4"
echo "   [3] NANO PRO GEMINI  GEMINI      - Gemini native, fast"
echo "   [4] GROK             GROK        - Grok, 4 variants"
echo "   [5] NANO             GEM_PIX     - basic, Flow API"
echo "   [6] IMAGEN_3_5_FLOW  IMAGEN_3_5  - Imagen 4, Flow API"
echo "   [7] WHISK            WHISK       - Whisk, categorized refs"
echo ""
MODEL="$DEFAULT_MODEL"
echo -n "  Engine [1-7] (Enter = $DEFAULT_MODEL): "
read MODEL_CHOICE
case "$MODEL_CHOICE" in
    1) MODEL="GEM_PIX_2" ;;
    2) MODEL="NARWHAL" ;;
    3) MODEL="GEMINI" ;;
    4) MODEL="GROK" ;;
    5) MODEL="GEM_PIX" ;;
    6) MODEL="IMAGEN_3_5" ;;
    7) MODEL="WHISK" ;;
esac
echo "   Selected: $MODEL"
echo ""

# ============================================================================
# ASPECT RATIO
# ============================================================================

echo " Select aspect ratio:"
echo "   [1] landscape  16:9, recommended for video"
echo "   [2] portrait   9:16"
echo "   [3] square     1:1"
echo ""
ASPECT="landscape"
echo -n "  Aspect [1/2/3] (Enter = landscape): "
read ASPECT_CHOICE
case "$ASPECT_CHOICE" in
    2) ASPECT="portrait" ;;
    3) ASPECT="square" ;;
esac
echo "   Selected: $ASPECT"
echo ""

# ============================================================================
# PARALLEL THREADS
# ============================================================================

PARALLEL=10
echo -n "  Parallel [1-10] (Enter = 10): "
read PARALLEL_INPUT
[ -n "$PARALLEL_INPUT" ] && PARALLEL="$PARALLEL_INPUT"
echo "   Selected: $PARALLEL"
echo ""

# ============================================================================
# CLIP IDs (optional)
# ============================================================================

IDS_ARG=""
echo -n "  Clip IDs (e.g. 1,2,3 or Enter for all): "
read IDS_INPUT
if [ -n "$IDS_INPUT" ]; then
    IDS_ARG="--ids $IDS_INPUT"
    echo "   Clips: $IDS_INPUT"
else
    echo "   Clips: ALL"
fi
echo ""

# ============================================================================
# REFERENCE MODE
# ============================================================================

MODE_ARG=""
if [ -d "$SCRIPT_DIR/ref" ]; then
    echo " ref/ folder found!"
    echo "   [1] Auto-detect"
    echo "   [2] Flow  - flat refs, up to 10"
    echo "   [3] Whisk - subject/scene/style categories"
    echo ""
    echo -n "  Ref mode [1/2/3] (Enter = auto): "
    read MODE_CHOICE
    case "$MODE_CHOICE" in
        2) MODE_ARG="--mode flow" ;;
        3) MODE_ARG="--mode whisk" ;;
    esac
    echo ""
else
    echo " No ref/ folder - generating without references"
    echo ""
fi

# ============================================================================
# API KEY SELECTION (with quota pre-check)
# ============================================================================

IDS_FOR_QUOTA=""
[ -n "$IDS_INPUT" ] && IDS_FOR_QUOTA="--ids $IDS_INPUT"

BACKUP_ARG=""
HAS_BK=$(cd "$AGENT_DIR" && python3 -c "import config; print('yes' if config.FASTGEN_API_KEY_BACKUP else '')" 2>/dev/null)

if [ -n "$HAS_BK" ]; then
    MAIN_Q="?"
    BK_Q="?"
    TMPQM=$(mktemp)
    TMPQB=$(mktemp)
    cd "$AGENT_DIR"
    python3 quota_check.py "$PROJECT_NAME" $IDS_FOR_QUOTA > "$TMPQM" 2>/dev/null
    python3 quota_check.py "$PROJECT_NAME" $IDS_FOR_QUOTA --backup-key > "$TMPQB" 2>/dev/null
    cd "$SCRIPT_DIR"
    while IFS='=' read -r KEY VALUE; do [ "$KEY" = "remaining" ] && MAIN_Q="$VALUE"; done < "$TMPQM"
    while IFS='=' read -r KEY VALUE; do [ "$KEY" = "remaining" ] && BK_Q="$VALUE"; done < "$TMPQB"
    rm -f "$TMPQM" "$TMPQB"
    echo " API key:"
    echo "   [1] Main key    quota: $MAIN_Q remaining  -- default --"
    echo "   [2] Backup key  quota: $BK_Q remaining"
    echo ""
    echo -n "  Key [1/2] (Enter = main): "
    read KEY_CHOICE
    if [ "$KEY_CHOICE" = "2" ]; then
        BACKUP_ARG="--backup-key"
        echo "   Selected: BACKUP"
    else
        echo "   Selected: main"
    fi
    echo ""
fi

# ============================================================================
# QUOTA CHECK
# ============================================================================

TMPQ=$(mktemp)

cd "$AGENT_DIR"
python3 quota_check.py "$PROJECT_NAME" $IDS_FOR_QUOTA $BACKUP_ARG > "$TMPQ" 2>/dev/null
QC_EXIT=$?
cd "$SCRIPT_DIR"

QC_REMAINING="?"
QC_NEEDED="?"
while IFS='=' read -r KEY VALUE; do
    [ "$KEY" = "remaining" ] && QC_REMAINING="$VALUE"
    [ "$KEY" = "needed" ] && QC_NEEDED="$VALUE"
done < "$TMPQ"
rm -f "$TMPQ"

if [ $QC_EXIT -eq 2 ]; then
    echo "================================================================================"
    echo " [WARN] QUOTA: remaining=$QC_REMAINING, needed=$QC_NEEDED - NOT ENOUGH"
    echo "   [1] Use BACKUP API key - FASTGEN_API_KEY_BACKUP from .env"
    echo "   [2] Continue with MAIN key anyway -- default --"
    echo "   [3] Cancel"
    echo "================================================================================"
    echo ""
    echo -n "  Choice [1/2/3] (Enter = main key): "
    read QC_CHOICE
    case "$QC_CHOICE" in
        1) BACKUP_ARG="--backup-key" ;;
        3) echo " Cancelled."; echo "Press Enter to exit..."; read; exit 0 ;;
    esac
    echo ""
elif [ $QC_EXIT -eq 3 ]; then
    echo "================================================================================"
    echo " [WARN] QUOTA: remaining=$QC_REMAINING, needed=$QC_NEEDED - NOT ENOUGH"
    echo "        No backup key - FASTGEN_API_KEY_BACKUP not set"
    echo "   [1] Continue with main key anyway -- default --"
    echo "   [2] Cancel"
    echo "================================================================================"
    echo ""
    echo -n "  Choice [1/2] (Enter = continue): "
    read QC_CHOICE
    [ "$QC_CHOICE" = "2" ] && echo " Cancelled." && echo "Press Enter to exit..." && read && exit 0
    echo ""
else
    echo " Quota: $QC_REMAINING remaining / $QC_NEEDED needed   [OK]"
    echo ""
fi

if [ "$BACKUP_ARG" = "--backup-key" ]; then
    TMPQ2=$(mktemp)
    cd "$AGENT_DIR"
    python3 quota_check.py "$PROJECT_NAME" $IDS_FOR_QUOTA --backup-key > "$TMPQ2" 2>/dev/null
    cd "$SCRIPT_DIR"
    BK_REMAINING="?"
    while IFS='=' read -r KEY VALUE; do
        [ "$KEY" = "remaining" ] && BK_REMAINING="$VALUE"
    done < "$TMPQ2"
    rm -f "$TMPQ2"
    echo " Backup key quota: $BK_REMAINING remaining / $QC_NEEDED needed"
    echo ""
fi

# ============================================================================
# CONFIRM
# ============================================================================

echo "================================================================================"
echo " SUMMARY:"
echo "   Project:  $PROJECT_NAME"
echo "   Engine:   $MODEL"
echo "   Aspect:   $ASPECT"
echo "   Parallel: $PARALLEL"
[ -n "$IDS_INPUT" ] && echo "   Clips:    $IDS_INPUT" || echo "   Clips:    ALL"
[ -n "$MODE_ARG" ] && echo "   Refs:     $MODE_ARG" || echo "   Refs:     auto"
[ -n "$BACKUP_ARG" ] && echo "   API key:  BACKUP" || echo "   API key:  main"
[ -n "$BACKUP_ARG" ] && echo "   Quota:    $BK_REMAINING remaining / $QC_NEEDED needed [BACKUP]" || echo "   Quota:    $QC_REMAINING remaining / $QC_NEEDED needed"
echo "================================================================================"
echo ""
echo "   [1] Start  (po umolchaniyu)"
echo "   [2] Cancel"
echo ""
read -p "  Vybor [1/2] (Enter = Start): " CONFIRM
if [ "$CONFIRM" = "2" ]; then
    echo " Cancelled."
    echo "Press Enter to exit..." && read
    exit 0
fi

echo ""
echo " Starting generation..."
echo ""

cd "$AGENT_DIR"

python3 agent.py generate \
    --project "$PROJECT_NAME" \
    --model "$MODEL" \
    --aspect "$ASPECT" \
    --parallel "$PARALLEL" \
    $IDS_ARG $MODE_ARG $BACKUP_ARG

GEN_EXIT=$?

echo ""
echo "================================================================================"
if [ $GEN_EXIT -ne 0 ]; then
    echo " [ERROR] Generation failed. Check log above."
else
    echo " [OK] DONE. Output: $SCRIPT_DIR/generated/"
fi
echo "================================================================================"
echo ""
echo "Press Enter to exit..."
read
exit $GEN_EXIT
