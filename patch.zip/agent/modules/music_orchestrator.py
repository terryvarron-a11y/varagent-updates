"""
Music Orchestrator — генерирует MP3-треки по music_plan.json через SunoClient.

Suno даёт 2 варианта на 1 запрос. Сохраняем оба в music/raw/<id>/<v1|v2>.mp3,
выбранный вариант копируем в music/<id>.mp3 (по умолчанию v1, можно поменять
в GUI Music Review).

После генерации обновляет music_plan.json — добавляет поля:
  tracks[i].suno_clip_ids   — оба clip_id от Suno
  tracks[i].suno_durations  — длительности обоих
  tracks[i].selected_variant — 1 или 2 (default=1)
  tracks[i].file            — путь к выбранному mp3 (относительно проекта)
"""
from __future__ import annotations

import json
import logging
import os
import random
import shutil
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Optional, List, Dict, Any

import config
from modules.music_fallback import generate_fallback_tracks
from modules.music_plan_utils import normalize_music_plan
from modules.suno_client import (
    SunoClient, SunoAuthError, SunoQuotaError, SunoAPIError, SunoCaptchaError,
    clamp_suno_duration,
    normalize_suno_model, prepare_suno_generation_fields,
)


# Suno даёт ~3.5 минуты на трек. Если эпизод длиннее — нужен continuation
# через continue_clip_id, либо несколько треков склеить crossfade в concat.
SUNO_MAX_TRACK_DURATION = 240  # security: треки длиннее 4 минут — warning, но не блок

# Запас к длине слота при заказе трека у Suno: лучше получить чуть
# длиннее и подрезать в миксе, чем зацикливать короткий.
MUSIC_DURATION_MARGIN = 1.05

# Ниже какой доли слота склеивать оба варианта вместо петли одного.
# 120с на слот 140с (86%) — петля добавит всего 20с, её не слышно.
# 55с на слот 122с (45%) — петля повторится дважды, и это заметно.
MUSIC_STITCH_BELOW = 0.7


def _env_int(name: str, default: int) -> int:
    """Настройка из .env напрямую (config.py грузит dotenv при импорте).

    Читаем мимо config, чтобы новые ключи работали без правки config.py."""
    raw = getattr(config, name, None)
    if raw in (None, ''):
        raw = os.getenv(name)
    try:
        return int(str(raw).strip())
    except (TypeError, ValueError):
        return default


def _audio_duration(path: Path) -> Optional[float]:
    """Длительность аудио через ffprobe. None — нечем измерить."""
    ffprobe = shutil.which('ffprobe')
    if not ffprobe:
        return None
    try:
        out = subprocess.run(
            [ffprobe, '-v', 'error', '-show_entries', 'format=duration',
             '-of', 'csv=p=0', str(path)],
            capture_output=True, text=True, timeout=30)
        return round(float((out.stdout or '').strip()), 2)
    except Exception:
        return None


def _pick_best_variant(durations: List[float], available: List[int],
                       slot_seconds: float) -> int:
    """Какой из скачанных вариантов класть в music/<id>.mp3.

    Suno на одну генерацию отдаёт два варианта РАЗНОЙ длины (живой пример:
    23.8с и 140с). Микшер зацикливает короткий под слот, поэтому берём:
      * самый короткий из тех, что покрывают слот целиком (его просто
        подрежут — петли не слышно);
      * если слот не покрывает никто — самый длинный (минимум повторов).
    Длительности неизвестны (0) — остаётся первый доступный.
    """
    if not available:
        raise ValueError("no downloaded variants")

    def dur(idx: int) -> float:
        try:
            return float(durations[idx - 1])
        except (IndexError, TypeError, ValueError):
            return 0.0

    known = [i for i in available if dur(i) > 0]
    if not known:
        return available[0]
    covering = [i for i in known if dur(i) >= float(slot_seconds or 0)]
    if covering:
        return min(covering, key=dur)
    return max(known, key=dur)


class MusicOrchestrator:
    """Гонит SunoClient по music_plan.json"""

    def __init__(
        self,
        project_dir: str | Path,
        plan_path: Optional[str | Path] = None,
        browser: Optional[str] = None,
        model: Optional[str] = None,
        parallel: int = 1,
    ):
        self.project_dir = Path(project_dir)
        self.plan_path = Path(plan_path) if plan_path else (self.project_dir / 'music_plan.json')
        self.browser = browser or getattr(config, 'SUNO_COOKIE_BROWSER', 'firefox')
        self.model = normalize_suno_model(model or getattr(config, 'SUNO_MODEL', 'chirp-fenix'))
        self.parallel = max(1, parallel)

        self.music_dir = self.project_dir / 'music'
        self.music_raw_dir = self.music_dir / 'raw'
        self.music_dir.mkdir(parents=True, exist_ok=True)
        self.music_raw_dir.mkdir(parents=True, exist_ok=True)
        self.audit_log_path = self.project_dir / 'music_generation.log'
        self._audit_lock = threading.Lock()

        self._client: Optional[SunoClient] = None
        self._client_lock = threading.Lock()

    def _get_client(self) -> SunoClient:
        with self._client_lock:
            if self._client is None:
                self._client = SunoClient(browser=self.browser)
            return self._client

    # =========================================================================
    # Public API
    # =========================================================================

    def generate_all(self, force: bool = False) -> Dict[str, Any]:
        """
        Запускает генерацию всех треков из music_plan.json.

        force=True перегенерирует уже готовые треки (по умолчанию пропускаем).

        Возвращает summary: {ok, skipped, failed, total}.
        """
        plan = self._load_plan()
        if self._quarantine_disabled_fallbacks(plan):
            self._save_plan(plan)
        original_count = len(plan.get('tracks', []))
        existing_music = any(self.music_dir.glob('*.mp3'))
        if force or not existing_music:
            plan = normalize_music_plan(
                plan,
                float(plan.get('audioDuration', 0) or 0),
                min_track_duration=getattr(config, 'MUSIC_MIN_TRACK_DURATION', 120),
                max_track_duration=getattr(config, 'MUSIC_MAX_TRACK_DURATION', 240),
                max_tracks=getattr(config, 'MUSIC_MAX_TRACKS', 10),
            )
        tracks = plan.get('tracks', [])
        self._reset_audit_log(plan)
        if (force or not existing_music) and len(tracks) != original_count:
            print(
                f"   Music plan simplified: {original_count} -> {len(tracks)} tracks "
                f"(min {getattr(config, 'MUSIC_MIN_TRACK_DURATION', 120)}s, "
                f"max {getattr(config, 'MUSIC_MAX_TRACKS', 10)} total)"
            )
            self._save_plan(plan)
        if not tracks:
            print("⚠️  music_plan не содержит треков — нечего генерировать")
            return {'ok': 0, 'skipped': 0, 'failed': 0, 'total': 0}

        print(f"\n🎵 Music Orchestrator: {len(tracks)} треков, browser={self.browser}, model={self.model}")
        provider = str(getattr(config, 'MUSIC_PROVIDER', 'suno') or 'suno').strip().lower()
        if provider in {'procedural', 'local_library', 'local_sound_library',
                        'safe_stock', 'safe', 'stock', 'stock_safe', 'pixabay', 'pexels'}:
            from modules.music_safe_stock import generate_safe_music_for_project

            print(f"\nMusic provider: {provider} (Local Sound Library)")
            return generate_safe_music_for_project(
                self.project_dir,
                plan_path=self.plan_path,
                provider=provider,
                force=force,
            )

        tracks_to_generate = [
            t for t in tracks
            if (t.get('genre') or '').lower() != 'silence'
            and (t.get('prompt') or '').strip()
            and (force or not (self.music_dir / self._track_filename(t.get('id'))).exists())
        ]
        suno_available = bool(tracks_to_generate)
        if tracks_to_generate:
            try:
                client = self._get_client()
                credits = client.get_credits()
                left = credits.get('total_credits_left', 0)
                need = len(tracks_to_generate) * 10  # 10 кредитов / запрос
                print(f"   Кредиты Suno: {left} (нужно ~{need})")
                if left < need:
                    print(f"   ⚠️  Недостаточно кредитов — некоторые треки не сгенерируются")
            except Exception as e:
                suno_available = False
                self._audit('SUNO_AUTH_FAILED', {
                    'browser': self.browser,
                    'model': self.model,
                    'error': f'{type(e).__name__}: {e}',
                })
                print(f"   ⚠️  Suno unavailable before generation: {e}")
        else:
            print("   All music files already exist - skipping Suno auth")

        ok = skipped = failed = 0
        results: List[Dict[str, Any]] = []

        if not suno_available:
            failed = len(tracks_to_generate)
        elif self.parallel > 1:
            print(f"   Параллельно: {self.parallel} потоков")
            with ThreadPoolExecutor(max_workers=self.parallel) as pool:
                futs = {
                    pool.submit(self._generate_one, t, force): t for t in tracks
                }
                for fut in as_completed(futs):
                    res = fut.result()
                    results.append(res)
                    if res['status'] == 'ok':       ok += 1
                    elif res['status'] == 'skipped': skipped += 1
                    else:                            failed += 1
        else:
            # Sleep между треками — Suno rate-limit ~6 запросов на сессию.
            # 30 сек между генерациями имитирует человеческий темп webapp.
            inter_track_sleep = int(getattr(__import__('config'), 'SUNO_INTER_TRACK_SLEEP', 30))
            for i, t in enumerate(tracks, 1):
                print(f"\n[{i}/{len(tracks)}] Track {t.get('id')} «{t.get('title') or t.get('mood', '')}»")
                res = self._generate_one(t, force)
                results.append(res)
                if res['status'] == 'ok':       ok += 1
                elif res['status'] == 'skipped': skipped += 1
                else:                            failed += 1
                failure_reason = str(res.get('reason', ''))
                if (
                    res.get('status') == 'failed'
                    and (
                        'token_validation_failed' in failure_reason
                        or 'rate_limited' in failure_reason
                        or 'Too many requests' in failure_reason
                    )
                ):
                    print("   ⚠️  Suno временно отклоняет Create-запросы — останавливаю генерацию, чтобы не добивать rate-limit")
                    break

                # Sleep между генерациями (rate-limit prevention).
                # Не нужен после skipped (трек уже был) и после последнего трека.
                if i < len(tracks) and res['status'] == 'ok' and inter_track_sleep > 0:
                    # Ровные паузы секунда-в-секунду — машинный почерк, на
                    # который Suno отвечает капчей. Разброс ±35% дешевле любых
                    # обходов: просто ведём себя как человек за webapp.
                    _pause = random.uniform(inter_track_sleep * 0.65,
                                            inter_track_sleep * 1.35)
                    print(f"   ⏱  Пауза {_pause:.0f}с (rate-limit prevention)")
                    time.sleep(_pause)

        # ── Ретраи упавших треков ────────────────────────────────────────
        # Suno регулярно роняет отдельную генерацию (таймаут клипа, 5xx,
        # rate-limit). Раньше такой трек просто исчезал, и его слот оставался
        # НЕМЫМ — на 30-минутном ролике это минуты тишины. Повторяем генерацию.
        retries = max(0, _env_int('MUSIC_TRACK_RETRIES', 1))
        captcha_cooldown = max(60, _env_int('MUSIC_CAPTCHA_COOLDOWN', 600))
        captcha_rounds_left = max(0, _env_int('MUSIC_CAPTCHA_RETRIES', 2))
        # ждать капчу имеет смысл, только если раунды повторов вообще есть
        if captcha_rounds_left:
            retries = max(retries, captcha_rounds_left)
        if suno_available and retries:
            by_id = {r['id']: r for r in results}
            for attempt in range(1, retries + 1):
                failed_tracks = [
                    t for t in tracks
                    if (by_id.get(t.get('id')) or {}).get('status') == 'failed'
                ]
                if not failed_tracks:
                    break
                print(f"\n   ♻️  Повтор генерации: {len(failed_tracks)} трек(ов), "
                      f"попытка {attempt}/{retries}")
                # Капча Cloudflare прилетает за частоту запросов. Сразу
                # повторять бессмысленно — выжидаем и пробуем снова; за
                # это время проверка обычно снимается сама.
                if any('captcha' in str((by_id.get(t.get('id')) or {}).get('reason', ''))
                       for t in failed_tracks):
                    if captcha_rounds_left <= 0:
                        print("   🛑 Suno всё ещё требует проверку Cloudflare — "
                              "пройдите её в браузере и перезапустите музыку")
                        break
                    captcha_rounds_left -= 1
                    print(f"   ⏳ Suno показал капчу — ждём "
                          f"{captcha_cooldown // 60} мин и пробуем снова "
                          f"(осталось заходов: {captcha_rounds_left + 1})",
                          flush=True)
                    self._audit('SUNO_CAPTCHA_COOLDOWN',
                                {'seconds': captcha_cooldown})
                    time.sleep(captcha_cooldown)
                for t in failed_tracks:
                    res = self._generate_one(t, force=True)
                    by_id[t.get('id')] = res
                    if res['status'] == 'ok':
                        ok += 1
                        failed = max(0, failed - 1)
                        print(f"   ✅ Track {t.get('id')}: со второго захода вышло")
            results = [by_id[k] for k in sorted(by_id)]

        # Обновить plan с результатами. Для skipped тоже сохраняем — это сохраняет
        # данные предыдущих успешных запусков при retry/догонке.
        results.sort(key=lambda r: r['id'])
        # по id, а не zip: при обрыве цикла (rate-limit break) списки разной
        # длины, и zip раньше приписывал треку чужой результат
        results_by_id = {r['id']: r for r in results}
        for t in sorted(tracks, key=lambda x: x.get('id', 0)):
            r = results_by_id.get(t.get('id'))
            if r and r['status'] in ('ok', 'skipped') and r.get('clip_ids'):
                t['suno_clip_ids'] = r['clip_ids']
                t['suno_durations'] = r['durations']
                # выбранный вариант берём из результата: если v1 не дошёл,
                # трек собран из v2, и микшер должен читать длительность v2
                t['selected_variant'] = r.get(
                    'selected_variant', t.get('selected_variant', 1))
                t['file'] = self._track_filename(t['id'])
        self._save_plan(plan)

        fallback_created = 0
        fallback_mode = str(
            getattr(config, 'MUSIC_FALLBACK_MODE', 'off') or 'off'
        ).strip().lower()
        fallback_enabled = bool(
            getattr(config, 'MUSIC_FALLBACK_ON_SUNO_FAIL', False)
        )
        if (
            fallback_enabled
            and fallback_mode == 'ffmpeg_ambient'
            and self._missing_music_count(tracks) > 0
        ):
            print("\n   Suno did not produce every track - creating local fallback beds for missing files")
            fb = generate_fallback_tracks(self.project_dir, plan, only_missing=True)
            fallback_created = int(fb.get('created', 0))
            if fallback_created:
                self._save_plan(plan)
        elif self._missing_music_count(tracks) > 0:
            # Пустой слот = тишина в ролике (на 30 минутах это могут быть
            # минуты немого видео). Лучше повторить соседний трек, чем молчать.
            filled = self._fill_missing_from_neighbours(tracks)
            if filled:
                self._save_plan(plan)
            if self._missing_music_count(tracks) > 0:
                print(
                    "\n   Suno did not produce every track - no synthetic audio was created; "
                    "concat will continue without missing music"
                )

        final_missing = self._missing_music_count(tracks)
        if force and not (
            fallback_enabled and fallback_mode == 'ffmpeg_ambient'
        ):
            final_missing = max(final_missing, failed)
        ready = max(0, len(tracks) - final_missing)
        print(
            f"\n✅ Music Orchestrator: ready={ready}, suno_ok={ok}, "
            f"skipped={skipped}, fallback={fallback_created}, missing={final_missing}"
        )
        self._audit('SUMMARY', {
            'ready': ready,
            'suno_ok': ok,
            'skipped': skipped,
            'fallback': fallback_created,
            'missing': final_missing,
        })
        return {
            'ok': ready,
            'skipped': skipped,
            'failed': final_missing,
            'fallback': fallback_created,
            'total': len(tracks),
        }

    # =========================================================================
    # Per-track generation
    # =========================================================================

    def _generate_one(self, track: Dict[str, Any], force: bool) -> Dict[str, Any]:
        tid = track.get('id')
        prompt = track.get('prompt', '').strip()
        tags = track.get('tags', '').strip()
        if track.get('intro_dynamic'):
            low_prompt = prompt.lower()
            # ВАЖНО: формулировки задают ХАРАКТЕР НАЧАЛА, но не форму трека.
            # Прежний набор («first 8-12 seconds are breathtaking, then settles
            # under narration») Suno читал как описание всего произведения и
            # выдавал джингл: замер 16.08.2026 — просили 130с, получили 21с и
            # 17с; тот же запрос без этих фраз дал 129.6с и 129.4с.
            intro_bits = []
            if 'energetic from the first second' not in low_prompt:
                intro_bits.append('energetic from the first second')
            if 'starts immediately' not in low_prompt:
                intro_bits.append('starts immediately with pulsing percussion')
            if 'no quiet opening' not in low_prompt:
                intro_bits.append('no silence before the music, no slow fade-in, no quiet opening')
            if 'full length' not in low_prompt:
                intro_bits.append('long continuous underscore that keeps playing '
                                  'at full length, no early ending, no outro')
            if intro_bits:
                prompt = ', '.join(intro_bits + [prompt])
            if 'dynamic intro' not in tags.lower():
                tags = ', '.join(
                    p for p in [
                        tags,
                        # без слов про «интро» — они укорачивают форму
                        'urgent, pulsing percussion, cinematic, instrumental, continuous',
                    ] if p
                )
        title = str(track.get('title') or f"Track {tid}").strip()
        if len(title) > 100:
            print(f"   ⚠️  Track {tid}: title too long ({len(title)} chars), truncating to 100 characters")
            title = title[:97].rstrip() + '...'
        genre = (track.get('genre') or '').lower()

        # Тишина: ничего не генерируем
        if genre == 'silence' or not prompt:
            print(f"   ⏸  Track {tid}: silence — skip")
            return {'id': tid, 'status': 'skipped', 'reason': 'silence', 'clip_ids': [], 'durations': []}

        target = self.music_dir / self._track_filename(tid)
        if target.exists() and not force:
            print(f"   ⏭  Track {tid}: {target.name} уже есть — skip (force=True для перегенерации)")
            return {'id': tid, 'status': 'skipped', 'reason': 'exists',
                    'clip_ids': track.get('suno_clip_ids', []),
                    'durations': track.get('suno_durations', [])}

        duration = float(track.get('endTime', 0)) - float(track.get('startTime', 0))
        if duration > SUNO_MAX_TRACK_DURATION:
            print(f"   ⚠️  Track {tid}: эпизод {duration:.0f}с > {SUNO_MAX_TRACK_DURATION}с (Suno даёт ~3.5 мин)")

        request_fields = prepare_suno_generation_fields(
            prompt,
            tags,
            instrumental=True,
            model=self.model,
        )
        self._audit('SUNO_REQUEST', {
            'track_id': tid,
            'title': title,
            'slot_seconds': duration,
            **request_fields,
        })
        client = self._get_client()
        try:
            t0 = time.time()
            # Длину просим ЯВНО под слот (Duration Control, поле `duration`)
            # с запасом +5%: лучше чуть длиннее и подрезать, чем зацикливать.
            # Без этого Suno выбирал сам и мог отдать 23.8с на слот в 2 минуты.
            wanted = duration * MUSIC_DURATION_MARGIN if duration > 0 else 0
            clip_ids = client.generate(
                prompt=prompt,
                tags=tags,
                title=title,
                instrumental=True,    # ВСЕГДА
                model=self.model,
                duration=wanted if wanted > 0 else None,
            )
            if wanted:
                print(f"   ⏱  Track {tid}: просим у Suno "
                      f"{clamp_suno_duration(wanted)}с под слот {duration:.0f}с")

            print(f"   📤 Track {tid}: запущены {len(clip_ids)} клипов, ждём...")

            def _on_progress(cid, status, elapsed, _clip):
                if int(elapsed) % 15 == 0:
                    sys.stdout.write(
                        f"\r      {cid[:8]} {status:10} t={elapsed:5.0f}с\n"
                    )
                    sys.stdout.flush()

            durations: List[float] = []
            track_raw_dir = self.music_raw_dir / str(tid)
            track_raw_dir.mkdir(parents=True, exist_ok=True)

            # Suno отдаёт два варианта одного трека. Падение ОДНОГО не должно
            # ронять трек целиком: второй уже скачан и полностью годится
            # (микшер зацикливает/подрезает его под слот). Раньше исключение
            # из wait_for_clip вылетало из цикла, и трек уходил в missing,
            # хотя v1 лежал на диске (инцидент 15.08.2026, трек 1).
            downloaded: List[int] = []
            variant_errors: List[str] = []
            for variant_idx, cid in enumerate(clip_ids, 1):
                try:
                    clip = client.wait_for_clip(cid, on_progress=_on_progress)
                    dur = float(clip.get('metadata', {}).get('duration', 0))
                    dst = track_raw_dir / f'v{variant_idx}.mp3'
                    client.download_audio(clip, dst)
                except (SunoAuthError, SunoQuotaError):
                    raise                      # фатально для всего прогона
                except Exception as exc:
                    durations.append(0.0)      # держим индексы вариантов
                    variant_errors.append(f'v{variant_idx}: {exc}')
                    print(f"   ⚠️  Track {tid} v{variant_idx}: не дошёл — {exc}")
                    continue
                durations.append(dur)
                downloaded.append(variant_idx)
                print(f"   ✅ Track {tid} v{variant_idx}: {dur:.1f}с → {dst.relative_to(self.project_dir)}")

            if not downloaded:
                raise SunoAPIError('; '.join(variant_errors) or 'no variants downloaded')

            # Копируем лучший вариант в music/<id>.mp3. Раньше жёстко брался
            # v1 — и трек на 23.8с выигрывал у варианта на 140с при слоте в
            # две минуты (инцидент 15.08.2026): микшеру приходилось крутить
            # 24-секундную петлю пять раз. Оба варианта уже оплачены одной
            # генерацией, поэтому выбор бесплатный.
            chosen_variant = _pick_best_variant(durations, downloaded, duration)
            chosen_src = track_raw_dir / f'v{chosen_variant}.mp3'
            if chosen_src.exists():
                self._copy_selected_music(chosen_src, target, intro_dynamic=bool(track.get('intro_dynamic')))

            # Фолбэк на два коротких: если ни один вариант не покрывает слот,
            # склеиваем оба — петля из одного слышна каждые ~50 секунд.
            best_dur = 0.0
            try:
                best_dur = float(durations[chosen_variant - 1])
            except (IndexError, TypeError, ValueError):
                best_dur = 0.0
            _stitch_threshold = duration * MUSIC_STITCH_BELOW
            if (len(downloaded) > 1 and duration > 0
                    and 0 < best_dur < _stitch_threshold):
                parts = [track_raw_dir / f'v{i}.mp3' for i in downloaded]
                parts = [p for p in parts if p.exists()]
                stitched = self._stitch_variants(parts, target) if len(parts) > 1 else None
                if stitched:
                    print(f"   🧩 Track {tid}: оба варианта коротки "
                          f"({', '.join(f'{durations[i-1]:.0f}с' for i in downloaded)}) — "
                          f"склеил в один трек {stitched:.0f}с под слот {duration:.0f}с")
                    durations[chosen_variant - 1] = stitched
                    self._audit('VARIANTS_STITCHED', {
                        'track_id': tid, 'parts': downloaded,
                        'result_seconds': stitched, 'slot_seconds': round(duration, 1)})

            elapsed = time.time() - t0
            _partial = f", вариантов {len(downloaded)}/{len(clip_ids)}" if variant_errors else ""
            print(f"   ✓ Track {tid} готов за {elapsed:.0f}с (выбран v{chosen_variant}{_partial})")
            self._audit('SUNO_SUCCESS', {
                'track_id': tid,
                'clip_ids': clip_ids,
                'durations': durations,
                'selected_variant': chosen_variant,
                'failed_variants': variant_errors,
                'elapsed_seconds': round(elapsed, 3),
            })
            return {
                'id': tid,
                'status': 'ok',
                'clip_ids': clip_ids,
                'durations': durations,
                'selected_variant': chosen_variant,
            }

        except SunoAuthError as e:
            print(f"   ❌ Track {tid}: AUTH ERROR — {e}")
            self._audit('SUNO_TRACK_FAILED', {
                'track_id': tid, 'kind': 'auth', 'error': str(e),
            })
            return {'id': tid, 'status': 'failed', 'reason': f'auth: {e}', 'clip_ids': [], 'durations': []}
        except SunoQuotaError as e:
            print(f"   ❌ Track {tid}: КРЕДИТЫ ЗАКОНЧИЛИСЬ — {e}")
            self._audit('SUNO_TRACK_FAILED', {
                'track_id': tid, 'kind': 'quota', 'error': str(e),
            })
            return {'id': tid, 'status': 'failed', 'reason': f'quota: {e}', 'clip_ids': [], 'durations': []}
        except SunoCaptchaError as e:
            print(f"   🛑 Track {tid}: {e}")
            self._audit('SUNO_CAPTCHA_REQUIRED', {'track_id': tid, 'error': str(e)})
            return {'id': tid, 'status': 'failed', 'reason': f'captcha: {e}',
                    'clip_ids': [], 'durations': []}
        except SunoAPIError as e:
            print(f"   ❌ Track {tid}: API ERROR — {e}")
            self._audit('SUNO_TRACK_FAILED', {
                'track_id': tid, 'kind': 'api', 'error': str(e),
            })
            return {'id': tid, 'status': 'failed', 'reason': f'api: {e}', 'clip_ids': [], 'durations': []}
        except Exception as e:
            logging.exception(f"Track {tid}: unexpected error")
            print(f"   ❌ Track {tid}: {e}")
            self._audit('SUNO_TRACK_FAILED', {
                'track_id': tid, 'kind': type(e).__name__, 'error': str(e),
            })
            return {'id': tid, 'status': 'failed', 'reason': str(e), 'clip_ids': [], 'durations': []}

    # =========================================================================
    # Variant switching (вызывается из Music Review GUI)
    # =========================================================================

    def select_variant(self, track_id: int, variant: int) -> bool:
        """Меняет selected_variant и копирует raw/<id>/v<variant>.mp3 → music/<id>.mp3."""
        plan = self._load_plan()
        tracks = plan.get('tracks', [])
        track = next((t for t in tracks if t.get('id') == track_id), None)
        if not track:
            return False

        src = self.music_raw_dir / str(track_id) / f'v{variant}.mp3'
        if not src.exists():
            print(f"⚠️  Вариант v{variant} не найден для track {track_id}: {src}")
            return False

        dst = self.music_dir / self._track_filename(track_id)
        self._copy_selected_music(src, dst, intro_dynamic=bool(track.get('intro_dynamic')))
        track['selected_variant'] = variant
        track['file'] = self._track_filename(track_id)
        self._save_plan(plan)
        print(f"✓ Track {track_id}: выбран v{variant}")
        return True

    # =========================================================================
    # Helpers
    # =========================================================================

    def _reset_audit_log(self, plan: Dict[str, Any]) -> None:
        payload = {
            'event': 'MUSIC_GENERATION_START',
            'timestamp': time.strftime('%Y-%m-%dT%H:%M:%S'),
            'provider': str(getattr(config, 'MUSIC_PROVIDER', 'suno') or 'suno'),
            'browser': self.browser,
            'model': self.model,
            'plan_path': str(self.plan_path),
            'tracks': len(plan.get('tracks', [])),
            'planned_tracks': [
                {
                    'id': track.get('id'),
                    'title': track.get('title'),
                    'startTime': track.get('startTime'),
                    'endTime': track.get('endTime'),
                    'prompt': track.get('prompt'),
                    'tags': track.get('tags'),
                    'instrumental': bool(track.get('instrumental', True)),
                }
                for track in plan.get('tracks', [])
            ],
        }
        with self._audit_lock:
            self.audit_log_path.write_text(
                json.dumps(payload, ensure_ascii=False) + '\n',
                encoding='utf-8',
            )

    def _quarantine_disabled_fallbacks(self, plan: Dict[str, Any]) -> int:
        fallback_enabled = bool(
            getattr(config, 'MUSIC_FALLBACK_ON_SUNO_FAIL', False)
        )
        fallback_mode = str(
            getattr(config, 'MUSIC_FALLBACK_MODE', 'off') or 'off'
        ).strip().lower()
        if fallback_enabled and fallback_mode == 'ffmpeg_ambient':
            return 0

        quarantine_dir = self.music_dir / 'rejected_fallback'
        changed = 0
        for track in plan.get('tracks', []):
            if track.get('fallback') != 'ffmpeg_ambient':
                continue
            changed += 1
            target = self.music_dir / self._track_filename(track.get('id'))
            if target.exists():
                quarantine_dir.mkdir(parents=True, exist_ok=True)
                quarantined = quarantine_dir / target.name
                if quarantined.exists():
                    quarantined = quarantine_dir / (
                        f"{target.stem}_{int(time.time())}{target.suffix}"
                    )
                shutil.move(str(target), str(quarantined))
                print(
                    f"   [music] Disabled synthetic fallback moved aside: "
                    f"{target.name} -> {quarantined.relative_to(self.project_dir)}"
                )
            track.pop('fallback', None)
            track.pop('file', None)
            track.pop('selected_variant', None)
            track.pop('suno_durations', None)
            track.pop('suno_clip_ids', None)
        return changed

    def _audit(self, event: str, payload: Dict[str, Any]) -> None:
        entry = {
            'event': event,
            'timestamp': time.strftime('%Y-%m-%dT%H:%M:%S'),
            **payload,
        }
        with self._audit_lock:
            with self.audit_log_path.open('a', encoding='utf-8') as fh:
                fh.write(json.dumps(entry, ensure_ascii=False) + '\n')

    def _track_filename(self, track_id: int) -> str:
        return f'{track_id}.mp3'

    def _stitch_variants(self, parts: List[Path], dst: Path,
                         crossfade: float = 1.5) -> Optional[float]:
        """Склеить оба варианта трека в один файл (кроссфейдом).

        Когда Suno отдал ДВА коротких варианта (живой пример: 54.6с и 50.9с на
        слот 122с), крутить петлю из одного — слышимый повтор каждые 55 секунд.
        Варианты сделаны одной генерацией, то есть в одном стиле и темпе, и
        склейка звучит как единый трек вдвое длиннее.

        Возвращает длительность результата или None, если склеить не вышло.
        """
        ffmpeg = shutil.which('ffmpeg')
        if not ffmpeg or len(parts) < 2:
            return None
        tmp = dst.with_name(f"{dst.stem}__stitched{dst.suffix}")
        cmd = [ffmpeg, '-y', '-hide_banner', '-loglevel', 'error']
        for part in parts:
            cmd += ['-i', str(part)]
        # acrossfade склеивает последовательно, гася стык
        filters, prev = [], '[0:a]'
        for idx in range(1, len(parts)):
            label = f'[a{idx}]'
            filters.append(
                f'{prev}[{idx}:a]acrossfade=d={crossfade}:c1=tri:c2=tri{label}')
            prev = label
        cmd += ['-filter_complex', ';'.join(filters), '-map', prev,
                '-c:a', 'libmp3lame', '-b:a', '192k', str(tmp)]
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True,
                                  encoding='utf-8', errors='replace')
            if proc.returncode != 0 or not tmp.exists() or tmp.stat().st_size <= 0:
                raise RuntimeError((proc.stderr or '').strip()[-300:])
            duration = _audio_duration(tmp)
            if dst.exists():
                dst.unlink()
            tmp.replace(dst)
            return duration
        except Exception as exc:
            logging.warning("Music: склейка вариантов не удалась: %s", exc)
            if tmp.exists():
                try:
                    tmp.unlink()
                except OSError:
                    pass
            return None

    def _copy_selected_music(self, src: Path, dst: Path, *, intro_dynamic: bool = False) -> None:
        """
        Copy the selected Suno variant into music/<id>.mp3 while trimming encoder
        padding or generated leading silence. This keeps the background audible
        from the first second when the plan starts at 0.0.
        """
        ffmpeg = shutil.which('ffmpeg')
        if not ffmpeg:
            shutil.copy2(src, dst)
            return

        threshold = '-45dB' if intro_dynamic else '-50dB'
        start_duration = '0.03' if intro_dynamic else '0.05'
        temp = dst.with_name(f"{dst.stem}__trimmed{dst.suffix}")
        cmd = [
            ffmpeg, '-y', '-hide_banner', '-loglevel', 'error',
            '-i', str(src),
            '-af',
            (
                'silenceremove='
                f'start_periods=1:start_duration={start_duration}:start_threshold={threshold}'
            ),
            '-c:a', 'libmp3lame', '-b:a', '192k',
            str(temp),
        ]
        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True, encoding='utf-8', errors='replace',
            )
            if proc.returncode != 0 or not temp.exists() or temp.stat().st_size <= 0:
                raise RuntimeError((proc.stderr or '').strip()[-500:])
            if dst.exists():
                dst.unlink()
            temp.replace(dst)
        except Exception as exc:
            logging.warning("Music trim/copy fallback for %s: %s", src, exc)
            if temp.exists():
                try:
                    temp.unlink()
                except OSError:
                    pass
            shutil.copy2(src, dst)

    def _fill_missing_from_neighbours(self, tracks: List[Dict[str, Any]]) -> int:
        """Пустой слот закрываем музыкой ближайшего готового трека.

        Тишина в середине ролика заметнее, чем повтор соседнего подклада, а
        микшер всё равно подрежет/зациклит файл под длину слота. Работает
        только по уже скачанным файлам — кредитов не тратит."""
        ready = []
        for t in tracks:
            tid = t.get('id')
            if tid is None:
                continue
            path = self.music_dir / self._track_filename(tid)
            if path.exists() and path.stat().st_size > 0:
                ready.append((t, path))
        if not ready:
            return 0

        filled = 0
        for t in tracks:
            tid = t.get('id')
            if tid is None or (t.get('genre') or '').lower() == 'silence':
                continue
            target = self.music_dir / self._track_filename(tid)
            if target.exists() and target.stat().st_size > 0:
                continue
            # ближайший по времени готовый трек
            start = float(t.get('startTime', 0) or 0)
            donor_track, donor_path = min(
                ready,
                key=lambda pair: abs(float(pair[0].get('startTime', 0) or 0) - start))
            try:
                shutil.copy2(donor_path, target)
            except OSError as exc:
                logging.warning("Music: не удалось подставить трек %s -> %s: %s",
                                donor_track.get('id'), tid, exc)
                continue
            t['file'] = self._track_filename(tid)
            t['filled_from_track'] = donor_track.get('id')
            # длительность и вариант берём донорские: микшер по ним решает
            # loop/trim, иначе посчитает длину неизвестной
            t['suno_durations'] = donor_track.get('suno_durations')
            t['selected_variant'] = donor_track.get('selected_variant', 1)
            filled += 1
            print(f"   🔁 Track {tid}: слот закрыт музыкой трека "
                  f"{donor_track.get('id')} (своя генерация не вышла)")
            self._audit('TRACK_FILLED_FROM_NEIGHBOUR',
                        {'track_id': tid, 'donor_id': donor_track.get('id')})
        return filled

    def _ready_music_count(self, tracks: List[Dict[str, Any]]) -> int:
        return sum(
            1 for t in tracks
            if (t.get('genre') or '').lower() == 'silence'
            or (self.music_dir / self._track_filename(t.get('id'))).exists()
        )

    def _missing_music_count(self, tracks: List[Dict[str, Any]]) -> int:
        return sum(
            1 for t in tracks
            if (t.get('genre') or '').lower() != 'silence'
            and not (self.music_dir / self._track_filename(t.get('id'))).exists()
        )

    def _load_plan(self) -> Dict[str, Any]:
        if not self.plan_path.exists():
            raise FileNotFoundError(f"music_plan.json не найден: {self.plan_path}")
        data = json.loads(self.plan_path.read_text(encoding='utf-8-sig'))
        if 'music_plan' in data and 'tracks' in data['music_plan']:
            return data['music_plan']
        return data

    def _save_plan(self, plan: Dict[str, Any]) -> None:
        wrapped = {'music_plan': plan} if 'tracks' in plan else plan
        self.plan_path.write_text(
            json.dumps(wrapped, indent=2, ensure_ascii=False),
            encoding='utf-8',
        )


# =========================================================================
# CLI helper для запуска вручную
# =========================================================================

def generate_for_project(
    project_dir: str,
    force: bool = False,
    browser: Optional[str] = None,
    model: Optional[str] = None,
    parallel: int = 1,
) -> Dict[str, Any]:
    # Свой лог стадии. `music_background.log` — это перехват ВЫВОДА фонового
    # процесса, а не логгер: DEBUG-строки модулей (план, Suno, микс) туда не
    # попадали вовсе. Теперь у музыки файл того же вида, что у стока и ютуба.
    from modules.stage_log import attach as _attach_log, detach as _detach_log

    _log_handler, _log_path = _attach_log(project_dir, 'music')
    if _log_path:
        print(f"  [Music] лог стадии: {_log_path}")
    orch = MusicOrchestrator(
        project_dir=project_dir, browser=browser, model=model, parallel=parallel,
    )
    try:
        return orch.generate_all(force=force)
    finally:
        if _log_path:
            print(f"  [Music] полный лог стадии: {_log_path}")
        _detach_log(_log_handler)
