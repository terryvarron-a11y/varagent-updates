#!/bin/bash
# START_PHOTO.COMMAND - Foto-slaydshou: Ken Burns + xfade (macOS - double click)

PROJECT_NAME="{project_name}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Auto-set execute permissions
chmod +x *.command *.sh 2>/dev/null
[ -f "$SCRIPT_DIR/.venv/bin/activate" ] && source "$SCRIPT_DIR/.venv/bin/activate"

# Open Terminal.app for interactive mode
if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e "tell app \"Terminal\" to do script \"cd '$SCRIPT_DIR' && exec '$0'\""
    exit 0
fi

clear
cd "$SCRIPT_DIR"

echo ""
echo "================================================================================"
echo " FOTO-SLAYDSHOU  —  Ken Burns + xfade"
echo " Project: $PROJECT_NAME"
echo "================================================================================"
echo ""

# --- Check montage_plan.json ---
if [ ! -f "montage_plan.json" ]; then
    echo "[ERROR] montage_plan.json not found!"
    echo "   Run run_director first."
    echo ""
    echo "Press Enter to exit..."
    read
    exit 1
fi

# --- Find audio ---
AUDIO_FILE=""
for ext in wav mp3 flac m4a aac; do
    f=$(ls *."$ext" 2>/dev/null | head -1)
    [ -n "$f" ] && AUDIO_FILE="$f" && break
done

if [ -z "$AUDIO_FILE" ]; then
    echo "[ERROR] Audio file not found!"
    echo "   Put .wav/.mp3 in project folder or pass: -a file.wav"
    echo ""
    echo "Press Enter to exit..."
    read
    exit 1
fi
echo "   Audio: $AUDIO_FILE"
echo ""

# --- Resolution ---
echo " Resolution:"
echo "   [1] 1920x1080  Full HD landscape (default)"
echo "   [2] 1280x720   HD landscape"
echo "   [3] 1080x1920  Full HD portrait (Reels/Shorts)"
echo "   [4] 1080x1080  Square"
echo ""
RESOLUTION="1920x1080"
echo -n "  Resolution [1-4] (Enter = 1920x1080): "
read RES_CHOICE
case "$RES_CHOICE" in
    2) RESOLUTION="1280x720" ;;
    3) RESOLUTION="1080x1920" ;;
    4) RESOLUTION="1080x1080" ;;
esac
echo "   Selected: $RESOLUTION"
echo ""

# --- Transition duration ---
echo " Transition duration (xfade):"
echo "   [1] 0.5s  — short"
echo "   [2] 0.7s  — standard (default)"
echo "   [3] 1.0s  — smooth"
echo ""
TDUR="0.7"
echo -n "  Transition [1-3] (Enter = 0.7s): "
read TDUR_CHOICE
case "$TDUR_CHOICE" in
    1) TDUR="0.5" ;;
    3) TDUR="1.0" ;;
esac
echo "   Selected: ${TDUR}s"
echo ""

OUTPUT_FILE="${PROJECT_NAME}_photo.mp4"
echo " Output: $OUTPUT_FILE"
echo ""

echo "================================================================================"
echo " SUMMARY:"
echo "   Project:    $PROJECT_NAME"
echo "   Audio:      $AUDIO_FILE"
echo "   Resolution: $RESOLUTION"
echo "   Transition: ${TDUR}s"
echo "   Output:     $OUTPUT_FILE"
echo "================================================================================"
echo ""
echo "   [1] Start  (po umolchaniyu)"
echo "   [2] Cancel"
echo ""
read -p "  Vybor [1/2] (Enter = Start): " CONFIRM
if [ "$CONFIRM" = "2" ]; then
    echo " Cancelled."
    echo "Press Enter to exit..." && read
    exit 0
fi

echo ""
echo " Renaming files in vid_img/..."
if [ -f "rename_videos.py" ]; then
    python3 rename_videos.py --dir vid_img
else
    echo "   [WARN] rename_videos.py not found, skipping..."
fi
echo ""

echo " Starting photo slideshow..."
echo ""

python3 photo_concat.py montage_plan.json \
    -a "$AUDIO_FILE" \
    -o "$OUTPUT_FILE" \
    --resolution "$RESOLUTION" \
    --transition-duration "$TDUR" \
    -b 10M

EXIT_CODE=$?

echo ""
echo "================================================================================"
if [ $EXIT_CODE -ne 0 ]; then
    echo " [ERROR] Failed. Check photo_concat_*.log"
else
    echo " [OK] DONE: $OUTPUT_FILE"
fi
echo "================================================================================"
echo ""
echo "Press Enter to exit..."
read
exit $EXIT_CODE
