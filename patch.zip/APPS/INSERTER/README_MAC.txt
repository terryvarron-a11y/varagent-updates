Audio Inserter — установка и запуск на macOS
==============================================

ПЕРВЫЙ ЗАПУСК (один раз)
------------------------
1. Откройте Terminal (Программы → Утилиты → Терминал).
2. Перетащите файл install_mac.command в окно терминала, нажмите Enter.
   (Если двойной клик открывает .command в текстовом редакторе — это значит
    что у файла нет исполняемого бита. Способ через Terminal обходит это.)
3. Скрипт поставит:
     • Homebrew (если ещё нет)
     • ffmpeg (нужен для самой склейки)
     • python3 + python-tk (нужны для GUI)
4. По окончании нажмите Enter, окно закроется.

ОБЫЧНЫЙ ЗАПУСК
---------------
• Двойной клик по AudioInserter.command.
• Откроется окно утилиты, Terminal закроется автоматически.

ЕСЛИ macOS РУГАЕТСЯ
-------------------
"AudioInserter.command не может быть открыт, так как разработчик не подтверждён":
  • Правый клик по файлу → "Открыть" → "Открыть" в диалоге.
  • Или System Settings → Privacy & Security → "Open Anyway".

Если повторно: запустите ещё раз install_mac.command — он снимает quarantine
с обоих .command файлов автоматически.

ПРОБЛЕМЫ
--------
• "Python 3 не найден" — запустите install_mac.command.
• "Tkinter не установлен" — install_mac.command поставит python-tk.
• "ffmpeg не найден в PATH" — install_mac.command поставит ffmpeg.
• "brew shellenv" не подхватился — перезапустите Terminal или выполните вручную:
    eval "$(/opt/homebrew/bin/brew shellenv)"          # Apple Silicon
    eval "$(/usr/local/bin/brew shellenv)"             # Intel
