#!/bin/bash
# SCENAGENT RTG - Checker for macOS
# Run: double-click this file in Finder

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Auto-set execute permissions
chmod +x *.command 2>/dev/null
[ -f "$SCRIPT_DIR/.venv/bin/activate" ] && source "$SCRIPT_DIR/.venv/bin/activate"

PYTHON_CMD="python3"
ERRORS=0

echo ""
echo "================================================================================"
echo " SCENAGENT RTG - CHECKER (macOS)"
echo "================================================================================"
echo ""

# ============================================================================
# 1. PYTHON3
# ============================================================================
echo "[1/5] Python3..."

PYVER=$(python3 --version 2>&1)
if [ $? -eq 0 ]; then
    echo " [OK] $PYVER"
else
    echo " [ERROR] Python3 not found!"
    ERRORS=$((ERRORS + 1))
fi

# ============================================================================
# 2. PIP
# ============================================================================
echo ""
echo "[2/5] pip..."

$PYTHON_CMD -m pip --version &>/dev/null
if [ $? -eq 0 ]; then
    echo " [OK] pip available"
else
    echo " [ERROR] pip not found!"
    ERRORS=$((ERRORS + 1))
fi

# ============================================================================
# 3. PYTHON PACKAGES
# ============================================================================
echo ""
echo "[3/5] Python packages..."

PKG_ERRORS=0
MISSING=""

$PYTHON_CMD -c "import assemblyai" 2>/dev/null || { echo " [MISS] assemblyai"; MISSING="$MISSING assemblyai"; PKG_ERRORS=$((PKG_ERRORS + 1)); }
$PYTHON_CMD -c "import google.genai" 2>/dev/null || { echo " [MISS] google.genai"; MISSING="$MISSING google-genai"; PKG_ERRORS=$((PKG_ERRORS + 1)); }
$PYTHON_CMD -c "import dotenv" 2>/dev/null || { echo " [MISS] python-dotenv"; MISSING="$MISSING python-dotenv"; PKG_ERRORS=$((PKG_ERRORS + 1)); }
$PYTHON_CMD -c "import tqdm" 2>/dev/null || { echo " [MISS] tqdm"; MISSING="$MISSING tqdm"; PKG_ERRORS=$((PKG_ERRORS + 1)); }
$PYTHON_CMD -c "import httpx" 2>/dev/null || { echo " [MISS] httpx"; MISSING="$MISSING httpx"; PKG_ERRORS=$((PKG_ERRORS + 1)); }
$PYTHON_CMD -c "import pydantic" 2>/dev/null || { echo " [MISS] pydantic"; MISSING="$MISSING pydantic"; PKG_ERRORS=$((PKG_ERRORS + 1)); }

ERRORS=$((ERRORS + PKG_ERRORS))

if [ $PKG_ERRORS -eq 0 ]; then
    echo " [OK] All packages installed"
else
    echo " [WARN] Missing:$MISSING"
fi

# ============================================================================
# 4. FFMPEG
# ============================================================================
echo ""
echo "[4/5] FFmpeg..."

if ffmpeg -version &>/dev/null; then
    echo " [OK] FFmpeg installed"
else
    echo " [ERROR] FFmpeg not found!"
    ERRORS=$((ERRORS + 1))
fi

# ============================================================================
# 5. .ENV
# ============================================================================
echo ""
echo "[5/5] .env file..."

if [ -f "agent/.env" ]; then
    echo " [OK] agent/.env exists"
else
    echo " [ERROR] agent/.env not found!"
    ERRORS=$((ERRORS + 1))
fi

# ============================================================================
# SUMMARY
# ============================================================================
echo ""
echo "================================================================================"
echo " RESULT"
echo "================================================================================"
echo ""

if [ $ERRORS -eq 0 ]; then
    echo " [OK] All components ready!"
    echo ""
    echo " You can run:"
    echo "   ./run_stage1_simple.command"
    echo "   ./run_stage2_auto.command"
else
    echo " [ERROR] Found $ERRORS error(s)"
    echo ""
    if [ $ERRORS -ge 3 ]; then
        echo " Recommendation: run ./install.command"
    fi
fi

echo ""
echo "================================================================================"
