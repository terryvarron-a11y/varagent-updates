"""
stock_markup.py — директива разметки сток-клипов для Pass 1.

Одна точка правды на ОБА директора (`chat_director.py` и `gpt_director.py`).
Модуль намеренно лёгкий: только текст, без импортов поиска/ffmpeg — его тянут
директора, им лишние зависимости не нужны.

Почему не два текста: маркеры уже один раз были скопированы в 7 файлов и это
стало миной (см. clip_sources.py). Директива живёт здесь, директора её зовут.

Взаимодействие с Real Photo
---------------------------
Стадии дополняют друг друга, а не конкурируют:
  Real Photo — исторический материал (личности, события, артефакты);
  Stock      — современная съёмка (природа, погода, город, техника, быт).
То, что Real Photo прямо перечисляет как BAD («generic atmospheric shots»,
«misty mountains, stormy sky») — идеальные кандидаты для стока.
Поле `source` одно, поэтому клип получает либо тот маркер, либо этот.

Pass 1 ТОЛЬКО ПОМЕЧАЕТ — запросы пишет стадия
---------------------------------------------
Задача Pass 1 — монтажный план: нарезка и тайминг. Ничего больше.
Поисковые запросы (`stock_query`) и выбор video/photo делает стоковая стадия
своим оператором (STOCK_PROMPT_PROVIDER) — ровно как Real Photo делает это
отдельным промптером, а не руками режиссёра.

Почему так, а не «заодно и запрос напишет»:
  • промптаж раздувает ответ Pass 1 → лишние токены и риск обрезки на длинных роликах;
  • Pass 1 чанкуется на длинном аудио (DIRECTOR_PASS1_CHUNK_THRESHOLD) — запросы
    разъехались бы по чанкам;
  • режиссёр может быть дорогой моделью, а сочинить «lightning storm clouds» —
    работа для дешёвой;
  • у стадии свой оператор ещё и сопоставляет локальную библиотеку — режиссёр
    про её содержимое не знает вовсе.
"""
from __future__ import annotations

import config


def stock_markup_directive() -> str:
    """Текст директивы для Pass 1. Пусто, если сток выключен."""
    if not getattr(config, 'STOCK_ENABLED', False):
        return ''

    target_pct = int(float(getattr(config, 'STOCK_RATIO_TARGET', 0.30)) * 100)
    video_pct = int(float(getattr(config, 'STOCK_VIDEO_SHARE', 0.70)) * 100)
    photo_pct = max(0, 100 - video_pct)

    return f"""

---

## STOCK FOOTAGE MARKUP

A separate stage replaces some AI-generated clips with REAL modern stock material
(Pexels / Pixabay / the user's own footage library). Mark suitable candidates AND
write a short search query for each.

GOOD candidates (mark them):
- Generic contemporary scenes: nature, landscapes, weather, seasons
- City life, traffic, crowds, streets, architecture (unnamed/generic)
- Technology, machinery, laboratories, screens, industry
- Everyday human actions filmed today: walking, working, cooking, typing, driving
- Atmospheric/establishing shots: fog, rain, waves, clouds, forest, fire
- Generic objects and textures: money, documents, food, plants, tools

BAD candidates (do NOT mark) — stock is MODERN STAGED footage, not archive:
- ANY historical events, periods or scenes ("1600 flood", "WW2 battle", "medieval city")
- Named historical figures (they belong to the Real Photo stage)
- Named specific places/landmarks that must be recognizable (Kremlin, Hiroshima)
- Anything requiring historical or factual accuracy
- Fictional/speculative/imagined scenes
- Clips already marked "source": "real_photo_pending"

Rule of thumb: if the narration is about the PAST — do NOT mark it for stock.
Modern staged footage inside a historical scene looks absurd and breaks the film.

Target: mark ~{target_pct}% of clips. Quality over quantity — a confident "no"
beats an uncertain "yes".

If clip qualifies → add ONE additional field to that clip:
  "source": "stock_pending"

If clip does NOT qualify → do not add any source field.

Example output:
{{"id": 5, "file": "5.mp4", "startTime": 0.0, "endTime": 4.8, "source": "stock_pending"}},
{{"id": 6, "file": "6.mp4", "startTime": 4.8, "endTime": 9.2}},

NOTE: only MARK clips. Do NOT write `stock_query`, `stock_media`, `reasoning` or any
other fields — those belong to the downstream stock stage, which has its own operator.
"""
