#!/bin/bash
set -u

ROOT="$HOME/Library/Application Support/VARAGENT"
PY="$ROOT/.venv/bin/python3"

export PATH="$HOME/.local/bin:$HOME/.codex/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
export CODEX_HOME="${CODEX_HOME:-$HOME/.codex}"

if [ ! -x "$PY" ] || [ ! -f "$ROOT/varagent.py" ]; then
    osascript -e 'display alert "VARAGENT is not installed" message "Run Install VARAGENT.app first." as critical'
    exit 1
fi

cd "$ROOT" || exit 1
exec "$PY" "$ROOT/varagent.py"
