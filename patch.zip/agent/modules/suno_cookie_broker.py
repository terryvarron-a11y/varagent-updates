"""Extract Suno cookies through the browser that owns App-Bound encryption."""

from __future__ import annotations

import os
import shutil
import sqlite3
import tempfile
from pathlib import Path
from typing import Any


class SunoCookieBrokerError(RuntimeError):
    pass


def _browser_install(browser: str) -> tuple[list[Path], list[tuple[Path, str]]]:
    appdata = Path(os.getenv("APPDATA") or Path.home() / "AppData" / "Roaming")
    local = Path(os.getenv("LOCALAPPDATA") or Path.home() / "AppData" / "Local")
    program_files = Path(os.getenv("PROGRAMFILES") or r"C:\Program Files")
    program_files_x86 = Path(os.getenv("PROGRAMFILES(X86)") or r"C:\Program Files (x86)")

    if browser == "opera":
        executables = [
            local / "Programs" / "Opera" / "opera.exe",
            local / "Programs" / "Opera GX" / "opera.exe",
            program_files / "Opera" / "opera.exe",
            program_files_x86 / "Opera" / "opera.exe",
        ]
        roots = [
            (appdata / "Opera Software" / "Opera Stable", "Default"),
            (appdata / "Opera Software" / "Opera GX Stable", "Default"),
        ]
    elif browser == "chrome":
        executables = [
            local / "Google" / "Chrome" / "Application" / "chrome.exe",
            program_files / "Google" / "Chrome" / "Application" / "chrome.exe",
            program_files_x86 / "Google" / "Chrome" / "Application" / "chrome.exe",
        ]
        roots = [(local / "Google" / "Chrome" / "User Data", "Default")]
    elif browser == "edge":
        executables = [
            program_files_x86 / "Microsoft" / "Edge" / "Application" / "msedge.exe",
            program_files / "Microsoft" / "Edge" / "Application" / "msedge.exe",
        ]
        roots = [(local / "Microsoft" / "Edge" / "User Data", "Default")]
    elif browser == "brave":
        executables = [
            local / "BraveSoftware" / "Brave-Browser" / "Application" / "brave.exe",
            program_files / "BraveSoftware" / "Brave-Browser" / "Application" / "brave.exe",
        ]
        roots = [(local / "BraveSoftware" / "Brave-Browser" / "User Data", "Default")]
    else:
        return [], []

    expanded_roots: list[tuple[Path, str]] = []
    for root, default_profile in roots:
        if not root.is_dir():
            continue
        profile_names = [default_profile]
        profile_names.extend(path.name for path in sorted(root.glob("Profile *")) if path.is_dir())
        for profile_name in profile_names:
            cookie_file = root / profile_name / "Network" / "Cookies"
            if cookie_file.is_file():
                expanded_roots.append((root, profile_name))
    return [path for path in executables if path.is_file()], expanded_roots


def _copy_sqlite(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    source_uri = f"file:{source.as_posix()}?mode=ro"
    try:
        with sqlite3.connect(source_uri, uri=True, timeout=3) as src:
            with sqlite3.connect(target) as dst:
                src.backup(dst)
    except sqlite3.Error:
        shutil.copy2(source, target)


def _clone_minimal_profile(source_root: Path, profile_name: str, target_root: Path) -> None:
    source_profile = source_root / profile_name
    target_profile = target_root / profile_name
    target_profile.mkdir(parents=True, exist_ok=True)

    local_state = source_root / "Local State"
    if not local_state.is_file():
        raise SunoCookieBrokerError(f"Browser Local State not found: {local_state}")
    shutil.copy2(local_state, target_root / "Local State")

    cookies = source_profile / "Network" / "Cookies"
    if not cookies.is_file():
        raise SunoCookieBrokerError(f"Browser cookie database not found: {cookies}")
    _copy_sqlite(cookies, target_profile / "Network" / "Cookies")

    for name in ("Preferences", "Secure Preferences"):
        source = source_profile / name
        if source.is_file():
            shutil.copy2(source, target_profile / name)


def _is_suno_cookie(cookie: dict[str, Any]) -> bool:
    domain = str(cookie.get("domain") or "")
    name = str(cookie.get("name") or "")
    return (
        "suno.com" in domain
        and (
            name == "__session"
            or name.startswith("__session_")
            or name == "__client"
            or name.startswith("__client_")
            or name == "suno_device_id"
        )
    )


def extract_suno_cookies(browser: str) -> list[dict[str, Any]]:
    """Let the installed Chromium browser decrypt a temporary profile copy."""
    browser = (browser or "").strip().lower()
    executables, profiles = _browser_install(browser)
    if not executables:
        raise SunoCookieBrokerError(f"{browser}: browser executable not found")
    if not profiles:
        raise SunoCookieBrokerError(f"{browser}: no profile with a cookie database found")

    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise SunoCookieBrokerError("Playwright is not installed") from exc

    failures: list[str] = []
    for executable in executables:
        for source_root, profile_name in profiles:
            try:
                with tempfile.TemporaryDirectory(prefix=f"varagent_suno_{browser}_") as tmp:
                    target_root = Path(tmp)
                    _clone_minimal_profile(source_root, profile_name, target_root)
                    with sync_playwright() as playwright:
                        context = playwright.chromium.launch_persistent_context(
                            user_data_dir=str(target_root),
                            executable_path=str(executable),
                            headless=True,
                            args=[
                                f"--profile-directory={profile_name}",
                                "--no-first-run",
                                "--disable-default-apps",
                                "--disable-background-networking",
                            ],
                        )
                        try:
                            cookies = context.cookies(
                                ["https://suno.com", "https://auth.suno.com"]
                            )
                        finally:
                            context.close()
                selected = [cookie for cookie in cookies if _is_suno_cookie(cookie)]
                if any(
                    cookie.get("name") == "__session"
                    or str(cookie.get("name") or "").startswith("__session_")
                    for cookie in selected
                ):
                    return selected
                failures.append(f"{profile_name}: Suno session cookie not present")
            except Exception as exc:
                failures.append(f"{profile_name}: {type(exc).__name__}: {exc}")

    detail = failures[-1] if failures else "unknown browser broker failure"
    raise SunoCookieBrokerError(f"{browser}: {detail}")
