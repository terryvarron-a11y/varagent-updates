#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Update Codex CLI to latest version.

The Windows release is a matched runtime: codex.exe, code-mode host, and
command runner must be updated together.
"""

import sys
import os
import platform
import shutil
import subprocess
import urllib.request
from pathlib import Path

CODEX_DIR = Path(__file__).parent / "Codex"
CODEX_EXE_WIN = CODEX_DIR / "codex-x86_64-pc-windows-msvc.exe"
WINDOWS_ASSETS = {
    "codex-x86_64-pc-windows-msvc.exe":
        "https://github.com/openai/codex/releases/latest/download/codex-x86_64-pc-windows-msvc.exe",
    "codex-code-mode-host.exe":
        "https://github.com/openai/codex/releases/latest/download/codex-code-mode-host-x86_64-pc-windows-msvc.exe",
    "codex-command-runner.exe":
        "https://github.com/openai/codex/releases/latest/download/codex-command-runner-x86_64-pc-windows-msvc.exe",
}


def get_current_version_win():
    if not CODEX_EXE_WIN.exists():
        return None
    try:
        result = subprocess.run(
            [str(CODEX_EXE_WIN), "--version"],
            capture_output=True, text=True, timeout=5
        )
        return result.stdout.strip()
    except Exception:
        return None


def _find_codex_mac():
    """Locate the standalone Codex CLI even when this process has a stale PATH."""
    codex_bin = shutil.which('codex')
    if codex_bin:
        return codex_bin
    native_bin = Path.home() / '.local' / 'bin' / 'codex'
    return str(native_bin) if native_bin.is_file() else None


def get_current_version_mac():
    """Read the version of the native macOS Codex CLI."""
    codex_bin = _find_codex_mac()
    if not codex_bin:
        return None
    try:
        result = subprocess.run(
            [codex_bin, "--version"],
            capture_output=True, text=True, timeout=5
        )
        return result.stdout.strip()
    except Exception:
        return None


def _download_asset(url, destination):
    part = destination.with_name(destination.name + '.part')
    part.unlink(missing_ok=True)
    # GitHub режет БЕЗЫМЯННЫЕ запросы (Python-urllib/*) агрессивным HTTP 429.
    # Браузерный User-Agent + ретраи с backoff по Retry-After снимают это —
    # именно из-за отсутствия UA у портабл-юзеров и падало обновление.
    _req = urllib.request.Request(url, headers={
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) VARAGENT-Updater',
        'Accept': 'application/octet-stream',
    })
    _attempts = 5
    response = None
    for _n in range(1, _attempts + 1):
        try:
            response = urllib.request.urlopen(_req, timeout=300)
            break
        except urllib.error.HTTPError as exc:
            if exc.code in (429, 403, 503) and _n < _attempts:
                _wait = 0
                try:
                    _wait = int(exc.headers.get('Retry-After') or 0)
                except (TypeError, ValueError):
                    _wait = 0
                _wait = max(_wait, min(60, 5 * (2 ** (_n - 1))))
                print(f"\n  GitHub {exc.code} (лимит запросов) — жду {_wait}с "
                      f"и пробую снова ({_n}/{_attempts - 1})...", flush=True)
                import time as _t
                _t.sleep(_wait)
                continue
            raise
    with response:
        total = int(response.headers.get('content-length', 0))
        downloaded = 0
        with open(part, 'wb') as file_obj:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                file_obj.write(chunk)
                downloaded += len(chunk)
                if total:
                    print(
                        f"\r  {destination.name}: {int(downloaded * 100 / total)}%",
                        end='',
                        flush=True,
                    )
    print()
    if total and downloaded != total:
        part.unlink(missing_ok=True)
        raise RuntimeError(f"incomplete download: {downloaded}/{total}")
    if downloaded < 1_000_000:
        part.unlink(missing_ok=True)
        raise RuntimeError(f"unexpectedly small executable: {downloaded} bytes")
    with open(part, 'rb') as file_obj:
        if file_obj.read(2) != b'MZ':
            part.unlink(missing_ok=True)
            raise RuntimeError("download is not a Windows executable")


def update_windows():
    """Download and atomically install the complete Windows runtime."""
    print("Downloading latest complete Codex CLI runtime...")
    CODEX_DIR.mkdir(exist_ok=True)
    destinations = {name: CODEX_DIR / name for name in WINDOWS_ASSETS}
    backups = {}
    try:
        for name, url in WINDOWS_ASSETS.items():
            print(f"Downloading {name}...")
            _download_asset(url, destinations[name])
        for destination in destinations.values():
            if destination.exists():
                backup = destination.with_name(destination.name + '.bak')
                shutil.copy2(destination, backup)
                backups[destination] = backup
        for destination in destinations.values():
            os.replace(destination.with_name(destination.name + '.part'), destination)
        if not get_current_version_win():
            raise RuntimeError("updated Codex executable did not report a version")
        print("[OK] Complete Codex runtime installed")
        return True
    except Exception as e:
        print(f"\n[FAIL] Download failed: {e}")
        for destination in destinations.values():
            destination.with_name(destination.name + '.part').unlink(missing_ok=True)
        for destination, backup in backups.items():
            if backup.exists():
                shutil.copy2(backup, destination)
        return False


def update_mac():
    """Install or update the standalone Codex CLI."""
    print("Updating Codex CLI with the native installer...")
    try:
        result = subprocess.run(
            ['/bin/sh', '-c', 'curl -fsSL https://chatgpt.com/codex/install.sh | sh'],
            text=True,
        )
        if result.returncode == 0:
            print("[OK] Codex installer completed")
            return True
        print(f"[FAIL] Codex installer exit code: {result.returncode}")
        return False
    except Exception as e:
        print(f"[FAIL] Codex installer error: {e}")
        return False


def main():
    print("=" * 60)
    print(f"Codex CLI Update Tool ({platform.system()} {platform.machine()})")
    print("=" * 60)

    system = platform.system()

    if system == 'Windows':
        current = get_current_version_win()
        print(f"Current version: {current or 'Not installed'}")
        print()
        if update_windows():
            new_version = get_current_version_win()
            if new_version:
                print(f"[OK] Updated to: {new_version}")
                if current and new_version == current:
                    print("  (Version unchanged - already latest)")
            else:
                print("[FAIL] Update verification failed")
            return 0
        return 1

    elif system == 'Darwin':
        current = get_current_version_mac()
        print(f"Current version: {current or 'Not installed'}")
        print()
        if update_mac():
            new_version = get_current_version_mac()
            if new_version:
                print(f"[OK] Updated to: {new_version}")
                if current and new_version == current:
                    print("  (Version unchanged - already latest)")
            else:
                print("[OK] Installer finished — restart VARAGENT before using `codex`")
            return 0
        return 1

    else:
        print(f"[FAIL] Платформа {system} не поддерживается. Установи Codex вручную:")
        print("  https://github.com/openai/codex/releases/latest")
        return 1


if __name__ == '__main__':
    sys.exit(main())
