@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

REM ============================================================================
REM 0_INTERACTIVESTART.BAT - Start from TTS stage (Interactive Mode)
REM Stage 0: TTS -> Transcription -> Direction
REM ============================================================================

echo.
echo ================================================================================
echo  0_INTERACTIVESTART  [TTS + Pipeline]  INTERACTIVE MODE
echo ================================================================================
echo.
echo  Script files from pipeline_queue\ will be processed.
echo  You will be asked about each TTS parameter.
echo  After audio is generated, you can listen before continuing.
echo.

set "SCRIPT=%~dp0agent\tools\tts_runner.py"

python "!SCRIPT!" --mode interactive

if errorlevel 1 (
    echo.
    echo [ERROR] TTS Runner failed!
    pause
    exit /b 1
)

echo.
echo ================================================================================
echo  [OK] 0_INTERACTIVESTART complete!
echo ================================================================================
pause
