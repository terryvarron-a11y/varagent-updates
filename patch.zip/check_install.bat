@echo off
chcp 866 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo ================================================================================
echo  SCENAGENT RTG - CHECKER
echo ================================================================================
echo.

set "ERRORS=0"
set "PYTHON_CMD=python"

REM ============================================================================
REM 1. PYTHON
REM ============================================================================
echo [1/5] Python...

python --version >nul 2>&1
if not errorlevel 1 (
    for /f "tokens=2" %%v in ('python --version 2^>^&1') do set PYVER=%%v
    echo  [OK] Python !PYVER!
    goto :py_ok
)

py --version >nul 2>&1
if not errorlevel 1 (
    for /f "tokens=2" %%v in ('py --version 2^>^&1') do set PYVER=%%v
    echo  [OK] Python !PYVER! (py launcher)
    set "PYTHON_CMD=py"
    goto :py_ok
)

echo  [ERROR] Python not found!
set /a ERRORS+=1

:py_ok

REM ============================================================================
REM 2. PIP
REM ============================================================================
echo.
echo [2/5] pip...

%PYTHON_CMD% -m pip --version >nul 2>&1
if not errorlevel 1 (
    echo  [OK] pip available
    goto :packages
)

echo  [ERROR] pip not found!
set /a ERRORS+=1

:packages
REM ============================================================================
REM 3. PACKAGES
REM ============================================================================
echo.
echo [3/5] Python packages...

set "PKG_ERRORS=0"

%PYTHON_CMD% -c "import assemblyai" 2>nul && (echo   [OK] assemblyai) || (echo   [MISS] assemblyai & set /a PKG_ERRORS+=1)
%PYTHON_CMD% -c "import google.genai" 2>nul && (echo   [OK] google.genai) || (echo   [MISS] google.genai & set /a PKG_ERRORS+=1)
%PYTHON_CMD% -c "import dotenv" 2>nul && (echo   [OK] python-dotenv) || (echo   [MISS] python-dotenv & set /a PKG_ERRORS+=1)
%PYTHON_CMD% -c "import tqdm" 2>nul && (echo   [OK] tqdm) || (echo   [MISS] tqdm & set /a PKG_ERRORS+=1)
%PYTHON_CMD% -c "import httpx" 2>nul && (echo   [OK] httpx) || (echo   [MISS] httpx & set /a PKG_ERRORS+=1)
%PYTHON_CMD% -c "import pydantic" 2>nul && (echo   [OK] pydantic) || (echo   [MISS] pydantic & set /a PKG_ERRORS+=1)

set /a ERRORS+=%PKG_ERRORS%

if %PKG_ERRORS%==0 (
    echo  [OK] All packages installed
) else (
    echo  [WARN] Missing %PKG_ERRORS% package(s)
)

REM ============================================================================
REM 4. FFMPEG
REM ============================================================================
echo.
echo [4/5] FFmpeg...

ffmpeg -version >nul 2>&1
if not errorlevel 1 (
    echo  [OK] FFmpeg installed
    goto :env_check
)

echo  [ERROR] FFmpeg not found!
set /a ERRORS+=1

:env_check
REM ============================================================================
REM 5. .ENV
REM ============================================================================
echo.
echo [5/5] .env file...

if exist "agent\.env" (
    echo  [OK] agent\.env exists
    goto :summary
)

echo  [ERROR] agent\.env not found!
set /a ERRORS+=1

:summary
REM ============================================================================
REM SUMMARY
REM ============================================================================
echo.
echo ================================================================================
echo  RESULT
echo ================================================================================
echo.

if %ERRORS%==0 (
    echo  [OK] All components ready!
    echo.
    echo  You can run:
    echo    run_stage1_simple.bat
    echo    run_stage2_auto.bat
) else (
    echo  [ERROR] Found %ERRORS% error(s)
    echo.
    if %ERRORS% GEQ 3 (
        echo  Recommendation: run install.bat
    )
)

echo.
echo ================================================================================
pause
