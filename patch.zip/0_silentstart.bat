@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

REM ============================================================================
REM 0_SILENTSTART.BAT - Start from TTS stage (Silent Mode)
REM Stage 0: TTS -> Transcription -> Direction
REM ============================================================================

echo.
echo ================================================================================
echo  0_SILENTSTART  [TTS + Pipeline]  SILENT MODE
echo ================================================================================

set "SCRIPT=%~dp0agent\tools\tts_runner.py"
set "ENV_FILE=%~dp0agent\.env"

REM Read TTS settings from .env for display
set "TTS_SERVICE=mat3u"
set "TTS_MAT3U_MODEL_ID=eleven_multilingual_v2"
set "TTS_MAT3U_SPLIT_TYPE=smart"
set "TTS_MAT3U_MAX_CHUNK_LENGTH=1000"
set "TTS_MAT3U_AUTO_PAUSE_ENABLED=false"
set "TTS_CSV666_CHUNK_SIZE=1000"
set "TTS_CSV666_OUTPUT_FORMAT=mp3"
set "ASSEMBLYAI_LANGUAGE_CODE=ru"
set "GEMINI_MODEL=gemini-3.1-pro-preview"
set "VIDEO_CLIP_MIN_DURATION=4"
set "VIDEO_CLIP_MAX_DURATION=8"
set "VEONONSTOP_ASPECT_RATIO=16:9"
set "VEONONSTOP_MAX_PARALLEL=3"

for /f "usebackq tokens=1,* delims==" %%A in ("%ENV_FILE%") do (
    set "KEY=%%A"
    set "VAL=%%B"
    set "KEY=!KEY: =!"
    if "!KEY!"=="TTS_SERVICE"                  set "TTS_SERVICE=!VAL!"
    if "!KEY!"=="TTS_MAT3U_MODEL_ID"           set "TTS_MAT3U_MODEL_ID=!VAL!"
    if "!KEY!"=="TTS_MAT3U_SPLIT_TYPE"         set "TTS_MAT3U_SPLIT_TYPE=!VAL!"
    if "!KEY!"=="TTS_MAT3U_MAX_CHUNK_LENGTH"   set "TTS_MAT3U_MAX_CHUNK_LENGTH=!VAL!"
    if "!KEY!"=="TTS_MAT3U_AUTO_PAUSE_ENABLED" set "TTS_MAT3U_AUTO_PAUSE_ENABLED=!VAL!"
    if "!KEY!"=="TTS_CSV666_CHUNK_SIZE"        set "TTS_CSV666_CHUNK_SIZE=!VAL!"
    if "!KEY!"=="TTS_CSV666_OUTPUT_FORMAT"     set "TTS_CSV666_OUTPUT_FORMAT=!VAL!"
    if "!KEY!"=="ASSEMBLYAI_LANGUAGE_CODE"     set "ASSEMBLYAI_LANGUAGE_CODE=!VAL!"
    if "!KEY!"=="GEMINI_MODEL"                 set "GEMINI_MODEL=!VAL!"
    if "!KEY!"=="VIDEO_CLIP_MIN_DURATION"      set "VIDEO_CLIP_MIN_DURATION=!VAL!"
    if "!KEY!"=="VIDEO_CLIP_MAX_DURATION"      set "VIDEO_CLIP_MAX_DURATION=!VAL!"
    if "!KEY!"=="VEONONSTOP_ASPECT_RATIO"      set "VEONONSTOP_ASPECT_RATIO=!VAL!"
    if "!KEY!"=="VEONONSTOP_MAX_PARALLEL"      set "VEONONSTOP_MAX_PARALLEL=!VAL!"
)

echo.
echo  CURRENT SETTINGS (.env):
echo  -------------------------------------------------------
echo  TTS service:          !TTS_SERVICE!
if /i "!TTS_SERVICE!"=="mat3u" (
    echo  Model ID:             !TTS_MAT3U_MODEL_ID!
    echo  Split type:           !TTS_MAT3U_SPLIT_TYPE!
    echo  Max chunk length:     !TTS_MAT3U_MAX_CHUNK_LENGTH!
    echo  Auto pause:           !TTS_MAT3U_AUTO_PAUSE_ENABLED!
) else (
    echo  Chunk size:           !TTS_CSV666_CHUNK_SIZE!
    echo  Output format:        !TTS_CSV666_OUTPUT_FORMAT!
)
echo  Transcription lang:   !ASSEMBLYAI_LANGUAGE_CODE!
echo  Gemini model:         !GEMINI_MODEL!
echo  Clip duration:        !VIDEO_CLIP_MIN_DURATION!-!VIDEO_CLIP_MAX_DURATION!s
echo  -------------------------------------------------------
echo.

set /p "CONFIRM=All correct? Start pipeline? (y=start / n=switch to interactive): "
echo.

if /i "!CONFIRM!"=="n" (
    echo  Switching to interactive mode...
    echo.
    call "%~dp00_interactivestart.bat"
    exit /b
)

if /i not "!CONFIRM!"=="y" (
    echo  Cancelled.
    pause
    exit /b 1
)

REM ============================================================================
REM  POST-PIPELINE: generation mode (approve once - runs silent, no prompts)
REM ============================================================================

echo  Post-pipeline generation (after TTS + transcription + direction):
echo.
echo    [1] Skip - manual via bat files          (default)
echo    [2] FastGen images only
echo    [3] FastGen images + VeoNonStop i2v      (animate)
echo    [4] VeoNonStop text-to-video (t2v)
echo    [5] VeoNonStop components (t2v + ref/)
echo.
echo  Veo settings from .env: ratio=!VEONONSTOP_ASPECT_RATIO!  parallel=!VEONONSTOP_MAX_PARALLEL!
echo  No further questions after start.
echo.

set "POST_ACTION=skip"
set /p POST_CHOICE="  Post-pipeline [1-5] (Enter = 1 skip): "
if "!POST_CHOICE!"=="2" set "POST_ACTION=fastgen"
if "!POST_CHOICE!"=="3" set "POST_ACTION=fastgen_i2v"
if "!POST_CHOICE!"=="4" set "POST_ACTION=t2v"
if "!POST_CHOICE!"=="5" set "POST_ACTION=components"

echo.
echo  Selected: !POST_ACTION!
echo.

echo ================================================================================
echo  Starting TTS + Pipeline [post-action: !POST_ACTION!]...
echo ================================================================================
echo.

python "!SCRIPT!" --mode silent --post-action !POST_ACTION!

if errorlevel 1 (
    echo.
    echo [ERROR] TTS Runner failed!
    pause
    exit /b 1
)

echo.
echo ================================================================================
echo  [OK] 0_SILENTSTART complete!
echo ================================================================================
pause
