"""
updater.py — Проверка и установка обновлений VARAGENT с GitHub
Версия: 2026.03.24-fix
"""
import hashlib
import json
import ssl
import sys
import urllib.request
import urllib.error
import zipfile
import io
from pathlib import Path, PurePosixPath
from typing import Optional

GITHUB_REPO      = 'terryvarron-a11y/varagent-updates'
VERSION_JSON_URL = f'https://raw.githubusercontent.com/{GITHUB_REPO}/main/version.json'
VERSION_API      = f'https://api.github.com/repos/{GITHUB_REPO}/contents/version.json'
PATCH_URL        = f'https://raw.githubusercontent.com/{GITHUB_REPO}/main/patch.zip'

SKIP_ON_INSTALL = {
    'projects/', '.env', 'agent/.env', 'publisher.py',
    '.codex/', 'Codex/.codex/',
}
# Ставятся ТОЛЬКО если у пользователя такого файла ещё нет — как новые ключи в
# `.env`: новое доезжает, своё остаётся. Обновление везёт весь софт целиком, а
# не изменения, поэтому в архиве лежат БАЗОВЫЕ промпты — те же, что и в прошлой
# версии. Перезаписывая ими, мы стирали правки пользователя ничем не отличающимся
# файлом, да ещё и молча (жалоба пользователя 27.08).
KEEP_IF_EXISTS = ('agent/prompts/',)
UPDATE_RECEIPT = '.varagent_update_state.json'

# Разовая принудительная замена файла из KEEP_IF_EXISTS.
#
# Обычно такой файл не трогаем — см. выше. Но иногда содержимое поставки
# меняется настолько, что старую копию надо заменить ВСЕМ, и правил её
# пользователь или нет, значения не имеет: шаблоны параллакса до 31.08
# разрешали модели дорисовывать в кадр то, чего на снимке не было (в зале
# сами собой достраивались ряды кресел). Замена делается ОДИН раз: у кого она
# уже прошла, тот дальше правит файл как хочет, и обновления его не трогают.
#
# Прежнее содержимое не пропадает — ложится рядом с суффиксом `.bak_<id>`.
# Отметка о выполненной замене хранится отдельным файлом: квитанция обновления
# перезаписывается каждой версией целиком и для этого не годится.
FORCE_ONCE = (
    ('agent/prompts/parallax_prompts.txt',
     '20260831_parallax_no_invented_objects'),
)
FORCE_ONCE_MARKER = '.varagent_forced_replacements'

# Файл шаблонов параллакса, который жил в КОРНЕ установки и правился руками.
# Раньше он читался первым и перебивал поставку — обновления шаблонов до таких
# пользователей не доезжали вовсе. Теперь точка правды одна (agent/prompts/), а
# корневой файл при обновлении отставляется в сторону с этим суффиксом.
LEGACY_PARALLAX_FILENAME = 'паралакс промпты.txt'
LEGACY_MIGRATED_SUFFIX = '.bak_migrated'

# Keys that must exist in agent/.env — added with defaults if missing.
# Order matters: each entry is (KEY, default_value, optional_comment_above).
_ENV_REQUIRED = [
    ('VEONONSTOP_API_KEY_3',  '',     '# VeoNonStop Key3 (optional)'),
    ('VEONONSTOP_KEY3_NAME',  'Key3', None),
    ('VEONONSTOP_API_KEY_4',  '',     '# VeoNonStop Key4 (optional)'),
    ('VEONONSTOP_KEY4_NAME',  'Key4', None),
    ('VEONONSTOP_API_BASE',   'https://veononstop.org/api/v1', '# VeoNonStop base URL per key (empty = use VEONONSTOP_API_BASE)'),
    ('VEONONSTOP_API_BASE_2', '', None),
    ('VEONONSTOP_API_BASE_3', '', None),
    ('VEONONSTOP_API_BASE_4', '', None),
    ('VEONONSTOP_MAX_DOWNLOADS', '12', '# Concurrent finished-video downloads (relay bandwidth cap)'),
    ('VEONONSTOP_USAGE_TIMEOUT', '30', '# /account/usage read timeout (s)'),
    ('VEONONSTOP_USAGE_RETRIES', '1', '# /account/usage transient retries'),
    ('VEONONSTOP_USAGE_RETRY_DELAY', '1.5', '# /account/usage retry backoff (s)'),
    ('VEONONSTOP_USAGE_FAIL_SOFT_ERRORS', '1', '# Usage poll errors before fail-soft'),
    ('SYNTHID_CLEAN_ENABLED', 'false',    '# SynthID image watermark removal (inflight, per-image)'),
    ('SYNTHID_STRENGTH',      'moderate', None),
    ('SYNTHID_VERSION',       'v1',       None),
    ('SYNTHID_SAVE_ORIG',          'false',  None),
    ('VEONONSTOP_RECAPTCHA_DELAY', '8.0',   '# reCAPTCHA retry base delay (s). Chrome: 3.0 | Dolphin+free proxy: 8.0 | Residential: 3.0'),
    ('VEONONSTOP_RECAPTCHA_JITTER','3.0',   None),
    ('VEONONSTOP_MAX_TIMEOUT_RETRIES', '5', '# Max server-timeout retries per clip before counting as failed attempt'),
    ('AUDIO_CLEAN_ENABLED',   'false',    '# Audio AI fingerprint removal (disabled)'),
    ('AUDIO_CLEAN_LEVEL',     'moderate', None),
    ('ASSEMBLYAI_SPEECH_MODELS', 'universal-3-pro,universal-2', '# AssemblyAI speech models (fallback chain)'),
    ('TTS_API_KEY_VOICEGEN', '', '# Voicegen TTS key (api.qw1voicegencore.pro)'),
    ('TTS_VOICEGEN_BASE_URL', 'https://api.qw1voicegencore.pro/api/v1', None),
    ('TTS_VOICEGEN_ENGINE', 'elevenLabsV3', '# Voicegen engine'),
    ('TTS_VOICEGEN_STABILITY', '0.5', None),
    ('TTS_VOICEGEN_CHUNK_SIZE', '1200', None),
    ('TTS_VOICEGEN_DELAY_BETWEEN_CHUNKS', '0.5', None),
    ('TTS_VOICEGEN_THREAD_COUNT', '10', None),
    ('TTS_API_KEY_LUMEAN', '', '# Lumean Public API key (api.lumean.app)'),
    ('TTS_LUMEAN_BASE_URL', 'https://api.lumean.app/api/public', None),
    ('TTS_LUMEAN_POLL_INTERVAL', '5', '# Lumean order polling interval (s)'),
    ('TTS_LUMEAN_POLL_TIMEOUT', '7200', '# Lumean order polling timeout (s)'),
    ('KIE_AI_API_KEY', '', '# Kie.ai API key (image remix)'),
    ('FASTGEN_API_KEY_BACKUP', '', '# FastGen backup API key'),
    ('FASTGEN_API_KEY_3', '', '# FastGen Key3 (optional)'),
    ('FASTGEN_API_KEY_4', '', '# FastGen Key4 (optional)'),
    ('FASTGEN_MAX_PARALLEL_2', '10', '# FastGen Key2 max workers'),
    ('FASTGEN_MAX_PARALLEL_3', '10', '# FastGen Key3 max workers'),
    ('FASTGEN_MAX_PARALLEL_4', '10', '# FastGen Key4 max workers'),
    ('FASTGEN_QUOTA_FALLBACK_VEONONSTOP', 'on',
     '# FastGen ImageGen: hourly quota gone on all keys -> remap the rest to VeoNonStop Banana Pro (on|off). No live VeoNonStop image quota -> wait for FastGen hourly reset'),
    ('VEONONSTOP_QUOTA_FALLBACK_FASTGEN', 'on',
     '# VeoNonStop ImageGen: daily image quota gone -> switch to a spare VeoNonStop key with real quota, otherwise hand the rest to FastGen (on|off)'),
    ('VEONONSTOP_QUOTA_FALLBACK_T2V', 'off',
     '# VeoNonStop ImageGen exhausted: use T2V for remaining clips instead of waiting for FastGen hourly quota (on|off; no FastGen key always uses T2V)'),
    ('VEONONSTOP_I2V_PARALLAX', 'off',
     '# I2V: replace per-clip prompts with the selected editable parallax template (on|off)'),
    ('VEONONSTOP_I2V_PARALLAX_METHOD', '1',
     '# I2V parallax template: 1=Balanced, 2=Strict, 3=Mechanical'),
    ('VEONONSTOP_I2V_PARALLAX_MIX_PERCLIP', 'off',
     '# I2V parallax: alternate parallax and normal per-clip prompts (on|off)'),
    ('VEONONSTOP_I2V_PARALLAX_EVERY_N', '2',
     '# I2V parallax mixed mode: apply parallax to every Nth clip ID'),
    ('VEONONSTOP_I2V_PARALLAX_AI', 'on',
     '# Parallax for AI frames. With video generation off they are animated by the background parallax pass (on|off)'),
    ('VEONONSTOP_I2V_PARALLAX_STOCK', 'off',
     '# Parallax for stock photos: they never reach i2v, so a separate pass animates them (on|off)'),
    ('VEONONSTOP_I2V_PARALLAX_REAL_PHOTO', 'off',
     '# Parallax for Real Photo stills, same separate pass (on|off)'),
    ('VEONONSTOP_I2V_PARALLAX_WAIT_TIMEOUT', '500',
     '# Seconds to let parallax finish once every stage is done; frames it misses stay stills with zoom'),
    ('VIDEO_LIVE_ANIMATE', '0',
     '# Animate frames as they appear, without waiting for ImageGen to finish (0|1). '
     'When images run on the SAME VeoNonStop key, animation still waits: slots are shared'),
    ('VARAGENT_LIVE_ANIMATE', '0',
     '# Same switch as VIDEO_LIVE_ANIMATE, under the name the GUI reads back on start; '
     'both are written together so the checkbox survives a restart'),
    ('VEONONSTOP_BANANA_MODEL_CHAIN', 'GEM_PIX_2,NARWHAL,HARBOR_SEAL',
     '# Per-clip model retry order on ALL_COOKIES_EXHAUSTED_FOR_MODEL (service-side cookie pool per model, not our key quota)'),
    ('DIRECTOR_BACKEND', 'gpt', '# Director backend (gemini or gpt)'),
    ('DIRECTOR_PROFILE', 'standard', '# Director behavior: standard | auto_visual_story'),
    ('VISUAL_STORY_MIN_SCENE_DURATION', '4.0', '# Legacy fallback only; runtime inherits active GUI clip_min'),
    ('VISUAL_STORY_TARGET_SCENE_DURATION', '6.0', '# Legacy fallback only; runtime derives target from active ranges'),
    ('VISUAL_STORY_MAX_SCENE_DURATION', '8.0', '# Legacy fallback only; runtime inherits active GUI clip_max'),
    ('VISUAL_STORY_CONTEXT_BEFORE', '2', '# Previous scene count in deterministic context packet'),
    ('VISUAL_STORY_CONTEXT_AFTER', '2', '# Following scene count in deterministic context packet'),
    ('VISUAL_STORY_VISUAL_HISTORY', '4', '# Recent selected visuals exposed to the query creator'),
    ('VISUAL_STORY_ALLOW_REUSE', 'true', '# Allow reuse_previous decisions'),
    ('VISUAL_STORY_MUST_HAVE', 'false', '# must_have frozen: false = not generated, not sent to vision'),
    ('VISUAL_STORY_CHAPTER_WORKERS', '4', '# Stage 2 (chapter chunks) parallel workers'),
    ('VISUAL_STORY_CHAPTER_MAX_SCENES', '60', '# Stage 2: max scenes per chunk, longer chapters split by code'),
    ('YOUTUBE_MATCH_ORIENTATION', 'true', '# YouTube: skip videos whose orientation mismatches the project (Shorts in 16:9)'),
    ('YOUTUBE_DISCOVERY_LIMIT', '12', '# YouTube: videos to fetch from search per clip (separate from the pool of parts)'),
    ('YOUTUBE_FRAGMENT_TOLERANCE_SEC', '1.0', '# YouTube: equal pieces per scene may exceed YOUTUBE_MAX_FRAGMENT_SEC by up to this'),
    ('VISUAL_STORY_REQUIRE_WORD_TIMESTAMPS', 'true', '# Refuse LLM-invented timing when word timestamps are missing'),
    ('VISUAL_STORY_FALLBACK', 'archive', '# Unresolved visual: stop | reuse_previous | archive | ai'),
    ('VISUAL_STORY_EPF_TIMEOUT', '180', '# EPF timeout per Auto Visual Story search'),
    ('GPT_MODEL', 'gpt-5.4', None),
    ('GPT_PROVIDER', 'openai', '# GPT provider: openai (Codex auth) | deepseek | openrouter | codex_reseller | gpt_nexus | meta_muse (direct chat API)'),
    ('DEEPSEEK_API_KEY', '', '# DeepSeek API key — needed when GPT_PROVIDER=deepseek'),
    ('DEEPSEEK_MODEL', 'deepseek-v4-flash', '# DeepSeek model: deepseek-v4-flash | deepseek-v4-pro'),
    ('OPENROUTER_API_KEY', '', '# OpenRouter API key — needed when GPT_PROVIDER=openrouter'),
    ('OPENROUTER_MODEL', 'openrouter/free', '# OpenRouter model: openrouter/free (auto), qwen/qwen3-coder:free, etc'),
    ('OPENROUTER_WEB_SEARCH', 'disabled', '# OpenRouter web search: enabled (:online) | disabled'),
    ('CODEX_RESELLER_URL', 'https://ai.ailink1.com/v1/chat/completions', '# Codex/GPT reseller OpenAI-compatible endpoint'),
    ('CODEX_RESELLER_API_KEY', '', '# Codex/GPT reseller API key'),
    ('CODEX_RESELLER_MODEL', 'gpt-5.6-terra', '# Codex/GPT reseller model'),
    ('GPT_NEXUS_URL', 'https://ccmaxshop.de5.net/v1/chat/completions', '# GPT Nexus OpenAI-compatible endpoint'),
    ('GPT_NEXUS_API_KEY', '', '# GPT Nexus API key'),
    ('GPT_NEXUS_EXTRA_API_KEYS', '', '# Optional additional GPT Nexus keys'),
    ('GPT_NEXUS_MODEL', 'gpt-5.5', '# GPT Nexus model'),
    ('GPT_NEXUS_USER_AGENT', 'codex_cli_rs/latest', '# Nexus gateway client identity'),
    ('META_MUSE_URL', 'https://api.meta.ai/v1/chat/completions', '# Meta Muse Spark OpenAI-compatible text endpoint'),
    ('META_MUSE_API_KEY', '', '# Meta Muse API key'),
    ('META_MUSE_MODEL', 'muse-spark-1.2-contributor', '# Approved Meta Muse Contributor model'),
    ('META_MUSE_MAX_TOKENS', '96000', '# Meta Muse reserve: reasoning and visible completion share this output budget'),
    ('CLIPROXY_BASE_URL', 'http://localhost:8317/v1/chat/completions', '# CLIProxyAPI local proxy → Gemini Pro (Antigravity OAuth). Director: GPT_PROVIDER=cliproxy'),
    ('CLIPROXY_API_KEY', 'varagent-cliproxy-local', '# Local proxy auth key (matches api-keys in ~/.cli-proxy-api/config.yaml). NOT an external secret'),
    ('CLIPROXY_MODEL', 'gemini-3.1-pro-low', '# CLIProxyAPI model (Gemini 3.1 Pro via Antigravity)'),
    ('CHAT_REASONING_LEVEL', 'medium', '# Reasoning for direct chat director: off|low|medium|high|max'),
    ('CHAT_MAX_TOKENS', '64000', '# Max output tokens per chat request (Pass2 chunk). DeepSeek max=64K'),
    ('PASS2_EXTERNALIZE_NEGATIVE', '1', '# Pass2: externalize NEGATIVE block from model output (append by script). 1=on 0=off'),
    ('PASS2_EXTERNALIZE_REFMATCH', '1', '# Pass2: externalize ref hard-match signature (append by script to first token). 1=on 0=off'),
    ('PASS2_EXTERNALIZE_STYLE', '1', '# Pass2: externalize STYLE block from model output (append by script). 1=on 0=off'),
    ('STYLE_EXTRACT_MODE', 'neuro', '# How to find style/negative blocks: neuro (LLM, any SG) | regex (anchors) | off'),
    ('STYLE_EXTRACT_BACKEND', '', '# Neuro-extract backend: gpt_nexus|codex_reseller|deepseek|openrouter|meta_muse|gemini|claude_api (empty=auto-pick)'),
    ('STYLE_EXTRACT_MODEL', '', '# Model slug for neuro-extract (empty=provider default)'),
    ('GPT_PASS2_CHUNK_SIZE', '150', None),
    ('GPT_PASS2_PARALLEL', '6', None),
    ('GPT_REWRITE_TIMEOUT', '90', '# Codex rewrite per-call timeout (s) — prevents pipeline stall on hung rewrite'),
    ('YT_PACK_GPT_TIMEOUT', '600', '# YT Packer Codex timeout (s) — big multi-language prompts need 10 min'),
    ('GPT_HIGH_DEMAND_COOLDOWN', '90', '# Cooldown (s) before retry when OpenAI returns "high demand" / Reconnecting...'),
    ('REWRITE_MODEL', 'gemini:gemini-2.5-flash-lite', '# Rewrite model (provider:model) — flash-lite has 1000 RPD free-tier vs 20 on flash'),
    ('REMIX_ENGINE', 'grok', '# Remix engine (grok, kieai, flower, openai or off)'),
    ('VEONONSTOP_REF_MODE', 'name_match', '# Ref mode: name_match (by prompt names) or use_all (all refs on every prompt)'),
    ('VEONONSTOP_FAST_CENSOR', 'off', '# Fast censor bypass: off | after_rewrites | ultrafast'),
    ('VEONONSTOP_IMAGE_UPSCALE', 'off', '# VeoNonStop image upscale: off | 2K | 4K'),
    ('VEONONSTOP_VIDEO_UPSCALE', 'false', '# VeoNonStop video upscale: true|false'),
    ('VEONONSTOP_MAX_RETRIES', '5', '# VeoNonStop max retries per task'),
    ('VEONONSTOP_MAX_SILENT_CYCLES', '5', '# VeoNonStop max silent poll cycles before giving up'),
    ('PIPELINE_VISLIDE_INTERVAL', '3', '# Vislide mode: seconds per slide'),
    ('YT_PACK_COVER_PROVIDER', 'fastgen', '# YT pack cover provider: fastgen | veononstop'),
    ('VIDEO_FPS', '25', '# Concat output FPS'),
    ('CONCAT_BITRATE', '10M', '# Concat output video bitrate'),
    ('PIPELINE_TRANSITIONS', 'false', '# Переходы между клипами (dip-to-X): true|false (опция, дефолт выкл)'),
    ('PIPELINE_TRANSITION_DURATION', '0.5', '# Длительность перехода в секундах'),
    ('PIPELINE_TRANSITION_STYLES', 'fade', '# Стиль(и) перехода через запятую (fade,wipeleft,dissolve,...)'),
    ('PIPELINE_ZOOM_STYLES', 'in-center', '# Ken Burns zoom-стиль(и): in-center (как было)|out-left|... через запятую'),
    ('VISION_CHECK_MODEL', 'gemini-2.5-flash-lite', '# Gemini model for vision_checks (image safety scans) — flash-lite: 1000 RPD free-tier'),
    ('VISION_API_KEY', '', '# Free-tier Gemini key for vision_checks + rewrite (paid quota NOT touched)'),
    ('GEMINI_API_KEY_FREE', '', '# Free-tier fallback for VISION_API_KEY (paid GEMINI_API_KEY intentionally not used)'),
    ('STORY_MODE', 'off', '# Chain mode: off (independent) | batch (morph imggen pairs) | morph (one chain) | chain (LLM-decided chains)'),
    ('CHAIN_IMGGEN_HEADS_ONLY', '1', '# Gen images only for chain heads (skip extends) — saves ~85% imggen'),
    ('VIDEO_EXTEND_FRAME_OFFSET', '0.5', '# Seconds from end to extract last frame (ffmpeg -sseof offset)'),
    ('VIDEO_EXTEND_TRIM_FRAMES', '1', '# video_concat.py: skip N first frames of extend clips (fps-independent via select filter)'),
    ('VIDEO_EXTEND_MUTE_AUDIO', '1', '# Mute audio for extend clips (VEO sound artifacts on each extend start)'),
    ('VIDEO_EXTEND_MAX_CHAIN', '10', '# Soft safety net: max clips in one chain before forced break (0=unlimited)'),
    ('CHAIN_CASCADE_RECOVERY', '1', '# Cascade recovery: regen prev clip on fail instead of immediate force break'),
    ('CHAIN_MAX_SAME_CLIP_FAILS', '3', '# Max fails of same clip before forced sub-chain head (prevents infinite loop)'),
    ('USATAYAI_GENERATOR_BRIDGE_MANIFEST', '', '# Generator bridge: delegate imggen/video to external app (e.g. Usataya). Empty=native VARAGENT.'),
    ('USATAYAI_BRIDGE_MANIFEST', '', '# Final bridge: post-concat processing (subtitles ASS, watermarks, logo). Empty=plain audio mux.'),
    # Real Photo Stage (archival photo/video insertion between Director and ImgGen)
    ('REAL_PHOTO_ENABLED',      'false', '# Real Photo stage: replace part of AI clips with archival photos/videos (off by default)'),
    ('REAL_PHOTO_RATIO_TARGET', '0.40',  '# Target % of clips to replace (0.0..1.0)'),
    ('REAL_PHOTO_RATIO_MIN',    '0.30',  '# Hard floor for replacement %'),
    ('REAL_PHOTO_RATIO_MAX',    '0.55',  '# Hard ceiling for replacement %'),
    ('REAL_PHOTO_EPF_BRIDGE',   '0',     '# Automatically run Extreme Picture Finder for selected Real Photo queries'),
    ('REAL_PHOTO_EPF_VISIBLE',  '0',     '# Show EPF windows while automatic searches run'),
    ('REAL_PHOTO_EPF_EXE',      '',      '# Optional EPF.exe override. Empty = auto-detect'),
    ('REAL_PHOTO_EPF_DATA_DIR', '',      '# Optional EPF data folder override. Empty = auto-detect'),
    ('REAL_PHOTO_EPF_ENGINES',  'google,bing', '# Comma-separated EPF image-search engines'),
    ('REAL_PHOTO_EPF_CANDIDATES', '12',  '# Candidate downloads per Real Photo clip'),
    ('REAL_PHOTO_VISION_CANDIDATES', '4', '# Archive path (Wikimedia/NASA/...): candidates shown to vision per source. 0 = first hit wins'),
    ('REAL_PHOTO_EPF_SEARCH_TIMEOUT', '180', '# Max seconds to wait for each EPF search'),
    ('REAL_PHOTO_EPF_DOWNLOAD_URL', 'https://drive.google.com/file/d/1xDYIqq6SKQDBEKJKaa9U_mB10I8nfZsy/view?usp=sharing', '# Google Drive URL for the verified VarAgent EPF portable bundle'),
    ('REAL_PHOTO_EPF_DOWNLOAD_SHA256', 'C3AE2A7F574511F915E66C6C717372BE3AE58B01331D4EA3C3836F4843489A5F', '# Required EPF bundle SHA-256'),
    ('REAL_PHOTO_VISION_PROVIDER', 'gemini', '# Vision selector: gemini|gpt_nexus|cliproxy|deepseek|openrouter|claude_api|codex_reseller'),
    ('REAL_PHOTO_VISION_MODEL', 'gemini-2.5-flash', '# Vision model used to choose one EPF candidate per clip'),
    ('REAL_PHOTO_START_SEC',    '15',    '# Archival photos legit only from this second onward (intro hook not marked). 0 = off. Added once, your value is kept on updates'),
    ('STOCK_START_SEC',         '0',     '# Stock footage allowed only from this second onward (intro hook stays generated). 0 = off'),
    ('INFOGRAPHIC_START_SEC',   '0',     '# Infographics allowed only from this second onward (a chart in the hook kills it). 0 = off'),
    ('REAL_PHOTO_SEARCH_DEPTH', '6',     '# How many records/articles to probe per archival source before next source in cascade (Wikipedia = N articles, pageimage each). Yandex exempt.'),
    ('CLIPROXY_REQUIRE_PROXY',  'true',  '# Require proxy when adding a CLIProxyAPI Gemini account. false = allow no-proxy (own VPN)'),
    ('CODEX_PROXY',             '',      '# Optional HTTP(S) proxy for codex.exe traffic (geo-block workaround). Format: http://user:pass@host:port. Empty = direct'),
    ('CLAUDE_PROXY',            '',      '# Optional HTTP(S) proxy for Claude Code CLI traffic. Empty = direct'),
    ('PASS1_CHUNK_ENABLED',     'false', '# Chunked Pass 1 for chat directors (DeepSeek/OpenRouter/CLIProxy): long audio is split into windows, plans stitched'),
    ('PASS1_CHUNK_MINUTES',     '20',    '# Pass 1 chunk window size, minutes'),
    ('PASS1_PARALLEL',          '1',     '# Parallel Pass 1 chunk requests (1 = sequential)'),
    ('SUBTITLE_PHRASE_LEN',     '50',    '# Subtitle phrase split length (see SUBTITLE_PHRASE_UNIT)'),
    ('SUBTITLE_PHRASE_UNIT',    'chars', '# Subtitle phrase unit: chars | words'),
    # ── Pipeline GUI toggles ("Save Defaults" persists them; GUI reads them back) ──
    ('VARAGENT_SUBTITLES_ENABLED', '0',      '# Pipeline tab: burn subtitles into the final video (1/0)'),
    ('VARAGENT_SUBTITLES_PRESET',  'bottom', '# Pipeline tab: subtitle template preset (bottom | center)'),
    ('VARAGENT_SUBTITLES_CUSTOM',  '0',      '# Pipeline tab: use a custom .ass template instead of the preset (1/0)'),
    ('VARAGENT_SUBTITLES_PATH',    '',       '# Pipeline tab: path to the custom .ass template'),
    ('VARAGENT_YT_PACK_ENABLED',   '0',      '# Pipeline tab: run the YouTube packer after concat (1/0)'),
    ('VARAGENT_SKIP_PREFLIGHT',    '0',      '# Pipeline tab: skip provider preflight checks (1/0)'),
    ('VARAGENT_CODEX_ADAPT',       '0',      '# Pipeline tab: Codex VEO prompt adaptation in per-clip mode (1/0)'),
    ('VARAGENT_FASTGEN_KEY_SLOT',  'main',   '# Pipeline tab: FastGen key selection (main | backup | key3 | key4 | both)'),
    ('VARAGENT_SG_MODE',           'one_for_all', '# Pipeline tab: style guide mode (one_for_all | individual)'),
    ('VARAGENT_SG_ADAPT',          '0',           '# Pipeline tab: adapt style guide per file (1/0)'),
    ('VARAGENT_REF_MODE',          'one_for_all', '# Pipeline tab: reference images mode (one_for_all | individual)'),
    ('VARAGENT_LOGO_MODE',         'one_for_all', '# Pipeline tab: logo mode (one_for_all | individual)'),
    ('VARAGENT_SCRIPT_TYPE',       'prose',       '# Pipeline tab: script type for script-start runs'),
    ('VARAGENT_VEO_ADV_VISIBLE',   '0',           '# Pipeline tab: keep the advanced video card expanded (1/0)'),
    ('VARAGENT_MUSIC_ENABLED',     '0',      '# Pipeline tab: background music stage (1/0)'),
    ('VARAGENT_MUSIC_REVIEW_GUI',  '0',      '# Pipeline tab: review generated music in the GUI before concat (1/0)'),
    ('MUSIC_TRACK_RETRIES',   '1',   '# Repeat a failed Suno track generation N times before giving up'),
    ('MUSIC_CAPTCHA_COOLDOWN','600', '# Wait, seconds, after Cloudflare captcha before retrying music generation'),
    ('MUSIC_CAPTCHA_RETRIES', '2',   '# How many times to wait out the captcha and retry'),
    ('PIPELINE_INFLIGHT_MODE',     'false',  '# Pipeline tab: start video generation as soon as each frame is ready (inflight)'),
    ('CINAI_VIDEO_CHAIN',         '1',   '# CinAI: frame+video in one graph (sticky node). 0 = separate ImageGen then i2v'),
    ('CINAI_VIDEO_DIRECT_TIMING', '1',   '# CinAI: order each clip its own duration from montage_plan (models with a smooth range, e.g. omni 3-10s)'),
    ('REAL_PHOTO_SOURCES',      'wikimedia,yandex,nasa,loc,met,getty,europeana,smithsonian,archive',
        '# Archive sources, comma-separated. Wiki(article-pageimage)/Yandex(web, no key)/NASA/LoC/Met/Getty/Archive = no key. Europeana/Smithsonian = optional free keys.'),
    ('REAL_PHOTO_YANDEX_EXCLUDE', '-нейросеть -нейро -ии -ai -midjourney -render -3d -рендер',
        '# Yandex minus-flags: exclude AI/3D-generated from results (engravings/maps/schematics kept)'),
    ('REAL_PHOTO_CODEX_MODEL',  'gpt-5.5', '# Codex model for clip selection / keyframe pick'),
    ('REAL_PHOTO_PROMPT_PROVIDER', 'codex',
        '# Real Photo query prompter (independent of director): codex|gpt_nexus|codex_reseller|cliproxy|deepseek|openrouter|meta_muse. chat-providers are more reliable than Codex CLI'),
    ('REAL_PHOTO_PROMPT_MODEL', '',
        '# Prompter model. Empty = provider default (CLIPROXY_MODEL / DEEPSEEK_MODEL / ...)'),
    ('ENTITY_OVERLAY_MODEL', '',
        '# Entity-card detection model. Empty = provider default'),
    ('YT_PACK_BACKEND', 'gemini',
        '# YT Packer operator: gemini|codex|gpt_nexus|codex_reseller|cliproxy|deepseek|openrouter|meta_muse|claude_api (empty = by model name)'),
    ('EUROPEANA_API_KEY',       '', '# Optional: free key from https://pro.europeana.eu/page/get-api'),
    ('SMITHSONIAN_API_KEY',     '', '# Optional: free key from https://api.data.gov/signup/'),
    ('RIJKSMUSEUM_API_KEY',     '', '# Optional: free key from https://data.rijksmuseum.nl'),
    ('REAL_PHOTO_SOURCE_MIX',   '1',
        '# Real Photo: 1 = candidates from ALL enabled sources go to vision on ONE contact sheet\n'
        '# (best of everything found, default); 0 = cascade, first source whose candidate passes wins'),
    ('REAL_PHOTO_MIX_MAX_CANDIDATES', '16', '# Max candidates on the mixed contact sheet'),
    ('REAL_PHOTO_NO_STOCK_PHOTOS', '1',
        '# 1 = keep photo-stock sites out: minus-words in the EPF search phrase + drop\n'
        '# downloads from stock domains; 0 = rely on vision alone (it sees the watermark)'),
    ('REAL_PHOTO_NO_MARKETPLACES', '1',
        '# 1 = keep marketplace product shots out (Amazon, eBay, AliExpress, WB, Ozon...):\n'
        '# they carry burned-in ad captions and no watermark, so vision lets them through'),
    ('STOCK_VISION_PROVIDER',   '',
        '# Stock vision picker: gemini|claude_code|codex_reseller|gpt_nexus|cliproxy|deepseek|openrouter|claude_api\n'
        '# (empty = same as Real Photo vision)'),
    ('STOCK_VISION_MODEL',      '', '# Stock vision model (empty = same as Real Photo)'),
    ('SERPER_API_KEY',          '', '# Optional: Real Photo source "Google (Serper)" — key from https://serper.dev (2500 free queries)'),
    ('OPENVERSE_CLIENT_ID',     '', '# Optional: Openverse registered client (empty = anonymous, 200 requests/day)'),
    ('OPENVERSE_CLIENT_SECRET', '', ''),
    # Smooth zoom для статичных кадров (Ken Burns в video_concat.py через scale eval=frame + crop)
    ('ZOOM_AMOUNT', '0.10', '# Smooth zoom amplitude per clip: 0.05 / 0.10 / 0.15 / 0.20'),
    ('ZOOM_CURVE',  'linear', '# Zoom curve: linear / constant_speed / ease_out'),
    ('ZOOM_SUPERSAMPLE', '2',
     '# Плавность зума: 1 = как раньше, 2 = без дрожания (+~25% времени), 3 = максимум (+~50%)'),
    # FastGen v5 endpoint (named refs binding по [name_ref] токенам в промпте).
    # 1 = использовать /v5/generations для flow/openai/grok/flower image + flow-ultra video + preflight.
    # 0 = legacy v4 (default — пока v5 в обкатке).
    ('REAL_PHOTO_PROMPT_FALLBACK', '1', '# Pass2 пишет промпты и для real_photo (страховка): провал/таймаут загрузки -> догенерация. 1=on'),
    ('REAL_PHOTO_WAIT_TIMEOUT', '1800', '# Макс время фоновой загрузки real_photo (s); дедлайн=MIN(конец генерации, это)'),
    # --- CINAI.TV (reverse Studio API: image + video generation) ---
    ('CINAI_ACCESS_TOKEN', '', '# CinAI Studio bearer token (captured by one-time browser login in Settings)'),
    ('CINAI_REFRESH_TOKEN', '', '# CinAI refresh token (rotated automatically by headless refresh)'),
    ('CINAI_TRANSPORT', 'workflow', '# CinAI transport: workflow (direct graph, verbatim prompt) | agent (legacy LLM runner)'),
    ('CINAI_API_BASE', 'https://api.cinai.tv', '# CinAI API host'),
    ('CINAI_APP_ID', 'runway-workflows', '# CinAI X-App-Id header'),
    ('CINAI_MODEL', 'gpt-image-2', '# CinAI image model slug'),
    ('CINAI_IMAGE_POOL_ENABLED', 'false', '# Add CinAI workers to the selected primary ImageGen provider'),
    ('CINAI_ASPECT_RATIO', '16:9', '# CinAI image aspect ratio'),
    ('CINAI_QUALITY', '1K', '# CinAI image quality: 1K | 2K | 4K'),
    ('CINAI_MAX_PARALLEL', '6', '# CinAI image workers (account max_concurrent_executions = 6)'),
    ('CINAI_TIMEOUT', '900', '# CinAI image SSE timeout (s)'),
    ('CINAI_MAX_RETRIES', '3', '# CinAI image retries per clip'),
    ('CINAI_TOKEN_REFRESH_SKEW_SECONDS', '300', '# Refresh CinAI token when < N seconds to expiry'),
    ('PIPELINE_VIDEO_ENGINE', 'veononstop', '# Video engine radio: veononstop | cinai | both_cinai | fastgen_ultra'),
    ('CINAI_VIDEO_ENABLED', 'false', '# CinAI VideoGen engine (set by GUI engine selector)'),
    ('CINAI_VIDEO_MODEL', 'seedance-2-0-lite', '# CinAI video model: seedance-2-0-lite | gemini-omni-flash | grok-video-i2v'),
    ('CINAI_VIDEO_MODE', 't2v', '# CinAI video mode for CLI runs: t2v | i2v | first_last | reference'),
    ('CINAI_VIDEO_RESOLUTION', '480p', '# CinAI video resolution (model-dependent: 480p/720p; Omni = 720p only)'),
    ('CINAI_VIDEO_DURATION', '5', '# CinAI video duration seconds (Grok: only 6/10/15)'),
    ('CINAI_VIDEO_AUDIO', '', '# CinAI audio toggle — Omni only: empty = model default, 1/0 = on/off'),
    ('CINAI_VIDEO_MAX_PARALLEL', '6', '# CinAI video workers (capped at 6)'),
    ('CINAI_MAX_CONCURRENT_EXECUTIONS', '6', '# Account-wide executions budget shared by all CinAI stages'),
    ('CINAI_VIDEO_MAX_RETRIES', '3', '# CinAI video retries per clip'),
    ('CINAI_VIDEO_RETRY_BASE_SECONDS', '5', '# CinAI video retry backoff base (s)'),
    ('CINAI_VIDEO_TIMEOUT', '1200', '# CinAI video SSE timeout (s)'),
    ('CINAI_VIDEO_MIN_BYTES', '32768', '# Reject downloaded video smaller than this (preview guard)'),
    ('CINAI_VIDEO_INFLIGHT_DRAIN_SECONDS', '120', '# Inflight: drain window after ImageGen done marker (s)'),
    ('CINAI_VIDEO_INFLIGHT_ACTIVE_GRACE_SECONDS', '120', '# Inflight: extra grace for already-submitted jobs (s)'),
    # --- INFOGRAPHIC (separate AI still route) ---
    ('INFOGRAPHIC_ENABLED', 'false', '# Enable director-selected infographic stills'),
    ('INFOGRAPHIC_RATIO_TARGET', '0.15', '# Target share of clips for infographics (0.0..1.0)'),
    ('INFOGRAPHIC_RATIO_MAX', '0.25', '# Hard ceiling for infographic share (0.0..1.0)'),
    ('INFOGRAPHIC_IMG_PROVIDER', 'fastgen', '# Dedicated infographic image provider: fastgen | veononstop | cinai'),
    ('INFOGRAPHIC_CINAI_MODEL', '', '# CinAI model for infographic clips (empty = CINAI_MODEL)'),
    ('INFOGRAPHIC_FASTGEN_MODEL', 'GEM_PIX', '# FastGen model for infographic clips'),
    ('INFOGRAPHIC_VEONONSTOP_MODE', 'imagen', '# VeoNonStop image mode for infographic clips'),
    ('INFOGRAPHIC_VEONONSTOP_BANANA_MODEL', 'GEM_PIX_2', '# Banana model for infographic clips'),
    ('INFOGRAPHIC_STATIC_CONCAT', 'true', '# Do not animate infographic stills in concat'),
    # --- MUSIC (Pass 3 — Suno) ---
    # --- STOCK (Pexels / Pixabay / own folder) ---
    ('STOCK_ENABLED', 'false', '# Stock footage/photos instead of AI generation: true|false'),
    ('STOCK_SOURCES', 'local,pexels,pixabay', '# Stock sources: local | pexels | pixabay | envato. Clips split evenly'),
    ('STOCK_LIBRARY_DIR', '', '# Own footage folder (scanned with subfolders). Empty = source off'),
    ('STOCK_RATIO_TARGET', '0.30', '# Share of ALL clips marked for stock by the director'),
    ('STOCK_VIDEO_SHARE', '0.70', '# Of stock clips: share of video, rest = photo'),
    ('STOCK_VISION_CANDIDATES', '5', '# Stock vision: footage candidates to download and show to vision (3 frames each). 0 = off'),
    ('STOCK_MUTE_AUDIO', 'true', '# Strip footage audio. Keep ON: audio is the main Content ID claim channel'),
    ('STOCK_EXCLUDE_AI', 'true', '# Drop AI-generated stock (Pixabay reports it; Pexels has no such flag)'),
    ('STOCK_CLIP_START_SEC', '0', '# Cut footage from this second. 0 = from the start'),
    ('STOCK_CLIP_START_JITTER', 'false', '# Randomize start point (similar footage → different first frames)'),
    ('STOCK_CLIP_START_JITTER_SEC', '2', '# Jitter range in seconds (+/-)'),
    ('STOCK_PROMPT_FALLBACK', 'true', '# Nothing found -> clip goes to normal AI generation'),
    ('STOCK_WAIT_TIMEOUT', '1800', '# Max background download time (s). Deadline = MIN(this, pipeline ready); concat never waits'),
    ('STOCK_PARALLEL', '12', '# Stock clips processed at once. Search and candidate download run free; only vision waits on its own semaphore'),
    ('STOCK_PIPELINE_WAIT_TIMEOUT', '500', '# Extra seconds to let stock finish once other stages are ready (same idea as YOUTUBE_WAIT_TIMEOUT). 0 = stop immediately'),
    ('STOCK_HTTP_RETRIES', '3', '# Retries when a stock API refuses (429 / 5xx / dropped connection). Each retry switches the key'),
    ('STOCK_HTTP_COOLDOWN', '5', '# Seconds to wait before the first retry; doubles each time. Retry-After from the stock wins'),
    ('STOCK_PROMPT_PROVIDER', '', '# Stock prompter (queries + own-library match): empty=auto | gpt_nexus|codex_reseller|cliproxy|deepseek|openrouter|meta_muse|claude_api|gpt|claude_code'),
    ('STOCK_PROMPT_MODEL', '', '# Stock prompter model. Empty = provider default'),
    ('STOCK_PROXY_URL', '', '# Optional proxy for stock APIs'),
    ('PEXELS_API_KEY', '', '# Free key: https://www.pexels.com/api/ (25000/month)'),
    ('PEXELS_API_KEY_2', '', '# Optional key pool for rotation'),
    ('PIXABAY_API_KEY', '', '# Free key: log in, then open https://pixabay.com/api/docs/ (key is shown there)'),
    ('PIXABAY_API_KEY_2', '', '# Optional key pool for rotation'),
    ('YOUTUBE_DLP_PATH', '', '# Optional yt-dlp executable path'),
    ('YTDLP_COOKIES_BROWSER', '',
        '# Browser for yt-dlp cookies: firefox|chrome|edge|opera|brave|vivaldi|chromium|safari;\n'
        '# "none" = no cookies at all; empty = auto (prefers a profile WITHOUT a YouTube login —\n'
        '# with an account, videos that disallow embedding become UNPLAYABLE)'),
    ('YOUTUBE_SEARCH_BACKEND', 'auto', '# YouTube discovery: auto (Data API if key, else yt-dlp) | data_api | yt_dlp'),
    ('YOUTUBE_DATA_API_KEY', '', '# Optional YouTube Data API v3 key; enables verified license/metadata search'),
    ('YOUTUBE_LICENSE_POLICY', 'creative_common', '# YouTube API license filter: creative_common (recommended) | any'),
    ('YOUTUBE_RIGHTS_TEXT_POLICY', 'exclude', '# Explicit rights restrictions in video descriptions: exclude (recommended) | warn'),
    ('YOUTUBE_SELECTOR_PROVIDER', 'auto', '# YouTube selector provider: auto (director direct-chat provider) | meta_muse|codex_reseller|...'),
    ('YOUTUBE_SELECTOR_MODEL', '', '# Optional YouTube selector model override'),
    ('YOUTUBE_ALLOW_SD', 'false', '# Take videos below 720p (Data API definition=sd)'),
    ('YOUTUBE_WINDOWS_PER_VIDEO', '6', '# Windows taken per video; pairs with YOUTUBE_POOL_TARGET as a grid (4x6 etc)'),
    ('YOUTUBE_RANK_PROVIDER', 'auto', '# Pool ranking operator: auto (stage text operator) | codex|meta_muse|deepseek|...'),
    ('YOUTUBE_RANK_MODEL', '', '# Optional pool ranking model override (a light model is enough)'),
    ('YOUTUBE_META_PARALLEL', '8', '# Parallel yt-dlp metadata requests; halved on every rate limit'),
    ('YOUTUBE_CLIP_PARALLEL', '4', '# How many YouTube clips are processed at once'),
    ('YOUTUBE_SOURCE_MAX_SHARE', '0.15', '# Max share of total runtime one YouTube video may provide (0 = unlimited)'),
    ('YOUTUBE_SOURCE_MAX_CHAIN', '3', '# Max consecutive scenes fed by one YouTube video (reuse chains)'),
    ('YOUTUBE_SAME_VIDEO_MIN_CLIP_GAP', '5', '# Fresh search: same video not closer than N clips to its last use'),
    # Envato Elements через панель Filesta: поиск по публичной выдаче,
    # мастер-файл платной загрузкой (300 в сутки) через Chrome по CDP.
    ('FILESTA_HOME', '', '# Folder for Filesta data. Empty = agent/.filesta/ (fingerprint + Chrome profile)'),
    ('FILESTA_PROFILE', '', '# Chrome profile for Filesta. Empty = agent/.filesta/chrome_profile'),
    ('FILESTA_FINGERPRINT', '', '# Captured device fingerprint. Empty = agent/.filesta/fp_real.json'),
    ('FILESTA_CDP_URL', 'http://127.0.0.1:9222', '# Chrome debug port used for Filesta downloads'),
    ('FILESTA_CHROME_EXE', '', '# Optional Chrome path. Empty = auto-detect'),
    ('FILESTA_MAX_MASTER_MB', '300', '# Master file ceiling (Envato serves the author original: 1080p ~86 MB, 4K up to 4.3 GB)'),
    ('FILESTA_CAPTCHA_WAIT_SEC', '300',
        '# How long to wait for a human to click the Turnstile checkbox in the open panel'),
    ('CAPTCHA_SOLVER_PROVIDER', 'capmonster', '# Optional captcha solver: capmonster | capsolver'),
    ('CAPTCHA_SOLVER_KEY', '',
        '# Optional: leave empty and the agent solves Turnstile itself (own render,\n'
        '# real mouse click) and, failing that, waits for you to click it'),
    ('FILESTA_ENVATO_STORYBOARD', 'false', '# Vision sees the preview mp4 (3 frames + duration) instead of the card poster'),
    ('FILESTA_ENVATO_PREVIEW_MAX_MB', '25', '# Ceiling for a preview download (free, does not spend the quota)'),
    ('STOCK_VISION_PER_SOURCE', '2', '# Candidates taken from EACH enabled stock before the rest fill the sheet. 0 = old behaviour'),
    ('STOCK_STRETCH_TOLERANCE_SEC', '2',
     '# Scene longer than the footage: up to this gap concat just slows the clip down; beyond it the scene is built from two pieces'),
    ('STOCK_MIN_PART_SEC', '1.5', '# Footage shorter than this cannot make even one piece of a scene'),
    ('STOCK_MASTER_MAX_MBPS', '40',
     '# Paid masters are stored as-is by Envato (measured 153 Mbps): squeeze anything\n'
     '# above this to keep the shared library small. 0 = never re-encode'),
    ('STOCK_IDLE_TIMEOUT', '300',
     '# Stock stage: seconds of SILENCE (no new scene closed) before we stop it.\n'
     '# Replaces the blind countdown - a long video no longer loses its tail'),
    ('YOUTUBE_IDLE_TIMEOUT', '300', '# YouTube stage: same silence watchdog'),
    ('REAL_PHOTO_IDLE_TIMEOUT', '300', '# Real Photo stage: same silence watchdog'),
    ('ENVATO_COOKIE_JSON', '', '# Envato browser cookie JSON; imported into the local Playwright profile'),
    ('ENVATO_BROWSER_PROFILE', '', '# Optional persistent Playwright profile directory for Envato'),
    ('ENVATO_BROWSER_EXECUTABLE', '', '# Optional portable Chrome/Chromium executable for Envato'),
    ('ENVATO_HEADLESS', 'true', '# Envato browser mode: true=headless, false=visible'),
    ('ENVATO_PROJECT_NAME', 'Varagent', '# Envato project name used by the normal Download dialog'),
    ('MUSIC_PROVIDER', 'suno', '# Music source: suno (generate) | local_library (your own folder). Old: safe_stock/pixabay/pexels = local_library'),
    ('MUSIC_LIBRARY_DIR', '', '# Local Sound Library folder (own music, scanned with subfolders). Empty = look only in project music_stock/'),
    ('MUSIC_DIRECTOR_BACKEND', '', '# Music director backend: empty=inherit, gpt(Codex)|gpt_nexus|codex_reseller|deepseek|openrouter|meta_muse|cliproxy|claude_code|claude_api'),
    ('MUSIC_CHAT_MODEL', '', '# Music model slug for a direct chat backend (empty=provider default)'),
    ('SUNO_COOKIE_BROWSER', 'firefox', '# Browser for Suno cookies: firefox|edge|chrome|opera|brave (Chrome v127+ ABE not readable)'),
    ('SUNO_MODEL', 'chirp-fenix', '# Suno model: chirp-fenix (v5.5) | chirp-v4 | chirp-v3-5'),
    ('SUNO_PARALLEL', '1', '# Suno orchestrator parallel threads (1=sequential, max 2-3 vs rate-limit)'),
    ('SUNO_INTER_TRACK_SLEEP', '30', '# Sleep (s) between sequential Suno generations (anti 422 rate-limit)'),
    ('MUSIC_DEFAULT_VOLUME_DB', '-21', '# Music loudness in final mix (positive 16 = -16 dB)'),
    ('MUSIC_DUCKING_DB', '-5', '# Sidechain ducking: how many dB music is dipped under the voice'),
    ('MUSIC_CROSSFADE_MS', '2000', '# Crossfade between adjacent tracks (ms)'),
    ('MUSIC_MIN_TRACK_DURATION', '120', '# Min music track duration (s)'),
    ('MUSIC_MAX_TRACK_DURATION', '240', '# Max music track duration (s, Suno ~3.5 min)'),
    ('MUSIC_MAX_TRACKS', '10', '# Max music tracks in plan'),
    ('MUSIC_FALLBACK_ON_SUNO_FAIL', 'false', '# Do not replace failed Suno music with synthetic noise'),
    ('MUSIC_FALLBACK_MODE', 'off', '# off | ffmpeg_ambient (explicit technical noise-bed opt-in only)'),
    # --- CLAUDE director/music backend (Claude CLI + Claude Nexus API) ---
    ('CLAUDE_MODEL', 'sonnet', '# Claude Code model alias: sonnet | opus | or full model name'),
    ('CLAUDE_CODE_USE_SUBSCRIPTION', 'true', '# true=use logged-in Claude Pro/Max CLI (drop ANTHROPIC_API_KEY from child)'),
    ('CLAUDE_RESELLER_ANTHROPIC_URL', 'https://ccmaxshop.de5.net/v1/messages', '# Claude Nexus native Anthropic Messages endpoint'),
    ('CLAUDE_RESELLER_ANTHROPIC_API_KEY', '', '# Claude Nexus API key'),
    ('CLAUDE_RESELLER_ANTHROPIC_EXTRA_API_KEYS', '', '# Optional additional Claude Nexus keys'),
    ('CLAUDE_RESELLER_ANTHROPIC_MODEL', 'claude-sonnet-4-6', '# Default Claude Nexus model'),
    ('CLAUDE_API_MODEL', '', '# Claude Nexus model override; old claude_api name kept for preset compatibility'),
    # --- ENTITY OVERLAY (Wikipedia person/place cards over video) ---
    ('ATTRIBUTION_OVERLAY', 'false', '# Source credit overlay on frame (Wikimedia/Google Images): true|false'),
    ('STOCK_MATCH_MIN_SHARE', '0.5', '# Share of query words that must match stock tags (0.0..1.0)'),
    ('STOCK_SEARCH_LIMIT', '80', '# Items per stock search request (Pexels max 80, Pixabay max 200)'),
    ('REAL_PHOTO_EPF_LANES', '4', '# Parallel EPF instances, each with its own data dir (1 = sequential)'),
    ('CODEX_MAX_PARALLEL', '4', '# Concurrent Codex CLI calls across all stages'),
    ('ENTITY_OVERLAY_ENABLED', 'false', '# Entity cards over video (Wikipedia persons/places): true|false'),
    ('ENTITY_OVERLAY_BACKEND', 'auto', '# Entity detector: auto | gpt_nexus | codex_reseller | direct chat providers | gpt | regex'),
    ('ENTITY_OVERLAY_MAX', '20', '# Max entity cards (0=unlimited)'),
    ('ENTITY_OVERLAY_PARALLEL', '4', '# How many cards to download at once (1 = one by one, old behavior)'),
    ('ENTITY_OVERLAY_WAIT_TIMEOUT', '1800', '# Max background card prep time (s). Deadline = MIN(this, generation done); concat never waits'),
    ('ENTITY_OVERLAY_CONCAT_DOWNLOAD', '', '# 1 = let concat download cards itself (only for manual concat runs without the pipeline)'),
    ('ENTITY_OVERLAY_HOLD_SEC', '4.2', '# Entity card display duration (s)'),
    ('ENTITY_OVERLAY_MIN_GAP_SEC', '24', '# Min gap between entity cards (s)'),
    ('ENTITY_OVERLAY_PROVIDERS', 'wikipedia,yandex', '# Image providers for entity cards'),
    ('ENTITY_OVERLAY_WIKI_LANGS', 'ru,en', '# Wikipedia languages for entity lookup'),
    # --- CONCAT QUEUE (background sequential tail: music + concat) ---
    ('CONCAT_QUEUE_ENABLED', 'true', '# Pipeline tail (music+concat) goes to background queue; generation takes next file immediately. false = old inline behavior'),
    ('FINAL_RANDOM_METADATA', 'true', '# Replace final video container metadata after all concat/post-processing stages'),

    # ── Хвосты 28.08: ключи, которые были в .env разработчика, но не
    # доезжали существующим пользователям — GUI показывал их пустыми, а
    # стадии молча жили на умолчаниях кода.
    ('ASSEMBLYAI_LANGUAGE_CODE', 'ru', '# Язык транскрипции (по умолчанию, можно переопределить в CLI)'),
    ('ASSEMBLYAI_SEGMENTATION_MODE', 'sentences', '# sentences  — каждое предложение отдельный блок (по умолчанию) paragraphs — группирует предложения в смысловые абзацы (меньше блоков, шире ох'),
    ('GEMINI_THINKING_LEVEL', 'medium', '# Значения: ’low’, ’medium’, ’high’ Влияет на глубину анализа и количество токенов'),
    ('GEMINI_THINKING_BUDGET', '0', '# Если задан — переопределяет GEMINI_THINKING_LEVEL для 2.x моделей 0 = не задан, используется маппинг из GEMINI_THINKING_LEVEL'),
    ('GEMINI_THINKING_LEVEL_PASS2', 'medium', '# Thinking для второго прохода (промпты) в двухпроходном режиме Gemini 3.x: ’low’, ’medium’, ’high’ (по умолчанию ’low’)'),
    ('GEMINI_THINKING_BUDGET_PASS2', '0', '# Gemini 2.x: budget в токенах (0 = использовать дефолт: 8000 для Pro, 0 для Flash)'),
    ('GENERATE_DIRECTOR_ANALYSIS', 'true', '# Генерация director_analysis.md (по умолчанию включена для отладки)'),
    ('GEMINI_TWO_PASS', 'false', '# Двухпроходный режим: проход 1 = JSON план, проход 2 = промпты (для длинных проектов)'),
    ('PROMPT_CHUNK_SIZE', '150', '# Если клипов больше — pass 2 разбивается на чанки по PROMPT_CHUNK_SIZE клипов. 0 = чанкование отключено (один запрос на все клипы).'),
    ('DIRECTOR_PASS1_CHUNK_THRESHOLD', '2400', '# THRESHOLD: если audioDuration > этого порога (сек), Pass 1 разбивается на чанки. 0 = всегда монолит (старый режим).'),
    ('DIRECTOR_PASS1_CHUNK_DURATION', '1200', '# Длина одного чанка Pass 1 (сек). 2400 сек = 40 мин, 1200 = 20 мин.'),
    ('CONT_ROLLBACK_SIZE', '20', '# Continuation loop отсекает последние N "уставших" промптов и просит их заново. 0 = откат отключён (дописываем строго с позиции обрыва).'),
    ('VIDEO_CLIP_MIN_DURATION', '4', ''),
    ('VIDEO_CLIP_MAX_DURATION', '8', ''),
    ('SLIDESHOW_CLIP_MIN_DURATION', '2', '# Слайдшоурежим (картинки)'),
    ('SLIDESHOW_CLIP_MAX_DURATION', '7', ''),
    ('INTRO_BLOCK_DURATION', '30', '# Длительность вступительной зоны таймлайна (секунды) Все клипы до этой отметки используют intro-настройки длительности'),
    ('INTRO_CLIP_MIN_DURATION', '0', '# Мин/макс длительность клипов во вступительном блоке (0 = авто) Если 0 — берётся из ACTIVE с ограничением max≤7'),
    ('INTRO_CLIP_MAX_DURATION', '0', ''),
    ('TTS_SERVICE', 'mat3u', '# Сервис озвучки: ’csv666’ | ’mat3u’ | ’voicegen’ | ’lumean’'),
    ('TTS_CSV666_CHUNK_SIZE', '1000', '# --- Настройки csv666 (voiceapi.csv666.ru) ---'),
    ('TTS_CSV666_OUTPUT_FORMAT', 'mp3', ''),
    ('TTS_MAT3U_MODEL_ID', 'eleven_multilingual_v2', '# --- Настройки mat3u (voicer.mat3u.com) ---'),
    ('TTS_MAT3U_SPLIT_TYPE', 'smart', ''),
    ('TTS_MAT3U_MAX_CHUNK_LENGTH', '1000', ''),
    ('TTS_MAT3U_SPLIT_OUTPUT', 'false', ''),
    ('TTS_MAT3U_AUTO_PAUSE_ENABLED', 'false', ''),
    ('TTS_MAT3U_AUTO_PAUSE_DURATION', '0.5', ''),
    ('TTS_MAT3U_AUTO_PAUSE_FREQUENCY', '1', ''),
    ('YT_PACK_LANGUAGES', 'ru,en', '# Языки (через запятую). Первый = исходный язык транскрипции'),
    ('YT_PACK_SUBTITLES', 'true', '# Переключатели подэтапов'),
    ('YT_PACK_DESCRIPTION', 'true', ''),
    ('YT_PACK_COVERS', 'true', ''),
    ('YT_PACK_COVER_COUNT', '4', ''),
    ('PIPELINE_START_POINT', 'audio', '# Точка старта: audio | script'),
    ('PIPELINE_CLIP_MODE', 'video', '# Режим клипов: video | slideshow | vislide'),
    ('PIPELINE_VIDEO_MODE', 'i2v', '# Режим видеогенерации: i2v | t2v | components | skip'),
    ('PIPELINE_PROMPT_MODE', 'single', '# Режим промптов: single | per_clip'),
    ('PIPELINE_RENDER_MODE', '720p', '# Рендер: 720p | 1080p | fast'),
    ('PIPELINE_WATERMARK', 'as_is', '# Ватермарка: as_is | blur_borders | skip'),
    ('PIPELINE_KEEP_FILES', 'false', '# Оставить ретайминг файлы: true | false'),
    ('PIPELINE_KEEP_VEO_SOUND', 'false', '# Оставить оригинальный звук из Veo-видео: true | false'),
    ('PIPELINE_IMG_GEN', 'veononstop', '# Источник изображений: fastgen | veononstop | cinai | skip'),
    ('FASTGEN_MODEL', 'FLOWER', '# Grok:      GROK    (Grok, возвращает 4 варианта) Whisk:     WHISK   (Whisk, категоризированные рефы subject/scene/style)'),
    ('FASTGEN_ASPECT_RATIO', 'landscape', '# Соотношение сторон: portrait, landscape, square'),
    ('FASTGEN_MAX_PARALLEL', '25', ''),
    ('FASTGEN_PREFLIGHT_REFS', 'true', '# Предполётная проверка рефов: тест до начала генерации (True = включена)'),
    ('FASTGEN_GROK_REMIX', 'true', '# Автоматический Grok-ремикс заблокированных рефов и цензурированных i2v кадров'),
    ('VEONONSTOP_MAX_PARALLEL', '4', ''),
    ('VEONONSTOP_ASPECT_RATIO', '16:9', '# Соотношение сторон видео/картинок: 16:9, 9:16, 1:1'),
    ('VEONONSTOP_IMGGEN_MODE', 'banana', '# Режим imggen: imagen, banana, banana_ref'),
    ('VEONONSTOP_BANANA_MODEL', 'GEM_PIX_2', '# Модель Banana VeoNonStop imggen: GEM_PIX_2 (Pro, дефолт) | NARWHAL (Banana 2) | HARBOR_SEAL (Banana 2 Lite)'),
    ('VEONONSTOP_POLL_INTERVAL', '10', '# Интервал поллинга статуса (секунды)'),
    ('VEONONSTOP_POLL_TIMEOUT', '180', '# Таймаут ожидания одной задачи (секунды, 30 мин по умолчанию)'),
    ('VEONONSTOP_REQUEST_DELAY', '3.0', '# Задержка между запросами воркеров (секунды). Увеличь если много reCAPTCHA ошибок. 3.0 = 24 воркера стартуют за 72с (было 10.0 = 230с). Умень'),
    ('CLAUDE_WORK_DIR', '', ''),
    ('MUSIC_BACKGROUND_WAIT_TIMEOUT', '1200', '# Suno runs in a background project process. Concat waits only here, after visual work has finished, so network music generation does not hold'),
    ('REAL_PHOTO_PIPELINE_WAIT_TIMEOUT', '100', '# После готовности основной генерации даём Real Photo отдельную фору, не посылая stop. По её истечении остающиеся pending-клипы снимаются и ид'),
    ('CLAUDE_API_PASS2_CHUNK_SIZE', '20', ''),
    ('CLAUDE_CODE_PASS2_CHUNK_SIZE', '20', '# Claude Code (CLI) pass2 chunk — отдельный от api; по умолчанию как api (20)'),
    ('TTS_VOICE_ID', '', ''),
    ('NON_AI_IMAGE_MODE', 'false', '# INFOGRAPHIC STAGE (AI stills routed separately from normal image generation) ==============================================================='),
    ('NON_AI_REAL_PHOTO_PERCENT', '50', ''),
    ('NON_AI_INFOGRAPHIC_PERCENT', '25', ''),
    ('NON_AI_STOCK_PERCENT', '25', ''),
    ('NON_AI_YOUTUBE_PERCENT', '25', ''),
    ('YOUTUBE_FOOTAGE_ENABLED', 'false', '# YouTube Footage is an opt-in stage with one explicitly selected source.'),
    ('YOUTUBE_RATIO_TARGET', '0.0', ''),
    ('YOUTUBE_POOL_TARGET', '6', ''),
    ('YOUTUBE_MAX_FRAGMENT_SEC', '3', ''),
    ('YOUTUBE_SAME_VIDEO_MIN_SOURCE_GAP_SEC', '20', ''),
    ('YOUTUBE_WAIT_TIMEOUT', '500', '# Extra wait only after all other stages are ready and concat is blocked by YouTube.'),
]

# Ключи, которые нужно обновить если значение устарело: (key, old_value, new_value)
_ENV_UPGRADES = [
    ('ASSEMBLYAI_SPEECH_MODELS', 'universal-3-pro', 'universal-3-pro,universal-2'),
    # Rewrite: flash (20 RPD free-tier) → flash-lite (1000 RPD). Users on gpt:gpt-5.4-mini keep their gpt rewriter (NOT forced back).
    ('REWRITE_MODEL', 'gemini:gemini-2.5-flash', 'gemini:gemini-2.5-flash-lite'),
    # Theme swap: zombovar.json merged into default.json (ClaudeVAR is now default)
    ('VARAGENT_THEME', 'zombovar', 'default'),
    # Real Photo: микс источников стал умолчанием (30.08). У кого стоит прежний
    # ноль — переводим на единицу; кто менял значение сам, тот с нулём и не
    # окажется. Настройка не разрушительная: возвращается галкой в интерфейсе.
    ('REAL_PHOTO_SOURCE_MIX', '0', '1'),
]

# Принудительная перезапись ключей (key, new_value) — ПУСТО ПО ПОЛИТИКЕ:
# если юзер задал значение в .env (свой ключ, свою модель) — апдейт его НЕ ТРОГАЕТ.
# Дефолты для свежеустановленных юзеров приходят через _ENV_REQUIRED.
# Ротация конкретных значений (например, dev-ключ забанили) — через _ENV_UPGRADES
# с парой (key, old_known_value, new_value): сработает только при точном совпадении строки.
_ENV_FORCE = []

_ENV_SECRET_KEY_MARKERS = ('API_KEY', 'TOKEN', 'SECRET', 'PASSWORD')

def _is_secret_env_key(key: str) -> bool:
    return any(marker in key.upper() for marker in _ENV_SECRET_KEY_MARKERS)

_ENV_FASTGEN_KEY_FIELDS = {'FASTGEN_API_KEY_BACKUP', 'FASTGEN_API_KEY_3', 'FASTGEN_API_KEY_4'}
_ENV_FASTGEN_PARALLEL_FIELDS = {'FASTGEN_MAX_PARALLEL_2', 'FASTGEN_MAX_PARALLEL_3', 'FASTGEN_MAX_PARALLEL_4'}

def _insert_env_lines_after_key(text: str, anchor_keys: set[str], new_lines: list[str]) -> str:
    if not new_lines:
        return text
    lines = text.splitlines()
    insert_at = None
    for i, line in enumerate(lines):
        raw = line.strip()
        if raw and not raw.startswith('#') and '=' in raw:
            key, _, _ = raw.partition('=')
            if key.strip() in anchor_keys:
                insert_at = i + 1
    if insert_at is None:
        insert_at = len(lines)
    lines[insert_at:insert_at] = new_lines
    return '\n'.join(lines) + '\n'

# Regex-миграция значений в .env: (pattern, replacement, human_note)
# Применяется к ВСЕМУ содержимому .env через re.sub. Нужно для коррекции
# значений, которые юзеры могли ввести до фикса (например, localhost → 127.0.0.1
# — чтобы обойти IPv6-перехват Dolphin Anty или похожих локальных серверов).
# Схема тоже форсится в http (у локального desk нет TLS — https ломает запросы).
_ENV_REGEX_MIGRATE = [
    (r'https?://localhost:(3001|3002|3003)/', r'http://127.0.0.1:\1/',
     'localhost->127.0.0.1 + force http for local desk ports (IPv6 bypass, no TLS on desk)'),
    (r'https://127\.0\.0\.1:(3001|3002|3003)/', r'http://127.0.0.1:\1/',
     'force http on 127.0.0.1 local desk ports (no TLS on desk)'),
]

# Загружаем токен из .env если есть (для обхода rate limit)
def _load_github_token(root: Path) -> 'Optional[str]':
    env_file = root / 'agent' / '.env'
    if env_file.exists():
        for line in env_file.read_text(encoding='utf-8').splitlines():
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                k, _, v = line.partition('=')
                if k.strip() == 'GITHUB_TOKEN':
                    return v.strip()
    return None


def _md5(path: Path) -> str:
    h = hashlib.md5()
    h.update(path.read_bytes())
    return h.hexdigest()


def _safe_patch_destination(root: Path, archive_name: str) -> tuple[str, Path]:
    normalized = archive_name.replace('\\', '/')
    rel = PurePosixPath(normalized)
    if (not normalized or rel.is_absolute() or '..' in rel.parts
            or (rel.parts and ':' in rel.parts[0])):
        raise RuntimeError(f'Небезопасный путь в patch.zip: {archive_name!r}')
    dest = root.joinpath(*rel.parts)
    resolved_root = root.resolve()
    resolved_dest = dest.resolve(strict=False)
    if not resolved_dest.is_relative_to(resolved_root):
        raise RuntimeError(f'Путь patch.zip выходит за папку программы: {archive_name!r}')
    return normalized, dest


def _forced_replacements_done(root: Path) -> set:
    """Разовые замены, которые в этой установке уже прошли."""
    try:
        text = (root / FORCE_ONCE_MARKER).read_text(encoding='utf-8')
    except (OSError, UnicodeDecodeError):
        return set()
    return {line.strip() for line in text.splitlines() if line.strip()}


def _remember_forced_replacement(root: Path, force_id: str) -> None:
    done = _forced_replacements_done(root)
    if force_id in done:
        return
    done.add(force_id)
    try:
        (root / FORCE_ONCE_MARKER).write_text(
            '\n'.join(sorted(done)) + '\n', encoding='utf-8')
    except OSError:
        # Не записалась отметка — замена повторится в следующий раз. Неприятно,
        # но безопасно: прежний файл всё равно уходит в `.bak_<id>`.
        pass


def _force_once_id(name: str, already_done: set) -> str | None:
    """Идентификатор разовой замены для этого файла, если она ещё нужна."""
    for target, force_id in FORCE_ONCE:
        if name == target and force_id not in already_done:
            return force_id
    return None


def _retire_legacy_parallax_file(root: Path, log) -> None:
    """Убрать из игры старый файл шаблонов в корне установки.

    Он не читается с 31.08, но пока лежит на месте — сбивает с толку: человек
    правит его и не понимает, почему ничего не меняется. Переносим рядом, под
    именем с суффиксом, и говорим куда смотреть.
    """
    legacy = root / LEGACY_PARALLAX_FILENAME
    try:
        if not legacy.is_file():
            return
    except OSError:
        return
    target = legacy.with_name(legacy.name + LEGACY_MIGRATED_SUFFIX)
    try:
        if target.exists():
            target.unlink()
        legacy.rename(target)
    except OSError as exc:
        log(f'  Не удалось отставить старый файл шаблонов: {exc}')
        return
    log(f'  Старый файл шаблонов в корне больше не читается → {target.name}')
    log('  Рабочий файл: agent/prompts/parallax_prompts.txt')


def _load_update_receipt(root: Path) -> dict:
    try:
        data = json.loads((root / UPDATE_RECEIPT).read_text(encoding='utf-8'))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_update_receipt(root: Path, data: dict, installed: list[str]) -> None:
    remote_files = data.get('files', {})
    if not data.get('version') or not data.get('patch_sha256'):
        return
    # Сколько раз ставили ИМЕННО эту версию. Нужно, чтобы не предлагать одно и
    # то же обновление бесконечно, когда какой-то файл упорно расходится
    # (см. `_receipt_matches`).
    previous = _load_update_receipt(root)
    attempts = 1
    if str(previous.get('version') or '') == str(data.get('version') or ''):
        attempts = int(previous.get('attempts') or 1) + 1
    receipt = {
        'version': str(data.get('version') or ''),
        'patch_sha256': str(data.get('patch_sha256') or '').strip().lower(),
        'attempts': attempts,
        'installed_files': {
            rel: remote_files.get(rel)
            for rel in installed
            if remote_files.get(rel)
        },
    }
    target = root / UPDATE_RECEIPT
    temp = target.with_suffix(target.suffix + '.tmp')
    temp.write_text(
        json.dumps(receipt, ensure_ascii=False, indent=2),
        encoding='utf-8')
    temp.replace(target)


def _receipt_matches(root: Path, data: dict) -> bool:
    """Эта версия уже установлена?

    Судим по квитанции: версия и контрольная сумма патча. Больше ничего.

    Раньше здесь дополнительно сверялся md5 КАЖДОГО установленного файла, и
    любой разошедшийся файл заставлял софт снова предлагать то же самое
    обновление — поставил, перезапустил, а он опять «доступно обновление», по
    кругу (жалоба 29.08). А расходиться файл может по десятку причин: софт сам
    его переписал при работе, пользователь поправил, права/перенос изменили
    содержимое.

    Проверка эта была и лишней: квитанция пишется ТОЛЬКО после успешной
    установки, а там md5 всех файлов уже сверены с version.json (см.
    `install_update`, «Проверка установленных файлов»). Не сошлось бы — до
    записи квитанции дело бы не дошло.
    """
    receipt = _load_update_receipt(root)
    if str(receipt.get('version') or '') != str(data.get('version') or ''):
        return False
    receipt_sha = str(receipt.get('patch_sha256') or '').strip().lower()
    if not receipt_sha or receipt_sha != str(
            data.get('patch_sha256') or '').strip().lower():
        return False
    installed_files = receipt.get('installed_files')
    if not isinstance(installed_files, dict) or not installed_files:
        return False

    remote_files = data.get('files', {})
    intact = True
    for rel, installed_md5 in installed_files.items():
        expected = remote_files.get(rel)
        local_path = root / rel
        if not expected or installed_md5 != expected:
            intact = False
            break
        if not local_path.exists() or _md5(local_path) != expected:
            intact = False
            break
    if intact:
        return True
    # Файл из установленного патча разошёлся. Один раз предложить переустановку
    # полезно — это чинит испорченную установку. Но если ту же версию уже
    # ставили дважды, а файл всё равно расходится, переустановка не поможет:
    # его меняет сам софт или система. Раньше здесь всегда возвращался False, и
    # человек ставил одно и то же обновление по кругу — поставил, перезапустил,
    # снова «доступно обновление» (жалоба 29.08).
    return int(receipt.get('attempts') or 1) >= 2


def _get_ssl_context():
    """Создает SSL context, совместимый с Mac/Windows/Linux."""
    try:
        # Метод 1: certifi (если доступен) — для Mac с Homebrew Python
        import certifi
        ctx = ssl.create_default_context(cafile=certifi.where())
        return ctx
    except ImportError:
        pass

    try:
        # Метод 2: create_default_context с отключенной проверкой
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    except Exception:
        pass

    # Метод 3: unverified context (последний fallback)
    return ssl._create_unverified_context()


_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) VARAGENT-Updater '
       '(+github.com/terryvarron-a11y)')


def _urlopen_retry(req, timeout: int, ctx, attempts: int = 5):
    """urlopen с ретраями на GitHub-лимит (429/403/503).

    Без ретраев обновление у портабл-юзеров падало на HTTP 429 при пике
    запросов к GitHub. Уважаем Retry-After, иначе экспоненциальный backoff."""
    import time as _t
    for _n in range(1, attempts + 1):
        try:
            return urllib.request.urlopen(req, timeout=timeout, context=ctx)
        except urllib.error.HTTPError as exc:
            if exc.code in (429, 403, 503) and _n < attempts:
                try:
                    wait = int(exc.headers.get('Retry-After') or 0)
                except (TypeError, ValueError):
                    wait = 0
                wait = max(wait, min(60, 5 * (2 ** (_n - 1))))
                _t.sleep(wait)
                continue
            raise


_TOKEN_REJECTED = {'seen': False}


def _fetch(url: str, token: str = None, timeout: int = 15) -> bytes:
    """Скачать файл обновления. Токен — только ускоритель, не пропуск.

    Репозиторий обновлений ПУБЛИЧНЫЙ: `raw.githubusercontent.com` отдаёт файлы
    и без токена, он нужен лишь ради лимита запросов. Но протухший или
    отозванный токен не игнорируется сервером, а ЛОМАЕТ запрос: GitHub отвечает
    404 (так он маскирует «нет доступа»), и кнопка обновления умирает с
    «HTTP Error 404: Not Found».

    Ровно это и случилось 30.08: раздаточный `github_pat_` истёк, и обновления
    встали у всех разом. Хуже того, починить это обновлением было нельзя —
    патч тоже не качался. Теперь на 401/403/404 с токеном пробуем ещё раз
    анонимно: сгоревший токен перестаёт быть смертельным.
    """
    ctx = _get_ssl_context()

    def _request(with_token: bool):
        headers = {'User-Agent': _UA}
        if with_token and token:
            headers['Authorization'] = f'token {token}'
        return _urlopen_retry(urllib.request.Request(url, headers=headers), timeout, ctx).read()

    if not token:
        return _request(False)
    try:
        return _request(True)
    except urllib.error.HTTPError as exc:
        if exc.code not in (401, 403, 404):
            raise
        if not _TOKEN_REJECTED['seen']:
            _TOKEN_REJECTED['seen'] = True
            print(f'   GITHUB_TOKEN отклонён ({exc.code}) — качаю без него. '
                  f'Токен просрочен или отозван; его можно очистить в agent/.env.')
        return _request(False)


def _fetch_version_json(token: str = None) -> dict:
    """Получает version.json через GitHub API (с токеном для обхода rate limit)."""
    import base64
    # api.github.com — жёсткий лимит 60 запросов/час на IP без токена, поэтому
    # СНАЧАЛА пробуем raw.githubusercontent.com (лимит кратно выше). API — только
    # запасной путь. Оба с ретраями на 429.
    try:
        return json.loads(_fetch(VERSION_JSON_URL, token=token))
    except Exception:
        pass
    headers = {
        'User-Agent': _UA,
        'Accept': 'application/vnd.github.v3+json',
    }
    if token:
        headers['Authorization'] = f'token {token}'
    req = urllib.request.Request(VERSION_API, headers=headers)
    ctx = _get_ssl_context()
    d = json.loads(_urlopen_retry(req, 15, ctx).read())
    return json.loads(base64.b64decode(d['content']))


def check_updates(root: Path) -> dict:
    """
    Проверяет наличие обновлений.

    Returns:
        {
          'available': bool,
          'version': str,
          'changelog': [...],
          'changed_files': [...],   # файлы которые реально изменились у юзера
          'error': str or None,
        }
    """
    token = _load_github_token(root)
    try:
        data = _fetch_version_json(token)
    except Exception:
        # Фоллбэк на raw URL — работает даже если GitHub API недоступен
        # или если старый updater.py сломан (NameError VERSION_API и т.п.)
        try:
            raw = _fetch(VERSION_JSON_URL, token)
            data = json.loads(raw)
        except Exception as e:
            return {'available': False, 'error': str(e)}

    remote_files = data.get('files', {})
    if _receipt_matches(root, data):
        return {
            'available': False,
            'version': data.get('version', '?'),
            'changelog': data.get('changelog', []),
            'changed_files': [],
            'requires_restart': data.get('requires_restart', False),
            'error': None,
        }

    changed = []
    for rel, remote_md5 in remote_files.items():
        local_path = root / rel
        if not local_path.exists():
            changed.append(rel)
        elif _md5(local_path) != remote_md5:
            changed.append(rel)

    return {
        'available': len(changed) > 0,
        'version':   data.get('version', '?'),
        'changelog': data.get('changelog', []),
        'changed_files': changed,
        'requires_restart': data.get('requires_restart', False),
        'error': None,
    }


def install_update(root: Path, progress_cb=None) -> dict:
    """
    Скачивает и устанавливает patch.zip.

    progress_cb(msg: str) — опциональный колбэк для прогресса

    Returns: {'ok': bool, 'installed': [...], 'error': str or None}
    """
    def log(msg):
        if progress_cb:
            progress_cb(msg)

    token = _load_github_token(root)
    requires_restart = False
    version_tag = 'latest'
    expected_patch_sha256 = ''
    data = {}

    try:
        # Сначала загружаем version.json для requires_restart
        log('Загрузка version.json...')
        try:
            data = _fetch_version_json(token)
            requires_restart = data.get('requires_restart', False)
            version_tag = str(data.get('version') or 'latest')
            expected_patch_sha256 = str(data.get('patch_sha256') or '').strip().lower()
        except Exception as ve:
            log(f'Предупреждение: не удалось загрузить version.json ({ve})')

        log('Скачивание патча...')
        # Version query prevents GitHub Raw/CDN from returning the previous patch.zip
        # immediately after a publish that reused the same file name.
        patch_bytes = _fetch(f'{PATCH_URL}?v={version_tag}', token, timeout=60)
        if expected_patch_sha256:
            actual_patch_sha256 = hashlib.sha256(patch_bytes).hexdigest()
            if actual_patch_sha256 != expected_patch_sha256:
                raise RuntimeError(
                    'Контрольная сумма patch.zip не совпала с version.json: '
                    f'{actual_patch_sha256} != {expected_patch_sha256}'
                )

        log('Установка файлов...')
        installed = []
        kept = []
        forced_done = _forced_replacements_done(root)
        forced_now = []
        with zipfile.ZipFile(io.BytesIO(patch_bytes)) as zf:
            for archive_name in zf.namelist():
                if archive_name.endswith(('/', '\\')):
                    continue
                name, dest = _safe_patch_destination(root, archive_name)
                # Пропускаем защищённые пути
                if any(name.startswith(s) for s in SKIP_ON_INSTALL):
                    continue
                # Правки пользователя не трогаем: такой файл ставится только
                # когда его нет вовсе (новая установка или пользователь удалил).
                if any(name.startswith(s) for s in KEEP_IF_EXISTS) and dest.exists():
                    force_id = _force_once_id(name, forced_done)
                    if force_id is None:
                        kept.append(name)
                        continue
                    # Разовая замена: прежний файл кладём рядом и ставим новый.
                    backup = dest.with_name(f'{dest.name}.bak_{force_id}')
                    try:
                        if backup.exists():
                            backup.unlink()
                        dest.replace(backup)
                        log(f'  ваш прежний файл сохранён: {backup.name}')
                    except OSError as exc:
                        log(f'  {name}: прежний файл не сохранить ({exc}) — оставляю ваш')
                        kept.append(name)
                        continue
                    forced_now.append(force_id)
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(zf.read(archive_name))
                installed.append(name)
                log(f'  {name}')

        remote_files = data.get('files', {})
        if remote_files:
            mismatched = [
                name for name in installed
                if remote_files.get(name) != _md5(root / Path(name))
            ]
            if mismatched:
                preview = ', '.join(mismatched[:10])
                raise RuntimeError(
                    f'Проверка установленных файлов не пройдена: {preview}')

        if kept:
            log(f'Сохранены ваши файлы (не тронуты): {len(kept)}')
            for name in kept:
                log(f'  оставлен ваш: {name}')
        # Отмечаем разовые замены ПОСЛЕ проверки контрольных сумм: если установка
        # сорвалась выше, отметки не будет и замена повторится.
        for force_id in dict.fromkeys(forced_now):
            _remember_forced_replacement(root, force_id)
        _retire_legacy_parallax_file(root, log)
        log(f'Готово. Установлено файлов: {len(installed)}')
        # Очистка __pycache__ — иначе Python может импортировать старый .pyc
        import shutil
        for cache_dir in root.rglob('__pycache__'):
            try:
                shutil.rmtree(cache_dir)
            except Exception:
                pass
        log('Очистка __pycache__ — OK')
        # patch_env из нового updater.py (файл уже перезаписан из zip,
        # но в памяти ещё старый модуль с устаревшим _ENV_REQUIRED)
        _new_updater = root / 'agent' / 'modules' / 'updater.py'
        if _new_updater.exists():
            _ns = {}
            exec(compile(_new_updater.read_text(encoding='utf-8'), str(_new_updater), 'exec'), _ns)
            _added = _ns['patch_env'](root)
            if _added:
                log(f'Обновлён .env: {", ".join(_added)}')
        else:
            patch_env(root)
        _install_fonts(root, log)
        # Доустановка зависимостей из requirements.txt: раньше updater только копировал
        # файлы, а pip не трогал — новые зависимости (напр. rookiepy/browser-cookie3 для
        # Suno cookie-auth) не появлялись у обновляющихся юзеров, и модуль музыки падал.
        # Теперь после копирования прогоняем pip install -r requirements.txt (быстро, если
        # всё уже стоит; ставит только недостающее/обновлённое). Не валит апдейт при сбое.
        _install_requirements(root, log)
        _write_update_receipt(root, data, installed)
        return {'ok': True, 'installed': installed, 'error': None,
                'requires_restart': requires_restart}

    except Exception as e:
        return {'ok': False, 'installed': [], 'error': str(e)}


def _managed_python_for_update(root: Path, log=None) -> str:
    """Return/create the Python runtime owned by the macOS installation."""
    if sys.platform != 'darwin':
        return sys.executable

    managed = root / '.venv' / 'bin' / 'python3'
    if managed.is_file():
        return str(managed)

    def _log(message):
        if log:
            log(message)

    try:
        import subprocess as _sp
        _log('macOS runtime: создание .venv...')
        result = _sp.run(
            [sys.executable, '-m', 'venv', str(root / '.venv')],
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='replace',
            timeout=300,
        )
        if result.returncode == 0 and managed.is_file():
            _log('macOS runtime: .venv готов.')
            return str(managed)
        tail = (result.stderr or result.stdout or '')[-300:]
        _log(f'[WARN] Не удалось создать macOS .venv: {tail}')
    except Exception as exc:
        _log(f'[WARN] Не удалось создать macOS .venv: {exc}')
    return sys.executable


def _install_requirements(root: Path, log=None) -> None:
    """pip install -r agent/requirements.txt после обновления файлов.

    Тихо и НЕ фатально: если pip недоступен / нет сети / сбой — логируем и идём
    дальше (обновление файлов уже применено, ломать его из-за pip нельзя)."""
    def _log(m):
        if log:
            log(m)
    req = root / 'agent' / 'requirements.txt'
    if not req.exists():
        return
    try:
        import subprocess as _sp
        _log('Проверка зависимостей (pip install -r requirements.txt)...')
        runtime_python = _managed_python_for_update(root, log)
        _cmd = [runtime_python, '-m', 'pip', 'install', '-r', str(req),
                '--disable-pip-version-check', '--prefer-binary',
                '--default-timeout=120', '--retries', '3',
                '--trusted-host', 'pypi.org', '--trusted-host', 'files.pythonhosted.org']
        _p = _sp.run(_cmd, capture_output=True, text=True, encoding='utf-8',
                     errors='replace', timeout=900)
        if _p.returncode == 0:
            _log('Зависимости актуальны.')
        else:
            _tail = (_p.stderr or _p.stdout or '')[-300:]
            _log(f'[WARN] pip install вернул код {_p.returncode} — часть зависимостей могла '
                 f'не установиться. Если модуль музыки/куки не работает, запустите '
                 f'install.bat (Win) или install.command (Mac). {_tail}')
    except Exception as _e:
        _log(f'[WARN] Не удалось запустить pip install ({_e}). При проблемах с зависимостями '
             f'запустите install.bat / install.command.')


def patch_env(root: Path) -> list:
    """
    Добавляет в agent/.env строки для ключей из _ENV_REQUIRED, если они отсутствуют.
    Существующие значения НЕ трогает.

    Returns: список добавленных ключей (пустой если всё уже было).
    """
    env_path = root / 'agent' / '.env'
    if not env_path.exists():
        # Свежая установка: в дистрибутиве лежит только .env.example, а сам
        # .env не едет ни в DMG, ни в патче (он в SKIP_ON_INSTALL). Без файла
        # редактор настроек в GUI молча пуст — человек видит вкладку без полей
        # и не понимает, куда вписывать ключи (улов на macOS 29.08).
        # `default_env.txt` — копия раздаточного .env (397 строк с дефолтами и
        # токеном обновлений, личные ключи вычищены). `.env.example` запасной:
        # он старее и знает лишь 124 строки.
        source = next((p for p in (env_path.with_name('default_env.txt'),
                                   env_path.with_name('.env.example'))
                       if p.is_file()), None)
        if source is None:
            return []
        try:
            env_path.parent.mkdir(parents=True, exist_ok=True)
            env_path.write_bytes(source.read_bytes())
        except OSError:
            return []

    try:
        text = env_path.read_text(encoding='utf-8')
    except Exception:
        return []

    # Собираем ключи и их значения
    existing_keys = {}  # key → value
    for line in text.splitlines():
        line = line.strip()
        if line and not line.startswith('#') and '=' in line:
            k, _, v = line.partition('=')
            existing_keys[k.strip()] = v.strip()

    added = []
    extra_lines = []
    fastgen_key_lines = []
    fastgen_parallel_lines = []
    for key, default, comment in _ENV_REQUIRED:
        if key not in existing_keys:
            # Ключа нет — добавляем
            target = extra_lines
            if key in _ENV_FASTGEN_KEY_FIELDS:
                target = fastgen_key_lines
            elif key in _ENV_FASTGEN_PARALLEL_FIELDS:
                target = fastgen_parallel_lines
            if comment:
                target.append(comment)
            target.append(f'{key}={default}')
            added.append(key)
        elif not existing_keys[key] and default and not _is_secret_env_key(key):
            # Ключ есть но пустой, а дефолт непустой — прописываем значение
            import re as _re
            text = _re.sub(
                rf'^({_re.escape(key)}\s*=)\s*$',
                rf'\g<1>{default}',
                text, count=1, flags=_re.MULTILINE
            )
            added.append(f'{key} (filled empty)')

    # Принудительная перезапись ключей
    for key, new_val in _ENV_FORCE:
        if _is_secret_env_key(key):
            continue
        if key in existing_keys and existing_keys[key] != new_val:
            import re as _re
            pattern = _re.compile(rf'^({_re.escape(key)}\s*=).*$', _re.MULTILINE)
            if pattern.search(text):
                text = pattern.sub(rf'\g<1>{new_val}', text)
                added.append(f'{key} (force-updated)')

    # Regex-миграции значений (например, localhost → 127.0.0.1)
    import re as _re
    for _pat, _repl, _note in _ENV_REGEX_MIGRATE:
        _new_text, _n = _re.subn(_pat, _repl, text)
        if _n > 0:
            text = _new_text
            added.append(f'regex-migrate x{_n}: {_note}')

    # Обновляем устаревшие значения
    for key, old_val, new_val in _ENV_UPGRADES:
        if key in existing_keys and existing_keys[key] == old_val:
            import re as _re
            pattern = _re.compile(rf'^({_re.escape(key)}\s*=\s*){_re.escape(old_val)}\s*$', _re.MULTILINE)
            if pattern.search(text):
                text = pattern.sub(rf'\g<1>{new_val}', text)
                added.append(f'{key} (upgraded)')

    if not added:
        return []

    text = _insert_env_lines_after_key(
        text,
        {'FASTGEN_API_KEY', 'FASTGEN_API_KEY_BACKUP', 'FASTGEN_API_KEY_2', 'FASTGEN_API_KEY_3', 'FASTGEN_API_KEY_4'},
        fastgen_key_lines,
    )
    text = _insert_env_lines_after_key(
        text,
        {'FASTGEN_MAX_PARALLEL', 'FASTGEN_MAX_PARALLEL_2', 'FASTGEN_MAX_PARALLEL_3', 'FASTGEN_MAX_PARALLEL_4'},
        fastgen_parallel_lines,
    )

    # Добавляем остальные новые ключи в конец файла
    if extra_lines:
        if not text.endswith('\n'):
            extra_lines.insert(0, '')
        text = text + '\n'.join(extra_lines) + '\n'

    env_path.write_text(text, encoding='utf-8')
    return added


def _install_fonts(root: Path, log=None):
    """Копирует шрифты из agent/fonts/ в системную папку шрифтов (если ещё не установлены)."""
    import platform
    import shutil

    fonts_dir = root / 'agent' / 'fonts'
    if not fonts_dir.exists():
        return

    system = platform.system()
    if system == 'Windows':
        # Per-user fonts — не требует прав администратора
        dest_dir = Path.home() / 'AppData' / 'Local' / 'Microsoft' / 'Windows' / 'Fonts'
    elif system == 'Darwin':
        dest_dir = Path.home() / 'Library' / 'Fonts'
    else:
        dest_dir = Path.home() / '.local' / 'share' / 'fonts'

    dest_dir.mkdir(parents=True, exist_ok=True)

    for font_file in fonts_dir.glob('*.ttf'):
        dest = dest_dir / font_file.name
        if dest.exists():
            continue
        try:
            shutil.copy2(str(font_file), str(dest))
            if log:
                log(f'  Шрифт установлен: {font_file.name}')
        except Exception as e:
            if log:
                log(f'  Шрифт {font_file.name}: не удалось ({e})')
