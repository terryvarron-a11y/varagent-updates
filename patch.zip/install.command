#!/bin/bash
# SCENAGENT RTG - Auto Installer for macOS
# Run: double-click this file in Finder

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Auto-set execute permissions
chmod +x *.command 2>/dev/null

PYTHON_CMD="python3"

echo ""
echo "================================================================================"
echo " SCENAGENT RTG - AUTO INSTALLER (macOS)"
echo "================================================================================"
echo ""

# ============================================================================
# HELPER: activate Homebrew in current shell session
# ============================================================================
_brew_activate() {
    if [ -f /opt/homebrew/bin/brew ]; then
        eval "$(/opt/homebrew/bin/brew shellenv)"
    elif [ -f /usr/local/bin/brew ]; then
        eval "$(/usr/local/bin/brew shellenv)"
    fi
}

# ============================================================================
# HELPER: install Homebrew if missing
# ============================================================================
_ensure_brew() {
    _brew_activate
    if command -v brew &>/dev/null; then
        return 0
    fi
    echo " Homebrew not found. Installing Homebrew..."
    echo " (will request administrator password)"
    echo ""
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    _brew_activate
    if ! command -v brew &>/dev/null; then
        echo " [ERROR] Failed to install Homebrew."
        echo "   Download manually: https://brew.sh"
        exit 1
    fi
    echo ""
    echo " [OK] Homebrew installed"
}

# ============================================================================
# 1. PYTHON3
# ============================================================================
echo "[1/5] Finding best Python (3.10-3.13)..."

_brew_activate

# Find the best Python: prefer 3.12, then 3.11, 3.13, 3.10. Skip 3.14+ (too new, broken packages).
PYTHON_CMD=""
for _candidate in \
    /opt/homebrew/bin/python3.12 /usr/local/bin/python3.12 \
    /opt/homebrew/bin/python3.11 /usr/local/bin/python3.11 \
    /opt/homebrew/bin/python3.13 /usr/local/bin/python3.13 \
    /opt/homebrew/bin/python3.10 /usr/local/bin/python3.10 \
    python3.12 python3.11 python3.13 python3.10; do
    if "$_candidate" --version &>/dev/null 2>&1; then
        _minor=$("$_candidate" -c "import sys; print(sys.version_info.minor)" 2>/dev/null)
        if [ -n "$_minor" ] && [ "$_minor" -ge 10 ] && [ "$_minor" -le 13 ]; then
            PYTHON_CMD="$_candidate"
            break
        fi
    fi
done

# Fallback: try generic python3 if it's 3.10-3.13
if [ -z "$PYTHON_CMD" ]; then
    _minor=$(python3 -c "import sys; print(sys.version_info.minor)" 2>/dev/null)
    if [ -n "$_minor" ] && [ "$_minor" -ge 10 ] && [ "$_minor" -le 13 ]; then
        PYTHON_CMD="python3"
    fi
fi

# Still nothing? Install python@3.12 via Homebrew
if [ -z "$PYTHON_CMD" ]; then
    echo " No suitable Python found (need 3.10-3.13). Installing python@3.12..."
    _ensure_brew
    brew install python@3.12
    _brew_activate
    for _p in /opt/homebrew/bin/python3.12 /usr/local/bin/python3.12; do
        if "$_p" --version &>/dev/null 2>&1; then
            PYTHON_CMD="$_p"
            break
        fi
    done
    if [ -z "$PYTHON_CMD" ]; then
        echo " [ERROR] Failed to install Python 3.12"
        echo "   Download manually: https://www.python.org/downloads/"
        exit 1
    fi
fi

PYVER=$($PYTHON_CMD --version 2>&1)
echo " [OK] $PYVER ($PYTHON_CMD)"

# ============================================================================
# 2. VENV + PACKAGES
# ============================================================================
echo ""
echo "[2/5] Creating virtual environment..."

VENV_DIR="$SCRIPT_DIR/.venv"

# Remove old venv if exists (clean install)
if [ -d "$VENV_DIR" ]; then
    echo " Removing old .venv..."
    rm -rf "$VENV_DIR"
fi

$PYTHON_CMD -m venv "$VENV_DIR"
if [ $? -ne 0 ]; then
    echo " [ERROR] Failed to create venv."
    echo " Try manually: $PYTHON_CMD -m venv .venv"
    exit 1
fi
echo " [OK] .venv created"

# Activate venv — all further commands use venv python/pip
source "$VENV_DIR/bin/activate"
PYTHON_CMD="$VENV_DIR/bin/python3"
PIP_CMD="$PYTHON_CMD -m pip"

echo ""
echo "[3/5] Installing Python packages..."
echo ""

if [ ! -f "agent/requirements.txt" ]; then
    echo " [ERROR] agent/requirements.txt not found!"
    echo " Make sure you run install.command from the project folder."
    exit 1
fi

$PIP_CMD install --upgrade pip 2>&1 | tail -1
$PIP_CMD install -r agent/requirements.txt 2>&1
if [ $? -ne 0 ]; then
    echo " [ERROR] Failed to install packages!"
    exit 1
fi

# Verify
_FAIL=0
for _pkg in requests assemblyai google.genai dotenv tqdm httpx pydantic colorama PIL; do
    if ! $PYTHON_CMD -c "import $_pkg" 2>/dev/null; then
        echo " [WARN] Cannot import $_pkg"
        _FAIL=1
    fi
done
if [ "$_FAIL" = "1" ]; then
    echo " [WARN] Some packages not importable. Trying force reinstall..."
    $PIP_CMD install --force-reinstall -r agent/requirements.txt 2>&1
fi
echo ""
echo " [OK] All packages installed (in .venv/)"

# ============================================================================
# 4. TKINTER
# ============================================================================
echo ""
echo "[4/5] tkinter (for GUI)..."

$PYTHON_CMD -c "import tkinter" 2>/dev/null
if [ $? -ne 0 ]; then
    echo " tkinter not found. Installing via Homebrew..."
    _ensure_brew
    # Determine exact python version for correct formula (e.g. python-tk@3.14)
    PY_VER_SHORT=$($PYTHON_CMD -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>/dev/null)
    brew install "python-tk@${PY_VER_SHORT}" 2>/dev/null || brew install python-tk
    $PYTHON_CMD -c "import tkinter" 2>/dev/null
    if [ $? -ne 0 ]; then
        echo " [ERROR] tkinter still not found."
        echo "   Try manually: brew install python-tk@${PY_VER_SHORT}"
        exit 1
    fi
    echo " [OK] tkinter installed"
else
    echo " [OK] tkinter available"
fi

# ============================================================================
# 5. FFMPEG
# ============================================================================
echo ""
echo "[5/5] FFmpeg..."

if ffmpeg -version &>/dev/null; then
    echo " [OK] FFmpeg already installed"
else
    echo " FFmpeg not found. Installing via Homebrew..."
    echo ""
    _ensure_brew
    brew install ffmpeg
    if [ $? -ne 0 ]; then
        echo " [ERROR] brew failed to install FFmpeg."
        echo "   Try manually: brew install ffmpeg"
        exit 1
    fi
    _brew_activate
    if ffmpeg -version &>/dev/null; then
        echo " [OK] FFmpeg installed and working"
    else
        echo " [OK] FFmpeg installed (may need terminal restart)"
    fi
fi

# ============================================================================
# .ENV FILE
# ============================================================================
echo ""
echo "================================================================================"
echo " Configuration (.env)..."
echo "================================================================================"

if [ ! -f "agent/.env" ]; then
    if [ -f "agent/.env.example" ]; then
        cp "agent/.env.example" "agent/.env"
        echo " [OK] Created agent/.env from template"
        echo ""
        echo " [!!!] API KEYS REQUIRED!"
        echo " Open agent/.env and fill in:"
        echo ""
        echo "   ASSEMBLYAI_API_KEY  = https://www.assemblyai.com/app/"
        echo "   GEMINI_API_KEY      = https://aistudio.google.com/app/apikey"
        echo "   FASTGEN_API_KEY     = https://fast-gen.ai"
        echo ""
    else
        echo " [WARN] agent/.env.example not found. Create agent/.env manually."
    fi
else
    echo " [OK] agent/.env already exists"
fi

# ============================================================================
# Make all .command scripts executable
# ============================================================================
echo ""
chmod +x "$SCRIPT_DIR"/*.command 2>/dev/null
echo " [OK] chmod +x *.command"

# ============================================================================
# DONE
# ============================================================================
echo ""
echo "================================================================================"
echo " INSTALLATION COMPLETE!"
echo "================================================================================"
echo ""
echo " Next steps:"
echo " 1. Open agent/.env and set your API keys"
echo " 2. Put audio file (.mp3/.wav/.m4a) in ready_to_go/"
echo " 3. Add style guide to style_guides/ (filename: project.txt)"
echo " 4. Run: ./run_stage1_simple.command"
echo ""
echo "================================================================================"
echo ""
