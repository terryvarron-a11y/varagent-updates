"""
YT Packer — YouTube-упаковщик (СТАДИЯ 5)
Генерирует SRT субтитры, заголовки, описание с chapters, теги и обложки.
"""
import json
import logging
import sys
import threading
import time
from pathlib import Path
from typing import Dict, Any, List, Optional

from google import genai
from google.genai import types

import config
from modules.fastgen import FastGenClient

logger = logging.getLogger(__name__)


# ============================================================================
# УТИЛИТЫ: SRT
# ============================================================================

def _seconds_to_srt_time(seconds: float) -> str:
    """Конвертировать секунды (float) в SRT формат HH:MM:SS,mmm"""
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    ms = int(round((seconds - int(seconds)) * 1000))
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def transcription_to_srt(transcription_data: List[Dict]) -> str:
    """
    Конвертировать transcription.json сегменты в SRT формат.
    Каждый сегмент: {"id": N, "text": "...", "start": 0.00, "end": 3.45}
    """
    lines = []
    for i, seg in enumerate(transcription_data, start=1):
        start = _seconds_to_srt_time(seg['start'])
        end = _seconds_to_srt_time(seg['end'])
        text = seg.get('text', '').strip()
        if text:
            lines.append(f"{i}")
            lines.append(f"{start} --> {end}")
            lines.append(text)
            lines.append("")
    return "\n".join(lines)


def extract_plain_text(transcription_data: List[Dict]) -> str:
    """Извлечь голый текст из транскрипции (без таймкодов)."""
    return " ".join(seg.get('text', '').strip() for seg in transcription_data if seg.get('text', '').strip())


def _detect_language(segments: list) -> Optional[str]:
    """Определить язык транскрипции по тексту сегментов (кириллица → ru, иначе en)."""
    sample = ' '.join(s.get('text', '') for s in segments[:50])
    letters = [c for c in sample if c.isalpha()]
    if not letters:
        return None
    cyrillic = sum(1 for c in letters if '\u0400' <= c <= '\u04ff')
    ratio = cyrillic / len(letters)
    if ratio > 0.5:
        return 'ru'
    latin = sum(1 for c in letters if c.isascii())
    if latin / len(letters) > 0.5:
        return 'en'
    return None


# ============================================================================
# КЛАСС YT PACKER
# ============================================================================

class YTPacker:
    """YouTube-упаковщик: субтитры, описание, обложки."""

    def __init__(self, project_dir: str, api_key: Optional[str] = None, source_lang: Optional[str] = None):
        self.project_dir = Path(project_dir)
        self.api_key = api_key or config.GEMINI_API_KEY
        self.client = genai.Client(api_key=self.api_key)
        self.output_dir = self.project_dir / 'yt_pack'
        self.output_dir.mkdir(exist_ok=True)
        self.input_tokens = 0
        self.output_tokens = 0
        self.costs: list = []  # list of cost_info dicts per API call
        self.source_language = source_lang  # будет перезаписан из transcription.json если есть

    # ------------------------------------------------------------------
    # Загрузка данных проекта
    # ------------------------------------------------------------------

    def _load_transcription(self) -> List[Dict]:
        """Загрузить транскрипцию из transcription.json."""
        path = self.project_dir / 'transcription.json'
        if not path.exists():
            raise FileNotFoundError(f"transcription.json не найден: {path}")
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        # transcription.json = {"transcription": [...], "language": "ru", "audioDuration": ...}
        if isinstance(data, dict):
            segments = data.get('transcription', [])
            self.source_language = data.get('language') or _detect_language(segments)
            return segments
        return data

    def _load_style_guide(self) -> Optional[str]:
        """Найти и загрузить style guide (*_style_*.txt)."""
        for f in sorted(self.project_dir.glob('*_style_*.txt')):
            with open(f, 'r', encoding='utf-8') as fh:
                return fh.read()
        return None

    def _find_ref_thumbs(self) -> List[Path]:
        """
        Найти референсы обложек в папке ref_thumb/ проекта (до 10 файлов).
        Поддерживаемые форматы: png, jpg, jpeg, webp.
        """
        image_exts = {'.png', '.jpg', '.jpeg', '.webp'}
        ref_dir = self.project_dir / 'ref_thumb'
        if not ref_dir.exists():
            return []
        refs = sorted(
            [f for f in ref_dir.iterdir() if f.is_file() and f.suffix.lower() in image_exts],
            key=lambda f: f.name
        )
        return refs[:10]

    # ------------------------------------------------------------------
    # Gemini API вызов
    # ------------------------------------------------------------------

    def _call_gemini(self, prompt: str, model: Optional[str] = None, label: str = '') -> str:
        """Вызвать Gemini API и вернуть текст ответа."""
        model_name = model or config.YT_PACK_MODEL

        generate_config = types.GenerateContentConfig(
            max_output_tokens=65536,
            temperature=0.7,
        )

        # Спиннер в отдельном потоке пока ждём ответ (только в интерактивном TTY)
        _stop = threading.Event()
        _use_spinner = sys.stdout.isatty()
        if _use_spinner:
            def _spin():
                chars = '|/-\\'
                t0 = time.time()
                i = 0
                while not _stop.is_set():
                    elapsed = int(time.time() - t0)
                    prefix = f'   {label} ' if label else '   '
                    sys.stdout.write(f'\r{prefix}{chars[i % 4]}  {elapsed}s...')
                    sys.stdout.flush()
                    i += 1
                    time.sleep(0.15)
                sys.stdout.write('\r' + ' ' * 60 + '\r')
                sys.stdout.flush()
            t = threading.Thread(target=_spin, daemon=True)
            t.start()

        try:
            response = self.client.models.generate_content(
                model=model_name,
                contents=prompt,
                config=generate_config,
            )
        finally:
            if _use_spinner:
                _stop.set()
                t.join()

        # Подсчёт токенов и стоимости
        um = getattr(response, 'usage_metadata', None)
        if um is not None:
            in_tok  = getattr(um, 'prompt_token_count',     0) or 0
            out_tok = getattr(um, 'candidates_token_count', 0) or 0
            self.input_tokens  += in_tok
            self.output_tokens += out_tok
            pricing = config.get_model_pricing(model_name)
            cost_estimate = config.estimate_cost(in_tok, out_tok, model_name)
            self.costs.append({
                'model':               model_name,
                'input_tokens':        in_tok,
                'output_tokens':       out_tok,
                'thinking_tokens':     0,
                'total_output_tokens': out_tok,
                'input_cost':          cost_estimate['input_cost'],
                'output_cost':         (out_tok / 1_000_000) * pricing['output'],
                'thinking_cost':       0.0,
                'total_cost':          cost_estimate['total_cost'],
            })

        return response.text

    # ------------------------------------------------------------------
    # ЭТАП 1: SRT субтитры
    # ------------------------------------------------------------------

    def generate_subtitles(self, transcription_data: List[Dict]) -> Dict[str, Path]:
        """
        Генерировать SRT на всех языках.
        Исходный язык = прямая конвертация, остальные = перевод через Gemini.
        Исходный язык определяется из transcription.json (поле 'language') или source_language.
        """
        languages = config.YT_PACK_LANGUAGES
        if not languages:
            print("   [SKIP] YT_PACK_LANGUAGES пуст")
            return {}

        results = {}

        # Определяем исходный язык транскрипции
        source_lang = self.source_language or languages[0]

        # Пословный SRT — исходный язык (максимальная точность таймкодов)
        word_srt = transcription_to_srt(transcription_data)

        # Сгруппированный SRT — для переводов (меньше блоков = меньше API-запросов)
        grouped_srt = self._group_transcription_srt(transcription_data)
        grouped_count = grouped_srt.count(' --> ')
        word_count = word_srt.count(' --> ')

        # Сохраняем пословный SRT исходного языка
        print(f"\n   Субтитры [{source_lang}] — конвертация из transcription.json...")
        srt_path = self.output_dir / f'subtitles_{source_lang}.srt'
        with open(srt_path, 'w', encoding='utf-8') as f:
            f.write(word_srt)
        results[source_lang] = srt_path
        print(f"   [OK] {srt_path.name} ({word_count} блоков, пословно)")

        # Также сохраняем как subtitles.srt (основной файл)
        base_srt_path = self.output_dir / 'subtitles.srt'
        with open(base_srt_path, 'w', encoding='utf-8') as f:
            f.write(word_srt)

        print(f"   Переводы: сгруппированный SRT ({grouped_count} блоков вместо {word_count})")

        # Переводы — используем grouped_srt (sentence-level, меньше чанков)
        for lang in languages:
            if lang == source_lang:
                continue
            print(f"   Субтитры [{lang}] — перевод через Gemini...")
            translated_srt = self._translate_srt(grouped_srt, source_lang, lang)
            if translated_srt:
                srt_path = self.output_dir / f'subtitles_{lang}.srt'
                with open(srt_path, 'w', encoding='utf-8') as f:
                    f.write(translated_srt)
                results[lang] = srt_path
                print(f"   [OK] {srt_path.name}")
            else:
                print(f"   [ERROR] Не удалось перевести на {lang}")

        return results

    def _translate_srt(self, srt_content: str, from_lang: str, to_lang: str) -> Optional[str]:
        """Перевести SRT через Gemini, сохраняя таймкоды. Разбивает на чанки при большом объёме."""
        # Разбиваем SRT на блоки (каждый блок = номер + таймкод + текст + пустая строка)
        blocks = self._split_srt_blocks(srt_content)

        CHUNK_SIZE = 400  # блоков на чанк (~1600 строк)

        if len(blocks) <= CHUNK_SIZE:
            # Маленький файл — переводим целиком
            return self._translate_srt_chunk(srt_content, from_lang, to_lang)

        # Большой файл — разбиваем на чанки
        total_chunks = (len(blocks) + CHUNK_SIZE - 1) // CHUNK_SIZE
        print(f"     Разбивка на {total_chunks} чанков ({len(blocks)} блоков)...")

        translated_parts = []
        for i in range(0, len(blocks), CHUNK_SIZE):
            chunk_blocks = blocks[i:i + CHUNK_SIZE]
            chunk_srt = "\n\n".join(chunk_blocks)
            chunk_num = i // CHUNK_SIZE + 1

            print(f"     Чанк {chunk_num}/{total_chunks}...")
            translated = self._translate_srt_chunk(chunk_srt, from_lang, to_lang, chunk_num, total_chunks)
            if translated:
                translated_parts.append(translated.strip())
            else:
                print(f"     [WARN] Чанк {chunk_num} не удалось перевести, пропуск")

        if not translated_parts:
            return None

        # Пересчитываем номера блоков
        full_srt = "\n\n".join(translated_parts)
        return self._renumber_srt(full_srt)

    def _split_srt_blocks(self, srt_content: str) -> List[str]:
        """Разбить SRT на отдельные блоки (номер + таймкод + текст)."""
        import re
        # SRT blocks separated by blank lines
        blocks = re.split(r'\n\n+', srt_content.strip())
        return [b.strip() for b in blocks if b.strip()]

    def _renumber_srt(self, srt_content: str) -> str:
        """Пересчитать номера субтитров после склейки чанков."""
        import re
        blocks = re.split(r'\n\n+', srt_content.strip())
        result = []
        counter = 1
        for block in blocks:
            block = block.strip()
            if not block:
                continue
            lines = block.split('\n')
            if len(lines) >= 2 and '-->' in lines[1]:
                # Заменяем номер
                lines[0] = str(counter)
                counter += 1
            elif len(lines) >= 2 and '-->' in lines[0]:
                # Номер отсутствует, добавляем
                lines.insert(0, str(counter))
                counter += 1
            result.append('\n'.join(lines))
        return '\n\n'.join(result) + '\n'

    def _translate_srt_chunk(self, srt_chunk: str, from_lang: str, to_lang: str,
                              chunk_num: int = 1, total_chunks: int = 1) -> Optional[str]:
        """Перевести один чанк SRT через Gemini."""
        prompt = f"""Translate the following SRT subtitles from {from_lang} to {to_lang}.
Keep ALL timecodes EXACTLY as they are. Translate ONLY the text lines.
Do NOT add any explanations, markdown formatting, or code blocks.
Return ONLY the translated SRT content, nothing else.

{srt_chunk}"""
        try:
            result = self._call_gemini(prompt, model=config.YT_PACK_TRANSLATE_MODEL,
                                       label=f'[{from_lang}→{to_lang} чанк {chunk_num}/{total_chunks}]')
            # Очистка от возможных маркеров markdown
            if result.startswith('```'):
                import re
                match = re.search(r'```(?:\w+)?\s*\n?(.*?)\n?\s*```', result, re.DOTALL)
                if match:
                    result = match.group(1)
            return result
        except Exception as e:
            logger.error(f"SRT translation chunk {chunk_num}/{total_chunks} {from_lang}->{to_lang} failed: {e}")
            return None

    # ------------------------------------------------------------------
    # ЭТАП 2: Заголовки + описание + теги + chapters
    # ------------------------------------------------------------------

    def generate_description(self, srt_content: str, style_guide: Optional[str] = None) -> Dict[str, Any]:
        """
        Генерировать заголовки, описание с chapters, теги — на всех языках.
        Принимает SRT (текст + таймкоды) для анализа тематических блоков.
        """
        languages = config.YT_PACK_LANGUAGES
        lang_list = ', '.join(languages)

        style_block = ""
        if style_guide:
            style_block = f"\n\nStyle/genre context:\n{style_guide[:2000]}"

        # Загрузка промпт-шаблона
        prompt_path = Path(__file__).parent.parent / 'prompts' / 'yt_packer_prompt.txt'
        if prompt_path.exists():
            with open(prompt_path, 'r', encoding='utf-8') as f:
                prompt_template = f.read()
            prompt = prompt_template.format(
                languages=lang_list,
                style_block=style_block,
                srt_content=srt_content,
            )
        else:
            # Fallback промпт если файл не найден
            prompt = self._build_description_prompt(srt_content, lang_list, style_block)

        print(f"\n   Генерация заголовков/описания/тегов [{lang_list}]...")
        raw_response = self._call_gemini(prompt, model=config.YT_PACK_CONTENT_MODEL,
                                         label='[контент]')

        # Всегда сохраняем сырой ответ для отладки
        debug_path = self.output_dir / 'yt_pack_raw_response.txt'
        with open(debug_path, 'w', encoding='utf-8') as f:
            f.write(raw_response)

        # Парсинг JSON из ответа
        result = self._parse_json_response(raw_response)
        if not result:
            print("   [ERROR] Не удалось распарсить JSON из ответа Gemini")
            print(f"   [DEBUG] Сырой ответ сохранён: {debug_path.name}")
            return {}

        # Сохранение JSON
        json_path = self.output_dir / 'yt_pack.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(f"   [OK] {json_path.name}")

        # Генерация .md файлов для каждого языка
        for lang in languages:
            lang_data = result.get(lang, {})
            if lang_data:
                md_path = self.output_dir / f'yt_pack_{lang}.md'
                md_content = self._format_md(lang, lang_data)
                with open(md_path, 'w', encoding='utf-8') as f:
                    f.write(md_content)
                print(f"   [OK] {md_path.name}")

        return result

    def _build_description_prompt(self, srt_content: str, lang_list: str, style_block: str) -> str:
        """Fallback-промпт если yt_packer_prompt.txt не найден."""
        return f"""You are a YouTube SEO expert. Analyze this video's SRT subtitles and generate marketing materials.

LANGUAGES: {lang_list}
{style_block}

For EACH language, return a JSON object with:
1. "titles" — array of 3-5 catchy YouTube title variants (max 100 chars each)
2. "description" — SEO-optimized description (500-1500 chars) with keywords naturally embedded
3. "chapters" — array of YouTube chapters [{{"time": "00:00", "title": "..."}}] based on thematic analysis of the transcript
4. "tags" — array of 15-25 SEO tags
5. "hashtags" — array of 3-5 hashtags for the description
6. "cover_prompt" — a detailed English prompt for generating a YouTube thumbnail image (1280x720) that captures the essence of the video content. Visually striking, high contrast, cinematic.

Return ONLY valid JSON in this format:
{{
  "{lang_list.split(',')[0].strip()}": {{
    "titles": ["...", "..."],
    "description": "...",
    "chapters": [{{"time": "00:00", "title": "..."}}, ...],
    "tags": ["...", "..."],
    "hashtags": ["...", "..."],
    "cover_prompt": "..."
  }},
  ...more languages...
}}

SRT SUBTITLES:
{srt_content}"""

    def _parse_json_response(self, text: str) -> Optional[Dict]:
        """Извлечь JSON из ответа Gemini (может быть в ```json ... ``` или усечён)."""
        import re

        # Попробовать извлечь из ```json ... ```
        match = re.search(r'```(?:json)?\s*\n?(.*?)\n?\s*```', text, re.DOTALL)
        json_text = match.group(1) if match else text

        # Попробовать как чистый JSON
        try:
            return json.loads(json_text)
        except json.JSONDecodeError:
            pass

        # Попробовать найти { ... } в тексте
        match = re.search(r'\{.*\}', text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(0))
            except json.JSONDecodeError:
                pass

        # Попробовать починить усечённый JSON (закрыть незакрытые скобки)
        json_candidate = json_text.strip()
        if not json_candidate.startswith('{'):
            match = re.search(r'\{', json_candidate)
            if match:
                json_candidate = json_candidate[match.start():]

        if json_candidate.startswith('{'):
            repaired = self._repair_truncated_json(json_candidate)
            if repaired:
                try:
                    result = json.loads(repaired)
                    print("   [WARN] JSON был усечён — восстановлен частично")
                    return result
                except json.JSONDecodeError:
                    pass

        return None

    def _repair_truncated_json(self, text: str) -> Optional[str]:
        """Попытка закрыть незакрытые скобки/кавычки в усечённом JSON."""
        # Отрезаем последнюю неполную строку (может быть обрезано посередине значения)
        last_newline = text.rfind('\n')
        if last_newline > 0:
            text = text[:last_newline]

        # Убираем trailing запятые и незакрытые строки
        text = text.rstrip()
        while text and text[-1] in (',', ':', '"', "'"):
            if text[-1] == '"':
                # Проверяем, не является ли это закрывающей кавычкой
                # Считаем кавычки — если нечётное число, удаляем
                count = 0
                for c in text:
                    if c == '"':
                        count += 1
                if count % 2 != 0:
                    text = text[:-1]
                else:
                    break
            else:
                text = text[:-1]
            text = text.rstrip()

        # Подсчитываем незакрытые { и [
        open_braces = 0
        open_brackets = 0
        in_string = False
        escape = False

        for c in text:
            if escape:
                escape = False
                continue
            if c == '\\' and in_string:
                escape = True
                continue
            if c == '"':
                in_string = not in_string
                continue
            if in_string:
                continue
            if c == '{':
                open_braces += 1
            elif c == '}':
                open_braces -= 1
            elif c == '[':
                open_brackets += 1
            elif c == ']':
                open_brackets -= 1

        # Закрываем незакрытые скобки
        if open_braces > 0 or open_brackets > 0:
            closing = ']' * max(0, open_brackets) + '}' * max(0, open_braces)
            text += closing

        return text if open_braces >= 0 and open_brackets >= 0 else None

    def _format_md(self, lang: str, data: Dict) -> str:
        """Форматировать данные языка в Markdown."""
        lines = [f"# YouTube Pack — {lang.upper()}\n"]

        # Заголовки
        titles = data.get('titles', [])
        if titles:
            lines.append("## Варианты заголовков\n")
            for i, t in enumerate(titles, 1):
                lines.append(f"{i}. {t}")
            lines.append("")

        # Описание
        desc = data.get('description', '')
        if desc:
            lines.append("## Описание\n")
            lines.append(desc)
            lines.append("")

        # Chapters
        chapters = data.get('chapters', [])
        if chapters:
            lines.append("## Chapters (таймкоды)\n")
            for ch in chapters:
                lines.append(f"{ch.get('time', '00:00')} {ch.get('title', '')}")
            lines.append("")

        # Теги
        tags = data.get('tags', [])
        if tags:
            lines.append("## Теги\n")
            lines.append(", ".join(tags))
            lines.append("")

        # Хештеги
        hashtags = data.get('hashtags', [])
        if hashtags:
            lines.append("## Хештеги\n")
            lines.append(" ".join(hashtags))
            lines.append("")

        # Cover prompt
        cover_prompt = data.get('cover_prompt', '')
        if cover_prompt:
            lines.append("## Cover Prompt\n")
            lines.append(cover_prompt)
            lines.append("")

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # ЭТАП 3: Обложки (FastGen)
    # ------------------------------------------------------------------

    def generate_covers(self, yt_pack_data: Dict[str, Any]) -> List[Path]:
        """
        Генерировать обложки через FastGen.
        - Базовые обложки (без текста) по cover_prompt из Gemini
        - Обложки с текстом заголовка на каждом языке (FastGen рендерит текст)
        """
        # Получаем cover_prompt из первого языка
        cover_prompt = None
        for lang_data in yt_pack_data.values():
            if isinstance(lang_data, dict):
                cover_prompt = lang_data.get('cover_prompt')
                if cover_prompt:
                    break

        if not cover_prompt:
            print("   [SKIP] cover_prompt не найден в yt_pack.json")
            return []

        covers_dir = self.output_dir / 'covers'
        covers_dir.mkdir(exist_ok=True)

        # Инициализация FastGen
        api_key = config.FASTGEN_API_KEY
        if not api_key:
            print("   [ERROR] FASTGEN_API_KEY не указан")
            return []

        fg = FastGenClient(api_key=api_key)

        # Загрузка референсов из ref_thumb/
        ref_uris = []
        ref_thumbs = self._find_ref_thumbs()
        if ref_thumbs:
            print(f"   Референсы обложек: {len(ref_thumbs)} файл(ов) в ref_thumb/")
            for rt in ref_thumbs:
                try:
                    uri = fg.upload_reference(str(rt))
                    ref_uris.append(uri)
                    print(f"     [OK] {rt.name}")
                except Exception as e:
                    print(f"     [WARN] {rt.name}: {e}")

        generated = []
        cover_count = config.YT_PACK_COVER_COUNT
        model = config.YT_PACK_COVER_MODEL

        # Базовые обложки (без текста)
        print(f"\n   Генерация базовых обложек ({cover_count} шт.)...")
        base_prompt = f"YouTube video thumbnail, 1280x720, cinematic, high contrast, no text. {cover_prompt}"
        for i in range(cover_count):
            try:
                op_id = fg.generate_flow(
                    prompt=base_prompt,
                    reference_uris=ref_uris if ref_uris else None,
                    model=model,
                    aspect_ratio='landscape',
                )
                result = fg.poll_operation(op_id)
                _r = result.get('result', [])
                images = result.get('images') or (_r if isinstance(_r, list) else _r.get('images', []))
                if images:
                    img_data = images[0] if isinstance(images[0], str) else images[0].get('url', '')
                    out_path = covers_dir / f'cover_base_{i+1}.png'
                    fg.save_image(img_data, str(out_path))
                    generated.append(out_path)
                    print(f"   [OK] cover_base_{i+1}.png")
            except Exception as e:
                print(f"   [ERROR] cover_base_{i+1}: {e}")

        # Обложки с текстом на каждом языке
        for lang in config.YT_PACK_LANGUAGES:
            lang_data = yt_pack_data.get(lang, {})
            titles = lang_data.get('titles', [])
            if not titles:
                continue

            title = titles[0]  # Берём первый вариант заголовка
            print(f"\n   Генерация обложки с текстом [{lang}]: \"{title[:50]}...\"")

            text_prompt = (
                f"YouTube video thumbnail, 1280x720, cinematic, high contrast. "
                f"Large bold text overlay: \"{title}\". "
                f"{cover_prompt}"
            )

            for i in range(min(2, cover_count)):  # 2 варианта с текстом на язык
                try:
                    op_id = fg.generate_flow(
                        prompt=text_prompt,
                        reference_uris=ref_uris if ref_uris else None,
                        model=model,
                        aspect_ratio='landscape',
                    )
                    result = fg.poll_operation(op_id)
                    _r = result.get('result', [])
                    images = result.get('images') or (_r if isinstance(_r, list) else _r.get('images', []))
                    if images:
                        img_data = images[0] if isinstance(images[0], str) else images[0].get('url', '')
                        out_path = covers_dir / f'cover_{lang}_{i+1}.png'
                        fg.save_image(img_data, str(out_path))
                        generated.append(out_path)
                        print(f"   [OK] cover_{lang}_{i+1}.png")
                except Exception as e:
                    print(f"   [ERROR] cover_{lang}_{i+1}: {e}")

        return generated

    # ------------------------------------------------------------------
    # Группировка транскрипции в предложения (для этапа 2)
    # ------------------------------------------------------------------

    def _group_transcription_srt(self, transcription_data: List[Dict],
                                  max_gap: float = 7.0, max_words: int = 15) -> str:
        """
        Сгруппировать пословную транскрипцию в предложения для промпта описания.
        Группирует по знакам конца предложения (. ! ? ...) или по времени/словам.
        Возвращает компактный SRT (~200-400 блоков вместо 3000+).
        """
        if not transcription_data:
            return ""

        sentence_ends = {'.', '!', '?', '...'}
        groups = []
        current_words = []
        current_start = None
        current_end = None

        for seg in transcription_data:
            text = seg.get('text', '').strip()
            if not text:
                continue

            start = seg.get('start', 0)
            end = seg.get('end', 0)

            if current_start is None:
                current_start = start

            current_words.append(text)
            current_end = end

            ends_sentence = any(text.endswith(p) for p in sentence_ends)
            too_long = len(current_words) >= max_words
            time_gap = (end - current_start) >= max_gap

            if ends_sentence or too_long or time_gap:
                groups.append({
                    'start': current_start,
                    'end': current_end,
                    'text': ' '.join(current_words),
                })
                current_words = []
                current_start = None
                current_end = None

        if current_words and current_start is not None:
            groups.append({
                'start': current_start,
                'end': current_end,
                'text': ' '.join(current_words),
            })

        lines = []
        for i, g in enumerate(groups, start=1):
            start = _seconds_to_srt_time(g['start'])
            end = _seconds_to_srt_time(g['end'])
            lines.append(f"{i}")
            lines.append(f"{start} --> {end}")
            lines.append(g['text'])
            lines.append("")

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # ГЛАВНЫЙ МЕТОД
    # ------------------------------------------------------------------

    def run(self) -> Dict[str, Any]:
        """Запустить YT Packer (все включённые подэтапы)."""
        print("\n" + "=" * 60)
        print("📦 YT PACKER — YouTube-упаковщик")
        print("=" * 60)

        # Загрузка транскрипции
        transcription_data = self._load_transcription()
        if not transcription_data:
            print("\n[ERROR] Транскрипция пуста или не найдена")
            return {}

        print(f"\n   Проект: {self.project_dir.name}")
        print(f"   Сегментов транскрипции: {len(transcription_data)}")
        print(f"   Язык транскрипции: {self.source_language or 'не определён (берём languages[0])'}")
        print(f"   Языки упаковки: {', '.join(config.YT_PACK_LANGUAGES)}")
        print(f"   Модель (контент):  {config.YT_PACK_CONTENT_MODEL}")
        print(f"   Модель (перевод):  {config.YT_PACK_TRANSLATE_MODEL}")

        # Показать статус подэтапов
        print(f"\n   Подэтапы:")
        print(f"     Субтитры:  {'ON' if config.YT_PACK_SUBTITLES else 'OFF'}")
        print(f"     Описание:  {'ON' if config.YT_PACK_DESCRIPTION else 'OFF'}")
        print(f"     Обложки:   {'ON' if config.YT_PACK_COVERS else 'OFF'}")

        results = {}

        # Этап 1: SRT
        if config.YT_PACK_SUBTITLES:
            print("\n" + "-" * 40)
            print("ЭТАП 1: SRT субтитры")
            print("-" * 40)
            srt_files = self.generate_subtitles(transcription_data)
            results['subtitles'] = {lang: str(path) for lang, path in srt_files.items()}

        # Этап 2: Описание
        yt_pack_data = {}
        if config.YT_PACK_DESCRIPTION:
            print("\n" + "-" * 40)
            print("ЭТАП 2: Заголовки + описание + теги")
            print("-" * 40)

            # Для анализа используем сгруппированный SRT (предложения, ~300 блоков вместо 3000+)
            srt_content = self._group_transcription_srt(transcription_data)
            print(f"   Сгруппировано в {srt_content.count(' --> ')} предложений для анализа")

            style_guide = self._load_style_guide()
            yt_pack_data = self.generate_description(srt_content, style_guide)
            results['description'] = yt_pack_data

        # Этап 3: Обложки
        if config.YT_PACK_COVERS:
            print("\n" + "-" * 40)
            print("ЭТАП 3: Обложки (FastGen)")
            print("-" * 40)

            if not yt_pack_data:
                # Загрузить из файла если этап 2 был выключен
                json_path = self.output_dir / 'yt_pack.json'
                if json_path.exists():
                    with open(json_path, 'r', encoding='utf-8') as f:
                        yt_pack_data = json.load(f)

            if yt_pack_data:
                cover_files = self.generate_covers(yt_pack_data)
                results['covers'] = [str(p) for p in cover_files]
            else:
                print("   [SKIP] yt_pack.json не найден — сначала запустите этап 2")

        # Итог + стоимость
        print("\n" + "=" * 60)
        print("📦 YT PACKER — ГОТОВО")
        if self.costs:
            keys = ['input_tokens', 'output_tokens', 'thinking_tokens', 'total_output_tokens',
                    'input_cost', 'output_cost', 'thinking_cost', 'total_cost']
            total_cost = {k: sum(c.get(k, 0) for c in self.costs) for k in keys}
            project_name = self.project_dir.name

            print(f"\n💰 Стоимость YT Packer:")
            print(f"   Input:   {total_cost['input_tokens']:>10,} токенов  = ${total_cost['input_cost']:.5f}")
            print(f"   Output:  {total_cost['output_tokens']:>10,} токенов  = ${total_cost['output_cost']:.5f}")
            print(f"   {'─' * 48}")
            print(f"   ИТОГО:                                    ${total_cost['total_cost']:.5f}")

            # Накопленный лог (cost_log.json — общий с director)
            log_path = Path(__file__).parent.parent / 'cost_log.json'
            key_id = self.api_key[-8:] if len(self.api_key) >= 8 else self.api_key
            if log_path.exists():
                with open(log_path, 'r', encoding='utf-8') as f:
                    log_data = json.load(f)
            else:
                log_data = {}
            if key_id not in log_data:
                log_data[key_id] = {'api_key_id': key_id, 'total_cost': 0.0, 'total_runs': 0, 'runs': []}
            entry = log_data[key_id]
            entry['runs'].append({
                'timestamp':     time.strftime('%Y-%m-%d %H:%M:%S'),
                'project':       project_name,
                'model':         f"yt_pack ({config.YT_PACK_CONTENT_MODEL} / {config.YT_PACK_TRANSLATE_MODEL})",
                'cost':          total_cost['total_cost'],
                'input_tokens':  total_cost['input_tokens'],
                'output_tokens': total_cost['output_tokens'],
                'thinking_tokens': 0,
            })
            entry['total_cost'] = round(entry['total_cost'] + total_cost['total_cost'], 8)
            entry['total_runs'] += 1
            with open(log_path, 'w', encoding='utf-8') as f:
                json.dump(log_data, f, ensure_ascii=False, indent=2)

            print(f"\n📊 Затраты по ключу ...{key_id}:")
            print(f"   Этот прогон:    ${total_cost['total_cost']:.5f}")
            print(f"   Прогонов всего: {entry['total_runs']}")
            print(f"   {'─' * 40}")
            print(f"   НАКОПЛЕНО:      ${entry['total_cost']:.5f}")
        elif self.input_tokens or self.output_tokens:
            print(f"   Токены Gemini: {self.input_tokens:,} in / {self.output_tokens:,} out")
        print("=" * 60)

        # Дописываем в общий run_log
        from modules.queue import append_run_log
        project_name = self.project_dir.name
        stages_done = ', '.join(filter(None, [
            'субтитры' if config.YT_PACK_SUBTITLES else '',
            'описание' if config.YT_PACK_DESCRIPTION else '',
            'обложки' if config.YT_PACK_COVERS else '',
        ]))
        log_params = {
            'Языки:':            ', '.join(config.YT_PACK_LANGUAGES),
            'Модель (контент):': config.YT_PACK_CONTENT_MODEL,
            'Модель (перевод):': config.YT_PACK_TRANSLATE_MODEL,
            'Этапы:':            stages_done or '—',
        }
        if self.costs:
            log_params['ИТОГО:'] = f"${total_cost['total_cost']:.5f}"
        append_run_log(self.project_dir, project_name, 'YT PACKER', log_params)

        return results


# ============================================================================
# ФУНКЦИЯ-ОБЁРТКА (для вызова из agent.py)
# ============================================================================

def run_yt_packer(project_dir: str, api_key: Optional[str] = None, source_lang: Optional[str] = None) -> Dict[str, Any]:
    """
    Запустить YT Packer для проекта.

    Args:
        project_dir: Путь к папке проекта
        api_key: Gemini API key (опционально, берётся из config)
        source_lang: Язык транскрипции (если None — читается из transcription.json)

    Returns:
        Результаты работы
    """
    packer = YTPacker(project_dir, api_key, source_lang=source_lang)
    return packer.run()
