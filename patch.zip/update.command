#!/bin/bash
# VARAGENT - Update
# Works even if varagent.py fails to launch.
# Run: double-click this file in Finder

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo ""
echo "================================================================"
echo " VARAGENT - Update"
echo " Works even if varagent.py fails to launch."
echo "================================================================"
echo ""

if ! command -v python3 &>/dev/null; then
    echo " [ERROR] python3 not found. Run install.command first."
    echo ""
    read -p "Press Enter to exit..." DUMMY
    exit 1
fi

TMP_PY="$(mktemp /tmp/varagent_update_XXXXXX.py)"

cat > "$TMP_PY" << 'PYEOF'
import sys, pathlib
p = pathlib.Path('.')
sys.path.insert(0, str(p / 'agent'))
from modules import updater as u
i = u.check_updates(p)
if i.get('error'):
    print('[ERROR]', i['error'])
    sys.exit(1)
if not i['available']:
    print('[OK] Already up to date: v' + i['version'])
    sys.exit(0)
print('Available: v' + i['version'])
for line in i.get('changelog', []):
    print(' *', line)
print()
res = u.install_update(p, lambda m: print(' ', m))
if not res['ok']:
    print('[ERROR]', res['error'])
    sys.exit(1)
print('[OK] Updated. Run varagent.command.')
PYEOF

echo " Checking for updates..."
echo ""
python3 "$TMP_PY"
EXIT_CODE=$?
rm -f "$TMP_PY"

if [ $EXIT_CODE -eq 1 ]; then
    echo ""
    echo " [ERROR] Update failed. See error above."
    echo ""
    read -p "Press Enter to exit..." DUMMY
    exit 1
fi

echo ""
echo " Run varagent.command"
echo ""
read -p "Press Enter to exit..." DUMMY
