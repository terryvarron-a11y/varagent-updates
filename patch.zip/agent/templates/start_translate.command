#!/bin/bash
# START_TRANSLATE.COMMAND - SRT Translation via Gemini AI
# Run: double-click this file in Finder

PROJECT_NAME="{project_name}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

chmod +x *.command 2>/dev/null
[ -f "$SCRIPT_DIR/.venv/bin/activate" ] && source "$SCRIPT_DIR/.venv/bin/activate"

if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e 'tell app "Terminal" to do script "cd '\''$SCRIPT_DIR'\'' && exec '\''$0'\''"'
    exit 0
fi

clear
cd "$SCRIPT_DIR"

echo ""
echo "================================================================================"
echo "SRT TRANSLATION: {project_name}"
echo "================================================================================"
echo ""

if [ ! -f "subtitles.srt" ]; then
    echo "[ERROR] subtitles.srt not found in project folder!"
    echo "   Run transcription first."
    echo "Press Enter to exit..." && read
    exit 1
fi

META_FLAG="--meta"
echo " Perevesti title i description?"
echo "   [1] Da - title + description  (po umolchaniyu)"
echo "   [2] Net - tolko subtitry"
echo ""
read -p "  Vybor [1/2] (Enter = 1): " DO_META
[ "$DO_META" = "2" ] && META_FLAG=""
echo ""

echo "   Project:  {project_name}"
echo "   Folder:   $SCRIPT_DIR"
echo ""

python3 "$ROOT_DIR/agent/tools/translate_srt.py" "$SCRIPT_DIR" $META_FLAG
RESULT=$?

if [ $RESULT -ne 0 ]; then
    echo ""
    echo "[ERROR] Translation failed!"
    echo "Press Enter to exit..." && read
    exit 1
fi

echo ""
echo "[OK] Done! Check translations/ folder."
echo "Press Enter to exit..." && read
exit 0
