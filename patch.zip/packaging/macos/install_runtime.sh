#!/bin/bash
set -euo pipefail

RESOURCES_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD_DIR="$RESOURCES_DIR/payload"
LAUNCHER_APP="$RESOURCES_DIR/VARAGENT.app"
INSTALL_ROOT="$HOME/Library/Application Support/VARAGENT"
APPLICATIONS_DIR="$HOME/Applications"
INSTALLED_APP="$APPLICATIONS_DIR/VARAGENT.app"

echo ""
echo "================================================================"
echo " VARAGENT for macOS"
echo "================================================================"
echo ""
echo "Architecture: $(uname -m)"
echo "Program folder: $INSTALL_ROOT"
echo ""

if [ ! -f "$PAYLOAD_DIR/varagent.py" ]; then
    echo "[ERROR] Installer payload is incomplete."
    read -r -p "Press Enter to close..."
    exit 1
fi

mkdir -p "$INSTALL_ROOT" "$APPLICATIONS_DIR"

RSYNC_ARGS=(-a --exclude=/.codex/ --exclude=/Codex/.codex/)
if [ -d "$INSTALL_ROOT/agent/prompts" ]; then
    RSYNC_ARGS+=(--exclude=/agent/prompts/)
fi

echo "[1/3] Copying VARAGENT..."
/usr/bin/rsync "${RSYNC_ARGS[@]}" "$PAYLOAD_DIR/" "$INSTALL_ROOT/"
/usr/bin/xattr -cr "$INSTALL_ROOT" 2>/dev/null || true
/usr/bin/find "$INSTALL_ROOT" -name '*.command' -exec /bin/chmod +x {} +

echo "[2/3] Installing runtime dependencies..."
/bin/bash "$INSTALL_ROOT/install.command"

echo "[3/3] Installing launcher..."
/bin/rm -rf "$INSTALLED_APP"
/usr/bin/ditto "$LAUNCHER_APP" "$INSTALLED_APP"
/usr/bin/xattr -cr "$INSTALLED_APP" 2>/dev/null || true

echo ""
echo "================================================================"
echo " INSTALLATION COMPLETE"
echo "================================================================"
echo ""
echo "VARAGENT.app is in: $APPLICATIONS_DIR"
echo "The working files are in: $INSTALL_ROOT"
echo "Updates will continue to use the existing varagent-updates channel."
echo ""

/usr/bin/open "$INSTALLED_APP"
read -r -p "Press Enter to close this window..."
