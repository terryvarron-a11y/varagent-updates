#!/bin/bash
# RUN_STAGE2_AUTO.COMMAND - Automatic video concat (macOS)
# Run: double-click this file in Finder
#
# Usage:
#   ./run_stage2_auto.command [fast|1080p]
#
# Parameters:
#   fast    - Fast concat, no re-encoding (default)
#   1080p   - Concat with 1080p re-encoding

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Auto-set execute permissions
chmod +x *.command 2>/dev/null
[ -f "$SCRIPT_DIR/.venv/bin/activate" ] && source "$SCRIPT_DIR/.venv/bin/activate"

echo ""
echo "================================================================================"
echo "AUTOMATIC VIDEO CONCAT FOR ALL PROJECTS"
echo "================================================================================"
echo ""

# Mode from argument
MODE="${1:-fast}"

if [ "$MODE" = "fast" ]; then
    echo "   Mode: FAST CONCAT (no re-encoding)"
    SCRIPT_FILE="process_fast.sh"
elif [ "$MODE" = "1080p" ]; then
    echo "   Mode: 1080p CONCAT (with re-encoding)"
    SCRIPT_FILE="process_1080p.sh"
else
    echo ""
    echo " [ERROR] Invalid parameter!"
    echo "   Usage: ./run_stage2_auto.command [fast|1080p]"
    echo "   fast  - fast concat (default)"
    echo "   1080p - concat with re-encoding"
    echo ""
    exit 1
fi

echo ""

# Check projects folder
if [ ! -d "projects" ]; then
    echo " [ERROR] projects/ folder not found!"
    exit 1
fi

cd "$SCRIPT_DIR/projects"

# Count project folders
PROJECT_COUNT=$(find . -maxdepth 1 -mindepth 1 -type d | wc -l | tr -d ' ')

if [ "$PROJECT_COUNT" -eq 0 ]; then
    echo ""
    echo " [ERROR] No projects found in projects/ folder!"
    echo ""
    exit 1
fi

echo "   Projects found: $PROJECT_COUNT"
echo ""

SUCCESS_COUNT=0
ERROR_COUNT=0

for PROJECT_DIR in */; do
    [ -d "$PROJECT_DIR" ] || continue
    PROJECT="${PROJECT_DIR%/}"

    echo ""
    echo "================================================================================"
    echo "PROJECT: $PROJECT"
    echo "================================================================================"
    echo ""

    # Check montage_plan.json
    if [ ! -f "$PROJECT/montage_plan.json" ]; then
        echo "   [ERROR] montage_plan.json not found!"
        echo "          Run run_stage1_simple.command first"
        ERROR_COUNT=$((ERROR_COUNT+1))
        continue
    fi
    echo "   montage_plan.json [OK]"

    # Check audio file (any format)
    AUDIO_FOUND=0
    for EXT in wav mp3 flac m4a aac; do
        if compgen -G "$PROJECT/*.$EXT" > /dev/null 2>&1; then
            AUDIO_FOUND=1
            break
        fi
    done
    if [ "$AUDIO_FOUND" -eq 0 ]; then
        echo "   [ERROR] Audio file not found!"
        ERROR_COUNT=$((ERROR_COUNT+1))
        continue
    fi
    echo "   Audio file [OK]"

    # Check video fragments
    HAS_VIDEO=0
    for VFILE in "$PROJECT"/*.mp4; do
        [ -f "$VFILE" ] || continue
        VNAME=$(basename "$VFILE")
        if [ "$VNAME" != "result.mp4" ]; then
            HAS_VIDEO=1
            break
        fi
    done

    if [ "$HAS_VIDEO" -eq 0 ]; then
        echo "   [ERROR] Video fragments not found!"
        echo "          Generate video in Veo3 and download to project folder."
        ERROR_COUNT=$((ERROR_COUNT+1))
        continue
    fi
    echo "   Video fragments [OK]"
    echo ""
    echo "   Starting concat..."
    echo ""

    # Run concat script
    cd "$PROJECT"
    if [ -f "$SCRIPT_FILE" ]; then
        bash "$SCRIPT_FILE"
        EXIT_CODE=$?
    else
        echo "   [WARN] $SCRIPT_FILE not found, running python3 directly..."
        python3 video_concat.py montage_plan.json -o "${PROJECT}.mp4"
        EXIT_CODE=$?
    fi
    cd ..

    if [ $EXIT_CODE -ne 0 ]; then
        echo ""
        echo "   [ERROR] Concat failed for $PROJECT!"
        ERROR_COUNT=$((ERROR_COUNT+1))
    else
        echo ""
        echo "   [OK] $PROJECT completed successfully!"
        SUCCESS_COUNT=$((SUCCESS_COUNT+1))
    fi
done

# ============================================================================
# SUMMARY
# ============================================================================

echo ""
echo "================================================================================"
echo "SUMMARY"
echo "================================================================================"
echo ""
echo "   Total projects: $PROJECT_COUNT"
echo "   [OK]    Success: $SUCCESS_COUNT"
echo "   [ERROR] Errors:  $ERROR_COUNT"
echo ""

if [ "$ERROR_COUNT" -gt 0 ]; then
    echo "   [WARN] Some projects finished with errors!"
    echo ""
else
    echo "   [OK] All projects processed successfully!"
    echo ""
    echo "   RESULTS:"
    echo "   - result.mp4 in each project folder"
    echo "   - VEO_AUDIO.wav in each project folder"
    echo "   - Veo3 fragments in FLOW_veo3_fragments/"
    echo ""
fi

echo "================================================================================"
echo ""
