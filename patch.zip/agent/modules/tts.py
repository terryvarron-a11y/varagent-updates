"""
TTS модуль — озвучка текста через два сервиса:
  - voiceapi.csv666.ru  (X-API-Key, template_uuid)
  - voicer.mat3u.com    (Bearer token, ElevenLabs voice_id)

Формат файла сценария (первая строка = voice_id):
    VOICE_ID_HERE
    Текст озвучки...
    строка 2...
"""
from __future__ import annotations

import time
import zipfile
import requests
from pathlib import Path
from typing import Optional
from tqdm import tqdm

import config
from modules.textio import read_user_text


# ============================================================================
# ПАРСЕР ФАЙЛА СЦЕНАРИЯ
# ============================================================================

def parse_script_file(script_path: Path) -> tuple[str, str]:
    """
    Читает файл сценария.
    Первая строка = voice_id, остальное = текст.

    Returns:
        (voice_id, text)
    """
    content = read_user_text(script_path).strip()
    lines = content.splitlines()
    if not lines:
        raise ValueError(f"Файл сценария пустой: {script_path}")

    voice_id = lines[0].strip()
    text = '\n'.join(lines[1:]).strip()

    if not voice_id:
        raise ValueError(f"Voice ID не найден в первой строке: {script_path}")
    if not text:
        raise ValueError(f"Текст сценария пустой (после первой строки): {script_path}")

    return voice_id, text


# ============================================================================
# БАЗОВЫЙ КЛИЕНТ
# ============================================================================

def _extract_audio_from_zip(zip_path: Path, output_dir: Path) -> Path:
    """
    Извлекает основной аудиофайл из ZIP.
    ZIP от TTS сервисов может содержать: чанки (chunk_001.mp3...) + склеенный файл (merged/full/result).
    Берём самый большой .mp3 — это склеенный файл.
    """
    audio_exts = {'.mp3', '.wav', '.m4a', '.aac', '.flac'}
    with zipfile.ZipFile(zip_path, 'r') as zf:
        zf.extractall(output_dir)
        audio_files = []
        for info in zf.infolist():
            p = output_dir / info.filename
            if p.suffix.lower() in audio_exts and p.is_file():
                audio_files.append(p)

    if not audio_files:
        raise RuntimeError(f"ZIP не содержит аудиофайлов: {zip_path}")

    # Берём самый большой файл — это склеенный результат
    best = max(audio_files, key=lambda f: f.stat().st_size)
    print(f"   ZIP: извлечено {len(audio_files)} файл(ов), основной: {best.name} ({best.stat().st_size // 1024} KB)")
    return best


class BaseTTSClient:
    POLL_INTERVAL = 5   # секунд между проверками статуса
    POLL_TIMEOUT  = 600 # секунд максимального ожидания

    def synthesize(self, text: str, voice_id: str, output_path: Path) -> Path:
        raise NotImplementedError

    def _wait_for_completion(self, task_id, status_fn, done_statuses, error_statuses) -> str:
        """Polling до готовности задачи."""
        elapsed = 0
        last_status = None
        with tqdm(desc="TTS: ожидание", unit="с", dynamic_ncols=True) as pbar:
            while elapsed < self.POLL_TIMEOUT:
                status = status_fn(task_id)
                if status != last_status:
                    pbar.set_postfix(status=status)
                    last_status = status
                if status in done_statuses:
                    pbar.update(elapsed)
                    return status
                if status in error_statuses:
                    raise RuntimeError(f"TTS задача провалилась со статусом: {status}")
                time.sleep(self.POLL_INTERVAL)
                elapsed += self.POLL_INTERVAL
                pbar.update(self.POLL_INTERVAL)
        raise TimeoutError(f"TTS задача не завершилась за {self.POLL_TIMEOUT}с")


# ============================================================================
# СЕРВИС 1: voiceapi.csv666.ru
# ============================================================================

class CSV666Client(BaseTTSClient):
    """
    API: voiceapi.csv666.ru
    Auth: X-API-Key header
    Voice: задаётся через template_uuid (голос привязан к шаблону)
    """
    BASE_URL = 'https://voiceapi.csv666.ru'

    def __init__(self, api_key: str = None):
        self.api_key = api_key or config.TTS_API_KEY_CSV666
        if not self.api_key:
            raise ValueError("TTS_API_KEY_CSV666 не задан в .env")
        self.headers = {'X-API-Key': self.api_key}

    def _find_template_uuid(self, voice_id: str) -> Optional[str]:
        """
        Ищет шаблон пользователя с данным voice_id в настройках.
        Если не найден — использует voice_id напрямую как template_uuid.
        """
        try:
            r = requests.get(f'{self.BASE_URL}/templates', headers=self.headers, timeout=15)
            r.raise_for_status()
            templates = r.json()
            for tmpl in templates:
                settings = tmpl.get('settings', {})
                # Ищем совпадение voice_id в любом поле settings
                if (settings.get('voice_id') == voice_id
                        or settings.get('voice') == voice_id
                        or str(tmpl.get('uuid', '')) == voice_id):
                    return tmpl['uuid']
        except Exception as e:
            print(f"   [WARN] Не удалось загрузить шаблоны csv666: {e}")
        # Fallback: считаем что voice_id — это уже template_uuid
        return voice_id

    def _get_status(self, task_id) -> str:
        r = requests.get(f'{self.BASE_URL}/tasks/{task_id}/status',
                         headers=self.headers, timeout=15)
        r.raise_for_status()
        return r.json().get('status', 'unknown')

    def synthesize(self, text: str, voice_id: str, output_path: Path) -> Path:
        template_uuid = self._find_template_uuid(voice_id)
        print(f"   csv666: template_uuid = {template_uuid}")

        payload = {
            'text': text,
            'template_uuid': template_uuid,
            'chunk_size': config.TTS_CSV666_CHUNK_SIZE,
        }

        r = requests.post(f'{self.BASE_URL}/tasks', json=payload,
                          headers=self.headers, timeout=30)
        r.raise_for_status()
        task_id = r.json()['task_id']
        print(f"   csv666: task_id = {task_id}")

        # Ждём готовности
        self._wait_for_completion(
            task_id,
            status_fn=self._get_status,
            done_statuses={'ending', 'ending_processed'},
            error_statuses={'error', 'error_handled'},
        )

        # Скачиваем результат
        r = requests.get(f'{self.BASE_URL}/tasks/{task_id}/result',
                         headers=self.headers, timeout=120, stream=True)
        r.raise_for_status()

        # Определяем формат по Content-Type (сервер может вернуть ZIP даже если просили mp3)
        ct = r.headers.get('Content-Type', '')
        is_zip = 'zip' in ct or config.TTS_CSV666_OUTPUT_FORMAT == 'zip'
        dl_suffix = '.zip' if is_zip else '.mp3'
        dl_path = output_path.with_suffix(dl_suffix)

        with open(dl_path, 'wb') as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)

        # Если ZIP — извлекаем основной аудиофайл
        if dl_path.suffix == '.zip' or zipfile.is_zipfile(dl_path):
            extract_dir = dl_path.parent / f'{dl_path.stem}_extracted'
            extract_dir.mkdir(exist_ok=True)
            audio = _extract_audio_from_zip(dl_path, extract_dir)
            # Копируем основной файл на место
            final = output_path.with_suffix(audio.suffix)
            audio.replace(final)
            print(f"   csv666: сохранено → {final}")
            return final

        print(f"   csv666: сохранено → {dl_path}")
        return dl_path


# ============================================================================
# СЕРВИС 2: voicer.mat3u.com
# ============================================================================

class Mat3uClient(BaseTTSClient):
    """
    API: voicer.mat3u.com
    Auth: Authorization: Bearer token
    Voice: ElevenLabs voice_id
    """
    BASE_URL = 'https://voicer.mat3u.com/api/v1'

    def __init__(self, api_key: str = None):
        self.api_key = api_key or config.TTS_API_KEY_MAT3U
        if not self.api_key:
            raise ValueError("TTS_API_KEY_MAT3U не задан в .env")
        self.headers = {'Authorization': f'Bearer {self.api_key}'}

    def _get_status(self, task_id: str) -> str:
        r = requests.get(f'{self.BASE_URL}/voice/status/{task_id}',
                         headers=self.headers, timeout=15)
        r.raise_for_status()
        return r.json().get('status', 'unknown')

    def synthesize(self, text: str, voice_id: str, output_path: Path) -> Path:
        payload = {
            'text': text,
            'voice_id': voice_id,
            'model_id': config.TTS_MAT3U_MODEL_ID,
            'split_type': config.TTS_MAT3U_SPLIT_TYPE,
            'max_chunk_length': config.TTS_MAT3U_MAX_CHUNK_LENGTH,
            'split_output': config.TTS_MAT3U_SPLIT_OUTPUT,
            'auto_pause_enabled': config.TTS_MAT3U_AUTO_PAUSE_ENABLED,
            'auto_pause_duration': config.TTS_MAT3U_AUTO_PAUSE_DURATION,
            'auto_pause_frequency': config.TTS_MAT3U_AUTO_PAUSE_FREQUENCY,
        }

        r = requests.post(f'{self.BASE_URL}/voice/synthesize', json=payload,
                          headers=self.headers, timeout=30)
        r.raise_for_status()
        data = r.json()
        task_id = data['task_id']
        chunks = data.get('chunks_count', '?')
        print(f"   mat3u: task_id = {task_id}, chunks = {chunks}")

        # Ждём готовности
        self._wait_for_completion(
            task_id,
            status_fn=self._get_status,
            done_statuses={'completed'},
            error_statuses={'failed'},
        )

        # Скачиваем результат
        r = requests.get(f'{self.BASE_URL}/voice/download/{task_id}',
                         headers=self.headers, timeout=120, stream=True)
        r.raise_for_status()

        # Определяем расширение по Content-Type
        ct = r.headers.get('Content-Type', '')
        if 'zip' in ct:
            dl_suffix = '.zip'
        elif 'mpeg' in ct or 'mp3' in ct:
            dl_suffix = '.mp3'
        else:
            dl_suffix = '.mp3'

        dl_path = output_path.with_suffix(dl_suffix)
        with open(dl_path, 'wb') as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)

        # Если ZIP (split_output=true) — извлекаем основной аудиофайл
        if dl_path.suffix == '.zip' or zipfile.is_zipfile(dl_path):
            extract_dir = dl_path.parent / f'{dl_path.stem}_extracted'
            extract_dir.mkdir(exist_ok=True)
            audio = _extract_audio_from_zip(dl_path, extract_dir)
            final = output_path.with_suffix(audio.suffix)
            audio.replace(final)
            print(f"   mat3u: сохранено → {final}")
            return final

        print(f"   mat3u: сохранено → {dl_path}")
        return dl_path


# ============================================================================
# ФАБРИКА
# ============================================================================

def get_tts_client(service: str = None) -> BaseTTSClient:
    """Возвращает клиент нужного сервиса."""
    svc = (service or config.TTS_SERVICE).lower()
    if svc == 'csv666':
        return CSV666Client()
    elif svc == 'mat3u':
        return Mat3uClient()
    else:
        raise ValueError(f"Неизвестный TTS сервис: {svc}. Допустимые: csv666, mat3u")


def run_tts(script_path: Path, output_path: Path, service: str = None) -> Path:
    """
    Высокоуровневая функция: читает файл сценария → генерирует аудио → возвращает путь.

    Args:
        script_path:  путь к .txt файлу (первая строка = voice_id)
        output_path:  желаемый путь к выходному файлу (расширение может измениться)
        service:      'csv666' | 'mat3u' | None (из .env)

    Returns:
        Путь к скачанному аудиофайлу
    """
    voice_id, text = parse_script_file(script_path)
    print(f"\n🎙️  TTS: {script_path.name}")
    print(f"   Сервис:   {service or config.TTS_SERVICE}")
    print(f"   Voice ID: {voice_id}")
    print(f"   Символов: {len(text)}")

    client = get_tts_client(service)
    return client.synthesize(text, voice_id, output_path)
