#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Update Codex CLI to latest version."""

import sys
import os
import urllib.request
import shutil
import subprocess
from pathlib import Path

CODEX_DIR = Path(__file__).parent / "Codex"
CODEX_EXE = CODEX_DIR / "codex-x86_64-pc-windows-msvc.exe"
DOWNLOAD_URL = "https://github.com/openai/codex/releases/latest/download/codex-x86_64-pc-windows-msvc.exe"

def get_current_version():
    """Get current Codex version."""
    if not CODEX_EXE.exists():
        return None
    try:
        result = subprocess.run(
            [str(CODEX_EXE), "--version"],
            capture_output=True,
            text=True,
            timeout=5
        )
        return result.stdout.strip()
    except Exception:
        return None

def download_latest():
    """Download latest Codex CLI."""
    print(f"Downloading latest Codex CLI from {DOWNLOAD_URL}...")

    # Create Codex directory if it doesn't exist
    CODEX_DIR.mkdir(exist_ok=True)

    # Backup current exe
    if CODEX_EXE.exists():
        backup = CODEX_EXE.with_suffix('.exe.bak')
        print(f"Backing up current version to {backup.name}...")
        shutil.copy2(CODEX_EXE, backup)

    # Download new version
    try:
        with urllib.request.urlopen(DOWNLOAD_URL, timeout=60) as response:
            total = int(response.headers.get('content-length', 0))
            downloaded = 0
            chunk_size = 8192

            with open(CODEX_EXE, 'wb') as f:
                while True:
                    chunk = response.read(chunk_size)
                    if not chunk:
                        break
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total:
                        pct = int(downloaded * 100 / total)
                        print(f"\rDownloading: {pct}% ({downloaded}/{total} bytes)", end='', flush=True)

        print("\n[OK] Download complete")
        return True

    except Exception as e:
        print(f"\n[FAIL] Download failed: {e}")
        # Restore backup if download failed
        backup = CODEX_EXE.with_suffix('.exe.bak')
        if backup.exists():
            print("Restoring backup...")
            shutil.copy2(backup, CODEX_EXE)
        return False

def main():
    print("=" * 60)
    print("Codex CLI Update Tool")
    print("=" * 60)

    current = get_current_version()
    if current:
        print(f"Current version: {current}")
    else:
        print("Current version: Not installed")

    print()

    if download_latest():
        new_version = get_current_version()
        if new_version:
            print(f"[OK] Updated to: {new_version}")
            if current and new_version == current:
                print("  (Version unchanged - already latest)")
        else:
            print("[FAIL] Update verification failed")
        return 0
    else:
        return 1

if __name__ == '__main__':
    sys.exit(main())
