"""Script Director transport for direct OpenAI-compatible chat providers."""

from __future__ import annotations

from typing import Any, Optional, Tuple

import config
from modules import chat_client
from modules.script_director import GeminiScriptDirector


class _ChatTextResponse:
    def __init__(self, text: str):
        self.text = text


class ChatScriptDirector(GeminiScriptDirector):
    """Reuse Script Director parsing while replacing Gemini with chat API."""

    def __init__(self, model_name: Optional[str] = None):
        self.provider = (getattr(config, 'GPT_PROVIDER', '') or '').strip().lower()
        defaults = {
            'deepseek': getattr(config, 'DEEPSEEK_MODEL', '') or 'deepseek-v4-flash',
            'openrouter': getattr(config, 'OPENROUTER_MODEL', '') or 'openrouter/free',
            'cliproxy': getattr(config, 'CLIPROXY_MODEL', '') or 'gemini-3.1-pro-low',
            'codex_reseller': (
                getattr(config, 'CODEX_RESELLER_MODEL', '') or 'gpt-5.6-terra'
            ),
            'gpt_nexus': getattr(config, 'GPT_NEXUS_MODEL', '') or 'gpt-5.5',
            'meta_muse': (
                getattr(config, 'META_MUSE_MODEL', '')
                or 'muse-spark-1.2-contributor'
            ),
        }
        if self.provider not in defaults:
            raise ValueError(
                f"ChatScriptDirector does not support provider: {self.provider}"
            )

        explicit = str(model_name or '').strip()
        if not explicit or (
            'gemini' in explicit.lower() and self.provider != 'cliproxy'
        ):
            explicit = defaults[self.provider]
        self.model_name = explicit
        self.input_tokens = 0
        self.output_tokens = 0
        self.api_key = chat_client._api_key(self.provider)
        if not self.api_key:
            raise ValueError(
                f"Script Director: API key for {self.provider} is not configured"
            )

    def _make_api_call(
        self,
        prompt: str,
        pass2_mode: bool = False,
        spinner_msg: str = "Chat provider is thinking",
        system_instruction: str = '',
    ) -> Tuple[Any, Optional[dict]]:
        messages = []
        if system_instruction.strip():
            messages.append({
                'role': 'system',
                'content': system_instruction.strip(),
            })
        messages.append({'role': 'user', 'content': prompt})
        text = chat_client.chat_completion(
            self.provider,
            self.model_name,
            messages,
            max_tokens=None,
            reasoning_level=getattr(config, 'CHAT_REASONING_LEVEL', 'medium'),
            web=(
                self.provider == 'openrouter'
                and getattr(config, 'OPENROUTER_WEB_SEARCH', 'disabled') == 'enabled'
            ),
            json_mode=False,
            timeout=getattr(config, 'GPT_DIRECTOR_TIMEOUT', 900),
        )
        return _ChatTextResponse(text), None
