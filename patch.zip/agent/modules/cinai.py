"""CinAI.tv image generation client.

This client targets the authenticated Studio reverse API documented in
``VARAGENT_API/docs/CINAI_TV_REVERSE_API.md``. It intentionally keeps the
credential in configuration and never prints authorization headers.
"""

from __future__ import annotations

import json
import logging
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from io import BytesIO
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
from urllib.parse import urlsplit, urlunsplit

import requests

import config
from extract_prompt import extract_all_prompts, find_prompts_file


CINAI_STUDIO_URL = "https://cinai.tv/StudioChat?tab=image"
_TOKEN_STORAGE_KEYS = (
    "base44_access_token",
    "access_token",
    "token",
)


def extract_access_token(storage: Dict[str, Any]) -> str:
    """Return the first plausible Studio bearer token from localStorage."""
    for key in _TOKEN_STORAGE_KEYS:
        value = storage.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
        if isinstance(value, dict):
            for nested in ("access_token", "token", "value"):
                candidate = value.get(nested)
                if isinstance(candidate, str) and candidate.strip():
                    return candidate.strip()
    return ""


def login_with_browser(
    profile_dir: Optional[str] = None,
    status_callback=None,
    timeout_seconds: int = 600,
) -> str:
    """Open an isolated persistent browser profile and capture CinAI's token.

    This deliberately uses Playwright's own browser profile. It does not depend
    on Opera, Chrome, Firefox, cookies, or a remote-debugging port.
    """
    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise CinAIError(
            "Playwright is required for CinAI login. Install it with "
            "`pip install playwright` and `python -m playwright install chromium`."
        ) from exc

    profile = Path(profile_dir or (Path(config.__file__).resolve().parent / ".cinai_browser"))
    profile.mkdir(parents=True, exist_ok=True)
    report = status_callback or (lambda _text: None)

    with sync_playwright() as playwright:
        report("Открываю браузер CinAI...")
        context = playwright.chromium.launch_persistent_context(
            str(profile),
            headless=False,
            viewport={"width": 1280, "height": 900},
        )
        page = context.pages[0] if context.pages else context.new_page()
        page.goto(CINAI_STUDIO_URL, wait_until="domcontentloaded", timeout=60000)
        report("Войдите в CinAI в открывшемся окне...")
        deadline = time.time() + max(30, int(timeout_seconds))
        token = ""
        while time.time() < deadline:
            for candidate in context.pages:
                try:
                    storage = candidate.evaluate("Object.fromEntries(Object.entries(localStorage))")
                    token = extract_access_token(storage or {})
                    if token:
                        break
                except Exception:
                    continue
            if token:
                break
            time.sleep(1)
        context.close()

    if not token:
        raise CinAIAuthError("CinAI login timed out: bearer token was not found")
    return token


class CinAIError(RuntimeError):
    """Base error for CinAI requests."""


class CinAIAuthError(CinAIError):
    """The configured bearer token was rejected."""


class CinAIRetryableError(CinAIError):
    """A transient HTTP, stream, or download failure."""


def _clean_error(text: str, limit: int = 300) -> str:
    text = (text or "").replace("\r", " ").replace("\n", " ").strip()
    return text[:limit]


def _is_retryable_status(status: int) -> bool:
    return status == 429 or 500 <= status <= 599


def _safe_parallel(value: Optional[int]) -> int:
    try:
        value = int(value or getattr(config, "CINAI_MAX_PARALLEL", 6))
    except (TypeError, ValueError):
        value = 6
    return max(1, min(value, 6))


def _image_dimensions(payload: bytes) -> Tuple[int, int]:
    try:
        from PIL import Image

        with Image.open(BytesIO(payload)) as image:
            return image.size
    except Exception:
        return 0, 0


def _download_variants(output_url: str) -> List[str]:
    """Return the original CinAI URL plus likely full-size CDN variants."""
    urls = [output_url]
    parsed = urlsplit(output_url)
    parts = parsed.path.rstrip("/").split("/")
    if (
        parsed.netloc.lower() == "imagedelivery.net"
        and len(parts) >= 2
        and parts[-1].lower() == "md"
    ):
        for variant in ("original", "public", "full", "hd"):
            candidate = urlunsplit(
                (parsed.scheme, parsed.netloc, "/".join(parts[:-1] + [variant]), parsed.query, "")
            )
            if candidate not in urls:
                urls.insert(0, candidate)
    return urls


class CinAIClient:
    def __init__(
        self,
        access_token: Optional[str] = None,
        base_url: Optional[str] = None,
        app_id: Optional[str] = None,
        timeout: Optional[int] = None,
    ) -> None:
        self.access_token = (access_token or getattr(config, "CINAI_ACCESS_TOKEN", "")).strip()
        self.base_url = (base_url or getattr(config, "CINAI_API_BASE", "https://api.cinai.tv")).rstrip("/")
        self.app_id = app_id or getattr(config, "CINAI_APP_ID", "runway-workflows")
        self.timeout = int(timeout or getattr(config, "CINAI_TIMEOUT", 900))
        if not self.access_token:
            raise CinAIAuthError("CINAI_ACCESS_TOKEN is not configured")

    def _headers(self, accept: str = "application/json") -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.access_token}",
            "X-App-Id": self.app_id,
            "Accept": accept,
            "Content-Type": "application/json",
        }

    def get_billing_balance(self) -> Dict[str, Any]:
        response = requests.post(
            f"{self.base_url}/api/functions/getBillingBalance",
            headers=self._headers(),
            timeout=(30, 60),
        )
        if response.status_code in (401, 403):
            raise CinAIAuthError("CinAI access token was rejected")
        if not response.ok:
            raise CinAIError(
                f"CinAI billing request failed ({response.status_code}): "
                f"{_clean_error(response.text)}"
            )
        return response.json()

    def get_model_perks_status(self) -> Dict[str, Any]:
        """Return the signed-in account's current per-model perk/quota state."""
        response = requests.get(
            f"{self.base_url}/api/model-perks/status",
            headers=self._headers(),
            timeout=(30, 60),
        )
        if response.status_code in (401, 403):
            raise CinAIAuthError("CinAI access token was rejected")
        if not response.ok:
            raise CinAIError(
                f"CinAI model perks request failed ({response.status_code}): "
                f"{_clean_error(response.text)}"
            )
        return response.json()

    def _parse_sse(self, response: requests.Response) -> Dict[str, Any]:
        event_name: Optional[str] = None
        data_lines: List[str] = []
        terminal: Optional[Dict[str, Any]] = None

        def consume() -> Optional[Dict[str, Any]]:
            nonlocal event_name, data_lines
            if not data_lines:
                event_name = None
                return None
            raw = "\n".join(data_lines)
            data_lines = []
            current_event = event_name
            event_name = None
            try:
                payload = json.loads(raw)
            except json.JSONDecodeError:
                logging.debug("CinAI ignored non-JSON SSE event %s", current_event)
                return None
            if current_event == "error" or payload.get("error"):
                message = payload.get("error") or payload.get("message") or "CinAI stream error"
                raise CinAIError(_clean_error(str(message)))
            if current_event == "result" or payload.get("result", {}).get("output_url"):
                return payload.get("result", payload)
            return None

        for raw_line in response.iter_lines(decode_unicode=True):
            line = raw_line or ""
            if not line:
                result = consume()
                if result is not None:
                    terminal = result
                    break
                continue
            if line.startswith(":"):
                continue
            if line.startswith("event:"):
                event_name = line[6:].strip()
            elif line.startswith("data:"):
                data_lines.append(line[5:].lstrip())

        if terminal is None:
            terminal = consume()
        if not terminal or not terminal.get("output_url"):
            raise CinAIError("CinAI stream ended without an image output_url")
        return terminal

    def generate_image(
        self,
        prompt: str,
        model: Optional[str] = None,
        aspect_ratio: Optional[str] = None,
        quality: Optional[str] = None,
    ) -> Dict[str, Any]:
        model = model or getattr(config, "CINAI_MODEL", "gpt-image-2")
        aspect_ratio = aspect_ratio or getattr(config, "CINAI_ASPECT_RATIO", "16:9")
        quality = (quality or getattr(config, "CINAI_QUALITY", "1K")).upper()
        directives = [
            {"key": "aspect_ratio", "value": aspect_ratio, "origin": "ui_control", "turn": 1},
            {"key": "image_count", "value": 1, "origin": "ui_control", "turn": 1},
            {"key": "model_id", "value": model, "origin": "ui_control", "turn": 1},
        ]
        body = {
            "prompt": prompt,
            "payload": {
                "workflow_context": None,
                "surface": "studio-image",
                "chat_history": [],
                "mode_hint": "image",
                "model_preferences": {"image": model},
                "aspect_ratio": aspect_ratio,
                "image_count": 1,
                "settings": {"resolution": quality},
                "context_envelope": {
                    "v": 1,
                    "items": [],
                    "directives": directives,
                    "prompt": prompt,
                },
                "client_request_id": str(uuid.uuid4()),
            },
        }
        try:
            response = requests.post(
                f"{self.base_url}/api/agent/dispatch/stream",
                headers=self._headers("text/event-stream"),
                json=body,
                stream=True,
                timeout=(30, self.timeout),
            )
        except requests.RequestException as exc:
            raise CinAIRetryableError(f"CinAI connection failed: {_clean_error(str(exc))}") from exc
        if response.status_code in (401, 403):
            raise CinAIAuthError("CinAI access token was rejected")
        if _is_retryable_status(response.status_code):
            raise CinAIRetryableError(
                f"CinAI generation returned HTTP {response.status_code}"
            )
        if not response.ok:
            raise CinAIError(
                f"CinAI generation failed ({response.status_code}): "
                f"{_clean_error(response.text)}"
            )
        try:
            return self._parse_sse(response)
        finally:
            response.close()

    def download_image(self, output_url: str, output_path: Path) -> None:
        best_payload = b""
        best_size = (0, 0)
        last_status: Optional[int] = None

        for candidate_url in _download_variants(output_url):
            try:
                response = requests.get(candidate_url, timeout=(30, 180))
            except requests.RequestException as exc:
                logging.debug("CinAI image download failed for %s: %s", candidate_url, exc)
                continue
            last_status = response.status_code
            if not response.ok:
                continue
            payload = response.content
            size = _image_dimensions(payload)
            if size[0] * size[1] > best_size[0] * best_size[1]:
                best_payload = payload
                best_size = size

        if not best_payload:
            if last_status == 429 or (last_status is not None and last_status >= 500):
                raise CinAIRetryableError(
                    f"CinAI image download returned HTTP {last_status}"
                )
            raise CinAIError(
                f"CinAI image download failed ({last_status or 'network error'})"
            )

        if max(best_size) and max(best_size) < 768:
            raise CinAIRetryableError(
                f"CinAI returned only a {best_size[0]}x{best_size[1]} preview, not a usable image"
            )

        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_bytes(best_payload)
        logging.info(
            "CinAI image downloaded: %s -> %s (%sx%s)",
            output_url,
            output_path.name,
            best_size[0],
            best_size[1],
        )

    def upload_image(self, image_path: str) -> str:
        path = Path(image_path)
        if not path.is_file():
            raise FileNotFoundError(path)
        mime = {
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".png": "image/png",
            ".webp": "image/webp",
        }.get(path.suffix.lower(), "application/octet-stream")
        headers = self._headers()
        headers.pop("Content-Type", None)
        try:
            with path.open("rb") as handle:
                response = requests.post(
                    f"{self.base_url}/api/integrations/Core/UploadFile",
                    headers=headers,
                    files={"file": (path.name, handle, mime)},
                    timeout=(30, 180),
                )
        except requests.RequestException as exc:
            raise CinAIRetryableError(
                f"CinAI upload failed: {_clean_error(str(exc))}"
            ) from exc
        if response.status_code in (401, 403):
            raise CinAIAuthError("CinAI access token was rejected")
        if not response.ok:
            raise CinAIError(
                f"CinAI upload failed ({response.status_code}): "
                f"{_clean_error(response.text)}"
            )
        file_url = (response.json().get("file_url") or "").strip()
        if not file_url:
            raise CinAIError("CinAI upload returned no file_url")
        return file_url

    def edit_image(
        self,
        image_path: str,
        prompt: str,
        output_path: str,
        model: str = "gpt-image-2-img2img",
        aspect_ratio: Optional[str] = None,
        quality: Optional[str] = None,
    ) -> str:
        image_url = self.upload_image(image_path)
        aspect_ratio = aspect_ratio or getattr(config, "CINAI_ASPECT_RATIO", "16:9")
        quality = (quality or getattr(config, "CINAI_QUALITY", "1K")).upper()
        body = {
            "prompt": prompt,
            "payload": {
                "workflow_context": None,
                "surface": "studio-image",
                "chat_history": [],
                "mode_hint": "image",
                "model_preferences": {"image": model},
                "aspect_ratio": aspect_ratio,
                "image_count": 1,
                "settings": {"resolution": quality},
                "images": [image_url],
                "context_envelope": {
                    "v": 1,
                    "items": [{
                        "idx": 0,
                        "kind": "image",
                        "url": image_url,
                        "origin": "composer_upload",
                        "role": None,
                    }],
                    "directives": [
                        {
                            "key": "aspect_ratio",
                            "value": aspect_ratio,
                            "origin": "ui_control",
                            "turn": 1,
                        },
                        {
                            "key": "image_count",
                            "value": 1,
                            "origin": "ui_control",
                            "turn": 1,
                        },
                        {
                            "key": "model_id",
                            "value": model,
                            "origin": "ui_control",
                            "turn": 1,
                        },
                    ],
                    "prompt": prompt,
                },
                "client_request_id": str(uuid.uuid4()),
            },
        }
        try:
            response = requests.post(
                f"{self.base_url}/api/agent/dispatch/stream",
                headers=self._headers("text/event-stream"),
                json=body,
                stream=True,
                timeout=(30, self.timeout),
            )
        except requests.RequestException as exc:
            raise CinAIRetryableError(
                f"CinAI edit failed: {_clean_error(str(exc))}"
            ) from exc
        if response.status_code in (401, 403):
            raise CinAIAuthError("CinAI access token was rejected")
        if not response.ok:
            raise CinAIError(
                f"CinAI edit failed ({response.status_code}): "
                f"{_clean_error(response.text)}"
            )
        try:
            result = self._parse_sse(response)
        finally:
            response.close()
        target = Path(output_path)
        self.download_image(str(result["output_url"]), target)
        return str(target)


def _load_prompts(project_path: Path, clip_ids: Optional[Iterable[int]]) -> Dict[int, str]:
    prompts_file = find_prompts_file(str(project_path))
    if not prompts_file:
        raise FileNotFoundError(f"Prompts file not found in {project_path}")
    prompts = extract_all_prompts(prompts_file)
    if not prompts:
        raise ValueError(f"No prompts found in {prompts_file}")
    if clip_ids is not None:
        wanted = {int(value) for value in clip_ids}
        prompts = {cid: text for cid, text in prompts.items() if cid in wanted}
    montage_path = project_path / "montage_plan.json"
    if montage_path.exists():
        try:
            montage = json.loads(montage_path.read_text(encoding="utf-8"))
            real_photo_ids = {
                int(clip["id"])
                for clip in montage.get("clips", [])
                if str(clip.get("source") or "").startswith("real_photo")
            }
        except (OSError, ValueError, TypeError, KeyError) as exc:
            logging.warning("CinAI could not read Real Photo markers: %s", exc)
        else:
            skipped_ids = sorted(real_photo_ids.intersection(prompts))
            if skipped_ids:
                prompts = {
                    clip_id: prompt
                    for clip_id, prompt in prompts.items()
                    if clip_id not in real_photo_ids
                }
                logging.info(
                    "CinAI skipping %d Real Photo clip(s): %s",
                    len(skipped_ids),
                    ", ".join(f"{clip_id:03d}" for clip_id in skipped_ids),
                )
    return prompts


def generate_all_images(
    project_dir: str,
    max_parallel: Optional[int] = None,
    clip_ids: Optional[List[int]] = None,
    model: Optional[str] = None,
    aspect_ratio: Optional[str] = None,
    quality: Optional[str] = None,
    silent: bool = False,
    **_: Any,
) -> Dict[str, Any]:
    project_path = Path(project_dir)
    output_dir = project_path / "generated"
    output_dir.mkdir(parents=True, exist_ok=True)
    prompts = _load_prompts(project_path, clip_ids)
    skipped: List[int] = []
    pending: Dict[int, str] = {}
    for clip_id, prompt in prompts.items():
        existing = next(
            (output_dir / f"{clip_id:03d}{ext}" for ext in (".png", ".jpg", ".jpeg", ".webp")
             if (output_dir / f"{clip_id:03d}{ext}").is_file()
             and (output_dir / f"{clip_id:03d}{ext}").stat().st_size > 0),
            None,
        )
        if existing:
            skipped.append(clip_id)
        else:
            pending[clip_id] = prompt

    if not pending:
        return {"generated": len(skipped), "failed": 0, "skipped": len(skipped), "results": []}

    client = CinAIClient()
    workers = _safe_parallel(max_parallel)
    retries = max(0, int(getattr(config, "CINAI_MAX_RETRIES", 3)))
    results: List[Dict[str, Any]] = []
    failed: List[int] = []

    def generate_one(clip_id: int, prompt: str) -> Dict[str, Any]:
        last_error: Optional[Exception] = None
        for attempt in range(retries + 1):
            try:
                result = client.generate_image(
                    prompt, model=model, aspect_ratio=aspect_ratio, quality=quality)
                path = output_dir / f"{clip_id:03d}.png"
                client.download_image(str(result["output_url"]), path)
                return {"id": clip_id, "file": str(path), "url": result["output_url"],
                        "model": result.get("model_slug", model)}
            except (CinAIRetryableError, requests.RequestException) as exc:
                last_error = exc
                if attempt >= retries:
                    break
                time.sleep(min(30, 2 ** attempt))
            except Exception as exc:
                last_error = exc
                break
        raise CinAIError(f"clip #{clip_id} failed: {_clean_error(str(last_error))}")

    with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="cinai") as executor:
        futures = {executor.submit(generate_one, cid, prompt): cid for cid, prompt in pending.items()}
        for future in as_completed(futures):
            clip_id = futures[future]
            try:
                result = future.result()
                results.append(result)
                print(f"  [CinAI] #{clip_id}: OK", flush=True)
            except Exception as exc:
                failed.append(clip_id)
                print(f"  [CinAI] #{clip_id}: FAILED - {_clean_error(str(exc))}", flush=True)
                logging.warning("CinAI clip %s failed: %s", clip_id, exc)

    return {
        "generated": len(results) + len(skipped),
        "failed": len(failed),
        "skipped": len(skipped),
        "results": sorted(results, key=lambda item: item["id"]),
        "failed_ids": sorted(failed),
    }
