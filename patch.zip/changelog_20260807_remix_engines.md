# Remix engines and fallback switch

## 2026-08-07

- Added selectable fallback remix engines: `KieAI`, `Grok`, `Banana Flower`, and `GPT Image`.
- Added `Off`, which prevents fallback stages from invoking image remix and lets them continue to static fallback.
- Unified the main GUI radio buttons and Settings `REMIX_ENGINE` selector so an old env value cannot silently replace a new UI choice.
- Banana Flower uses FastGen V6 `flower_image_edit`.
- GPT Image uses FastGen V6 `openai_image_generate` with the failed image as an input.
- Existing Grok/KieAI fallback chains remain unchanged.
