#!/bin/bash
# START_YT_PACK.COMMAND - YouTube Packer (subtitles, description, covers)
# Run: double-click this file in Finder

PROJECT_NAME="{project_name}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

chmod +x *.command 2>/dev/null

if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e 'tell app "Terminal" to do script "cd '\''$SCRIPT_DIR'\'' && exec '\''$0'\''"'
    exit 0
fi

clear

echo ""
echo "================================================================================"
echo "YT PACKER: {project_name}"
echo "================================================================================"
echo ""

if [ ! -f "transcription.json" ]; then
    echo "[ERROR] transcription.json not found in project folder!"
    echo "   YT Packer requires at least transcription.json"
    echo "Press Enter to exit..." && read
    exit 1
fi

echo "   Project:  $PROJECT_NAME"
echo "   Folder:   $SCRIPT_DIR"
echo ""

cd "$ROOT_DIR/agent"
python3 agent.py yt-pack --project "$PROJECT_NAME"
RESULT=$?

if [ $RESULT -ne 0 ]; then
    echo ""
    echo "[ERROR] YT Packer failed!"
    echo "Press Enter to exit..." && read
    exit 1
fi

echo ""
echo "[OK] YT Packer done! Check yt_pack/ folder."
echo "Press Enter to exit..." && read
exit 0
