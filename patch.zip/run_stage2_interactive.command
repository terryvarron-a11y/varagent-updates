#!/bin/bash
# RUN_STAGE2_INTERACTIVE.COMMAND - Interactive video concat (macOS)
# Run: double-click this file in Finder
#
# Usage:
#   ./run_stage2_interactive.command [fast|1080p]

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Auto-set execute permissions
chmod +x *.command 2>/dev/null

echo ""
echo "================================================================================"
echo "INTERACTIVE VIDEO CONCAT FOR ALL PROJECTS"
echo "================================================================================"
echo ""

# Mode from argument
MODE="${1:-fast}"

if [ "$MODE" = "fast" ]; then
    echo "   Mode: FAST CONCAT (no re-encoding)"
    SCRIPT_FILE="process_fast_interactive.sh"
elif [ "$MODE" = "1080p" ]; then
    echo "   Mode: 1080p CONCAT (with re-encoding)"
    SCRIPT_FILE="process_1080p_interactive.sh"
else
    echo ""
    echo " [ERROR] Invalid parameter!"
    echo "   Usage: ./run_stage2_interactive.command [fast|1080p]"
    echo "   fast  - fast concat (default)"
    echo "   1080p - concat with re-encoding"
    echo ""
    exit 1
fi

echo ""

# Check projects folder
if [ ! -d "projects" ]; then
    echo " [ERROR] projects/ folder not found!"
    exit 1
fi

cd "$SCRIPT_DIR/projects"

PROJECT_COUNT=$(find . -maxdepth 1 -mindepth 1 -type d | wc -l | tr -d ' ')

if [ "$PROJECT_COUNT" -eq 0 ]; then
    echo ""
    echo " [ERROR] No projects found in projects/ folder!"
    echo ""
    exit 1
fi

echo "   Projects found: $PROJECT_COUNT"
echo ""

SUCCESS_COUNT=0
ERROR_COUNT=0

for PROJECT_DIR in */; do
    [ -d "$PROJECT_DIR" ] || continue
    PROJECT="${PROJECT_DIR%/}"

    echo ""
    echo "================================================================================"
    echo "PROJECT: $PROJECT"
    echo "================================================================================"
    echo ""

    # Check montage_plan.json
    if [ ! -f "$PROJECT/montage_plan.json" ]; then
        echo "   [ERROR] montage_plan.json not found!"
        echo "          Run run_stage1_simple.command first"
        ERROR_COUNT=$((ERROR_COUNT+1))
        continue
    fi
    echo "   montage_plan.json [OK]"

    # Check audio
    AUDIO_FOUND=0
    for EXT in wav mp3 flac m4a aac; do
        if compgen -G "$PROJECT/*.$EXT" > /dev/null 2>&1; then
            AUDIO_FOUND=1
            break
        fi
    done
    if [ "$AUDIO_FOUND" -eq 0 ]; then
        echo "   [ERROR] Audio file not found!"
        ERROR_COUNT=$((ERROR_COUNT+1))
        continue
    fi
    echo "   Audio file [OK]"

    # Check video fragments
    HAS_VIDEO=0
    for VFILE in "$PROJECT"/*.mp4; do
        [ -f "$VFILE" ] || continue
        VNAME=$(basename "$VFILE")
        if [ "$VNAME" != "result.mp4" ]; then
            HAS_VIDEO=1
            break
        fi
    done

    if [ "$HAS_VIDEO" -eq 0 ]; then
        echo "   [ERROR] Video fragments not found!"
        echo "          Generate video in Veo3 and download to project folder."
        ERROR_COUNT=$((ERROR_COUNT+1))
        continue
    fi
    echo "   Video fragments [OK]"
    echo ""
    echo "   Starting concat..."
    echo ""

    cd "$PROJECT"
    if [ -f "$SCRIPT_FILE" ]; then
        bash "$SCRIPT_FILE"
    elif [ -f "process_fast.sh" ]; then
        bash "process_fast.sh"
    else
        python3 video_concat.py montage_plan.json -o "${PROJECT}.mp4"
    fi
    EXIT_CODE=$?
    cd ..

    if [ $EXIT_CODE -ne 0 ]; then
        echo ""
        echo "   [ERROR] Concat failed for $PROJECT!"
        ERROR_COUNT=$((ERROR_COUNT+1))
    else
        echo ""
        echo "   [OK] $PROJECT completed successfully!"
        SUCCESS_COUNT=$((SUCCESS_COUNT+1))
    fi
done

# Summary
echo ""
echo "================================================================================"
echo "SUMMARY"
echo "================================================================================"
echo ""
echo "   Total projects: $PROJECT_COUNT"
echo "   [OK]    Success: $SUCCESS_COUNT"
echo "   [ERROR] Errors:  $ERROR_COUNT"
echo ""

if [ "$ERROR_COUNT" -gt 0 ]; then
    echo "   [WARN] Some projects finished with errors!"
else
    echo "   [OK] All projects processed successfully!"
    echo ""
    echo "   RESULTS:"
    echo "   - result.mp4 in each project folder"
    echo "   - VEO_AUDIO.wav in each project folder"
    echo "   - Veo3 fragments in FLOW_veo3_fragments/"
fi
echo ""
echo "================================================================================"
echo ""
