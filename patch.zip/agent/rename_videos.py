#!/usr/bin/env python3
"""
Переименование видеофрагментов и изображений в формат N.mp4 / N.png

Извлекает номер из имени файла и переименовывает в этот номер.

Поддерживаемые форматы входных файлов:
- *.mp4, *.mov, *.png, *.jpg, *.jpeg, *.webp
- Примеры:
  - 087-veo-33-meta-...mp4  → 87.mp4
  - shot0027_Golden...mp4   → 27.mp4
  - banana_0006.png         → 6.png
  - myprefix042.jpg         → 42.jpg
  - 001.png                 → пропускается (уже готово)

Важно:
- Номер извлекается из начала имени или после произвольного текстового префикса
- Файлы без номера пропускаются
- Уже переименованные файлы (1.mp4, 2.png, ...) пропускаются
"""
import argparse
import re
import sys
import os
import json
from datetime import datetime
from pathlib import Path
from typing import List, Tuple, Dict

# Установка UTF-8 кодировки для Windows
if sys.platform == 'win32':
    os.system('chcp 65001 >nul')
    # Перекодировка stdout для поддержки UTF-8
    sys.stdout.reconfigure(encoding='utf-8')


SKIP_NAMES = {'result.mp4', 'result_original_audio.wav'}
MEDIA_EXTS = ['*.mp4', '*.mov', '*.png', '*.jpg', '*.jpeg', '*.webp']
ALREADY_RENAMED_RE = re.compile(r'^\d+\.(mp4|mov|png|jpg|jpeg|webp)$', re.IGNORECASE)
DEFAULT_ZERO_PAD = 3  # 3-значный формат: 001, 012, 134 — совместим с video_concat и subtitle генераторами


def find_video_files(directory: Path = Path('.')) -> List[Path]:
    """
    Найти все медиафайлы в директории (видео и изображения).
    """
    media_files = []

    for ext in MEDIA_EXTS:
        for file_path in directory.glob(ext):
            if file_path.name in SKIP_NAMES:
                continue
            # ALREADY_RENAMED_RE больше не исключаем: файлы вида `1.mp4` нужно
            # переименовать в `001.mp4` если zero_pad изменился. Проверка old==new
            # делается в rename loop — если имя уже правильное, оно просто пропустится.
            media_files.append(file_path)

    media_files.sort(key=lambda x: extract_number_from_filename(x))
    return media_files


def extract_number_from_filename(file_path: Path) -> int:
    """
    Извлечь номер из НАЧАЛА имени файла

    Примеры:
        087-veo-33-meta-... → 87
        001-veo-1-meta-... → 1
        123-foo-bar.mp4 → 123
        shot0027_Golden_Age... → 27
        foo-bar.mp4 → 0 (нет номера)

    Поддерживаемые форматы:
        - ^(\\d+)           — цифры в начале (087-veo-... → 87)
        - ^shot(\\d+)       — префикс shot (shot0027_... → 27)
        - ^scene(\\d+)      — префикс scene (scene0042_... → 42)
        - ^clip(\\d+)       — префикс clip (clip0015_... → 15)
        - ^frag(\\d+)       — префикс frag (frag0008_... → 8)

    Args:
        file_path: Путь к файлу

    Returns:
        Номер из начала файла или 0
    """
    filename = file_path.name
    
    # Сначала — цифры в самом начале
    m = re.match(r'^(\d+)', filename)
    if m:
        return int(m.group(1))

    # Затем — любой текстовый префикс (буквы, цифры, _ ) перед блоком цифр
    # banana_0006.png → 6,  shot0027_foo.mp4 → 27,  myprefix042.jpg → 42
    m = re.match(r'^[a-zA-Z][a-zA-Z0-9_]*?(\d+)', filename, re.IGNORECASE)
    if m:
        return int(m.group(1))

    return 0


LOG_FILE = 'rename_log.json'


def rename_videos(
    directory: Path = Path('.'),
    dry_run: bool = False,
    verbose: bool = True,
    zero_pad: int = DEFAULT_ZERO_PAD,
) -> Tuple[int, int, List[str]]:
    """
    Переименовать видеофайлы Veo3

    Args:
        directory: Директория с файлами
        dry_run: Режим предпросмотра (без переименования)
        verbose: Подробный вывод

    Returns:
        Кортеж (успешно, ошибок, список предупреждений)
    """
    warnings = []
    success_count = 0
    error_count = 0
    log_entries = []

    # Найти все видеофайлы
    video_files = find_video_files(directory)

    if not video_files:
        if verbose:
            print("ℹ️  Файлы Veo3 не найдены")
        return 0, 0, warnings

    if verbose:
        print(f"📹 Найдено файлов: {len(video_files)}")
        print("="*60)

    # Переименовываем с сохранением номера из начала имени
    for old_path in video_files:
        # Извлекаем номер из начала имени
        new_number = extract_number_from_filename(old_path)

        # Определяем расширение. zero_pad=3 → 001.mp4, 012.png, 134.jpg
        if zero_pad and zero_pad > 0:
            new_name = f"{new_number:0{zero_pad}d}{old_path.suffix}"
        else:
            new_name = f"{new_number}{old_path.suffix}"
        new_path = directory / new_name

        # Проверка на конфликт имён
        if old_path == new_path:
            if verbose:
                print(f"   ✓ {old_path.name} (уже переименован)")
            success_count += 1
            continue

        if new_path.exists() and new_path != old_path:
            msg = f"⚠️  Конфликт: {new_name} уже существует, пропускаю {old_path.name}"
            warnings.append(msg)
            if verbose:
                print(msg)
            error_count += 1
            continue

        if dry_run:
            if verbose:
                print(f"   → {old_path.name} → {new_name}")
        else:
            try:
                old_path.rename(new_path)
                log_entries.append({'from': old_path.name, 'to': new_name})
                if verbose:
                    print(f"   ✓ {old_path.name} → {new_name}")
                success_count += 1
            except Exception as e:
                msg = f"❌ Ошибка переименования {old_path.name}: {e}"
                warnings.append(msg)
                if verbose:
                    print(msg)
                error_count += 1

    # Сохраняем лог для возможности отката
    if not dry_run and log_entries:
        log_path = directory / LOG_FILE
        log_data = {
            'timestamp': datetime.now().isoformat(),
            'directory': str(directory),
            'renames': log_entries,
        }
        try:
            with open(log_path, 'w', encoding='utf-8') as f:
                json.dump(log_data, f, ensure_ascii=False, indent=2)
            if verbose:
                print(f"\n   💾 Лог сохранён: {log_path}  (откат: undo_rename.bat)")
        except Exception as e:
            if verbose:
                print(f"\n   ⚠️  Не удалось сохранить лог: {e}")

    return success_count, error_count, warnings


def undo_renames(directory: Path = Path('.'), verbose: bool = True) -> int:
    """
    Откатить переименование по сохранённому логу.

    Returns:
        Код выхода (0 = OK, 1 = ошибка)
    """
    log_path = directory / LOG_FILE
    if not log_path.exists():
        print(f"❌ Лог не найден: {log_path}")
        print("   Откат невозможен — rename_log.json отсутствует")
        return 1

    with open(log_path, 'r', encoding='utf-8') as f:
        log_data = json.load(f)

    renames = log_data.get('renames', [])
    if not renames:
        print("ℹ️  Лог пуст, нечего откатывать")
        return 0

    print(f"🔄 Откат {len(renames)} переименований...")
    print("="*60)

    errors = 0
    for entry in reversed(renames):
        old_name = entry['to']    # текущее имя (после rename)
        new_name = entry['from']  # оригинальное имя (до rename)
        old_path = directory / old_name
        new_path = directory / new_name

        if not old_path.exists():
            print(f"   ⚠️  Файл не найден (пропуск): {old_name}")
            continue
        if new_path.exists():
            print(f"   ⚠️  Конфликт: {new_name} уже существует, пропуск")
            errors += 1
            continue

        try:
            old_path.rename(new_path)
            if verbose:
                print(f"   ✓ {old_name} → {new_name}")
        except Exception as e:
            print(f"   ❌ {old_name}: {e}")
            errors += 1

    if errors == 0:
        log_path.unlink()
        print(f"\n✅ Откат выполнен. Лог удалён.")
    else:
        print(f"\n⚠️  Откат с ошибками ({errors}). Лог сохранён.")

    return 0 if errors == 0 else 1


def main():
    parser = argparse.ArgumentParser(
        description='Переименование видеофрагментов Veo3 в формат 1.mp4, 2.mp4, ...',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Примеры использования:
  python rename_videos.py              # Переименовать все файлы
  python rename_videos.py --dry-run    # Предпросмотр без переименования
  python rename_videos.py -v           # Подробный вывод
  python rename_videos.py --dir path   # Указать директорию
        """
    )
    
    parser.add_argument(
        '--dir',
        type=Path,
        default=Path('.'),
        help='Директория с видеофайлами (по умолчанию: текущая)'
    )
    
    parser.add_argument(
        '--undo',
        action='store_true',
        help='Откатить переименование по rename_log.json'
    )

    parser.add_argument(
        '--dry-run',
        action='store_true',
        help='Режим предпросмотра (без переименования)'
    )
    
    parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        default=True,
        help='Подробный вывод (по умолчанию: включён)'
    )
    
    parser.add_argument(
        '-q', '--quiet',
        action='store_true',
        help='Тихий режим (минимум вывода)'
    )

    parser.add_argument(
        '--zero-pad',
        type=int,
        default=DEFAULT_ZERO_PAD,
        help=f'Длина числового имени с лидирующими нулями (по умолчанию: {DEFAULT_ZERO_PAD} → 001.mp4, 012.png). 0 = без паддинга (1.mp4).'
    )

    args = parser.parse_args()
    
    # Проверка директории
    if not args.dir.exists():
        print(f"❌ Директория не найдена: {args.dir}")
        sys.exit(1)

    if not args.dir.is_dir():
        print(f"❌ Это не директория: {args.dir}")
        sys.exit(1)

    verbose = args.verbose and not args.quiet

    # Режим отката
    if args.undo:
        print("\n" + "="*60)
        print("↩️  ОТКАТ ПЕРЕИМЕНОВАНИЯ VEO3")
        print("="*60 + "\n")
        rc = undo_renames(directory=args.dir, verbose=verbose)
        sys.exit(rc)

    # Запуск переименования
    if verbose:
        print("\n" + "="*60)
        if args.dry_run:
            print("🔍 ПРЕДПРОСМОТР ПЕРЕИМЕНОВАНИЯ")
        else:
            print("✏️  ПЕРЕИМЕНОВАНИЕ ФАЙЛОВ VEO3")
        print("="*60 + "\n")

    success, errors, warnings = rename_videos(
        directory=args.dir,
        dry_run=args.dry_run,
        verbose=verbose,
        zero_pad=args.zero_pad,
    )

    # Итоги
    if verbose:
        print("\n" + "="*60)
        if args.dry_run:
            print("ПРЕДПРОСМОТР ЗАВЕРШЕН")
        else:
            print("ПЕРЕИМЕНОВАНИЕ ЗАВЕРШЕНО")
        print("="*60)
        print(f"   ✅ Успешно: {success}")
        if errors > 0:
            print(f"   ❌ Ошибки: {errors}")
        if warnings:
            print(f"   ⚠️  Предупреждения: {len(warnings)}")
        print()

    # Выход с кодом ошибки если были проблемы
    if errors > 0 and not args.dry_run:
        sys.exit(1)

    sys.exit(0)


if __name__ == '__main__':
    main()
