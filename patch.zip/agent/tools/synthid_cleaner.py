#!/usr/bin/env python3
"""
synthid_cleaner.py — Google SynthID watermark removal wrapper.

Wraps: https://github.com/aloshdenny/reverse-SynthID
Source: src/extraction/synthid_bypass.py

TWO USAGE MODES:

1. CLI — Control Panel standalone (processes entire folder):
       python synthid_cleaner.py <images_dir> [--strength moderate] [--version v1]
   Prints PROGRESS:N/TOTAL on each processed image.

2. Importable — inflight hook from imggen.py / fastgen.py worker threads:
       from tools.synthid_cleaner import clean_single_image
       ok = clean_single_image(path, strength='moderate', version='v1')
   Synchronous, runs in calling thread (one per image concurrently).
   Returns True on success, False on failure (never raises).

Logging:
    CLI mode: prints [SynthID] ... + PROGRESS:N/TOTAL
    Function mode: prints [SynthID] <filename>: OK/FAILED with flush=True
    Both go to stdout of the calling process (piped to varagent.py log).
"""

import sys
import os
import argparse
import shutil
import subprocess
import urllib.request
from pathlib import Path

# ── Tool download config ──────────────────────────────────────────────────────
_BASE_URL        = "https://raw.githubusercontent.com/aloshdenny/reverse-SynthID/main/src/extraction/"
_ARTIFACTS_URL   = "https://raw.githubusercontent.com/aloshdenny/reverse-SynthID/main/artifacts/"
TOOL_LOCAL       = Path(__file__).parent / "_synthid_bypass.py"
CODEBOOK_V3      = Path(__file__).parent / "synthid_codebook_v3.npz"
CODEBOOK_V3_EXP  = Path(__file__).parent / "synthid_codebook_v3_expanded.npz"

# local name → (base_url, remote filename)
_REQUIRED_FILES = {
    "_synthid_bypass.py":              (_BASE_URL,      "synthid_bypass.py"),
    "robust_extractor.py":             (_BASE_URL,      "robust_extractor.py"),
    "synthid_codebook_v3.npz":         (_ARTIFACTS_URL, "spectral_codebook_v3.npz"),
    "synthid_codebook_v3_expanded.npz":(_ARTIFACTS_URL, "spectral_codebook_v3_expanded.npz"),
}

# pip package name -> import name
DEPS_MAP = {
    "numpy":          "numpy",
    "scipy":          "scipy",
    "opencv-python":  "cv2",
    "PyWavelets":     "pywt",
    "scikit-learn":   "sklearn",
    "Pillow":         "PIL",
    "tqdm":           "tqdm",
}


# ── Helpers ───────────────────────────────────────────────────────────────────

def _log(msg: str) -> None:
    print(f"[SynthID] {msg}", flush=True)


def _ensure_deps() -> None:
    missing = []
    for pkg, import_name in DEPS_MAP.items():
        try:
            __import__(import_name)
        except ImportError:
            missing.append(pkg)
    if not missing:
        return
    _log(f"Installing missing deps: {' '.join(missing)}")
    subprocess.run(
        [sys.executable, "-m", "pip", "install", "--quiet"] + missing,
        check=False,
    )
    for pkg, import_name in DEPS_MAP.items():
        if pkg in missing:
            try:
                __import__(import_name)
            except ImportError:
                _log(f"ERROR: Could not install {pkg}. Run: pip install {pkg}")
                # Don't sys.exit here — called from worker threads; just return
                return


def _ensure_tool() -> bool:
    """Download all required repo files. Returns True if all available."""
    tools_dir = Path(__file__).parent
    missing = {
        local: (base_url, remote)
        for local, (base_url, remote) in _REQUIRED_FILES.items()
        if not (tools_dir / local).exists()
    }
    if not missing:
        return True
    _log(f"Downloading {len(missing)} file(s) from GitHub...")
    for local_name, (base_url, remote_name) in missing.items():
        url = base_url + remote_name
        dest = tools_dir / local_name
        _log(f"  -> {remote_name}")
        try:
            urllib.request.urlretrieve(url, str(dest))
            _log(f"     OK: {local_name}")
        except Exception as e:
            _log(f"ERROR: Could not download {remote_name}: {e}")
            return False
    return True


# ── Core single-image function (importable) ───────────────────────────────────

def clean_single_image(
    file_path: str,
    strength: str = "moderate",
    version: str = "v1",
) -> bool:
    """
    Remove SynthID watermark from a single image file in-place.

    Called from imggen.py / fastgen.py worker threads immediately after
    each image is saved to generated/. Synchronous — blocks only the
    calling thread. Safe to call concurrently from multiple threads.

    Args:
        file_path: Absolute path to the image file (.jpg/.png)
        strength:  'gentle' | 'moderate' | 'aggressive' | 'extreme'
        version:   'v1' | 'v2' | 'v3'

    Returns:
        True on success (original backed up, file replaced with clean version)
        False on any failure (original preserved, no modification)
    """
    p = Path(file_path)
    if not p.exists():
        _log(f"WARNING: file not found: {p.name}")
        return False

    if not _ensure_tool():
        return False

    # OpenCV (used by _synthid_bypass.py) cannot handle non-ASCII paths on Windows.
    # Copy input/output to a pure-ASCII temp dir, process there, copy result back.
    import tempfile, uuid
    _use_tempdir = any(ord(c) > 127 for c in str(p))
    if _use_tempdir:
        _tmp_dir = Path(tempfile.gettempdir()) / f"synthid_{uuid.uuid4().hex[:8]}"
        _tmp_dir.mkdir(exist_ok=True)
        _tmp_in  = _tmp_dir / p.name
        _tmp_out_path = _tmp_dir / (p.stem + "_out" + p.suffix)
        shutil.copy2(str(p), str(_tmp_in))
        work_in  = _tmp_in
        work_out = _tmp_out_path
    else:
        work_in  = p
        work_out = p.with_name(p.stem + "_synthid_tmp" + p.suffix)
        _tmp_dir = None

    orig_bak = p.with_name(p.stem + "_synthid_orig" + p.suffix)

    try:
        cmd = [
            sys.executable, str(TOOL_LOCAL),
            "bypass", str(work_in), str(work_out),
            "--version", version,
            "--strength", strength,
            "--no-verify",
        ]
        # v3 requires a spectral codebook — use expanded if available, else standard
        if version == "v3":
            codebook = CODEBOOK_V3_EXP if CODEBOOK_V3_EXP.exists() else CODEBOOK_V3
            cmd += ["--codebook", str(codebook)]

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )

        if result.returncode != 0 or not work_out.exists():
            err = (result.stderr or result.stdout or "").strip()
            if err:
                _log(f"WARNING: {p.name}: {err[:120]}")
            return False

        # Back up original, replace with cleaned version
        shutil.copy2(str(p), str(orig_bak))
        shutil.copy2(str(work_out), str(p))
        return True

    except Exception as e:
        _log(f"WARNING: exception processing {p.name}: {e}")
        return False

    finally:
        # Clean up temp directory if we used one
        if _tmp_dir and _tmp_dir.exists():
            try:
                shutil.rmtree(str(_tmp_dir), ignore_errors=True)
            except Exception:
                pass


# ── CLI mode (Control Panel standalone) ──────────────────────────────────────

def main() -> None:
    # Quick install-only mode (no folder needed)
    if '--install' in sys.argv:
        _ensure_deps()
        _ensure_tool()
        _log("[OK] SynthID remover installed successfully")
        sys.exit(0)

    parser = argparse.ArgumentParser(
        description="Remove SynthID watermarks from all images in a folder"
    )
    parser.add_argument("images_dir", help="Folder containing .jpg/.png images")
    parser.add_argument(
        "--strength",
        choices=["gentle", "moderate", "aggressive", "extreme"],
        default="moderate",
        help="Removal strength (default: moderate)",
    )
    parser.add_argument(
        "--version",
        choices=["v1", "v2", "v3"],
        default="v1",
        help="Bypass algorithm version (default: v1, no codebook needed)",
    )
    args = parser.parse_args()

    images_dir = Path(args.images_dir)
    if not images_dir.is_dir():
        print(f"[SynthID] ERROR: Not a directory: {images_dir}", flush=True)
        sys.exit(1)

    _ensure_deps()

    # Collect images (skip backups/temps from previous runs)
    images = sorted(
        f for f in (list(images_dir.glob("*.jpg")) + list(images_dir.glob("*.png")))
        if "_synthid_orig" not in f.name and "_synthid_tmp" not in f.name
    )

    if not images:
        _log("No images to process.")
        print("[OK] SynthID: nothing to clean.", flush=True)
        sys.exit(0)

    total = len(images)
    _log(f"Processing {total} images  strength={args.strength}  version={args.version}")
    print(f"PROGRESS:0/{total}", flush=True)

    ok_count = 0
    fail_count = 0

    for i, img in enumerate(images, 1):
        success = clean_single_image(str(img), strength=args.strength, version=args.version)
        status = "OK" if success else "FAILED"
        _log(f"{img.name}: {status}")
        if success:
            ok_count += 1
        else:
            fail_count += 1
        print(f"PROGRESS:{i}/{total}", flush=True)

    _log(f"Done: {ok_count} cleaned, {fail_count} failed")
    print(f"[OK] SynthID removal complete: {ok_count}/{total} images processed", flush=True)

    if fail_count > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
