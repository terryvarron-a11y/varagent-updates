"""
Конфигурация агента Video Production Agent
"""
import os
import sys
from pathlib import Path
from dotenv import load_dotenv

# Загрузка переменных окружения из .env
load_dotenv(Path(__file__).parent / '.env')


def _model(key: str, default: str = '') -> str:
    """Читает имя модели из env, обрезая инлайн-комментарии (# ...)."""
    return os.getenv(key, default).split('#')[0].strip()

# ============================================================================
# API КЛЮЧИ
# ============================================================================

# AssemblyAI API (транскрипция)
ASSEMBLYAI_API_KEY = os.getenv('ASSEMBLYAI_API_KEY', '')

# Gemini API (режиссура)
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY', '')

# ============================================================================
# ПУТИ К ФАЙЛАМ
# ============================================================================

# Базовая директория проекта
BASE_DIR = Path(__file__).parent

# Директория с промптами
PROMPTS_DIR = BASE_DIR / 'prompts'

# Директория для временных файлов
TEMP_DIR = BASE_DIR / 'temp'

# Директория для логов
LOGS_DIR = BASE_DIR / 'logs'

# ============================================================================
# НАСТРОЙКИ ASSEMBLYAI
# ============================================================================

# Модели транскрипции (приоритетный список, через запятую)
# universal-3-pro — лучшее качество ($0.21/ч)
# universal-2     — быстрее и дешевле ($0.15/ч, -40%)
_speech_models_raw = os.getenv('ASSEMBLYAI_SPEECH_MODELS', 'universal-3-pro,universal-2')
ASSEMBLYAI_SPEECH_MODELS = [m.strip() for m in _speech_models_raw.split(',') if m.strip()]

# Язык транскрипции (по умолчанию, можно переопределить в CLI)
ASSEMBLYAI_LANGUAGE_CODE = os.getenv('ASSEMBLYAI_LANGUAGE_CODE', 'ru')

# Поддерживаемые языки
ASSEMBLYAI_SUPPORTED_LANGUAGES = [
    'en',  # English
    'ru',  # Russian
    'es',  # Spanish
    'fr',  # French
    'de',  # German
    'it',  # Italian
    'pt',  # Portuguese
    'nl',  # Dutch
    'pl',  # Polish
    'ja',  # Japanese
    'zh',  # Chinese
    'ko',  # Korean
    'hi',  # Hindi
    'ar',  # Arabic
]

# Режим сегментации транскрипции: 'sentences' или 'paragraphs'
# sentences  — каждое предложение отдельный блок (по умолчанию)
# paragraphs — группирует предложения в смысловые абзацы (меньше блоков, шире охват)
ASSEMBLYAI_SEGMENTATION_MODE = os.getenv('ASSEMBLYAI_SEGMENTATION_MODE', 'sentences')

# HTTP timeout for AssemblyAI SDK (seconds). Default 30s is too low for large files on slow connections.
ASSEMBLYAI_HTTP_TIMEOUT = float(os.getenv('ASSEMBLYAI_HTTP_TIMEOUT', '600'))

# ============================================================================
# НАСТРОЙКИ GEMINI
# ============================================================================

# Модель для режиссуры (по умолчанию)
GEMINI_MODEL = _model('GEMINI_MODEL', 'gemini-3.1-pro')

# Модель для rewrite промптов (при цензуре VEO). flash = бесплатно/быстро, pro = точнее
# Формат: 'gemini:model-name' или 'gpt:model-name'
REWRITE_MODEL = os.getenv('REWRITE_MODEL', 'gemini:gemini-2.5-flash')

# Thinking Level для Gemini 3.x Pro (уровень мышления)
# Значения: 'low', 'medium', 'high'
# Влияет на глубину анализа и количество токенов
GEMINI_THINKING_LEVEL = os.getenv('GEMINI_THINKING_LEVEL', 'medium')

# Двухпроходный режим: проход 1 = JSON план, проход 2 = промпты (для длинных проектов)
GEMINI_TWO_PASS = os.getenv('GEMINI_TWO_PASS', 'false').lower() in ('true', '1', 'yes')

# Прямое задание thinking budget в токенах (для Gemini 2.x)
# Если задан — переопределяет GEMINI_THINKING_LEVEL для 2.x моделей
# 0 = не задан, используется маппинг из GEMINI_THINKING_LEVEL
_budget_raw = os.getenv('GEMINI_THINKING_BUDGET', '0')
GEMINI_THINKING_BUDGET = int(_budget_raw) if _budget_raw.isdigit() else 0

# Thinking для второго прохода (промпты) в двухпроходном режиме
# Gemini 3.x: 'low', 'medium', 'high' (по умолчанию 'low')
GEMINI_THINKING_LEVEL_PASS2 = os.getenv('GEMINI_THINKING_LEVEL_PASS2', 'medium')
# Gemini 2.x: budget в токенах (0 = использовать дефолт: 8000 для Pro, 0 для Flash)
_budget_p2_raw = os.getenv('GEMINI_THINKING_BUDGET_PASS2', '0')
GEMINI_THINKING_BUDGET_PASS2 = int(_budget_p2_raw) if _budget_p2_raw.isdigit() else 0

# Генерация director_analysis.md (по умолчанию включена для отладки)
GENERATE_DIRECTOR_ANALYSIS = os.getenv('GENERATE_DIRECTOR_ANALYSIS', 'true').lower() in ('true', '1', 'yes')

# Максимальный размер чанка промптов в проходе 2.
# Если клипов больше — pass 2 разбивается на чанки по PROMPT_CHUNK_SIZE клипов.
# 0 = чанкование отключено (один запрос на все клипы).
_chunk_raw = os.getenv('PROMPT_CHUNK_SIZE', '150')
PROMPT_CHUNK_SIZE = int(_chunk_raw) if _chunk_raw.isdigit() else 150

# Чанкование Pass 1 (монтажный план) для длинных озвучек.
# THRESHOLD: если audioDuration > этого порога (сек), Pass 1 разбивается на чанки.
# 0 = всегда монолит (старый режим).
DIRECTOR_PASS1_CHUNK_THRESHOLD = int(os.getenv('DIRECTOR_PASS1_CHUNK_THRESHOLD', '2400'))
# Длина одного чанка Pass 1 (сек). 2400 сек = 40 мин, 1200 = 20 мин.
DIRECTOR_PASS1_CHUNK_DURATION  = int(os.getenv('DIRECTOR_PASS1_CHUNK_DURATION',  '1200'))

# Откат при авто-дополнении (rollback).
# Continuation loop отсекает последние N "уставших" промптов и просит их заново.
# 0 = откат отключён (дописываем строго с позиции обрыва).
_rollback_raw = os.getenv('CONT_ROLLBACK_SIZE', '20')
CONT_ROLLBACK_SIZE = int(_rollback_raw) if _rollback_raw.isdigit() else 20

# ============================================================================
# GPT / CODEX DIRECTOR (alternative to Gemini)
# ============================================================================

# Backend режиссуры: 'gemini' (default) или 'gpt' (Codex CLI)
DIRECTOR_BACKEND = os.getenv('DIRECTOR_BACKEND', 'gemini').strip().lower()

# Путь к Codex CLI exe (auto-detect per platform)
import shutil as _shutil
_codex_env = os.getenv('CODEX_EXE_PATH', '')
if _codex_env and os.path.exists(_codex_env):
    CODEX_EXE_PATH = _codex_env
elif sys.platform == 'win32':
    _codex_win = str(BASE_DIR.parent / 'Codex' / 'codex-x86_64-pc-windows-msvc.exe')
    CODEX_EXE_PATH = _codex_win if os.path.exists(_codex_win) else ''
else:
    # macOS / Linux: ищем в PATH (npm install -g @openai/codex)
    CODEX_EXE_PATH = _shutil.which('codex') or ''

# Модель GPT для режиссуры через Codex
GPT_MODEL = _model('GPT_MODEL', 'gpt-5.4')

# Таймаут на один exec вызов Codex (секунды)
GPT_DIRECTOR_TIMEOUT = int(os.getenv('GPT_DIRECTOR_TIMEOUT', '1200'))

# Sandbox mode: 'danger-full-access' или 'workspace-write'
GPT_SANDBOX_MODE = os.getenv('GPT_SANDBOX_MODE', 'danger-full-access')

# Количество клипов на один exec вызов pass 2 (0 = все за раз)
_gpt_chunk_raw = os.getenv('GPT_PASS2_CHUNK_SIZE', '100')
GPT_PASS2_CHUNK_SIZE = int(_gpt_chunk_raw) if _gpt_chunk_raw.isdigit() else 100

# VEO style guide для Codex adapt (дефолт = универсальный, можно заменить в GUI)
VEO_ADAPT_STYLE_GUIDE = os.getenv('VEO_ADAPT_STYLE_GUIDE',
    str(BASE_DIR.parent / 'prompts_other' / 'VEO_I2V_UNIVERSAL_STYLE_v1.md'))

# ============================================================================
# ТАРИФЫ GEMINI API (на 2026-03-29)
# ============================================================================
# Источник: https://ai.google.dev/pricing
#
# gemini-3-flash-preview:    $0.50 in / $3.00 out  — быстрая, дешёвая
# gemini-2.5-pro:            $1.25 in / $10.00 out (>200K: $2.50/$15.00)
# gemini-3.1-pro-preview:    $2.00 in / $12.00 out — флагман
#
# gemini-3-pro-preview: DEPRECATED 2026-03-09, shut down
# ============================================================================

GEMINI_PRICING = {
    'gemini-3-flash-preview': {
        'input': 0.50,
        'output': 3.00,
    },
    'gemini-2.5-flash': {
        'input': 0.075,
        'output': 0.30,
    },
    'gemini-2.5-pro': {
        'input': 1.25,
        'output': 10.00,
    },
    'gemini-3.1-pro-preview': {
        'input': 2.00,
        'output': 12.00,
    },
}

# ============================================================================
# НАСТРОЙКИ TTS (Text-to-Speech / Озвучка)
# ============================================================================

# Сервис озвучки: 'csv666' | 'mat3u'
TTS_SERVICE = os.getenv('TTS_SERVICE', 'mat3u')

# API ключи
TTS_API_KEY_CSV666 = os.getenv('TTS_API_KEY_CSV666', '')
TTS_API_KEY_MAT3U  = os.getenv('TTS_API_KEY_MAT3U', '')

# --- Настройки csv666 (voiceapi.csv666.ru) ---
TTS_CSV666_CHUNK_SIZE    = int(os.getenv('TTS_CSV666_CHUNK_SIZE', '1000'))
TTS_CSV666_OUTPUT_FORMAT = os.getenv('TTS_CSV666_OUTPUT_FORMAT', 'mp3')  # mp3 | zip

# --- Настройки mat3u (voicer.mat3u.com) ---
TTS_MAT3U_MODEL_ID             = os.getenv('TTS_MAT3U_MODEL_ID', 'eleven_multilingual_v2')
TTS_MAT3U_SPLIT_TYPE           = os.getenv('TTS_MAT3U_SPLIT_TYPE', 'smart')       # smart|sentences|paragraphs|max_length
TTS_MAT3U_MAX_CHUNK_LENGTH     = int(os.getenv('TTS_MAT3U_MAX_CHUNK_LENGTH', '1000'))  # 100-1000
TTS_MAT3U_SPLIT_OUTPUT         = os.getenv('TTS_MAT3U_SPLIT_OUTPUT', 'false').lower() in ('true', '1', 'yes')
TTS_MAT3U_AUTO_PAUSE_ENABLED   = os.getenv('TTS_MAT3U_AUTO_PAUSE_ENABLED', 'false').lower() in ('true', '1', 'yes')
TTS_MAT3U_AUTO_PAUSE_DURATION  = float(os.getenv('TTS_MAT3U_AUTO_PAUSE_DURATION', '0.5'))
TTS_MAT3U_AUTO_PAUSE_FREQUENCY = int(os.getenv('TTS_MAT3U_AUTO_PAUSE_FREQUENCY', '1'))

# ============================================================================
# НАСТРОЙКИ YT PACKER (YouTube-упаковщик)
# ============================================================================

# Языки (через запятую). Первый = исходный язык транскрипции
_yt_langs_raw = os.getenv('YT_PACK_LANGUAGES', 'ru,en')
YT_PACK_LANGUAGES = [lang.strip() for lang in _yt_langs_raw.split(',') if lang.strip()]

# Модель Gemini по умолчанию (используется как fallback для перевода и контента)
YT_PACK_MODEL = _model('YT_PACK_MODEL', 'gemini-2.5-flash')
# Модель для перевода субтитров (можно дешевле — flash/flash-lite)
YT_PACK_TRANSLATE_MODEL = _model('YT_PACK_TRANSLATE_MODEL') or YT_PACK_MODEL
# Модель для контента: заголовки, описание, теги, промпты обложек (можно мощнее — pro)
YT_PACK_CONTENT_MODEL = _model('YT_PACK_CONTENT_MODEL') or YT_PACK_MODEL

# Переключатели подэтапов
YT_PACK_SUBTITLES = os.getenv('YT_PACK_SUBTITLES', 'true').lower() in ('true', '1', 'yes')
YT_PACK_DESCRIPTION = os.getenv('YT_PACK_DESCRIPTION', 'true').lower() in ('true', '1', 'yes')
YT_PACK_COVERS = os.getenv('YT_PACK_COVERS', 'true').lower() in ('true', '1', 'yes')

# Настройки обложек
YT_PACK_COVER_PROVIDER = os.getenv('YT_PACK_COVER_PROVIDER', 'fastgen')  # fastgen | veononstop
YT_PACK_COVER_MODEL = _model('YT_PACK_COVER_MODEL', 'GEM_PIX_2')
YT_PACK_COVER_COUNT = int(os.getenv('YT_PACK_COVER_COUNT', '4'))

# ============================================================================
# НАСТРОЙКИ FASTGEN API (генерация изображений)
# ============================================================================

# API ключ FastGen (основной)
FASTGEN_API_KEY = os.getenv('FASTGEN_API_KEY', '')

# Резервный API ключ FastGen (используется когда основной исчерпал квоту/лицензию)
# Если не задан — fallback на основной ключ (чтобы auto-switch не падал)
FASTGEN_API_KEY_BACKUP = os.getenv('FASTGEN_API_KEY_BACKUP', '') or FASTGEN_API_KEY

# Второй API ключ FastGen (dual-key: параллельная работа двумя аккаунтами)
# Если FASTGEN_API_KEY_2 не задан — fallback на FASTGEN_API_KEY_BACKUP
FASTGEN_API_KEY_2 = os.getenv('FASTGEN_API_KEY_2', '') or os.getenv('FASTGEN_API_KEY_BACKUP', '')
FASTGEN_MAX_PARALLEL_2 = int(os.getenv('FASTGEN_MAX_PARALLEL_2',
                                        os.getenv('FASTGEN_MAX_PARALLEL', '25')))

# Базовые URL
FASTGEN_API_BASE = 'https://api.fast-gen.ai/api'
FASTGEN_STORAGE_URL = 'https://storage.fast-gen.ai'

# Движок/модель генерации изображений:
#   Flow API:  GEM_PIX_2 (Nano Pro, рекомендуется), GEM_PIX (Nano), IMAGEN_3_5, NARWHAL (Nano Banana 2)
#   Gemini:    GEMINI  (Gemini native, быстрый)
#   Grok:      GROK    (Grok, возвращает 4 варианта)
#   Whisk:     WHISK   (Whisk, категоризированные рефы subject/scene/style)
FASTGEN_MODEL = os.getenv('FASTGEN_MODEL', 'GEMINI')

# Соотношение сторон: portrait, landscape, square
FASTGEN_ASPECT_RATIO = os.getenv('FASTGEN_ASPECT_RATIO', 'landscape')

# Максимум параллельных генераций
FASTGEN_MAX_PARALLEL = int(os.getenv('FASTGEN_MAX_PARALLEL', '25'))

# Интервал поллинга статуса (секунды)
FASTGEN_POLL_INTERVAL = 8

# Таймаут ожидания одной генерации (секунды)
FASTGEN_POLL_TIMEOUT = 300

# Количество повторных попыток при ошибках
FASTGEN_MAX_RETRIES = 3

# Предполётная проверка рефов: тест до начала генерации (True = включена)
FASTGEN_PREFLIGHT_REFS = os.getenv('FASTGEN_PREFLIGHT_REFS', 'true').lower() in ('true', '1', 'yes')

# Автоматический Grok-ремикс заблокированных рефов и цензурированных i2v кадров
FASTGEN_GROK_REMIX = os.getenv('FASTGEN_GROK_REMIX', 'true').lower() in ('true', '1', 'yes')

# ============================================================================
# НАСТРОЙКИ KIE.AI (ремиксер рефов и i2v кадров)
# ============================================================================

# API ключ Kie.ai (https://kie.ai)
KIE_AI_API_KEY = os.getenv('KIE_AI_API_KEY', '')

# Kie.ai ремикс включён если задан ключ
KIE_AI_REMIX = bool(KIE_AI_API_KEY)

# Выбор ремиксера: 'kieai' или 'grok'
REMIX_ENGINE = os.getenv('REMIX_ENGINE', 'grok').lower()

# Хотя бы один ремиксер доступен (KieAI или Grok)
REMIX_AVAILABLE = KIE_AI_REMIX or FASTGEN_GROK_REMIX

# ============================================================================
# НАСТРОЙКИ VEONONSTOP API (видеогенерация + картинки)
# ============================================================================

# API ключ VeoNonStop (https://veononstop.org)
VEONONSTOP_API_KEY = os.getenv('VEONONSTOP_API_KEY', '')
# Второй API ключ (опционально): если задан — задачи распределяются round-robin
VEONONSTOP_API_KEY_2 = os.getenv('VEONONSTOP_API_KEY_2', '')
VEONONSTOP_MAX_PARALLEL_2 = int(os.getenv('VEONONSTOP_MAX_PARALLEL_2',
                                           os.getenv('VEONONSTOP_MAX_PARALLEL', '4')))
# Третий API ключ (опционально)
VEONONSTOP_API_KEY_3 = os.getenv('VEONONSTOP_API_KEY_3', '')
VEONONSTOP_MAX_PARALLEL_3 = int(os.getenv('VEONONSTOP_MAX_PARALLEL_3',
                                           os.getenv('VEONONSTOP_MAX_PARALLEL', '4')))
# Четвёртый API ключ (опционально)
VEONONSTOP_API_KEY_4 = os.getenv('VEONONSTOP_API_KEY_4', '')
VEONONSTOP_MAX_PARALLEL_4 = int(os.getenv('VEONONSTOP_MAX_PARALLEL_4',
                                           os.getenv('VEONONSTOP_MAX_PARALLEL', '4')))
# Названия планов для Key1-Key4 (показываются в GUI)
VEONONSTOP_KEY1_NAME = os.getenv('VEONONSTOP_KEY1_NAME', 'Key1')
VEONONSTOP_KEY2_NAME = os.getenv('VEONONSTOP_KEY2_NAME', 'Key2')
VEONONSTOP_KEY3_NAME = os.getenv('VEONONSTOP_KEY3_NAME', 'Key3')
VEONONSTOP_KEY4_NAME = os.getenv('VEONONSTOP_KEY4_NAME', 'Key4')

# Базовый URL API
VEONONSTOP_API_BASE = 'https://veononstop.org/api/v1'

# Параллельных задач (default=4, max=concurrent_tasks из API).
# 4 — безопасное значение без slots_full. Можно повысить через .env до 12.
VEONONSTOP_MAX_PARALLEL = int(os.getenv('VEONONSTOP_MAX_PARALLEL', '4'))

# Соотношение сторон видео/картинок: 16:9, 9:16, 1:1
VEONONSTOP_ASPECT_RATIO = os.getenv('VEONONSTOP_ASPECT_RATIO', '16:9')

# Режим imggen: imagen, banana, banana_ref
VEONONSTOP_IMGGEN_MODE = os.getenv('VEONONSTOP_IMGGEN_MODE', 'banana')

# Интервал поллинга статуса (секунды)
VEONONSTOP_POLL_INTERVAL = int(os.getenv('VEONONSTOP_POLL_INTERVAL', '10'))

# Таймаут ожидания одной задачи (секунды, 30 мин по умолчанию)
VEONONSTOP_POLL_TIMEOUT = int(os.getenv('VEONONSTOP_POLL_TIMEOUT', '1800'))

# Модель Banana Pro: GEM_PIX или GEM_PIX_2 (по умолчанию)
VEONONSTOP_BANANA_MODEL = os.getenv('VEONONSTOP_BANANA_MODEL', 'GEM_PIX_2')

# Режим применения рефов: name_match (по именам из промпта) или use_all (все рефы на каждый промпт)
VEONONSTOP_REF_MODE = os.getenv('VEONONSTOP_REF_MODE', 'name_match')

# Задержка между запросами воркеров (секунды). Увеличь если много reCAPTCHA ошибок.
# 10.0 = 24 воркера стартуют за 230с. Веб-версия: 15с. Уменьши если не нужен такой разброс.
VEONONSTOP_REQUEST_DELAY = float(os.getenv('VEONONSTOP_REQUEST_DELAY', '10.0'))

# Макс. попыток на шаг генерации (Phase 1 и каждый шаг цепочки при техн. ошибке)
VEONONSTOP_MAX_RETRIES = int(os.getenv('VEONONSTOP_MAX_RETRIES', '3'))

# Повторные запуски в silent режиме (для клипов с техн. ошибками)
VEONONSTOP_MAX_SILENT_CYCLES = int(os.getenv('VEONONSTOP_MAX_SILENT_CYCLES', '5'))

# Режим быстрой цензуры: off | after_rewrites | ultrafast
#   off            — полная цепочка (реврайты + ремиксы + минималистик)
#   after_rewrites — реврайты да, ремиксы нет, сразу static fallback
#   ultrafast      — сразу static fallback без реврайтов и ремиксов
VEONONSTOP_FAST_CENSOR = os.getenv('VEONONSTOP_FAST_CENSOR', 'off').lower()

# Апскейл изображений после генерации: off | 2K | 4K
VEONONSTOP_IMAGE_UPSCALE = os.getenv('VEONONSTOP_IMAGE_UPSCALE', 'off').lower()

# Апскейл видео после генерации (1080p): true/false
VEONONSTOP_VIDEO_UPSCALE = os.getenv('VEONONSTOP_VIDEO_UPSCALE', '').lower() in ('true', '1', 'yes')

# ============================================================================
# НАСТРОЙКИ ВИДЕО
# ============================================================================

# Длительность одного фрагмента (секунды)
VIDEO_FRAGMENT_DURATION = 8.0

# FPS для финального видео
VIDEO_FPS = 60

# ============================================================================
# ДЛИТЕЛЬНОСТЬ КЛИПОВ МОНТАЖНОГО ПЛАНА
# ============================================================================

# Видеорежим (Veo3-фрагменты)
VIDEO_CLIP_MIN_DURATION    = int(os.getenv('VIDEO_CLIP_MIN_DURATION',    '4'))
VIDEO_CLIP_MAX_DURATION    = int(os.getenv('VIDEO_CLIP_MAX_DURATION',    '8'))

# Слайдшоурежим (картинки)
SLIDESHOW_CLIP_MIN_DURATION = int(os.getenv('SLIDESHOW_CLIP_MIN_DURATION', '2'))
SLIDESHOW_CLIP_MAX_DURATION = int(os.getenv('SLIDESHOW_CLIP_MAX_DURATION', '7'))

# Активный режим — выставляется агентом при старте (по умолчанию видео)
ACTIVE_CLIP_MIN_DURATION = VIDEO_CLIP_MIN_DURATION
ACTIVE_CLIP_MAX_DURATION = VIDEO_CLIP_MAX_DURATION

# ============================================================================
# ВСТУПИТЕЛЬНЫЙ БЛОК (intro)
# ============================================================================

# Длительность вступительной зоны таймлайна (секунды)
# Все клипы до этой отметки используют intro-настройки длительности
INTRO_BLOCK_DURATION = int(os.getenv('INTRO_BLOCK_DURATION', '30'))

# Мин/макс длительность клипов во вступительном блоке (0 = авто)
# Если 0 — берётся из ACTIVE с ограничением max≤7
INTRO_CLIP_MIN_DURATION = int(os.getenv('INTRO_CLIP_MIN_DURATION', '0'))
INTRO_CLIP_MAX_DURATION = int(os.getenv('INTRO_CLIP_MAX_DURATION', '0'))


def get_intro_clip_min():
    return INTRO_CLIP_MIN_DURATION if INTRO_CLIP_MIN_DURATION > 0 else ACTIVE_CLIP_MIN_DURATION


def get_intro_clip_max():
    return INTRO_CLIP_MAX_DURATION if INTRO_CLIP_MAX_DURATION > 0 else min(7, ACTIVE_CLIP_MAX_DURATION)

# ============================================================================
# НАСТРОЙКИ ЛОГГИРОВАНИЯ
# ============================================================================

# Уровень логгирования
LOG_LEVEL = 'DEBUG'  # 'DEBUG', 'INFO', 'WARNING', 'ERROR'

# Формат логов
LOG_FORMAT = '%(asctime)s | %(levelname)-8s | %(message)s'

# ============================================================================
# НАСТРОЙКИ GUI ПАЙПЛАЙНА (умолчания вкладки Pipeline Launcher)
# ============================================================================

# Точка старта: audio | script
PIPELINE_START_POINT  = os.getenv('PIPELINE_START_POINT',  'audio')
# Режим клипов: video | slideshow | vislide
PIPELINE_CLIP_MODE         = os.getenv('PIPELINE_CLIP_MODE',         'video')
PIPELINE_VISLIDE_INTERVAL  = int(os.getenv('PIPELINE_VISLIDE_INTERVAL', '3'))
# Источник изображений: fastgen | veononstop | skip
PIPELINE_IMG_GEN      = os.getenv('PIPELINE_IMG_GEN',      'fastgen')
# Режим видеогенерации: i2v | t2v | components | skip
PIPELINE_VIDEO_MODE   = os.getenv('PIPELINE_VIDEO_MODE',   'i2v')
# Режим промптов: single | per_clip
PIPELINE_PROMPT_MODE  = os.getenv('PIPELINE_PROMPT_MODE',  'single')
# Рендер: 720p | 1080p | fast
PIPELINE_RENDER_MODE  = os.getenv('PIPELINE_RENDER_MODE',  '720p')
# Ватермарка: as_is | blur_borders | skip
PIPELINE_WATERMARK    = os.getenv('PIPELINE_WATERMARK',    'as_is')
# Оставить ретайминг файлы: true | false
PIPELINE_KEEP_FILES   = os.getenv('PIPELINE_KEEP_FILES',   'false').lower() in ('true', '1', 'yes')
# Оставить оригинальный звук из Veo-видео: true | false
PIPELINE_KEEP_VEO_SOUND = os.getenv('PIPELINE_KEEP_VEO_SOUND', 'false').lower() in ('true', '1', 'yes')

# ============================================================================
# ПРОВЕРКА КЛЮЧЕЙ
# ============================================================================

def check_api_keys():
    """Проверяет наличие API ключей"""
    errors = []

    if not ASSEMBLYAI_API_KEY:
        errors.append('ASSEMBLYAI_API_KEY не найден в .env')

    if not GEMINI_API_KEY:
        errors.append('GEMINI_API_KEY не найден в .env')

    return errors


def get_model_pricing(model_name: str) -> dict:
    """Возвращает тарифы для указанной модели"""
    return GEMINI_PRICING.get(model_name, {'input': 0.0, 'output': 0.0})


def estimate_cost(input_tokens: int, output_tokens: int, model_name: str) -> dict:
    """
    Оценивает стоимость запроса
    
    Args:
        input_tokens: Количество входных токенов
        output_tokens: Количество выходных токенов
        model_name: Название модели
    
    Returns:
        Словарь с оценкой стоимости
    """
    pricing = get_model_pricing(model_name)
    
    input_cost = (input_tokens / 1_000_000) * pricing['input']
    output_cost = (output_tokens / 1_000_000) * pricing['output']
    total_cost = input_cost + output_cost
    
    return {
        'model': model_name,
        'input_tokens': input_tokens,
        'output_tokens': output_tokens,
        'input_cost': input_cost,
        'output_cost': output_cost,
        'total_cost': total_cost,
    }


# ============================================================================
# СОЗДАНИЕ ДИРЕКТОРИЙ
# ============================================================================

def create_directories():
    """Создаёт необходимые директории"""
    TEMP_DIR.mkdir(exist_ok=True)
    LOGS_DIR.mkdir(exist_ok=True)
    PROMPTS_DIR.mkdir(exist_ok=True)
