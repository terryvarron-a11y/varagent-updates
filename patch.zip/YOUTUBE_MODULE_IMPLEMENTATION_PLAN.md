# YouTube Module: Final Implementation Plan

Date: 2026-08-20
Source of truth: `VARAGENT_API`

## Goal

Implement YouTube footage as a source-aware, license-aware stage for montage
scenes. The director defines the scene and its duration. The YouTube module
finds, evaluates, downloads, validates, and composes footage without asking
the director for a URL, video ID, or internal YouTube timestamps.
The replacement is a single active runtime: the old local-folder YouTube
branch and the old metadata-only selector are archived, not kept as
coexisting execution paths.

## GUI settings

The YouTube Footage settings block must expose:

- YouTube discovery only; local footage remains configured in Stock Footage;
- search backend: Auto, YouTube Data API, or yt-dlp metadata;
- license policy:
  - Creative Commons: use `videoLicense=creativeCommon` in YouTube Data API
    `search.list`;
  - Any license: do not send a license restriction to `search.list`;
- explicit rights-text policy: exclude or warn;
- Data API key;
- candidate pool size;
- maximum duration of one moving YouTube part;
- source-gap and stage wait settings;
- optional smart ranking settings.

The GUI displays human-readable labels. Internal values remain stable:
`creative_common` and `any`.

## Source routing

The query planner chooses a preferred source type:

- abstract or generic human actions and ordinary household processes:
  EPF/stock first, YouTube only as fallback;
- concrete places, animals, rare behavior, real events, transport, machinery,
  sports, and documentary footage:
  YouTube is allowed and can be preferred;
- fantasy, metaphorical, or impossible scenes:
  AI or another explicitly selected source.

YouTube is not restricted to historical or news footage.

## Discovery

For each YouTube scene:

1. The query planner creates several semantic search queries.
2. The Data API searches each query and collects multiple video IDs.
3. Duplicate IDs are removed.
4. With Creative Commons policy, the server-side license filter is applied
   during `search.list`.
5. `videos.list` fetches duration, availability, description, channel, date,
   statistics, and license metadata.
6. Defensive license and explicit commercial-rights text checks run before
   ranking or download.

The server-side license filter saves downstream work but does not remove the
fixed quota cost of the `search.list` request itself.

## Temporal candidate generation

The module locates useful moments inside each video using this order:

1. captions/subtitles;
2. chapters;
3. timestamps in the description;
4. sparse visual scan;
5. additional fallback windows when needed.

Candidate generation creates fixed-duration parts before Vision evaluates
them. The maximum is `YOUTUBE_MAX_FRAGMENT_SEC` (normally 3 seconds).

A long scene duration is not used as the download duration of one YouTube
part. A 6-second scene may use two 3-second parts. Only a final remainder may
be shorter than the configured maximum.

## Vision selection

Vision receives one contact sheet per scene containing labeled candidate parts.
Each candidate has a fixed start and duration and may show start, middle, and
end frames in the sheet.

The text prompt contains the visual intent and constraints but does not
duplicate timestamps. Vision returns candidate IDs and ranking/reasons only.
It does not invent URLs, video IDs, timestamps, or durations.

Vision evaluates:

- semantic relevance;
- required subject and action;
- useful movement;
- visual quality;
- titles, logos, watermarks, or distracting overlays;
- slideshow or irrelevant content.

## Download and validation

The selected candidate is downloaded by `yt-dlp` using the exact precomputed
range. The module then:

1. retries the next ranked candidate if download fails;
2. validates the result with FFmpeg;
3. normalizes size, FPS, codec, and audio;
4. stores the final fragment in the project `vid_img` directory;
5. writes selection and provenance artifacts.

The module never downloads the entire candidate pool unless a separate
diagnostic mode explicitly requests it.

## Scene composition

The composer fills the complete scene duration from approved parts. It may
combine YouTube, EPF, stock, and other permitted sources. It must wait for
YouTube processing to finish before concat starts.

If YouTube fails, fallback order is:

1. next ranked YouTube candidate;
2. another located window/video;
3. EPF/stock;
4. the pipeline's configured final fallback.

## Artifacts

For every processed YouTube scene, retain:

- search queries;
- discovered video metadata;
- license and rights checks;
- candidate windows and their fixed source ranges;
- Vision ranking response;
- selected parts;
- actual downloaded ranges;
- source URLs and provenance;
- fallback/error log.

Suggested files:

- `youtube/clips/<clip_id>/selection.json`;
- `youtube/clips/<clip_id>/provenance.json`;
- `youtube/pools/<pool_key>.json`.

## Implementation order

### Phase 0: Contracts and source routing

1. Define the scene input contract: scene text, visual intent, duration,
   source preference, must-have, avoid, and fallback sources.
2. Define the query-planner output contract: multiple search queries,
   canonical subject, temporal terms, source type, and negative constraints.
3. Keep source routing explicit:
   `EPF/stock -> YouTube -> AI` for generic actions, and
   `YouTube -> EPF/stock -> AI` for concrete places, animals, events, and
   documentary processes.
4. Add deterministic normalization for missing or malformed planner fields.

### Phase 1: Multi-query licensed discovery

1. Execute all planner queries, not only the first query.
2. Deduplicate by `video_id`.
3. Apply `videoLicense=creativeCommon` during Data API search when selected.
4. Use `any` only when explicitly selected in GUI.
5. Fetch metadata in batches with `videos.list`.
6. Retain defensive license, embeddable, duration, and rights-text checks.
7. Persist the complete discovered pool and the rejection reasons.

### Phase 2: Temporal localization

1. Inspect captions/subtitles, chapters, and description timestamps.
2. Normalize every located time interval to the source video duration.
3. Use sparse visual scanning when text metadata does not locate a moment.
4. Generate several temporal windows per video.
5. Do not download the entire candidate pool.
6. Record the origin of every window: caption, chapter, description, or scan.

### Phase 3: Fixed candidate parts

1. Convert located windows into exact candidate parts before Vision.
2. Each part has an immutable `candidate_id`, `video_id`, `start`, `end`,
   and `duration`.
3. Every moving YouTube part is at most `YOUTUBE_MAX_FRAGMENT_SEC`.
4. A scene longer than that limit is composed from several parts.
5. Vision cannot shorten, extend, or relocate a part.
6. The final remainder may be shorter only when it is the mathematically
   required remainder of the scene budget.
7. Reject only technically unusable parts, not parts merely shorter than the
   complete scene duration.

### Phase 4: Preview and Vision selection

1. Render lightweight previews/contact sheets for candidate parts.
2. Send one labeled contact sheet per scene where possible.
3. Put `C1`, `C2`, and similar IDs on the image; keep timestamps in the
   internal candidate table rather than duplicating them in the prompt.
4. Send the visual intent, must-have, avoid, and quality requirements as text.
5. Require strict JSON containing candidate IDs only.
6. Validate that the response contains every eligible ID exactly once.
7. Fall back deterministically if Vision is unavailable or returns invalid JSON.
8. Store the prompt, contact sheet, raw response, normalized ranking, and
   rejection reasons.

### Phase 5: Selection, rotation, and download

1. Apply source-interval spacing and project-level usage rotation.
2. Try candidates in Vision ranking order, then deterministic fallback order.
3. Download only the selected exact range through yt-dlp.
4. Retry the next candidate on HTTP 403, unavailable media, timeout, or
   invalid output.
5. Validate the media with FFmpeg and normalize project parameters.
6. Never mark a clip ready before its final media and provenance exist.

### Phase 6: Mixed-source composition

1. Build a scene composition plan whose part durations sum to the scene
   duration.
2. Permit YouTube, EPF, stock, and other configured non-AI sources in one
   scene when the source policy allows it.
3. Avoid filling a long scene with arbitrary adjacent pieces from one video.
4. Preserve the selected source range for every composition part.
5. Make concat wait for every selected YouTube part and all fallbacks.
6. Resolve abandoned pending markers to a terminal fallback with a clear log.

### Phase 7: GUI and persistence

1. Expose source mode, search backend, license policy, rights policy, API key,
   pool size, fragment limit, rotation gap, timeout, and Vision selector.
2. Display human-readable license labels while persisting stable values.
3. Ensure `.env`, GUI defaults, presets, and runtime environment agree.
4. Show the effective source/license policy in the run log.

### Phase 8: Verification gates

1. Unit-test contracts and normalization.
2. Mock-test multi-query discovery, deduplication, CC filtering, rights
   rejection, temporal windows, fixed durations, Vision ID validation,
   fallback ranking, range download, and composition waiting.
3. Run a live Data API discovery smoke test.
4. Run a live preview/Vision smoke test with a small candidate pool.
5. Run a live one-scene download and composition test.
6. Preserve artifacts for manual inspection.
7. Only after all gates pass, prepare the API-to-portable synchronization.

## Explicit non-goals

- Vision does not choose arbitrary duration.
- The director does not provide internal YouTube timestamps.
- YouTube is not the default source for generic household or abstract human
  actions.
- A 10-second scan window is not itself a final 10-second candidate.
- Do not sync the unfinished YouTube implementation to `VARAGENT_API_PORTABLE`
  until the API-side tests and live smoke test are accepted.
