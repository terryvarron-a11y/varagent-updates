#!/usr/bin/env python3
"""
ГРУППОВАЯ СКЛЕЙКА - v6 OVERLAP GUARD
• Валидация монтажного плана
• Сортировка клипов по startTime (защита от JSON-порядка от Gemini)
• Анализ и заполнение всех гэпов
• Обнаружение и коррекция перекрытий (внахлёст)
• Проверка существующих файлов
• Групповая склейка без перекодирования
• Автоисправление финальной синхронизации (быстрое обрезание)
• GPU ускорение
• Логгирование всех операций
• Запрос перед удалением temp папки
"""

import subprocess
import json
import sys
import os
import glob as _glob
import argparse
from pathlib import Path
from tqdm import tqdm
import platform
import time
import shutil
import logging
from datetime import datetime
import traceback

IS_PIPE = not sys.stdout.isatty()  # True когда запущен как subprocess (pipeline mode)

if platform.system() == 'Windows':
    SUBPROCESS_FLAGS = {'creationflags': 0x08000000}
    # Принудительно UTF-8 для stdout/stderr — иначе на английских Windows (cp1252)
    # Кириллица в print() вызывает UnicodeEncodeError
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
else:
    SUBPROCESS_FLAGS = {}

# ============================================================================
# FFMPEG RESOLVER — ищет ffmpeg/ffprobe в PATH и типичных местах установки
# (на случай если PATH не обновился после winget/choco install)
# ============================================================================
def _resolve_ff(name: str) -> str:
    found = shutil.which(name)
    if found:
        return found
    if platform.system() == 'Windows':
        exe = name + '.exe'
        # winget (Gyan.FFmpeg) — самый частый способ установки
        wg = os.path.expandvars('%LOCALAPPDATA%\\Microsoft\\WinGet\\Packages')
        if os.path.isdir(wg):
            import glob as _g2
            for candidate in _g2.glob(
                    os.path.join(wg, 'Gyan.FFmpeg_*', '**', exe), recursive=True):
                if os.path.isfile(candidate):
                    return candidate
        # Chocolatey
        choco = os.path.join(os.environ.get('ProgramData', 'C:\\ProgramData'),
                             'chocolatey', 'lib', 'ffmpeg', 'tools', 'ffmpeg', 'bin', exe)
        if os.path.isfile(choco):
            return choco
        # Ручная установка
        for d in [r'C:\ffmpeg\bin', r'C:\Program Files\ffmpeg\bin',
                  r'C:\Program Files (x86)\ffmpeg\bin']:
            p = os.path.join(d, exe)
            if os.path.isfile(p):
                return p
    return name  # надеемся что PATH уже содержит бинарник

FFMPEG  = _resolve_ff('ffmpeg')
FFPROBE = _resolve_ff('ffprobe')

# Клипы с target_duration <= этого порога обрезаются (trim) вместо ускорения через setpts.
# Ускорение коротких клипов до 2x и выше даёт неестественное видео; обрезка выглядит лучше.
TRIM_MAX_DURATION = 5.9

# ============================================================================
# ============================================================================
# SUBTITLE HELPERS
# ============================================================================

def _srt_to_ass(srt_path: str, template_path: str, output_path: str):
    """Конвертирует SRT в ASS, применяя стили из ASS-шаблона."""
    import re as _re

    # Читаем шаблон — берём всё до [Events]
    tpl = open(template_path, encoding='utf-8-sig').read()
    if '[Events]' in tpl:
        header = tpl[:tpl.index('[Events]')]
    else:
        header = tpl.rstrip() + '\n'

    # Парсим SRT
    srt_text = open(srt_path, encoding='utf-8-sig').read()
    blocks = [b.strip() for b in _re.split(r'\n{2,}', srt_text) if b.strip()]

    def _tc(s):
        # 00:00:01,500 → 0:00:01.50
        h, m, rest = s.split(':')
        sec, ms = _re.split(r'[,.]', rest)
        return f"{int(h)}:{m}:{sec}.{ms[:2]}"

    events = ['[Events]',
              'Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text']
    for b in blocks:
        lines = b.splitlines()
        tc_line = next((l for l in lines if '-->' in l), None)
        if not tc_line:
            continue
        ti = lines.index(tc_line)
        t0, t1 = [s.strip() for s in tc_line.split('-->')]
        text = ' '.join(lines[ti + 1:]).strip()
        if not text:
            continue
        events.append(f"Dialogue: 0,{_tc(t0)},{_tc(t1)},Default,,0,0,0,,{text}")

    open(output_path, 'w', encoding='utf-8-sig').write(
        header + '\n'.join(events) + '\n')


# ============================================================================
# НАСТРОЙКА ЛОГГИРОВАНИЯ
# ============================================================================

def setup_logging():
    """Настраивает логгирование в файл и консоль"""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = f'video_concat_{timestamp}.log'

    logger = logging.getLogger('VideoConcat')
    logger.setLevel(logging.DEBUG)

    formatter = logging.Formatter(
        '%(asctime)s | %(levelname)-8s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.WARNING)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    logger.info("="*80)
    logger.info("НАЧАЛО РАБОТЫ СКРИПТА")
    logger.info("="*80)

    return logger, log_file

# Глобальный логгер
logger = None

# ============================================================================
# ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
# ============================================================================

def get_audio_duration(audio_path):
    """Получает длительность аудиофайла в секундах"""
    try:
        logger.debug(f"Получение длительности аудио: {audio_path}")
        result = subprocess.run(
            [FFPROBE, '-v', 'error', '-show_entries', 'format=duration',
             '-of', 'default=noprint_wrappers=1:nokey=1', audio_path],
            capture_output=True, text=True, check=True, **SUBPROCESS_FLAGS
        )
        duration = float(result.stdout.strip())
        logger.info(f"Длительность аудио: {duration:.2f} сек")
        return duration
    except Exception as e:
        logger.error(f"Ошибка при получении длительности аудио: {e}")
        logger.error(traceback.format_exc())
        print(f"❌ Ошибка при получении длительности аудио: {e}")
        sys.exit(1)

def get_video_duration(video_path):
    """Получает длительность видеофайла в секундах"""
    try:
        result = subprocess.run(
            [FFPROBE, '-v', 'error', '-show_entries', 'format=duration',
             '-of', 'default=noprint_wrappers=1:nokey=1', str(video_path)],
            capture_output=True, text=True, check=True, **SUBPROCESS_FLAGS
        )
        duration = float(result.stdout.strip())
        logger.debug(f"Длительность видео {video_path}: {duration:.2f} сек")
        return duration
    except Exception as e:
        logger.warning(f"Не удалось получить длительность {video_path}: {e}")
        return 0

def get_file_size_mb(file_path):
    """Получает размер файла в МБ"""
    try:
        size = os.path.getsize(file_path) / (1024 * 1024)
        return size
    except:
        return 0

def check_processed_file(file_path, min_size_kb=100):
    """Проверяет что обработанный файл существует и не битый"""
    if not os.path.exists(file_path):
        return False
    if os.path.getsize(file_path) < min_size_kb * 1024:
        logger.debug(f"Файл {file_path} слишком мал")
        return False
    try:
        duration = get_video_duration(file_path)
        return duration > 0
    except:
        return False

def get_video_resolution(file_path):
    """Возвращает (width, height) видео или (0, 0) при ошибке."""
    try:
        result = subprocess.run(
            [FFPROBE, '-v', 'error', '-select_streams', 'v:0',
             '-show_entries', 'stream=width,height',
             '-of', 'csv=p=0', str(file_path)],
            capture_output=True, text=True, **SUBPROCESS_FLAGS
        )
        parts = result.stdout.strip().split(',')
        if len(parts) >= 2:
            return int(parts[0]), int(parts[1])
    except Exception:
        pass
    return 0, 0

def validate_montage_plan(clips, audio_path):
    """Валидация монтажного плана"""
    logger.info("ЭТАП 1: ВАЛИДАЦИЯ МОНТАЖНОГО ПЛАНА")

    print("\n" + "="*80)
    print("📋 ВАЛИДАЦИЯ МОНТАЖНОГО ПЛАНА")
    print("="*80)

    if not clips:
        logger.error("Ошибка: нет clips в плане!")
        print("❌ Ошибка: нет clips в плане!")
        sys.exit(1)

    if audio_path is None:
        # VEO audio inline mode without narration — derive timeline from clips
        actual_audio_duration = clips[-1]['endTime']
        logger.info(f"veo-audio-inline без нарации: длительность из клипов {actual_audio_duration:.2f}с")
        print(f"\n[INFO] Нарация не задана (veo-audio-inline режим). Длительность из монтажного плана: {actual_audio_duration:.2f}с")
    else:
        actual_audio_duration = get_audio_duration(audio_path)
        if actual_audio_duration is None:
            logger.error(f"Не удалось получить длительность аудио: {audio_path}")
            print(f"❌ Не удалось получить длительность аудио: {audio_path}")
            sys.exit(1)
    logger.info(f"Количество clips в плане: {len(clips)}")

    print(f"\n📊 Длительность аудио: {actual_audio_duration:.2f} сек")
    print(f"📊 Количество clips: {len(clips)}")

    first_start = clips[0]['startTime']
    last_end = clips[-1]['endTime']

    logger.info(f"Первый clip начинается: {first_start:.2f} сек")
    logger.info(f"Последний clip заканчивается: {last_end:.2f} сек")

    print(f"\n📊 Покрытие плана:")
    print(f"   • Первый clip: {first_start:.2f} сек")
    print(f"   • Последний clip: {last_end:.2f} сек")
    print(f"   • Аудио: 0.00 - {actual_audio_duration:.2f} сек")

    if first_start > 0.1:
        logger.warning(f"Гэп в начале: {first_start:.2f} сек")
        print(f"\n⚠️  ВНИМАНИЕ: Первый clip начинается с {first_start:.2f}с (будет исправлено)")

    if abs(last_end - actual_audio_duration) > 0.1:
        if last_end < actual_audio_duration:
            logger.warning(f"Гэп в конце: {actual_audio_duration - last_end:.2f} сек")
            print(f"⚠️  ВНИМАНИЕ: Последний clip {last_end:.2f}с < аудио {actual_audio_duration:.2f}с (будет исправлено)")
        else:
            logger.warning(f"Последний clip длиннее аудио на {last_end - actual_audio_duration:.2f} сек")
            print(f"⚠️  ВНИМАНИЕ: Последний clip {last_end:.2f}с > аудио {actual_audio_duration:.2f}с")

    print(f"\n✅ Валидация завершена")
    print("="*80)
    logger.info("Валидация плана завершена успешно")

    return actual_audio_duration

def analyze_gaps(clips, audio_duration):
    """Анализирует все гэпы и перекрытия: в начале, внутри, в конце"""
    logger.info("ЭТАП 2: АНАЛИЗ ГЭПОВ И ПЕРЕКРЫТИЙ")

    print("\n" + "="*80)
    print("🔍 АНАЛИЗ ГЭПОВ И ПЕРЕКРЫТИЙ")
    print("="*80)

    gaps_info = []
    corrections = []

    # 1. Проверка начального гэпа
    first_start = clips[0]['startTime']
    if first_start > 0.01:
        gap = first_start
        logger.info(f"ГЭП В НАЧАЛЕ: {gap:.2f} сек")
        gaps_info.append(f"⚠️  ГЭП В НАЧАЛЕ: {gap:.2f} сек (до первого clip)")
        corrections.append({
            'type': 'start_gap',
            'clip_index': 0,
            'original_start': first_start,
            'new_start': 0.0,
            'gap_size': gap
        })

    # 2. Проверка внутренних гэпов и перекрытий
    for i in range(len(clips) - 1):
        end_current = clips[i]['endTime']
        start_next = clips[i+1]['startTime']
        diff = start_next - end_current

        if diff > 0.01:
            # Гэп — растягиваем предыдущий клип
            gap = diff
            logger.info(f"ВНУТРЕННИЙ ГЭП #{i+1}: {gap:.2f} сек между clip {clips[i]['id']} и {clips[i+1]['id']}")
            gaps_info.append(f"⚠️  ГЭП #{i+1}: {gap:.2f} сек между clip {clips[i]['id']} и {clips[i+1]['id']}")
            logger.info(f"  → Решение: РЕТАЙМ clip {clips[i]['id']} (+{gap:.2f} сек)")
            corrections.append({
                'type': 'retime_extend',
                'clip_index': i,
                'gap_size': gap,
                'original_duration': end_current - clips[i]['startTime'],
                'new_duration': (end_current - clips[i]['startTime']) + gap
            })

        elif diff < -0.01:
            # Перекрытие — обрезаем предыдущий клип
            overlap = -diff
            logger.warning(f"ПЕРЕКРЫТИЕ #{i+1}: {overlap:.2f} сек между clip {clips[i]['id']} и {clips[i+1]['id']}")
            gaps_info.append(f"🔴 ПЕРЕКРЫТИЕ #{i+1}: {overlap:.2f} сек между clip {clips[i]['id']} и {clips[i+1]['id']}")
            logger.info(f"  → Решение: ОБРЕЗКА clip {clips[i]['id']} endTime {end_current:.2f} → {start_next:.2f}")
            corrections.append({
                'type': 'trim_overlap',
                'clip_index': i,
                'overlap_size': overlap,
                'original_end': end_current,
                'new_end': start_next
            })

    # 3. Проверка конечного гэпа
    last_end = clips[-1]['endTime']
    if last_end < audio_duration - 0.01:
        gap = audio_duration - last_end
        logger.info(f"ГЭП В КОНЦЕ: {gap:.2f} сек")
        gaps_info.append(f"⚠️  ГЭП В КОНЦЕ: {gap:.2f} сек (после последнего clip)")
        corrections.append({
            'type': 'end_gap',
            'clip_index': len(clips) - 1,
            'original_end': last_end,
            'new_end': audio_duration,
            'gap_size': gap
        })

    # Вывод результатов
    if gaps_info:
        overlaps_count = sum(1 for c in corrections if c['type'] == 'trim_overlap')
        gaps_count = len(gaps_info) - overlaps_count
        logger.info(f"Найдено: гэпов={gaps_count}, перекрытий={overlaps_count}")
        print(f"\n📊 Найдено: гэпов={gaps_count}, перекрытий={overlaps_count}")
        for info in gaps_info:
            print(f"   {info}")

        print(f"\n🔧 План корректировок:")
        for corr in corrections:
            if corr['type'] == 'start_gap':
                print(f"   • Clip {clips[corr['clip_index']]['id']}: РЕТАЙМ начала с {corr['original_start']:.2f}→0.00 (+{corr['gap_size']:.2f}с)")
            elif corr['type'] == 'end_gap':
                print(f"   • Clip {clips[corr['clip_index']]['id']}: РЕТАЙМ конца с {corr['original_end']:.2f}→{corr['new_end']:.2f} (+{corr['gap_size']:.2f}с)")
            elif corr['type'] == 'retime_extend':
                print(f"   • Clip {clips[corr['clip_index']]['id']}: РЕТАЙМ длительности {corr['original_duration']:.2f}→{corr['new_duration']:.2f}с")
            elif corr['type'] == 'trim_overlap':
                print(f"   • Clip {clips[corr['clip_index']]['id']}: ОБРЕЗКА {corr['original_end']:.2f}→{corr['new_end']:.2f} (-{corr['overlap_size']:.2f}с)")
    else:
        logger.info("Гэпов и перекрытий не обнаружено")
        print(f"\n✅ Гэпов и перекрытий не обнаружено! План идеален!")

    print("="*80)
    logger.info(f"Анализ завершен. Корректировок: {len(corrections)}")

    return corrections

def fix_video_audio_sync(video_path, audio_path, temp_dir, encoder_type, codec, bitrate):
    """АВТОМАТИЧЕСКОЕ ИСПРАВЛЕНИЕ рассинхронизации видео и аудио"""
    logger.info("ЭТАП 6: ПРОВЕРКА ФИНАЛЬНОЙ СИНХРОНИЗАЦИИ")
    print("\n" + "="*80)
    print("🔧 ПРОВЕРКА ФИНАЛЬНОЙ СИНХРОНИЗАЦИИ")
    print("="*80)

    video_duration = get_video_duration(video_path)
    audio_duration = get_audio_duration(audio_path)

    logger.info(f"Длительность склеенного видео: {video_duration:.2f} сек")
    logger.info(f"Длительность аудио озвучки: {audio_duration:.2f} сек")

    print(f"\n📊 Длительность склеенного видео: {video_duration:.2f} сек")
    print(f"📊 Длительность аудио озвучки: {audio_duration:.2f} сек")

    diff = video_duration - audio_duration
    print(f"📊 Разница: {diff:.2f} сек")
    logger.info(f"Разница: {diff:.2f} сек")

    # Идеальная синхронизация
    if abs(diff) <= 0.1:
        logger.info("Синхронизация идеальна")
        print(f"\n✅ Отлично! Синхронизация идеальна (разница {abs(diff):.2f} сек)")
        print("="*80)
        return str(video_path)

    # Допустимая рассинхронизация
    if abs(diff) <= 0.5:
        logger.info("Небольшая рассинхронизация, допустима")
        print(f"\n✅ Хорошо! Небольшая рассинхронизация ({abs(diff):.2f} сек)")
        print("="*80)
        return str(video_path)

    # Быстрая обрезка/дополнение хвоста (0.5-2.5 сек) БЕЗ перекодирования
    if abs(diff) <= 2.5:
        logger.info(f"Быстрая коррекция хвоста: {abs(diff):.2f} сек (trim без перекодирования)")
        print(f"\n🔧 Обнаружена рассинхронизация: {abs(diff):.2f} сек")
        print(f"   Применяю быструю обрезку/дополнение (БЕЗ перекодирования)...")

        fixed_video = temp_dir / 'concat_video_fixed.mp4'

        if diff > 0:
            # Видео длиннее - обрезаем хвост
            logger.info(f"Обрезаем {diff:.2f} сек с хвоста (trim)")
            print(f"   Видео длиннее аудио на {diff:.2f} сек")
            print(f"   Обрезаем хвост через trim...")
            cmd = [
                FFMPEG, '-y',
                '-i', str(video_path),
                '-t', str(audio_duration),
                '-c', 'copy',
                str(fixed_video)
            ]
        else:
            # Видео короче - обрезаем по аудио
            logger.info(f"Видео короче на {abs(diff):.2f} сек - обрезаем по аудио (копия)")
            print(f"   Видео короче аудио на {abs(diff):.2f} сек")
            print(f"   Обрезаем по длительности аудио (копия)...")
            cmd = [
                FFMPEG, '-y',
                '-i', str(video_path),
                '-t', str(audio_duration),
                '-c', 'copy',
                str(fixed_video)
            ]

        logger.debug(f"FFmpeg команда: {' '.join(cmd)}")

        trim_success = False
        try:
            run_ffmpeg_with_spinner(cmd, "Обрезка хвоста")
            logger.info("Быстрая коррекция хвоста выполнена успешно")
            trim_success = True
        except subprocess.CalledProcessError as e:
            logger.error(f"Ошибка коррекции хвоста: {e}")
            logger.error(traceback.format_exc())
            print(f"   ⚠️  Trim не сработал, перехожу на setpts...")

        if trim_success:
            fixed_duration = get_video_duration(fixed_video)
            final_diff = abs(fixed_duration - audio_duration)
            logger.info(f"Новая длительность видео: {fixed_duration:.2f} сек, разница: {final_diff:.2f} сек")

            print(f"\n✅ Исправление завершено!")
            print(f"   Новая длительность видео: {fixed_duration:.2f} сек")
            print(f"   Разница с аудио: {final_diff:.2f} сек")
            print("="*80)

            return str(fixed_video)
        # Если trim не удался - код продолжит выполнение и перейдёт к setpts ниже

    # Разница > 2 сек (или trim не сработал) - равномерная коррекция через setpts (перекодирование).
    # setpts равномерно сжимает/растягивает весь видеоряд - синхрон идеален в каждой точке.

    logger.warning(f"Рассинхронизация {abs(diff):.2f} сек - применяю setpts ускорение/замедление")
    print(f"\n🔧 Обнаружена рассинхронизация: {abs(diff):.2f} сек")
    print(f"   Применяю ускорение/замедление (требует перекодирования)...")

    fixed_video = temp_dir / 'concat_video_fixed.mp4'
    encoder_params = get_encoder_params(encoder_type, codec, bitrate)
    speed_factor = video_duration / audio_duration

    if diff < 0:
        logger.info(f"Замедляем видео: {speed_factor:.4f}x")
        print(f"   Видео короче аудио на {abs(diff):.2f} сек")
        print(f"   Замедляем видео: {speed_factor:.4f}x")
    else:
        logger.info(f"Ускоряем видео: {speed_factor:.4f}x")
        print(f"   Видео длиннее аудио на {diff:.2f} сек")
        print(f"   Ускоряем видео: {speed_factor:.4f}x")

    # Не используем -r 60: он форсирует N кадров/сек независимо от PTS,
    # что нейтрализует сжатие setpts и оставляет ту же длину видео.
    cmd = [
        FFMPEG, '-y',
        '-i', str(video_path),
        '-filter:v', f'setpts={1/speed_factor}*PTS',
    ] + encoder_params + [
        '-c:a', 'copy',
        str(fixed_video)
    ]

    logger.debug(f"FFmpeg команда: {' '.join(cmd)}")
    print(f"   Обработка (это займёт время)...")

    try:
        subprocess.run(cmd, check=True, capture_output=True, **SUBPROCESS_FLAGS)
        logger.info("Ускорение/замедление выполнено успешно")
    except subprocess.CalledProcessError as e:
        logger.error(f"Ошибка ускорения/замедления: {e}")
        logger.error(traceback.format_exc())
        raise

    fixed_duration = get_video_duration(fixed_video)
    final_diff = abs(fixed_duration - audio_duration)
    logger.info(f"Новая длительность видео: {fixed_duration:.2f} сек, разница: {final_diff:.2f} сек")

    print(f"\n✅ Исправление завершено!")
    print(f"   Новая длительность видео: {fixed_duration:.2f} сек")
    print(f"   Разница с аудио: {final_diff:.2f} сек")
    print("="*80)

    return str(fixed_video)


def _test_encoder(codec):
    """Проверяет, работает ли энкодер реально (не просто скомпилирован)"""
    try:
        test_cmd = [
            FFMPEG, '-hide_banner', '-loglevel', 'error',
            '-f', 'lavfi', '-i', 'nullsrc=s=256x256:d=0.1',
            '-pix_fmt', 'yuv420p',
            '-c:v', codec, '-frames:v', '1', '-f', 'null', '-'
        ]
        r = subprocess.run(test_cmd, capture_output=True, timeout=10, **SUBPROCESS_FLAGS)
        return r.returncode == 0
    except Exception:
        return False


def detect_gpu_encoder(force_amd=False):
    """Определяет доступный GPU энкодер (с реальной проверкой работоспособности)"""
    logger.debug("Определение доступного GPU энкодера")
    try:
        result = subprocess.run([FFMPEG, '-hide_banner', '-encoders'],
                              capture_output=True, text=True, **SUBPROCESS_FLAGS)
        if 'h264_amf' in result.stdout:
            if _test_encoder('h264_amf'):
                logger.info("Обнаружен AMD GPU (h264_amf)")
                return 'amd', 'h264_amf'
            else:
                logger.warning("h264_amf в списке, но AMD GPU недоступен — пропуск")
        # force_amd = "попробуй AMD первым", но если AMD недоступен — всё равно пробуем NVIDIA
        if 'h264_nvenc' in result.stdout:
            if _test_encoder('h264_nvenc'):
                logger.info("Обнаружен NVIDIA GPU (h264_nvenc)")
                return 'nvidia', 'h264_nvenc'
            else:
                logger.warning("h264_nvenc в списке, но NVIDIA GPU недоступен — пропуск")
        logger.info("GPU не обнаружен, используется CPU (libx264)")
        return 'cpu', 'libx264'
    except Exception as e:
        logger.warning(f"Ошибка определения GPU: {e}")
        return 'cpu', 'libx264'

def get_encoder_params(encoder_type, codec, bitrate='10M'):
    """Возвращает параметры для выбранного энкодера"""
    if encoder_type == 'nvidia':
        return ['-c:v', codec, '-preset', 'p4', '-tune', 'hq', '-b:v', bitrate,
                '-maxrate', bitrate, '-bufsize', f'{int(bitrate[:-1])*2}M',
                '-profile:v', 'high', '-pix_fmt', 'yuv420p']
    elif encoder_type == 'amd':
        return ['-c:v', codec, '-quality', 'speed', '-b:v', bitrate,
                '-maxrate', bitrate, '-bufsize', f'{int(bitrate[:-1])*2}M',
                '-profile:v', 'high', '-pix_fmt', 'yuv420p']
    else:
        return ['-c:v', codec, '-preset', 'medium', '-b:v', bitrate,
                '-maxrate', bitrate, '-bufsize', f'{int(bitrate[:-1])*2}M',
                '-profile:v', 'high', '-pix_fmt', 'yuv420p']

def create_freeze_frame(source_video, output_video, duration, encoder_type, codec, bitrate, fps=60):
    """Создаёт freeze frame из последнего кадра источника"""
    logger.debug(f"Создание freeze frame из {source_video} длительностью {duration:.2f} сек")

    encoder_params = get_encoder_params(encoder_type, codec, bitrate)
    temp_frame = output_video.parent / f'temp_frame_{output_video.stem}.png'

    try:
        cmd_extract = [
            FFMPEG, '-y',
            '-sseof', '-1',
            '-i', str(source_video),
            '-update', '1',
            '-q:v', '1',
            str(temp_frame)
        ]
        logger.debug(f"Извлечение последнего кадра: {' '.join(cmd_extract)}")
        subprocess.run(cmd_extract, check=True, capture_output=True, **SUBPROCESS_FLAGS)

        cmd_create = [
            FFMPEG, '-y',
            '-loop', '1',
            '-i', str(temp_frame),
            '-t', str(duration),
            '-r', str(fps)
        ] + encoder_params + [
            '-an',
            str(output_video)
        ]
        logger.debug(f"Создание видео из кадра: {' '.join(cmd_create)}")
        subprocess.run(cmd_create, check=True, capture_output=True, **SUBPROCESS_FLAGS)

        temp_frame.unlink()
        logger.info(f"Freeze frame создан: {output_video}")
    except Exception as e:
        logger.error(f"Ошибка создания freeze frame: {e}")
        logger.error(traceback.format_exc())
        raise

def build_atempo_chain(speed_factor):
    """
    Создаёт цепочку atempo фильтров для ускорения/замедления аудио.
    FFmpeg atempo поддерживает только 0.5-2.0, для больших значений нужна цепочка.

    atempo=2.0 → аудио в 2 раза быстрее (длительность /2)
    atempo=0.5 → аудио в 2 раза медленнее (длительность *2)

    speed_factor — во сколько раз нужно ускорить (>1 = быстрее, <1 = медленнее).
    atempo = speed_factor напрямую (НЕ 1/speed_factor!)
    """
    target_atempo = speed_factor  # БЕЗ инверсии!

    if 0.5 <= target_atempo <= 2.0:
        return f'atempo={target_atempo:.5f}'

    chain = []
    current = target_atempo

    if current > 2.0:
        while current > 2.0:
            chain.append('atempo=2.0')
            current /= 2.0
        chain.append(f'atempo={current:.5f}')
    elif current < 0.5:
        while current < 0.5:
            chain.append('atempo=0.5')
            current *= 2.0
        chain.append(f'atempo={current:.5f}')

    return ','.join(chain)

_IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.webp', '.bmp', '.tiff', '.tif'}


def _image_to_zoom_video(input_file, output_file, target_duration, encoder_type, codec, bitrate, logo_path=None, fps=60):
    """
    Конвертирует изображение в видео с медленным зумом (Ken Burns effect).
    Зум: 100% → 110% за target_duration секунд.
    """
    logger.info(f"Изображение → зум-видео: {input_file} ({target_duration:.2f}с)")
    print(f"   🖼️  Изображение → зум-видео ({target_duration:.2f}с)")

    output_path = Path(output_file)
    encoder_params = get_encoder_params(encoder_type, codec, bitrate)
    total_frames = int(target_duration * fps)

    # zoompan: зум от 1.0 до 1.1 за весь клип, центр кадра
    zoom_expr = f"'min(1.1, 1.0 + (in_w*0.1/in_w)*on/{total_frames})'"
    zoom_filter = (
        f"scale=8000:-1,"
        f"zoompan=z={zoom_expr}:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)'"
        f":d={total_frames}:s=1920x1080:fps={fps}"
    )

    if logo_path:
        video_filter = f"[0:v]{zoom_filter}[v];[1:v]scale=120:120[logo];[v][logo]overlay=W-w-4:H-h-4"
        cmd = [FFMPEG, '-y', '-nostdin',
               '-loop', '1', '-i', input_file, '-i', str(logo_path),
               '-filter_complex', video_filter,
               '-t', f'{target_duration:.6f}',
               '-r', str(fps)] + encoder_params + ['-an', str(output_path)]
    else:
        cmd = [FFMPEG, '-y', '-nostdin',
               '-loop', '1', '-i', input_file,
               '-filter:v', zoom_filter,
               '-t', f'{target_duration:.6f}',
               '-r', str(fps)] + encoder_params + ['-an', str(output_path)]

    subprocess.run(cmd, check=True, capture_output=True, **SUBPROCESS_FLAGS)
    logger.info(f"Зум-видео готово: {output_file}")


def _build_atempo(speed_factor: float) -> str:
    """Строит цепочку atempo фильтров для любого speed_factor (диапазон каждого [0.5, 2.0])."""
    filters = []
    sf = speed_factor
    while sf > 2.0:
        filters.append("atempo=2.0")
        sf /= 2.0
    while sf < 0.5:
        filters.append("atempo=0.5")
        sf /= 0.5
    filters.append(f"atempo={sf:.6f}")
    return ",".join(filters)


def process_video(input_file, output_file, target_duration, encoder_type, codec, bitrate,
                   logo_path=None, blur_borders=False, keep_audio=False, upscale_1080=False, fps=60):
    """Обрабатывает видео с ретаймингом до нужной длительности + точная обрезка.
    Если input_file — изображение, создаёт зум-видео нужной длины.
    blur_borders=True — размывает ~8% края кадра (скрытие водяных знаков).
    keep_audio=True  — сохраняет VEO аудио в ретаймленном фрагменте (для script-mode без нарации)."""
    input_path = Path(input_file)

    # Изображение → зум-видео
    if input_path.suffix.lower() in _IMAGE_EXTENSIONS:
        _image_to_zoom_video(input_file, output_file, target_duration,
                             encoder_type, codec, bitrate, logo_path, fps=fps)
        return get_video_duration(output_file)

    logger.debug(f"Ретайминг {input_file} → {output_file} (целевая длительность: {target_duration:.2f} сек)")

    output_path = Path(output_file)
    temp_output = output_path.with_suffix('.temp.mp4')

    try:
        result = subprocess.run(
            [FFPROBE, '-v', 'error', '-show_entries', 'format=duration',
             '-of', 'default=noprint_wrappers=1:nokey=1', input_file],
            capture_output=True, text=True, **SUBPROCESS_FLAGS
        )
        _dur_str = result.stdout.strip()
        if not _dur_str:
            logger.warning(f"ffprobe returned empty duration for {input_file} — file may be corrupt, skipping")
            return None
        current_duration = float(_dur_str)

        # Trim mode: короткие целевые длительности обрезаем вместо ускорения.
        # Если source достаточно длинный — speed_factor=1.0 → setpts=PTS/1.0 (no-op) +
        # -t target_duration обрежет хвост без перекодирования темпа.
        # Если source короче target — нормальный ретайм (замедление).
        if target_duration <= TRIM_MAX_DURATION and current_duration >= target_duration:
            speed_factor = 1.0
            logger.info(f"Trim mode: target {target_duration:.2f}с ≤ {TRIM_MAX_DURATION}с, source {current_duration:.2f}с → обрезка без ускорения")
        else:
            speed_factor = current_duration / target_duration

        logger.debug(f"Текущая длительность: {current_duration:.2f} сек, speed_factor: {speed_factor:.4f}")

        encoder_params = get_encoder_params(encoder_type, codec, bitrate)

        # Blur-borders: тонкие чёрные полосы сверху и снизу для скрытия watermark
        blur_suffix = ""
        if blur_borders:
            blur_suffix = ",drawbox=x=0:y=0:w=iw:h=ih*0.06:color=black:t=fill,drawbox=x=0:y=ih*0.94:w=iw:h=ih*0.06:color=black:t=fill"

        # Апскейл до 1080p если запрошен
        scale_suffix = ",scale=1920:1080" if upscale_1080 else ""

        # ШАГ 1: Ретайминг с перекодированием (+ overlay лого если задан)
        # keep_audio=False (по умолчанию): аудио стрипается (-an), заменяется нарацией в Этапе 8.
        # keep_audio=True (script-mode): аудио ретаймится через atempo и сохраняется в итоговом видео.
        audio_args = ['-filter:a', _build_atempo(speed_factor)] if keep_audio else ['-an']

        if logo_path:
            # filter_complex: ретайминг + overlay лого в правый нижний угол
            video_filter = (
                f'[0:v]setpts=PTS/{speed_factor}{blur_suffix}{scale_suffix}[v];'
                f'[1:v]scale=120:120[logo];'
                f'[v][logo]overlay=W-w-4:H-h-4'
            )
            cmd = [FFMPEG, '-y', '-nostdin',
                   '-i', input_file, '-i', str(logo_path),
                   '-filter_complex', video_filter] + audio_args + [
                   '-t', f'{target_duration:.6f}',
                   '-r', str(fps)] + encoder_params + [str(temp_output)]
        else:
            vf = f'setpts=PTS/{speed_factor}{blur_suffix}{scale_suffix}'
            cmd = [FFMPEG, '-y', '-nostdin', '-i', input_file,
                   '-filter:v', vf] + audio_args + [
                   '-t', f'{target_duration:.6f}',
                   '-r', str(fps)] + encoder_params + [str(temp_output)]

        subprocess.run(cmd, check=True, capture_output=True, **SUBPROCESS_FLAGS)

        # Переименовываем temp → final
        if output_path.exists():
            output_path.unlink()
        temp_output.rename(output_path)

        result_duration = get_video_duration(output_path)
        diff = abs(result_duration - target_duration)
        logger.info(f"Clip {os.path.basename(input_file)}: {current_duration:.2f}с → {result_duration:.2f}с (цель {target_duration:.2f}с, разница {diff:.3f}с)")

        logger.debug(f"Ретайминг завершен: {output_file}")
        return result_duration
    except Exception as e:
        logger.error(f"Ошибка ретайминга {input_file}: {e}")
        logger.error(traceback.format_exc())
        # Пробуем очистить temp файл
        try:
            if temp_output.exists():
                temp_output.unlink()
        except:
            pass
        raise

def group_concat(file_list, output_file, temp_dir, group_size=9999, sub_path=None, encoder_type='cpu', bitrate='10M', total_duration=None):
    """ГРУППОВАЯ СКЛЕЙКА"""
    logger.info("ЭТАП 5: ГРУППОВАЯ СКЛЕЙКА")
    logger.info(f"Всего файлов: {len(file_list)}, размер группы: {group_size}")

    print(f"\n🔗 ГРУППОВАЯ СКЛЕЙКА {len(file_list)} файлов...")
    print(f"   💡 Размер группы: {group_size} файлов")

    num_groups = (len(file_list) + group_size - 1) // group_size
    print(f"   📊 Групп: {num_groups}")
    print()

    chunk_files = []
    start_time = time.time()

    print(f"📦 Этап 1: Склейка групп")
    for group_idx in range(num_groups):
        start_idx = group_idx * group_size
        end_idx = min(start_idx + group_size, len(file_list))
        group_files = file_list[start_idx:end_idx]

        chunk_file = temp_dir / f'chunk_{group_idx+1:02d}.mp4'

        logger.info(f"Склейка группы {group_idx+1}/{num_groups}: файлы {start_idx+1}-{end_idx}")

        concat_list = temp_dir / f'group_{group_idx+1}.txt'
        with open(concat_list, 'w', encoding='utf-8') as f:
            for fpath in group_files:
                f.write(f"file '{Path(fpath).absolute()}'\n")

        print(f"   Группа {group_idx+1}/{num_groups}: файлы {start_idx+1}-{end_idx} → chunk_{group_idx+1:02d}.mp4")

        cmd = [FFMPEG, '-y', '-nostdin', '-f', 'concat', '-safe', '0',
               '-i', str(concat_list), '-c', 'copy', '-reset_timestamps', '1', str(chunk_file)]

        group_start = time.time()
        try:
            # TTY (BAT) → реальный tqdm прогресс-бар; IS_PIPE (GUI) → простой текст
            run_ffmpeg_with_progress(cmd, None, f"Склейка {group_idx+1}/{num_groups}")

            elapsed = time.time() - group_start
            print(f"   ✅ Склейка группы {group_idx+1}/{num_groups} ({elapsed:.1f}с)")
            chunk_files.append(str(chunk_file))
            concat_list.unlink()
            logger.info(f"Группа {group_idx+1} склеена за {elapsed:.1f}с")
        except subprocess.CalledProcessError as e:
            print(f"\n   ❌")
            logger.error(f"Ошибка склейки группы {group_idx+1}: {e}")
            logger.error(traceback.format_exc())
            raise

    print()

    # Optimisation: if only 1 chunk and no subtitles — just rename, skip redundant ffmpeg pass
    if len(chunk_files) == 1 and not sub_path:
        import shutil as _shutil
        _shutil.move(str(chunk_files[0]), str(output_file))
        print(f"   ✅ Единственный чанк → финальный файл (без пересклейки)")
        logger.info("Единственный чанк — перемещён напрямую, ffmpeg не нужен")
    else:
        print(f"🔗 Этап 2: Склейка {len(chunk_files)} чанков...")
        logger.info(f"Склейка {len(chunk_files)} чанков в финальный файл")

        final_concat_list = temp_dir / 'final_chunks.txt'
        with open(final_concat_list, 'w', encoding='utf-8') as f:
            for chunk in chunk_files:
                f.write(f"file '{Path(chunk).absolute()}'\n")

        if sub_path:
            # FFmpeg ass= filter chokes on non-ASCII paths — copy to system temp (guaranteed ASCII)
            # Also set fontsdir= so libass finds Book Antiqua from agent/fonts/ on macOS
            import shutil as _shutil, tempfile as _tempfile
            _ass_src = Path(sub_path).absolute()
            _ass_safe = Path(_tempfile.gettempdir()) / '_varagent_subs.ass'
            _shutil.copy2(str(_ass_src), str(_ass_safe))
            _ass_escaped = str(_ass_safe).replace('\\', '/').replace(':', '\\:')
            # Look for agent/fonts/ next to video_concat.py (portable install: project/../../../agent/fonts)
            _fonts_dir = None
            for _cand in [
                Path(__file__).parent / 'agent' / 'fonts',
                Path(__file__).parent.parent / 'agent' / 'fonts',
                Path(__file__).parent.parent.parent / 'agent' / 'fonts',
            ]:
                if _cand.exists():
                    _fonts_dir = _cand
                    break
            if _fonts_dir:
                _fd_escaped = str(_fonts_dir).replace('\\', '/').replace(':', '\\:')
                _vf = f"ass='{_ass_escaped}':fontsdir='{_fd_escaped}'"
                logger.info(f"Subtitle fontsdir: {_fonts_dir}")
            else:
                _vf = f"ass='{_ass_escaped}'"
            if encoder_type == 'amd':
                _vcodec = ['-c:v', 'h264_amf', '-quality', 'quality', '-b:v', bitrate]
            elif encoder_type == 'nvidia':
                _vcodec = ['-c:v', 'h264_nvenc', '-preset', 'p4', '-b:v', bitrate]
            else:
                _vcodec = ['-c:v', 'libx264', '-preset', 'slow', '-crf', '18']
            print(f"   [SUBTITLES] Burning {Path(sub_path).name} into video (re-encoding)...")
            logger.info(f"Subtitle burn-in: encoder={encoder_type} file={sub_path}")
            cmd = [FFMPEG, '-y', '-nostdin', '-f', 'concat', '-safe', '0',
                   '-i', str(final_concat_list), '-vf', _vf] + _vcodec + [
                   '-c:a', 'copy', '-reset_timestamps', '1', str(output_file)]
            # Re-encode with progress bar (reads stdout line-by-line, no RAM buildup)
            run_ffmpeg_with_progress(cmd, total_duration, description="Subtitle burn-in")
            final_concat_list.unlink()
        else:
            cmd = [FFMPEG, '-y', '-nostdin', '-f', 'concat', '-safe', '0',
                   '-i', str(final_concat_list), '-c', 'copy', '-reset_timestamps', '1', str(output_file)]
            try:
                # -c copy is fast — stderr is small, but still write to file not RAM
                _ff_log = Path(output_file).parent / 'ffmpeg_concat.log'
                with open(_ff_log, 'w') as _fl:
                    subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=_fl, **SUBPROCESS_FLAGS)
                final_concat_list.unlink()
            except subprocess.CalledProcessError as e:
                logger.error(f"Ошибка финальной склейки: {e}")
                if _ff_log.exists():
                    _tail = _ff_log.read_text(errors='replace')[-2000:]
                    logger.error(f"FFmpeg stderr (tail): {_tail}")
                logger.error(traceback.format_exc())
                raise

        print(f"   ✅ Готово!")
        logger.info("Финальная склейка чанков завершена")

        for chunk in chunk_files:
            Path(chunk).unlink()

    elapsed = time.time() - start_time
    final_size = get_file_size_mb(output_file)

    logger.info(f"Групповая склейка завершена: размер {final_size:.0f} MB, время {elapsed/60:.1f} мин")

    print(f"\n   ✅ Склейка завершена!")
    print(f"      💾 Размер: {final_size:.0f} MB")
    print(f"      ⏱️  Время: {elapsed/60:.1f} мин")
    print()

def run_ffmpeg_with_progress_by_files(cmd, total_files, description="Склейка"):
    """
    Запускает FFmpeg с прогресс-баром по количеству файлов.
    Используется для склейки через concat demuxer.
    """
    logger.debug(f"Запуск FFmpeg с прогресс-баром по файлам: {description}")

    cmd_with_progress = cmd + ['-progress', 'pipe:1']
    process = subprocess.Popen(cmd_with_progress, stdout=subprocess.PIPE,
                              stderr=subprocess.DEVNULL, universal_newlines=True,
                              **SUBPROCESS_FLAGS)

    start_time = time.time()
    last_refresh = time.time()

    # Прогресс-бар по количеству файлов
    with tqdm(total=total_files, desc=description, unit="файл",
              bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}]') as pbar:
        last_update = start_time

        for line in process.stdout:
            line = line.strip()

            # При склейке ffmpeg не отдаёт точный прогресс,
            # поэтому обновляем плавно по времени
            now = time.time()
            if now - last_update >= 0.2:
                # Эмулируем прогресс по elapsed времени
                elapsed = now - start_time
                # Предполагаем линейную скорость: total_files / estimated_total
                # Но так как не знаем общую длительность, просто пульсим прогресс
                pbar.update(0)  # Обновление без изменения прогресса
                last_update = now

            now = time.time()
            if now - last_refresh >= 1.0:
                pbar.refresh()
                last_refresh = now

    process.wait()

    elapsed = time.time() - start_time
    logger.info(f"{description} завершена за {elapsed:.1f}с")

    if process.returncode != 0:
        logger.error(f"FFmpeg завершился с ошибкой: returncode={process.returncode}")
        raise subprocess.CalledProcessError(process.returncode, cmd)


def run_ffmpeg_with_spinner(cmd, description="Обработка"):
    """
    Запускает FFmpeg со спиннером (анимация ожидания).
    Stdout дренируется в фоновом потоке чтобы не было pipe deadlock.
    """
    logger.debug(f"Запуск FFmpeg со спиннером: {description}")

    process = subprocess.Popen(cmd, stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL,
                               **SUBPROCESS_FLAGS)

    spinners = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
    start_time = time.time()
    spinner_idx = 0
    last_refresh = start_time

    try:
        while process.poll() is None:
            now = time.time()
            if now - last_refresh >= 0.1:
                elapsed = now - start_time
                sys.stdout.write(f'\r   {spinners[spinner_idx]} {description}: {elapsed:.1f}с')
                sys.stdout.flush()
                spinner_idx = (spinner_idx + 1) % len(spinners)
                last_refresh = now
            time.sleep(0.05)

        elapsed = time.time() - start_time
        sys.stdout.write(f'\r   ✅ {description} завершено за {elapsed:.1f}с   \n')
        sys.stdout.flush()
        logger.info(f"{description} завершено за {elapsed:.1f}с")

        if process.returncode != 0:
            logger.error(f"FFmpeg завершился с ошибкой: returncode={process.returncode}")
            raise subprocess.CalledProcessError(process.returncode, cmd)

    except KeyboardInterrupt:
        process.kill()
        sys.stdout.write(f'\r   ❌ {description} прервано   \n')
        sys.stdout.flush()
        raise


def run_ffmpeg_with_progress(cmd, total_duration, description="Processing"):
    """Запускает FFmpeg с прогресс-баром"""
    logger.debug(f"Запуск FFmpeg с прогресс-баром: {description}")

    cmd_with_progress = cmd + ['-progress', 'pipe:1']
    process = subprocess.Popen(cmd_with_progress, stdout=subprocess.PIPE,
                              stderr=subprocess.DEVNULL, universal_newlines=True,
                              **SUBPROCESS_FLAGS)

    start_time = time.time()
    got_any_progress = False
    last_refresh = start_time

    if total_duration is None or total_duration <= 0:
        bar_fmt = None
        tqdm_total = None
    else:
        tqdm_total = round(total_duration, 1)
        bar_fmt = None

    if IS_PIPE:
        # Pipeline mode: drain progress lines, печатаем простой текст каждые 5с
        last_time = 0
        last_pipe_print = start_time
        for line in process.stdout:
            line = line.strip()
            if line.startswith('out_time_us=') or line.startswith('out_time_ms='):
                try:
                    val = line.split('=')[1]
                    if val and val != 'N/A':
                        time_s = int(val) / 1000000.0
                        if time_s > last_time:
                            last_time = time_s
                            got_any_progress = True
                            if tqdm_total and time.time() - last_pipe_print >= 5.0:
                                pct = min(100, int(time_s / tqdm_total * 100))
                                print(f"   {description}: {pct}% ({time_s:.0f}/{tqdm_total:.0f}s)")
                                last_pipe_print = time.time()
                except (ValueError, IndexError):
                    pass
    else:
        # TTY mode: tqdm прогресс-бар
        tqdm_kwargs = dict(total=tqdm_total, desc=description, unit="s")
        if bar_fmt:
            tqdm_kwargs['bar_format'] = bar_fmt
        with tqdm(**tqdm_kwargs) as pbar:
            last_time = 0
            for line in process.stdout:
                line = line.strip()
                if line.startswith('out_time_us=') or line.startswith('out_time_ms='):
                    try:
                        val = line.split('=')[1]
                        if val and val != 'N/A':
                            time_s = int(val) / 1000000.0
                            delta = time_s - last_time
                            if delta > 0:
                                pbar.update(delta)
                                last_time = time_s
                                got_any_progress = True
                    except (ValueError, IndexError):
                        pass
                elif line.startswith('out_time=') and not got_any_progress:
                    try:
                        val = line.split('=')[1]
                        if val and val != 'N/A':
                            parts = val.split(':')
                            time_s = float(parts[0])*3600 + float(parts[1])*60 + float(parts[2])
                            delta = time_s - last_time
                            if delta > 0:
                                pbar.update(delta)
                                last_time = time_s
                    except (ValueError, IndexError):
                        pass
                now = time.time()
                if now - last_refresh >= 1.0:
                    pbar.refresh()
                    last_refresh = now

    process.wait()

    elapsed = time.time() - start_time
    logger.info(f"{description} завершено за {elapsed:.1f}с (прогресс отслеживался: {got_any_progress})")

    if process.returncode != 0:
        logger.error(f"FFmpeg завершился с ошибкой: returncode={process.returncode}")
        raise subprocess.CalledProcessError(process.returncode, cmd)

def ask_delete_temp_folder(temp_dir, no_cleanup=False):
    """Спрашивает пользователя об удалении временной папки"""
    
    # Если --no-cleanup, просто оставляем папку без вопросов
    if no_cleanup:
        logger.info("--no-cleanup: temp папка сохранена")
        print(f"\n🧹 Временная папка: {temp_dir}")
        print(f"   💾 Размер: {sum(f.stat().st_size for f in temp_dir.rglob('*') if f.is_file()) / (1024*1024):.0f} MB")
        print(f"   ✅ Папка сохранена (флаг --no-cleanup)")
        return
    
    print(f"\n🧹 Временная папка: {temp_dir}")
    print(f"   💾 Размер: {sum(f.stat().st_size for f in temp_dir.rglob('*') if f.is_file()) / (1024*1024):.0f} MB")

    # Если stdin не интерактивный (IS_PIPE, subprocess, redirected) — не спрашиваем, удаляем автоматически
    if not sys.stdin.isatty():
        logger.info("stdin не TTY — удаляем temp папку автоматически")
        try:
            shutil.rmtree(temp_dir)
            print(f"   ✅ Папка удалена (auto)")
            logger.info("Временная папка удалена (auto, non-TTY)")
        except Exception as e:
            print(f"   ⚠️  Ошибка удаления: {e}")
        return

    print()
    while True:
        try:
            response = input("Удалить временную папку? (y/n): ").strip().lower()
        except EOFError:
            logger.info("stdin EOF — удаляем temp папку автоматически")
            try:
                shutil.rmtree(temp_dir)
                print(f"\n   ✅ Папка удалена (auto, EOF)")
                logger.info("Временная папка удалена (auto, EOF)")
            except Exception as e:
                print(f"\n   ⚠️  Ошибка удаления: {e}")
            return
        if response in ['y', 'yes', 'д', 'да']:
            logger.info("Пользователь выбрал удалить temp папку")
            try:
                shutil.rmtree(temp_dir)
                print("   ✅ Папка удалена")
                logger.info("Временная папка удалена")
            except Exception as e:
                print(f"   ⚠️  Ошибка удаления: {e}")
                logger.error(f"Ошибка удаления temp папки: {e}")
            break
        elif response in ['n', 'no', 'н', 'нет']:
            logger.info("Пользователь выбрал оставить temp папку")
            print(f"   ✅ Папка сохранена: {temp_dir.absolute()}")
            break
        elif response == '':
            # Enter без ввода — не цикличим, считаем как 'n'
            logger.info("Пустой ввод — temp папка сохранена")
            print(f"   ✅ Папка сохранена")
            break
        else:
            print("   ⚠️  Введите 'y' (удалить) или 'n' (оставить)")

# ============================================================================
# MAIN
# ============================================================================

def main():
    global logger

    # Форсируем line-buffered вывод — без этого BAT накапливает весь вывод и выдаёт разом
    try:
        sys.stdout.reconfigure(line_buffering=True)
    except AttributeError:
        pass  # Python < 3.7

    parser = argparse.ArgumentParser(description='Групповая склейка - v6 OVERLAP GUARD')
    parser.add_argument('plan', help='Путь к montage_plan.json')
    parser.add_argument('-o', '--output', default='result.mp4', help='Выходной файл')
    parser.add_argument('-a', '--audio', default=None, help='Аудио озвучка (по умолчанию ищется любой .wav/.mp3 файл)')
    parser.add_argument('-b', '--bitrate', default='10M', help='Битрейт видео')
    parser.add_argument('-g', '--group-size', type=int, default=9999, help='Размер группы для склейки (по умолчанию 9999 = один проход)')
    parser.add_argument('-r', '--resolution', default=None, help='Разрешение (1080, 720) — опционально, для совместимости')
    parser.add_argument('--no-gpu', action='store_true', help='Использовать CPU вместо GPU')
    parser.add_argument('--force-amd', action='store_true', help='Принудительно использовать AMD GPU')
    parser.add_argument('--force-reprocess', action='store_true', help='Переобработать все файлы')
    parser.add_argument('--logo', default=None, help='PNG лого для наложения (правый нижний угол). Если не указан — ищется logo.png в папке проекта')
    parser.add_argument('--blur-borders', action='store_true', help='Размыть границы видео (защита от водяных знаков)')
    parser.add_argument('--no-cleanup', action='store_true', help='Не удалять temp_processed после завершения')
    parser.add_argument('--veo-audio-inline', action='store_true', help='Оставить VEO аудио прямо на видеоряде (для script-mode без нарации — итоговый concat будет со звуком VEO)')
    parser.add_argument('--subtitles', default=None, help='Путь к .ass файлу субтитров для выжигания. Используй "auto" для авто-поиска *.ass в папке проекта.')
    parser.add_argument('--fps', type=int, default=60, choices=[24, 25, 30, 50, 60],
                        help='FPS для зум-видео из изображений и freeze-frame (default=60)')
    args = parser.parse_args()

    # НАСТРОЙКА ЛОГГИРОВАНИЯ
    logger, log_file = setup_logging()

    logger.info(f"Параметры запуска:")
    logger.info(f"  plan: {args.plan}")
    logger.info(f"  output: {args.output}")
    logger.info(f"  audio: {args.audio}")
    logger.info(f"  bitrate: {args.bitrate}")
    logger.info(f"  group_size: {args.group_size}")
    logger.info(f"  resolution: {args.resolution}")
    logger.info(f"  no_gpu: {args.no_gpu}")
    logger.info(f"  force_amd: {args.force_amd}")
    logger.info(f"  force_reprocess: {args.force_reprocess}")
    logger.info(f"  logo: {args.logo}")
    logger.info(f"  blur_borders: {args.blur_borders}")
    logger.info(f"  no_cleanup: {args.no_cleanup}")
    logger.info(f"  veo_audio_inline: {args.veo_audio_inline}")
    logger.info(f"  subtitles: {args.subtitles}")

    print("="*80)
    print("[VIDEO] ГРУППОВАЯ СКЛЕЙКА - v6 OVERLAP GUARD")
    print("="*80)
    print(f"\n[LOG] Лог-файл: {log_file}")

    # Авто-rename vid_img/ и generated/ в 3-значный формат перед склейкой.
    # Источники генераций часто пишут файлы с длинными именами
    # (banana_0001_Late Renaissance_...png, veo3_generation_abc123.mp4 и т.п.),
    # склейка ожидает 001.mp4 / 001.png. rename_videos.py идемпотентен —
    # повторный вызов на уже переименованных файлах ничего не делает.
    try:
        _proj_dir = Path(args.plan).resolve().parent
        for _sub in ('vid_img', 'generated'):
            _sd = _proj_dir / _sub
            if not _sd.is_dir():
                continue
            print(f"\n[AUTO-RENAME] {_sub}/ → 3-digit format...")
            try:
                import sys as _sys
                _agent_dir = (Path(__file__).resolve().parent / 'agent')
                if str(_agent_dir) not in _sys.path:
                    _sys.path.insert(0, str(_agent_dir))
                from rename_videos import rename_videos as _rv
                _ok, _err, _w = _rv(directory=_sd, dry_run=False, verbose=False, zero_pad=3)
                print(f"  renamed OK={_ok}, errors={_err}, warnings={len(_w)}")
            except Exception as _re:
                print(f"  [WARN] auto-rename failed ({_re}) — продолжаем с тем что есть")
    except Exception:
        pass

    # Определение энкодера
    encoder_type, codec = ('cpu', 'libx264') if args.no_gpu else detect_gpu_encoder(args.force_amd)

    if encoder_type == 'nvidia':
        print("\n[OK] NVIDIA GPU - h264_nvenc")
    elif encoder_type == 'amd':
        print("\n[OK] AMD GPU - h264_amf")
    else:
        print("\n[INFO] CPU - libx264")

    print(f"[INFO] Битрейт: {args.bitrate}")
    print(f"[INFO] План: {args.plan}")

    # Определение пути к .ass субтитрам (если переданы)
    _sub_path = None
    if args.subtitles:
        if args.subtitles.lower() == 'auto':
            _ass_files = _glob.glob('*.ass')
            if _ass_files:
                _sub_path = str(Path(_ass_files[0]).absolute())
                print(f"[SUBTITLES] Auto-detected: {Path(_sub_path).name}")
                logger.info(f"Subtitles auto-detected: {_sub_path}")
            else:
                logger.info("Subtitles: auto mode, no .ass file found in project folder")
        elif os.path.exists(args.subtitles):
            _template_path = str(Path(args.subtitles).absolute())
            # Если передан .ass шаблон — ищем SRT в папке проекта и мержим
            _srt_candidates = [
                Path(args.plan).parent / 'SRT' / 'subtitles.srt',
                Path(args.plan).parent / 'SRT' / 'subtitles_split.srt',
            ]
            _srt_found = next((p for p in _srt_candidates if p.exists()), None)
            if _srt_found:
                _merged_ass = Path(args.plan).parent / 'SRT' / '_subtitles_merged.ass'
                _srt_to_ass(str(_srt_found), _template_path, str(_merged_ass))
                _sub_path = str(_merged_ass.absolute())
                print(f"[SUBTITLES] Template: {Path(_template_path).name} + SRT: {_srt_found.name} → merged")
                logger.info(f"Subtitles merged: {_sub_path}")
            else:
                # Нет SRT — выжигаем шаблон как есть (если в нём уже есть события)
                _sub_path = _template_path
                print(f"[SUBTITLES] Template only (no SRT found): {Path(_sub_path).name}")
                logger.info(f"Subtitles template only: {_sub_path}")
        else:
            print(f"[SUBTITLES] WARNING: file not found: {args.subtitles}")
            logger.warning(f"Subtitles file not found: {args.subtitles}")

    # Загрузка плана
    try:
        logger.info(f"Загрузка плана: {args.plan}")
        with open(args.plan, 'r', encoding='utf-8-sig') as f:
            plan = json.load(f)
        logger.info("План загружен успешно")
    except (FileNotFoundError, json.JSONDecodeError) as e:
        logger.error(f"Ошибка загрузки плана: {e}")
        logger.error(traceback.format_exc())
        print(f"❌ Ошибка загрузки плана: {e}")
        sys.exit(1)

    clips = plan.get('clips', [])
    if not clips:
        logger.error("Нет clips в плане")
        print("❌ Нет clips в плане!")
        sys.exit(1)

    # -----------------------------------------------------------------------
    # СОРТИРОВКА ПО startTime
    # Gemini иногда вставляет клипы не в том порядке в JSON-массив.
    # Сортируем по startTime, чтобы гарантировать правильный порядок склейки.
    # -----------------------------------------------------------------------
    ids_before = [c['id'] for c in clips]
    clips = sorted(clips, key=lambda c: c['startTime'])
    ids_after = [c['id'] for c in clips]

    misplaced = [ids_before[i] for i in range(len(ids_before)) if ids_before[i] != ids_after[i]]
    if misplaced:
        logger.warning(f"Клипы переупорядочены по startTime! Было не на месте: {misplaced}")
        print(f"\n⚠️  ПРЕДУПРЕЖДЕНИЕ: {len(misplaced)} клипов были не в хронологическом порядке в JSON")
        print(f"   Переставлены: {misplaced}")
        print(f"   (Gemini иногда вставляет клипы не на своё место — теперь исправлено)")
    else:
        logger.info("Порядок клипов по startTime: OK")

    # Поиск аудиофайла если не указан
    audio_file = args.audio
    if audio_file is None:
        logger.debug(f"Audio auto-search in cwd: {Path('.').resolve()}")
        all_audio = []
        for ext in ['*.wav', '*.WAV', '*.mp3', '*.MP3', '*.Mp3',
                    '*.flac', '*.FLAC', '*.m4a', '*.M4A', '*.aac', '*.AAC']:
            found = [f for f in Path('.').glob(ext) if '_original_audio' not in f.name]
            all_audio.extend(found)
            if found and audio_file is None:
                audio_file = str(found[0])
        if all_audio:
            logger.debug(f"Audio files found: {[f.name for f in all_audio]}")
        else:
            logger.debug(f"No audio files found. Files in cwd: {[f.name for f in Path('.').iterdir() if f.is_file()][:20]}")

    if audio_file is None or not os.path.exists(str(audio_file)):
        if getattr(args, 'veo_audio_inline', False):
            logger.warning("Нарация не найдена — veo-audio-inline режим: видео будет БЕЗ нарации, только VEO-звук")
            print(f"\n⚠️  ВНИМАНИЕ: Аудиофайл нарации не найден в папке проекта!")
            print(f"   cwd: {Path('.').resolve()}")
            print(f"   Видео будет собрано БЕЗ нарации (только VEO-звук клипов)")
            print(f"   Чтобы добавить нарацию — положите .mp3/.wav в папку проекта и перезапустите concat\n")
            audio_file = None
        else:
            logger.error(f"Аудио файл не найден")
            print(f"❌ Аудио файл не найден!")
            print(f"   Положите .wav, .mp3, .flac, .m4a или .aac в папку проекта")
            print(f"   Или укажите явно: -a имя_файла.wav")
            sys.exit(1)

    logger.info(f"Используемый аудиофайл: {audio_file}")

    # Поиск лого для наложения (logo.png в текущей папке или --logo)
    logo_path = None
    if args.logo:
        if os.path.exists(args.logo):
            logo_path = Path(args.logo)
            print(f"[INFO] Лого: {logo_path}")
        else:
            print(f"⚠️  Лого не найдено: {args.logo} — продолжаем без лого")
    else:
        auto_logo = Path('logo.png')
        if auto_logo.exists():
            logo_path = auto_logo
            print(f"[INFO] Лого найдено: logo.png")
    if logo_path:
        logger.info(f"Лого overlay: {logo_path}")
    else:
        logger.info("Лого overlay: не используется")

    try:
        # ЭТАП 1: ВАЛИДАЦИЯ ПЛАНА
        audio_duration = validate_montage_plan(clips, audio_file)

        # ЭТАП 2: АНАЛИЗ ГЭПОВ И ПЕРЕКРЫТИЙ
        corrections = analyze_gaps(clips, audio_duration)

        temp_dir = Path('temp_processed')
        temp_dir.mkdir(exist_ok=True)
        logger.info(f"Создана временная папка: {temp_dir.absolute()}")

        # Применяем корректировки к clips
        corrected_clips = clips.copy()
        for corr in corrections:
            idx = corr['clip_index']
            if corr['type'] == 'start_gap':
                corrected_clips[idx] = {
                    **corrected_clips[idx],
                    'startTime': 0.0,
                    'original_startTime': corrected_clips[idx]['startTime']
                }
            elif corr['type'] == 'end_gap':
                corrected_clips[idx] = {
                    **corrected_clips[idx],
                    'endTime': audio_duration,
                    'original_endTime': corrected_clips[idx]['endTime']
                }
            elif corr['type'] == 'retime_extend':
                corrected_clips[idx] = {
                    **corrected_clips[idx],
                    'endTime': corrected_clips[idx]['endTime'] + corr['gap_size'],
                    'original_endTime': corrected_clips[idx]['endTime']
                }
            elif corr['type'] == 'trim_overlap':
                corrected_clips[idx] = {
                    **corrected_clips[idx],
                    'endTime': corr['new_end'],
                    'original_endTime': corrected_clips[idx]['endTime']
                }

        # ЭТАП 3: ПРОВЕРКА СУЩЕСТВУЮЩИХ ФАЙЛОВ
        logger.info("ЭТАП 3: ПРОВЕРКА СУЩЕСТВУЮЩИХ ФАЙЛОВ")
        existing_files = {}
        if not args.force_reprocess:
            print(f"\n🔍 Проверка существующих файлов...")
            _total_clips = len(corrected_clips)
            if IS_PIPE:
                print(f"PROGRESS:0/{_total_clips}", flush=True)
            _check_iter = corrected_clips if IS_PIPE else tqdm(
                corrected_clips, desc="   Checking", unit="clip",
                bar_format="{desc}: {bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]"
            )
            for _ci, clip in enumerate(_check_iter, 1):
                clip_id = clip['id']
                target_duration = clip['endTime'] - clip['startTime']
                output_file = temp_dir / f"processed_{clip_id}.mp4"

                if check_processed_file(output_file):
                    actual_dur = get_video_duration(output_file)
                    if abs(actual_dur - target_duration) < 0.1:
                        # При 1080p — дополнительно проверяем что файл уже в 1920x1080
                        if args.resolution == '1080':
                            w, h = get_video_resolution(output_file)
                            if w != 1920 or h != 1080:
                                logger.debug(f"Файл {clip_id} не 1080p ({w}x{h}), пересоздаём")
                                continue
                        existing_files[clip_id] = str(output_file)
                        logger.debug(f"Файл {clip_id} уже готов")

                if IS_PIPE:
                    print(f"PROGRESS:{_ci}/{_total_clips}", flush=True)

            logger.info(f"Найдено готовых файлов: {len(existing_files)}")
            logger.info(f"Требуют обработки: {len(corrected_clips) - len(existing_files)}")

            print(f"   ✅ Найдено готовых: {len(existing_files)}")
            print(f"   🔄 Требуют обработки: {len(corrected_clips) - len(existing_files)}")
        else:
            logger.info("Режим force_reprocess - все файлы будут переобработаны")
            print(f"\n⚠️  Режим --force-reprocess: переобработка всех файлов")

        # ЭТАП 4: ОБРАБОТКА КЛИПОВ
        logger.info("ЭТАП 4: РЕТАЙМИНГ ФРАГМЕНТОВ")
        files_to_process = []
        for clip in corrected_clips:
            if clip['id'] not in existing_files:
                files_to_process.append(clip)

        # Папка для ретаймленных фрагментов с оригинальным VEO аудио

        # Кумулятивный трекер дрифта: разница Σ(actual) - Σ(planned).
        # При ретайминге каждого следующего клипа вычитаем накопленный дрифт из target_duration,
        # чтобы итоговая сумма клипов точно совпала с длиной аудио (без re-encode в финале).
        cumulative_planned = 0.0   # сумма target_duration из плана
        cumulative_actual  = 0.0   # сумма фактических длин выходных клипов

        if files_to_process:
            logger.info(f"Требуют ретайминга: {len(files_to_process)} файлов")
            print(f"\n🔄 Ретайминг {len(files_to_process)} фрагментов (с коррекцией дрифта)...", flush=True)
            files_to_process_ids = {clip['id'] for clip in files_to_process}
            _retime_total = len(files_to_process)
            _retime_done = 0
            if IS_PIPE:
                print(f"PROGRESS:0/{_retime_total}", flush=True)
                print(f"   Всего к ретаймингу: {_retime_total}", flush=True)
            _retime_pbar = None if IS_PIPE else tqdm(
                total=_retime_total, desc="   Ретайминг", unit="фр",
                bar_format="{desc}: {bar}| {n}/{total} фрагментов [{elapsed}<{remaining}]"
            )
            # Auto-detect target resolution: если в vid_img/ есть 1080p клипы,
            # то 720p клипы (упавшие апскейлы) автоматически масштабируются до 1080p.
            _auto_target_1080 = False
            _vid_img_prescan = Path('vid_img')
            if _vid_img_prescan.exists():
                _max_prescan_h = 0
                for _pf in _vid_img_prescan.glob('*.mp4'):
                    _, _ph = get_video_resolution(str(_pf))
                    if _ph > _max_prescan_h:
                        _max_prescan_h = _ph
                if _max_prescan_h >= 1080:
                    _auto_target_1080 = True
                    logger.info(f"Auto-upscale: detected {_max_prescan_h}px source clips — sub-1080p clips will be scaled to 1080p")
                    print(f"   Авто-апскейл: найдены {_max_prescan_h}p клипы — 720p клипы будут отмасштабированы до 1080p", flush=True)
            # Итерируем ВСЕ клипы в порядке монтажного плана для корректного трекинга дрифта.
            # Для уже готовых клипов — только читаем фактическую длину и обновляем счётчики.
            for clip in corrected_clips:
                    clip_id = clip['id']
                    target_duration = clip['endTime'] - clip['startTime']
                    output_file = temp_dir / f"processed_{clip_id}.mp4"

                    if clip_id not in files_to_process_ids:
                        # Файл уже готов — обновляем трекеры без перекодирования
                        actual_dur = get_video_duration(output_file)
                        cumulative_planned += target_duration
                        cumulative_actual  += actual_dur
                        continue

                    # Кумулятивный дрифт: если положительный — мы уже "убежали" вперёд,
                    # нужно укоротить текущий клип; если отрицательный — мы отстаём.
                    drift = cumulative_actual - cumulative_planned
                    adjusted_target = max(0.1, target_duration - drift)
                    if abs(drift) > 0.001:
                        logger.debug(f"Clip {clip_id}: drift={drift:+.4f}с → target {target_duration:.4f}с → adjusted {adjusted_target:.4f}с")

                    # Определяем источник: vid_img/{id:03d}.mp4 → clip['file'] → fallback
                    source_file = None
                    vid_img_dir = Path('vid_img')
                    for fmt in [f'{clip_id:03d}', str(clip_id)]:
                        for ext in ('mp4', 'mov', 'png', 'jpg', 'jpeg', 'webp'):
                            candidate = vid_img_dir / f'{fmt}.{ext}'
                            if candidate.exists():
                                source_file = str(candidate)
                                break
                        if source_file:
                            break
                    if not source_file:
                        cf = clip.get('file')
                        if cf and Path(cf).exists():
                            source_file = cf
                    if not source_file:
                        # Slideshow fallback: look for image in generated/
                        gen_dir = Path('generated')
                        for fmt in [f'{clip_id:03d}', str(clip_id)]:
                            for ext in ('png', 'jpg', 'jpeg', 'webp'):
                                candidate = gen_dir / f'{fmt}.{ext}'
                                if candidate.exists():
                                    source_file = str(candidate)
                                    break
                            if source_file:
                                break
                    if not source_file:
                        logger.error(f"Clip {clip_id}: файл не найден (clip['file']={clip.get('file')}, vid_img/ пусто)")
                        print(f"\n❌ Clip {clip_id}: файл не найден! Проверьте vid_img/")
                        sys.exit(1)

                    try:
                        # Per-clip upscale: явный -r 1080, либо авто если в проекте смешанные разрешения
                        if Path(source_file).suffix.lower() not in _IMAGE_EXTENSIONS:
                            _, _src_h = get_video_resolution(source_file)
                            _per_clip_upscale = (args.resolution == '1080') or (_auto_target_1080 and 0 < _src_h < 1080)
                        else:
                            _per_clip_upscale = (args.resolution == '1080')
                        actual_dur = process_video(source_file, str(output_file), adjusted_target,
                                    encoder_type, codec, args.bitrate, logo_path=logo_path,
                                    blur_borders=args.blur_borders,
                                    keep_audio=getattr(args, 'veo_audio_inline', False),
                                    upscale_1080=_per_clip_upscale,
                                    fps=getattr(args, 'fps', 60))
                        if actual_dur is None:
                            actual_dur = get_video_duration(output_file) if Path(output_file).exists() else None
                        if actual_dur is None:
                            # Corrupt video — try static fallback from generated/ image
                            _gen_dir = Path(source_file).parent.parent / 'generated'
                            _fallback_img = None
                            for _ext in ('.png', '.jpg', '.jpeg', '.webp'):
                                _candidate = _gen_dir / f"{clip_id:03d}{_ext}"
                                if _candidate.exists() and _candidate.stat().st_size > 1000:
                                    _fallback_img = str(_candidate)
                                    break
                            if _fallback_img:
                                logger.warning(f"Clip {clip_id}: corrupt video {source_file} — fallback to image {_fallback_img}")
                                print(f"   ⚠️  Clip {clip_id}: битый видео → зум из картинки")
                                _image_to_zoom_video(_fallback_img, str(output_file), adjusted_target,
                                                     encoder_type, codec, args.bitrate, logo_path=logo_path,
                                                     fps=getattr(args, 'fps', 60))
                                actual_dur = get_video_duration(output_file) if Path(output_file).exists() else adjusted_target
                                if actual_dur is None:
                                    actual_dur = adjusted_target
                            else:
                                raise RuntimeError(f"Clip {clip_id}: corrupt video {source_file} and no fallback image in generated/")
                        existing_files[clip_id] = str(output_file)
                        cumulative_planned += target_duration
                        cumulative_actual  += actual_dur

                        _retime_done += 1
                        if IS_PIPE:
                            print(f"   Ретайминг: {_retime_done}/{_retime_total} (clip {clip_id})", flush=True)
                        elif _retime_pbar is not None:
                            _retime_pbar.update(1)
                    except Exception as e:
                        logger.error(f"Критическая ошибка обработки clip {clip_id}: {e}")
                        print(f"\n❌ Ошибка обработки: {e}")
                        sys.exit(1)

            if _retime_pbar is not None:
                _retime_pbar.close()
            total_drift = cumulative_actual - cumulative_planned
            logger.info(f"Ретайминг завершён. Суммарный дрифт после коррекции: {total_drift:+.3f}с")
            print(f"   📊 Суммарный дрифт после коррекции: {total_drift:+.3f}с")
        else:
            logger.info("Все файлы уже обработаны")
            print(f"\n✅ Все файлы уже обработаны")

        # Формируем упорядоченный список обработанных файлов
        print(f"\n📦 Формирование финального списка файлов...")
        logger.info("Формирование финального списка файлов")
        processed_files_ordered = []

        for clip in corrected_clips:
            clip_id = clip['id']
            processed_files_ordered.append(existing_files[clip_id])

        logger.info(f"Всего файлов для склейки: {len(processed_files_ordered)}")
        print(f"   ✅ Всего файлов для склейки: {len(processed_files_ordered)}")

        # ЭТАП 5: ГРУППОВАЯ СКЛЕЙКА
        temp_video = temp_dir / 'concat_video.mp4'
        group_concat(processed_files_ordered, temp_video, temp_dir, args.group_size, sub_path=_sub_path, encoder_type=encoder_type, bitrate=args.bitrate, total_duration=audio_duration)

        # ЭТАП 6: АВТОИСПРАВЛЕНИЕ ФИНАЛЬНОЙ СИНХРОНИЗАЦИИ
        if audio_file is not None:
            temp_video = fix_video_audio_sync(temp_video, audio_file, temp_dir,
                                              encoder_type, codec, args.bitrate)
        else:
            logger.info("ЭТАП 6: пропуск (нет нарации, veo-audio-inline режим)")

        # ЭТАП 7: ИЗВЛЕЧЕНИЕ ОРИГИНАЛЬНОГО АУДИО
        logger.info("ЭТАП 7: ИЗВЛЕЧЕНИЕ ОРИГИНАЛЬНОГО АУДИО")
        print(f"\n🔊 Извлечение оригинального аудио...")
        original_audio = args.output.replace('.mp4', '_original_audio.wav')
        try:
            subprocess.run([FFMPEG, '-y', '-i', str(temp_video),
                           '-vn', '-acodec', 'pcm_s16le', original_audio],
                          check=True, capture_output=True, **SUBPROCESS_FLAGS)
            logger.info(f"Оригинальное аудио извлечено: {original_audio}")
            print(f"   ✅ {original_audio}")
        except Exception as e:
            logger.warning(f"Не удалось извлечь оригинальное аудио: {e}")
            print(f"   ⚠️  Не удалось")

        # ЭТАП 8: ЗАМЕНА АУДИО (или копирование temp_video в veo-audio-inline режиме без нарации)
        if audio_file is not None:
            logger.info("ЭТАП 8: ЗАМЕНА АУДИО НА ОЗВУЧКУ")

            print(f"\n🎵 Замена аудио на озвучку...")
            pre_encoded_audio = temp_dir / 'narration_aac.m4a'
            if IS_PIPE:
                print(f"PROGRESS:0/2", flush=True)
            print(f"   Шаг 1/2: Кодирование аудио WAV → AAC...")
            cmd_aac = [FFMPEG, '-y', '-i', audio_file,
                       '-c:a', 'aac', '-b:a', '192k', str(pre_encoded_audio)]
            aac_duration = audio_duration if audio_duration else None
            try:
                run_ffmpeg_with_progress(cmd_aac, aac_duration, "AAC кодирование")
                logger.info(f"Аудио предварительно закодировано")
            except subprocess.CalledProcessError as e:
                logger.error(f"Ошибка кодирования аудио: {e}")
                raise

            print(f"   Шаг 2/2: Сборка видео + аудио (без перекодирования)...")
            cmd_mux = [FFMPEG, '-y', '-i', str(temp_video), '-i', str(pre_encoded_audio),
                       '-map', '0:v', '-map', '1:a', '-c:v', 'copy',
                       '-c:a', 'copy', '-shortest', args.output]

            run_ffmpeg_with_progress(cmd_mux, aac_duration, "Сборка")
            logger.info(f"Финальный файл создан: {args.output}")

            try:
                pre_encoded_audio.unlink()
            except:
                pass
        else:
            # veo-audio-inline без нарации: temp_video уже содержит ретаймленный VEO звук
            logger.info("ЭТАП 8: пропуск замены аудио — копируем temp_video с VEO звуком в выходной файл")
            print(f"\n[OK] VEO audio inline: сохраняем VEO звук в финальном видео...")
            shutil.copy2(str(temp_video), args.output)
            logger.info(f"Финальный файл создан (VEO audio): {args.output}")

        # ЭТАП 9: ОЧИСТКА
        logger.info("ЭТАП 9: ОЧИСТКА")
        ask_delete_temp_folder(temp_dir, args.no_cleanup)

        # ФИНАЛ
        print("\n" + "="*80)
        print("✅ ГОТОВО!")
        print("="*80)
        print(f"\n📹 Видео: {args.output}")
        print(f"   • FPS: {getattr(args, 'fps', 60)}")
        print(f"   • Битрейт: {args.bitrate}")
        print(f"   • Кодек: {codec} ({encoder_type.upper()})")
        print(f"\n🔊 Оригинальное аудио: {original_audio}")
        print(f"🎵 Озвучка: {audio_file if audio_file else '(VEO audio inline — нарация не использовалась)'}")
        print(f"\n📝 Лог-файл: {log_file}")
        print("="*80)

        logger.info("="*80)
        logger.info("СКРИПТ ЗАВЕРШЁН УСПЕШНО")
        logger.info("="*80)

    except Exception as e:
        logger.critical("КРИТИЧЕСКАЯ ОШИБКА!")
        logger.critical(f"Ошибка: {e}")
        logger.critical(traceback.format_exc())
        print(f"\n❌ КРИТИЧЕСКАЯ ОШИБКА: {e}")
        print(f"\n📝 Подробности в лог-файле: {log_file}")
        sys.exit(1)

if __name__ == '__main__':
    main()
