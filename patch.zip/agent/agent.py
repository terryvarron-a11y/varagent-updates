#!/usr/bin/env python3
"""
Video Production Agent - Главный скрипт
Автоматизация создания видео через AI
"""
import argparse
import subprocess
import sys
import os
from pathlib import Path
from datetime import datetime
import json
import logging
import traceback
import time
from datetime import datetime as dt
from typing import Optional
from tqdm import tqdm


class _TeeStream:
    """Дублирует stdout в файл."""
    def __init__(self, original, file_handle):
        self._orig = original
        self._file = file_handle
    def write(self, data):
        self._orig.write(data)
        try:
            self._file.write(data)
            self._file.flush()
        except Exception:
            pass
    def flush(self):
        self._orig.flush()
        try:
            self._file.flush()
        except Exception:
            pass
    def __getattr__(self, name):
        return getattr(self._orig, name)

# Установка UTF-8 кодировки для Windows (консоль + вывод)
if sys.platform == 'win32':
    os.system('chcp 65001 >nul')
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')

# Добавляем путь к модулям
sys.path.insert(0, str(Path(__file__).parent))

import config
from modules.transcriber import AssemblyAITranscriber, transcribe_audio
from modules.director import GeminiDirector, direct_project
from modules.script_director import GeminiScriptDirector, script_direct_project
from modules.validator import (
    validate_transcription_json,
    validate_montage_plan_json,
    validate_json_file,
    validate_file_exists
)
from modules.queue import (
    get_ready_files,
    get_sg_all_file,
    get_all_style_guides_for_audio,
    setup_project,
    create_process_batch_files,
    create_fragment_checker
)
from modules.fastgen import generate_all_images
from modules.yt_packer import run_yt_packer
from modules.veo_video import generate_all_videos as veo_generate_all_videos
from modules.imggen import generate_all_images as veo_generate_all_images
from modules.cinai import generate_all_images as cinai_generate_all_images
from modules.cinai_video import (
    generate_all_videos as cinai_generate_all_videos,
    merge_video_outputs as cinai_merge_video_outputs,
)
from modules.ref_compress import compress_refs
from modules.pipeline_video_modes import (
    INTRO_I2V_T2V_MODE,
    split_intro_i2v_t2v_clip_ids,
)


POST_ACTION_ALIASES = {
    # Legacy names from the mistaken CinAI composite route. CinAI is an
    # ImageGen provider; VeoNonStop remains the video stage.
    "cinai_i2v": "veo_i2v",
    "cinai_veo_i2v": "veo_i2v",
}

POST_ACTION_CHOICES = [
    "skip",
    "fastgen",
    "imggen",
    "cinai",
    "fastgen_i2v",
    "veo_i2v",
    "both_i2v",
    INTRO_I2V_T2V_MODE,
    "t2v",
    "i2v",
    "first_last",
    "reference",
    "components",
    "cinai_components",
    "fastgen_ultra_t2v",
    "fastgen_ultra_ingredients",
    "fastgen_ultra_i2v",
]


def _parse_post_action(value: str) -> str:
    """Normalize legacy composite-route names before argparse validation."""
    return POST_ACTION_ALIASES.get(value, value)


# ============================================================================
# YT PACKER: ИНТЕРАКТИВНЫЙ ЗАПУСК ПОСЛЕ ПРОМПТОВ
# ============================================================================

def _ask_yt_packer(project_dir: str, source_lang: str = None) -> bool:
    """
    Спрашивает юзера запустить ли YT Packer после создания промптов.
    source_lang — язык транскрипции (из AssemblyAI), автоматически ставится первым в YT_PACK_LANGUAGES.
    Возвращает True если запущен и успешен.
    """
    # Подставляем язык транскрипции как исходный язык YT Packer
    if source_lang:
        other_langs = [l for l in config.YT_PACK_LANGUAGES if l != source_lang]
        config.YT_PACK_LANGUAGES = [source_lang] + other_langs

    print()
    print("=" * 60)
    print("  YT PACKER — YouTube packaging")
    print("=" * 60)
    print()
    choice = input("  Run YT Packer? (y/n, Enter=n): ").strip().lower()
    if choice != 'y':
        print("  [SKIP] YT Packer skipped.")
        return False

    print()
    print("  Mode:")
    print("    [1] Silent      (use .env defaults, show & confirm)")
    print("    [2] Interactive (ask each parameter)")
    print()
    mode = input("  Choose [1/2] (Enter=1): ").strip()

    if mode == '2':
        _yt_packer_interactive()
    else:
        _yt_packer_silent()

    # Запуск
    try:
        run_yt_packer(project_dir)
        return True
    except Exception as e:
        print(f"\n  [ERROR] YT Packer failed: {e}")
        logging.debug(traceback.format_exc())
        return False


def _yt_packer_silent():
    """Показывает текущие настройки YT Packer из .env, спрашивает подтверждение."""
    print()
    print("  " + "-" * 50)
    print("  YT PACKER SETTINGS (from .env)")
    print("  " + "-" * 50)
    print(f"  Languages:    {', '.join(config.YT_PACK_LANGUAGES)}")
    print(f"  Model:        {config.YT_PACK_MODEL}")
    print(f"  Subtitles:    {'ON' if config.YT_PACK_SUBTITLES else 'OFF'}")
    print(f"  Description:  {'ON' if config.YT_PACK_DESCRIPTION else 'OFF'}")
    print(f"  Covers:       {'ON' if config.YT_PACK_COVERS else 'OFF'}")
    if config.YT_PACK_COVERS:
        print(f"  Cover model:  {config.YT_PACK_COVER_MODEL}")
        print(f"  Cover count:  {config.YT_PACK_COVER_COUNT}")
    print("  " + "-" * 50)
    print()

    confirm = input("  All correct? (y/n, Enter=y): ").strip().lower()
    if confirm == 'n':
        print("  Switching to interactive mode...")
        _yt_packer_interactive()


def _yt_packer_interactive():
    """Спрашивает каждый параметр YT Packer у пользователя."""
    print()
    print("  " + "-" * 50)
    print("  YT PACKER INTERACTIVE SETUP")
    print("  " + "-" * 50)

    # Languages
    print()
    current_langs = ','.join(config.YT_PACK_LANGUAGES)
    langs_input = input(f"  Languages (comma-separated) [{current_langs}]: ").strip()
    if langs_input:
        config.YT_PACK_LANGUAGES = [l.strip() for l in langs_input.split(',') if l.strip()]

    # Models
    models = {'1': 'gemini-2.5-flash', '2': 'gemini-2.5-pro', '3': 'gemini-2.0-flash'}
    print()
    print("  Model for subtitle TRANSLATION (cheap/fast):")
    print("    [1] gemini-2.5-flash       (fast, default)")
    print("    [2] gemini-2.5-pro         (quality)")
    print("    [3] gemini-2.0-flash       (ultra-fast)")
    print()
    m = input(f"  Translation model [1/2/3] (Enter={config.YT_PACK_TRANSLATE_MODEL}): ").strip()
    if m in models:
        config.YT_PACK_TRANSLATE_MODEL = models[m]

    print()
    print("  Model for CONTENT (titles/description/tags/covers):")
    print("    [1] gemini-2.5-flash       (fast, default)")
    print("    [2] gemini-2.5-pro         (quality)")
    print("    [3] gemini-2.0-flash       (ultra-fast)")
    print()
    m = input(f"  Content model [1/2/3] (Enter={config.YT_PACK_CONTENT_MODEL}): ").strip()
    if m in models:
        config.YT_PACK_CONTENT_MODEL = models[m]

    # Subtitles
    print()
    sub = input(f"  Generate subtitles? (y/n) [{'y' if config.YT_PACK_SUBTITLES else 'n'}]: ").strip().lower()
    if sub in ('y', 'n'):
        config.YT_PACK_SUBTITLES = (sub == 'y')

    # Description
    desc = input(f"  Generate description/titles/tags? (y/n) [{'y' if config.YT_PACK_DESCRIPTION else 'n'}]: ").strip().lower()
    if desc in ('y', 'n'):
        config.YT_PACK_DESCRIPTION = (desc == 'y')

    # Covers
    cov = input(f"  Generate covers? (y/n) [{'y' if config.YT_PACK_COVERS else 'n'}]: ").strip().lower()
    if cov in ('y', 'n'):
        config.YT_PACK_COVERS = (cov == 'y')

    if config.YT_PACK_COVERS:
        count = input(f"  Cover count [1-8] ({config.YT_PACK_COVER_COUNT}): ").strip()
        if count.isdigit() and 1 <= int(count) <= 8:
            config.YT_PACK_COVER_COUNT = int(count)

    print()
    print(f"  Settings applied: langs={','.join(config.YT_PACK_LANGUAGES)}, "
          f"translate_model={config.YT_PACK_TRANSLATE_MODEL}, "
          f"content_model={config.YT_PACK_CONTENT_MODEL}, "
          f"subs={'ON' if config.YT_PACK_SUBTITLES else 'OFF'}, "
          f"desc={'ON' if config.YT_PACK_DESCRIPTION else 'OFF'}, "
          f"covers={'ON' if config.YT_PACK_COVERS else 'OFF'}")


# ============================================================================
# USATAYAI GENERATOR BRIDGE
# ============================================================================

def _maybe_run_usatayai_generator_bridge(project_dir: str, action: str, prompt_mode: str = 'single') -> bool:
    """Optional external video-generator bridge for USATAYAI.

    Enabled only when env USATAYAI_GENERATOR_BRIDGE_MANIFEST points to a JSON manifest.
    Returns True when the bridge handled video generation and VAR can continue to concat.
    Returns False when no bridge is enabled and native VAR generation must run as before.
    Raises RuntimeError when bridge is enabled but failed.
    """
    manifest_path = os.environ.get('USATAYAI_GENERATOR_BRIDGE_MANIFEST', '').strip()
    if not manifest_path:
        return False

    bridge_py = Path(__file__).resolve().parent / 'bridges' / 'usatayai_generator_bridge.py'
    if not bridge_py.exists():
        raise RuntimeError(f'USATAYAI generator bridge not found: {bridge_py}')

    cmd = [
        sys.executable,
        str(bridge_py),
        '--manifest', manifest_path,
        '--project', str(project_dir),
        '--action', str(action or ''),
        '--prompt-mode', str(prompt_mode or 'single'),
    ]

    print(f"  [USATAYAI-GEN-BRIDGE] enabled: {bridge_py.name}", flush=True)
    print(f"  [USATAYAI-GEN-BRIDGE] manifest: {manifest_path}", flush=True)

    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding='utf-8',
        errors='replace',
    )

    try:
        for line in proc.stdout:
            line = line.rstrip('\n\r')
            if line:
                print(line, flush=True)
    finally:
        rc = proc.wait()

    if rc != 0:
        raise RuntimeError(f'USATAYAI generator bridge failed with code {rc}')

    print("  [USATAYAI-GEN-BRIDGE] done -> vid_img/", flush=True)
    return True


# ============================================================================
# НАСТРОЙКА ЛОГГИРОВАНИЯ
# ============================================================================

def setup_logging(log_dir: Path) -> Path:
    """Настройка логгирования"""
    log_dir.mkdir(exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = log_dir / f'agent_{timestamp}.log'

    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(getattr(logging, config.LOG_LEVEL))
    file_handler.setFormatter(logging.Formatter(config.LOG_FORMAT))

    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.WARNING)
    stream_handler.setFormatter(logging.Formatter(config.LOG_FORMAT))

    root = logging.getLogger()
    root.setLevel(getattr(logging, config.LOG_LEVEL))
    root.handlers.clear()
    root.addHandler(file_handler)
    root.addHandler(stream_handler)
    
    # Скрыть DEBUG логи от httpcore и других библиотек
    logging.getLogger('httpcore').setLevel(logging.WARNING)
    logging.getLogger('httpx').setLevel(logging.WARNING)
    logging.getLogger('google').setLevel(logging.WARNING)

    return log_file


# ============================================================================
# КОМАНДЫ АГЕНТА
# ============================================================================

def cmd_transcribe(args):
    """Команда: транскрипция аудио"""
    print("\n" + "="*60)
    print("🎙️  ТРАНСКРИПЦИЯ АУДИО (AssemblyAI)")
    print("="*60)

    # Проверка API ключа
    if not config.ASSEMBLYAI_API_KEY:
        print("\n❌ Ошибка: ASSEMBLYAI_API_KEY не указан в .env")
        sys.exit(1)

    # Проверка файла
    audio_path = Path(args.audio)
    if not audio_path.exists():
        print(f"\n❌ Аудиофайл не найден: {audio_path}")
        sys.exit(1)

    # Определение выходного пути
    output_path = args.output or audio_path.parent / 'transcription.json'
    
    # Язык
    language_code = args.language or config.ASSEMBLYAI_LANGUAGE_CODE
    print(f"\n📊 Язык транскрипции: {language_code}")

    try:
        # Транскрипция
        result = transcribe_audio(str(audio_path), str(output_path), language_code=language_code)

        print(f"\n✅ ТРАНСКРИПЦИЯ ЗАВЕРШЕНА!")
        print(f"   Фрагментов: {len(result['transcription'])}")
        print(f"   Длительность: {result['audioDuration']:.2f} сек")
        print(f"   Файл: {output_path}")

    except Exception as e:
        print(f"\n❌ Ошибка транскрипции: {e}")
        logging.debug(traceback.format_exc())
        sys.exit(1)


def cmd_direct(args):
    """Команда: режиссерский анализ"""
    log_dir = Path(__file__).parent / 'logs'
    log_file = setup_logging(log_dir)

    # Override backend from CLI
    if getattr(args, 'director_backend', None):
        config.DIRECTOR_BACKEND = args.director_backend
    if getattr(args, 'director_profile', None):
        config.DIRECTOR_PROFILE = args.director_profile

    backend = config.DIRECTOR_BACKEND
    backend_label = 'GPT (Codex)' if backend == 'gpt' else 'Gemini'

    print("\n" + "="*60)
    print(f"🎬 РЕЖИССЕРСКИЙ АНАЛИЗ ({backend_label})")
    print("="*60)
    print(f"📝 Лог-файл: {log_file}")

    # Проверка API ключа (только для Gemini)
    if backend != 'gpt' and not config.GEMINI_API_KEY:
        print("\n❌ Ошибка: GEMINI_API_KEY не указан в .env")
        sys.exit(1)

    # Проверка файлов
    transcription_path = Path(args.transcription)
    style_guide_path = Path(args.style)

    if not transcription_path.exists():
        print(f"\n❌ Транскрипция не найдена: {transcription_path}")
        sys.exit(1)

    if not style_guide_path.exists():
        print(f"\n❌ Style guide не найден: {style_guide_path}")
        sys.exit(1)

    # Валидация транскрипции
    is_valid, data, msg = validate_json_file(str(transcription_path))
    if not is_valid:
        print(f"\n❌ Ошибка транскрипции: {data}")
        sys.exit(1)

    is_valid, errors = validate_transcription_json(data)
    if not is_valid:
        print(f"\n⚠️  Предупреждения транскрипции:")
        for error in errors:
            print(f"   • {error}")
        if not args.force:
            print("\nИспользуйте --force для пропуска валидации")
            sys.exit(1)

    # Определение выходной директории
    output_dir = args.output or transcription_path.parent

    # Выбор модели
    model_name = args.model or config.GEMINI_MODEL
    print(f"\n📊 Модель: {model_name}")
    
    # director_analysis.md
    generate_director = args.director_analysis if args.director_analysis is not None else config.GENERATE_DIRECTOR_ANALYSIS
    print(f"📊 director_analysis.md: {'✓ ВКЛЮЧЕН' if generate_director else '✗ ОТКЛЮЧЕН'}")

    two_pass = getattr(args, 'two_pass', False)
    prompts_only = getattr(args, 'prompts_only', False)
    if prompts_only:
        print(f"📊 Режим: только промпты (--prompts-only, проход 2)")
    elif two_pass:
        print(f"📊 Режим: 2-проходный (--two-pass)")
    else:
        print(f"📊 Режим: 1-проходный")

    # Resume: ищем существующий файл промптов
    resume_path = None
    if getattr(args, 'resume', False) and prompts_only:
        _od = Path(output_dir)
        _candidates = sorted(_od.glob(f"{args.project}_prompts_*.txt"))
        _non_over = [f for f in _candidates if 'OVERPROMPT' not in f.name]
        _best = _non_over[-1] if _non_over else (_candidates[-1] if _candidates else None)
        if _best:
            resume_path = str(_best)
            print(f"\n🔄 Продолжение с файла: {_best.name}")
        else:
            print("\n⚠️  Существующий файл промптов не найден, начинаем заново")

    try:
        # Режиссерский анализ
        results = direct_project(
            str(transcription_path),
            str(style_guide_path),
            str(output_dir),
            args.project,
            model_name=model_name,
            two_pass=two_pass,
            prompts_only=prompts_only,
            resume_path=resume_path,
            director_profile=getattr(args, 'director_profile', None),
            visual_story_step=getattr(args, 'visual_story_step', 'full'),
            visual_story_mock=getattr(args, 'visual_story_mock', False),
            visual_story_mock_assets=getattr(args, 'visual_story_mock_assets', False),
        )

        print(f"\n✅ РЕЖИССЕРСКИЙ АНАЛИЗ ЗАВЕРШЕН!")
        for name, path in results.items():
            print(f"   • {name}: {path}")

    except Exception as e:
        print(f"\n❌ Ошибка режиссерского анализа: {e}")
        logging.debug(traceback.format_exc())
        sys.exit(1)


def cmd_visual_story(args):
    """Run or resume the Auto Visual Story Director profile for one project."""
    project_dir = Path(args.project).resolve()
    if not project_dir.is_dir():
        print(f"\n❌ Project directory not found: {project_dir}")
        sys.exit(1)
    transcription_path = project_dir / "transcription.json"
    if not transcription_path.exists():
        print(f"\n❌ transcription.json not found: {transcription_path}")
        sys.exit(1)
    style_path = Path(args.style).resolve() if args.style else None
    if style_path is None:
        candidates = sorted(project_dir.glob("*_style_*.txt"))
        style_path = candidates[0] if candidates else None
    if style_path is None or not style_path.exists():
        print("\n❌ Auto Visual Story requires a style guide file")
        sys.exit(1)

    if args.director_backend:
        config.DIRECTOR_BACKEND = args.director_backend
    config.DIRECTOR_PROFILE = "auto_visual_story"
    result = direct_project(
        str(transcription_path),
        str(style_path),
        str(project_dir),
        args.project_name or project_dir.name,
        model_name=args.model,
        director_profile="auto_visual_story",
        visual_story_step=args.step,
        visual_story_mock=args.mock,
        visual_story_mock_assets=args.mock_assets,
        resume_path="resume" if args.resume else None,
    )
    print("\n✅ Auto Visual Story завершён")
    for key, value in result.items():
        if key not in {"cost", "selection", "final_gate"}:
            print(f"   • {key}: {value}")


def cmd_script_direct(args):
    """Команда: режиссура из текстового сценария (без аудио/транскрипции)."""
    print("\n" + "="*60)
    print("🎬 SCRIPT DIRECTOR MODE")
    print("="*60)

    script_path = Path(args.script)
    style_path  = Path(args.style)

    if not script_path.exists():
        print(f"\n❌ Сценарий не найден: {script_path}")
        sys.exit(1)
    if not style_path.exists():
        print(f"\n❌ Style guide не найден: {style_path}")
        sys.exit(1)

    # Папка вывода: рядом со сценарием или явно заданная
    if args.output:
        output_dir = Path(args.output)
    else:
        output_dir = script_path.parent / f"SCRIPT_{script_path.stem}"
    output_dir.mkdir(parents=True, exist_ok=True)

    project_name = args.project or script_path.stem
    script_type  = args.script_type
    two_pass     = args.two_pass

    log_dir = Path(__file__).parent / 'logs'
    setup_logging(log_dir)
    logging.info(f"Script director: script={script_path.name} type={script_type} two_pass={two_pass}")

    # Применяем настройки длительности клипов из CLI
    _cm = getattr(args, 'clip_mode', None)
    if _cm in ('slideshow', 'vislide'):
        config.ACTIVE_CLIP_MIN_DURATION = config.SLIDESHOW_CLIP_MIN_DURATION
        config.ACTIVE_CLIP_MAX_DURATION = config.SLIDESHOW_CLIP_MAX_DURATION
    if getattr(args, 'clip_min', None):
        config.ACTIVE_CLIP_MIN_DURATION = args.clip_min
    if getattr(args, 'clip_max', None):
        config.ACTIVE_CLIP_MAX_DURATION = args.clip_max

    print(f"   Сценарий:   {script_path.name}")
    print(f"   Тип:        {script_type}")
    print(f"   Style:      {style_path.name}")
    print(f"   Проект:     {project_name}")
    print(f"   Режим:      {'2-pass' if two_pass else '1-pass'}")
    print(f"   Клипы:      {config.ACTIVE_CLIP_MIN_DURATION}-{config.ACTIVE_CLIP_MAX_DURATION}с")
    print(f"   Вывод:      {output_dir}")

    try:
        result = script_direct_project(
            script_path=str(script_path),
            style_guide_path=str(style_path),
            output_dir=str(output_dir),
            project_name=project_name,
            script_type=script_type,
            two_pass=two_pass,
        )
        print(f"\n✅ Script Director завершён!")
        for k, v in result.items():
            if k not in ('cost', 'num_prompts', 'num_clips'):
                print(f"   • {k}: {v}")

        # Пост-пайплайн генерация
        post_action = getattr(args, 'post_action', None)
        yt_pack = getattr(args, 'yt_pack', False)
        _vi = getattr(args, 'vislide_interval', 0) or 0
        if _cm == 'vislide' and _vi < 2:
            _vi = 3
        if _cm == 'vislide' and _vi >= 2:
            os.environ['VARAGENT_VISLIDE_INTERVAL'] = str(_vi)
        if post_action and post_action != 'skip':
            _run_post_pipeline_silent(str(output_dir), post_action)
        # YT Pack отдельно (после генерации) — единый путь, не блокирует
        if yt_pack:
            _run_yt_pack_after_done(str(output_dir))

    except Exception as e:
        print(f"\n❌ Ошибка: {e}")
        logging.debug(traceback.format_exc())
        sys.exit(1)


def cmd_validate(args):
    """Команда: валидация файлов"""
    print("\n" + "="*60)
    print("🔍 ВАЛИДАЦИЯ ФАЙЛОВ")
    print("="*60)
    
    files_validated = 0
    errors_found = 0
    
    # Валидация transcription.json
    if args.transcription:
        print(f"\n📄 Валидация: {args.transcription}")
        is_valid, data, msg = validate_json_file(args.transcription)
        
        if is_valid:
            is_valid, errors = validate_transcription_json(data)
            if is_valid:
                print("   ✅ transcription.json валиден")
                files_validated += 1
            else:
                print("   ❌ Ошибки transcription.json:")
                for error in errors:
                    print(f"      • {error}")
                errors_found += len(errors)
        else:
            print(f"   ❌ {data}")
            errors_found += 1
    
    # Валидация montage_plan.json
    if args.montage_plan:
        print(f"\n📄 Валидация: {args.montage_plan}")
        is_valid, data, msg = validate_json_file(args.montage_plan)
        
        if is_valid:
            audio_duration = data.get('audioDuration', 0)
            is_valid, errors = validate_montage_plan_json(data, audio_duration)
            if is_valid:
                print("   ✅ montage_plan.json валиден")
                files_validated += 1
            else:
                print("   ❌ Ошибки montage_plan.json:")
                for error in errors:
                    print(f"      • {error}")
                errors_found += len(errors)
        else:
            print(f"   ❌ {data}")
            errors_found += 1
    
    # Валидация всех файлов в директории
    if args.all or args.dir:
        dir_path = Path(args.dir) if args.dir else Path('.')
        print(f"\n📄 Сканирование директории: {dir_path}")
        
        for json_file in dir_path.glob('*.json'):
            if json_file.name in ['transcription.json', 'montage_plan.json']:
                if json_file.name == 'transcription.json':
                    args.transcription = str(json_file)
                    cmd_validate(args)
                elif json_file.name == 'montage_plan.json':
                    args.montage_plan = str(json_file)
                    cmd_validate(args)
    
    # Итог
    print("\n" + "="*60)
    if errors_found == 0:
        print(f"✅ ВАЛИДАЦИЯ ЗАВЕРШЕНА: {files_validated} файлов без ошибок")
    else:
        print(f"❌ ВАЛИДАЦИЯ ЗАВЕРШЕНА: найдено {errors_found} ошибок")
        sys.exit(1)


def cmd_run(args):
    """Команда: полный пайплайн (этапы 1-2)"""
    # Override backend from CLI
    if getattr(args, 'director_backend', None):
        config.DIRECTOR_BACKEND = args.director_backend
    if getattr(args, 'director_profile', None):
        config.DIRECTOR_PROFILE = args.director_profile

    print("\n" + "="*60)
    print("🚀 ПОЛНЫЙ ПЛАЙПЛАЙН (Этапы 1-2: Агент)")
    print("="*60)

    # Проверка API ключей
    errors = config.check_api_keys()
    if errors:
        print("\n❌ Ошибки конфигурации:")
        for error in errors:
            print(f"   • {error}")
        sys.exit(1)

    # Проверка аудиофайла
    audio_path = Path(args.audio)
    if not audio_path.exists():
        print(f"\n❌ Аудиофайл не найден: {audio_path}")
        sys.exit(1)

    # Проверка style guide
    style_guide_path = Path(args.style)
    if not style_guide_path.exists():
        print(f"\n❌ Style guide не найден: {style_guide_path}")
        sys.exit(1)

    # Настройка логгирования
    log_dir = Path('logs')
    log_file = setup_logging(log_dir)
    logging.info(f"Запуск пайплайна: {args.audio}")
    
    # Язык транскрипции
    language_code = args.language or config.ASSEMBLYAI_LANGUAGE_CODE
    print(f"\n📊 Язык транскрипции: {language_code}")
    
    # Выбор модели
    if config.DIRECTOR_BACKEND == 'gpt':
        model_name = config.GPT_MODEL
        print(f"📊 Модель GPT: {model_name}")
    else:
        model_name = args.model or config.GEMINI_MODEL
        print(f"📊 Модель Gemini: {model_name}")
    
    # director_analysis.md
    generate_director = args.director_analysis if args.director_analysis is not None else config.GENERATE_DIRECTOR_ANALYSIS
    print(f"📊 director_analysis.md: {'✓ ВКЛЮЧЕН' if generate_director else '✗ ОТКЛЮЧЕН'}")

    # ЭТАП 1: ТРАНСКРИПЦИЯ
    print("\n" + "="*60)
    print("ЭТАП 1/2: ТРАНСКРИПЦИЯ")
    print("="*60)

    transcription_output = audio_path.parent / 'transcription.json'

    try:
        transcription_result = transcribe_audio(str(audio_path), str(transcription_output), language_code=language_code)
        logging.info(f"Транскрипция завершена: {transcription_output}")
    except Exception as e:
        print(f"\n❌ Ошибка транскрипции: {e}")
        logging.debug(traceback.format_exc())
        sys.exit(1)

    # Проверка качества транскрипции перед режиссёром
    if transcription_result.get('_quality_critical', False):
        print("\n⛔ Транскрипция аномальная! Режиссёр НЕ запущен.")
        print("   Проверьте transcription.json и перезапустите транскрипцию.")
        print("   Используйте --force для принудительного запуска.")
        if not getattr(args, 'force', False):
            sys.exit(1)

    # SG Adapt: адаптируем стайлгайд под текущий сюжет (если запрошено)
    if getattr(args, 'adapt_sg', False):
        print("\n" + "="*60)
        print("SG ADAPT: АДАПТАЦИЯ СТАЙЛГАЙДА")
        print("="*60)
        from modules.sg_adapter import adapt_style_guide
        adapted = adapt_style_guide(
            original_sg_path=str(style_guide_path),
            project_dir=str(audio_path.parent),
            project_name=args.project,
        )
        style_guide_path = Path(adapted)
        print(f"  Adapted SG: {style_guide_path.name}")

    # ЭТАП 2: РЕЖИССЕРСКИЙ АНАЛИЗ
    print("\n" + "="*60)
    print("ЭТАП 2/2: РЕЖИССЕРСКИЙ АНАЛИЗ")
    print("="*60)

    output_dir = audio_path.parent

    try:
        result = direct_project(
            str(transcription_output),
            str(style_guide_path),
            str(output_dir),
            args.project,
            model_name=model_name,
            director_profile=getattr(args, 'director_profile', None),
            visual_story_step=getattr(args, 'visual_story_step', 'full'),
            visual_story_mock=getattr(args, 'visual_story_mock', False),
            visual_story_mock_assets=getattr(args, 'visual_story_mock_assets', False),
        )
        logging.info(f"Режиссерский анализ завершен: {output_dir}")
        
        # Вывод стоимости сразу после завершения
        if 'cost' in result:
            print(f"\n💰 СТОИМОСТЬ:")
            print(f"   Input:  {result['cost']['input_tokens']:,} токенов = ${result['cost']['input_cost']:.4f}")
            print(f"   Output: {result['cost']['output_tokens']:,} токенов = ${result['cost']['output_cost']:.4f}")
            print(f"   ИТОГО:  ${result['cost']['total_cost']:.4f}")
    except Exception as e:
        print(f"\n❌ Ошибка режиссерского анализа: {e}")
        logging.debug(traceback.format_exc())
        sys.exit(1)

    # ЭТАП 3: ГЕНЕРАЦИЯ ИЗОБРАЖЕНИЙ (опционально)
    if getattr(args, 'with_images', False):
        if not config.FASTGEN_API_KEY:
            print("\n[WARN] FASTGEN_API_KEY not set, skipping image generation")
        else:
            print("\n" + "="*60)
            print("STAGE 3/3: IMAGE GENERATION (FastGen)")
            print("="*60)

            try:
                gen_result = generate_all_images(
                    project_dir=str(output_dir),
                )
                ok = gen_result.get('generated', 0)
                total = gen_result.get('total_clips', 0)
                logging.info(f"Image generation: {ok}/{total}")
            except Exception as e:
                print(f"\n[ERROR] Image generation failed: {e}")
                logging.debug(traceback.format_exc())
                # Don't exit — stages 1-2 already completed

    # ФИНАЛ — отчет
    print("\n" + "="*60)
    print("STAGES 1-2 COMPLETE!")
    print("="*60)

    # Чтение лога проекта для вывода стоимости
    project_log = output_dir / f'{args.project}_log.txt'
    if project_log.exists():
        with open(project_log, 'r', encoding='utf-8') as f:
            content = f.read()
            if "СТОИМОСТЬ:" in content:
                cost_section = content.split("СТОИМОСТЬ:")[1].split("===")[0]
                print(f"\n  Cost: {cost_section.strip()}")

    print(f"\n  Output: {output_dir}")
    print(f"  Prompts: {args.project}_prompts_*.txt")
    print(f"  Log: {log_file}")

    # Интерактивное меню: только в терминале (не в GUI/pipeline)
    if sys.stdin.isatty():
        _ask_post_pipeline_action(str(output_dir))
        _ask_yt_packer(str(output_dir), source_lang=language_code)


def cmd_status(args):
    """Команда: статус проекта"""
    print("\n" + "="*60)
    print("📊 СТАТУС ПРОЕКТА")
    print("="*60)

    project_dir = Path(args.dir) if args.dir else Path('.')

    # Проверка файлов
    files = {
        'narration.wav': 'Аудио озвучка',
        'transcription.json': 'Транскрипция',
        'montage_plan.json': 'Монтажный план',
    }

    print(f"\n📂 Директория: {project_dir.absolute()}\n")

    for filename, description in files.items():
        file_path = project_dir / filename
        if file_path.exists():
            size = file_path.stat().st_size
            if size > 1024*1024:
                size_str = f"{size / (1024*1024):.1f} MB"
            elif size > 1024:
                size_str = f"{size / 1024:.1f} KB"
            else:
                size_str = f"{size} B"
            print(f"   ✅ {filename:<25} {size_str:>10}  {description}")
        else:
            print(f"   ❌ {filename:<25} {'не найден':>10}  {description}")

    # Проверка style guide файла (ищем по маске *_style_*.txt)
    style_files = list(project_dir.glob('*_style_*.txt'))
    if style_files:
        for sf in style_files:
            size = sf.stat().st_size
            size_str = f"{size / 1024:.1f} KB" if size > 1024 else f"{size} B"
            print(f"   ✅ {sf.name:<25} {size_str:>10}  Style Guide")
    else:
        print(f"   ❌ {'*_style_*.txt':<25} {'не найден':>10}  Style Guide")

    # Проверка prompts файла (ищем по маске *_prompts_*.txt)
    prompts_files = list(project_dir.glob('*_prompts_*.txt'))
    if prompts_files:
        for pf in prompts_files:
            size = pf.stat().st_size
            size_str = f"{size / 1024:.1f} KB" if size > 1024 else f"{size} B"
            print(f"   ✅ {pf.name:<25} {size_str:>10}  Промпты для Veo3")
    else:
        print(f"   ❌ {'*_prompts_*.txt':<25} {'не найден':>10}  Промпты для Veo3")

    # Проверка видеофайлов
    print("\n🎬 Видеофрагменты:")
    video_files = list(project_dir.glob('*.mp4')) + list(project_dir.glob('*.mov'))

    if video_files:
        # Проверка переименованных файлов
        numbered_files = [f for f in video_files if f.name[0].isdigit()]
        veo_files = [f for f in video_files if 'veo' in f.name.lower()]

        if numbered_files:
            print(f"   ✅ Переименованные: {len(numbered_files)} файлов")
            max_num = max(int(f.name.split('.')[0]) for f in numbered_files if f.name[0].isdigit())
            min_num = min(int(f.name.split('.')[0]) for f in numbered_files if f.name[0].isdigit())
            print(f"      Диапазон: {min_num} - {max_num}")

        if veo_files:
            print(f"   ⏳ Veo3 (требуют переименования): {len(veo_files)} файлов")
    else:
        print("   ⏳ Видеофрагменты не найдены (ожидают генерации в Veo3)")

    # Итог
    print("\n" + "="*60)

    # Определение стадии проекта
    if not (project_dir / 'transcription.json').exists():
        print("📍 СТАДИЯ: Ожидает транскрипции")
        print("   Запусти: agent run --audio narration.wav")
    elif not (project_dir / 'montage_plan.json').exists():
        print("📍 СТАДИЯ: Ожидает режиссерского анализа")
        print("   Запусти: agent direct --transcription transcription.json --style style_guide.txt")
    elif not video_files:
        print("📍 СТАДИЯ: Ожидает генерации видео в Veo3")
        print("   1. Открой prompts.txt")
        print("   2. Сгенерируй видео в Veo3")
        print("   3. Скачай в папку проекта")
    elif not numbered_files and veo_files:
        print("📍 СТАДИЯ: Ожидает переименования видео")
        print("   Запусти: process.bat")
    else:
        print("📍 СТАДИЯ: Готов к склейке")
        print("   Запусти: process.bat")


def cmd_cost_estimate(args):
    """Команда: оценка стоимости для озвучки"""
    print("\n" + "="*60)
    print("ОЦЕНКА СТОИМОСТИ GEMINI API")
    print("="*60)
    
    audio_duration_min = args.duration  # минуты
    language = args.language  # язык для учёта токенизации
    
    # Эмпирическая оценка
    # Русский язык: ~120-140 слов в минуту (медленнее английского)
    # Но токенизация БОЛЬШЕ: русское слово = 1.5-2.0 токена (vs 1.3 для английского)
    # Потому что:
    #   - Кириллица = больше байт на символ
    #   - Сложные окончания = больше суб-слов
    
    # Коэффициенты по языкам
    language_coeffs = {
        'en': {'wpm': 150, 'tokens_per_word': 1.3},   # английский
        'ru': {'wpm': 130, 'tokens_per_word': 1.8},   # русский (больше токенов!)
        'es': {'wpm': 140, 'tokens_per_word': 1.4},   # испанский
        'fr': {'wpm': 140, 'tokens_per_word': 1.4},   # французский
        'de': {'wpm': 130, 'tokens_per_word': 1.5},   # немецкий
        'it': {'wpm': 140, 'tokens_per_word': 1.4},   # итальянский
        'pt': {'wpm': 140, 'tokens_per_word': 1.4},   # португальский
        'zh': {'wpm': 180, 'tokens_per_word': 1.0},   # китайский (иероглифы)
        'ja': {'wpm': 180, 'tokens_per_word': 1.2},   # японский
        'ko': {'wpm': 170, 'tokens_per_word': 1.3},   # корейский
    }
    
    lang_config = language_coeffs.get(language, language_coeffs['ru'])
    words_per_minute = lang_config['wpm']
    tokens_per_word = lang_config['tokens_per_word']
    
    # Расчёт количества слов и токенов транскрипции
    total_words = audio_duration_min * words_per_minute
    transcription_tokens = int(total_words * tokens_per_word)
    
    # ========================================================================
    # ВХОДНЫЕ ТОКЕНЫ (INPUT)
    # ========================================================================
    # 1. Системный промпт (инструкция режиссёра с правилами пауз и т.д.)
    system_prompt_tokens = 5130
    
    # 2. Style guide (визуальный стиль проекта)
    style_guide_tokens = 700
    
    # 3. Транскрипция (рассчитана выше)
    # transcription_tokens
    
    # 4. Дополнительные данные (название, длительность, форматирование)
    extra_tokens = 210
    
    input_tokens = system_prompt_tokens + style_guide_tokens + transcription_tokens + extra_tokens
    
    # ========================================================================
    # ВЫХОДНЫЕ ТОКЕНЫ (OUTPUT)
    # ========================================================================
    # Оценка количества сцен: 1 сцена на ~5 секунд аудио
    num_scenes = int((audio_duration_min * 60) / 5)
    
    # 1. montage_plan.json (~25 токенов на клип)
    montage_plan_tokens = num_scenes * 25
    
    # 2. prompts.txt (style guide + visual description на каждую сцену)
    # ~200 токенов на сцену
    prompts_tokens = num_scenes * 200
    
    # 3. 4list_prompts.txt — ЗАМОРОЖЕНО (экономия ~280 токенов на сцену)
    # list_prompts_tokens = num_scenes * 280
    list_prompts_tokens = 0  # ИСКЛЮЧЁН ИЗ ПАЙПЛАЙНА
    
    # 4. director_analysis.md (таблица с обоснованиями) — УПРАВЛЯЕМОЕ
    # director_analysis_tokens = 5000  # Если включено
    director_analysis_tokens = 5000 if config.GENERATE_DIRECTOR_ANALYSIS else 0
    
    output_tokens = montage_plan_tokens + prompts_tokens + list_prompts_tokens + director_analysis_tokens
    
    # ========================================================================
    # ВЫВОД ИНФОРМАЦИИ
    # ========================================================================
    
    print(f"\nВходные данные:")
    print(f"   Длительность аудио: {audio_duration_min} мин")
    print(f"   Язык: {language}")
    print(f"   Примерное количество слов: {total_words:,}")
    print(f"   Токенизация: {tokens_per_word} токена/слово ({language})")
    print(f"   Токены транскрипции: ~{transcription_tokens:,}")
    
    print(f"\nВХОДНЫЕ ТОКЕНЫ (INPUT):")
    print(f"   Системный промпт:     ~{system_prompt_tokens:,}")
    print(f"   Style guide:          ~{style_guide_tokens:,}")
    print(f"   Транскрипция:         ~{transcription_tokens:,}")
    print(f"   Доп. данные:          ~{extra_tokens:,}")
    print(f"   {'-'*33}")
    print(f"   ВСЕГО INPUT:          ~{input_tokens:,}")
    
    print(f"\nВЫХОДНЫЕ ТОКЕНЫ (OUTPUT):")
    print(f"   montage_plan.json:    ~{montage_plan_tokens:,} ({num_scenes} сцен x 25)")
    print(f"   prompts.txt:          ~{prompts_tokens:,} ({num_scenes} сцен x 200)")
    print(f"   4list_prompts.txt:    ИСКЛЮЧЁН (экономия ~{num_scenes * 280:,} токенов)")
    if config.GENERATE_DIRECTOR_ANALYSIS:
        print(f"   director_analysis.md: ~{director_analysis_tokens:,} (ВКЛЮЧЕНО)")
    else:
        print(f"   director_analysis.md: ИСКЛЮЧЁН (экономия ~5,000 токенов)")
    print(f"   {'-'*33}")
    print(f"   ВСЕГО OUTPUT:         ~{output_tokens:,}")
    
    print("\n" + "="*60)
    print("СТОИМОСТЬ ПО МОДЕЛЯМ:")
    print("="*60)
    
    models = [
        ('gemini-2.5-flash', 'Flash (быстро/дешево)'),
        ('gemini-2.5-pro', 'Pro (качество)'),
        ('gemini-2.0-flash-exp', '2.0 Flash Exp (бесплатно beta)'),
    ]
    
    print(f"\n{'Модель':<25} {'Input':<12} {'Output':<12} {'Стоимость':<10}")
    print("-" * 60)
    
    for model_id, model_name in models:
        cost = config.estimate_cost(input_tokens, output_tokens, model_id)
        print(f"{model_name:<25} ${cost['input_cost']:<11.4f} ${cost['output_cost']:<11.4f} ${cost['total_cost']:.4f}")
    
    print("\n" + "="*60)
    print("Примечание:")
    assembly_cost = audio_duration_min * 0.15 / 60
    print(f"   * AssemblyAI: ~$0.15/час = ${assembly_cost:.2f} за {audio_duration_min} мин")
    print("   * Цены актуальны на 2026-02-21")
    print("   * gemini-2.0-flash-exp бесплатен в период beta")
    print(f"   * 4list_prompts.txt ИСКЛЮЧЁН — экономия ~{num_scenes * 280:,} токенов output")
    print(f"   * director_analysis.md: {'ВКЛЮЧЁНО' if config.GENERATE_DIRECTOR_ANALYSIS else 'ОТКЛЮЧЕНО'} (экономия ~5,000 токенов = $0.05/проект на Pro)")
    print(f"   * Управление: GENERATE_DIRECTOR_ANALYSIS в .env или --director-analysis в CLI")
    print("="*60)


def _report_music_status(project_dir: str, *, prefix: str = "  ") -> None:
    """Итог музыкальной стадии в общий лог пайплайна.

    Музыка генерится отдельным фоновым процессом и пишет свой статус в
    `music_background_status.json` — в сводке пайплайна её не было вовсе, и
    пользователь не знал, сделалась она или нет.
    """
    import json as _json

    path = Path(project_dir) / 'music_background_status.json'
    music_dir = Path(project_dir) / 'music'
    ready_files = sorted(music_dir.glob('*.mp3')) if music_dir.exists() else []
    if not path.exists():
        if ready_files:
            print(f"{prefix}[Music] итог: {len(ready_files)} трек(ов) готово")
        return
    try:
        data = _json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return
    state = str(data.get('state') or data.get('stage') or '?')
    total = int(data.get('tracks') or 0)
    ready = int(data.get('ready_tracks') or len(ready_files))
    failed = int(data.get('failed') or 0)
    if state == 'completed':
        tail = f", {failed} не вышло" if failed else ""
        print(f"{prefix}[Music] итог: {ready} из {total} трек(ов) готово{tail}")
    elif state in ('failed', 'error'):
        print(f"{prefix}[Music] итог: ОШИБКА — {str(data.get('error') or state)[:120]}")
    else:
        print(f"{prefix}[Music] итог: ещё идёт ({state}), готово {ready} из {total} — "
              f"склейка подождёт музыку")


def _save_failed_prompts(project_dir: str, stage: str, failed_count: int) -> None:
    """Сохраняет информацию о несгенерированных клипах в failed_prompts.txt.

    stage: 'imggen', 'i2v', 't2v', 'components'
    """
    p = Path(project_dir)
    failed_file = p / 'failed_prompts.txt'
    remap_dense_prompts_for_montage = None

    # Читаем промпты
    try:
        from extract_prompt import extract_all_prompts, find_prompts_file, remap_dense_prompts_for_montage
        prompts_file = find_prompts_file(str(p))
        all_prompts = extract_all_prompts(prompts_file) if prompts_file else {}
    except Exception:
        all_prompts = {}

    # Читаем montage_plan для списка clip IDs
    try:
        import json as _json
        mp_path = p / 'montage_plan.json'
        if mp_path.exists():
            mp_data = _json.loads(mp_path.read_text(encoding='utf-8-sig'))
            mp = mp_data.get('montage_plan', mp_data)
            clips = mp.get('clips', [])
            all_clip_ids = [c['id'] for c in clips]
            if all_prompts and remap_dense_prompts_for_montage:
                all_prompts, _ = remap_dense_prompts_for_montage(all_prompts, clips)
        else:
            all_clip_ids = sorted(all_prompts.keys())
    except Exception:
        all_clip_ids = sorted(all_prompts.keys())

    missing = []

    if stage == 'imggen':
        gen_dir = p / 'generated'
        for cid in all_clip_ids:
            found = any((gen_dir / f"{cid:03d}{ext}").exists()
                        for ext in ('.png', '.jpg', '.jpeg', '.webp'))
            if not found:
                prompt = all_prompts.get(cid, f'(prompt #{cid} not found)')
                missing.append((cid, prompt))

    elif stage in ('i2v', 't2v', 'components'):
        vid_dir = p / 'vid_img'
        for cid in all_clip_ids:
            if not (vid_dir / f"{cid:03d}.mp4").exists():
                prompt = all_prompts.get(cid, f'(prompt #{cid} not found)')
                if stage == 'i2v':
                    # Показываем какой файл-картинку нужно было оживить
                    img_name = f"generated/{cid:03d}.png"
                    missing.append((cid, f"[image: {img_name}] {prompt[:150]}"))
                else:
                    missing.append((cid, prompt))

    if not missing:
        return

    lines = [f"=== FAILED {stage.upper()} ({len(missing)} clips) ===\n"]
    for cid, prompt in missing:
        lines.append(f"#{cid:03d}: {prompt[:200]}\n")

    # Append (не перезаписываем — могут быть failed от обоих стадий)
    with open(failed_file, 'a', encoding='utf-8') as f:
        f.writelines(lines)
        f.write("\n")

    print(f"  Failed {stage} prompts saved to: {failed_file.name} ({len(missing)} clips)")
    logging.info(f"Saved {len(missing)} failed {stage} prompts to {failed_file}")


def _start_inflight_watcher(p_dir: str, video_key_slot: str, video_parallel: int,
                            ar: str, prompt_mode: str, vislide_interval: int = 0,
                            prompts_file_path: str = None,
                            fastgen_key_slot: str = None,
                            output_dir_name: str = 'vid_img'):
    """Launch watch_i2v*.py as background subprocess for inflight i2v mode.
    Engine routing: VARAGENT_VIDEO_ENGINE=fastgen_ultra → watch_i2v_flowultra.py,
    else watch_i2v.py (VeoNonStop). Returns Popen handle or None on failure."""
    import subprocess as _sp
    _engine = os.environ.get('VARAGENT_VIDEO_ENGINE', 'veononstop').strip().lower()
    if _engine == 'cinai':
        watch_script = Path(__file__).parent / 'watch_i2v_cinai.py'
        _script_label = 'watch_i2v_cinai.py'
    elif _engine == 'fastgen_ultra':
        watch_script = Path(__file__).parent / 'watch_i2v_flowultra.py'
        # Flow Ultra uses existing FastGen key slot from pipeline settings.
        _script_label = 'watch_i2v_flowultra.py'
    else:
        watch_script = Path(__file__).parent / 'watch_i2v.py'
        _script_label = 'watch_i2v.py'
    if not watch_script.exists():
        print(f"  [WARN] {_script_label} not found — inflight mode disabled")
        return None
    project_path = Path(p_dir).resolve()
    cmd = [sys.executable, str(watch_script),
           '--project', str(project_path),
           '--parallel', str(video_parallel),
           '--key-slot', video_key_slot,
           '--aspect', ar]
    if prompt_mode == 'single':
        cmd.append('--single-prompt')
    if vislide_interval >= 2:
        cmd += ['--vislide-interval', str(vislide_interval)]
    if prompts_file_path:
        cmd += ['--prompts-file', str(prompts_file_path)]
    if _engine == 'cinai':
        cmd += [
            '--model', str(getattr(config, 'CINAI_VIDEO_MODEL', 'seedance-2-0-lite')),
            '--mode', 'i2v',
            '--duration', str(getattr(config, 'CINAI_VIDEO_DURATION', 5)),
            '--resolution', str(getattr(config, 'CINAI_VIDEO_RESOLUTION', '') or ''),
            '--audio', str(getattr(config, 'CINAI_VIDEO_AUDIO', '') or ''),
            '--output-dir', output_dir_name,
            '--done-file', str(project_path / 'generated' / '.imagegen_done'),
            '--drain-seconds', str(getattr(config, 'CINAI_VIDEO_INFLIGHT_DRAIN_SECONDS', 120)),
        ]
    # FU end-image: generated/ of next clip (pair mode)
    if _engine == 'fastgen_ultra' and os.environ.get('VARAGENT_FU_END_IMAGE') == '1':
        cmd += ['--end-image-dir', str(project_path / 'generated')]
    cmd.append('--no-cancel')  # imggen runs in parallel — don't cancel its tasks
    if _engine == 'cinai':
        cmd = [item for item in cmd if item != '--no-cancel']
    print(f"  [INFLIGHT] Starting {_script_label} (engine={_engine}, key={cmd[cmd.index('--key-slot')+1]}, parallel={video_parallel})"
          + (f" [vislide every {vislide_interval}]" if vislide_interval >= 2 else "") + "...")
    try:
        import os as _os
        _env = dict(_os.environ)
        _env['PYTHONUTF8'] = '1'
        proc = _sp.Popen(cmd, cwd=str(Path(__file__).parent), env=_env,
                         stdout=sys.stdout, stderr=sys.stdout)
        return proc
    except Exception as e:
        print(f"  [WARN] Inflight mode failed to start: {e}")
        return None


def _wait_inflight_watcher(proc, p_dir: str, output_dir_name: str = 'vid_img') -> bool:
    """Wait for watch_i2v subprocess, check returncode & vid_img/ contents.
    Returns True if vid_img/ has videos, False if inflight failed (caller should fallback)."""
    print("  [INFLIGHT] Waiting for watch_i2v.py to finish...")
    proc.wait()
    rc = proc.returncode
    vid_dir = Path(p_dir) / output_dir_name
    vids = list(vid_dir.glob('*.mp4')) if vid_dir.exists() else []
    if rc != 0:
        print(f"  [INFLIGHT] WARNING: watch_i2v.py exited with code {rc}")
    if rc != 0:
        print(f"  [INFLIGHT] WARNING: inflight produced an incomplete result ({len(vids)} videos)")
        print(f"  [INFLIGHT] Falling back to finalized generation for missing clips...")
        return False
    if vids:
        print(f"  [INFLIGHT] watch_i2v done -> vid_img/ ({len(vids)} videos)")
        return True
    else:
        print(f"  [INFLIGHT] WARNING: vid_img/ is empty — inflight produced no videos")
        print(f"  [INFLIGHT] Falling back to standard i2v generation...")
        return False


def _run_post_pipeline_silent(
    project_dir: str, action: str, prompt_mode: str = 'single',
    run_yt_pack: bool = False,
    use_codex_adapt: bool = False,
) -> None:
    """Запуск пост-пайплайн генерации в silent-режиме (без интерактивных вопросов).

    Args:
        project_dir: Путь к проекту
        action: image-only or explicit image-provider -> video-provider route,
            for example `veo_i2v` with `PIPELINE_IMG_GEN=cinai`
        prompt_mode: 'single' (один промпт на все) или 'perclip' (оригинальные промпты)
        use_codex_adapt: GPT-адаптация промптов для VEO i2v
    """
    if not action:
        return
    from modules.non_ai_image_policy import (
        apply_policy as _apply_non_ai_policy,
        enabled as _non_ai_enabled,
        protect_unresolved as _protect_non_ai,
    )
    _non_ai_mode = _non_ai_enabled()
    if _non_ai_mode:
        plan_path = Path(project_dir) / 'montage_plan.json'
        try:
            _apply_non_ai_policy(plan_path)
        except Exception as exc:
            print(f"  [Non-AI] configuration error: {exc}")
            return
        print("  [Non-AI] ordinary ImageGen/VideoGen disabled; external/static routes only")
        action = 'skip'
    if action == 'skip':
        external_stages_enabled = any(
            os.environ.get(key, '').lower() in ('1', 'true', 'yes', 'on')
            for key in (
                'REAL_PHOTO_ENABLED',
                'STOCK_ENABLED',
                'YOUTUBE_FOOTAGE_ENABLED',
                'INFOGRAPHIC_ENABLED',
                'ENTITY_OVERLAY_ENABLED',
            )
        )
        if not external_stages_enabled:
            return
        print("  [Silent] Neural generation skipped; running enabled external/static stages")

    # ── Формат кадра ролика (16:9 / 9:16 / 1:1) ────────────────────────────
    # Единый источник — VEONONSTOP_ASPECT_RATIO (радио Ratio в GUI). От него
    # считаются целевые размеры для Real Photo / Stock / Entity-карточек —
    # раньше тут были захардкожены 1920x1080 и вертикальный ролик получал
    # горизонтальные стадии.
    _frame_ar = (config.VEONONSTOP_ASPECT_RATIO or '16:9').strip()
    if _frame_ar == '9:16':
        _frame_w, _frame_h = 1080, 1920
    elif _frame_ar == '1:1':
        _frame_w, _frame_h = 1080, 1080
    else:
        _frame_w, _frame_h = 1920, 1080

    # ── Интро-гейты ВСЕХ стадий — до старта стадий и генерации ─────────────
    # Гейт снимает маркер со вступления, а генераторы по этому же маркеру
    # решают, брать клип или пропустить. Пока каждый гейт срабатывал внутри
    # своей (фоновой) стадии, ImageGen успевал прочитать план раньше — видел
    # ещё не снятый маркер, пропускал клип как внешний, а гейт снимал метку в
    # пустоту: кадра не делал никто (26.08: клип 3 ушёл в i2v без картинки).
    try:
        from modules.clip_sources import apply_stage_intro_gates
        apply_stage_intro_gates(project_dir, printer=lambda m: print(m))
    except Exception as _gate_exc:                   # noqa: BLE001
        print(f"  [Intro gate] общий барьер пропущен: {_gate_exc}")
        logging.exception("Stage intro gates failed for %s: %s",
                          project_dir, _gate_exc)

    # ── Real Photo stage (between Director output and ImgGen/Veo) ──────────
    # Triggered by env var REAL_PHOTO_ENABLED=1 (set by GUI / .env).
    # Phase 1 (selector): синхронно — Codex picks clips, marks `source: real_photo_pending`
    # в montage_plan. ImgGen/Veo читают marker и пропускают эти клипы.
    # Phase 2 (downloads): daemon thread — параллельно с ImgGen скачивает фото в generated/{id}.png.
    # Перед video_concat (и перед i2v, если он запущен ПОСЛЕ) поток джойнится.
    _real_photo_thread = None
    _real_photo_holder = [None]   # mutable container for summary
    _real_photo_proc = None       # processor instance — needed для thread'а
    _real_photo_selections = None
    import threading as _rp_threading
    _real_photo_stop = _rp_threading.Event()  # сигнал "видео готово — стоп загрузку"
    if os.environ.get('REAL_PHOTO_ENABLED', '0').lower() in ('1', 'true', 'yes'):
        try:
            from modules.real_photo import RealPhotoProcessor
            from pathlib import Path as _PathRP
            print()
            print("  " + "=" * 56)
            print("  REAL PHOTO STAGE — archival photo selector (sync)")
            print("  " + "=" * 56)
            _rp_target = float(os.environ.get('REAL_PHOTO_RATIO_TARGET',
                                              getattr(config, 'REAL_PHOTO_RATIO_TARGET', 0.40)))
            _rp_min    = float(os.environ.get('REAL_PHOTO_RATIO_MIN',
                                              getattr(config, 'REAL_PHOTO_RATIO_MIN', 0.30)))
            _rp_max    = float(os.environ.get('REAL_PHOTO_RATIO_MAX',
                                              getattr(config, 'REAL_PHOTO_RATIO_MAX', 0.55)))
            _rp_srcs_raw = os.environ.get('REAL_PHOTO_SOURCES', '')
            if 'REAL_PHOTO_SOURCES' in os.environ:
                _rp_srcs = [s.strip() for s in _rp_srcs_raw.split(',') if s.strip()]
            else:
                _rp_srcs = getattr(config, 'REAL_PHOTO_SOURCES',
                                   ['wikimedia', 'nasa', 'loc', 'met'])
            _real_photo_proc = RealPhotoProcessor(
                project_dir=_PathRP(project_dir),
                target_ratio=_rp_target, min_ratio=_rp_min, max_ratio=_rp_max,
                sources=_rp_srcs,
                codex_model=getattr(config, 'REAL_PHOTO_CODEX_MODEL', None),
                target_w=_frame_w, target_h=_frame_h,
                fps=getattr(config, 'VIDEO_FPS', 60),
            )
            _real_photo_selections = _real_photo_proc.select_phase()
            if _real_photo_selections:
                # Spawn background thread for downloads — parallel with ImgGen.
                # Общий deadline защищает от вечного зависания; после нейрогенерации
                # _wait_real_photo даёт EPF отдельную короткую фору перед fallback.
                import threading as _rp_th
                import time as _rp_time
                _rp_deadline = _rp_time.time() + int(getattr(config, 'REAL_PHOTO_WAIT_TIMEOUT', 1800))
                def _rp_worker():
                    try:
                        _real_photo_holder[0] = _real_photo_proc.process_phase(
                            _real_photo_selections, stop_event=_real_photo_stop, deadline_ts=_rp_deadline)
                    except Exception as _rpe:
                        print(f"  [Real Photo] BG download failed: {_rpe}")
                        logging.debug(traceback.format_exc())
                        _real_photo_holder[0] = {'error': str(_rpe)}
                _real_photo_thread = _rp_th.Thread(target=_rp_worker, daemon=True, name='real-photo-bg')
                _real_photo_thread.start()
                _rp_to_min = int(getattr(config, 'REAL_PHOTO_WAIT_TIMEOUT', 1800)) // 60
                _rp_tail_wait = max(
                    0, int(getattr(config, 'REAL_PHOTO_PIPELINE_WAIT_TIMEOUT', 100))
                )
                print(f"  [Real Photo] Background download started for {len(_real_photo_selections)} clips")
                print(f"  [Real Photo] Качает параллельно генерации; после генерации ждём ещё "
                      f"{_rp_tail_wait}с, общий лимит {_rp_to_min} мин\n")
            else:
                print("  [Real Photo] No clips selected — skipping\n")
        except Exception as e:
            print(f"  [Real Photo] Selector failed (continuing pipeline): {e}")
            logging.debug(traceback.format_exc())

    # ── Stock stage (между Director и ImgGen/Veo) ──────────────────────────
    # Клипы уже размечены режиссёром в Pass 1 (`source: stock_pending`) — свой
    # селектор не нужен, сразу качаем.
    # Фоновый поток, как real_photo: качает параллельно генерации, не тормозя её.
    # От дырок страхует общий Pre-concat fallback ниже: он ловит клипы по ФАКТУ
    # отсутствия медиа, снимает любой source-маркер и догенеривает картинкой по
    # промпту из Pass 2 (промпты пишутся и для помеченных клипов —
    # STOCK_PROMPT_FALLBACK / REAL_PHOTO_PROMPT_FALLBACK).
    _stock_thread = None
    _stock_holder = [None]
    if os.environ.get('STOCK_ENABLED', 'false').lower() in ('1', 'true', 'yes'):
        try:
            from modules.stock_stage import run_stock_stage
            from pathlib import Path as _PathST
            import threading as _st_th
            import time as _st_time
            print()
            print("  " + "=" * 56)
            print("  STOCK STAGE — real footage/photos (background)")
            print("  " + "=" * 56)
            # Свой таймаут, не общий с real_photo: видео качается дольше архивных фото
            _st_timeout = int(os.environ.get('STOCK_WAIT_TIMEOUT',
                                             getattr(config, 'STOCK_WAIT_TIMEOUT', 1800)))
            _st_deadline = _st_time.time() + _st_timeout

            def _stock_worker():
                try:
                    _stock_holder[0] = run_stock_stage(
                        _PathST(project_dir),
                        target_w=_frame_w, target_h=_frame_h,
                        fps=getattr(config, 'VIDEO_FPS', 60),
                        stop_event=_real_photo_stop,   # общая стоп-кнопка пайплайна
                        deadline_ts=_st_deadline,
                    )
                except Exception as _ste:
                    print(f"  [Stock] BG stage failed: {_ste}")
                    logging.debug(traceback.format_exc())
                    _stock_holder[0] = {'error': str(_ste)}

            _stock_thread = _st_th.Thread(target=_stock_worker, daemon=True, name='stock-bg')
            _stock_thread.start()
            print(f"  [Stock] Качает параллельно генерации; стоп = конец генерации ИЛИ "
                  f"{_st_timeout // 60} мин (что раньше)")
            print("  [Stock] Недокачанные → догенерация по промпту режиссёра\n")
        except Exception as e:
            print(f"  [Stock] стадия не стартовала (продолжаю без стока): {e}")
            logging.debug(traceback.format_exc())

    # ── Entity overlays (карточки персон/мест) ─────────────────────────────
    # Раньше качались ВНУТРИ конката (этап 8.4) и держали его: 20 карточек ×
    # (Wikipedia + скачивание) — минуты простоя, прервать нечем. Теперь качаем
    # заранее и параллельно генерации; конкат возьмёт готовое из кэша.
    # Карточки независимы → частичный результат нормален: не успели 8 из 20 —
    # в ролике будет 12 карточек, а не ошибка.
    # YouTube/user-footage stage runs independently from Stock and Real Photo.
    _youtube_thread = None
    _youtube_holder = [None]
    _youtube_stop = _rp_threading.Event()

    if os.environ.get('YOUTUBE_FOOTAGE_ENABLED', 'false').lower() in ('1', 'true', 'yes'):
        try:
            from modules.youtube_stage import run_youtube_stage
            from pathlib import Path as _PathYT
            import threading as _yt_th

            print()
            print("  " + "=" * 56)
            print("  YOUTUBE FOOTAGE STAGE - user library / YouTube (background)")
            print("  " + "=" * 56)

            def _youtube_worker():
                try:
                    _youtube_holder[0] = run_youtube_stage(
                        _PathYT(project_dir),
                        target_w=_frame_w,
                        target_h=_frame_h,
                        fps=getattr(config, 'VIDEO_FPS', 60),
                        # Real Photo completion must not cancel YouTube.
                        stop_event=_youtube_stop,
                        deadline_ts=None,
                    )
                except Exception as _yte:
                    print(f"  [YouTube] BG stage failed: {_yte}")
                    logging.debug(traceback.format_exc())
                    _youtube_holder[0] = {'error': str(_yte)}

            _youtube_thread = _yt_th.Thread(
                target=_youtube_worker,
                daemon=True,
                name='youtube-footage-bg',
            )
            _youtube_thread.start()
            print(
                "  [YouTube] started in background; the wait timer begins only "
                "when the pipeline is otherwise ready for concat"
            )
        except Exception as e:
            print(f"  [YouTube] stage did not start: {e}")
            logging.debug(traceback.format_exc())

    _entity_thread = None
    _entity_holder = [None]
    if os.environ.get('ENTITY_OVERLAY_ENABLED', 'false').lower() in ('1', 'true', 'yes', 'on'):
        try:
            from pathlib import Path as _PathEnt
            import threading as _ent_th
            import time as _ent_time
            print()
            print("  " + "=" * 56)
            print("  ENTITY OVERLAYS — person/place cards (background)")
            print("  " + "=" * 56)
            _ent_timeout = int(os.environ.get('ENTITY_OVERLAY_WAIT_TIMEOUT',
                                              getattr(config, 'ENTITY_OVERLAY_WAIT_TIMEOUT', 1800)))
            _ent_deadline = _ent_time.time() + _ent_timeout

            def _entity_worker():
                try:
                    from modules.entity_overlay import plan_and_render_entity_overlays as _plan_ent_bg
                    # size — целевое разрешение проекта; если конкат соберёт в другом,
                    # карточки дорендерятся из кэша локально, без сети.
                    _ent_size = os.environ.get('ENTITY_OVERLAY_SIZE', f'{_frame_w}x{_frame_h}')
                    _entity_holder[0] = _plan_ent_bg(
                        _PathEnt(project_dir),
                        size=_ent_size,
                        stop_event=_real_photo_stop,   # общая стоп-кнопка пайплайна
                        deadline_ts=_ent_deadline,
                    )
                except Exception as _ee:
                    print(f"  [Entity] BG failed: {_ee}")
                    logging.debug(traceback.format_exc())
                    _entity_holder[0] = None

            _entity_thread = _ent_th.Thread(target=_entity_worker, daemon=True, name='entity-bg')
            _entity_thread.start()
            print(f"  [Entity] Качает параллельно генерации; стоп = конец генерации ИЛИ "
                  f"{_ent_timeout // 60} мин (что раньше)")
            print("  [Entity] Конкат возьмёт готовые карточки из кэша и качать не будет\n")
        except Exception as e:
            print(f"  [Entity] стадия не стартовала (карточки соберёт конкат): {e}")
            logging.debug(traceback.format_exc())

    def _wait_entity(*, label="i2v"):
        """Стоп + join фоновой entity-стадии перед финалом.

        Не успел — не беда: конкат возьмёт из кэша то, что готово (cache_only),
        недостающие карточки просто не появятся в ролике.
        """
        nonlocal _entity_thread
        if _entity_thread is None:
            return
        if _entity_thread.is_alive():
            print(f"  [Entity] {label}: стоп загрузку карточек (готовые — в кэше)")
            _real_photo_stop.set()
            _entity_thread.join(timeout=120)
            if _entity_thread.is_alive():
                print("  [Entity] поток не завершился за 120с — иду дальше")
        _cards = _entity_holder[0]
        if isinstance(_cards, list):
            print(f"  [Entity] итог: {len(_cards)} карточек готово")
        _entity_thread = None    # idempotent

    def _wait_stock(*, label="i2v"):
        """Стоп + join фоновой стоковой стадии. Вызывается перед всем, что пишет
        в vid_img/ или читает montage_plan для генерации."""
        nonlocal _stock_thread
        if _stock_thread is None:
            return
        if _stock_thread.is_alive():
            if _non_ai_mode:
                _stock_wait = max(
                    1, int(getattr(config, 'STOCK_WAIT_TIMEOUT', 1800)))
                print(f"  [Stock] {label}: Non-AI mode, waiting up to {_stock_wait}s")
                _stock_thread.join(timeout=_stock_wait)
            else:
                print(f"  [Stock] {label}: стоп загрузку (недокачанные → догенерация по промпту)")
                _real_photo_stop.set()
                _stock_thread.join(timeout=120)   # грейс на завершение текущего клипа
            if _stock_thread.is_alive():
                print("  [Stock] wait expired; unresolved clips remain non-AI pending")
                _real_photo_stop.set()
                _stock_thread.join(timeout=15)
        st = _stock_holder[0]
        if isinstance(st, dict) and not st.get('error') and st.get('total'):
            print(f"  [Stock] итог: {st.get('ok', 0)} из стока, "
                  f"{st.get('fallback', 0)} → нейрогенерация")
        _stock_thread = None   # idempotent: повторные вызовы — no-op

    def _wait_youtube(*, label="i2v"):
        """Join YouTube Footage before fallback or concat."""
        nonlocal _youtube_thread
        if _youtube_thread is None:
            return
        wait_expired = False
        if _youtube_thread.is_alive():
            wait_sec = max(1, int(getattr(config, 'YOUTUBE_WAIT_TIMEOUT', 500)))
            print(
                f"  [YouTube] {label}: all other stages are ready; "
                f"waiting up to {wait_sec}s before EPF fallback"
            )
            _youtube_thread.join(timeout=wait_sec)
        if _youtube_thread.is_alive():
            wait_expired = True
            print(
                "  [YouTube] concat wait expired; stopping YouTube and routing "
                "unresolved clips to EPF/Real Photo"
            )
            _youtube_stop.set()
            # The active scene may already contain useful YouTube fragments.
            # Give it one EPF-search budget to render only the missing tail and
            # commit the hybrid clip before full fallback handles untouched
            # youtube_pending scenes.
            _youtube_finish_wait = max(
                30,
                int(getattr(config, 'REAL_PHOTO_EPF_SEARCH_TIMEOUT', 180) or 180)
                + 120,
            )
            _youtube_thread.join(timeout=_youtube_finish_wait)
        if wait_expired:
            try:
                from modules.youtube_stage import fallback_pending_youtube
                fallback_result = fallback_pending_youtube(
                    _PathYT(project_dir),
                    target_w=_frame_w,
                    target_h=_frame_h,
                    fps=getattr(config, 'VIDEO_FPS', 60),
                )
                print(
                    f"  [YouTube] EPF fallback selected "
                    f"{fallback_result.get('selected', 0)} clips"
                )
                if fallback_result.get('error'):
                    print(
                        f"  [YouTube] EPF fallback error: "
                        f"{fallback_result.get('error')}"
                    )
            except Exception as fallback_exc:
                print(f"  [YouTube] EPF fallback failed: {fallback_exc}")
                logging.debug(traceback.format_exc())
        yt = _youtube_holder[0]
        if isinstance(yt, dict):
            print(
                f"  [YouTube] result: {yt.get('ok', 0)} ok / "
                f"{yt.get('failed', 0)} failed / {yt.get('total', 0)} total"
            )
        _youtube_thread = None

    def _wait_real_photo(*, label="i2v"):
        """Give Real Photo a bounded final window before enabling AI fallback."""
        nonlocal _real_photo_thread
        if _real_photo_thread is None:
            return
        if _real_photo_thread.is_alive():
            _rp_tail_wait = max(0, int(
                getattr(
                    config,
                    'REAL_PHOTO_WAIT_TIMEOUT' if _non_ai_mode
                    else 'REAL_PHOTO_PIPELINE_WAIT_TIMEOUT',
                    1800 if _non_ai_mode else 100,
                )
            ))
            print(f"  [Real Photo] {label}: жду EPF ещё до {_rp_tail_wait}с "
                  f"{'(Non-AI mode)' if _non_ai_mode else 'до AI fallback'}")
            _real_photo_thread.join(timeout=_rp_tail_wait)
        if _real_photo_thread.is_alive():
            print("  [Real Photo] финальный wait истёк — стоп остаток, "
                  "недокачанные → догенерация")
            _real_photo_stop.set()
            _real_photo_thread.join(timeout=15)
            if _real_photo_thread.is_alive():
                print("  [Real Photo] поток не завершился за 15с после стопа — иду дальше")
        rp = _real_photo_holder[0]
        if rp and 'rendered' in rp:
            print(f"  [Real Photo] Done: {rp.get('rendered', 0)}/{rp.get('selected', 0)} rendered "
                  f"({rp.get('downloaded_mb', 0)} MB)")
        elif rp and 'error' in rp:
            print(f"  [Real Photo] WARNING: download failed: {rp.get('error')}")
        _real_photo_thread = None  # idempotent: future calls no-op

    p_dir = str(project_dir)
    ar = config.VEONONSTOP_ASPECT_RATIO

    # GUI may override key slot and parallel via env vars
    imggen_key_slot  = (os.environ.get('VARAGENT_IMGGEN_KEY_SLOT')
                        or os.environ.get('VEONONSTOP_IMGGEN_KEY_SLOT')
                        or '1')
    video_key_slot   = (os.environ.get('VARAGENT_VIDEO_KEY_SLOT')
                        or os.environ.get('VEONONSTOP_VIDEO_KEY_SLOT')
                        or '1')
    imggen_parallel  = int(os.environ.get('VARAGENT_IMGGEN_PARALLEL',
                                          os.environ.get('VEONONSTOP_MAX_PARALLEL',
                                                         config.VEONONSTOP_MAX_PARALLEL)))
    video_parallel   = int(os.environ.get('VARAGENT_VIDEO_PARALLEL',
                                          os.environ.get('VEONONSTOP_MAX_PARALLEL',
                                                         config.VEONONSTOP_MAX_PARALLEL)))
    inflight_mode    = os.environ.get('VARAGENT_INFLIGHT_MODE', '0') == '1'
    fg_dual_key      = os.environ.get('FASTGEN_DUAL_KEY', '0') == '1'
    vislide_interval = int(os.environ.get('VARAGENT_VISLIDE_INTERVAL', '0'))
    _UPS_MAP = {'2k': 'UPSAMPLE_IMAGE_RESOLUTION_2K', '4k': 'UPSAMPLE_IMAGE_RESOLUTION_4K'}
    imggen_upscale   = _UPS_MAP.get(config.VEONONSTOP_IMAGE_UPSCALE.lower())
    _inflight_done_marker = Path(p_dir) / 'generated' / '.imagegen_done'
    if inflight_mode:
        _inflight_done_marker.unlink(missing_ok=True)

    def _mark_inflight_imagegen_done() -> None:
        if not inflight_mode:
            return
        try:
            _inflight_done_marker.parent.mkdir(parents=True, exist_ok=True)
            _inflight_done_marker.write_text(str(time.time()), encoding='utf-8')
        except OSError as exc:
            print(f"  [INFLIGHT] Could not write ImageGen done marker: {exc}")

    def _resolve_fastgen_slot(slot: str, allow_dual: bool = False):
        slot_norm = str(slot or '1').lower()
        slot_norm = {
            'key1': '1', 'main': '1',
            'key2': '2', 'backup': '2',
            'key3': '3', 'key4': '4',
        }.get(slot_norm, slot_norm)
        key1 = getattr(config, 'FASTGEN_API_KEY', '') or ''
        keys = {
            '1': key1,
            '2': (getattr(config, 'FASTGEN_API_KEY_2', '') or
                  getattr(config, 'FASTGEN_API_KEY_BACKUP', '') or ''),
            '3': getattr(config, 'FASTGEN_API_KEY_3', '') or '',
            '4': getattr(config, 'FASTGEN_API_KEY_4', '') or '',
        }
        if slot_norm in ('2', '3', '4'):
            _slot_key = keys.get(slot_norm) or ''
            return (_slot_key or key1 or None, False,
                    slot_norm if _slot_key and _slot_key != key1 else '1')
        if allow_dual and slot_norm in ('both', 'all', '1,2', '1,2,3,4'):
            _extra = [v for k, v in keys.items() if k != '1' and v and v != key1]
            return (key1 or None, bool(_extra), 'all' if _extra else '1')
        return (key1 or None, False, '1')

    # Legacy: VEONONSTOP_MAX_PARALLEL still applies when not overridden
    parallel = video_parallel

    # ── Codex VEO adapt (parallel with imggen) ──────────────────────────
    import threading as _th
    _adapt_result = [None]
    _adapt_event = _th.Event()

    def _run_adapt():
        try:
            from modules.codex_adapt import adapt_prompts_for_veo
            _adapt_result[0] = adapt_prompts_for_veo(p_dir)
        except Exception as e:
            print(f"  [codex-adapt] Failed: {e}")
        finally:
            _adapt_event.set()

    action = POST_ACTION_ALIASES.get(action, action)

    _should_adapt = (use_codex_adapt
                     and prompt_mode == 'perclip'
                     and action in (
                         'fastgen_i2v', 'veo_i2v',
                         'both_i2v', INTRO_I2V_T2V_MODE,
                     ))
    if _should_adapt:
        _th.Thread(target=_run_adapt, daemon=True, name='codex-adapt').start()
        print("  [codex-adapt] VEO prompt adaptation started in background")
    else:
        _adapt_event.set()
    # ────────────────────────────────────────────────────────────────────

    def _get_vislide_clip_ids() -> list:
        """Читает montage_plan.json и возвращает только анимируемые clip_ids для vislide."""
        import json as _json
        plan_path = Path(project_dir) / 'montage_plan.json'
        if not plan_path.exists():
            return []
        try:
            data = _json.loads(plan_path.read_text(encoding='utf-8-sig'))
            plan = data.get('montage_plan', data)
            clips = plan.get('clips', [])
        except Exception:
            return []
        intro_dur = config.INTRO_BLOCK_DURATION
        animated = _vislide_clip_ids(clips, vislide_interval, intro_dur=intro_dur)
        n_intro = sum(1 for c in clips if c.get('startTime', 0) < intro_dur)
        print(f"  [Vislide] interval={vislide_interval}, intro={intro_dur}s ({n_intro} clips): "
              f"{len(animated)}/{len(clips)} clips → i2v")
        return animated

    def _get_intro_i2v_t2v_clip_ids() -> tuple[list[int], list[int]]:
        """Split the montage at the configured intro boundary for hybrid video."""
        import json as _json
        plan_path = Path(project_dir) / 'montage_plan.json'
        if not plan_path.exists():
            return [], []
        try:
            data = _json.loads(plan_path.read_text(encoding='utf-8-sig'))
            plan = data.get('montage_plan', data)
            clips = plan.get('clips', [])
        except Exception as exc:
            print(f"  [Intro I2V + T2V] Could not read montage plan: {exc}")
            return [], []
        intro_ids, t2v_ids = split_intro_i2v_t2v_clip_ids(
            clips, config.INTRO_BLOCK_DURATION)
        print(
            f"  [Intro I2V + T2V] intro={config.INTRO_BLOCK_DURATION}s: "
            f"{len(intro_ids)} clip(s) -> ImageGen + I2V, "
            f"{len(t2v_ids)} clip(s) -> T2V"
        )
        return intro_ids, t2v_ids

    def _vislide_copy_static(animated_ids: list):
        """Копирует картинки не-анимируемых клипов из generated/ → vid_img/ как статик-фолбек."""
        import json as _json, shutil
        p = Path(project_dir)
        plan_path = p / 'montage_plan.json'
        if not plan_path.exists():
            return
        try:
            data = _json.loads(plan_path.read_text(encoding='utf-8-sig'))
            plan = data.get('montage_plan', data)
            all_ids = [c['id'] for c in plan.get('clips', [])]
        except Exception:
            return
        animated_set = set(animated_ids)
        gen_dir = p / 'generated'
        vid_dir = p / 'vid_img'
        vid_dir.mkdir(exist_ok=True)
        copied = 0
        for cid in all_ids:
            if cid in animated_set:
                continue
            # уже есть mp4 — пропускаем
            if (vid_dir / f"{cid:03d}.mp4").exists():
                continue
            # ищем картинку
            src = None
            for ext in ('.png', '.jpg', '.jpeg', '.webp'):
                candidate = gen_dir / f"{cid:03d}{ext}"
                if candidate.exists():
                    src = candidate
                    break
            if src:
                dest = vid_dir / f"{cid:03d}{src.suffix}"
                shutil.copy(str(src), str(dest))
                copied += 1
        if copied:
            print(f"  [Vislide] Static fallback: {copied} images copied to vid_img/")

    def _resolve_veo_key(slot: str) -> list:
        """Returns list of 1-based key indices for the given slot."""
        slot = str(slot or '1').strip().lower()
        slot = {
            'key1': '1', 'main': '1',
            'key2': '2', 'backup': '2',
            'key3': '3', 'key4': '4',
        }.get(slot, slot)
        ALL_KEYS = [
            config.VEONONSTOP_API_KEY,
            config.VEONONSTOP_API_KEY_2,
            config.VEONONSTOP_API_KEY_3,
            config.VEONONSTOP_API_KEY_4,
        ]
        if slot in ('both', 'all'):
            active = [i + 1 for i, k in enumerate(ALL_KEYS) if k]
            return active if active else [1]
        if ',' in slot:
            indices = []
            for s in slot.split(','):
                try:
                    idx = int(s.strip())
                    if 1 <= idx <= 4 and ALL_KEYS[idx - 1]:
                        indices.append(idx)
                except (ValueError, TypeError):
                    pass
            return indices if indices else _first_filled(ALL_KEYS)
        try:
            idx = int(slot)
        except (ValueError, TypeError):
            idx = 1
        if 1 <= idx <= 4 and ALL_KEYS[idx - 1]:
            return [idx]
        return _first_filled(ALL_KEYS)

    def _apply_infographic_intro_gate() -> None:
        """Снять маркер `infographic` со вступления — ДО старта любых стадий.

        Интро-гейт: диаграмма во вступлении убивает хук. Своя граница у стадии
        (у Real Photo и стока — собственные, независимые).

        Зовётся СИНХРОННО перед запуском фоновой инфографики и ImageGen.
        Раньше гейт жил внутри `_infographic_clip_ids()`, то есть срабатывал уже
        в фоновом потоке — и ImageGen, стартовавший параллельно, успевал
        прочитать план со ЕЩЁ НЕ снятым маркером, считал клип внешним и
        пропускал его. Кадра не появлялось ни у инфографики (маркер снят), ни у
        генерации (успела отфильтровать) → клип уходил в i2v без картинки
        (прогон 26.08: `IDs: 3` в «images missing», гонка строк 477 vs 489).
        Функция идемпотентна: повторный вызов не найдёт маркеров и ничего не
        сделает.
        """
        if not getattr(config, 'INFOGRAPHIC_ENABLED', False):
            return
        _ig_gate = float(getattr(config, 'INFOGRAPHIC_START_SEC', 0) or 0)
        if _ig_gate <= 0:
            return
        try:
            from modules.clip_sources import INFOGRAPHIC_SOURCES, apply_intro_gate
            apply_intro_gate(Path(p_dir) / 'montage_plan.json',
                             INFOGRAPHIC_SOURCES, _ig_gate,
                             label='Infographic', printer=print)
        except Exception as exc:
            print(f"  [Infographic] интро-гейт пропущен: {exc}")
            logging.exception(
                "Infographic intro gate skipped for %s (start_sec=%s): %s",
                p_dir, _ig_gate, exc)

    def _infographic_clip_ids() -> list[int]:
        """Return Pass 1 clips reserved for the dedicated static infographic route."""
        if not getattr(config, 'INFOGRAPHIC_ENABLED', False):
            return []
        try:
            import json as _json
            raw = _json.loads((Path(p_dir) / 'montage_plan.json').read_text(encoding='utf-8-sig'))
            plan = raw.get('montage_plan', raw)
            return [
                int(clip['id']) for clip in plan.get('clips', [])
                if clip.get('source') == 'infographic' and clip.get('id') is not None
            ]
        except Exception as exc:
            print(f"  [Infographic] Could not read montage plan: {exc}")
            return []

    def _run_infographic_images(clip_ids: list[int] | None = None) -> dict:
        """Generate static infographics through their own provider/model, then stage them."""
        from modules.clip_sources import materialize_static_images

        target_ids = clip_ids if clip_ids is not None else _infographic_clip_ids()
        if not target_ids:
            return {'generated': 0, 'failed': 0, 'results': []}

        provider = (getattr(config, 'INFOGRAPHIC_IMG_PROVIDER', '') or '').strip().lower()
        # Оператор инфографики не выбран (или доля инфографики была нулевой, а
        # сцены пришли сюда фолбэком из архивов) — берём ПЕРВЫЙ доступный
        # генератор картинок и модель GPT, если провайдер её умеет, иначе
        # Banana (требование пользователя 26.08). Без этого такие сцены
        # оставались без исполнителя.
        _auto_model = None
        if provider not in ('fastgen', 'veononstop', 'cinai'):
            for _cand, _ready in (
                ('cinai', bool(getattr(config, 'CINAI_ACCESS_TOKEN', ''))),
                ('veononstop', _has_any_veo_key()),
                ('fastgen', bool(getattr(config, 'FASTGEN_API_KEY', ''))),
            ):
                if not _ready:
                    continue
                provider = _cand
                if _cand == 'cinai':
                    _auto_model = 'gpt-image-2'          # у CinAI GPT есть
                elif _cand == 'veononstop':
                    _auto_model = 'imagen'               # режим; GPT-модели нет → Banana ниже
                else:
                    _auto_model = 'GEM_PIX_2'            # FastGen: Banana-семейство
                print(f"  [Infographic] оператор не задан — беру {provider}"
                      f" (модель {_auto_model})")
                break
            else:
                print("  [Infographic] нет ни одного доступного генератора картинок")
                return {'generated': 0, 'failed': len(target_ids), 'results': [],
                        'error': 'no image generator configured'}
        print(f"  [Infographic] {len(target_ids)} static clips -> {provider}")
        try:
            if provider == 'fastgen':
                info_api, info_dual, _ = _resolve_fastgen_slot(imggen_key_slot, allow_dual=True)
                if not info_api:
                    raise RuntimeError("FASTGEN_API_KEY is not configured")
                result = generate_all_images(
                    project_dir=p_dir,
                    clip_ids=target_ids,
                    model=_auto_model or getattr(config, 'INFOGRAPHIC_FASTGEN_MODEL', None),
                    api_key=info_api,
                    dual_key=info_dual,
                    preflight=not _skip_pf,
                    silent=True,
                    include_infographics=True,
                )
            elif provider == 'veononstop':
                if not _has_any_veo_key():
                    raise RuntimeError("no VeoNonStop key is configured")
                info_mode = (getattr(config, 'INFOGRAPHIC_VEONONSTOP_MODE', 'imagen') or 'imagen').strip()
                result = veo_generate_all_images(
                    project_dir=p_dir,
                    mode=info_mode,
                    max_parallel=imggen_parallel,
                    clip_ids=target_ids,
                    aspect_ratio=ar,
                    active_keys=_resolve_veo_key(imggen_key_slot),
                    preflight=not _skip_pf,
                    silent=True,
                    include_infographics=True,
                    banana_model_key=getattr(config, 'INFOGRAPHIC_VEONONSTOP_BANANA_MODEL', None),
                )
            elif provider == 'cinai':
                if not getattr(config, 'CINAI_ACCESS_TOKEN', ''):
                    raise RuntimeError("CINAI_ACCESS_TOKEN is not configured")
                result = cinai_generate_all_images(
                    project_dir=p_dir,
                    clip_ids=target_ids,
                    model=_auto_model or getattr(config, 'INFOGRAPHIC_CINAI_MODEL', None),
                    aspect_ratio=getattr(config, 'INFOGRAPHIC_CINAI_ASPECT_RATIO', ar),
                    quality=getattr(config, 'INFOGRAPHIC_CINAI_QUALITY', '1K'),
                    max_parallel=getattr(config, 'CINAI_MAX_PARALLEL', 6),
                    silent=True,
                    include_infographics=True,
                )
            else:
                raise RuntimeError(f"unknown INFOGRAPHIC_IMG_PROVIDER={provider!r}")
        except Exception as exc:
            print(f"  [Infographic] Generation failed: {exc}")
            logging.debug(traceback.format_exc())
            # Инфографика — ПОСЛЕДНЕЕ звено цепочки: в режиме «только не-AI» за
            # ней никого нет, и упавший провайдер оставлял сцену пустой. Пробуем
            # остальных доступных, прежде чем сдаться (требование 26.08).
            _tried = {provider}
            for _next, _ready in (
                ('cinai', bool(getattr(config, 'CINAI_ACCESS_TOKEN', ''))),
                ('veononstop', _has_any_veo_key()),
                ('fastgen', bool(getattr(config, 'FASTGEN_API_KEY', ''))),
            ):
                if _next in _tried or not _ready:
                    continue
                print(f"  [Infographic] пробую запасной генератор: {_next}")
                try:
                    if _next == 'cinai':
                        result = cinai_generate_all_images(
                            project_dir=p_dir, clip_ids=target_ids,
                            model='gpt-image-2',
                            aspect_ratio=getattr(config, 'INFOGRAPHIC_CINAI_ASPECT_RATIO', ar),
                            quality=getattr(config, 'INFOGRAPHIC_CINAI_QUALITY', '1K'),
                            max_parallel=getattr(config, 'CINAI_MAX_PARALLEL', 6),
                            silent=True, include_infographics=True)
                    elif _next == 'veononstop':
                        result = veo_generate_all_images(
                            project_dir=p_dir, mode='imagen', max_parallel=imggen_parallel,
                            clip_ids=target_ids, aspect_ratio=ar,
                            active_keys=_resolve_veo_key(imggen_key_slot),
                            preflight=not _skip_pf, silent=True, include_infographics=True,
                            banana_model_key=getattr(config, 'INFOGRAPHIC_VEONONSTOP_BANANA_MODEL', None))
                    else:
                        _fa, _fd, _ = _resolve_fastgen_slot(imggen_key_slot, allow_dual=True)
                        if not _fa:
                            continue
                        result = generate_all_images(
                            project_dir=p_dir, clip_ids=target_ids, model='GEM_PIX_2',
                            api_key=_fa, dual_key=_fd, preflight=not _skip_pf,
                            silent=True, include_infographics=True)
                    print(f"  [Infographic] запасной {_next} отработал")
                    break
                except Exception as _exc2:              # noqa: BLE001
                    _tried.add(_next)
                    print(f"  [Infographic] запасной {_next} тоже не смог: {_exc2}")
            else:
                # Все генераторы легли. Возвращаем сцены АРХИВАМ — это
                # последний рабочий путь (требование 26.08). Помечаем
                # `infographic_failed`, чтобы архивы не отправили их в
                # инфографику повторно: иначе получится петля
                # EPF → Wikimedia → инфографика → EPF.
                print("  [Infographic] ни один генератор не отработал — "
                      "возвращаю сцены архивам (real_photo_pending)")
                try:
                    from modules.clip_sources import apply_clip_source_delta

                    apply_clip_source_delta(
                        Path(p_dir) / 'montage_plan.json',
                        {int(cid): {'source': 'real_photo_pending',
                                    'infographic_failed': True}
                         for cid in target_ids},
                        log=lambda message: print(f"  [Infographic] {message}"),
                    )
                except Exception as _delta_exc:          # noqa: BLE001
                    print(f"  [Infographic] не смог вернуть сцены архивам: {_delta_exc}")
                return {'generated': 0, 'failed': len(target_ids), 'results': [],
                        'error': str(exc), 'returned_to_archives': list(target_ids)}

        materialize_static_images(p_dir)
        print(f"  [Infographic] Done: {result.get('generated', 0)} images -> generated/ + vid_img/")
        return result

    def _has_any_veo_key() -> bool:
        return any([
            getattr(config, 'VEONONSTOP_API_KEY', '') or '',
            getattr(config, 'VEONONSTOP_API_KEY_2', '') or '',
            getattr(config, 'VEONONSTOP_API_KEY_3', '') or '',
            getattr(config, 'VEONONSTOP_API_KEY_4', '') or '',
        ])

    def _flowultra_parallel() -> int:
        # Flow Ultra has its own worker budget; do not inherit Veo multi-key total.
        return 24

    def _count_generated_images() -> int:
        gen_dir = Path(project_dir) / 'generated'
        if not gen_dir.exists():
            return 0
        return sum(1 for ext in ('.png', '.jpg', '.jpeg', '.webp') for _ in gen_dir.glob(f'*{ext}'))

    def _image_exists(clip_id: int) -> bool:
        gen_dir = Path(project_dir) / 'generated'
        return any(
            (gen_dir / f"{int(clip_id):03d}{ext}").is_file()
            for ext in ('.png', '.jpg', '.jpeg', '.webp')
        )

    def _run_t2v_image_fallback(image_result: dict) -> Optional[dict]:
        """Generate videos for image IDs left by a terminal quota fallback."""
        if not image_result or not image_result.get('t2v_fallback_required'):
            return None
        clip_ids = sorted({
            int(cid) for cid in image_result.get('failed_ids', [])
            if not _image_exists(int(cid))
        })
        if not clip_ids:
            return {'generated': 0, 'failed': 0, 'failed_ids': []}
        if not _has_any_veo_key():
            print("  [T2V FALLBACK] Cannot start: no VeoNonStop video key configured")
            return {
                'generated': 0,
                'failed': len(clip_ids),
                'failed_ids': clip_ids,
            }
        prompts_file_path = None
        if _should_adapt:
            if not _adapt_event.wait(timeout=600):
                print("  [codex-adapt] Timeout - T2V fallback uses original prompts")
            else:
                prompts_file_path = _adapt_result[0]
        reason = image_result.get('t2v_fallback_reason') or 'image capacity exhausted'
        print(
            f"  [T2V FALLBACK] {reason}: generating {len(clip_ids)} remaining clip(s)"
        )
        return veo_generate_all_videos(
            project_dir=p_dir,
            mode='t2v',
            max_parallel=video_parallel,
            aspect_ratio=ar,
            single_prompt=_video_single_prompt(),
            active_keys=_resolve_veo_key(video_key_slot),
            clip_ids=clip_ids,
            silent=True,
            prompts_file_path=prompts_file_path,
        )

    def _call_image_provider(
        provider: str,
        *,
        use_claims: bool = False,
        clip_ids=None,
    ):
        """Run one image provider with the current pipeline settings."""
        provider = str(provider or '').strip().lower()
        if provider == 'fastgen':
            if not getattr(config, 'FASTGEN_API_KEY', ''):
                raise RuntimeError('FASTGEN_API_KEY not set for ImageGen')
            _img_api, _img_dual, _img_slot = _resolve_fastgen_slot(
                imggen_key_slot, allow_dual=True)
            return generate_all_images(
                project_dir=p_dir,
                clip_ids=clip_ids,
                api_key=_img_api,
                dual_key=_img_dual,
                preflight=not _skip_pf,
                silent=True,
                use_claims=use_claims,
                claim_owner='fastgen',
                allow_veo_fallback=not use_claims,
            )
        if provider == 'veononstop':
            if not _has_any_veo_key():
                raise RuntimeError('VeoNonStop key not set for ImageGen')
            return veo_generate_all_images(
                project_dir=p_dir,
                clip_ids=clip_ids,
                mode=config.VEONONSTOP_IMGGEN_MODE,
                max_parallel=imggen_parallel,
                aspect_ratio=ar,
                active_keys=_resolve_veo_key(imggen_key_slot),
                upscale_resolution=imggen_upscale,
                preflight=not _skip_pf,
                silent=True,
                max_cycles=(
                    getattr(config, 'VEONONSTOP_MAX_SILENT_CYCLES', 3)
                    if use_claims else None
                ),
                use_claims=use_claims,
                claim_owner='veononstop',
            )
        if provider == 'cinai':
            if not getattr(config, 'CINAI_ACCESS_TOKEN', ''):
                raise RuntimeError('CINAI_ACCESS_TOKEN not set for ImageGen')
            return cinai_generate_all_images(
                project_dir=p_dir,
                clip_ids=clip_ids,
                max_parallel=getattr(config, 'CINAI_MAX_PARALLEL', 6),
                model=getattr(config, 'CINAI_MODEL', 'gpt-image-2'),
                aspect_ratio=(
                    getattr(config, 'CINAI_ASPECT_RATIO', '') or ar or '16:9'
                ),
                quality=getattr(config, 'CINAI_QUALITY', '1K'),
                silent=True,
                use_claims=use_claims,
                claim_owner='cinai',
            )
        if provider == 'skip':
            return {'generated': _count_generated_images(), 'failed': 0}
        raise RuntimeError(f'Unknown ImageGen provider: {provider!r}')

    def _run_image_generation(provider: str, *, clip_ids=None):
        """Run the selected ImageGen, optionally sharing the pool with CinAI."""
        provider = str(provider or '').strip().lower()
        pool_enabled = (
            str(os.environ.get(
                'CINAI_IMAGE_POOL_ENABLED',
                '1' if getattr(config, 'CINAI_IMAGE_POOL_ENABLED', False) else '0',
            )).strip().lower() in ('1', 'true', 'yes', 'on')
            and provider in ('fastgen', 'veononstop')
        )
        if not pool_enabled:
            return _call_image_provider(provider, clip_ids=clip_ids)
        if not getattr(config, 'CINAI_ACCESS_TOKEN', ''):
            print("  [+CinAI] CINAI_ACCESS_TOKEN is empty; using only the primary ImageGen")
            return _call_image_provider(provider, clip_ids=clip_ids)

        from concurrent.futures import ThreadPoolExecutor

        print(
            f"  [+CinAI] Shared image pool: {provider} + CinAI "
            f"({getattr(config, 'CINAI_MODEL', 'gpt-image-2')}, "
            f"x{getattr(config, 'CINAI_MAX_PARALLEL', 6)})"
        )
        provider_results = {}
        with ThreadPoolExecutor(max_workers=2, thread_name_prefix='image-pool') as pool:
            futures = {
                pool.submit(
                    _call_image_provider, provider, use_claims=True,
                    clip_ids=clip_ids,
                ): provider,
                pool.submit(
                    _call_image_provider, 'cinai', use_claims=True,
                    clip_ids=clip_ids,
                ): 'cinai',
            }
            for future, label in futures.items():
                try:
                    provider_results[label] = future.result()
                except Exception as exc:
                    provider_results[label] = {
                        'generated': 0,
                        'failed': 0,
                        'failed_ids': [],
                        'error': str(exc),
                    }
                    print(f"  [+CinAI] {label} failed: {exc}")
                    logging.exception("Image pool provider %s failed", label)

        primary_failed_ids = [
            int(cid)
            for cid in provider_results.get(provider, {}).get('failed_ids', [])
            if not _image_exists(int(cid))
        ]
        if primary_failed_ids:
            print(
                f"  [+CinAI] {provider} failed {len(primary_failed_ids)} clip(s); "
                "returning them to CinAI once"
            )
            try:
                provider_results['cinai_retry'] = _call_image_provider(
                    'cinai',
                    clip_ids=primary_failed_ids,
                )
            except Exception as exc:
                provider_results['cinai_retry'] = {
                    'generated': 0,
                    'failed': len(primary_failed_ids),
                    'failed_ids': primary_failed_ids,
                    'error': str(exc),
                }
                print(f"  [+CinAI] CinAI retry failed to start: {exc}")

        cinai_result = provider_results.get('cinai', {})
        cinai_failed_ids = [
            int(cid) for cid in cinai_result.get('failed_ids', [])
            if not _image_exists(int(cid))
        ]
        cinai_failed_ids.extend(
            int(cid)
            for cid in provider_results.get('cinai_retry', {}).get(
                'failed_ids', [])
            if not _image_exists(int(cid))
        )
        cinai_failed_ids = sorted(set(cinai_failed_ids))
        fallback_result = {}
        if cinai_failed_ids:
            if _has_any_veo_key():
                print(
                    f"  [+CinAI] CinAI failed {len(cinai_failed_ids)} clip(s); "
                    "sending them directly to VeoNonStop"
                )
                fallback_result = veo_generate_all_images(
                    project_dir=p_dir,
                    mode=config.VEONONSTOP_IMGGEN_MODE,
                    max_parallel=imggen_parallel,
                    clip_ids=cinai_failed_ids,
                    aspect_ratio=ar,
                    active_keys=_resolve_veo_key(imggen_key_slot),
                    upscale_resolution=imggen_upscale,
                    preflight=not _skip_pf,
                    silent=True,
                    max_cycles=getattr(
                        config, 'VEONONSTOP_MAX_SILENT_CYCLES', 3),
                    use_claims=False,
                )
            else:
                print(
                    f"  [+CinAI] VeoNonStop fallback unavailable for "
                    f"{len(cinai_failed_ids)} CinAI failure(s): no API key"
                )

        failed_candidates = set()
        for item in provider_results.values():
            failed_candidates.update(
                int(cid) for cid in item.get('failed_ids', []))
        failed_candidates.update(
            int(cid) for cid in fallback_result.get('failed_ids', []))
        unresolved = sorted(
            cid for cid in failed_candidates if not _image_exists(cid))
        result = {
            'generated': _count_generated_images(),
            'failed': len(unresolved),
            'failed_ids': unresolved,
            'results': provider_results,
            'cinai_fallback': fallback_result,
            't2v_fallback_required': any(
                item.get('t2v_fallback_required')
                for item in list(provider_results.values()) + [fallback_result]
            ),
            't2v_fallback_reason': next(
                (
                    item.get('t2v_fallback_reason')
                    for item in list(provider_results.values()) + [fallback_result]
                    if item.get('t2v_fallback_required')
                ),
                '',
            ),
        }
        print(
            f"  [+CinAI] Pool complete: images={result['generated']}, "
            f"failed={result['failed']}"
        )
        return result

    def _video_single_prompt() -> Optional[str]:
        if prompt_mode != 'single':
            return None
        sp_path = Path(p_dir) / 'single_prompt.txt'
        if sp_path.exists():
            text = sp_path.read_text(encoding='utf-8-sig').strip()
            if text:
                print(f"  Using single_prompt.txt: {text[:50]}...")
                return text
        return 'default'

    def _start_inflight_watcher_for_engine(engine: str, *, prompts_file_path: str = None):
        old_engine = os.environ.get('VARAGENT_VIDEO_ENGINE')
        try:
            os.environ['VARAGENT_VIDEO_ENGINE'] = engine
            # Flow Ultra is pinned to FastGen Key1 in the current implementation;
            # VeoNonStop keeps the selected Veo key slot.
            key_slot = '1' if engine == 'fastgen_ultra' else video_key_slot
            engine_parallel = _flowultra_parallel() if engine == 'fastgen_ultra' else video_parallel
            return _start_inflight_watcher(
                p_dir, key_slot, engine_parallel, ar, prompt_mode,
                vislide_interval=vislide_interval,
                prompts_file_path=prompts_file_path,
                output_dir_name='vid_img_cinai' if engine == 'cinai' else 'vid_img',
            )
        finally:
            if old_engine is None:
                os.environ.pop('VARAGENT_VIDEO_ENGINE', None)
            else:
                os.environ['VARAGENT_VIDEO_ENGINE'] = old_engine

    def _run_parallel_i2v_providers(prompts_file_path: str = None) -> dict:
        from concurrent.futures import ThreadPoolExecutor, as_completed
        from modules.flowultra import generate_all_videos_flow_ultra

        _vislide_ids = _get_vislide_clip_ids() if vislide_interval >= 2 else None
        single_prompt = _video_single_prompt()
        jobs = {}

        def _run_veo_provider():
            if not _has_any_veo_key():
                print("  [BOTH] VeoNonStop skipped: no VEONONSTOP keys configured")
                return {'generated': 0, 'failed': 0, 'results': []}
            print("  [BOTH] Starting VeoNonStop i2v...")
            return veo_generate_all_videos(
                project_dir=p_dir, mode='i2v',
                max_parallel=video_parallel, aspect_ratio=ar,
                single_prompt=single_prompt,
                active_keys=_resolve_veo_key(video_key_slot),
                clip_ids=_vislide_ids,
                silent=True,
                no_cancel=True,
                prompts_file_path=prompts_file_path,
            )

        def _run_flowultra_provider():
            if not getattr(config, 'FASTGEN_API_KEY', ''):
                print("  [BOTH] Flow Ultra skipped: FASTGEN_API_KEY not configured")
                return {'generated': 0, 'failed': 0, 'results': []}
            _requested_fu_slot = str(os.environ.get('VARAGENT_FU_KEY_SLOT', '1') or '1').lower()
            if _requested_fu_slot not in ('1', 'key1', 'main'):
                print(f"  [BOTH] Flow Ultra supports only FastGen Key1 here; ignoring FU key={_requested_fu_slot}")
            _fu_api, _fu_dual_env, _fg_slot = _resolve_fastgen_slot('1', allow_dual=False)
            _fu_parallel = _flowultra_parallel()
            _fu_end_dir = str(Path(p_dir) / 'generated') if os.environ.get('VARAGENT_FU_END_IMAGE') == '1' else None
            print(f"  [BOTH] Starting FastGen Flow Ultra keyframes (fastgen_key={_fg_slot}, parallel={_fu_parallel})...")
            return generate_all_videos_flow_ultra(
                project_dir=p_dir,
                mode='keyframes',
                max_parallel=_fu_parallel,
                aspect_ratio=ar,
                clip_ids=_vislide_ids,
                single_prompt=single_prompt,
                api_key=_fu_api,
                dual_key=_fu_dual_env,
                end_image_dir=_fu_end_dir,
                prompts_file_path=prompts_file_path,
                silent=True,
                no_cancel=True,
            )

        with ThreadPoolExecutor(max_workers=2) as executor:
            jobs[executor.submit(_run_veo_provider)] = 'VeoNonStop'
            jobs[executor.submit(_run_flowultra_provider)] = 'Flow Ultra'
            results = {}
            for fut in as_completed(jobs):
                label = jobs[fut]
                try:
                    results[label] = fut.result()
                except Exception as e:
                    print(f"  [BOTH] {label} failed: {e}")
                    logging.debug(traceback.format_exc())
                    results[label] = {'generated': 0, 'failed': 1, 'results': []}

        if _vislide_ids:
            _vislide_copy_static(_vislide_ids)
        total_failed = sum(int(r.get('failed', 0) or 0) for r in results.values())
        total_generated = sum(int(r.get('generated', 0) or 0) for r in results.values())
        print("  [BOTH] Video providers done -> vid_img/")
        for label, r in results.items():
            print(f"  [BOTH]   {label}: ok={r.get('generated', 0)} fail={r.get('failed', 0)}")
        return {'generated': total_generated, 'failed': total_failed, 'results': results}

    def _run_cinai_video_stage(
        mode: str,
        *,
        output_dir_name: str = "vid_img",
        reference_dir: Optional[str] = None,
        prompts_file_path: Optional[str] = None,
    ) -> dict:
        if not getattr(config, 'CINAI_VIDEO_ENABLED', False):
            print("  [SKIP] CINAI_VIDEO_ENABLED is false")
            return {'generated': 0, 'failed': 0, 'results': [], 'failed_ids': []}
        if not getattr(config, 'CINAI_ACCESS_TOKEN', ''):
            print("  [SKIP] CINAI_ACCESS_TOKEN not set for VideoGen")
            return {'generated': 0, 'failed': 0, 'results': [], 'failed_ids': []}
        print(
            f"  Starting CinAI VideoGen "
            f"(model={getattr(config, 'CINAI_VIDEO_MODEL', '')}, mode={mode})..."
        )
        # состояние провайдера ДО старта: он то отдаёт клип за 40с, то уходит в
        # шторм на 4-5 минут с падениями. Без этой строки медленный прогон
        # выглядит как поломка пайплайна.
        try:
            from modules.cinai_health import describe as _cinai_describe
            print(f"  {_cinai_describe()}")
        except Exception as _exc:
            logging.debug("CinAI health check skipped: %s", _exc)
        # музыка идёт параллельно в отдельном процессе — показываем, где она,
        # чтобы её прогресс не пропадал за час видео-генерации
        _report_music_status(p_dir)
        result = cinai_generate_all_videos(
            project_dir=p_dir,
            mode=mode,
            max_parallel=int(
                getattr(config, 'CINAI_VIDEO_MAX_PARALLEL', video_parallel) or video_parallel
            ),
            # Формат кадра — ЕДИНЫЙ ратио пайплайна (радио Ratio в GUI), как у
            # VeoNonStop и у inflight-вотчера (--aspect ar). Раньше бралось из
            # config.CINAI_VIDEO_ASPECT_RATIO (дефолт 16:9 существует всегда,
            # GUI его не пишет) — вертикальный проект получал горизонтальные
            # клипы, причём только в finalized-ветке.
            aspect_ratio=ar,
            model=getattr(config, 'CINAI_VIDEO_MODEL', None),
            duration=getattr(config, 'CINAI_VIDEO_DURATION', 5),
            resolution=getattr(config, 'CINAI_VIDEO_RESOLUTION', ''),
            audio=(
                str(getattr(config, 'CINAI_VIDEO_AUDIO', '')).lower()
                in ('1', 'true', 'yes', 'on')
                if getattr(config, 'CINAI_VIDEO_MODEL', '') == 'gemini-omni-flash'
                and str(getattr(config, 'CINAI_VIDEO_AUDIO', '')).strip()
                else None
            ),
            reference_dir=reference_dir,
            prompts_file_path=prompts_file_path,
            output_dir_name=output_dir_name,
            silent=True,
        )
        print(
            f"  CinAI VideoGen done: {result.get('generated', 0)} generated, "
            f"{result.get('failed', 0)} failed -> {output_dir_name}/"
        )
        return result

    def _run_parallel_veo_cinai_i2v(prompts_file_path: str = None) -> dict:
        """Run VeoNonStop and CinAI in isolated output dirs, then merge first-success."""
        from concurrent.futures import ThreadPoolExecutor, as_completed

        single_prompt = _video_single_prompt()
        cinai_stage_dir = "vid_img_cinai"
        jobs = {}

        def _run_veo():
            if not _has_any_veo_key():
                print("  [BOTH] VeoNonStop skipped: no keys configured")
                return {'generated': 0, 'failed': 0, 'results': []}
            return veo_generate_all_videos(
                project_dir=p_dir,
                mode='i2v',
                max_parallel=video_parallel,
                aspect_ratio=ar,
                single_prompt=single_prompt,
                active_keys=_resolve_veo_key(video_key_slot),
                silent=True,
                no_cancel=True,
                prompts_file_path=prompts_file_path,
            )

        def _run_cinai():
            return _run_cinai_video_stage(
                "i2v",
                output_dir_name=cinai_stage_dir,
                prompts_file_path=prompts_file_path,
            )

        with ThreadPoolExecutor(max_workers=2) as executor:
            jobs[executor.submit(_run_veo)] = "VeoNonStop"
            jobs[executor.submit(_run_cinai)] = "CinAI"
            provider_results = {}
            for future in as_completed(jobs):
                label = jobs[future]
                try:
                    provider_results[label] = future.result()
                except Exception as exc:
                    logging.debug(traceback.format_exc())
                    print(f"  [BOTH] {label} failed: {exc}")
                    provider_results[label] = {'generated': 0, 'failed': 1, 'results': []}

        primary_dir = Path(p_dir) / "vid_img"
        secondary_dir = Path(p_dir) / cinai_stage_dir
        primary_dir.mkdir(parents=True, exist_ok=True)
        merge_policy = os.environ.get("CINAI_BOTH_MERGE_POLICY", "first_success").strip().lower()
        if merge_policy not in ("first_success", "preferred_provider", "keep_all"):
            merge_policy = "first_success"
        merge_result = cinai_merge_video_outputs(
            primary_dir,
            secondary_dir,
            policy=merge_policy,
            preferred_provider=os.environ.get("CINAI_BOTH_PREFERRED_PROVIDER", "veononstop"),
        )
        merged = int(merge_result.get("merged", 0) or 0)
        try:
            from modules.cinai_video import _load_project_clips
            from modules.clip_sources import VIDEO_SKIP_SOURCES
            expected_ids = {
                int(item["id"])
                for item in _load_project_clips(Path(p_dir))
                if item.get("id") is not None
                and item.get("source") not in VIDEO_SKIP_SOURCES
            }
        except Exception:
            expected_ids = set()
        selected_ids = {
            int(path.stem)
            for path in primary_dir.glob("*.mp4")
            if path.stem.isdigit()
        }
        if expected_ids:
            selected_ids &= expected_ids
        total_failed = len(expected_ids - selected_ids) if expected_ids else sum(
            int(item.get("failed", 0) or 0) for item in provider_results.values()
        )
        provider_generated = sum(
            int(item.get("generated", 0) or 0) for item in provider_results.values()
        )
        total_generated = len(selected_ids) if expected_ids else provider_generated
        print(
            f"  [BOTH] VeoNonStop + CinAI done: selected={total_generated}, "
            f"provider_generated={provider_generated}, merged_from_cinai={merged}, "
            f"failed={total_failed}"
        )
        return {
            "generated": total_generated,
            "failed": total_failed,
            "provider_generated": provider_generated,
            "results": provider_results,
            "merged": merged,
            "overwritten": int(merge_result.get("overwritten", 0) or 0),
            "selected": merge_result.get("selected", {}),
            "merge_policy": merge_policy,
        }

    # ── REF SIZE PREFLIGHT ────────────────────────────────────────────────────
    # Compress any refs that exceed 1.5 MB before any API calls touch them.
    # (Primary compression runs in a background thread during transcription;
    #  this call is a safety net for direct invocations and any leftovers.)
    _ref_dir_pf = Path(project_dir) / 'ref'
    if _ref_dir_pf.exists():
        _ref_limit = 2.0 if action in ('fastgen', 'fastgen_i2v', 'both_i2v') else 5.0
        compress_refs(str(_ref_dir_pf), max_mb=_ref_limit)
    # ─────────────────────────────────────────────────────────────────────────

    _skip_pf = os.environ.get('VARAGENT_SKIP_PREFLIGHT', '0') == '1'

    # ── Шапка лога: печатаем ПРОВАЙДЕРОВ, которые реально отработают ──────
    # `action` — внутренний алиас пост-действия, один на несколько движков:
    # `veo_i2v` одинаково зовётся и для VeoNonStop, и для CinAI, а слоты
    # ключей ImgKey/VidKey существуют только у VeoNonStop/FastGen. Печатать
    # их на прогоне CinAI — врать в лог.
    _env_video_engine = (os.environ.get('VARAGENT_VIDEO_ENGINE', '') or '').strip().lower()
    _pipeline_img_gen = (os.environ.get('PIPELINE_IMG_GEN')
                         or getattr(config, 'PIPELINE_IMG_GEN', 'veononstop')
                         or 'veononstop').lower()

    def _img_stage_provider() -> Optional[str]:
        """Кто наполняет generated/ на этом action (None — стадии нет)."""
        if action in ('fastgen', 'fastgen_i2v', 'fastgen_ultra_i2v'):
            return 'fastgen'
        if action == 'cinai':
            return 'cinai'
        if action in ('imggen', 'veo_i2v', 'both_i2v'):
            return _pipeline_img_gen
        return None

    def _video_stage_engine() -> Optional[str]:
        """Кто наполняет vid_img/ на этом action (None — стадии нет)."""
        if action in ('fastgen', 'imggen', 'cinai', 'skip'):
            return None
        if action.startswith('fastgen_ultra'):
            return 'fastgen_ultra'
        if action == 'cinai_components':
            return 'cinai'
        if action == 'both_i2v':
            return 'both_cinai' if _env_video_engine == 'both_cinai' else 'both_flowultra'
        if action == 'fastgen_i2v':
            return 'veononstop'
        return 'cinai' if _env_video_engine == 'cinai' else 'veononstop'

    def _cinai_video_summary() -> str:
        # кламп 1..6 как в самой стадии — иначе шапка печатала бы 24
        _cw = max(1, min(int(
            getattr(config, 'CINAI_VIDEO_MAX_PARALLEL', video_parallel) or video_parallel
        ), 6))
        return (f"CinAI ({getattr(config, 'CINAI_VIDEO_MODEL', '') or '?'}, "
                f"workers {_cw})")

    def _imggen_summary() -> Optional[str]:
        provider = _img_stage_provider()
        if not provider:
            return None
        if provider == 'skip':
            return "ImageGen: skip"
        if provider == 'cinai':
            # action=='cinai' идёт мимо imggen_parallel — см. ветку ниже;
            # кламп 1..6 как в _safe_parallel самой стадии
            _iw = (getattr(config, 'CINAI_MAX_PARALLEL', 6) if action == 'cinai'
                   else (imggen_parallel or getattr(config, 'CINAI_MAX_PARALLEL', 6)))
            return f"ImageGen: CinAI (workers {max(1, min(int(_iw), 6))})"
        _label = 'FastGen' if provider == 'fastgen' else 'VeoNonStop'
        summary = f"ImageGen: {_label} (key {imggen_key_slot}, workers {imggen_parallel})"
        pool_enabled = str(os.environ.get(
            'CINAI_IMAGE_POOL_ENABLED',
            '1' if getattr(config, 'CINAI_IMAGE_POOL_ENABLED', False) else '0',
        )).strip().lower() in ('1', 'true', 'yes', 'on')
        if pool_enabled:
            summary += (
                f" + CinAI ({getattr(config, 'CINAI_MODEL', 'gpt-image-2')}, "
                f"workers {getattr(config, 'CINAI_MAX_PARALLEL', 6)})"
            )
        return summary

    def _videogen_summary() -> Optional[str]:
        engine = _video_stage_engine()
        if not engine:
            return None
        if engine == 'cinai':
            return f"VideoGen: {_cinai_video_summary()}"
        if engine == 'fastgen_ultra':
            return f"VideoGen: FastGen Flow Ultra (workers {_flowultra_parallel()})"
        _veo = f"VeoNonStop (key {video_key_slot}, workers {video_parallel})"
        if engine == 'both_cinai':
            return f"VideoGen: {_veo} + {_cinai_video_summary()}"
        if engine == 'both_flowultra':
            return (f"VideoGen: {_veo} + FastGen Flow Ultra "
                    f"(workers {_flowultra_parallel()})")
        return f"VideoGen: {_veo}"

    print(f"\n  [Silent] Post-pipeline: {action.upper()}")
    print("  " + "  |  ".join(
        [f"Ratio: {ar}"]
        + [bit for bit in (_imggen_summary(), _videogen_summary()) if bit])
        + ("  | INFLIGHT" if inflight_mode else ""))
    _settings_source = os.environ.get('VARAGENT_SETTINGS_SOURCE', '').strip()
    _fastgen_selection = os.environ.get('VARAGENT_FASTGEN_KEY_SELECTION', '').strip()
    if _settings_source or _fastgen_selection:
        print(f"  Settings source: {_settings_source or 'unknown'}"
              + (f" | FastGen selection: {_fastgen_selection}" if _fastgen_selection else ""))

    # Инфографика — ВСЕГДА фоном. У неё свой генератор и свои клипы (маркер
    # `infographic`): основной ImageGen/VideoGen/вотчеры эти клипы фильтруют,
    # а finally-хвост джойнит поток ДО Pre-concat fallback и склейки — гонок
    # нет. Раньше для i2v-веток стадия шла СИНХРОННО и задерживала старт
    # генерации на минуты (15.08: CinAI Chain ждал инфографику 2.5 мин).
    _infographic_thread = None
    _infographic_holder = [{'generated': 0, 'failed': 0, 'results': []}]

    # Интро-гейт — СИНХРОННО и ДО старта потоков: он снимает маркер `infographic`
    # со вступления, а ImageGen ниже фильтрует клипы по этому самому маркеру.
    # Сделай это в фоне — и обе стороны разойдутся: гейт снимет метку уже после
    # того, как ImageGen прочитал план, и клип останется вообще без кадра.
    _apply_infographic_intro_gate()

    def _run_infographic_worker():
        _infographic_holder[0] = _run_infographic_images()

    _infographic_thread = _th.Thread(
        target=_run_infographic_worker,
        daemon=True,
        name='infographic-bg',
    )
    _infographic_thread.start()
    if getattr(config, 'INFOGRAPHIC_ENABLED', False):
        print("  [Infographic] Static generation started in parallel with the main stages")

    # USATAYAI external generator bridge: VAR keeps its director/plan,
    # but the actual video generation can be delegated to the host app.
    # If bridge is not enabled, native VAR generation continues unchanged.
    if _maybe_run_usatayai_generator_bridge(p_dir, action, prompt_mode):
        return

    try:
        if action == 'fastgen':
            if not config.FASTGEN_API_KEY:
                print("  [SKIP] FASTGEN_API_KEY not set")
                return
            print("  Starting FastGen image generation...")
            result = _run_image_generation('fastgen')
            print(f"  FastGen done: {result.get('generated', 0)} images -> generated/")
            _mark_inflight_imagegen_done()

        elif action == 'fastgen_i2v':
            if not config.FASTGEN_API_KEY:
                print("  [SKIP] FASTGEN_API_KEY not set")
                return
            if not _has_any_veo_key():
                print("  [SKIP] VeoNonStop key not set in any slot (1-4)")
                return

            # Inflight: start watch_i2v.py so it animates images as they appear
            _watch_proc = None
            _watch_ready = _th.Event()
            if inflight_mode:
                if _should_adapt:
                    # Adapt running in background — launch watcher from a deferred thread
                    # so imggen starts immediately and isn't blocked by adapt wait
                    def _launch_watcher_after_adapt():
                        nonlocal _watch_proc
                        _inflight_prompts = None
                        if _adapt_event.wait(timeout=600) and _adapt_result[0]:
                            _inflight_prompts = _adapt_result[0]
                            print(f"  [codex-adapt] Ready: {Path(_inflight_prompts).name}")
                        else:
                            print("  [codex-adapt] Timeout — watcher uses original prompts")
                        _watch_proc = _start_inflight_watcher(p_dir, video_key_slot, video_parallel, ar, prompt_mode,
                                                               vislide_interval=vislide_interval,
                                                               prompts_file_path=_inflight_prompts)
                        _watch_ready.set()
                    _th.Thread(target=_launch_watcher_after_adapt, daemon=True, name='deferred-watcher').start()
                    print("  [INFLIGHT] Watcher will start after VEO adapt finishes")
                else:
                    _watch_proc = _start_inflight_watcher(p_dir, video_key_slot, video_parallel, ar, prompt_mode,
                                                           vislide_interval=vislide_interval)
                    _watch_ready.set()

            print("  Starting FastGen image generation...")
            result = _run_image_generation('fastgen')
            ok = result.get('generated', 0)
            img_failed = result.get('failed', 0)
            print(f"  FastGen done: {ok} images -> generated/")
            _mark_inflight_imagegen_done()

            _t2v_result = _run_t2v_image_fallback(result)
            if _t2v_result is not None:
                img_failed = int(_t2v_result.get('failed', 0) or 0)
                if img_failed > 0:
                    _save_failed_prompts(p_dir, 't2v', img_failed)
            elif img_failed > 0:
                _save_failed_prompts(p_dir, 'imggen', img_failed)

            if ok > 0:
                _inflight_ok = False
                if inflight_mode:
                    _watch_ready.wait(timeout=660)  # ensure watcher started
                if inflight_mode and _watch_proc is not None:
                    _inflight_ok = _wait_inflight_watcher(_watch_proc, p_dir)
                    if _inflight_ok:
                        vid_failed = 0  # watch_i2v manages its own retries

                if not (inflight_mode and _watch_proc is not None and _inflight_ok):
                    vid_keys = _resolve_veo_key(video_key_slot)
                    # Wait for Codex adapt if running
                    if _should_adapt:
                        if not _adapt_event.wait(timeout=600):
                            print("  [codex-adapt] Timeout — using original prompts")
                        elif _adapt_result[0]:
                            print(f"  [codex-adapt] Ready: {Path(_adapt_result[0]).name}")
                    print("  Starting VeoNonStop i2v...")
                    single_prompt = None
                    if prompt_mode == 'single':
                        sp_path = Path(p_dir) / 'single_prompt.txt'
                        if sp_path.exists():
                            single_prompt = sp_path.read_text(encoding='utf-8-sig').strip()
                            print(f"  Using single_prompt.txt: {single_prompt[:50]}...")
                        else:
                            single_prompt = 'default'
                    _vislide_ids = _get_vislide_clip_ids() if vislide_interval >= 2 else None
                    vid_result = veo_generate_all_videos(
                        project_dir=p_dir, mode='i2v',
                        max_parallel=video_parallel, aspect_ratio=ar,
                        single_prompt=single_prompt,
                        active_keys=vid_keys,
                        clip_ids=_vislide_ids,
                        silent=True,
                        prompts_file_path=_adapt_result[0],
                    )
                    vid_failed = vid_result.get('failed', 0)
                    print("  i2v done -> vid_img/")
                    if _vislide_ids:
                        _vislide_copy_static(_vislide_ids)
                    if vid_failed > 0:
                        _save_failed_prompts(p_dir, 'i2v', vid_failed)

                total_failed = img_failed + vid_failed
                if total_failed > 0:
                    marker = Path(p_dir) / 'has_failed_clips.flag'
                    marker.write_text(f"img_failed={img_failed}\nvid_failed={vid_failed}\n", encoding='utf-8')
                    print(f"  [WARNING] {total_failed} clips failed (img={img_failed}, vid={vid_failed})")
                    print(f"  Failed info saved to: failed_prompts.txt + has_failed_clips.flag")
            elif inflight_mode and _watch_proc is not None:
                _watch_proc.terminate()

        elif action == 'both_i2v':
            _both_cinai = (
                os.environ.get('VARAGENT_VIDEO_ENGINE', '').strip().lower()
                == 'both_cinai'
            )
            from pathlib import Path as _Path
            img_source = (os.environ.get('PIPELINE_IMG_GEN') or getattr(config, 'PIPELINE_IMG_GEN', 'veononstop') or 'veononstop').lower()
            img_failed = 0

            _watch_procs = []
            _watch_ready = _th.Event()

            def _launch_both_watchers(prompts_file_path: str = None):
                started = []
                if _has_any_veo_key():
                    started.append(('VeoNonStop', _start_inflight_watcher_for_engine(
                        'veononstop', prompts_file_path=prompts_file_path)))
                else:
                    print("  [INFLIGHT BOTH] VeoNonStop watcher skipped: no VEONONSTOP keys")
                if _both_cinai:
                    if getattr(config, 'CINAI_ACCESS_TOKEN', ''):
                        started.append(('CinAI', _start_inflight_watcher_for_engine(
                            'cinai', prompts_file_path=prompts_file_path)))
                    else:
                        print("  [INFLIGHT BOTH] CinAI watcher skipped: CINAI_ACCESS_TOKEN empty")
                elif getattr(config, 'FASTGEN_API_KEY', ''):
                    started.append(('Flow Ultra', _start_inflight_watcher_for_engine(
                        'fastgen_ultra', prompts_file_path=prompts_file_path)))
                else:
                    print("  [INFLIGHT BOTH] Flow Ultra watcher skipped: FASTGEN_API_KEY empty")
                return [(label, proc) for label, proc in started if proc is not None]

            if inflight_mode:
                if _should_adapt:
                    def _launch_both_after_adapt():
                        nonlocal _watch_procs
                        _inflight_prompts = None
                        if _adapt_event.wait(timeout=600) and _adapt_result[0]:
                            _inflight_prompts = _adapt_result[0]
                            print(f"  [codex-adapt] Ready: {Path(_inflight_prompts).name}")
                        else:
                            print("  [codex-adapt] Timeout — watchers use original prompts")
                        _watch_procs = _launch_both_watchers(_inflight_prompts)
                        _watch_ready.set()
                    _th.Thread(target=_launch_both_after_adapt, daemon=True,
                               name='deferred-both-watchers').start()
                    print("  [INFLIGHT BOTH] Watchers will start after VEO adapt finishes")
                else:
                    _watch_procs = _launch_both_watchers(None)
                    _watch_ready.set()

            if img_source == 'skip':
                ok = _count_generated_images()
                result = {'generated': ok, 'failed': 0}
                print(f"  [BOTH] ImageGen skipped; existing generated images: {ok}")
            else:
                try:
                    print(f"  [BOTH] Starting {img_source} ImageGen...")
                    result = _run_image_generation(img_source)
                except Exception as exc:
                    print(f"  [SKIP] ImageGen failed to start: {exc}")
                    return
                ok = int(result.get('generated', 0) or 0)
                img_failed = int(result.get('failed', 0) or 0)
                print(
                    f"  [BOTH] {img_source} ImageGen done: {ok} images "
                    f"-> generated/  (failed={img_failed})"
                )
            _mark_inflight_imagegen_done()

            existing_images = _count_generated_images()
            if ok <= 0 and existing_images > 0:
                ok = existing_images
                print(f"  [BOTH] Using existing generated/ images: {existing_images}")

            _t2v_result = _run_t2v_image_fallback(result)
            if _t2v_result is not None:
                img_failed = int(_t2v_result.get('failed', 0) or 0)
                if img_failed > 0:
                    _save_failed_prompts(p_dir, 't2v', img_failed)
            elif img_failed > 0:
                _save_failed_prompts(p_dir, 'imggen', img_failed)

            if ok <= 0:
                print("  [SKIP] No images available in generated/ — cannot run both i2v providers")
                for _, proc in _watch_procs:
                    try:
                        proc.terminate()
                    except Exception:
                        pass
                return

            if _both_cinai and inflight_mode:
                import shutil
                _watch_ready.wait(timeout=660)
                expected_watchers = {"VeoNonStop", "CinAI"}
                actual_watchers = {label for label, _ in _watch_procs}
                _inflight_ok = expected_watchers.issubset(actual_watchers)
                if not _inflight_ok:
                    missing = ", ".join(sorted(expected_watchers - actual_watchers))
                    print(
                        f"  [INFLIGHT BOTH] Required provider watcher(s) missing: "
                        f"{missing}; finalized fallback will run"
                    )
                for label, proc in _watch_procs:
                    print(f"  [INFLIGHT BOTH] Waiting for {label} watcher...")
                    _watch_ok = _wait_inflight_watcher(
                        proc,
                        p_dir,
                        output_dir_name='vid_img_cinai' if label == 'CinAI' else 'vid_img',
                    )
                    _inflight_ok = _inflight_ok and _watch_ok
                _cinai_stage = Path(p_dir) / 'vid_img_cinai'
                _primary_stage = Path(p_dir) / 'vid_img'
                _primary_stage.mkdir(parents=True, exist_ok=True)
                if _cinai_stage.exists():
                    for candidate in sorted(_cinai_stage.glob('*.mp4')):
                        target = _primary_stage / candidate.name
                        if not target.exists():
                            shutil.copy2(candidate, target)
                if _inflight_ok:
                    print("  [BOTH] VeoNonStop + CinAI inflight complete -> vid_img/")
                    return
                print("  [BOTH] Inflight pair incomplete; finalized branch will fill missing clips")

            if _both_cinai:
                prompts_file_path = None
                if _should_adapt:
                    if not _adapt_event.wait(timeout=600):
                        print("  [codex-adapt] Timeout - using original prompts")
                    elif _adapt_result[0]:
                        prompts_file_path = _adapt_result[0]
                        print(f"  [codex-adapt] Ready: {Path(prompts_file_path).name}")
                print("  [BOTH] Starting parallel VideoGen: VeoNonStop + CinAI...")
                vid_result = _run_parallel_veo_cinai_i2v(
                    prompts_file_path=prompts_file_path,
                )
                vid_failed = int(vid_result.get('failed', 0) or 0)
                total_failed = img_failed + vid_failed
                if total_failed > 0:
                    marker = Path(p_dir) / 'has_failed_clips.flag'
                    marker.write_text(
                        f"img_failed={img_failed}\nvid_failed={vid_failed}\n"
                        "mode=both_i2v\nproviders=veononstop,cinai\n",
                        encoding='utf-8',
                    )
                    print(f"  [WARNING] {total_failed} clips failed (img={img_failed}, vid={vid_failed})")
                return

            if inflight_mode:
                _watch_ready.wait(timeout=660)
                _inflight_ok = False
                for label, proc in _watch_procs:
                    print(f"  [INFLIGHT BOTH] Waiting for {label} watcher...")
                    _inflight_ok = _wait_inflight_watcher(proc, p_dir) or _inflight_ok
                if _inflight_ok:
                    print("  both_i2v done -> vid_img/ (via inflight watchers)")
                    return

            prompts_file_path = None
            if _should_adapt:
                if not _adapt_event.wait(timeout=600):
                    print("  [codex-adapt] Timeout — using original prompts")
                elif _adapt_result[0]:
                    prompts_file_path = _adapt_result[0]
                    print(f"  [codex-adapt] Ready: {Path(prompts_file_path).name}")

            print("  [BOTH] Starting parallel VideoGen: VeoNonStop + FastGen Flow Ultra...")
            vid_result = _run_parallel_i2v_providers(prompts_file_path=prompts_file_path)
            vid_failed = int(vid_result.get('failed', 0) or 0)
            total_failed = img_failed + vid_failed
            if total_failed > 0:
                marker = Path(p_dir) / 'has_failed_clips.flag'
                marker.write_text(f"img_failed={img_failed}\nvid_failed={vid_failed}\nmode=both_i2v\n", encoding='utf-8')
                print(f"  [WARNING] {total_failed} clips failed (img={img_failed}, vid={vid_failed})")
                print(f"  Failed info saved to: failed_prompts.txt + has_failed_clips.flag")

        elif action == 'imggen':
            # Image generation only — no i2v (used by slideshow mode).
            # VideoGen is VeoNonStop here. ImageGen is selected independently
            # through PIPELINE_IMG_GEN, just like the GUI ImageGen stage.
            img_source = (
                os.environ.get('PIPELINE_IMG_GEN')
                or getattr(config, 'PIPELINE_IMG_GEN', 'veononstop')
                or 'veononstop'
            ).lower()
            if img_source == 'skip':
                result = {'generated': _count_generated_images(), 'failed': 0}
                print(f"  ImageGen skipped; existing images: {result['generated']}")
            else:
                print(f"  Starting {img_source} ImageGen...")
                result = _run_image_generation(img_source)
            ok = result.get('generated', 0)
            img_failed = result.get('failed', 0)
            print(f"  {img_source.capitalize()} ImageGen done: {ok} images -> generated/")
            _mark_inflight_imagegen_done()
            if img_failed > 0:
                _save_failed_prompts(p_dir, 'imggen', img_failed)

        elif action == 'cinai':
            if not getattr(config, 'CINAI_ACCESS_TOKEN', ''):
                print("  [SKIP] CINAI_ACCESS_TOKEN not configured")
                return
            print("  Starting CinAI image generation...")
            result = cinai_generate_all_images(
                project_dir=p_dir,
                max_parallel=getattr(config, 'CINAI_MAX_PARALLEL', 6),
                model=getattr(config, 'CINAI_MODEL', None),
                aspect_ratio=ar,
                quality=getattr(config, 'CINAI_QUALITY', '1K'),
                silent=True,
            )
            ok = result.get('generated', 0)
            img_failed = result.get('failed', 0)
            print(f"  CinAI done: {ok} images -> generated/")
            if img_failed > 0:
                _save_failed_prompts(p_dir, 'imggen', img_failed)

        elif action == INTRO_I2V_T2V_MODE:
            if not _has_any_veo_key():
                print("  [SKIP] VeoNonStop key not set in any slot (1-4)")
                return
            if inflight_mode:
                print(
                    "  [Intro I2V + T2V] Inflight is disabled for this mixed route; "
                    "it has both image-driven and direct-video clips."
                )

            intro_ids, t2v_ids = _get_intro_i2v_t2v_clip_ids()
            if not intro_ids and not t2v_ids:
                print("  [SKIP] Intro I2V + T2V: montage plan has no usable clips")
                return

            img_source = (
                os.environ.get('PIPELINE_IMG_GEN')
                or getattr(config, 'PIPELINE_IMG_GEN', 'veononstop')
                or 'veononstop'
            ).lower()
            image_result = {'generated': 0, 'failed': 0, 'failed_ids': []}
            if intro_ids:
                if img_source == 'skip':
                    image_result = {
                        'generated': 0,
                        'failed': len(intro_ids),
                        'failed_ids': intro_ids,
                    }
                    print(
                        "  [Intro I2V + T2V] ImageGen is Skip, so intro clips "
                        "cannot be sent to I2V."
                    )
                else:
                    print(
                        f"  Starting {img_source} ImageGen for "
                        f"{len(intro_ids)} intro clip(s)..."
                    )
                    image_result = _run_image_generation(
                        img_source, clip_ids=intro_ids)
                    print(
                        f"  {img_source.capitalize()} intro ImageGen done: "
                        f"{image_result.get('generated', 0)} images -> generated/"
                    )
            _mark_inflight_imagegen_done()

            # Preserve the existing quota policy: an intro image that cannot be
            # made may still become T2V through the separately configured quota
            # fallback. The normal path remains I2V for every available intro frame.
            fallback_result = _run_t2v_image_fallback(image_result)
            image_failed = (
                int(fallback_result.get('failed', 0) or 0)
                if fallback_result is not None
                else int(image_result.get('failed', 0) or 0)
            )

            prompts_file_path = None
            if _should_adapt:
                if not _adapt_event.wait(timeout=600):
                    print("  [codex-adapt] Timeout - using original prompts")
                else:
                    prompts_file_path = _adapt_result[0]

            vid_keys = _resolve_veo_key(video_key_slot)
            single_prompt = _video_single_prompt()
            i2v_failed = 0
            intro_ready_ids = [cid for cid in intro_ids if _image_exists(cid)]
            if intro_ready_ids:
                print(
                    f"  Starting VeoNonStop I2V for {len(intro_ready_ids)} "
                    "intro clip(s)..."
                )
                i2v_result = veo_generate_all_videos(
                    project_dir=p_dir,
                    mode='i2v',
                    max_parallel=video_parallel,
                    aspect_ratio=ar,
                    single_prompt=single_prompt,
                    active_keys=vid_keys,
                    clip_ids=intro_ready_ids,
                    silent=True,
                    prompts_file_path=prompts_file_path,
                )
                i2v_failed = int(i2v_result.get('failed', 0) or 0)
            elif intro_ids and fallback_result is None:
                print("  [Intro I2V + T2V] No generated intro frames available for I2V")

            t2v_failed = 0
            if t2v_ids:
                print(
                    f"  Starting VeoNonStop T2V for {len(t2v_ids)} "
                    "post-intro clip(s)..."
                )
                t2v_result = veo_generate_all_videos(
                    project_dir=p_dir,
                    mode='t2v',
                    max_parallel=video_parallel,
                    aspect_ratio=ar,
                    single_prompt=single_prompt,
                    active_keys=vid_keys,
                    clip_ids=t2v_ids,
                    silent=True,
                    prompts_file_path=prompts_file_path,
                )
                t2v_failed = int(t2v_result.get('failed', 0) or 0)

            total_failed = image_failed + i2v_failed + t2v_failed
            if total_failed:
                _save_failed_prompts(p_dir, INTRO_I2V_T2V_MODE, total_failed)
                marker = Path(p_dir) / 'has_failed_clips.flag'
                marker.write_text(
                    f"intro_image_failed={image_failed}\n"
                    f"intro_i2v_failed={i2v_failed}\n"
                    f"post_intro_t2v_failed={t2v_failed}\n",
                    encoding='utf-8',
                )
                print(
                    f"  [WARNING] {total_failed} clips failed "
                    f"(intro image={image_failed}, i2v={i2v_failed}, t2v={t2v_failed})"
                )
            else:
                print("  Intro I2V + T2V done -> vid_img/")

        elif action == 'veo_i2v':
            _cinai_video_selected = (
                os.environ.get('VARAGENT_VIDEO_ENGINE', '').strip().lower() == 'cinai'
            )
            # НЕТ раннего выхода для CinAI: ImageGen (generated/) обязан отработать
            # ДО VideoGen — ветка ниже сама зовёт _run_cinai_video_stage после
            # ImageGen. Ранний return здесь пропускал ImageGen (все i2v падали
            # "source missing"), а также _wait_real_photo/_wait_stock и
            # Pre-concat fallback в конце функции — очередь склейки валилась
            # на неснятых *_pending маркерах (инцидент ВВВ_20260815_0150).
            if not _cinai_video_selected and not _has_any_veo_key():
                print("  [SKIP] VeoNonStop key not set in any slot (1-4)")
                return

            # Реальный видеорежим CinAI в композитной ветке: i2v (дефолт) или
            # first_last — оба кормятся картинками из generated/, поэтому GUI
            # маппит их на veo_i2v, а сам режим передаёт через CINAI_VIDEO_MODE.
            # Дефолт конфига 't2v' сюда не пропускаем — t2v идёт голой веткой.
            _cinai_video_mode = (
                os.environ.get('CINAI_VIDEO_MODE')
                or getattr(config, 'CINAI_VIDEO_MODE', 'i2v')
                or 'i2v'
            ).strip().lower()
            if _cinai_video_mode not in ('i2v', 'first_last'):
                _cinai_video_mode = 'i2v'
            # Inflight-вотчер умеет только i2v (watch_i2v_cinai.py --mode i2v);
            # для first_last честно уходим в финализированную ветку после ImageGen.
            _cinai_inflight_unsupported = (
                _cinai_video_selected and _cinai_video_mode != 'i2v'
            )
            if inflight_mode and _cinai_inflight_unsupported:
                print("  [INFLIGHT] CinAI first_last не поддерживает inflight — "
                      "финализированная генерация после ImageGen")

            # Inflight: start watch_i2v.py so it animates images as they appear
            _watch_proc = None
            _watch_ready = _th.Event()
            if inflight_mode and not _cinai_inflight_unsupported:
                if _should_adapt:
                    # Deferred watcher: wait for adapt in background, don't block imggen
                    def _launch_watcher_after_adapt_v():
                        nonlocal _watch_proc
                        _inflight_prompts = None
                        if _adapt_event.wait(timeout=600) and _adapt_result[0]:
                            _inflight_prompts = _adapt_result[0]
                            print(f"  [codex-adapt] Ready: {Path(_inflight_prompts).name}")
                        else:
                            print("  [codex-adapt] Timeout — watcher uses original prompts")
                        _watch_proc = _start_inflight_watcher(p_dir, video_key_slot, video_parallel, ar, prompt_mode,
                                                               vislide_interval=vislide_interval,
                                                               prompts_file_path=_inflight_prompts)
                        _watch_ready.set()
                    _th.Thread(target=_launch_watcher_after_adapt_v, daemon=True, name='deferred-watcher-v').start()
                    print("  [INFLIGHT] Watcher will start after VEO adapt finishes")
                else:
                    _watch_proc = _start_inflight_watcher(p_dir, video_key_slot, video_parallel, ar, prompt_mode,
                                                           vislide_interval=vislide_interval)
                    _watch_ready.set()

            # ImageGen and VideoGen are separate stages.  Keep this existing
            # VeoNonStop i2v route, but honor the ImageGen provider selected
            # by the GUI/environment.
            img_source = (
                os.environ.get('PIPELINE_IMG_GEN')
                or getattr(config, 'PIPELINE_IMG_GEN', 'veononstop')
                or 'veononstop'
            ).lower()

            # ── ЦЕПОЧКА CinAI: ImageGen+i2v одним графом ────────────────────
            # Когда и картинки, и видео делает CinAI (finalized i2v), провайдер
            # умеет прогнать image->video на своей стороне: кадр НЕ качается и
            # НЕ заливается обратно (экономия ~30% времени клипа и 2-3 МБ
            # трафика). Оба результата приходят в одном потоке: кадр всё равно
            # сохраняем в generated/ (нужен конкату/фолбэку/Finalize).
            # Остальные клипы (сток/real_photo/инфографика/уже готовые) идут
            # обычным путём ниже: ImageGen пропустит готовые кадры, VideoGen —
            # готовые mp4. При любой ошибке цепочки — просто продолжаем
            # классическим маршрутом, клипы ничего не теряют.
            _chain_failed = 0
            # Липкая нода включается галкой в GUI (CINAI_VIDEO_CHAIN):
            # выключил — идём раздельным путём ImageGen → i2v, чтобы можно
            # было сравнить скорость на своём материале.
            if (_cinai_video_selected and _cinai_video_mode == 'i2v'
                    and img_source == 'cinai' and not inflight_mode
                    and getattr(config, 'CINAI_VIDEO_CHAIN', True)
                    and getattr(config, 'CINAI_ACCESS_TOKEN', '')
                    and getattr(config, 'CINAI_VIDEO_ENABLED', False)):
                try:
                    from modules.cinai_video import (
                        chain_eligible_clips as _chain_ids_fn,
                        generate_chained_i2v as _chain_gen,
                    )
                    _chain_ids = _chain_ids_fn(p_dir)
                    if _chain_ids:
                        print(f"  [CinAI Chain] ImageGen+i2v одним графом: "
                              f"{len(_chain_ids)} клипов")
                        _chain_res = _chain_gen(
                            p_dir,
                            _chain_ids,
                            aspect_ratio=ar,
                            video_prompts_file=_adapt_result[0] if _adapt_result[0] else None,
                            silent=True,
                        )
                        _chain_failed = int(_chain_res.get('failed', 0) or 0)
                        print(f"  [CinAI Chain] done: "
                              f"video={_chain_res.get('generated', 0)} "
                              f"frames={len(_chain_res.get('images', []))} "
                              f"failed={_chain_failed}")
                        # упавшие в цепочке клипы добираются обычным путём ниже
                except Exception as _che:
                    print(f"  [CinAI Chain] недоступна ({str(_che)[:200]}) — "
                          f"обычный маршрут ImageGen -> i2v")
                    logging.debug(traceback.format_exc())

            if img_source == 'skip':
                result = {'generated': _count_generated_images(), 'failed': 0}
                print(f"  ImageGen skipped; existing images: {result['generated']}")
            else:
                print(f"  Starting {img_source} ImageGen...")
                result = _run_image_generation(img_source)
            ok = result.get('generated', 0)
            img_failed = result.get('failed', 0)
            print(f"  {img_source.capitalize()} ImageGen done: {ok} images -> generated/")
            _mark_inflight_imagegen_done()

            _t2v_result = _run_t2v_image_fallback(result)
            if _t2v_result is not None:
                img_failed = int(_t2v_result.get('failed', 0) or 0)
                if img_failed > 0:
                    _save_failed_prompts(p_dir, 't2v', img_failed)
            elif img_failed > 0:
                _save_failed_prompts(p_dir, 'imggen', img_failed)

            if ok > 0:
                _inflight_ok = False
                if inflight_mode and not _cinai_inflight_unsupported:
                    # при first_last вотчер не стартовал — _watch_ready никто
                    # не взведёт, ждать её значит зависнуть на 11 минут
                    _watch_ready.wait(timeout=660)
                if inflight_mode and _watch_proc is not None:
                    _inflight_ok = _wait_inflight_watcher(_watch_proc, p_dir)
                    if _inflight_ok:
                        vid_failed = 0

                if (not (inflight_mode and _watch_proc is not None and _inflight_ok)
                        and _cinai_video_selected):
                    _cinai_result = _run_cinai_video_stage(
                        _cinai_video_mode,
                        prompts_file_path=_adapt_result[0] if _adapt_result[0] else None,
                    )
                    vid_failed = int(_cinai_result.get('failed', 0) or 0)
                    if vid_failed > 0:
                        _save_failed_prompts(p_dir, 'i2v', vid_failed)
                if not (inflight_mode and _watch_proc is not None and _inflight_ok) and not _cinai_video_selected:
                    vid_keys = _resolve_veo_key(video_key_slot)
                    # Wait for Codex adapt if running
                    if _should_adapt:
                        if not _adapt_event.wait(timeout=600):
                            print("  [codex-adapt] Timeout — using original prompts")
                        elif _adapt_result[0]:
                            print(f"  [codex-adapt] Ready: {Path(_adapt_result[0]).name}")
                    print("  Starting VeoNonStop i2v...")
                    single_prompt = None
                    if prompt_mode == 'single':
                        sp_path = Path(p_dir) / 'single_prompt.txt'
                        if sp_path.exists():
                            single_prompt = sp_path.read_text(encoding='utf-8-sig').strip()
                            print(f"  Using single_prompt.txt: {single_prompt[:50]}...")
                        else:
                            single_prompt = 'default'
                    _vislide_ids = _get_vislide_clip_ids() if vislide_interval >= 2 else None
                    vid_result = veo_generate_all_videos(
                        project_dir=p_dir, mode='i2v',
                        max_parallel=video_parallel, aspect_ratio=ar,
                        single_prompt=single_prompt,
                        active_keys=vid_keys,
                        clip_ids=_vislide_ids,
                        silent=True,
                        prompts_file_path=_adapt_result[0],
                    )
                    vid_failed = vid_result.get('failed', 0)
                    print("  i2v done -> vid_img/")
                    if _vislide_ids:
                        _vislide_copy_static(_vislide_ids)
                    if vid_failed > 0:
                        _save_failed_prompts(p_dir, 'i2v', vid_failed)

                total_failed = img_failed + vid_failed
                if total_failed > 0:
                    marker = Path(p_dir) / 'has_failed_clips.flag'
                    marker.write_text(f"img_failed={img_failed}\nvid_failed={vid_failed}\n", encoding='utf-8')
                    print(f"  [WARNING] {total_failed} clips failed (img={img_failed}, vid={vid_failed})")
                    print(f"  Failed info saved to: failed_prompts.txt + has_failed_clips.flag")
            elif inflight_mode and _watch_proc is not None:
                _watch_proc.terminate()

        elif action in ('t2v', 'i2v', 'first_last', 'reference', 'components', 'cinai_components'):
            if (
                os.environ.get('VARAGENT_VIDEO_ENGINE', '').strip().lower() == 'cinai'
                or action == 'cinai_components'
            ):
                cinai_mode = 'components' if action in ('components', 'cinai_components') else action
                result = _run_cinai_video_stage(
                    cinai_mode,
                    reference_dir=str(Path(p_dir) / 'ref') if cinai_mode == 'reference' else None,
                )
                vid_failed = int(result.get('failed', 0) or 0)
                if vid_failed > 0:
                    _save_failed_prompts(p_dir, cinai_mode, vid_failed)
                return
            # Любой из четырёх слотов: ниже ключ всё равно берётся по
            # video_key_slot, и проверять только первый — значит скипнуть
            # стадию у того, кто работает вторым ключом.
            if not _has_any_veo_key():
                print("  [SKIP] VeoNonStop key not set in any slot (1-4)")
                return
            if action in ('i2v', 'first_last'):
                # Голая ветка — резюм-режим БЕЗ ImageGen: источники обязаны
                # уже лежать в generated/. Гард распространён и на first_last
                # (тоже кормится из generated/), а проверка видит не только
                # png — CinAI/сток кладут и jpg/webp.
                from pathlib import Path as _Path
                gen_dir = _Path(project_dir) / 'generated'
                _has_imgs = gen_dir.exists() and any(
                    any(gen_dir.glob(f'*{_e}'))
                    for _e in ('.png', '.jpg', '.jpeg', '.webp')
                )
                if not _has_imgs:
                    print(f"  [SKIP] {action} requires images in generated/ — run ImageGen first")
                    return
            ref_dir = None
            if action == 'components':
                from pathlib import Path as _Path
                ref_dir = str(_Path(project_dir) / 'ref')
            vid_keys = _resolve_veo_key(video_key_slot)
            _vislide_ids = _get_vislide_clip_ids() if (vislide_interval >= 2 and action == 'i2v') else None
            print(f"  Starting VeoNonStop {action} (key={video_key_slot})...")
            vid_result = veo_generate_all_videos(
                project_dir=p_dir, mode=action,
                max_parallel=video_parallel, aspect_ratio=ar,
                ref_dir=ref_dir,
                active_keys=vid_keys,
                clip_ids=_vislide_ids,
                silent=True,
            )
            vid_failed = vid_result.get('failed', 0)
            print(f"  {action} done -> vid_img/")
            if _vislide_ids:
                _vislide_copy_static(_vislide_ids)

            if vid_failed > 0:
                _save_failed_prompts(p_dir, action, vid_failed)
                marker = Path(p_dir) / 'has_failed_clips.flag'
                marker.write_text(f"vid_failed={vid_failed}\nmode={action}\n", encoding='utf-8')
                print(f"  [WARNING] {vid_failed} clips failed in {action}")
                print(f"  Failed info saved to: failed_prompts.txt + has_failed_clips.flag")

        elif action in ('fastgen_ultra_t2v', 'fastgen_ultra_ingredients', 'fastgen_ultra_i2v'):
            if not getattr(config, 'FASTGEN_API_KEY', ''):
                print("  [SKIP] FASTGEN_API_KEY not set")
                return
            from modules.flowultra import generate_all_videos_flow_ultra
            _mode_map = {
                'fastgen_ultra_t2v':         't2v',
                'fastgen_ultra_ingredients': 'ingredients',
                'fastgen_ultra_i2v':         'keyframes',
            }
            _fu_mode = _mode_map[action]
            _fu_ref_dir = None
            if _fu_mode == 'ingredients':
                from pathlib import Path as _Path
                _fu_ref_dir = str(_Path(project_dir) / 'ref')

            # === Inflight watcher: start BEFORE ImageGen so it animates images as they appear ===
            _watch_proc = None
            _watch_ready = _th.Event()
            if _fu_mode == 'keyframes' and inflight_mode:
                # Pipeline env var routes _start_inflight_watcher → watch_i2v_flowultra.py
                os.environ['VARAGENT_VIDEO_ENGINE'] = 'fastgen_ultra'
                if _should_adapt:
                    def _launch_fu_watcher_after_adapt():
                        nonlocal _watch_proc
                        _inflight_prompts = None
                        if _adapt_event.wait(timeout=600) and _adapt_result[0]:
                            _inflight_prompts = _adapt_result[0]
                            print(f"  [codex-adapt] Ready: {Path(_inflight_prompts).name}")
                        else:
                            print("  [codex-adapt] Timeout — watcher uses original prompts")
                        _watch_proc = _start_inflight_watcher(
                            p_dir, '1', _flowultra_parallel(), ar, prompt_mode,
                            vislide_interval=vislide_interval,
                            prompts_file_path=_inflight_prompts)
                        _watch_ready.set()
                    _th.Thread(target=_launch_fu_watcher_after_adapt, daemon=True,
                                name='deferred-fu-watcher').start()
                    print("  [INFLIGHT] FU watcher will start after VEO adapt finishes")
                else:
                    _watch_proc = _start_inflight_watcher(
                        p_dir, '1', _flowultra_parallel(), ar, prompt_mode,
                        vislide_interval=vislide_interval)
                    _watch_ready.set()

            # === ImageGen FIRST for keyframes mode (needs generated/<NNN>.png per clip) ===
            # Matches fastgen_i2v pattern — t2v and ingredients skip this step.
            if _fu_mode == 'keyframes':
                print("  Starting FastGen image generation (for Flow Ultra keyframes)...")
                _img_api, _img_dual, _img_slot = _resolve_fastgen_slot(imggen_key_slot, allow_dual=True)
                _img_result = generate_all_images(
                    project_dir=p_dir,
                    api_key=_img_api,
                    dual_key=_img_dual,
                    preflight=not _skip_pf,
                    silent=True,
                )
                _img_ok = _img_result.get('generated', 0)
                _img_failed = _img_result.get('failed', 0)
                print(f"  FastGen ImageGen done: {_img_ok} images -> generated/  (failed={_img_failed})")
                if _img_failed > 0:
                    _save_failed_prompts(p_dir, 'imggen', _img_failed)
                if _img_ok == 0:
                    print("  [SKIP] ImageGen produced 0 images — cannot run Flow Ultra keyframes")
                    return

            # === Flow Ultra video generation ===
            # Single-prompt mode: read single_prompt.txt as VeoNonStop path does
            _fu_single_prompt = None
            if prompt_mode == 'single':
                sp_path = Path(p_dir) / 'single_prompt.txt'
                if sp_path.exists():
                    _fu_single_prompt = sp_path.read_text(encoding='utf-8-sig').strip() or None
                    if _fu_single_prompt:
                        print(f"  Using single_prompt.txt: {_fu_single_prompt[:50]}...")
                else:
                    _fu_single_prompt = 'default'  # first prompt from prompts file
            # Vislide clip_ids filter (reuse helper)
            _fu_vislide_ids = _get_vislide_clip_ids() if vislide_interval >= 2 else None
            # Flow Ultra uses the existing video key slot setting, mapped to FastGen keys.
            _fu_video_slot = str(video_key_slot or '1').lower()
            if _fu_video_slot not in ('1', 'key1', 'main'):
                print(f"  [WARN] Flow Ultra supports only FastGen Key1 here; ignoring video key={video_key_slot}")
            _fu_api, _fu_dual_env, _fg_slot = _resolve_fastgen_slot('1', allow_dual=False)
            # End-image dir for keyframes mode (VARAGENT_FU_END_IMAGE=1)
            _fu_end_dir = None
            if _fu_mode == 'keyframes' and os.environ.get('VARAGENT_FU_END_IMAGE') == '1':
                _fu_end_dir = str(Path(p_dir) / 'generated')

            # === Inflight branch: wait for watcher to finish (it handles video gen) ===
            _inflight_ok = False
            if _fu_mode == 'keyframes' and inflight_mode:
                _watch_ready.wait(timeout=660)
                if _watch_proc is not None:
                    _inflight_ok = _wait_inflight_watcher(_watch_proc, p_dir)
                if _inflight_ok:
                    # Watcher already produced videos — skip in-process FU batch
                    print(f"  {action} done -> vid_img/ (via inflight watcher)")
                    return

            _fu_parallel = _flowultra_parallel()
            print(f"  Starting FastGen Flow Ultra ({_fu_mode})  fastgen_key={_fg_slot} dual={_fu_dual_env} parallel={_fu_parallel}")
            vid_result = generate_all_videos_flow_ultra(
                project_dir=p_dir,
                mode=_fu_mode,
                max_parallel=_fu_parallel,
                aspect_ratio=ar,
                ref_dir=_fu_ref_dir,
                single_prompt=_fu_single_prompt,
                clip_ids=_fu_vislide_ids,
                api_key=_fu_api,
                dual_key=_fu_dual_env,
                end_image_dir=_fu_end_dir,
                silent=True,
            )
            vid_failed = vid_result.get('failed', 0)
            print(f"  {action} done -> vid_img/  (ok={vid_result.get('generated',0)}, fail={vid_failed})")
            if _fu_vislide_ids:
                print(f"  Vislide: {len(_fu_vislide_ids)} clips animated")
            if vid_failed > 0:
                marker = Path(p_dir) / 'has_failed_clips.flag'
                marker.write_text(f"vid_failed={vid_failed}\nmode={action}\n", encoding='utf-8')
                print(f"  [WARNING] {vid_failed} clips failed in {action}")

    except Exception as e:
        print(f"  [ERROR] Post-pipeline {action} failed: {e}")
        logging.debug(traceback.format_exc())
    finally:
        # ── Хвост пайплайна в finally: у веток генерации есть ранние return
        # (CinAI veo_i2v/t2v, both_cinai, inflight-пары, FU inflight). Раньше
        # каждый такой return перепрыгивал ожидание фоновых стадий и Pre-concat
        # fallback — real_photo/stock оставались *_pending в montage_plan, и
        # очередь склейки падала на ConcatGuard (инцидент ВВВ_20260815_0150).
        if _infographic_thread is not None:
            print("  [Infographic] Waiting for parallel static generation...")
            _infographic_thread.join()
            if _infographic_holder[0].get('failed', 0):
                _save_failed_prompts(p_dir, 'imggen', _infographic_holder[0]['failed'])
        # Итог стадии в общую сводку: раньше Real Photo и Сток отчитывались, а
        # инфографика молчала, и по финалу нельзя было понять, отработала ли она.
        _ig = _infographic_holder[0] if _infographic_holder else {}
        if _ig and (_ig.get('generated') or _ig.get('failed')):
            print(f"  [Infographic] итог: {_ig.get('generated', 0)} сделано, "
                  f"{_ig.get('failed', 0)} не вышло")

        # Музыка идёт отдельным фоновым процессом и в сводке не появлялась —
        # пользователь не знал, сделалась она или нет. Читаем её статус-файл.
        _report_music_status(p_dir)

        # Real Photo / Stock: дождаться фоновых загрузок до YT Pack / video_concat.
        # Обязательно ДО Pre-concat fallback ниже: иначе он увидит клип без медиа
        # (поток ещё качает) и зря догенерит картинку поверх будущего футажа.
        _wait_youtube(label="pipeline finish")
        _wait_real_photo(label="pipeline finish")
        _wait_stock(label="pipeline finish")
        _wait_entity(label="pipeline finish")

        # Pre-concat fallback: догенерить картинкой ЛЮБОЙ клип без медиа.
        # Ловим по ФАКТУ отсутствия медиа (нет vid_img/{id} И нет generated/{id}), а НЕ по
        # source-маркеру — потому что real_photo при провале сам делает revert (убирает source).
        # Так покрываем всё: pending без фото, revert'нутые провалы, упавшую генерацию,
        # недокачанный сток (внутри снимается ЛЮБОЙ source, включая stock_*).
        # Промпт уже есть из Pass 2 (промпты пишутся и для помеченных клипов).
        # Вход по ОБОИМ флагам: раньше висел только на REAL_PHOTO_PROMPT_FALLBACK — выключи
        # его юзер, и недокачанные сток-клипы остались бы помеченными → дырки в ролике.
        if (not _non_ai_mode and (
                getattr(config, 'REAL_PHOTO_PROMPT_FALLBACK', True)
                or getattr(config, 'STOCK_PROMPT_FALLBACK', True))):
            try:
                import json as _rpj
                _mp_path = Path(project_dir) / 'montage_plan.json'
                _gen_dir = Path(project_dir) / 'generated'
                _vid_dir = Path(project_dir) / 'vid_img'

                def _clip_has_vid_media(cid):
                    for _fmt in (f"{cid:03d}", str(cid)):
                        for _e in ('mp4', 'mov', 'png', 'jpg', 'jpeg', 'webp'):
                            _f = _vid_dir / f"{_fmt}.{_e}"
                            if _f.exists() and _f.stat().st_size > 1000:
                                return True
                    return False

                def _clip_has_generated_image(cid):
                    for _fmt in (f"{cid:03d}", str(cid)):
                        for _e in ('png', 'jpg', 'jpeg', 'webp'):
                            _f = _gen_dir / f"{_fmt}.{_e}"
                            if _f.exists() and _f.stat().st_size > 1000:
                                return True
                    return False

                def _clip_has_media(cid):
                    return _clip_has_vid_media(cid) or _clip_has_generated_image(cid)

                if _mp_path.exists():
                    _mp = _rpj.loads(_mp_path.read_text(encoding='utf-8-sig'))
                    _mp_plan = _mp.get('montage_plan', _mp)
                    _undelivered, _infographic_missing, _changed = [], [], False
                    for _c in _mp_plan.get('clips', []):
                        _cid = _c.get('id')
                        if _cid is None:
                            continue
                        _cid = int(_cid)
                        if not _clip_has_media(_cid):
                            if _c.get('source') == 'infographic':
                                _infographic_missing.append(_cid)
                                continue
                            _undelivered.append(_cid)
                            # снять real_photo маркер если остался (иначе imggen отфильтрует клип)
                            if _c.pop('source', None) is not None:
                                _changed = True
                    if _changed:
                        _mp_path.write_text(_rpj.dumps(_mp, ensure_ascii=False, indent=2), encoding='utf-8')
                    if _infographic_missing:
                        _ims = sorted(_infographic_missing)
                        print(f"\n  [Infographic fallback] {len(_ims)} static clips without media -> dedicated retry: "
                              f"{_ims[:10]}{'...' if len(_ims) > 10 else ''}")
                        _run_infographic_images(_ims)
                    if _undelivered:
                        _us = sorted(_undelivered)
                        # Догенерация идёт ТЕМ ЖЕ генератором, что выбран для проекта
                        # (PIPELINE_IMG_GEN — та же настройка, по которой ветвится основной
                        # пайплайн на 1824). Раньше был хардкод VeoNonStop: проект на FastGen
                        # получал догенерацию через VeoNonStop (чужие ключи/стиль), а при
                        # banana_ref без рефов imggen падал.
                        _fb_src = (os.environ.get('PIPELINE_IMG_GEN')
                                   or getattr(config, 'PIPELINE_IMG_GEN', 'veononstop') or 'veononstop').lower()
                        print(f"\n  [Pre-concat fallback] {len(_us)} клипов без медиа → догенерация картинкой "
                              f"(без анимации, генератор={_fb_src}): "
                              f"{_us[:10]}{'...' if len(_us) > 10 else ''}")
                        try:
                            if _fb_src == 'cinai' and getattr(config, 'CINAI_ACCESS_TOKEN', ''):
                                _fb_result = cinai_generate_all_images(
                                    project_dir=p_dir,
                                    clip_ids=_undelivered,
                                    max_parallel=getattr(config, 'CINAI_MAX_PARALLEL', 6),
                                    model=getattr(config, 'CINAI_MODEL', 'gpt-image-2'),
                                    aspect_ratio=getattr(config, 'CINAI_ASPECT_RATIO', '16:9'),
                                    quality=getattr(config, 'CINAI_QUALITY', '1K'),
                                    silent=True,
                                )
                                print(f"  [Pre-concat fallback] CinAI: "
                                      f"ok={_fb_result.get('generated', 0)} "
                                      f"failed={_fb_result.get('failed', 0)}")
                            elif _fb_src == 'fastgen' and getattr(config, 'FASTGEN_API_KEY', ''):
                                from modules.fastgen import generate_all_images as _fg_gen
                                _fb_api, _fb_dual, _fb_slot = _resolve_fastgen_slot(
                                    imggen_key_slot, allow_dual=True)
                                _fb_result = _fg_gen(
                                    project_dir=p_dir,
                                    clip_ids=_undelivered,
                                    api_key=_fb_api,
                                    dual_key=_fb_dual,
                                    silent=True,
                                    preflight=False,
                                )
                                print(f"  [Pre-concat fallback] FastGen slot={_fb_slot}: "
                                      f"ok={_fb_result.get('generated', 0)} "
                                      f"failed={_fb_result.get('failed', 0)}")
                            else:
                                # veononstop (или неизвестный источник → безопасный дефолт)
                                from modules.imggen import generate_all_images as _rp_imggen
                                _rp_mode = (getattr(config, 'VEONONSTOP_IMGGEN_MODE', 'imagen') or 'imagen').strip()
                                # banana_ref/banana2_ref грузят style-reference из project/ref/.
                                # Для догенерации одиночных клипов рефов может не быть → imggen
                                # кинет ошибку. Проверяем и откатываемся на imagen.
                                if _rp_mode in ('banana_ref', 'banana2_ref'):
                                    _ref_dir = Path(project_dir) / 'ref'
                                    _has_refs = _ref_dir.is_dir() and any(
                                        p.suffix.lower() in ('.jpg', '.jpeg', '.png', '.webp')
                                        for p in _ref_dir.iterdir() if p.is_file()
                                    )
                                    if not _has_refs:
                                        print(f"  [Pre-concat fallback] режим {_rp_mode}, но в project/ref/ нет "
                                              f"рефов → откат на imagen")
                                        _rp_mode = 'imagen'
                                _rp_imggen(project_dir=p_dir, mode=_rp_mode, clip_ids=_undelivered,
                                           silent=True, preflight=False)
                        except Exception as _ge:
                            print(f"  [Pre-concat fallback] ⚠️  Догенерация не удалась: {_ge}")
                            logging.debug(traceback.format_exc())
            except Exception as _fe:
                print(f"  [Pre-concat fallback] пропущен: {_fe}")
                logging.debug(traceback.format_exc())
        elif _non_ai_mode:
            _protect_non_ai(Path(project_dir) / 'montage_plan.json')

    # YT Packer НЕ запускается здесь: он не нужен concat'у, а раньше блокировал
    # PROJECT_DONE → заставлял concat ждать. Теперь YT pack вызывается ПОСЛЕ PROJECT_DONE
    # (см. _run_yt_pack_after_done), чтобы идти ПАРАЛЛЕЛЬНО concat'у.


def _run_yt_pack_after_done(project_dir: str) -> None:
    """YT Packer — вызывается ПОСЛЕ PROJECT_DONE, чтобы не блокировать concat."""
    try:
        from modules.yt_packer import run_yt_packer
        print(f"\n  [YT Pack] Starting YouTube packer for {Path(project_dir).name}...")
        run_yt_packer(project_dir)
        print(f"  [YT Pack] Done → yt_pack/")
    except Exception as e:
        print(f"  [ERROR] YT Pack failed: {e}")
        logging.debug(traceback.format_exc())


def _ask_post_pipeline_action(project_dir: str, clip_ids=None, aspect_ratio: str = None) -> None:
    """Interactive menu after direction completes: what to do next with prompts."""
    if not _has_any_veo_key():
        # Ни одного ключа VeoNonStop (ни в одном слоте) — меню не о чем
        return

    print("\n" + "=" * 60)
    print("  WHAT TO DO NEXT?")
    print("=" * 60)
    print()
    print("  [1] FastGen images + VeoNonStop animate (i2v)")
    print("  [2] VeoNonStop images (Imagen/Banana) + VeoNonStop animate (i2v)")
    print("  [3] Prompts -> VeoNonStop text-to-video (t2v)")
    print("  [4] Prompts + refs -> VeoNonStop components (multi-image-to-video)")
    print("  [5] FastGen images only (no video)")
    print("  [6] VeoNonStop images only (no video)")
    print("  [7] Skip — manual workflow")
    print()

    while True:
        choice = input("  Select [1-7, Enter=7]: ").strip() or '7'
        if choice in ('1', '2', '3', '4', '5', '6', '7'):
            break
        print("  Enter 1-7")

    if choice == '7':
        print("  Skipped. Use run_generate / run_img2video bat files manually.")
        return

    p_dir = str(project_dir)

    # --- Aspect ratio ---
    ar = aspect_ratio or config.VEONONSTOP_ASPECT_RATIO
    print(f"\n  Aspect ratio (current: {ar}):")
    print("    [1] 16:9  [2] 9:16  [3] 1:1")
    ar_sel = input(f"    Select [1/2/3, Enter={ar}]: ").strip()
    if ar_sel == '1': ar = '16:9'
    elif ar_sel == '2': ar = '9:16'
    elif ar_sel == '3': ar = '1:1'

    # --- Parallel workers ---
    par = config.VEONONSTOP_MAX_PARALLEL
    par_input = input(f"\n  Parallel workers [1-24, Enter={par}]: ").strip()
    if par_input.isdigit() and 1 <= int(par_input) <= 24:
        par = int(par_input)

    # --- Choices 1, 2: images then i2v ---
    if choice in ('1', '2'):
        # Step A: generate images
        if choice == '1':
            # FastGen
            if not config.FASTGEN_API_KEY:
                print("\n  [ERROR] FASTGEN_API_KEY not set in .env")
                return
            print("\n  Starting FastGen image generation...")
            try:
                result = generate_all_images(
                    project_dir=p_dir,
                    clip_ids=clip_ids,
                )
                ok = result.get('generated', 0)
                print(f"  FastGen done: {ok} images generated")
            except Exception as e:
                print(f"  [ERROR] FastGen failed: {e}")
                return
        else:
            # VeoNonStop images — ask which sub-mode
            print("\n  VeoNonStop image generator:")
            print("    [1] Imagen 3.5")
            print("    [2] Banana Pro")
            print("    [3] Banana Pro + style-reference (iz ref/)")
            print()
            while True:
                img_choice = input("    Select [1/2/3, Enter=1]: ").strip() or '1'
                if img_choice in ('1', '2', '3'):
                    break
                print("    Enter 1, 2, or 3")
            img_mode = {'1': 'imagen', '2': 'banana', '3': 'banana_ref'}[img_choice]
            print(f"\n  Starting VeoNonStop image generation ({img_mode})...")
            try:
                result = veo_generate_all_images(
                    project_dir=p_dir,
                    mode=img_mode,
                    max_parallel=par,
                    clip_ids=clip_ids,
                    aspect_ratio=ar,
                )
                ok = result.get('generated', 0)
                print(f"  VeoNonStop images done: {ok} images generated")
            except Exception as e:
                print(f"  [ERROR] VeoNonStop image generation failed: {e}")
                return

        # Step B: ask prompt source for i2v
        print("\n  Prompt source for video animation:")
        print("    [1] Director prompts (per-clip from *_prompts_*.txt)")
        print("    [2] Single prompt for all clips")
        print()
        single_prompt = None
        while True:
            ps = input("    Select [1/2, Enter=1]: ").strip() or '1'
            if ps in ('1', '2'):
                break
            print("    Enter 1 or 2")
        if ps == '2':
            single_prompt = input("    Enter prompt: ").strip()
            if not single_prompt:
                print("    Empty prompt — using per-clip prompts")
                single_prompt = None

        print("\n  Starting VeoNonStop image-to-video...")
        try:
            result = veo_generate_all_videos(
                project_dir=p_dir,
                mode='i2v',
                max_parallel=par,
                clip_ids=clip_ids,
                single_prompt=single_prompt,
                aspect_ratio=ar,
            )
            ok = result.get('generated', 0)
            print(f"\n  img2video done: {ok} videos generated -> vid_img/")
        except Exception as e:
            print(f"  [ERROR] img2video failed: {e}")
        return

    # --- Choice 3: t2v ---
    if choice == '3':
        print("\n  Prompt source for text-to-video:")
        print("    [1] Director prompts (per-clip from *_prompts_*.txt)")
        print("    [2] Single prompt for all clips")
        print()
        single_prompt = None
        while True:
            ps = input("    Select [1/2, Enter=1]: ").strip() or '1'
            if ps in ('1', '2'):
                break
            print("    Enter 1 or 2")
        if ps == '2':
            single_prompt = input("    Enter prompt: ").strip()
            if not single_prompt:
                print("    Empty prompt — using per-clip prompts")
                single_prompt = None

        print("\n  Starting VeoNonStop text-to-video...")
        try:
            result = veo_generate_all_videos(
                project_dir=p_dir,
                mode='t2v',
                max_parallel=par,
                clip_ids=clip_ids,
                single_prompt=single_prompt,
                aspect_ratio=ar,
            )
            ok = result.get('generated', 0)
            print(f"\n  t2v done: {ok} videos generated -> vid_img/")
        except Exception as e:
            print(f"  [ERROR] t2v failed: {e}")
        return

    # --- Choice 4: components (multi-image-to-video) ---
    if choice == '4':
        ref_dir = str(Path(project_dir) / 'ref')
        if not Path(ref_dir).exists():
            print(f"\n  [WARN] ref/ folder not found: {ref_dir}")
            custom = input("  Custom ref path (or Enter to cancel): ").strip()
            if not custom:
                print("  Cancelled.")
                return
            ref_dir = custom

        print("\n  Starting VeoNonStop components (multi-image-to-video)...")
        try:
            result = veo_generate_all_videos(
                project_dir=p_dir,
                mode='components',
                max_parallel=par,
                clip_ids=clip_ids,
                aspect_ratio=ar,
                ref_dir=ref_dir,
            )
            ok = result.get('generated', 0)
            print(f"\n  components done: {ok} videos generated -> vid_img/")
        except Exception as e:
            print(f"  [ERROR] components failed: {e}")
        return

    # --- Choice 5: FastGen images only ---
    if choice == '5':
        if not config.FASTGEN_API_KEY:
            print("\n  [ERROR] FASTGEN_API_KEY not set in .env")
            return
        print("\n  Starting FastGen image generation...")
        try:
            result = generate_all_images(
                project_dir=p_dir,
                clip_ids=clip_ids,
            )
            ok = result.get('generated', 0)
            print(f"\n  FastGen done: {ok} images generated -> generated/")
        except Exception as e:
            print(f"  [ERROR] FastGen failed: {e}")
        return

    # --- Choice 6: VeoNonStop images only ---
    if choice == '6':
        print("\n  VeoNonStop image generator:")
        print("    [1] Imagen 3.5")
        print("    [2] Banana Pro")
        print("    [3] Banana Pro + style-reference (iz ref/)")
        print()
        while True:
            img_choice = input("    Select [1/2/3, Enter=1]: ").strip() or '1'
            if img_choice in ('1', '2', '3'):
                break
            print("    Enter 1, 2, or 3")
        img_mode = {'1': 'imagen', '2': 'banana', '3': 'banana_ref'}[img_choice]
        print(f"\n  Starting VeoNonStop image generation ({img_mode})...")
        try:
            result = veo_generate_all_images(
                project_dir=p_dir,
                mode=img_mode,
                max_parallel=par,
                clip_ids=clip_ids,
                aspect_ratio=ar,
            )
            ok = result.get('generated', 0)
            print(f"\n  VeoNonStop images done: {ok} images generated -> generated/")
        except Exception as e:
            print(f"  [ERROR] VeoNonStop image generation failed: {e}")
        return


def _ask_image_generator() -> str:
    """Интерактивный выбор генератора изображений."""
    print("\n  Image generator:")
    print("    [1] FastGen (Replicate)")
    print("    [2] VeoNonStop Imagen 3.5")
    print("    [3] VeoNonStop Banana Pro       (GEM_PIX_2)")
    print("    [4] VeoNonStop Banana Pro + ref (GEM_PIX_2)")
    print("    [5] VeoNonStop Banana 2         (NARWHAL)")
    print("    [6] VeoNonStop Banana 2  + ref  (NARWHAL)")
    print("    [7] CinAI Studio (gpt-image-2)")
    print()
    while True:
        choice = input("  Select [1-7, Enter=1]: ").strip() or '1'
        if choice in ('1', '2', '3', '4', '5', '6', '7'):
            return {'1': 'fastgen', '2': 'imagen', '3': 'banana', '4': 'banana_ref',
                    '5': 'banana2', '6': 'banana2_ref', '7': 'cinai'}[choice]
        print("  Enter 1 to 7")


def _ask_post_generate_action() -> Optional[str]:
    """Интерактивный вопрос после генерации картинок: конвертировать в видео?"""
    print("\n  Convert images to video?")
    print("    [1] Yes, image-to-video (ozhivit kartinki)")
    print("    [2] Yes, text-to-video (bez kartinok, zanovo)")
    print("    [3] Yes, components (t2v + referensy iz ref/)")
    print("    [4] No, tolko izobrazheniya")
    print()
    while True:
        choice = input("  Select [1/2/3/4, Enter=4]: ").strip() or '4'
        if choice == '1':
            return 'i2v'
        elif choice == '2':
            return 't2v'
        elif choice == '3':
            return 'components'
        elif choice == '4':
            return None
        print("  Enter 1, 2, 3 or 4")


def _first_filled(all_keys: list) -> list:
    """Первый ЗАПОЛНЕННЫЙ слот. Откат при выборе слота без ключа.

    Раньше откатывались жёстко на [1]: выбран слот 2, заполнен только слот 3 —
    брался пустой первый, и прогон падал уже в клиенте («not set in .env»).
    """
    for i, key in enumerate(all_keys):
        if key:
            return [i + 1]
    return [1]


def _has_any_veo_key() -> bool:
    """Есть ли хоть один ключ VeoNonStop — в ЛЮБОМ из четырёх слотов.

    Проверять только VEONONSTOP_API_KEY (слот 1) нельзя: пользователь свободно
    снимает первый ключ и работает вторым («BRO»). Тогда стадия видео молча
    пропускалась, а падал уже concat: «Media missing for clips» — видео просто
    никто не делал (инцидент 07.08.2026, ключ слота 2).
    """
    return any([
        getattr(config, 'VEONONSTOP_API_KEY', '') or '',
        getattr(config, 'VEONONSTOP_API_KEY_2', '') or '',
        getattr(config, 'VEONONSTOP_API_KEY_3', '') or '',
        getattr(config, 'VEONONSTOP_API_KEY_4', '') or '',
    ])


def _resolve_veo_key(slot: str) -> list:
    """Returns list of 1-based key indices for the given slot."""
    slot = str(slot or '1').strip().lower()
    slot = {
        'key1': '1', 'main': '1',
        'key2': '2', 'backup': '2',
        'key3': '3', 'key4': '4',
    }.get(slot, slot)
    ALL_KEYS = [
        config.VEONONSTOP_API_KEY,
        config.VEONONSTOP_API_KEY_2,
        config.VEONONSTOP_API_KEY_3,
        config.VEONONSTOP_API_KEY_4,
    ]
    if slot in ('both', 'all'):
        active = [i + 1 for i, k in enumerate(ALL_KEYS) if k]
        return active if active else [1]
    if ',' in slot:
        indices = []
        for s in slot.split(','):
            try:
                idx = int(s.strip())
                if 1 <= idx <= 4 and ALL_KEYS[idx - 1]:
                    indices.append(idx)
            except (ValueError, TypeError):
                pass
        return indices if indices else _first_filled(ALL_KEYS)
    try:
        idx = int(slot)
    except (ValueError, TypeError):
        idx = 1
    if 1 <= idx <= 4 and ALL_KEYS[idx - 1]:
        return [idx]
    return _first_filled(ALL_KEYS)


def cmd_generate(args):
    """Команда: генерация изображений (этап 3) — FastGen или VeoNonStop"""
    log_dir = Path(__file__).parent / 'logs'
    log_file = setup_logging(log_dir)

    print("\n" + "="*60)
    print("STAGE 3: IMAGE GENERATION")
    print("="*60)
    print(f"Log: {log_file}")

    # Определение папки проекта
    base_dir = Path(__file__).parent.parent
    project_dir = base_dir / 'projects' / args.project

    if not project_dir.exists():
        print(f"\n[ERROR] Project not found: {project_dir}")
        sys.exit(1)

    # Парсинг ID клипов
    clip_ids = None
    if args.ids:
        try:
            clip_ids = [int(x.strip()) for x in args.ids.split(',')]
            print(f"\n  Selected clips: {clip_ids}")
        except ValueError:
            print(f"\n[ERROR] Invalid --ids format: {args.ids} (expected: 1,2,3)")
            sys.exit(1)

    # Выбор генератора: CLI-аргумент или интерактивно
    image_gen = getattr(args, 'image_gen', None) or _ask_image_generator()

    try:
        if image_gen == 'cinai':
            if not getattr(config, 'CINAI_ACCESS_TOKEN', ''):
                print("\n[ERROR] CINAI_ACCESS_TOKEN not set in .env")
                sys.exit(1)
            print(f"\n  Generator: CinAI ({args.model or config.CINAI_MODEL})")
            result = cinai_generate_all_images(
                project_dir=str(project_dir),
                max_parallel=args.parallel or config.CINAI_MAX_PARALLEL,
                clip_ids=clip_ids,
                model=args.model or config.CINAI_MODEL,
                aspect_ratio=args.aspect or config.CINAI_ASPECT_RATIO,
                quality=getattr(args, 'quality', None) or config.CINAI_QUALITY,
                silent=not sys.stdin.isatty(),
            )
        elif image_gen == 'fastgen':
            # --- FastGen ---
            key_slot = getattr(args, 'key_slot', '1')
            dual_key_flag = False

            if key_slot in ('2', '3', '4'):
                _key_attr = {
                    '2': 'FASTGEN_API_KEY_2',
                    '3': 'FASTGEN_API_KEY_3',
                    '4': 'FASTGEN_API_KEY_4',
                }[key_slot]
                _slot_key = getattr(config, _key_attr, '')
                if key_slot == '2' and not _slot_key:
                    _slot_key = getattr(config, 'FASTGEN_API_KEY_BACKUP', '')
                if not _slot_key:
                    print(f"\n[ERROR] {_key_attr} not set in .env")
                    sys.exit(1)
                api_key = _slot_key
                print(f"\n  [INFO] FastGen: using Key{key_slot} ({_key_attr})")
            elif key_slot in ('both', 'all'):
                api_key = config.FASTGEN_API_KEY
                dual_key_flag = True
                print("\n  [INFO] FastGen: multi-key mode (all configured FastGen keys)")
            else:
                # key_slot == '1' or legacy --backup-key
                api_key = config.FASTGEN_API_KEY
                if getattr(args, 'backup_key', False):
                    if not config.FASTGEN_API_KEY_BACKUP:
                        print("\n[ERROR] FASTGEN_API_KEY_BACKUP not set in .env")
                        sys.exit(1)
                    api_key = config.FASTGEN_API_KEY_BACKUP
                    print("\n  [INFO] FastGen: using BACKUP key")

            if not api_key:
                print("\n[ERROR] FASTGEN_API_KEY not set in .env")
                sys.exit(1)

            print(f"\n  Generator: FastGen ({args.model or config.FASTGEN_MODEL})")

            result = generate_all_images(
                project_dir=str(project_dir),
                max_parallel=args.parallel or config.FASTGEN_MAX_PARALLEL,
                clip_ids=clip_ids,
                mode=args.mode,
                model=args.model,
                aspect_ratio=args.aspect,
                api_key=api_key,
                preflight=not getattr(args, 'no_preflight', False),
                dual_key=dual_key_flag,
            )

        else:
            # --- VeoNonStop (imagen / banana / banana_ref) ---
            if not _has_any_veo_key():
                print("\n[ERROR] VeoNonStop key not set in .env "
                      "(ни один слот: VEONONSTOP_API_KEY / _2 / _3 / _4)")
                sys.exit(1)

            key_slot = getattr(args, 'key_slot', '1')
            veo_keys = _resolve_veo_key(key_slot)
            print(f"\n  VeoNonStop keys: {veo_keys}")
            print(f"\n  Generator: VeoNonStop ({image_gen.upper()})")

            result = veo_generate_all_images(
                project_dir=str(project_dir),
                mode=image_gen,
                max_parallel=args.parallel or config.VEONONSTOP_MAX_PARALLEL,
                clip_ids=clip_ids,
                aspect_ratio=args.aspect,
                active_keys=veo_keys,
                preflight=not getattr(args, 'no_preflight', False),
                silent=not sys.stdin.isatty(),
            )

        ok = result.get('generated', 0)
        failed = result.get('failed', 0)

        print(f"\n{'='*60}")
        print(f"IMAGE GENERATION COMPLETE!")
        print(f"{'='*60}")
        print(f"  OK: {ok}")
        if failed:
            print(f"  Failed: {failed}")
        print(f"  Output: {project_dir / 'generated'}")

        # Предложение конвертировать в видео (если VeoNonStop ключ есть)
        if ok > 0 and config.VEONONSTOP_API_KEY and sys.stdin.isatty():
            video_mode = _ask_post_generate_action()
            if video_mode:
                # Спросить источник промптов (per-clip или один на всё)
                single_prompt = None
                print("\n  Prompt source for video generation:")
                print("    [1] Director prompts (per-clip from *_prompts_*.txt)")
                print("    [2] Single prompt for all clips")
                print()
                while True:
                    ps = input("    Select [1/2, Enter=1]: ").strip() or '1'
                    if ps in ('1', '2'):
                        break
                    print("    Enter 1 or 2")
                if ps == '2':
                    single_prompt = input("    Enter prompt: ").strip() or None

                print(f"\n  Starting img2video ({video_mode})...")
                veo_generate_all_videos(
                    project_dir=str(project_dir),
                    mode=video_mode,
                    max_parallel=config.VEONONSTOP_MAX_PARALLEL,
                    clip_ids=clip_ids,
                    aspect_ratio=args.aspect,
                    single_prompt=single_prompt,
                )

    except Exception as e:
        print(f"\n[ERROR] Generation failed: {e}")
        logging.debug(traceback.format_exc())
        sys.exit(1)


def cmd_img2video(args):
    """Команда: генерация видеоклипов через VeoNonStop API (этап 3.5)"""
    log_dir = Path(__file__).parent / 'logs'
    log_file = setup_logging(log_dir)

    print("\n" + "="*60)
    print("STAGE 3.5: VIDEO GENERATION (VeoNonStop)")
    print("="*60)
    print(f"Log: {log_file}")

    if not _has_any_veo_key():
        print("\n[ERROR] VeoNonStop key not set in .env "
              "(ни один слот: VEONONSTOP_API_KEY / _2 / _3 / _4)")
        sys.exit(1)

    # Определение папки проекта
    base_dir = Path(__file__).parent.parent
    project_dir = base_dir / 'projects' / args.project

    if not project_dir.exists():
        print(f"\n[ERROR] Project not found: {project_dir}")
        sys.exit(1)

    # Парсинг ID клипов
    clip_ids = None
    if args.ids:
        try:
            clip_ids = [int(x.strip()) for x in args.ids.split(',')]
            print(f"\n  Selected clips: {clip_ids}")
        except ValueError:
            print(f"\n[ERROR] Invalid --ids format: {args.ids}")
            sys.exit(1)

    # Prompt: --prompt-file overrides --prompt (fixes Cyrillic encoding via CMD)
    single_prompt = args.prompt
    if getattr(args, 'prompt_file', None):
        pf = Path(args.prompt_file)
        if not pf.exists():
            print(f"\n[ERROR] --prompt-file not found: {pf}")
            sys.exit(1)
        single_prompt = pf.read_text(encoding='utf-8').strip()
        if not single_prompt:
            print(f"\n[ERROR] --prompt-file is empty: {pf}")
            sys.exit(1)
        print(f"\n  Prompt loaded from file: \"{single_prompt[:80]}{'...' if len(single_prompt) > 80 else ''}\"")

    # Key slot
    key_slot = getattr(args, 'key_slot', '1')
    veo_keys = _resolve_veo_key(key_slot)
    print(f"\n  Video keys: {veo_keys}")

    # Режим — интерактивный выбор если не указан
    mode = args.mode
    if not mode:
        print("\n  Video generation mode:")
        print("    [1] i2v        — image-to-video (ozhivlenie kartinok iz generated/)")
        print("    [2] t2v        — text-to-video (video iz promptov, bez kartinok)")
        print("    [3] components — text-to-video + referensy iz ref/")
        print()
        while True:
            choice = input("  Select [1/2/3]: ").strip()
            if choice == '1':
                mode = 'i2v'
                break
            elif choice == '2':
                mode = 't2v'
                break
            elif choice == '3':
                mode = 'components'
                break
            print("  Enter 1, 2, or 3")

    try:
        result = veo_generate_all_videos(
            project_dir=str(project_dir),
            mode=mode,
            max_parallel=args.parallel or config.VEONONSTOP_MAX_PARALLEL,
            clip_ids=clip_ids,
            single_prompt=single_prompt,
            aspect_ratio=args.ratio,
            ref_dir=args.ref_dir,
            active_keys=veo_keys,
            no_cancel=getattr(args, 'no_cancel', False),
        )

        ok = result.get('generated', 0)
        failed = result.get('failed', 0)
        skipped = result.get('skipped', 0)

        print(f"\n{'='*60}")
        print(f"IMG2VIDEO COMPLETE!")
        print(f"{'='*60}")
        print(f"  OK: {ok}")
        print(f"  Skipped: {skipped}")
        if failed:
            print(f"  Failed: {failed}")
        print(f"  Output: {project_dir / 'vid_img'}")

    except Exception as e:
        print(f"\n[ERROR] img2video failed: {e}")
        logging.debug(traceback.format_exc())
        sys.exit(1)


def cmd_real_photos(args):
    """Команда: Real Photo stage — подмена AI-видеоряда реальными архивными материалами."""
    from modules.real_photo import run_real_photo_stage

    project_name = args.project
    projects_dir = Path(__file__).parent.parent / 'projects'
    project_dir = projects_dir / project_name if not Path(project_name).is_absolute() else Path(project_name)

    if not project_dir.exists():
        print(f"\n[ERROR] Проект не найден: {project_dir}")
        sys.exit(1)
    if not (project_dir / 'montage_plan.json').exists():
        print(f"\n[ERROR] montage_plan.json не найден в {project_dir} — сначала прогони director.")
        sys.exit(1)
    if not (project_dir / 'transcription.json').exists():
        print(f"\n[ERROR] transcription.json не найден — сначала прогони transcribe.")
        sys.exit(1)

    # Resolve overrides from args / .env
    target = getattr(args, 'target_ratio', None)
    rmin   = getattr(args, 'min_ratio', None)
    rmax   = getattr(args, 'max_ratio', None)
    sources_arg = getattr(args, 'sources', None)
    sources_list = [s.strip() for s in sources_arg.split(',')] if sources_arg else None
    codex_model = getattr(args, 'codex_model', None) or (config.REAL_PHOTO_CODEX_MODEL or None)

    # Logging
    log_dir = Path(__file__).parent / 'logs'
    log_dir.mkdir(exist_ok=True)
    log_file = log_dir / f'real_photos_{project_dir.name}_{datetime.now():%Y%m%d_%H%M%S}.log'
    fh = logging.FileHandler(str(log_file), encoding='utf-8')
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter('%(asctime)s | %(levelname)-7s | %(message)s', datefmt='%H:%M:%S'))
    logging.getLogger('RealPhoto').addHandler(fh)
    logging.getLogger('RealPhoto').setLevel(logging.INFO)
    # Also stream to stdout
    sh = logging.StreamHandler(sys.stdout)
    sh.setLevel(logging.INFO)
    sh.setFormatter(logging.Formatter('  %(message)s'))
    logging.getLogger('RealPhoto').addHandler(sh)

    print()
    print("=" * 60)
    print("  REAL PHOTO STAGE — archival photo/video insertion")
    print("=" * 60)
    print(f"  Project:        {project_dir.name}")
    print(f"  Target ratio:   {int((target or config.REAL_PHOTO_RATIO_TARGET)*100)}% "
          f"(min {int((rmin or config.REAL_PHOTO_RATIO_MIN)*100)}%, "
          f"max {int((rmax or config.REAL_PHOTO_RATIO_MAX)*100)}%)")
    _display_sources = sources_list if sources_list is not None else config.REAL_PHOTO_SOURCES
    print(f"  Sources:        {', '.join(_display_sources) if _display_sources else '(none)'}")
    print(f"  Codex model:    {codex_model or config.GPT_MODEL}")
    print(f"  Log:            {log_file.name}")
    print("=" * 60)
    print()

    try:
        summary = run_real_photo_stage(
            project_dir=str(project_dir),
            target_ratio=target,
            min_ratio=rmin,
            max_ratio=rmax,
            sources=sources_list,
            codex_model=codex_model,
        )
    except Exception as e:
        print(f"\n[ERROR] Real Photo stage failed: {e}")
        logging.debug(traceback.format_exc())
        sys.exit(1)

    print()
    print("=" * 60)
    print(f"  DONE: {summary.get('rendered', 0)}/{summary.get('selected', 0)} clips rendered")
    print(f"        photos: {summary.get('by_type', {}).get('photo', 0)}, "
          f"videos: {summary.get('by_type', {}).get('video', 0)}")
    print(f"        credits: {summary.get('credits_path', '')}")
    print("=" * 60)


def cmd_real_photo_epf_select(args):
    """Select downloaded EPF candidates with the configured vision model."""
    from tools.extreme_picture_finder_bridge import select_job_with_vision

    result = select_job_with_vision(
        args.job,
        provider=getattr(args, 'provider', None),
        model=getattr(args, 'model', None),
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


def cmd_real_photo_epf_ingest(args):
    """Ingest vision-selected EPF candidates into generated/."""
    from tools.extreme_picture_finder_bridge import ingest_job

    result = ingest_job(args.job, replace=bool(getattr(args, 'replace', False)))
    print(json.dumps(result, ensure_ascii=False, indent=2))


def cmd_yt_pack(args):
    """Команда: YT Packer — YouTube-упаковщик"""
    project_name = args.project
    source_lang = getattr(args, 'source_lang', None)
    projects_dir = Path(__file__).parent.parent / 'projects'
    project_dir = projects_dir / project_name

    if not project_dir.exists():
        print(f"\n[ERROR] Проект не найден: {project_dir}")
        sys.exit(1)

    # Показать настройки / интерактивный выбор
    if getattr(args, 'interactive', False):
        _yt_packer_interactive()
    else:
        print()
        print("  " + "-" * 50)
        print(f"  Project:      {project_name}")
        print(f"  Languages:    {', '.join(config.YT_PACK_LANGUAGES)}")
        print(f"  Model:        {config.YT_PACK_MODEL}")
        print(f"  Subtitles:    {'ON' if config.YT_PACK_SUBTITLES else 'OFF'}")
        print(f"  Description:  {'ON' if config.YT_PACK_DESCRIPTION else 'OFF'}")
        print(f"  Covers:       {'ON' if config.YT_PACK_COVERS else 'OFF'}")
        if config.YT_PACK_COVERS:
            print(f"  Cover count:  {config.YT_PACK_COVER_COUNT}")
        print("  " + "-" * 50)
        print()
        choice = input("  Start? (1=yes / 2=exit, Enter=1): ").strip()
        if choice == '2':
            print("  Cancelled.")
            sys.exit(0)

    # Логгирование
    log_dir = Path(__file__).parent / 'logs'
    log_file = setup_logging(log_dir)

    try:
        results = run_yt_packer(str(project_dir), source_lang=source_lang)
        if not results:
            print("\n[WARN] YT Packer завершился без результатов")
    except Exception as e:
        print(f"\n[ERROR] YT Packer failed: {e}")
        logging.debug(traceback.format_exc())
        sys.exit(1)


def _vislide_clip_ids(all_clips: list, interval: int, intro_dur: int = 0) -> list:
    """Вислайд: каждый N-й клип (1-based) идёт в i2v + все клипы интро-блока.

    Args:
        all_clips: list of clip dicts with 'id' and optional 'startTime'
        interval: every N-th clip gets animated
        intro_dur: clips with startTime < intro_dur are always animated (0 = disabled)
    """
    animated = set()
    all_ids = [c['id'] for c in all_clips]
    # Every N-th clip
    for i, cid in enumerate(all_ids):
        if (i + 1) % interval == 0:
            animated.add(cid)
    # Force intro block
    if intro_dur > 0:
        for c in all_clips:
            if c.get('startTime', 0) < intro_dur:
                animated.add(c['id'])
    return sorted(animated)


def cmd_process_queue(args):
    """Команда: обработка файлов из выбранной очереди."""
    run_pipeline = getattr(args, 'run', False)
    language_code = getattr(args, 'language', None) or config.ASSEMBLYAI_LANGUAGE_CODE

    # Override backend from CLI
    if getattr(args, 'director_backend', None):
        config.DIRECTOR_BACKEND = args.director_backend
    if getattr(args, 'director_profile', None):
        config.DIRECTOR_PROFILE = args.director_profile
    director_profile = (
        getattr(args, 'director_profile', None)
        or getattr(config, 'DIRECTOR_PROFILE', 'standard')
        or 'standard'
    ).strip().lower()

    # Логгирование — сразу при старте, всегда
    log_dir = Path(__file__).parent / 'logs'
    log_file = setup_logging(log_dir)

    backend_label = 'GPT' if config.DIRECTOR_BACKEND == 'gpt' else 'Gemini'
    print("\n" + "="*60)
    print(f"ОБРАБОТКА ОЧЕРЕДИ — Director: {backend_label}")
    if run_pipeline:
        print("+ АВТОЗАПУСК ПАЙПЛАЙНА (транскрипция + режиссура)")
    print("="*60)
    print(f"📝 Лог-файл: {log_file}")

    # Выбор режима: видео / слайдшоу / вислайд
    clip_mode = getattr(args, 'clip_mode', None)
    if director_profile == 'auto_visual_story':
        clip_mode = 'slideshow'
    vislide_interval = getattr(args, 'vislide_interval', 0) or 0
    print()
    if clip_mode == 'slideshow':
        config.ACTIVE_CLIP_MIN_DURATION = config.SLIDESHOW_CLIP_MIN_DURATION
        config.ACTIVE_CLIP_MAX_DURATION = config.SLIDESHOW_CLIP_MAX_DURATION
        print(f"  → Слайдшоурежим: клипы {config.ACTIVE_CLIP_MIN_DURATION}-{config.ACTIVE_CLIP_MAX_DURATION}с")
    elif clip_mode == 'video':
        config.ACTIVE_CLIP_MIN_DURATION = config.VIDEO_CLIP_MIN_DURATION
        config.ACTIVE_CLIP_MAX_DURATION = config.VIDEO_CLIP_MAX_DURATION
        print(f"  → Видеорежим: клипы {config.ACTIVE_CLIP_MIN_DURATION}-{config.ACTIVE_CLIP_MAX_DURATION}с")
    elif clip_mode == 'vislide':
        if vislide_interval < 2:
            vislide_interval = 3
        config.ACTIVE_CLIP_MIN_DURATION = config.SLIDESHOW_CLIP_MIN_DURATION
        config.ACTIVE_CLIP_MAX_DURATION = config.SLIDESHOW_CLIP_MAX_DURATION
        print(f"  → Вислайд-режим (каждый {vislide_interval}-й оживляется): клипы {config.ACTIVE_CLIP_MIN_DURATION}-{config.ACTIVE_CLIP_MAX_DURATION}с")
    else:
        print("Что создаём?")
        print(f"  [1] Видео      (Veo3-фрагменты)   клипы {config.VIDEO_CLIP_MIN_DURATION}-{config.VIDEO_CLIP_MAX_DURATION}с  (Enter = по умолчанию)")
        print(f"  [2] Слайдшоу   (картинки)          клипы {config.SLIDESHOW_CLIP_MIN_DURATION}-{config.SLIDESHOW_CLIP_MAX_DURATION}с")
        print(f"  [3] Вислайд    (каждый N-й оживл.) клипы {config.SLIDESHOW_CLIP_MIN_DURATION}-{config.SLIDESHOW_CLIP_MAX_DURATION}с")
        print()
        while True:
            mode_choice = input("Ваш выбор [1/2/3]: ").strip()
            if mode_choice in ('', '1'):
                clip_mode = 'video'
                config.ACTIVE_CLIP_MIN_DURATION = config.VIDEO_CLIP_MIN_DURATION
                config.ACTIVE_CLIP_MAX_DURATION = config.VIDEO_CLIP_MAX_DURATION
                print(f"  → Видеорежим: клипы {config.ACTIVE_CLIP_MIN_DURATION}-{config.ACTIVE_CLIP_MAX_DURATION}с")
                break
            elif mode_choice == '2':
                clip_mode = 'slideshow'
                config.ACTIVE_CLIP_MIN_DURATION = config.SLIDESHOW_CLIP_MIN_DURATION
                config.ACTIVE_CLIP_MAX_DURATION = config.SLIDESHOW_CLIP_MAX_DURATION
                print(f"  → Слайдшоурежим: клипы {config.ACTIVE_CLIP_MIN_DURATION}-{config.ACTIVE_CLIP_MAX_DURATION}с")
                break
            elif mode_choice == '3':
                clip_mode = 'vislide'
                if vislide_interval < 2:
                    vislide_interval = 3
                config.ACTIVE_CLIP_MIN_DURATION = config.SLIDESHOW_CLIP_MIN_DURATION
                config.ACTIVE_CLIP_MAX_DURATION = config.SLIDESHOW_CLIP_MAX_DURATION
                while True:
                    n_str = input(f"  Каждый N-й клип оживлять [default={vislide_interval}]: ").strip()
                    if not n_str:
                        break
                    if n_str.isdigit() and int(n_str) >= 2:
                        vislide_interval = int(n_str)
                        break
                    print("  Введите число >= 2")
                print(f"  → Вислайд-режим (каждый {vislide_interval}-й): клипы {config.ACTIVE_CLIP_MIN_DURATION}-{config.ACTIVE_CLIP_MAX_DURATION}с")
                break
            else:
                print("  Введите 1, 2 или 3 (Enter = видео)")

    # Переопределение длительности клипов из CLI (--clip-min / --clip-max)
    clip_min_arg = getattr(args, 'clip_min', None)
    clip_max_arg = getattr(args, 'clip_max', None)
    if clip_min_arg is not None:
        config.ACTIVE_CLIP_MIN_DURATION = clip_min_arg
    if clip_max_arg is not None:
        config.ACTIVE_CLIP_MAX_DURATION = clip_max_arg
    if clip_min_arg is not None or clip_max_arg is not None:
        print(f"  → Длительность переопределена: {config.ACTIVE_CLIP_MIN_DURATION}-{config.ACTIVE_CLIP_MAX_DURATION}с")

    # Параметры вступительного блока
    intro_min = config.get_intro_clip_min()
    intro_max = config.get_intro_clip_max()
    print(f"  → Вступительный блок: первые {config.INTRO_BLOCK_DURATION}с → клипы {intro_min}-{intro_max}с")

    # Пути к папкам
    base_dir = Path(__file__).parent.parent
    _queue_dir_arg = getattr(args, 'queue_dir', None)
    if _queue_dir_arg and Path(_queue_dir_arg).is_dir():
        ready_dir = Path(_queue_dir_arg)
        print(f"\n[GUI] Queue dir: {ready_dir.name}/")
    else:
        ready_dir = base_dir / 'pipeline_queue'
    projects_dir = base_dir / 'projects'
    concat_script = base_dir / 'video_concat.py'

    # Проверка папок
    if not ready_dir.exists():
        ready_dir.mkdir(parents=True, exist_ok=True)
        print(f"\n✅ Папка {ready_dir.name} создана: {ready_dir}")

    if not projects_dir.exists():
        projects_dir.mkdir(parents=True, exist_ok=True)
        print(f"✅ Папка projects создана: {projects_dir}")

    # Получение списка файлов
    audio_files = get_ready_files(ready_dir)

    # --file-list из GUI: сохраняем порядок загрузки (обходит алфавитную сортировку).
    # ВАЖНО: при переданном --file-list полный скан папки очереди ЗАПРЕЩЁН.
    # Раньше пропавший файл (или битый JSON) молча оставлял audio_files = полный
    # скан pipeline_queue/ — запуск обрабатывал ЧУЖИЕ файлы очереди с чужим слепком
    # настроек и мог повторно прогнать уже обработанный файл (дубль проекта).
    # Теперь: явная ошибка + exit 1 (GUI покажет "Phase failed" и пойдёт к следующему файлу).
    _file_list_raw = getattr(args, 'file_list', None)
    if _file_list_raw:
        try:
            import json as _json_fl
            _fl_all = [Path(p) for p in _json_fl.loads(_file_list_raw)]
        except Exception as _fle:
            print(f"\n[ERROR] --file-list не разобран: {_fle}")
            print("   Скан папки очереди при --file-list запрещён — запуск прерван.")
            sys.exit(1)
        _fl_missing = [p for p in _fl_all if not p.exists()]
        _fl = [p for p in _fl_all if p.exists()]
        for _mp in _fl_missing:
            print(f"[ERROR] Файл очереди не найден: {_mp}")
        if not _fl:
            print("\n[ERROR] Ни один файл из --file-list не существует. Запуск прерван (скан папки запрещён).")
            sys.exit(1)
        audio_files = _fl
        _miss_note = f"  (пропущено отсутствующих: {len(_fl_missing)})" if _fl_missing else ""
        print(f"\n[GUI] File list: {len(audio_files)} file(s) in GUI load order{_miss_note}")

    if not audio_files:
        print(f"\n[WARN] В очереди нет входных файлов")
        print(f"   Папка: {ready_dir}")
        print(f"   Положите туда .wav .mp3 .flac .m4a .aac или видео .mp4 .mov .mkv .webm .avi .m4v")
        sys.exit(0)

    print(f"\nНайдено файлов: {len(audio_files)}")
    for f in audio_files:
        print(f"   - {f.name}")

    # Парсим --ref-map (индивидуальные рефы из GUI: {"audio.wav": "/path/.pending_refs/stem/"})
    import json as _json
    _ref_map_raw = getattr(args, 'ref_map', None)
    if _ref_map_raw:
        os.environ['VARAGENT_REF_MAP'] = _ref_map_raw
        print(f"\n[GUI] Ref map: индивидуальные рефы для {len(_json.loads(_ref_map_raw))} файлов")

    # Парсим --style-map (индивидуальные стили из GUI: {"audio.mp3": "/path/sg.txt"})
    _style_map_raw = getattr(args, 'style_map', None)
    style_map = {}
    if _style_map_raw:
        try:
            style_map = _json.loads(_style_map_raw)
            print(f"\n[GUI] Style map: {len(style_map)} audio->SG mapping(s) — автоматический поиск отключён")
            for _a, _s in style_map.items():
                print(f"   {_a} -> {Path(_s).name}")
        except Exception as e:
            print(f"\n[WARN] Не удалось разобрать --style-map: {e}. Используем автопоиск.")
            style_map = {}

    # ПРОВЕРКА НА КОНФЛИКТ SG_ALL + ИНДИВИДУАЛЬНЫЕ
    # Пропускаем если стили переданы явно через GUI (--style или --style-map)
    sg_all_file = None
    use_sg_all = False
    if style_map or getattr(args, 'style', None):
        # Стили переданы явно из GUI — автоматический поиск не требуется
        pass
    else:
        print("\n" + "="*60)
        print("ПРОВЕРКА STYLE GUIDES")
        print("="*60)

        sg_all_file = get_sg_all_file(ready_dir)

        if sg_all_file:
            print(f"\n✅ SG_ALL найден: {sg_all_file.name}")

            # Проверяем есть ли индивидуальные
            individual_guides = []
            for audio_file in audio_files:
                guides = get_all_style_guides_for_audio(audio_file, ready_dir)
                individual_guides.extend(guides)

            if individual_guides:
                print(f"\n⚠️  НАЙДЕНЫ ИНДИВИДУАЛЬНЫЕ STYLE GUIDES!")
                print(f"   Количество: {len(individual_guides)}")
                for g in individual_guides:
                    print(f"   • {g.name}")

                print("\n" + "="*60)
                print("ВЫБЕРИТЕ ДЕЙСТВИЕ:")
                print("="*60)
                print("  1. Использовать SG_ALL для ВСЕХ аудио")
                print("  2. Использовать индивидуальные для каждого аудио")
                print("  3. Временно заморозить SG_ALL (переименовать в .bak)")
                print()

                try:
                    choice = input("Введите номер (1/2/3): ").strip()
                except EOFError:
                    choice = '2'
                    print(f"[non-interactive] auto-selected: 2 (individual style guides)")

                if choice == '1':
                    print(f"\n✅ Будет использован SG_ALL: {sg_all_file.name}")
                    use_sg_all = True
                elif choice == '2':
                    print(f"\n✅ Будут использованы индивидуальные style guides")
                    use_sg_all = False
                elif choice == '3':
                    # Переименовываем SG_ALL
                    bak_name = sg_all_file.name + '.bak'
                    sg_all_file.rename(sg_all_file.parent / bak_name)
                    print(f"\n✅ SG_ALL заморожен: {bak_name}")
                    use_sg_all = False
                else:
                    print(f"\n⚠️  Неверный выбор, используем SG_ALL по умолчанию")
                    use_sg_all = True
            else:
                print(f"\n✅ Индивидуальные style guides не найдены")
                use_sg_all = True
        else:
            print(f"\nℹ️  SG_ALL не найден, будут использованы индивидуальные style guides")
            use_sg_all = False

    # Обработка каждого файла
    print("\n" + "="*60)
    print("ОБРАБОТКА ПРОЕКТОВ")
    print("="*60)

    # Инициализация списка ошибок
    errors = []
    success_count = 0
    _processed_names: set = set()  # track processed filenames for live queue rescan

    # Определяем нужно ли копировать аудио (если несколько style guides)
    copy_audio = False
    if not use_sg_all:
        # Проверяем есть ли несколько style guides для одного аудио
        for audio_file in audio_files:
            guides = get_all_style_guides_for_audio(audio_file, ready_dir)
            if len(guides) > 1:
                copy_audio = True
                break

    # Queue loop: process files, rescan for new ones after each project
    _queue_index = 0
    while _queue_index < len(audio_files):
        audio_file = audio_files[_queue_index]
        _queue_index += 1
        _processed_names.add(audio_file.name)
        print(f"\n  [{_queue_index}/{len(audio_files)}] {audio_file.name}")
        try:
            # Определяем какой style guide использовать
            if style_map and audio_file.name in style_map:
                style_guide = Path(style_map[audio_file.name])  # индивидуальный из GUI
            elif getattr(args, 'style', None):
                style_guide = Path(args.style)  # один для всех из GUI
            elif use_sg_all and sg_all_file:
                style_guide = sg_all_file
            else:
                style_guide = None  # Будет найден автоматически по имени в очереди
            
            # Настройка проекта
            project_info = setup_project(audio_file, ready_dir, projects_dir, concat_script, style_guide, copy_audio)

            # Удаление исходного файла из очереди (только если проект создан успешно)
            if not copy_audio and audio_file.exists():
                try:
                    audio_file.unlink()
                    print(f"   [OK] Аудиофайл перемещён: {audio_file.name}")
                except Exception as e:
                    print(f"   [WARN] Не удалось удалить оригинал: {e}")

            print(f"\n[OK] Проект создан: {project_info['name']}")
            print(f"   Папка: {project_info['project_dir']}")

            # Запуск полного пайплайна сразу после создания проекта
            pipeline_ok = True
            if run_pipeline:
                audio_path = Path(project_info['audio_file'])
                style_path = Path(project_info['style_guide']) if project_info.get('style_guide') else None
                project_name = project_info['name']
                project_dir = Path(project_info['project_dir'])
                transcription_path = Path(project_info['transcription'])

                print(f"\n{'='*60}")
                print(f"ПАЙПЛАЙН: {project_name}")
                print(f"{'='*60}")

                if not style_path or not style_path.exists():
                    print(f"   [WARN] Style guide не найден, пайплайн пропущен")
                else:
                    _full_log_path = project_dir / f'{project_name}_full.log'
                    _full_log_fh = open(_full_log_path, 'w', encoding='utf-8', errors='replace')
                    _orig_stdout = sys.stdout
                    sys.stdout = _TeeStream(_orig_stdout, _full_log_fh)
                    # Log launch arguments
                    import shlex as _shlex
                    print(f"  [ARGS] {' '.join(_shlex.quote(str(a)) for a in sys.argv)}")
                    try:
                        from_script = getattr(args, 'from_script', None)
                        script_type = getattr(args, 'script_type', 'prose')

                        if from_script:
                            if director_profile == 'auto_visual_story':
                                raise ValueError(
                                    "Auto Visual Story currently requires audio word timestamps "
                                    "and is not available with --from-script"
                                )
                            # === Script mode: пропускаем TTS + транскрипцию ===
                            script_path = Path(from_script)
                            if not script_path.exists():
                                print(f"\n❌ Сценарий не найден: {script_path}")
                                pipeline_ok = False
                                continue
                            logging.info(f"Script mode: {script_path.name}, type={script_type}")
                            script_direct_project(
                                str(script_path),
                                str(style_path),
                                str(project_dir),
                                project_name,
                                script_type=script_type,
                                two_pass=getattr(args, 'two_pass', False),
                            )
                            logging.info(f"Script director завершен: {project_dir}")
                        else:
                            # === Обычный режим: транскрипция + режиссёр ===
                            logging.info(f"Запуск пайплайна: {audio_path.name}, язык: {language_code}")

                            # -- REF PREFLIGHT: compress refs in background while transcription runs --
                            import threading as _threading
                            _ref_dir_bg = project_dir / 'ref'
                            _ref_thread = None
                            if _ref_dir_bg.exists():
                                _ref_thread = _threading.Thread(
                                    target=compress_refs,
                                    args=(str(_ref_dir_bg),),
                                    kwargs={'max_mb': 5.0},
                                    daemon=True,
                                    name='ref-compress',
                                )
                                _ref_thread.start()
                                logging.info(f"ref_compress: background thread started for {_ref_dir_bg}")

                            # Готовую транскрипцию не переделываем: повторный
                            # запуск проекта (после сбоя стадии, доработки плана,
                            # смены настроек) платил за неё заново, хотя файл
                            # лежит рядом (улов 26.08).
                            _existing_words = 0
                            if transcription_path.exists():
                                try:
                                    _existing = json.loads(
                                        transcription_path.read_text(encoding='utf-8-sig'))
                                    _existing_words = len(_existing.get('words') or [])
                                except Exception as _exc:
                                    logging.warning(
                                        f"transcription.json не прочитан ({_exc}) — транскрибирую заново")
                            if _existing_words:
                                print(f"  ✓ Транскрипция уже есть ({_existing_words} слов) — пропускаю")
                                logging.info(
                                    f"Транскрипция взята с диска: {transcription_path} ({_existing_words} слов)")
                                transcription_result = _existing
                            else:
                                transcription_result = transcribe_audio(str(audio_path), str(transcription_path), language_code=language_code)
                                logging.info(f"Транскрипция завершена: {transcription_path}")

                            if transcription_result.get('_quality_critical', False):
                                print(f"\n⛔ Транскрипция '{project_name}' аномальная!")
                                print("   Режиссёр НЕ запущен. Проверьте transcription.json.")
                                pipeline_ok = False
                                continue

                            # SG Adapt: адаптируем стайлгайд под текущий сюжет
                            if getattr(args, 'adapt_sg', False) and style_path:
                                print("  Adapting style guide to current script...")
                                from modules.sg_adapter import adapt_style_guide
                                adapted = adapt_style_guide(
                                    original_sg_path=str(style_path),
                                    project_dir=str(project_dir),
                                    project_name=project_name,
                                )
                                style_path = Path(adapted)
                                print(f"  Adapted SG: {style_path.name}")

                            direct_project(
                                str(transcription_path),
                                str(style_path),
                                str(project_dir),
                                project_name,
                                two_pass=getattr(args, 'two_pass', False),
                                director_profile=director_profile,
                                visual_story_step=(
                                    'analyze'
                                    if director_profile == 'auto_visual_story'
                                    else 'full'
                                ),
                            )
                            logging.info(f"Режиссерский анализ завершен: {project_dir}")
                        # Тут закончена ТОЛЬКО режиссура: план и промпты. Впереди
                        # источники кадра, генерация и склейка. Прежнее «Пайплайн
                        # завершён» пугало пользователей — они видели «завершён»,
                        # готового ролика не находили и считали, что всё сломалось
                        # (замечание пользователя 27.08).
                        print(f"\n[OK] Режиссура завершена: {project_name} — "
                              f"план и промпты готовы.")
                        print("     Впереди: сборка или генерация кадров и "
                              "склейка в цельный готовый ролик.")

                        # Music has all of its inputs after directing. Run it in
                        # a separate process so the main pipeline can continue
                        # with images/video and hand PROJECT_DONE to concat.
                        if _start_music_background(project_dir):
                            logging.info(
                                "music_background: started after directing for %s",
                                project_dir,
                            )

                        # Join ref-compress background thread before generation uses the refs
                        if '_ref_thread' in dir() and _ref_thread and _ref_thread.is_alive():
                            logging.info("ref_compress: waiting for background thread...")
                            _ref_thread.join(timeout=120)

                        # Пост-пайплайн генерация: silent если передан --post-action, иначе интерактивно
                        post_action = getattr(args, 'post_action', None)
                        if director_profile == 'auto_visual_story':
                            post_action = 'skip'
                        prompt_mode = getattr(args, 'prompt_mode', 'single')
                        yt_pack = getattr(args, 'yt_pack', False)
                        # Передаём vislide_interval через env var (как остальные runtime-параметры)
                        if clip_mode == 'vislide' and vislide_interval >= 2:
                            os.environ['VARAGENT_VISLIDE_INTERVAL'] = str(vislide_interval)
                        if director_profile == 'auto_visual_story':
                            print(
                                "  [Auto Visual Story] analysis ready; starting EPF/materialization "
                                "after background music launch"
                            )
                            direct_project(
                                str(transcription_path),
                                str(style_path),
                                str(project_dir),
                                project_name,
                                director_profile=director_profile,
                                visual_story_step='search',
                            )
                            direct_project(
                                str(transcription_path),
                                str(style_path),
                                str(project_dir),
                                project_name,
                                director_profile=director_profile,
                                visual_story_step='finalize',
                            )
                            if getattr(config, 'VEONONSTOP_I2V_PARALLAX', False):
                                try:
                                    from modules.auto_visual_parallax import (
                                        run_auto_visual_parallax,
                                    )
                                    _auto_story_parallax = (
                                        run_auto_visual_parallax(
                                            project_dir,
                                            veo_generate_all_videos,
                                        )
                                    )
                                    _auto_story_photo_ids = (
                                        _auto_story_parallax['eligible_ids']
                                    )
                                    _auto_story_parallax_ids = (
                                        _auto_story_parallax['selected_ids']
                                    )
                                    _auto_story_every_n = (
                                        _auto_story_parallax['every_n']
                                    )
                                    # Вид параллакса пишем всегда: шаблоны ведут
                                    # себя по-разному (2 «строгий» запрещает
                                    # любое движение внутри кадра, кроме камеры),
                                    # и без этой строки по логу не понять, почему
                                    # оживление выглядит как обычный наезд.
                                    _px_method = getattr(
                                        config, 'VEONONSTOP_I2V_PARALLAX_METHOD', 1)
                                    _px_names = {
                                        1: 'сбалансированный',
                                        2: 'строгий (двигается только камера)',
                                        3: 'механический',
                                    }
                                    _px_label = _px_names.get(_px_method, '?')
                                    if _auto_story_parallax_ids:
                                        print(
                                            f"  [Параллакс] шаблон {_px_method} "
                                            f"({_px_label}) → "
                                            f"{len(_auto_story_parallax_ids)} из "
                                            f"{len(_auto_story_photo_ids)} фото-клипов, "
                                            f"каждый {_auto_story_every_n}-й: "
                                            f"{_auto_story_parallax_ids}"
                                        )
                                        _auto_story_parallax_result = (
                                            _auto_story_parallax['result'] or {}
                                        )
                                        _px_done = _auto_story_parallax_result.get(
                                            'generated', 0)
                                        print(f"  [Параллакс] готово: {_px_done} видео")
                                        logging.info(
                                            "Параллакс: шаблон %s (%s), каждый %s-й, "
                                            "клипы %s из %s пригодных, сделано %s",
                                            _px_method, _px_label, _auto_story_every_n,
                                            _auto_story_parallax_ids,
                                            len(_auto_story_photo_ids), _px_done,
                                        )
                                    else:
                                        print(
                                            f"  [Параллакс] шаблон {_px_method} "
                                            f"({_px_label}) включён, но пригодных "
                                            "фото-клипов не нашлось — склейка "
                                            "сделает зум"
                                        )
                                        logging.info(
                                            "Параллакс: шаблон %s (%s) включён, "
                                            "пригодных фото-клипов нет (каждый %s-й "
                                            "из %s) — склейка сделает зум",
                                            _px_method, _px_label, _auto_story_every_n,
                                            len(_auto_story_photo_ids),
                                        )
                                except Exception as _auto_story_parallax_exc:
                                    print(
                                        "  [Auto Visual Story/Parallax] "
                                        f"stage failed; concat will use zoom: "
                                        f"{_auto_story_parallax_exc}"
                                    )
                                    logging.exception(
                                        "Auto Visual Story parallax stage failed"
                                    )
                            print(
                                "  [Auto Visual Story] EPF/materialization complete; "
                                "remaining stills will use FFmpeg zoom"
                            )
                        elif post_action:
                            _run_post_pipeline_silent(
                                str(project_dir), post_action, prompt_mode,
                                run_yt_pack=yt_pack,
                                use_codex_adapt=getattr(args, 'codex_adapt', False),
                            )
                        else:
                            if sys.stdin.isatty():
                                _ask_post_pipeline_action(str(project_dir))
                            if yt_pack:
                                _run_post_pipeline_silent(str(project_dir), 'skip', run_yt_pack=True)

                        # Сигнал для GUI: все этапы завершены, можно запускать конкат
                        print(f"PROJECT_DONE: {project_dir}", flush=True)

                        # YT Pack — ПОСЛЕ PROJECT_DONE: идёт параллельно concat'у (varagent),
                        # а не блокирует его (concat ждёт PROJECT_DONE, не YT pack).
                        if yt_pack:
                            _run_yt_pack_after_done(str(project_dir))

                        # Live Queue rescan — только для CLI-режима без явного списка.
                        # GUI передаёт --file-list и обрабатывает очередь как серию
                        # одиночных запусков (оркестратор varagent подаёт по одному файлу
                        # со своим слепком настроек) → rescan отключён: он «съедал» чужие
                        # файлы и дестабилизировал очередь (готов был только 1 из N).
                        if not _file_list_raw:
                            _new_files = [f for f in get_ready_files(ready_dir)
                                          if f.name not in _processed_names and f not in audio_files]
                            if _new_files:
                                # Apply order.json if exists (GUI QM reorder)
                                _order_path = ready_dir / 'order.json'
                                if _order_path.exists():
                                    try:
                                        _oj = json.loads(_order_path.read_text(encoding='utf-8-sig'))
                                        _order_map = {name: i for i, name in enumerate(_oj)}
                                        _new_files.sort(key=lambda f: _order_map.get(f.name, 9999))
                                    except Exception:
                                        pass
                                audio_files.extend(_new_files)
                                print(f"QUEUE_UPDATE: {len(audio_files)}", flush=True)
                                print(f"  [QUEUE] +{len(_new_files)} new file(s) detected, total: {len(audio_files)}")

                        # Предложить запуск YT Packer (только в терминале, только если не было --post-action и не было --yt-pack)
                        if not post_action and not yt_pack and sys.stdin.isatty():
                            _ask_yt_packer(str(project_dir), source_lang=language_code)
                    except Exception as pipeline_err:
                        print(f"\n[ERROR] Ошибка пайплайна для {project_name}: {pipeline_err}")
                        logging.debug(traceback.format_exc())
                        pipeline_ok = False
                        errors.append({
                            'file': project_name,
                            'error': str(pipeline_err),
                            'traceback': traceback.format_exc()
                        })
                    finally:
                        sys.stdout = _orig_stdout
                        _full_log_fh.close()

            if pipeline_ok:
                success_count += 1

        except Exception as e:
            error_msg = f"Ошибка при создании проекта {audio_file.name}: {e}"
            print(f"\n[ERROR] {error_msg}")
            logging.debug(traceback.format_exc())

            # Сохраняем ошибку в список
            errors.append({
                'file': audio_file.name,
                'error': str(e),
                'traceback': traceback.format_exc()
            })
            continue

    # Сохранение отчёта об ошибках
    if errors:
        error_report_path = base_dir / 'errors.json'
        with open(error_report_path, 'w', encoding='utf-8', errors='replace') as f:
            json.dump({
                'timestamp': datetime.now().isoformat(),
                'total_projects': len(audio_files),
                'successful': success_count,
                'failed': len(errors),
                'error_rate': len(errors) / len(audio_files),
                'errors': errors
            }, f, indent=2, ensure_ascii=False)
        
        print(f"\n⚠️  Отчёт об ошибках сохранён: {error_report_path}")

    # Итог
    print("\n" + "="*60)
    print("[ERROR] ОБРАБОТКА ОЧЕРЕДИ ЗАВЕРШЕНА С ОШИБКАМИ!" if errors
          else "[OK] ОБРАБОТКА ОЧЕРЕДИ ЗАВЕРШЕНА!")
    print("="*60)

    if run_pipeline:
        print(f"""
Обработано проектов: {success_count} из {len(audio_files)}
Успешно: {success_count}
Ошибки: {len(errors)}

Папка проектов: {projects_dir}
""")
        if success_count > 0:
            print("СЛЕДУЮЩИЙ ШАГ:")
            print("   Открой prompts_*.txt в папке проекта и генерируй видео в Veo3.")
            print("   Затем положи видеофрагменты в папку проекта и запусти process_fast.bat")
        if errors:
            print("\nОШИБКИ (проекты, требующие повторного запуска):")
            for err in errors:
                proj = err.get('project') or err.get('file', '?')
                msg  = err.get('error', '?')
                print(f"   [{proj}] {msg}")
            print()
            print("КАК ПОВТОРИТЬ режиссуру без повторной транскрипции:")
            print("   python agent/agent.py direct \\")
            print("     --transcription projects/<PROJECT>/transcription.json \\")
            print("     --style pipeline_queue/<STYLE>.txt \\")
            print("     --project <PROJECT>")
        print()
    else:
        print(f"""
Создано проектов: {success_count} из {len(audio_files)}
Успешно: {success_count}
Ошибки: {len(errors)}

Папка проектов: {projects_dir}

СЛЕДУЮЩИЕ ШАГИ:
   Запустите полный пайплайн:
      python agent.py process --run
   Или для отдельного проекта:
      python agent.py run --audio projects/PROJECT_NAME/audio.mp3 --style style_guide.txt --project PROJECT_NAME
""")
    if errors:
        raise SystemExit(1)


# ============================================================================
# DRY-RUN
# ============================================================================

def cmd_dry_run(args):
    """Тестовый прогон: проверка компонентов + mock-симуляция пайплайна без API вызовов."""
    import shutil
    import importlib
    import time
    import random

    GREEN   = '\033[92m'
    RED     = '\033[91m'
    YELLOW  = '\033[93m'
    CYAN    = '\033[96m'
    MAGENTA = '\033[95m'
    DIM     = '\033[2m'
    RESET   = '\033[0m'
    BOLD    = '\033[1m'

    OK   = f"{GREEN}[OK]{RESET}"
    FAIL = f"{RED}[FAIL]{RESET}"
    WARN = f"{YELLOW}[WARN]{RESET}"
    MOCK = f"{MAGENTA}[MOCK]{RESET}"

    agent_dir = Path(__file__).parent
    root_dir  = agent_dir.parent
    rtg_dir   = root_dir / 'pipeline_queue'

    def sep(title=''):
        if title:
            print(f"\n{BOLD}── {title} {'─'*(50-len(title))}{RESET}")
        else:
            print(f"{DIM}{'─'*60}{RESET}")

    def step(msg, sym=None):
        s = sym or MOCK
        print(f"  {s}  {msg}")

    # ═══════════════════════════════════════════════
    # БЛОК 1: ПРОВЕРКА КОМПОНЕНТОВ
    # ═══════════════════════════════════════════════
    print()
    print(f"{BOLD}{'='*60}{RESET}")
    print(f"{BOLD}  DRY-RUN  (0 API calls){RESET}")
    print(f"{BOLD}{'='*60}{RESET}")

    sep("COMPONENTS CHECK")
    results = []

    def check(label, passed, detail=''):
        sym = OK if passed else FAIL
        line = f"  {sym}  {label}"
        if detail:
            line += f"  {DIM}{detail}{RESET}"
        print(line)
        results.append(passed)
        return passed

    # Модули
    for mod_name, label in [
        ('modules.transcriber',   'transcriber'),
        ('modules.director',      'director'),
        ('modules.fastgen',       'fastgen'),
        ('modules.imggen',        'imggen'),
        ('modules.veo_video',     'veo_video'),
        ('modules.yt_packer',     'yt_packer'),
    ]:
        try:
            importlib.import_module(mod_name)
            check(label, True)
        except Exception as e:
            check(label, False, str(e))

    # API ключи
    ffmpeg_path = shutil.which('ffmpeg')
    check('ffmpeg',            bool(ffmpeg_path),              ffmpeg_path or 'NOT IN PATH')
    check('ASSEMBLYAI_API_KEY', bool(config.ASSEMBLYAI_API_KEY), 'SET' if config.ASSEMBLYAI_API_KEY else 'MISSING')
    check('GEMINI_API_KEY',     bool(config.GEMINI_API_KEY),     'SET' if config.GEMINI_API_KEY     else 'MISSING')
    check('FASTGEN_API_KEY',    bool(config.FASTGEN_API_KEY),    'SET' if config.FASTGEN_API_KEY    else 'MISSING')
    check('VEONONSTOP_API_KEY', bool(config.VEONONSTOP_API_KEY), 'SET' if config.VEONONSTOP_API_KEY else 'MISSING')

    all_ok = all(results)
    print()
    if not all_ok:
        print(f"  {FAIL}  Component check failed — fix before pipeline run.")
        print()
        return

    print(f"  {OK}  All components ready.")

    if not getattr(args, 'mock', False):
        # Без --mock: только проверка компонентов
        sep("PIPELINE CHAIN")
        stages = [
            ('TTS (optional)',           True),
            ('Stage 1  Transcription',   bool(config.ASSEMBLYAI_API_KEY)),
            ('Stage 2  Direction',       bool(config.GEMINI_API_KEY)),
            ('Stage 3  Image gen',       bool(config.FASTGEN_API_KEY) or bool(config.VEONONSTOP_API_KEY)),
            ('Stage 3.5  Video gen',     bool(config.VEONONSTOP_API_KEY)),
            ('Stage 4  Concat (ffmpeg)', bool(ffmpeg_path)),
            ('Stage 5  YT Pack',         True),
        ]
        for i, (label, ready) in enumerate(stages):
            arrow = ' →' if i < len(stages) - 1 else ''
            print(f"  {OK if ready else WARN}  {label}{arrow}")
        print()
        print(f"{BOLD}{'='*60}{RESET}")
        print(f"  {GREEN}{BOLD}Pipeline ready.{RESET}  Run with --mock for full simulation.")
        print(f"{BOLD}{'='*60}{RESET}")
        print()
        return

    # ═══════════════════════════════════════════════
    # БЛОК 2: MOCK PIPELINE SIMULATION
    # ═══════════════════════════════════════════════
    sep("MOCK PIPELINE SIMULATION")
    print(f"  {DIM}No API calls. Simulating pipeline flow with fake data.{RESET}")

    # Найти аудио/видео в pipeline_queue
    audio_files = (list(rtg_dir.glob('*.mp3')) + list(rtg_dir.glob('*.wav'))
                   + list(rtg_dir.glob('*.flac')) + list(rtg_dir.glob('*.m4a')) + list(rtg_dir.glob('*.aac'))
                   + list(rtg_dir.glob('*.mp4')) + list(rtg_dir.glob('*.mov')) + list(rtg_dir.glob('*.mkv'))
                   + list(rtg_dir.glob('*.webm')) + list(rtg_dir.glob('*.avi')) + list(rtg_dir.glob('*.m4v')))
    style_files = list(rtg_dir.glob('*.txt'))

    if audio_files:
        audio = audio_files[0]
        size_mb = audio.stat().st_size / 1_048_576
        est_min = max(1, round(size_mb / 1.5))
        audio_name = audio.stem
    else:
        audio_name = 'sample_audio'
        est_min = 5

    clip_avg = (config.VIDEO_CLIP_MIN_DURATION + config.VIDEO_CLIP_MAX_DURATION) / 2
    est_clips = max(5, round(est_min * 60 / clip_avg))
    project_name = f"FLOW_{audio_name}_{datetime.now().strftime('%d%m%y_%H%M')}"

    # CONFIG SUMMARY
    two_pass = config.GEMINI_TWO_PASS
    veo_par  = config.VEONONSTOP_MAX_PARALLEL
    fg_par   = config.FASTGEN_MAX_PARALLEL
    ratio    = config.VEONONSTOP_ASPECT_RATIO

    print()
    print(f"  {DIM}Config:  lang={config.ASSEMBLYAI_LANGUAGE_CODE}  model={config.GEMINI_MODEL}")
    print(f"           two-pass={two_pass}  clips={config.VIDEO_CLIP_MIN_DURATION}-{config.VIDEO_CLIP_MAX_DURATION}s  ratio={ratio}")
    print(f"           fastgen.parallel={fg_par}  veo.parallel={veo_par}{RESET}")

    # ── STAGE 0: TTS (skip) ──
    sep("Stage 0  TTS")
    step(f"audio found in pipeline_queue/: {audio.name if audio_files else '[none]'}")
    if audio_files:
        step(f"TTS skipped — audio already present", OK)
    else:
        step(f"Would run TTS: script.txt → audio.mp3", MOCK)

    # ── STAGE 1: QUEUE + TRANSCRIPTION ──
    sep("Stage 1  Queue + Transcription (AssemblyAI)")
    step(f"Queue: pipeline_queue/{audio_name}.*  →  projects/{project_name}/")
    step(f"Transcription: {audio_name}  (~{est_min} min audio)")
    step(f"  ← {est_min*8} segments, lang={config.ASSEMBLYAI_LANGUAGE_CODE}  [mock]")
    step(f"  → transcription.json", OK)

    # ── STAGE 2: DIRECTION ──
    sep("Stage 2  Direction (Gemini)")
    step(f"Model: {config.GEMINI_MODEL}  two-pass={two_pass}")
    if two_pass:
        step(f"Pass 1: JSON plan  →  {est_clips} clips planned")
        step(f"Pass 2: prompts    →  {est_clips} prompts generated (chunked)")
    else:
        step(f"Single pass: plan + prompts  →  {est_clips} clips")
    step(f"  → montage_plan.json  +  *_prompts_*.txt", OK)

    # ── STAGE 3: IMAGE GEN ──
    sep("Stage 3  Image generation (FastGen)")
    step(f"FastGen {config.FASTGEN_MODEL}  parallel={fg_par}  aspect={config.FASTGEN_ASPECT_RATIO}")
    step(f"  {est_clips} images  ({est_clips} prompts from prompts.txt)")
    step(f"  batches: {(est_clips + fg_par - 1) // fg_par} × {fg_par} workers")
    step(f"  est. time: ~{round(est_clips / fg_par * 8)}s  (mock: skipped)", MOCK)
    step(f"  → generated/{'{001..%03d}' % est_clips}.png", OK)

    # ── STAGE 3.5: VIDEO GEN ──
    sep("Stage 3.5  Video generation (VeoNonStop i2v)")
    submit_slots = max(1, veo_par // 3)
    step(f"i2v  ratio={ratio}  parallel={veo_par}  submit_semaphore={submit_slots}")
    step(f"  {est_clips} clips  (images from generated/)")
    step(f"  est. time: ~{round(est_clips / veo_par * 75 / 60)}m  @75s/clip  (mock: skipped)", MOCK)
    step(f"  → vid_img/{'{001..%03d}' % est_clips}.mp4", OK)

    # ── STAGE 4: CONCAT ──
    sep("Stage 4  Concat (video_concat.py + FFmpeg)")
    total_s = round(est_clips * clip_avg)
    step(f"Input: {est_clips} fragments  +  montage_plan.json")
    step(f"Retiming → concat → final trim  (~{total_s}s = {total_s//60}:{total_s%60:02d} min)")
    step(f"  → projects/{project_name}/{project_name}.mp4", OK)

    # ── STAGE 5: YT PACK ──
    sep("Stage 5  YT Pack")
    langs = getattr(config, 'YT_PACK_LANGUAGES', [config.ASSEMBLYAI_LANGUAGE_CODE])
    step(f"Languages: {' + '.join(str(l) for l in langs[:3])}")
    step(f"  → subtitles (.srt)  description  tags  cover prompts", OK)

    # ── SUMMARY ──
    sep("SUMMARY")
    cost_ai   = round(est_min * 0.007, 2)
    cost_gem  = round(est_clips * 0.002, 2)
    cost_fg   = round(est_clips * 0.015, 2)
    cost_veo  = round(est_clips * 0.05,  2)
    cost_tot  = round(cost_ai + cost_gem + cost_fg + cost_veo, 2)
    time_img  = round(est_clips / fg_par * 8)
    time_vid  = round(est_clips / veo_par * 75)

    print(f"\n  Project:   {project_name}")
    print(f"  Audio:     {audio_name}  (~{est_min} min)")
    print(f"  Clips:     {est_clips}")
    print(f"  Est. time: ~{time_img}s image gen  +  ~{time_vid//60}m video gen  +  ~3m concat")
    print(f"  Est. cost: AssemblyAI ~${cost_ai}  Gemini ~${cost_gem}  FastGen ~${cost_fg}  VeoNon ~${cost_veo}")
    print(f"             Total ~${cost_tot}")
    print()
    print(f"{BOLD}{'='*60}{RESET}")
    print(f"  {GREEN}{BOLD}Mock run complete. 0 API calls made.{RESET}")
    print(f"{BOLD}{'='*60}{RESET}")
    print()


# ============================================================================
# MUSIC (Pass 3 — Suno) CLI
# ============================================================================

def _find_style_guide(project_dir: Path) -> Optional[Path]:
    """Ищет style guide в типовых местах проекта и очереди."""
    priority_patterns = (
        'style_guide_adapted.txt',
        'style_guide.txt',
        '*_стиль*.txt',
        '*_style_*.txt',
        '*_style.txt',
        'SG_*.txt',
    )
    for pattern in priority_patterns:
        for cand in project_dir.glob(pattern):
            if cand.is_file() and cand.stat().st_size > 0:
                return cand

    proj_root = project_dir.parent.parent
    pname = project_dir.name
    for subdir in ('pipeline_queue',):
        d = proj_root / subdir
        if not d.exists():
            continue
        for sg in (list(d.glob('*_стиль.txt')) + list(d.glob('*_style.txt')) + list(d.glob('SG_*.txt'))):
            sg_stem = sg.stem.replace('_стиль', '').replace('_style', '').replace('SG_', '')
            if sg_stem and sg_stem in pname:
                return sg
        sg_global = list(d.glob('SG_*.txt'))
        if sg_global:
            return sg_global[0]

    txts = [t for t in project_dir.glob('*.txt')
            if 'prompts' not in t.name.lower() and 'transcrip' not in t.name.lower()]
    if txts:
        return txts[0]
    return None


_MUSIC_BACKGROUND_STATUS = "music_background_status.json"


def _write_music_background_status(project_dir: Path, **payload) -> None:
    """Atomically publish background music progress for the concat worker."""
    status_path = project_dir / _MUSIC_BACKGROUND_STATUS
    data = {
        "updated_at": datetime.now().isoformat(timespec="seconds"),
        **payload,
    }
    temporary = status_path.with_suffix(".tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(status_path)


def _start_music_background(project_dir: Path) -> bool:
    """Launch music in a project-owned process parallel to visual generation."""
    if os.environ.get("VARAGENT_MUSIC_ENABLED", "0").lower() not in (
        "1", "true", "yes", "on",
    ):
        return False

    _write_music_background_status(project_dir, state="starting", ready_tracks=0)
    log_path = project_dir / "music_background.log"
    command = [
        sys.executable,
        str(Path(__file__).resolve()),
        "music-background",
        str(project_dir),
    ]
    try:
        with log_path.open("w", encoding="utf-8", buffering=1) as log_file:
            process = subprocess.Popen(
                command,
                cwd=str(Path(__file__).parent),
                env=os.environ.copy(),
                stdin=subprocess.DEVNULL,
                stdout=log_file,
                stderr=subprocess.STDOUT,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        _write_music_background_status(
            project_dir,
            state="running",
            pid=process.pid,
            log_file=log_path.name,
            ready_tracks=0,
        )
        print(f"  [Music] Background plan+generation started (pid {process.pid})")
        return True
    except Exception as exc:
        _write_music_background_status(
            project_dir,
            state="failed",
            error=f"{type(exc).__name__}: {exc}",
            ready_tracks=0,
        )
        print(f"  [Music] Background start failed: {exc}")
        logging.debug(traceback.format_exc())
        return False


def cmd_music_background(args):
    """Create a music plan and tracks in an independent project process."""
    from modules.music_director import music_direct_project
    from modules.music_orchestrator import generate_for_project

    project_dir = Path(args.project_dir).resolve()
    if not project_dir.is_dir():
        raise RuntimeError(f"Music background project not found: {project_dir}")
    _write_music_background_status(project_dir, state="running", stage="plan", ready_tracks=0)
    try:
        transcription_path = project_dir / "transcription.json"
        montage_plan_path = project_dir / "montage_plan.json"
        style_path = _find_style_guide(project_dir)
        if not transcription_path.is_file():
            raise FileNotFoundError(transcription_path)
        if not montage_plan_path.is_file():
            raise FileNotFoundError(montage_plan_path)
        if not style_path or not style_path.is_file():
            raise FileNotFoundError("Style guide not found")

        print(f"── Music background: plan ({project_dir.name}) ──")
        plan = music_direct_project(
            transcription_path=str(transcription_path),
            montage_plan_path=str(montage_plan_path),
            style_guide_path=str(style_path),
            output_dir=str(project_dir),
            project_name=project_dir.name,
        )
        _write_music_background_status(
            project_dir,
            state="running",
            stage="generate",
            tracks=int(plan.get("tracks_count", 0)),
            ready_tracks=0,
        )
        print(f"── Music background: generate ({project_dir.name}) ──")
        generated = generate_for_project(
            project_dir=str(project_dir),
            browser=getattr(config, "SUNO_COOKIE_BROWSER", None),
            model=getattr(config, "SUNO_MODEL", None),
        )
        # Не только mp3: локальная библиотека копирует треки с родным
        # расширением (wav/flac/...) — считаем все аудиоформаты миксера.
        _audio_exts = ('.mp3', '.wav', '.m4a', '.aac', '.flac', '.ogg')
        ready_tracks = sum(
            1 for f in (project_dir / "music").glob("*")
            if f.is_file() and f.suffix.lower() in _audio_exts
        )
        _write_music_background_status(
            project_dir,
            state="completed",
            stage="completed",
            tracks=int(generated.get("total", plan.get("tracks_count", 0))),
            ready_tracks=ready_tracks,
            failed=int(generated.get("failed", 0)),
        )
        print(f"✅ Music background completed: {ready_tracks} ready track(s)")
    except Exception as exc:
        _write_music_background_status(
            project_dir,
            state="failed",
            stage="failed",
            error=f"{type(exc).__name__}: {exc}",
            ready_tracks=0,
        )
        print(f"❌ Music background failed: {exc}")
        logging.debug(traceback.format_exc())
        raise SystemExit(2)


def cmd_music_plan(args):
    """Pass 3: создаёт music_plan.json через music-режиссёра (backend по .env)."""
    from modules.music_director import music_direct_project

    project_dir = Path(args.project_dir).resolve()
    if not project_dir.is_dir():
        print(f"❌ Папка не найдена: {project_dir}")
        sys.exit(1)

    transcription_path = project_dir / 'transcription.json'
    montage_plan_path = project_dir / 'montage_plan.json'
    if not transcription_path.exists():
        print(f"❌ Нет transcription.json в {project_dir}")
        sys.exit(1)
    if not montage_plan_path.exists():
        print(f"❌ Нет montage_plan.json в {project_dir} — сначала запустите Pass 1")
        sys.exit(1)

    style_path = Path(args.style) if args.style else _find_style_guide(project_dir)
    if not style_path or not style_path.exists():
        print(f"❌ Style guide не найден. Укажите --style вручную.")
        sys.exit(1)

    print(f"📂 Project: {project_dir}")
    print(f"📜 Style:   {style_path}")

    result = music_direct_project(
        transcription_path=str(transcription_path),
        montage_plan_path=str(montage_plan_path),
        style_guide_path=str(style_path),
        output_dir=str(project_dir),
        project_name=project_dir.name,
        model_name=args.model,
    )
    print(f"\n✅ music_plan.json готов:")
    print(f"   треков: {result['tracks_count']}")
    print(f"   аудио:  {result['audio_duration']:.0f}с")
    print(f"\n→ Дальше: python agent.py music-generate \"{project_dir}\"")


def cmd_music_generate(args):
    """Гонит Suno генерацию по music_plan.json (cookie auth). Опц. concat после успеха."""
    from modules.music_orchestrator import generate_for_project

    project_dir = Path(args.project_dir).resolve()
    if not project_dir.is_dir():
        print(f"❌ Папка не найдена: {project_dir}")
        sys.exit(1)
    if not (project_dir / 'music_plan.json').exists():
        print(f"❌ Нет music_plan.json — сначала запустите music-plan")
        sys.exit(1)

    summary = generate_for_project(
        project_dir=str(project_dir),
        force=args.force,
        browser=args.browser,
        model=args.model,
        parallel=args.parallel,
    )

    if summary['failed'] > 0:
        print(f"\n⚠️  {summary['failed']} треков не удалось сгенерировать")
        if not getattr(args, 'auto_concat', False):
            sys.exit(2)
        print(f"   но --auto-concat указан — пробуем concat с тем что есть")

    if getattr(args, 'auto_concat', False):
        _run_auto_concat(project_dir, args)
    else:
        print(f"\n→ Дальше: python agent.py music-review \"{project_dir}\"")


def cmd_music_browser_generate(args):
    """Suno-генерация через видимый persistent-браузер (или safe-stock провайдер)."""
    from modules.suno_browser_automator import generate_for_project_browser, SunoBrowserError

    project_dir = Path(args.project_dir).resolve()
    if not project_dir.is_dir():
        print(f"❌ Project folder not found: {project_dir}")
        sys.exit(1)
    if not (project_dir / 'music_plan.json').exists():
        print(f"❌ music_plan.json not found in {project_dir}")
        sys.exit(1)

    import config as _config
    music_provider = str(getattr(_config, 'MUSIC_PROVIDER', 'suno') or 'suno').strip().lower()
    if music_provider in {'procedural', 'safe_stock', 'stock', 'pixabay', 'pexels'}:
        from modules.music_safe_stock import generate_safe_music_for_project
        summary = generate_safe_music_for_project(
            project_dir=str(project_dir), provider=music_provider, force=args.force,
        )
        print(f"\n✅ Safe music summary ({summary.get('provider', music_provider)}):")
        print(f"   ok: {summary['ok']}  skipped: {summary['skipped']}  failed: {summary['failed']}  total: {summary['total']}")
        if summary["failed"] > 0:
            sys.exit(2)
        print(f"\n→ Next: python agent.py music-review \"{project_dir}\"")
        return

    try:
        summary = generate_for_project_browser(
            project_dir=str(project_dir),
            force=args.force,
            profile_dir=args.profile_dir,
            headless=args.headless,
            max_tracks=args.max_tracks,
            login_only=args.login_only,
            login_timeout_sec=args.login_timeout,
        )
    except SunoBrowserError as exc:
        print(f"\n❌ Browser Suno failed: {exc}")
        sys.exit(2)

    print("\n✅ Browser Suno summary:")
    print(f"   ok: {summary['ok']}  skipped: {summary['skipped']}  failed: {summary['failed']}  total: {summary['total']}")
    if summary["failed"] > 0:
        sys.exit(2)
    if not args.login_only:
        print(f"\n→ Next: python agent.py music-review \"{project_dir}\"")


def _run_auto_concat(project_dir: Path, args):
    """Auto-concat: запускает video_concat.py с --music-plan для готового проекта."""
    import subprocess as _sp
    mp = project_dir / 'montage_plan.json'
    music_plan = project_dir / 'music_plan.json'
    music_dir = project_dir / 'music'
    if not mp.exists():
        print(f"❌ montage_plan.json не найден — concat невозможен")
        sys.exit(3)
    _music_exts = ('.mp3', '.wav', '.m4a', '.aac', '.flac', '.ogg')
    if not music_dir.exists() or not any(
            f.suffix.lower() in _music_exts
            for f in music_dir.iterdir() if f.is_file()):
        print(f"⚠️  В {music_dir} нет аудио-треков — concat пойдёт без музыки")

    output_mp4 = project_dir / f'{project_dir.name}.mp4'
    video_concat_py = project_dir.parent.parent / 'video_concat.py'
    cmd = [
        sys.executable, str(video_concat_py),
        'montage_plan.json',
        '-o', f'{project_dir.name}.mp4',
        '-b', getattr(args, 'concat_bitrate', '10M'),
        '--force-amd',
    ]
    if music_plan.exists() and music_dir.exists():
        cmd.extend(['--music-plan', 'music_plan.json', '--music-dir', 'music'])
    print(f"\n🎬 Auto-concat: {project_dir.name}\n   {' '.join(cmd)}")
    rc = _sp.call(cmd, cwd=str(project_dir))
    if rc != 0:
        print(f"\n❌ Concat вернул код {rc}")
        sys.exit(rc)
    print(f"\n✅ Готово: {output_mp4}")


def cmd_music_review(args):
    """Открывает GUI плеер для треков (preview + выбор варианта/громкости)."""
    from modules.music_review import open_review

    project_dir = Path(args.project_dir).resolve()
    if not project_dir.is_dir():
        print(f"❌ Папка не найдена: {project_dir}")
        sys.exit(1)
    if not (project_dir / 'music_plan.json').exists():
        print(f"❌ Нет music_plan.json в {project_dir}")
        sys.exit(1)

    print(f"🖼  Открываю Music Review GUI для {project_dir.name}...")
    open_review(project_dir)


# ============================================================================
# CLI ИНТЕРФЕЙС
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description='Video Production Agent - Автоматизация создания видео',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Примеры использования:
  agent run --audio narration.wav --style style_guide.txt --project "My Video"
  agent transcribe --audio narration.wav
  agent direct --transcription transcription.json --style style_guide.txt
  agent validate --all
  agent status
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Команды')
    
    # Команда: run (полный пайплайн)
    parser_run = subparsers.add_parser('run', help='Полный пайплайн (этапы 1-2)')
    parser_run.add_argument('--director-backend', type=str, default=None,
                            choices=['gemini', 'gpt'],
                            help='Backend режиссуры: gemini (default) или gpt (Codex CLI)')
    parser_run.add_argument(
        '--director-profile',
        choices=['standard', 'auto_visual_story'],
        default=None,
        help='Director behavior profile (default: DIRECTOR_PROFILE from config)',
    )
    parser_run.add_argument('--audio', required=True, help='Путь к аудиофайлу')
    parser_run.add_argument('--style', required=True, help='Путь к style_guide.txt')
    parser_run.add_argument('--project', default='Untitled', help='Название проекта')
    parser_run.add_argument('--language', choices=config.ASSEMBLYAI_SUPPORTED_LANGUAGES,
                           default=None, help='Язык аудио (по умолчанию из .env)')
    parser_run.add_argument('--model', type=str, default=None, help='Модель Gemini (например gemini-3.0-pro)')
    parser_run.add_argument('--director-analysis', action='store_true', default=None,
                           help='Генерировать director_analysis.md (переопределяет .env)')
    parser_run.add_argument('--force', action='store_true', help='Запустить режиссёра даже при аномальной транскрипции')
    parser_run.add_argument('--with-images', action='store_true', default=False,
                           help='Run FastGen image generation (stage 3) after director')
    parser_run.add_argument('--adapt-sg', action='store_true', default=False,
                           help='Adapt style guide to current script via GPT (Codex CLI) before direction')
    parser_run.set_defaults(func=cmd_run)

    # Команда: transcribe
    parser_transcribe = subparsers.add_parser('transcribe', help='Транскрипция аудио')
    parser_transcribe.add_argument('--audio', required=True, help='Путь к аудиофайлу')
    parser_transcribe.add_argument('--output', help='Путь для transcription.json')
    parser_transcribe.add_argument('--language', choices=config.ASSEMBLYAI_SUPPORTED_LANGUAGES,
                                  default=None, help='Язык аудио (по умолчанию из .env)')
    parser_transcribe.set_defaults(func=cmd_transcribe)

    # Команда: direct
    parser_direct = subparsers.add_parser('direct', help='Режиссерский анализ')
    parser_direct.add_argument('--transcription', required=True, help='Путь к transcription.json')
    parser_direct.add_argument('--style', required=True, help='Путь к style_guide.txt')
    parser_direct.add_argument('--output', help='Директория для результатов')
    parser_direct.add_argument('--project', default='Untitled', help='Название проекта')
    parser_direct.add_argument('--force', action='store_true', help='Пропустить валидацию')
    parser_direct.add_argument('--model', type=str, default=None, help='Модель Gemini (например gemini-3.0-pro)')
    parser_direct.add_argument('--director-analysis', action='store_true', default=None,
                              help='Генерировать director_analysis.md (переопределяет .env)')
    parser_direct.add_argument('--director-backend', type=str, default=None,
                              choices=['gemini', 'gpt'],
                              help='Backend режиссуры: gemini (default) или gpt (Codex CLI)')
    parser_direct.add_argument(
        '--director-profile',
        choices=['standard', 'auto_visual_story'],
        default=None,
        help='Director behavior profile (default: DIRECTOR_PROFILE from config)',
    )
    parser_direct.add_argument('--two-pass', action='store_true', default=False,
                              help='Двухпроходный режим: проход 1 = JSON план, проход 2 = промпты (для проектов > 15 мин)')
    parser_direct.add_argument('--prompts-only', action='store_true', default=False,
                              help='Только проход 2: читает готовый montage_plan.json и генерирует промпты')
    parser_direct.add_argument('--resume', action='store_true', default=False,
                              help='Продолжить запись промптов с места остановки (только с --prompts-only)')
    parser_direct.add_argument(
        '--visual-story-step',
        choices=['analyze', 'search', 'finalize', 'full'],
        default='full',
        help='Auto Visual Story stage when --director-profile=auto_visual_story',
    )
    parser_direct.add_argument('--visual-story-mock', action='store_true', default=False,
                              help='Use deterministic scene/query responses (no LLM)')
    parser_direct.add_argument('--visual-story-mock-assets', action='store_true', default=False,
                              help='Create test images instead of running EPF')
    parser_direct.add_argument('--adapt-sg', action='store_true', default=False,
                              help='Adapt style guide to current script via GPT (Codex CLI) before direction')
    parser_direct.set_defaults(func=cmd_direct)

    parser_visual_story = subparsers.add_parser(
        'visual-story',
        help='Run/resume Auto Visual Story profile for an existing project',
    )
    parser_visual_story.add_argument('--project', required=True, help='Project directory')
    parser_visual_story.add_argument('--style', default=None, help='Style guide override')
    parser_visual_story.add_argument('--project-name', default=None, help='Project label')
    parser_visual_story.add_argument('--model', default=None, help='Model override')
    parser_visual_story.add_argument('--director-backend', choices=['gemini', 'gpt'], default=None)
    parser_visual_story.add_argument('--step', choices=['analyze', 'search', 'finalize', 'full'],
                                     default='full')
    parser_visual_story.add_argument('--resume', action='store_true', default=False)
    parser_visual_story.add_argument('--mock', action='store_true', default=False,
                                     help='Use deterministic scene/query responses (no LLM)')
    parser_visual_story.add_argument('--mock-assets', action='store_true', default=False,
                                     help='Create test images instead of running EPF')
    parser_visual_story.set_defaults(func=cmd_visual_story)
    
    # Команда: validate
    parser_validate = subparsers.add_parser('validate', help='Валидация файлов')
    parser_validate.add_argument('--transcription', help='Путь к transcription.json')
    parser_validate.add_argument('--montage-plan', help='Путь к montage_plan.json')
    parser_validate.add_argument('--all', action='store_true', help='Валидировать все JSON')
    parser_validate.add_argument('--dir', help='Директория для сканирования')
    parser_validate.set_defaults(func=cmd_validate)
    
    # Команда: status
    parser_status = subparsers.add_parser('status', help='Статус проекта')
    parser_status.add_argument('--dir', default='.', help='Директория проекта')
    parser_status.set_defaults(func=cmd_status)
    
    # Команда: cost-estimate
    parser_cost = subparsers.add_parser('cost-estimate', help='Оценка стоимости API')
    parser_cost.add_argument('--duration', type=int, default=30, help='Длительность аудио в минутах (по умолчанию 30)')
    parser_cost.add_argument('--language', choices=config.ASSEMBLYAI_SUPPORTED_LANGUAGES,
                            default='ru', help='Язык аудио (влияет на токенизацию, по умолчанию ru)')
    parser_cost.set_defaults(func=cmd_cost_estimate)
    
    # Команда: generate (генерация изображений — FastGen или VeoNonStop)
    parser_generate = subparsers.add_parser('generate', help='Image generation (stage 3) — FastGen / VeoNonStop / CinAI')
    parser_generate.add_argument('--project', required=True, help='Project folder name (in projects/)')
    parser_generate.add_argument('--ids', type=str, default=None,
                                 help='Comma-separated clip IDs (e.g., 1,2,3). Default: all')
    parser_generate.add_argument('--parallel', type=int, default=None,
                                 help=f'Max parallel generations (default: {config.FASTGEN_MAX_PARALLEL})')
    parser_generate.add_argument('--mode', choices=['flow', 'whisk'], default=None,
                                 help='Reference mode: flow (flat refs) or whisk (categorized). Auto-detected if not set')
    parser_generate.add_argument('--model', type=str, default=None,
                                 help=f'FastGen model (default: {config.FASTGEN_MODEL})')
    parser_generate.add_argument('--aspect', type=str, default=None,
                                 help=f'Aspect ratio (default: {config.FASTGEN_ASPECT_RATIO})')
    parser_generate.add_argument('--quality', choices=['1K', '2K', '4K'], default=None,
                                 help=f'CinAI output resolution (default: {getattr(config, "CINAI_QUALITY", "1K")})')
    parser_generate.add_argument('--backup-key', action='store_true', default=False,
                                 help='Use FASTGEN_API_KEY_BACKUP instead of main key')
    parser_generate.add_argument('--image-gen', choices=['fastgen', 'cinai', 'imagen', 'banana', 'banana_ref', 'banana2', 'banana2_ref'],
                                 default=None,
                                 help='Image generator: fastgen, cinai, imagen, banana, banana_ref')
    parser_generate.add_argument('--no-preflight', action='store_true', default=False,
                                 help='Skip preflight ref test (banana_ref mode only)')
    parser_generate.add_argument('--key-slot', choices=['1', '2', '3', '4', 'both', 'all'], default='1',
                                 help='Key slot: 1-4=specific key, both/all=all configured keys in parallel')
    parser_generate.set_defaults(func=cmd_generate)

    # Команда: img2video (генерация видео через VeoNonStop)
    parser_i2v = subparsers.add_parser('img2video', help='Video generation via VeoNonStop API (stage 3.5)')
    parser_i2v.add_argument('--project', required=True, help='Project folder name (in projects/)')
    parser_i2v.add_argument('--mode', choices=['i2v', 't2v', 'components'], default=None,
                            help='Mode: i2v (image-to-video), t2v (text-to-video), components (t2v + refs)')
    parser_i2v.add_argument('--ids', type=str, default=None,
                            help='Comma-separated clip IDs (e.g., 1,2,3). Default: all')
    parser_i2v.add_argument('--parallel', type=int, default=None,
                            help=f'Max parallel tasks (default: {config.VEONONSTOP_MAX_PARALLEL})')
    parser_i2v.add_argument('--ratio', type=str, default=None,
                            help=f'Aspect ratio: 16:9, 9:16, 1:1 (default: {config.VEONONSTOP_ASPECT_RATIO})')
    parser_i2v.add_argument('--prompt', type=str, default=None,
                            help='Single prompt for all clips (overrides per-clip prompts)')
    parser_i2v.add_argument('--prompt-file', type=str, default=None,
                            help='Path to file with single prompt (UTF-8). Overrides --prompt.')
    parser_i2v.add_argument('--key-slot', choices=['1', '2', '3', '4', 'both', 'all'], default='1',
                            help='Key slot: 1-4=specific key, both/all=all configured keys in parallel')
    parser_i2v.add_argument('--ref-dir', type=str, default=None,
                            help='Reference images directory (for components mode, default: PROJECT/ref/)')
    parser_i2v.add_argument('--no-cancel', action='store_true', default=False,
                            help='Skip cancel-all-tasks on startup (use when another generation runs in parallel)')
    parser_i2v.set_defaults(func=cmd_img2video)

    # Команда: real-photos (Real archival photo/video insertion stage)
    parser_real = subparsers.add_parser('real-photos',
        help='Real Photo stage — подмена части AI-видеоряда живыми архивами (stage 3.5b)')
    parser_real.add_argument('--project', required=True,
        help='Имя папки проекта (в projects/) или абсолютный путь')
    parser_real.add_argument('--target-ratio', type=float, default=None,
        dest='target_ratio',
        help='Целевая доля клипов для замены (0.0..1.0). Default: REAL_PHOTO_RATIO_TARGET')
    parser_real.add_argument('--min-ratio', type=float, default=None,
        dest='min_ratio',
        help='Минимальная доля. Default: REAL_PHOTO_RATIO_MIN')
    parser_real.add_argument('--max-ratio', type=float, default=None,
        dest='max_ratio',
        help='Максимальная доля (жёсткий потолок). Default: REAL_PHOTO_RATIO_MAX')
    parser_real.add_argument('--sources', type=str, default=None,
        help='Источники через запятую: wikimedia,nasa,loc,archive')
    parser_real.add_argument('--codex-model', type=str, default=None,
        dest='codex_model',
        help='Модель Codex для отбора (default: REAL_PHOTO_CODEX_MODEL или GPT_MODEL)')
    parser_real.set_defaults(func=cmd_real_photos)

    parser_epf_select = subparsers.add_parser(
        'real-photo-epf-select',
        help='Choose EPF image candidates with the configured vision LLM',
    )
    parser_epf_select.add_argument(
        '--job', required=True,
        help='Path to _real_photo_work/extreme_picture_finder',
    )
    parser_epf_select.add_argument('--provider', default=None)
    parser_epf_select.add_argument('--model', default=None)
    parser_epf_select.set_defaults(func=cmd_real_photo_epf_select)

    parser_epf_ingest = subparsers.add_parser(
        'real-photo-epf-ingest',
        help='Copy vision-selected EPF images into generated/',
    )
    parser_epf_ingest.add_argument(
        '--job', required=True,
        help='Path to _real_photo_work/extreme_picture_finder',
    )
    parser_epf_ingest.add_argument('--replace', action='store_true')
    parser_epf_ingest.set_defaults(func=cmd_real_photo_epf_ingest)

    # Команда: yt-pack (YouTube-упаковщик)
    parser_ytpack = subparsers.add_parser('yt-pack', help='YT Packer — субтитры, описание, обложки (stage 5)')
    parser_ytpack.add_argument('--project', required=True, help='Название папки проекта (в projects/)')
    parser_ytpack.add_argument('--source-lang', default=None,
                                help='Язык транскрипции (ru, en, ...). Если не указан — читается из transcription.json')
    parser_ytpack.add_argument('--interactive', action='store_true', default=False,
                                help='Спросить каждый параметр интерактивно перед запуском')
    parser_ytpack.set_defaults(func=cmd_yt_pack)

    # Команда: process (обработка очереди)
    parser_process = subparsers.add_parser('process', help='Обработка файлов из очереди')
    parser_process.add_argument('--style', default=None, metavar='FILE',
                                help='Явный style guide для всех аудио (передаётся из GUI)')
    parser_process.add_argument('--style-map', default=None, metavar='JSON',
                                help='JSON-маппинг {"audio.mp3": "/path/sg.txt"} для индивидуальных style guides (из GUI)')
    parser_process.add_argument('--file-list', default=None, metavar='JSON',
                                help='JSON-массив путей к аудиофайлам (из GUI, сохраняет порядок загрузки)')
    parser_process.add_argument('--queue-dir', default=None, metavar='DIR',
                                help='Папка очереди (из GUI: pipeline_queue/)')
    parser_process.add_argument('--ref-map', default=None, metavar='JSON',
                                help='JSON-маппинг {"audio.wav": "/path/staging/"} индивидуальных рефов (из GUI)')
    parser_process.add_argument('--run', action='store_true',
                                help='Запустить полный пайплайн (транскрипция + режиссура) сразу после настройки каждого проекта')
    parser_process.add_argument('--director-backend', type=str, default=None,
                                choices=['gemini', 'gpt'],
                                help='Backend режиссуры: gemini (default) или gpt (Codex CLI)')
    parser_process.add_argument(
        '--director-profile',
        choices=['standard', 'auto_visual_story'],
        default=None,
        help='Director behavior profile (default: DIRECTOR_PROFILE from config)',
    )
    parser_process.add_argument('--two-pass', action='store_true', default=False,
                                help='Двухпроходный режим для режиссуры (для проектов > 15 мин)')
    parser_process.add_argument('--language', choices=config.ASSEMBLYAI_SUPPORTED_LANGUAGES,
                                default=None, help='Язык озвучки (default: из .env ASSEMBLYAI_LANGUAGE_CODE)')
    parser_process.add_argument('--clip-mode', choices=['video', 'slideshow', 'vislide'], default=None,
                                help='Тип клипов: video (Veo3, 4-8с), slideshow (картинки, 2-7с), vislide (каждый N-й клип оживляется). Если не указан — спрашивает интерактивно.')
    parser_process.add_argument('--vislide-interval', type=int, default=0, metavar='N',
                                help='В режиме vislide: каждый N-й клип идёт в i2v воркер (остальные — Ken Burns). Default=3')
    parser_process.add_argument('--clip-min', type=int, default=None,
                                help='Минимальная длительность клипа (сек, переопределяет .env)')
    parser_process.add_argument('--clip-max', type=int, default=None,
                                help='Максимальная длительность клипа (сек, переопределяет .env)')
    parser_process.add_argument('--post-action',
                                type=_parse_post_action,
                                choices=POST_ACTION_CHOICES,
                                default=None,
                                help='Post-pipeline generation; ImageGen provider is selected with PIPELINE_IMG_GEN')
    parser_process.add_argument('--prompt-mode',
                                choices=['single', 'perclip'],
                                default='single',
                                help='Prompt mode for i2v: single (one prompt for all) or perclip (original prompts from prompts.txt)')
    parser_process.add_argument('--codex-adapt', action='store_true', default=False,
                                help='GPT adapt image prompts for VEO i2v animation')
    parser_process.add_argument('--from-script', metavar='FILE', default=None,
                                help='Script file (.txt) — skip TTS+transcription, use GeminiScriptDirector instead')
    parser_process.add_argument('--script-type', choices=['prose', 'screenplay'], default='prose',
                                help='Script type: prose (default) or screenplay')
    parser_process.add_argument('--yt-pack', action='store_true', default=False,
                                help='Run YT Packer (subtitles, description, covers) after all stages')
    parser_process.add_argument('--adapt-sg', action='store_true', default=False,
                                help='Adapt style guide to current script via GPT (Codex CLI) before direction')
    parser_process.set_defaults(func=cmd_process_queue)

    # Команда: script (режиссура из текстового сценария)
    parser_script = subparsers.add_parser('script', help='Script Director — режиссура из текстового сценария (без аудио)')
    parser_script.add_argument('--script', required=True, metavar='FILE', help='Путь к текстовому сценарию (.txt)')
    parser_script.add_argument('--style',  required=True, metavar='FILE', help='Путь к style_guide.txt')
    parser_script.add_argument('--project', default=None, help='Название проекта (по умолчанию — имя файла сценария)')
    parser_script.add_argument('--output', default=None, help='Папка вывода (по умолчанию: рядом со сценарием)')
    parser_script.add_argument('--script-type', choices=['prose', 'screenplay'], default='prose',
                                help='Тип сценария: prose (проза, по умолчанию) или screenplay')
    parser_script.add_argument('--director-backend', type=str, default=None,
                                choices=['gemini', 'gpt'],
                                help='Backend режиссуры: gemini (default) или gpt (Codex CLI)')
    parser_script.add_argument('--two-pass', action='store_true', default=False,
                                help='Двухпроходный режим (Pass 1 = JSON план, Pass 2 = промпты)')
    parser_script.add_argument('--clip-mode', choices=['video', 'slideshow', 'vislide'], default=None)
    parser_script.add_argument('--vislide-interval', type=int, default=0, metavar='N',
                                help='В режиме vislide: каждый N-й клип идёт в i2v (default=3)')
    parser_script.add_argument('--clip-min', type=int, default=None)
    parser_script.add_argument('--clip-max', type=int, default=None)
    parser_script.add_argument('--post-action',
                                type=_parse_post_action,
                                choices=POST_ACTION_CHOICES,
                                default=None)
    parser_script.add_argument('--yt-pack', action='store_true', default=False,
                                help='Run YT Packer after all stages')
    parser_script.set_defaults(func=cmd_script_direct)

    parser_dryrun = subparsers.add_parser('dry-run', help='Тестовый прогон — проверка компонентов + mock-симуляция пайплайна')
    parser_dryrun.add_argument('--mock', action='store_true', default=False,
                               help='Симулировать полный пайплайн с фейковыми данными (0 API вызовов)')
    parser_dryrun.set_defaults(func=cmd_dry_run)

    # ========================================================================
    # MUSIC stages (Pass 3 — Suno)
    # ========================================================================
    parser_mplan = subparsers.add_parser(
        'music-plan', help='Pass 3: создаёт music_plan.json через music-режиссёра')
    parser_mplan.add_argument('project_dir', help='Папка проекта (transcription.json + montage_plan.json)')
    parser_mplan.add_argument('--style', default=None, help='Путь к style guide (по умолч. автопоиск)')
    parser_mplan.add_argument('--model', default=None, help='Модель режиссёра (default из .env)')
    parser_mplan.set_defaults(func=cmd_music_plan)

    parser_mbg = subparsers.add_parser(
        'music-background',
        help='Internal: create music plan and tracks while visual stages run',
    )
    parser_mbg.add_argument('project_dir', help='Папка проекта с transcription.json и montage_plan.json')
    parser_mbg.set_defaults(func=cmd_music_background)

    parser_mgen = subparsers.add_parser(
        'music-generate', help='Suno генерация по music_plan.json (cookie из браузера)')
    parser_mgen.add_argument('project_dir', help='Папка проекта с music_plan.json')
    parser_mgen.add_argument('--browser', default=None, help='chrome|edge|firefox|opera|brave (default из .env)')
    parser_mgen.add_argument('--model', default=None, help='Suno model: chirp-fenix|chirp-v4|chirp-v3-5')
    parser_mgen.add_argument('--parallel', type=int, default=1, help='Параллельные потоки (default 1)')
    parser_mgen.add_argument('--force', action='store_true', help='Перегенерировать существующие треки')
    parser_mgen.add_argument('--auto-concat', action='store_true',
                             help='После генерации сразу запустить video_concat.py с --music-plan')
    parser_mgen.add_argument('--concat-bitrate', default='10M', help='Битрейт для auto-concat (default 10M)')
    parser_mgen.set_defaults(func=cmd_music_generate)

    parser_mbrowser = subparsers.add_parser(
        'music-browser-generate', help='Suno генерация через видимый persistent-браузер')
    parser_mbrowser.add_argument('project_dir', help='Папка проекта с music_plan.json')
    parser_mbrowser.add_argument('--force', action='store_true', help='Перегенерировать существующие треки')
    parser_mbrowser.add_argument('--profile-dir', default=None,
                                 help='Persistent browser profile (default agent/temp/suno_browser_profile)')
    parser_mbrowser.add_argument('--headless', action='store_true', help='Скрытый браузер (после стабильного логина)')
    parser_mbrowser.add_argument('--max-tracks', type=int, default=None, help='Сгенерировать только первые N треков')
    parser_mbrowser.add_argument('--login-only', action='store_true', help='Только логин, без генерации')
    parser_mbrowser.add_argument('--login-timeout', type=int, default=300, help='Сек ожидания Suno Create UI (default 300)')
    parser_mbrowser.set_defaults(func=cmd_music_browser_generate)

    parser_mrev = subparsers.add_parser(
        'music-review', help='GUI плеер для прослушивания/настройки треков')
    parser_mrev.add_argument('project_dir', help='Папка проекта с music_plan.json и music/')
    parser_mrev.set_defaults(func=cmd_music_review)

    args = parser.parse_args()
    
    if args.command is None:
        parser.print_help()
        sys.exit(0)
    
    args.func(args)


if __name__ == '__main__':
    main()
