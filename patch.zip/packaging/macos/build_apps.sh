#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
PAYLOAD_DIR="${PAYLOAD_DIR:-$ROOT_DIR/payload}"
OUT_DIR="${OUT_DIR:-$ROOT_DIR/dist}"
ARCH="${ARCH:-$(uname -m)}"
VERSION="${VERSION:-$(date +%Y.%m.%d)}"
WORK_DIR="$OUT_DIR/work-$ARCH"
DMG_ROOT="$WORK_DIR/dmg"
LAUNCHER_APP="$WORK_DIR/VARAGENT.app"
INSTALLER_APP="$DMG_ROOT/Install VARAGENT.app"

rm -rf "$WORK_DIR"
mkdir -p "$LAUNCHER_APP/Contents/MacOS"
mkdir -p "$INSTALLER_APP/Contents/MacOS" "$INSTALLER_APP/Contents/Resources"

cat > "$LAUNCHER_APP/Contents/Info.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleName</key><string>VARAGENT</string>
<key>CFBundleDisplayName</key><string>VARAGENT</string>
<key>CFBundleIdentifier</key><string>com.varagent.desktop</string>
<key>CFBundleVersion</key><string>${VERSION}</string>
<key>CFBundleShortVersionString</key><string>${VERSION}</string>
<key>CFBundleExecutable</key><string>VARAGENT</string>
<key>LSMinimumSystemVersion</key><string>14.0</string>
<key>NSHighResolutionCapable</key><true/>
</dict></plist>
EOF
cp "$ROOT_DIR/packaging/macos/launcher.sh" "$LAUNCHER_APP/Contents/MacOS/VARAGENT"
chmod +x "$LAUNCHER_APP/Contents/MacOS/VARAGENT"

cat > "$INSTALLER_APP/Contents/Info.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleName</key><string>Install VARAGENT</string>
<key>CFBundleDisplayName</key><string>Install VARAGENT</string>
<key>CFBundleIdentifier</key><string>com.varagent.installer</string>
<key>CFBundleVersion</key><string>${VERSION}</string>
<key>CFBundleShortVersionString</key><string>${VERSION}</string>
<key>CFBundleExecutable</key><string>Install VARAGENT</string>
<key>LSMinimumSystemVersion</key><string>14.0</string>
<key>NSHighResolutionCapable</key><true/>
</dict></plist>
EOF
cp "$ROOT_DIR/packaging/macos/installer_launcher.sh" "$INSTALLER_APP/Contents/MacOS/Install VARAGENT"
cp "$ROOT_DIR/packaging/macos/install_runtime.sh" "$INSTALLER_APP/Contents/Resources/install_runtime.sh"
chmod +x "$INSTALLER_APP/Contents/MacOS/Install VARAGENT" "$INSTALLER_APP/Contents/Resources/install_runtime.sh"
/usr/bin/ditto "$PAYLOAD_DIR" "$INSTALLER_APP/Contents/Resources/payload"
/usr/bin/ditto "$LAUNCHER_APP" "$INSTALLER_APP/Contents/Resources/VARAGENT.app"

codesign --force --deep --sign - "$LAUNCHER_APP"
codesign --force --deep --sign - "$INSTALLER_APP"
codesign --verify --deep --strict "$INSTALLER_APP"

cat > "$DMG_ROOT/README FIRST.txt" <<EOF
VARAGENT for macOS ($ARCH)

1. Open "Install VARAGENT.app".
2. If macOS blocks the first launch, Control-click the app, choose Open,
   then confirm Open once. A notarized build can remove this extra step
   when Apple Developer signing credentials are configured.
3. Wait for Terminal to report INSTALLATION COMPLETE.
4. VARAGENT will be installed in ~/Applications and launched automatically.

The installer downloads Python, Python packages, Playwright Chromium,
FFmpeg, yt-dlp and Codex CLI. Internet access is required.
EOF

mkdir -p "$OUT_DIR"
DMG_PATH="$OUT_DIR/VARAGENT_macOS_${ARCH}.dmg"
rm -f "$DMG_PATH"
hdiutil create -volname "VARAGENT $ARCH" -srcfolder "$DMG_ROOT" -ov -format UDZO "$DMG_PATH"
shasum -a 256 "$DMG_PATH" > "$DMG_PATH.sha256"
echo "$DMG_PATH"
