#!/bin/bash
# Audio Inserter dependency installer for macOS.
# Installs Python packages into a local .venv so Homebrew/System Python is not modified.

set -e

echo "============================================================"
echo "  Audio Inserter - dependency install (macOS)"
echo "============================================================"
echo ""

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

chmod +x "$DIR"/*.command 2>/dev/null || true
xattr -dr com.apple.quarantine "$DIR"/*.command 2>/dev/null || true

load_brew() {
    if command -v brew >/dev/null 2>&1; then
        return 0
    fi
    if [ -x /opt/homebrew/bin/brew ]; then
        eval "$(/opt/homebrew/bin/brew shellenv)"
    elif [ -x /usr/local/bin/brew ]; then
        eval "$(/usr/local/bin/brew shellenv)"
    fi
}

ensure_brew() {
    load_brew
    if command -v brew >/dev/null 2>&1; then
        echo "Homebrew found: $(command -v brew)"
        return 0
    fi

    echo "Homebrew not found. Installing Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    load_brew

    if [ -x /opt/homebrew/bin/brew ]; then
        if ! grep -q 'brew shellenv' "$HOME/.zprofile" 2>/dev/null; then
            echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> "$HOME/.zprofile"
        fi
    elif [ -x /usr/local/bin/brew ]; then
        if ! grep -q 'brew shellenv' "$HOME/.zprofile" 2>/dev/null; then
            echo 'eval "$(/usr/local/bin/brew shellenv)"' >> "$HOME/.zprofile"
        fi
    fi
}

ffmpeg_has_overlay() {
    command -v ffmpeg >/dev/null 2>&1 && ffmpeg -hide_banner -filters 2>/dev/null | grep -qE '^[ .A-Z|]*overlay[[:space:]]'
}

python_ok() {
    "$1" -c "import tkinter, venv" >/dev/null 2>&1
}

find_python() {
    for cand in python3 /opt/homebrew/bin/python3 /usr/local/bin/python3 /usr/bin/python3; do
        if command -v "$cand" >/dev/null 2>&1; then
            py_path="$(command -v "$cand")"
            if python_ok "$py_path"; then
                echo "$py_path"
                return 0
            fi
        fi
    done
    return 1
}

install_python_tk() {
    ensure_brew
    echo "Installing Python/Tkinter with Homebrew..."
    brew install python || true
    brew install python-tk 2>/dev/null || \
        brew install python-tk@3.13 2>/dev/null || \
        brew install python-tk@3.12 2>/dev/null || \
        brew install python-tk@3.11
}

echo "[1/5] Checking ffmpeg..."
load_brew
if ! ffmpeg_has_overlay; then
    ensure_brew
    brew install ffmpeg || brew reinstall ffmpeg
    load_brew
    if ! ffmpeg_has_overlay; then
        echo "ERROR: ffmpeg was found, but the required overlay filter is missing."
        echo "Current ffmpeg: $(command -v ffmpeg 2>/dev/null || echo 'NOT FOUND')"
        echo "Try opening a new Terminal window and run install_mac.command again."
        read -p "Press Enter to close this window..." _
        exit 1
    fi
else
    echo "ffmpeg found: $(command -v ffmpeg)"
fi

echo "[2/5] Checking Python with Tkinter..."
PY="$(find_python || true)"
if [ -z "$PY" ]; then
    install_python_tk
    load_brew
    PY="$(find_python || true)"
fi

if [ -z "$PY" ]; then
    echo "ERROR: Could not find Python 3 with tkinter and venv."
    echo "Try installing Xcode Command Line Tools and rerun this file."
    read -p "Press Enter to close this window..." _
    exit 1
fi
echo "Python found: $PY"

echo "[3/5] Creating local virtual environment..."
VENV="$DIR/.venv"
if [ ! -x "$VENV/bin/python" ]; then
    "$PY" -m venv "$VENV"
fi
VPY="$VENV/bin/python"

echo "[4/5] Installing Python packages into local .venv..."
"$VPY" -m pip install --upgrade pip
if [ -f "$DIR/requirements.txt" ]; then
    "$VPY" -m pip install -r "$DIR/requirements.txt"
else
    "$VPY" -m pip install Pillow ttkbootstrap
fi

echo "[5/5] Final check..."
echo "  ffmpeg       : $(ffmpeg -version 2>/dev/null | head -1 || echo 'NOT FOUND')"
echo "  python       : $("$VPY" --version 2>/dev/null || echo 'NOT FOUND')"
echo "  tkinter      : $("$VPY" -c 'import tkinter; print(tkinter.TkVersion)' 2>/dev/null || echo 'NOT FOUND')"
echo "  Pillow       : $("$VPY" -c 'import PIL; print(PIL.__version__)' 2>/dev/null || echo 'NOT FOUND')"
echo "  ttkbootstrap : $("$VPY" -c 'import ttkbootstrap; print("OK")' 2>/dev/null || echo 'NOT FOUND')"

echo ""
echo "============================================================"
echo "  Ready. Run AudioInserter.command to start the app."
echo "============================================================"
echo ""

read -p "Press Enter to close this window..." _
