#!/bin/bash
# START_VEO_I2V.COMMAND - VeoNonStop Image-to-Video (i2v)
# Run: double-click this file in Finder

PROJECT_NAME="{project_name}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
AGENT_DIR="$(cd "$SCRIPT_DIR/../../agent" && pwd)"

chmod +x *.command *.sh 2>/dev/null

if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e "tell app \"Terminal\" to do script \"cd '$SCRIPT_DIR' && exec '$0'\""
    exit 0
fi

echo ""
echo "========================================================================"
echo "  VeoNonStop IMAGE-TO-VIDEO (i2v)"
echo "  Project: $PROJECT_NAME"
echo "========================================================================"
echo ""

# Check generated/
if [ ! -d "$SCRIPT_DIR/generated" ]; then
    echo "  [ERROR] generated/ folder not found!"
    echo "    Generate images first."
    read -p "Press Enter to close..."
    exit 1
fi

# Aspect ratio
echo "  Select aspect ratio:"
echo "    [1] 16:9   landscape, default"
echo "    [2] 9:16   portrait"
echo "    [3] 1:1    square"
echo ""
read -p "  Aspect [1/2/3] (Enter = 1): " RATIO_CHOICE
RATIO="16:9"
case "$RATIO_CHOICE" in
    2) RATIO="9:16" ;;
    3) RATIO="1:1" ;;
esac
echo "    Selected: $RATIO"
echo ""

# Parallel
read -p "  Parallel [1-24] (Enter = 12): " PARALLEL
PARALLEL="${PARALLEL:-12}"
echo "    Selected: $PARALLEL"
echo ""

# Clip IDs
read -p "  Clip IDs (e.g. 1,2,3 or Enter for all): " IDS_INPUT
IDS_ARG=""
if [ -n "$IDS_INPUT" ]; then
    IDS_ARG="--ids $IDS_INPUT"
    echo "    Clips: $IDS_INPUT"
else
    echo "    Clips: ALL"
fi
echo ""

# Prompt source
echo "  Prompt source:"
echo "    [1] Director prompts (per-clip)"
echo "    [2] Single prompt for all clips"
echo ""
read -p "  Prompt [1/2] (Enter = 1): " PROMPT_CHOICE
PROMPT_ARG=""
if [ "$PROMPT_CHOICE" = "2" ]; then
    if [ -f "${PROJECT_DIR}single_prompt.txt" ]; then
        SP_PREVIEW=$(head -1 "${PROJECT_DIR}single_prompt.txt")
        echo "    Loaded from single_prompt.txt"
        echo "    Prompt: $SP_PREVIEW"
        PROMPT_ARG="--prompt-file \"${PROJECT_DIR}single_prompt.txt\""
    else
        read -p "  Enter prompt: " PROMPT_INPUT
        if [ -n "$PROMPT_INPUT" ]; then
            echo "$PROMPT_INPUT" > "${PROJECT_DIR}single_prompt.txt"
            echo "    Saved to single_prompt.txt"
            echo "    Prompt: $PROMPT_INPUT"
            PROMPT_ARG="--prompt-file \"${PROJECT_DIR}single_prompt.txt\""
        else
            echo "    Prompt: per-clip"
        fi
    fi
else
    echo "    Prompt: per-clip"
fi
echo ""

# Confirm
echo "========================================================================"
echo "  SUMMARY:"
echo "    Project:  $PROJECT_NAME"
echo "    Mode:     i2v (image-to-video)"
echo "    Ratio:    $RATIO"
echo "    Parallel: $PARALLEL"
echo "========================================================================"
echo ""
read -p "  Start? (y/n): " CONFIRM
if [ "$CONFIRM" != "y" ] && [ "$CONFIRM" != "Y" ]; then
    echo "  Cancelled."
    exit 0
fi

echo ""
echo "  Starting image-to-video..."
echo ""

cd "$AGENT_DIR"

eval python agent.py img2video \
    --project "$PROJECT_NAME" \
    --mode "i2v" \
    --ratio "$RATIO" \
    --parallel "$PARALLEL" $IDS_ARG $PROMPT_ARG

EXIT_CODE=$?
echo ""
if [ $EXIT_CODE -ne 0 ]; then
    echo "[ERROR] i2v generation failed. See log above."
else
    echo "========================================================================"
    echo "  DONE. Output: $SCRIPT_DIR/vid_img/"
    echo "========================================================================"
fi
echo ""
read -p "Press Enter to close..."
