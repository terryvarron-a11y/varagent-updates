"""Automatic bridge between Real Photo and Extreme Picture Finder (EPF).

VarAgent owns the semantic work: Real Photo produces one web-search query for
each selected clip, EPF collects image candidates, then the configured vision
model selects one candidate and the bridge imports it into ``generated/``.
EPF is driven through its documented ``update SearchFileName=...`` CLI; no
manual project opening, phrase import, or folder selection is part of the
normal pipeline.
"""

from __future__ import annotations

import argparse
import base64
import json
import logging
import mimetypes
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

logger = logging.getLogger("ExtremePictureFinderBridge")

IMAGE_EXTENSIONS = frozenset({".jpg", ".jpeg", ".png", ".webp", ".gif", ".tif", ".tiff", ".bmp"})
DEFAULT_ENGINES = ("google", "bing")
DEFAULT_EXE = Path(r"X:\ExtremePictureFinder\App\EPF\EPF.exe")
AGENT_DIR = Path(__file__).resolve().parents[1]
if str(AGENT_DIR) not in sys.path:
    sys.path.insert(0, str(AGENT_DIR))
BUNDLED_ROOT = Path(__file__).resolve().parents[2] / "tools" / "ExtremePictureFinder"
BUNDLED_DATA_ROOT = Path(__file__).resolve().parents[2] / "epf_data"
BUNDLED_DATA_DIR = BUNDLED_DATA_ROOT / "Extreme Picture Finder"


def _bridge_event(job: Path, event: str, **fields: Any) -> None:
    """Persist bridge progress beside the EPF job and mirror it to the logger."""
    payload = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "event": event,
        **fields,
    }
    try:
        with (job / "bridge_events.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(payload, ensure_ascii=False) + "\n")
    except OSError:
        logger.debug("Unable to write EPF bridge event", exc_info=True)
    message = fields.get("message") or event
    logger.info("  [EPF] %s", message)


@dataclass(frozen=True)
class BridgeSelection:
    clip_id: int
    query: str
    local_query: str = ""
    preferred_type: str = "photo"
    confidence: str = ""


def _epf_encode(value: str) -> str:
    """Encode an EPF INI value in the format used by its native .epr files."""
    return "".join(f"%{byte:02X}" for byte in str(value).encode("utf-8"))


def _safe_clip_id(value: Any) -> int:
    clip_id = int(value)
    if clip_id < 0:
        raise ValueError(f"clip_id must be non-negative: {value!r}")
    return clip_id


def _landscape_search_query(query: str) -> str:
    """Bias image search toward landscape results without changing semantic selection."""
    normalized = query.strip()
    lowered = normalized.lower()
    if any(token in lowered for token in ("landscape", "horizontal", "widescreen", "16:9")):
        return normalized
    return f"{normalized} landscape horizontal photograph"


def _selection_dict(selection: Any) -> BridgeSelection:
    if isinstance(selection, BridgeSelection):
        return selection
    if hasattr(selection, "clip_id") and hasattr(selection, "search_query"):
        return BridgeSelection(
            clip_id=_safe_clip_id(selection.clip_id),
            query=str(selection.search_query or "").strip(),
            local_query=str(getattr(selection, "search_query_local", "") or "").strip(),
            preferred_type=str(getattr(selection, "preferred_type", "photo") or "photo"),
            confidence=str(getattr(selection, "confidence", "") or ""),
        )
    if isinstance(selection, dict):
        return BridgeSelection(
            clip_id=_safe_clip_id(selection["clip_id"]),
            query=str(selection.get("query") or selection.get("search_query") or "").strip(),
            local_query=str(
                selection.get("local_query") or selection.get("search_query_local") or ""
            ).strip(),
            preferred_type=str(selection.get("preferred_type") or "photo"),
            confidence=str(selection.get("confidence") or ""),
        )
    raise TypeError(f"Unsupported selection type: {type(selection).__name__}")


def _config_value(name: str, default: str = "") -> str:
    try:
        import config

        return str(getattr(config, name, default) or default)
    except ImportError:
        return os.getenv(name, default)


def _configured_engines(engines: Iterable[str] | str | None = None) -> list[str]:
    if engines is None:
        engines = _config_value("REAL_PHOTO_EPF_ENGINES", ",".join(DEFAULT_ENGINES))
    if isinstance(engines, str):
        engines = engines.split(",")
    result: list[str] = []
    for engine in engines:
        name = str(engine or "").strip().lower()
        if name and name not in result:
            result.append(name)
    return result or list(DEFAULT_ENGINES)


def _safe_file_token(value: str, fallback: str = "project") -> str:
    token = re.sub(r"[^a-zA-Z0-9_-]+", "_", value).strip("_").lower()
    return token[:42] or fallback


def _epf_root(executable: Path) -> Path:
    """Return the portable root for either launcher or core executable."""
    if executable.name.lower() == "expicturefinderportable.exe":
        return executable.parent
    if executable.parent.name.lower() == "epf" and executable.parent.parent.name.lower() == "app":
        return executable.parent.parent.parent
    return executable.parent


def resolve_epf_install(
    executable: str | Path | None = None,
    data_dir: str | Path | None = None,
) -> tuple[Path, Path]:
    """Resolve the EPF portable launcher and its private data directory."""
    if os.name != "nt":
        raise OSError("Extreme Picture Finder integration is available only on Windows")
    configured_exe = str(executable or _config_value("REAL_PHOTO_EPF_EXE", "")).strip()
    candidates = [Path(configured_exe)] if configured_exe else []
    candidates.extend([
        BUNDLED_ROOT / "App" / "EPF" / "EPF.exe",
        DEFAULT_EXE,
        Path("EPF.exe"),
    ])

    epf_exe: Path | None = None
    for candidate in candidates:
        if candidate.name.lower() == "expicturefinderportable.exe":
            core = candidate.parent / "App" / "EPF" / "EPF.exe"
            if core.is_file():
                candidate = core
        if candidate.is_file():
            epf_exe = candidate.resolve()
            break
    if epf_exe is None:
        raise FileNotFoundError(
            "Extreme Picture Finder executable not found. Set REAL_PHOTO_EPF_EXE "
            "to App\\EPF\\EPF.exe or install the verified bundle from VarAgent."
        )

    configured_data = str(data_dir or _config_value("REAL_PHOTO_EPF_DATA_DIR", "")).strip()
    data_candidates = [Path(configured_data)] if configured_data else []
    data_candidates.append(BUNDLED_DATA_DIR)
    data_candidates.append(_epf_root(epf_exe) / "Settings" / "Extreme Picture Finder")

    epf_data: Path | None = None
    for candidate in data_candidates:
        if candidate.is_dir():
            epf_data = candidate.resolve()
            break
    if epf_data is None:
        raise FileNotFoundError(
            "Extreme Picture Finder data directory not found. Set "
            "REAL_PHOTO_EPF_DATA_DIR to the folder containing Searches and Data."
        )
    return epf_exe, epf_data


def _available_engines(data_dir: Path) -> set[str]:
    path = data_dir / "searchengines.dat"
    if not path.exists():
        return set()
    text = path.read_text(encoding="utf-8", errors="replace")
    return {
        match.group(1).strip().lower()
        for match in re.finditer(r"(?m)^\[([^\]]+)\]\s*$", text)
    }


def _ensure_search_engines(epf_exe: Path, data_dir: Path) -> set[str]:
    """Bootstrap a missing global engine list from the installed portable copy."""
    destination = data_dir / "searchengines.dat"
    if not destination.exists():
        root = _epf_root(epf_exe)
        sources = [
            root / "Settings" / "Extreme Picture Finder" / "searchengines.dat",
            root / "App" / "DefaultData" / "Extreme Picture Finder" / "searchengines.dat",
        ]
        source = next((path for path in sources if path.is_file()), None)
        if source is not None:
            data_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
            logger.info("[EPF bridge] Installed missing searchengines.dat from %s", source)
    return _available_engines(data_dir)


def _native_search_epr(
    *,
    query: str,
    destination: Path,
    data_file_name: str,
    title: str,
    engines: Iterable[str],
    max_files: int,
) -> str:
    """Create a native EPF search .epr, including phrase and engine sections."""
    engine_rows = [f"Engine{index:03d}={engine}" for index, engine in enumerate(engines)]
    return "\n".join(
        [
            "[Settings]",
            "AcceptCookies=True",
            "AfterCompleteAction=acaNone",
            "AfterCompleteExportFileList=False",
            "AfterCompleteExportFileListAddHeaderRow=False",
            "AfterCompleteExportFileListCustomSeparator=%7C",
            "AfterCompleteExportFileListFileName=",
            "AfterCompleteExportFileListMode=200",
            "AfterCompleteExportFileListSearchOnlyExisting=True",
            "AfterCompleteExportFileListSeparator=100",
            "AfterCompleteProject=",
            "AfterCompleteProjectStartType=stResume",
            "AllowRedirectBackToParent=False",
            "AutoContinueDownloadSeconds=1",
            "AutoContinueDownloadType=acdSeconds",
            "AutoContinueDownloadURLRE=",
            "AutoContinueManualLogin=False",
            "Completed=False",
            "ConflictsRenameNumberOfDigits=3",
            "DatabaseCategoryID=0",
            "DatabaseCategoryName=",
            "DatabaseID=0",
            f"DataFileName={_epf_encode(data_file_name)}",
            "DefaultRefererCustomText=",
            "DefaultRefererType=hrtNatural",
            f"DestinationFolder={_epf_encode(str(destination.resolve()))}",
            "DownloadTargetFilesFromExternalSites=True",
            "ExplorationDepth=2",
            "ExplorationLimit=selEntireSite",
            "ExplorationType=setRegular",
            "FolderForEachSearchEngine=False",
            "FolderForEachSearchPhrase=False",
            "ForceFileExt=False",
            "ManualLogin=False",
            "ManualLoginMessage=",
            "MaxDelayBetweenDownloads=4",
            "MaxFileDate=46242,1900847917",
            "MaxFileSizeLimit=30",
            "MaxFileSizeUnit=fsuMB",
            "MaxImageHeight=4096",
            "MaxImageWidth=4096",
            f"MaxSearchResNumber={max_files}",
            "MinDelayBetweenDownloads=1",
            "MinFileDate=46242,1900847917",
            "MinFileSizeLimit=10",
            "MinFileSizeUnit=fsuKB",
            "MinImageHeight=256",
            "MinImageWidth=256",
            "NamingParentPageTitleURLRE=",
            "NamingRemoveCharsEnd=False",
            "NamingRemoveCharsEndNum=5",
            "NamingRemoveCharsStart=False",
            "NamingRemoveCharsStartNum=5",
            "NamingTagAttributeName=",
            "PageCustomParsersAddedURLsPosition=aupBefore",
            "PageCustomParsersAddedURLsType=autNone",
            "PartiallyDownloadedFilesCount=0",
            "Password=",
            "ProcessedAddresses=0",
            "ReplaceSlashesInSubFolders=False",
            "ResolveNamingConflictsType=rncRename",
            "SafeSearch=True",
            "SaveDigitsStartFrom=0",
            "SavedTargetFiles=0",
            "SaveExt=",
            "SaveNamingType=sntOriginal",
            "SaveNumberOfDigits=3",
            "SavePrefix=",
            "SaveQueryStringParamName=",
            "SaveSuffix=",
            "SearchMode=smOnlyImages",
            f"StopAfterFileNumber={max_files}",
            "StopAfterFileSizeMB=10",
            "StopAfterTimeMinutes=60",
            "StopAtTime=23:59",
            "SubFoldersAddTextEnd=False",
            "SubFoldersAddTextStart=False",
            "SubFoldersEndText=",
            "SubFoldersFileNum=200",
            "SubFoldersMode=sfmNone",
            "SubFoldersPageTitleURLRE=",
            "SubFoldersRemoveCharsEnd=False",
            "SubFoldersRemoveCharsEndNum=5",
            "SubFoldersReplaceSlashesWith=%2D",
            "SubFoldersStartingURLAddDomain=True",
            "SubFoldersStartingURLAddFullURL=False",
            "SubFoldersStartingURLAddNum=True",
            "SubFoldersTargetFileAddDomain=True",
            "SubFoldersWebsiteFoldersAddDocument=False",
            "SubFoldersWebsiteFoldersAddDomain=False",
            "SuggestedSimultaneousConnections=0",
            "TemplateFileName=",
            "TGPGalleryTitleContains=",
            "TGPGalleryURLContains=",
            "TGPMaxPageDepth=4",
            "TGPMaxTargetFileDepth=5",
            f"Title={_epf_encode(title)}",
            "UseAfterCompleteSound=False",
            "UseExplorationDepth=True",
            "UseMaxFileDate=False",
            "UseMaxFileSizeLimit=True",
            "UseMaxImageHeight=True",
            "UseMaxImageWidth=True",
            "UseMinFileDate=False",
            "UseMinFileSizeLimit=True",
            "UseMinImageHeight=True",
            "UseMinImageWidth=True",
            "UseQueryStringParam=False",
            "UserAgent=",
            "UseRandomDelayBetweenDownloads=False",
            "Username=",
            "UseSavePrefix=False",
            "UseSaveSuffix=False",
            "UseStopAfterFileNumber=True",
            "UseStopAfterFileSizeMB=False",
            "UseStopAfterTime=False",
            "UseStopAtTime=False",
            "",
            "[SearchPhrases]",
            f"Phrase00000={_epf_encode(query)}",
            "",
            "[TargetFiles]",
            "File000=*.jp*",
            "File001=*.pn*",
            "File002=*.webp",
            "File003=*.gif",
            "File004=*.bmp",
            "",
            "[SearchEngines]",
            *engine_rows,
            "",
            "[ExportColumns]",
            "Column000=100",
            "Column001=102",
            "",
        ]
    )


def create_job(
    project_dir: str | Path,
    selections: Iterable[Any],
    *,
    destination_root: str | Path | None = None,
    max_files_per_clip: int = 12,
    register_with_epf: bool = False,
    epf_executable: str | Path | None = None,
    epf_data_dir: str | Path | None = None,
    engines: Iterable[str] | str | None = None,
) -> Path:
    """Create a traceable bridge job and optionally register native EPF searches."""
    project = Path(project_dir).resolve()
    if not project.is_dir():
        raise FileNotFoundError(project)
    if max_files_per_clip < 1:
        raise ValueError("max_files_per_clip must be positive")

    epf_exe: Path | None = None
    epf_data: Path | None = None
    selected_engines = _configured_engines(engines)
    if register_with_epf:
        epf_exe, epf_data = resolve_epf_install(epf_executable, epf_data_dir)
        available = _ensure_search_engines(epf_exe, epf_data)
        missing = [engine for engine in selected_engines if engine not in available]
        selected_engines = [engine for engine in selected_engines if engine in available]
        if missing:
            logger.warning("[EPF bridge] Unavailable engines ignored: %s", ", ".join(missing))
        if not selected_engines:
            raise RuntimeError(
                f"EPF has no configured requested engines in {epf_data / 'searchengines.dat'}"
            )

    run_token = datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:6]
    job_dir = project / "_real_photo_work" / "extreme_picture_finder" / run_token
    job_dir.mkdir(parents=True, exist_ok=True)
    destination = Path(destination_root).resolve() if destination_root else job_dir / "downloads"
    destination.mkdir(parents=True, exist_ok=True)
    project_token = _safe_file_token(project.name)

    normalized: list[dict[str, Any]] = []
    for raw in selections:
        item = _selection_dict(raw)
        if not item.query:
            logger.warning("Skipping clip %s with empty Real Photo query", item.clip_id)
            continue
        clip_dir = job_dir / f"clip_{item.clip_id:03d}"
        download_dir = destination / f"clip_{item.clip_id:03d}"
        clip_dir.mkdir(parents=True, exist_ok=True)
        download_dir.mkdir(parents=True, exist_ok=True)

        search_stem = f"varagent_{project_token}_{item.clip_id:03d}_{uuid.uuid4().hex[:8]}"
        search_file_name = f"{search_stem}.epr"
        data_file_name = f"{search_stem}.dat"
        title = f"VarAgent | {project.name} | clip {item.clip_id:03d}"
        epf_query = _landscape_search_query(item.query)
        epr_text = _native_search_epr(
            query=epf_query,
            destination=download_dir,
            data_file_name=data_file_name,
            title=title,
            engines=selected_engines,
            max_files=max_files_per_clip,
        )
        local_epr = clip_dir / "project.epr"
        local_epr.write_text(epr_text, encoding="utf-8")
        (clip_dir / "search_phrase.txt").write_text(item.query + "\n", encoding="utf-8")
        if item.local_query and item.local_query != item.query:
            (clip_dir / "search_phrase_local.txt").write_text(
                item.local_query + "\n", encoding="utf-8"
            )

        epf_search_path = None
        if epf_data is not None:
            epf_search_path = epf_data / "Searches" / search_file_name
            epf_search_path.parent.mkdir(parents=True, exist_ok=True)
            epf_search_path.write_text(epr_text, encoding="utf-8")

        normalized.append(
            {
                **asdict(item),
                "epf_query": epf_query,
                "clip_dir": str(clip_dir),
                "download_dir": str(download_dir),
                "max_files": max_files_per_clip,
                "source": "extreme_picture_finder",
                "license": "unknown",
                "epf_search_file": search_file_name if epf_search_path else "",
                "epf_search_path": str(epf_search_path) if epf_search_path else "",
                "epf_data_file": data_file_name,
            }
        )

    manifest = {
        "version": 2,
        "backend": "extreme_picture_finder",
        "automatic": bool(register_with_epf),
        "project": project.name,
        "project_dir": str(project),
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "destination_root": str(destination),
        "epf_executable": str(epf_exe) if epf_exe else "",
        "epf_data_dir": str(epf_data) if epf_data else "",
        "engines": selected_engines,
        "items": normalized,
    }
    (job_dir / "bridge_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return job_dir


def _valid_downloads(download_dir: Path) -> list[Path]:
    return sorted(
        (
            path
            for path in download_dir.rglob("*")
            if path.is_file()
            and path.suffix.lower() in IMAGE_EXTENSIONS
            and path.stat().st_size >= 10 * 1024
        ),
        key=lambda path: (-path.stat().st_size, path.name.lower()),
    )


def _epr_is_completed(path: Path) -> bool:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False
    match = re.search(r"(?mi)^Completed=(.+?)\s*$", text)
    return bool(match and match.group(1).strip().lower() == "true")


def _set_epf_runtime_paths(epf_exe: Path, data_dir: Path) -> dict[str, tuple[Any, int] | None]:
    """Temporarily point EPF at VarAgent-owned data without requiring UAC."""
    if os.name != "nt":
        return {}
    import winreg

    key_path = r"SOFTWARE\Extreme Internet Software\Extreme Picture Finder 3\Settings"
    previous: dict[str, tuple[Any, int] | None] = {}
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path) as key:
        for name in ("DataDir", "InstallDir"):
            try:
                previous[name] = winreg.QueryValueEx(key, name)
            except FileNotFoundError:
                previous[name] = None
        winreg.SetValueEx(key, "DataDir", 0, winreg.REG_SZ, str(data_dir.resolve()))
        winreg.SetValueEx(key, "InstallDir", 0, winreg.REG_SZ, str(epf_exe.parent.resolve()))
    return previous


def _restore_epf_runtime_paths(previous: dict[str, tuple[Any, int] | None]) -> None:
    if os.name != "nt" or not previous:
        return
    import winreg

    key_path = r"SOFTWARE\Extreme Internet Software\Extreme Picture Finder 3\Settings"
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path) as key:
        for name, saved in previous.items():
            if saved is None:
                try:
                    winreg.DeleteValue(key, name)
                except FileNotFoundError:
                    pass
            else:
                value, value_type = saved
                winreg.SetValueEx(key, name, 0, value_type, value)


def _stop_epf_process(process: subprocess.Popen | None) -> None:
    if process is None or process.poll() is not None:
        return
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)


def _launch_search(
    epf_exe: Path,
    data_dir: Path,
    search_file_name: str,
    *,
    item: dict[str, Any],
) -> tuple[subprocess.Popen, dict[str, tuple[Any, int] | None]]:
    if not search_file_name:
        raise RuntimeError("EPF search file was not registered")
    startupinfo = None
    creationflags = 0
    if os.name == "nt":
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = 0
        creationflags = 0x08000000
    clip_dir = Path(item.get("clip_dir") or Path(item["epf_search_path"]).parent)
    stdout_path = clip_dir / "epf_stdout.log"
    stderr_path = clip_dir / "epf_stderr.log"
    command = (
        f'"{epf_exe}" update '
        f'SearchFileName="{search_file_name}"'
    )
    previous = _set_epf_runtime_paths(epf_exe, data_dir)
    try:
        with stdout_path.open("ab") as stdout, stderr_path.open("ab") as stderr:
            process = subprocess.Popen(
                command,
                cwd=str(epf_exe.parent),
                stdin=subprocess.DEVNULL,
                stdout=stdout,
                stderr=stderr,
                env=os.environ.copy(),
                startupinfo=startupinfo,
                creationflags=creationflags,
            )
        return process, previous
    except Exception:
        _restore_epf_runtime_paths(previous)
        raise


def _wait_for_search(
    item: dict[str, Any],
    *,
    timeout_sec: int,
    stop_event=None,
    deadline_ts: float | None = None,
    poll_sec: float = 1.5,
    process: subprocess.Popen | None = None,
    progress_callback=None,
) -> dict[str, Any]:
    search_path = Path(item["epf_search_path"])
    started = time.monotonic()
    last_report = -10.0
    while True:
        candidates = _valid_downloads(Path(item["download_dir"]))
        elapsed = time.monotonic() - started
        if progress_callback is not None and elapsed - last_report >= 10:
            progress_callback(
                candidates=len(candidates),
                elapsed_sec=round(elapsed, 1),
                process_returncode=process.poll() if process is not None else None,
            )
            last_report = elapsed
        if _epr_is_completed(search_path):
            return {
                "clip_id": _safe_clip_id(item["clip_id"]),
                "status": "completed",
                "candidates": len(candidates),
                "elapsed_sec": round(elapsed, 1),
                "process_returncode": process.poll() if process is not None else None,
            }
        if stop_event is not None and stop_event.is_set():
            return {
                "clip_id": _safe_clip_id(item["clip_id"]),
                "status": "stopped",
                "candidates": len(candidates),
                "elapsed_sec": round(elapsed, 1),
            }
        if deadline_ts is not None and time.time() >= deadline_ts:
            return {
                "clip_id": _safe_clip_id(item["clip_id"]),
                "status": "deadline",
                "candidates": len(candidates),
                "elapsed_sec": round(elapsed, 1),
            }
        if elapsed >= timeout_sec:
            return {
                "clip_id": _safe_clip_id(item["clip_id"]),
                "status": "timeout",
                "candidates": len(candidates),
                "elapsed_sec": round(elapsed, 1),
                "process_returncode": process.poll() if process is not None else None,
            }
        time.sleep(poll_sec)


def run_job(
    job_dir: str | Path,
    *,
    provider: str | None = None,
    model: str | None = None,
    timeout_sec: int | None = None,
    stop_event=None,
    deadline_ts: float | None = None,
) -> dict[str, Any]:
    """Run native EPF searches, select candidates with vision, and import images."""
    job = Path(job_dir).resolve()
    manifest_path = job / "bridge_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not manifest.get("automatic"):
        raise RuntimeError("Job was not registered with EPF and cannot run automatically")

    epf_exe = Path(manifest["epf_executable"])
    if not epf_exe.is_file():
        raise FileNotFoundError(f"EPF executable missing: {epf_exe}")
    epf_data_dir = Path(manifest["epf_data_dir"])
    if not epf_data_dir.is_dir():
        raise FileNotFoundError(f"EPF data directory missing: {epf_data_dir}")
    per_search_timeout = max(
        30,
        int(timeout_sec or _config_value("REAL_PHOTO_EPF_SEARCH_TIMEOUT", "180") or 180),
    )
    _bridge_event(
        job,
        "job_started",
        items=len(manifest.get("items", [])),
        timeout_sec=per_search_timeout,
        epf_executable=str(epf_exe),
        message=(
            f"automatic job started: {len(manifest.get('items', []))} clips, "
            f"{per_search_timeout}s timeout per clip"
        ),
    )
    search_results: list[dict[str, Any]] = []
    for index, item in enumerate(manifest.get("items", []), 1):
        clip_id = _safe_clip_id(item["clip_id"])
        if stop_event is not None and stop_event.is_set():
            search_results.append({"clip_id": clip_id, "status": "stopped", "candidates": 0})
            continue
        if deadline_ts is not None and time.time() >= deadline_ts:
            search_results.append({"clip_id": clip_id, "status": "deadline", "candidates": 0})
            continue
        logger.info(
            "  [EPF %s/%s] clip %03d: %s",
            index,
            len(manifest["items"]),
            clip_id,
            item["query"],
        )
        process = None
        registry_snapshot: dict[str, tuple[Any, int] | None] = {}
        try:
            process, registry_snapshot = _launch_search(
                epf_exe,
                epf_data_dir,
                str(item["epf_search_file"]),
                item=item,
            )
            _bridge_event(
                job,
                "search_started",
                clip_id=clip_id,
                index=index,
                total=len(manifest["items"]),
                pid=process.pid,
                command=[
                    str(epf_exe),
                    "update",
                    f'SearchFileName="{item["epf_search_file"]}"',
                ],
                message=f"clip {clip_id:03d}: EPF update started (pid {process.pid})",
            )

            def _report_progress(**fields):
                return_code = fields.get("process_returncode")
                process_state = "running" if return_code is None else f"exit {return_code}"
                _bridge_event(
                    job,
                    "search_progress",
                    clip_id=clip_id,
                    message=(
                        f"clip {clip_id:03d}: waiting {fields.get('elapsed_sec', 0):.1f}s, "
                        f"{fields.get('candidates', 0)} candidates, EPF {process_state}"
                    ),
                    **fields,
                )

            result = _wait_for_search(
                item,
                timeout_sec=per_search_timeout,
                stop_event=stop_event,
                deadline_ts=deadline_ts,
                process=process,
                progress_callback=_report_progress,
            )
        except Exception as exc:
            logger.warning("  [EPF] clip %03d failed: %s", clip_id, exc)
            result = {"clip_id": clip_id, "status": "launch_failed", "error": str(exc), "candidates": 0}
        finally:
            _stop_epf_process(process)
            _restore_epf_runtime_paths(registry_snapshot)
        search_results.append(result)
        logger.info(
            "  [EPF] clip %03d: %s (%s candidates)",
            clip_id,
            result["status"],
            result.get("candidates", 0),
        )
        _bridge_event(
            job,
            "search_finished",
            message=(
                f"clip {clip_id:03d}: {result['status']}, "
                f"{result.get('candidates', 0)} candidates"
            ),
            **result,
        )

    _bridge_event(
        job,
        "vision_started",
        provider=provider or "",
        model=model or "",
        message=f"vision selection started: {provider or 'configured provider'} / {model or 'configured model'}",
    )
    vision = select_job_with_vision(job, provider=provider, model=model)
    _bridge_event(job, "vision_finished", message="vision selection finished", **vision)
    ingested = ingest_job(job)
    _bridge_event(
        job,
        "ingest_finished",
        message=f"import finished: {ingested.get('ingested', 0)} images",
        **ingested,
    )
    summary = {
        "backend": "extreme_picture_finder",
        "job_dir": str(job),
        "searches": search_results,
        "vision": vision,
        "ingest": ingested,
        "ingested": ingested.get("ingested", 0),
    }
    (job / "automatic_result.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return summary


def run_automatic_job(
    project_dir: str | Path,
    selections: Iterable[Any],
    *,
    provider: str | None = None,
    model: str | None = None,
    max_files_per_clip: int | None = None,
    timeout_sec: int | None = None,
    stop_event=None,
    deadline_ts: float | None = None,
) -> dict[str, Any]:
    """Create and execute an EPF bridge job in one automatic pipeline call."""
    max_files = max(
        1,
        int(max_files_per_clip or _config_value("REAL_PHOTO_EPF_CANDIDATES", "12") or 12),
    )
    job = create_job(
        project_dir,
        selections,
        max_files_per_clip=max_files,
        register_with_epf=True,
    )
    return run_job(
        job,
        provider=provider,
        model=model,
        timeout_sec=timeout_sec,
        stop_event=stop_event,
        deadline_ts=deadline_ts,
    )


def _vision_image_data(path: Path, *, max_bytes: int = 60 * 1024) -> str:
    """Return a compact data URI suitable for multimodal chat APIs."""
    raw = path.read_bytes()
    mime = mimetypes.guess_type(path.name)[0] or "image/jpeg"
    try:
        from io import BytesIO

        from PIL import Image

        with Image.open(path) as image:
            image = image.convert("RGB")
            image.thumbnail((640, 640))
            for quality in (72, 62, 52, 42, 34):
                stream = BytesIO()
                image.save(stream, format="JPEG", quality=quality, optimize=True)
                raw = stream.getvalue()
                if len(raw) <= max_bytes:
                    break
            if len(raw) > max_bytes:
                image.thumbnail((448, 448))
                stream = BytesIO()
                image.save(stream, format="JPEG", quality=38, optimize=True)
                raw = stream.getvalue()
            mime = "image/jpeg"
    except Exception:
        pass
    return f"data:{mime};base64,{base64.b64encode(raw).decode('ascii')}"


def _image_dimensions(path: Path) -> tuple[int, int]:
    try:
        from PIL import Image

        with Image.open(path) as image:
            return image.size
    except Exception:
        return 0, 0


def _candidate_label(path: Path) -> str:
    width, height = _image_dimensions(path)
    if width and height:
        orientation = "landscape" if width >= height else "portrait"
        return f"{path.name} ({width}x{height}, {orientation})"
    return path.name


def _parse_selection(text: str, candidates: list[Path]) -> str:
    """Extract a selected filename from a strict JSON vision response."""
    payload = text.strip()
    if "```" in payload:
        payload = payload.replace("```json", "").replace("```", "").strip()
    data = json.loads(payload)
    chosen = str(data.get("file") or "").strip()
    names = {path.name: path for path in candidates}
    if chosen not in names:
        raise ValueError(f"vision selector returned unknown file: {chosen!r}")
    return chosen


def select_job_with_vision(
    job_dir: str | Path,
    *,
    provider: str | None = None,
    model: str | None = None,
) -> dict[str, Any]:
    """Ask the configured vision LLM to choose one EPF candidate per clip."""
    job = Path(job_dir).resolve()
    manifest = json.loads((job / "bridge_manifest.json").read_text(encoding="utf-8"))
    provider = (provider or _config_value("REAL_PHOTO_VISION_PROVIDER", "gemini")).strip().lower()
    model = (model or _config_value("REAL_PHOTO_VISION_MODEL", "gemini-2.5-flash")).strip()
    results: list[dict[str, Any]] = []

    for item in manifest.get("items", []):
        clip_id = _safe_clip_id(item["clip_id"])
        candidates = _valid_downloads(Path(item["download_dir"]))[:12]
        if not candidates:
            results.append({"clip_id": clip_id, "status": "no_download"})
            continue
        per_image_budget = max(24 * 1024, (520 * 1024) // len(candidates))
        prompt = (
            "Choose the single best real photograph for this video clip. "
            "Match the image to the search query. Prefer a real subject and a clear, "
            "high-resolution composition. Strongly prefer a landscape/horizontal image "
            "when relevance and quality are comparable. Reject logos, thumbnails, screenshots, "
            "watermarks, icons, AI art, and unrelated results. "
            f"Search query: {item['query']}\n"
            "Images are labeled by filename. Return JSON only: "
            '{"file":"exact_filename","reason":"brief reason"}'
        )
        try:
            if provider == "claude_code":
                from modules.claude_code_runner import ClaudeCodeRunner

                clip_dir = job / f"clip_{clip_id:03d}"
                result_file = clip_dir / "claude_vision_selection.json"
                result_file.unlink(missing_ok=True)
                candidate_lines = "\n".join(
                    f"- {_candidate_label(path)}: {path.resolve().as_posix()}"
                    for path in candidates
                )
                task_file = clip_dir / "_claude_vision_task.md"
                task_file.write_text(
                    (
                        "Use the Read tool to inspect every image listed below. "
                        "Choose the single image that best matches the search query. "
                        "Prefer a real subject, clear composition, and useful resolution. "
                        "Reject logos, thumbnails, screenshots, watermarks, icons, AI art, "
                        "and unrelated results.\n\n"
                        f"Search query: {item['query']}\n\n"
                        f"Candidates:\n{candidate_lines}\n\n"
                        "Write strict JSON only to this exact file:\n"
                        f"{result_file.resolve().as_posix()}\n\n"
                        'Schema: {"file":"exact_filename","reason":"brief reason"}\n'
                        "The file field must contain only one filename from the list."
                    ),
                    encoding="utf-8",
                )
                runner = ClaudeCodeRunner(model_name=model, timeout=300)
                returncode, stdout, stderr, _elapsed = runner.run_task_file(
                    task_file,
                    clip_dir,
                    label=f"epf_vision_{clip_id}",
                )
                if returncode != 0:
                    raise RuntimeError(
                        f"Claude Code vision failed (exit {returncode}): "
                        f"{stderr[-500:] or stdout[-500:]}"
                    )
                if not result_file.exists():
                    raise RuntimeError("Claude Code did not create the vision result JSON")
                text = result_file.read_text(encoding="utf-8-sig", errors="replace")
            elif provider == "gemini":
                from google import genai
                import config

                key = getattr(config, "VISION_API_KEY", "") or getattr(config, "GEMINI_API_KEY", "")
                if not key:
                    raise RuntimeError("Gemini vision key is not configured")
                parts = [{"text": prompt}]
                for path in candidates:
                    parts.append({"text": f"Filename: {_candidate_label(path)}"})
                    parts.append(
                        {
                            "inline_data": {
                                "mime_type": "image/jpeg",
                                "data": _vision_image_data(
                                    path, max_bytes=per_image_budget
                                ).split(",", 1)[1],
                            }
                        }
                    )
                response = genai.Client(api_key=key).models.generate_content(
                    model=model,
                    contents=[{"parts": parts}],
                )
                text = response.text or ""
            else:
                from modules.chat_client import chat_completion

                content: list[dict[str, Any]] = [{"type": "text", "text": prompt}]
                for path in candidates:
                    content.append({"type": "text", "text": f"Filename: {_candidate_label(path)}"})
                    content.append(
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": _vision_image_data(
                                    path, max_bytes=per_image_budget
                                )
                            },
                        }
                    )
                text = chat_completion(
                    provider,
                    model,
                    [{"role": "user", "content": content}],
                    max_tokens=300,
                    json_mode=True,
                    timeout=300,
                )
            chosen = _parse_selection(text, candidates)
            selection_path = job / f"clip_{clip_id:03d}" / "selected.json"
            selection_path.write_text(
                json.dumps(
                    {"file": chosen, "provider": provider, "model": model, "raw": text},
                    ensure_ascii=False,
                    indent=2,
                ),
                encoding="utf-8",
            )
            results.append({"clip_id": clip_id, "status": "selected", "file": chosen})
        except Exception as exc:
            logger.warning("Vision selection failed for clip %s: %s", clip_id, exc)
            results.append({"clip_id": clip_id, "status": "selection_failed", "error": str(exc)})

    result = {
        "backend": "extreme_picture_finder",
        "provider": provider,
        "model": model,
        "results": results,
    }
    (job / "vision_selection_result.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return result


def _render_contained_landscape(source: Path, target: Path) -> dict[str, Any]:
    """Render a full uncropped image over a blurred 16:9 background."""
    from PIL import Image, ImageEnhance, ImageFilter, ImageOps

    frame_size = (1920, 1080)
    with Image.open(source) as opened:
        image = ImageOps.exif_transpose(opened).convert("RGB")
        original_size = image.size
        background = ImageOps.fit(image, frame_size, method=Image.Resampling.LANCZOS)
        background = background.filter(ImageFilter.GaussianBlur(radius=32))
        background = ImageEnhance.Brightness(background).enhance(0.55)
        foreground = ImageOps.contain(image, frame_size, method=Image.Resampling.LANCZOS)
        x = (frame_size[0] - foreground.width) // 2
        y = (frame_size[1] - foreground.height) // 2
        background.paste(foreground, (x, y))
        background.save(target, format="JPEG", quality=94, optimize=True, subsampling=0)
    return {
        "original_width": original_size[0],
        "original_height": original_size[1],
        "output_width": frame_size[0],
        "output_height": frame_size[1],
        "fit_mode": "contain_blur",
    }


def ingest_job(job_dir: str | Path, *, replace: bool = False) -> dict[str, Any]:
    """Import vision-selected EPF files into ``generated/{id:03d}``."""
    job = Path(job_dir).resolve()
    manifest_path = job / "bridge_manifest.json"
    if not manifest_path.exists():
        raise FileNotFoundError(manifest_path)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    project = Path(manifest["project_dir"]) if manifest.get("project_dir") else job.parents[3]
    generated = project / "generated"
    generated.mkdir(parents=True, exist_ok=True)

    results: list[dict[str, Any]] = []
    for item in manifest.get("items", []):
        clip_id = _safe_clip_id(item["clip_id"])
        source_dir = Path(item["download_dir"])
        candidates = _valid_downloads(source_dir)
        if not candidates:
            results.append({"clip_id": clip_id, "status": "no_download"})
            continue
        selection_path = job / f"clip_{clip_id:03d}" / "selected.json"
        selected_file: Path | None = None
        if selection_path.exists():
            selected_data = json.loads(selection_path.read_text(encoding="utf-8"))
            raw_selected = str(selected_data.get("file") or "").strip()
            if raw_selected:
                selected_file = Path(raw_selected)
                if not selected_file.is_absolute():
                    download_path = (source_dir / selected_file).resolve()
                    local_path = (selection_path.parent / selected_file).resolve()
                    selected_file = download_path if download_path.exists() else local_path
        if selected_file is None or selected_file not in candidates:
            results.append(
                {
                    "clip_id": clip_id,
                    "status": "awaiting_selection",
                    "candidates": [str(path) for path in candidates],
                    "selection_file": str(selection_path),
                }
            )
            continue
        target = generated / f"{clip_id:03d}.jpg"
        existing = list(generated.glob(f"{clip_id:03d}.*"))
        if existing and not replace:
            results.append({"clip_id": clip_id, "status": "exists", "file": str(existing[0])})
            continue
        for old in existing:
            old.unlink()
        render_info = _render_contained_landscape(selected_file, target)
        results.append(
            {
                "clip_id": clip_id,
                "status": "ingested",
                "file": str(target),
                "source_file": str(selected_file),
                "license": "unknown",
                **render_info,
            }
        )

    summary = {
        "backend": "extreme_picture_finder",
        "project": project.name,
        "generated_dir": str(generated),
        "results": results,
        "ingested": sum(result["status"] == "ingested" for result in results),
        "missing": sum(
            result["status"] in {"no_download", "awaiting_selection"} for result in results
        ),
        "awaiting_selection": sum(
            result["status"] == "awaiting_selection" for result in results
        ),
    }
    (job / "ingest_result.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return summary


def _cli() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    create = sub.add_parser("create-job")
    create.add_argument("project_dir")
    create.add_argument("selections_json")
    create.add_argument("--register", action="store_true")
    run = sub.add_parser("run")
    run.add_argument("job_dir")
    run.add_argument("--provider", default=None)
    run.add_argument("--model", default=None)
    run.add_argument("--timeout", type=int, default=None)
    ingest = sub.add_parser("ingest")
    ingest.add_argument("job_dir")
    ingest.add_argument("--replace", action="store_true")
    select = sub.add_parser("select")
    select.add_argument("job_dir")
    select.add_argument("--provider", default=None)
    select.add_argument("--model", default=None)
    args = parser.parse_args()

    if args.command == "create-job":
        data = json.loads(Path(args.selections_json).read_text(encoding="utf-8"))
        print(create_job(args.project_dir, data, register_with_epf=args.register))
    elif args.command == "run":
        print(
            json.dumps(
                run_job(args.job_dir, provider=args.provider, model=args.model, timeout_sec=args.timeout),
                ensure_ascii=False,
                indent=2,
            )
        )
    elif args.command == "ingest":
        print(json.dumps(ingest_job(args.job_dir, replace=args.replace), ensure_ascii=False, indent=2))
    else:
        print(
            json.dumps(
                select_job_with_vision(args.job_dir, provider=args.provider, model=args.model),
                ensure_ascii=False,
                indent=2,
            )
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli())
