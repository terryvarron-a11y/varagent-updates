#!/bin/bash
# PROCESS_1080P_INTERACTIVE.COMMAND - Video concat 1080p interactive (macOS - double click)
# Run: double-click this file in Finder

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Auto-set execute permissions
chmod +x *.command *.sh 2>/dev/null

# Open Terminal.app for interactive mode
if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e "tell app \"Terminal\" to do script \"cd '$SCRIPT_DIR' && exec '$0'\""
    exit 0
fi

clear

echo ""
echo "================================================================================"
echo "CONCAT 1080p (with re-encoding) - INTERACTIVE"
echo "================================================================================"
echo ""

# Check montage_plan.json
if [ ! -f "montage_plan.json" ]; then
    echo "[ERROR] montage_plan.json not found!"
    echo "Press Enter to exit..."
    read
    exit 1
fi

# Find audio file
AUDIO_FILE=""
for EXT in wav mp3 flac m4a aac; do
    for F in *.$EXT; do
        [ -f "$F" ] && AUDIO_FILE="$F" && break 2
    done
done

if [ -z "$AUDIO_FILE" ]; then
    echo "[ERROR] Audio file not found!"
    echo "   Put .wav, .mp3, .flac, .m4a or .aac in the project folder"
    echo "Press Enter to exit..."
    read
    exit 1
fi
echo "   Audio found: $AUDIO_FILE"

# ============================================================================
# STEP 1: RENAME VIDEO FRAGMENTS
# ============================================================================

echo ""
echo "[1/4] Renaming video fragments..."
echo ""

if [ -f "rename_videos.py" ]; then
    python3 rename_videos.py --dir vid_img
    if [ $? -ne 0 ]; then
        echo "[ERROR] Rename failed!"
        echo "Press Enter to exit..."
        read
        exit 1
    fi
else
    echo "   [WARN] rename_videos.py not found, skipping..."
fi

# ============================================================================
# STEP 2: CHECK FRAGMENTS
# ============================================================================

echo ""
echo "[2/4] Checking fragments..."
echo ""

if [ -f "check_fragments.command" ]; then
    bash check_fragments.command
    if [ $? -ne 0 ]; then
        echo ""
        echo "================================================================================"
        echo "PROMPTS FOR MISSING FRAGMENTS"
        echo "================================================================================"
        echo ""
        echo "  Copy these prompts to Veo3 to generate missing fragments"
        echo ""

        if [ -f "missing_fragments.txt" ]; then
            MISSING=$(cat missing_fragments.txt)
            echo "   Missing fragments: $MISSING"
            echo ""
            if [ -f "extract_prompt.py" ]; then
                for ID in $MISSING; do
                    echo "================================================================================"
                    echo "FRAGMENT #$ID (MISSING)"
                    echo "================================================================================"
                    echo ""
                    python3 extract_prompt.py "$ID"
                    echo ""
                done
            else
                echo "[WARN] extract_prompt.py not found, open *_prompts_*.txt manually"
            fi
        fi

        echo ""
        echo "NEXT STEPS:"
        echo "   1. Copy prompts above"
        echo "   2. Generate missing fragments in Veo3"
        echo "   3. Download files to this folder"
        echo "   4. Run process_1080p_interactive.command again"
        echo ""
        echo "Press Enter to exit..."
        read
        exit 1
    fi
else
    echo "   [WARN] check_fragments.command not found, skipping check..."
fi

# ============================================================================
# STEP 2.5: FFPROBE INTEGRITY CHECK (parallel background jobs)
# ============================================================================

echo ""
echo "[2.5/4] Validating fragment integrity (ffprobe)..."
echo ""

TMPD=$(mktemp -d)
PIDS=()
MAX_JOBS=8

for F in vid_img/*.mp4; do
    [ -f "$F" ] || continue
    STEM=$(basename "$F" .mp4)
    (
        if ffprobe -v error "$F" 2>"$TMPD/$STEM.err"; then
            echo ok > "$TMPD/$STEM.status"
        else
            echo broken > "$TMPD/$STEM.status"
        fi
    ) &
    PIDS+=($!)
    if [ ${#PIDS[@]} -ge $MAX_JOBS ]; then
        wait "${PIDS[@]}"
        PIDS=()
    fi
done
[ ${#PIDS[@]} -gt 0 ] && wait "${PIDS[@]}"

BROKEN_IDS=""
BROKEN_COUNT=0
TOTAL=0
for STATF in "$TMPD"/*.status; do
    [ -f "$STATF" ] || continue
    TOTAL=$((TOTAL + 1))
    if [ "$(cat "$STATF")" = "broken" ]; then
        STEM=$(basename "$STATF" .status)
        ID=$(echo "$STEM" | sed 's/^0*//' | tr -d '[:space:]')
        [ -z "$ID" ] && ID=0
        ERR=$(head -1 "$TMPD/$STEM.err" 2>/dev/null)
        echo "   [BROKEN] #$ID — $ERR"
        BROKEN_IDS="$BROKEN_IDS $ID"
        BROKEN_COUNT=$((BROKEN_COUNT + 1))
    fi
done
rm -rf "$TMPD"

if [ $BROKEN_COUNT -gt 0 ]; then
    echo ""
    echo "========================================================================"
    echo "[ERROR] Broken fragments ($BROKEN_COUNT):$BROKEN_IDS"
    echo "   Regenerate them and re-run."
    echo "========================================================================"
    echo ""
    if [ -f "extract_prompt.py" ]; then
        for ID in $BROKEN_IDS; do
            echo "=== FRAGMENT #$ID ==="
            python3 extract_prompt.py "$ID"
            echo ""
        done
    fi
    echo "Press Enter to exit..."
    read
    exit 1
fi
echo "   [OK] All $TOTAL fragments valid"

# ============================================================================
# STEP 3: CONCAT 1080p
# ============================================================================

echo ""
echo "[3/4] Concat video (1080p, 10Mbps, re-encoding)..."
echo ""

python3 video_concat.py montage_plan.json -o "{project_name}.mp4" -b 10M
if [ $? -ne 0 ]; then
    echo "[ERROR] Concat failed!"
    echo "Press Enter to exit..."
    read
    exit 1
fi

# ============================================================================
# STEP 4: CLEANUP
# ============================================================================

echo ""
echo "[4/4] Renaming original audio..."
echo ""

if [ -f "result_original_audio.wav" ]; then
    mv "result_original_audio.wav" "VEO_AUDIO.wav"
    echo "   [OK] VEO_AUDIO.wav created"
fi

echo ""
echo "[4/4] Cleanup..."
echo ""

# Interactive: ask about deleting temp_processed
if [ -d "temp_processed" ]; then
    echo ""
    echo "   Found temp_processed folder with processed fragments."
    echo "   Delete it to save space?"
    echo ""
    echo "   [1] Yes, delete (recommended)"
    echo "   [2] No, keep (for debugging)"
    echo ""
    echo -n "   Your choice [1-2] (Enter = 1): "
    read CHOICE
    case "$CHOICE" in
        1|"")
            rm -rf "temp_processed"
            echo "   [OK] temp_processed removed"
            ;;
        2)
            echo "   [OK] temp_processed kept"
            ;;
        *)
            echo "   [WARN] Invalid choice, keeping temp_processed"
            ;;
    esac
fi

mkdir -p "FLOW_veo3_fragments"
for F in *.mp4; do
    [ -f "$F" ] || continue
    if [ "$F" != "{project_name}.mp4" ]; then
        mv "$F" "FLOW_veo3_fragments/"
    fi
done

echo ""
echo "================================================================================"
echo "[OK] DONE!"
echo "================================================================================"
echo ""
echo "   Result:    {project_name}.mp4"
echo "   Audio:     VEO_AUDIO.wav"
echo "   Fragments: FLOW_veo3_fragments/"
echo ""
echo "Press Enter to exit..."
read
