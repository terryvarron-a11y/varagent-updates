#!/usr/bin/env python3
"""
Emergency updater для VARAGENT — обходит SSL ошибку в старом updater.py
Использует только стандартную библиотеку Python 3.x
"""
import urllib.request
import urllib.error
import ssl
import zipfile
import io
import json
from pathlib import Path, PurePosixPath
import sys
import hashlib

GITHUB_REPO = 'terryvarron-a11y/varagent-updates'
PATCH_URL = f'https://raw.githubusercontent.com/{GITHUB_REPO}/main/patch.zip'
VERSION_URL = f'https://raw.githubusercontent.com/{GITHUB_REPO}/main/version.json'
SKIP_ON_INSTALL = {
    'projects/', '.env', 'agent/.env', 'publisher.py',
    '.codex/', 'Codex/.codex/',
}


def safe_patch_destination(root, archive_name):
    normalized = archive_name.replace('\\', '/')
    rel = PurePosixPath(normalized)
    if (not normalized or rel.is_absolute() or '..' in rel.parts
            or (rel.parts and ':' in rel.parts[0])):
        raise RuntimeError(f'Небезопасный путь в patch.zip: {archive_name!r}')
    dest = root.joinpath(*rel.parts)
    if not dest.resolve(strict=False).is_relative_to(root.resolve()):
        raise RuntimeError(f'Путь patch.zip выходит за папку программы: {archive_name!r}')
    return normalized, dest


def create_ssl_context():
    """Создает SSL context с отключенной проверкой."""
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    except Exception:
        return ssl._create_unverified_context()


def fetch(url, timeout=30):
    """Скачивает данные по URL."""
    ctx = create_ssl_context()
    req = urllib.request.Request(url, headers={'User-Agent': 'varagent-emergency-updater'})
    try:
        response = urllib.request.urlopen(req, timeout=timeout, context=ctx)
        return response.read()
    except urllib.error.URLError as e:
        print(f"Ошибка загрузки {url}: {e}")
        sys.exit(1)


def main():
    print("=" * 60)
    print(" VARAGENT Emergency Update")
    print("=" * 60)
    print()
    print("Этот скрипт обходит SSL ошибку в старом updater.py")
    print("и устанавливает последнее обновление напрямую с GitHub.")
    print()

    root = Path(__file__).parent

    # Получаем version.json
    print("[1/4] Загрузка version.json...")
    try:
        version_data = json.loads(fetch(VERSION_URL))
        version = version_data.get('version', 'unknown')
        expected_patch_sha256 = str(
            version_data.get('patch_sha256') or '').strip().lower()
        print(f"      Доступная версия: {version}")
    except Exception as e:
        print(f"      Предупреждение: не удалось загрузить version.json ({e})")
        version = 'unknown'
        version_data = {}
        expected_patch_sha256 = ''

    print()

    # Скачиваем patch.zip
    print("[2/4] Загрузка patch.zip...")
    patch_bytes = fetch(PATCH_URL, timeout=120)
    if expected_patch_sha256:
        actual_patch_sha256 = hashlib.sha256(patch_bytes).hexdigest()
        if actual_patch_sha256 != expected_patch_sha256:
            raise RuntimeError(
                "Контрольная сумма patch.zip не совпала с version.json: "
                f"{actual_patch_sha256} != {expected_patch_sha256}")
    print(f"      Скачано {len(patch_bytes)} байт")
    print()

    # Устанавливаем файлы
    print("[3/4] Установка файлов...")
    installed = []
    with zipfile.ZipFile(io.BytesIO(patch_bytes)) as zf:
        for archive_name in zf.namelist():
            if archive_name.endswith(('/', '\\')):
                continue
            name, dest = safe_patch_destination(root, archive_name)
            # Пропускаем защищённые пути
            if any(name.startswith(s) for s in SKIP_ON_INSTALL):
                continue
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(zf.read(archive_name))
            installed.append(name)
            if len(installed) % 20 == 0:
                print(f"      Установлено {len(installed)} файлов...")

    remote_files = version_data.get('files', {})
    mismatched = [
        name for name in installed
        if remote_files and remote_files.get(name) != hashlib.md5(
            (root / Path(name)).read_bytes()).hexdigest()
    ]
    if mismatched:
        raise RuntimeError(
            "Проверка установленных файлов не пройдена: "
            + ", ".join(mismatched[:10]))

    print(f"      Готово. Установлено файлов: {len(installed)}")
    print()

    # Очистка __pycache__
    print("[4/4] Очистка кеша Python...")
    import shutil
    cache_count = 0
    for cache_dir in root.rglob('__pycache__'):
        try:
            shutil.rmtree(cache_dir)
            cache_count += 1
        except Exception:
            pass
    print(f"      Удалено {cache_count} __pycache__ директорий")
    print()

    print("=" * 60)
    print(f"✓ Обновление установлено: {version}")
    print("=" * 60)
    print()
    print("Теперь можно использовать обычный updater.")
    print("Перезапустите VARAGENT.")
    print()

    # Установка certifi для будущих обновлений
    print("Установка certifi для надёжной работы updater...")
    try:
        import subprocess
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'certifi', '--quiet'])
        print("✓ certifi установлен")
    except Exception as e:
        print(f"⚠ Не удалось установить certifi: {e}")
        print("  Вы можете установить вручную: pip install certifi")

    print()
    input("Нажмите Enter для выхода...")


if __name__ == '__main__':
    main()
