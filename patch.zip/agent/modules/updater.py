"""
updater.py — Проверка и установка обновлений VARAGENT с GitHub
Версия: 2026.03.24-fix
"""
import hashlib
import json
import urllib.request
import urllib.error
import zipfile
import io
from pathlib import Path

GITHUB_REPO      = 'terryvarron-a11y/varagent-updates'
VERSION_JSON_URL = f'https://raw.githubusercontent.com/{GITHUB_REPO}/main/version.json'
VERSION_API      = f'https://api.github.com/repos/{GITHUB_REPO}/contents/version.json'
PATCH_URL        = f'https://raw.githubusercontent.com/{GITHUB_REPO}/main/patch.zip'

SKIP_ON_INSTALL = {'projects/', '.env', 'agent/.env', 'publisher.py'}

# Загружаем токен из .env если есть (для обхода rate limit)
def _load_github_token(root: Path) -> str | None:
    env_file = root / 'agent' / '.env'
    if env_file.exists():
        for line in env_file.read_text(encoding='utf-8').splitlines():
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                k, _, v = line.partition('=')
                if k.strip() == 'GITHUB_TOKEN':
                    return v.strip()
    return None


def _md5(path: Path) -> str:
    h = hashlib.md5()
    h.update(path.read_bytes())
    return h.hexdigest()


def _fetch(url: str, token: str | None = None, timeout: int = 15) -> bytes:
    headers = {'User-Agent': 'varagent-updater'}
    if token:
        headers['Authorization'] = f'token {token}'
    req = urllib.request.Request(url, headers=headers)
    return urllib.request.urlopen(req, timeout=timeout).read()


def _fetch_version_json(token: str | None = None) -> dict:
    """Получает version.json через GitHub API (с токеном для обхода rate limit)."""
    import base64
    headers = {
        'User-Agent': 'varagent-updater',
        'Accept': 'application/vnd.github.v3+json',
    }
    if token:
        headers['Authorization'] = f'token {token}'
    req = urllib.request.Request(VERSION_API, headers=headers)
    d = json.loads(urllib.request.urlopen(req, timeout=15).read())
    return json.loads(base64.b64decode(d['content']))


def check_updates(root: Path) -> dict:
    """
    Проверяет наличие обновлений.

    Returns:
        {
          'available': bool,
          'version': str,
          'changelog': [...],
          'changed_files': [...],   # файлы которые реально изменились у юзера
          'error': str | None,
        }
    """
    token = _load_github_token(root)
    try:
        data = _fetch_version_json(token)
    except Exception as e:
        return {'available': False, 'error': str(e)}

    remote_files = data.get('files', {})
    changed = []
    for rel, remote_md5 in remote_files.items():
        local_path = root / rel.replace('/', '\\')
        if not local_path.exists():
            changed.append(rel)
        elif _md5(local_path) != remote_md5:
            changed.append(rel)

    return {
        'available': len(changed) > 0,
        'version':   data.get('version', '?'),
        'changelog': data.get('changelog', []),
        'changed_files': changed,
        'requires_restart': data.get('requires_restart', False),
        'error': None,
    }


def install_update(root: Path, progress_cb=None) -> dict:
    """
    Скачивает и устанавливает patch.zip.

    progress_cb(msg: str) — опциональный колбэк для прогресса

    Returns: {'ok': bool, 'installed': [...], 'error': str | None}
    """
    def log(msg):
        if progress_cb:
            progress_cb(msg)

    token = _load_github_token(root)
    requires_restart = False

    try:
        # Сначала загружаем version.json для requires_restart
        log('Загрузка version.json...')
        try:
            data = _fetch_version_json(token)
            requires_restart = data.get('requires_restart', False)
        except Exception as ve:
            log(f'Предупреждение: не удалось загрузить version.json ({ve})')

        log('Скачивание патча...')
        patch_bytes = _fetch(PATCH_URL, token, timeout=60)

        log('Установка файлов...')
        installed = []
        with zipfile.ZipFile(io.BytesIO(patch_bytes)) as zf:
            for name in zf.namelist():
                # Пропускаем защищённые пути
                if any(name.startswith(s) for s in SKIP_ON_INSTALL):
                    continue
                dest = root / name.replace('/', '\\')
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(zf.read(name))
                installed.append(name)
                log(f'  {name}')

        log(f'Готово. Установлено файлов: {len(installed)}')
        return {'ok': True, 'installed': installed, 'error': None,
                'requires_restart': requires_restart}

    except Exception as e:
        return {'ok': False, 'installed': [], 'error': str(e)}
