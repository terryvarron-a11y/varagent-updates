# 🎯 START HERE — НАЧНИТЕ ОТСЮДА

**Добро пожаловать в SCENAGENT_RTG!**

---

## 📋 ЧТО ЗДЕСЬ ЛЕЖИТ

Это **чистая копия проекта** Video Production Agent для разработки и тестирования.

**Включено:**
- ✅ Весь код агента (`agent/`)
- ✅ Вся документация (`docs/`)
- ✅ Все скрипты и BAT-файлы
- ✅ Пустые папки для работы (`pipeline_queue/`, `projects/`)

**Не включено:**
- ❌ Старые файлы из корня (_комбайн\)
- ❌ Временные файлы и кэш
- ❌ Результаты тестов

---

## 🚀 ПЕРВЫЕ ШАГИ

### 1. Откройте папку в VS Code

```
File → Open Folder → SCENAGENT_RTG
```

### 2. Настройте API ключи

```bash
cd agent
copy .env.example .env
# Отредактируйте .env, вставьте ключи
```

### 3. Установите зависимости

```bash
pip install -r agent/requirements.txt
```

### 4. Прочитайте документацию

**Главный файл:** [`docs/PROJECT_STATUS.md`](docs/PROJECT_STATUS.md) ⭐

**Для быстрого старта:** [`README.md`](README.md)

---

## 📁 СТРУКТУРА

```
SCENAGENT_RTG/
├── agent/              ← Код (CLI, модули, шаблоны)
├── docs/               ← Документация (10 файлов)
├── pipeline_queue/        ← Сюда кладите аудиофайлы
├── projects/           ← Здесь создаются проекты
│
├── run_stage1.bat      ← Запуск 1 этапа
├── run_stage2_*.bat    ← Запуск 2 этапа
└── README.md           ← Краткая инструкция
```

---

## 🎯 СЛЕДУЮЩИЕ ШАГИ

1. **Настройте API ключи** в `agent/.env`
2. **Положите тестовый файл** в `pipeline_queue/`
3. **Запустите тест:**
   ```bash
   agent process
   run_stage1.bat
   ```

---

## 📚 ДОКУМЕНТАЦИЯ

| Файл | Описание |
|------|----------|
| [`docs/PROJECT_STATUS.md`](docs/PROJECT_STATUS.md) ⭐ | **ПОЛНЫЙ СТАТУС ПРОЕКТА** |
| [`docs/README.md`](docs/README.md) | Индекс документации |
| [`docs/HUMAN_PIPELINE.md`](docs/HUMAN_PIPELINE.md) | Для пользователей |
| [`docs/TECHNICAL_PIPELINE.md`](docs/TECHNICAL_PIPELINE.md) | Для разработчиков |
| [`README.md`](README.md) | Краткий старт |

---

## ✅ ГОТОВО К РАБОТЕ!

**Откройте [`docs/PROJECT_STATUS.md`](docs/PROJECT_STATUS.md) для полной информации!**

---

**Удачи в разработке!** 🚀
