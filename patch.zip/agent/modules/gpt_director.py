"""
GPT Director через Codex CLI.
Drop-in замена GeminiDirector — тот же интерфейс analyze().
"""
from __future__ import annotations

import json
import logging
import subprocess
import sys
import time
import threading
from pathlib import Path
from typing import Optional, Dict, Any
from datetime import datetime

import config
from modules.validator import validate_montage_plan_json, check_clip_id_sequence


class GptDirector:
    """Режиссёрский анализ через GPT (Codex CLI)"""

    def __init__(self, model_name: Optional[str] = None):
        self.model_name = model_name or config.GPT_MODEL
        self.codex_exe = Path(config.CODEX_EXE_PATH)
        self.schemas_dir = Path(__file__).parent.parent / 'schemas'
        self.prompts_dir = Path(__file__).parent.parent / 'prompts'
        self.timeout = config.GPT_DIRECTOR_TIMEOUT

        if not config.CODEX_EXE_PATH or not self.codex_exe.is_file():
            raise FileNotFoundError(f"Codex CLI не найден: {self.codex_exe}")

    # =========================================================================
    # ГЛАВНЫЙ МЕТОД — тот же интерфейс что у GeminiDirector
    # =========================================================================

    def analyze(
        self,
        transcription_path: str,
        style_guide_path: str,
        output_dir: str,
        project_name: str = "Untitled",
        two_pass: bool = False,
        prompts_only: bool = False,
        resume_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        output_dir = Path(output_dir)
        transcription_path = Path(transcription_path)
        style_guide_path = Path(style_guide_path)

        # Загрузить транскрипцию
        transcription = json.loads(transcription_path.read_text(encoding='utf-8'))
        audio_duration = transcription.get('audioDuration', 0)
        style_guide = style_guide_path.read_text(encoding='utf-8')

        results = {}

        if prompts_only:
            mp_path = output_dir / 'montage_plan.json'
            if not mp_path.exists():
                raise FileNotFoundError(f"montage_plan.json не найден: {mp_path}")
            montage_plan = json.loads(mp_path.read_text(encoding='utf-8'))
        else:
            # === PASS 1 — montage_plan.json ===
            montage_plan, mp_path = self._run_pass1(
                transcription_path, style_guide_path,
                output_dir, project_name, audio_duration, transcription
            )

        results['montage_plan'] = str(mp_path)
        results['num_clips'] = len(montage_plan.get('clips', []))

        # === PASS 2 — prompts ===
        # GPT через Codex всегда работает в two-pass режиме (два отдельных exec вызова)
        prompts_path, num_prompts = self._run_pass2(
            mp_path, transcription_path, style_guide_path,
            output_dir, project_name, montage_plan,
            resume_path=resume_path
        )
        if num_prompts == 0:
            raise RuntimeError(
                f"GPT Pass 2 вернул 0 промптов — файл пустой или Codex не записал. "
                f"Пайплайн остановлен. Перезапустите с режимом 'Prompts only'."
            )
        results['prompts'] = str(prompts_path) if prompts_path else None
        results['num_prompts'] = num_prompts
        results['cost'] = {
            'total_cost': 0,
            'input_tokens': 0,
            'output_tokens': 0,
            'note': 'GPT via ChatGPT subscription'
        }
        return results

    # =========================================================================
    # CODEX SUBPROCESS WRAPPER
    # =========================================================================

    def _run_codex(
        self,
        task_prompt: str,
        schema_file: str,
        result_file: Path,
        working_dir: Path,
    ) -> dict:
        """
        Запуск codex exec и чтение control JSON.
        Возвращает распарсенный control dict.
        """
        schema_path = self.schemas_dir / schema_file

        if not schema_path.exists():
            raise FileNotFoundError(f"Schema не найдена: {schema_path}")

        # Удалить предыдущий result если есть
        if result_file.exists():
            result_file.unlink()

        # Write task prompt to file to avoid Windows MAX_PATH / cmd length limits
        task_file = working_dir / f'_codex_{schema_file.replace(".json", "")}_task.md'
        task_file.write_text(task_prompt, encoding='utf-8')
        short_prompt = f"Read and follow ALL instructions from this file: {task_file.as_posix()}"

        cmd = [
            str(self.codex_exe), 'exec',
            short_prompt,
            '--output-schema', str(schema_path),
            '--output-last-message', str(result_file),
            '--dangerously-bypass-approvals-and-sandbox',
            '--skip-git-repo-check',
            '-m', self.model_name,
            '-C', str(working_dir),
        ]

        logging.info(f"Codex exec: model={self.model_name} schema={schema_file} cwd={working_dir}")
        t0 = time.time()

        # Run with real-time output streaming
        _stdout_lines = []
        _stderr_lines = []
        _returncode = [None]
        _done = threading.Event()
        _last_activity = [t0]

        def _exec():
            try:
                p = subprocess.Popen(
                    cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    text=True, encoding='utf-8', errors='replace',
                )
                # Read stdout in background thread
                def _read_stderr():
                    for line in p.stderr:
                        _stderr_lines.append(line.rstrip())
                        _last_activity[0] = time.time()
                serr_t = threading.Thread(target=_read_stderr, daemon=True)
                serr_t.start()

                for line in p.stdout:
                    line = line.rstrip()
                    if line:
                        _stdout_lines.append(line)
                        _last_activity[0] = time.time()
                        # Show Codex tool calls / file writes in real-time
                        ll = line.lower()
                        if any(k in ll for k in ('write', 'read', 'wrote', 'append', 'file', 'prompt')):
                            sys.stdout.write(f'\r   📝 {line[:100]:<100}\n')
                            sys.stdout.flush()

                p.wait(timeout=self.timeout)
                serr_t.join(timeout=5)
                _returncode[0] = p.returncode
            except subprocess.TimeoutExpired:
                p.kill()
                _returncode[0] = -1
            except Exception as e:
                _stderr_lines.append(str(e))
                _returncode[0] = -1
            finally:
                _done.set()

        thread = threading.Thread(target=_exec, daemon=True)
        thread.start()

        # Progress monitor — спиннер каждую секунду (GUI перехватывает в нижний лейбл)
        _last_size = 0
        _last_prompts = 0
        _monitor_file = None
        _spinner_chars = '⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
        _spin_i = 0

        while not _done.is_set():
            elapsed = time.time() - t0
            mins = int(elapsed) // 60
            secs = int(elapsed) % 60
            time_str = f"{mins}м {secs:02d}с" if mins > 0 else f"{secs}с"

            # Re-scan for prompts file periodically (Pass 1 не пишет промпты, но на всякий)
            if not _monitor_file:
                _mf = list(working_dir.glob('*_prompts_*.txt'))
                if _mf:
                    _monitor_file = max(_mf, key=lambda f: f.stat().st_mtime)

            if _monitor_file and _monitor_file.exists():
                try:
                    sz = _monitor_file.stat().st_size
                    if sz != _last_size:
                        _last_size = sz
                        txt = _monitor_file.read_text(encoding='utf-8', errors='replace')
                        n = len([p for p in txt.strip().split('\n\n') if p.strip()])
                        if n != _last_prompts:
                            _last_prompts = n
                except Exception:
                    pass

            # Спиннер каждую секунду
            spin = _spinner_chars[_spin_i % len(_spinner_chars)]
            _spin_i += 1
            idle = time.time() - _last_activity[0]
            idle_warn = f" idle {int(idle)}s" if idle > 60 else ""
            extra = f" | {_last_prompts} prompts" if _last_prompts > 0 else ""
            sys.stdout.write(f'\r{spin} GPT Pass1: {time_str}{extra}{idle_warn}   \n')
            sys.stdout.flush()

            _done.wait(1)

            # Hard timeout
            if elapsed > self.timeout:
                print(f"   ⏰ GPT timeout ({self.timeout}s)")
                logging.error(f"Codex timeout after {self.timeout}s")
                raise RuntimeError(f"Codex timeout after {self.timeout}s")

        elapsed = time.time() - t0
        mins = int(elapsed) // 60
        secs = int(elapsed) % 60
        time_str = f"{mins}м {secs:02d}с" if mins > 0 else f"{secs}с"

        if _returncode[0] == -1 and not _stdout_lines:
            sys.stdout.write(f'\r   ⏰ GPT timeout ({self.timeout}s)              \n')
            sys.stdout.flush()
            logging.error(f"Codex timeout after {self.timeout}s")
            raise RuntimeError(f"Codex timeout after {self.timeout}s")

        sys.stdout.write(f'\r   ✅ GPT — готово за {time_str}              \n')
        sys.stdout.flush()

        proc_stdout = '\n'.join(_stdout_lines)
        proc_stderr = '\n'.join(_stderr_lines)

        logging.info(f"Codex finished in {elapsed:.1f}s, exit_code={_returncode[0]}")

        # Извлечь tokens used из stderr/stdout
        for line in (proc_stderr).split('\n') + (proc_stdout).split('\n'):
            if 'tokens used' in line.lower():
                logging.info(f"Codex tokens: {line.strip()}")
                print(f"   📊 {line.strip()}")

        if _returncode[0] != 0:
            logging.error(f"Codex stderr (last 2000): {proc_stderr[-2000:]}")

        if not result_file.exists():
            raise RuntimeError(
                f"Codex не создал {result_file.name} "
                f"(exit {_returncode[0]}): {proc_stderr[:500]}"
            )

        raw = result_file.read_text(encoding='utf-8').strip()
        try:
            control = json.loads(raw)
        except json.JSONDecodeError as e:
            logging.error(f"Invalid JSON in {result_file}: {raw[:500]}")
            raise RuntimeError(f"Codex вернул невалидный JSON: {e}")

        logging.info(f"Codex control: {json.dumps(control, ensure_ascii=False)}")
        print(f"   ⏱  Codex: {elapsed:.0f}s, model={self.model_name}")
        return control

    # =========================================================================
    # PASS 2 — FILE MONITORING + TRIVIAL CONTROL SCHEMA
    # =========================================================================

    def _run_codex_pass2(
        self,
        task_prompt: str,
        prompts_path: Path,
        n_clips: int,
        working_dir: Path,
        prompts_offset: int = 0,
    ) -> int:
        """
        Запуск codex для Pass 2 с минимальной схемой {"status":"done"}.
        Схема заставляет Codex писать промпты в файл через file-write tool.
        Мониторим файл промптов:
          - как только n_clips промптов написано и файл стабилен 15с — убиваем процесс
          - не ждём финального {"status":"done"} — убиваем как только файл готов
          - hard timeout с восстановлением из файла или stdout
        Возвращает суммарное количество промптов в файле.
        """
        schema_path = self.schemas_dir / 'pass2_control.json'
        result_file = working_dir / f'_codex_pass2_control_{prompts_path.stem}.json'

        # Write task prompt to file to avoid Windows MAX_PATH / cmd length limits
        task_file = working_dir / f'_codex_pass2_task_{prompts_path.stem}.md'
        task_file.write_text(task_prompt, encoding='utf-8')
        short_prompt = f"Read and follow ALL instructions from this file: {task_file.as_posix()}"

        cmd = [
            str(self.codex_exe), 'exec',
            short_prompt,
            '--output-schema', str(schema_path),
            '--output-last-message', str(result_file),
            '--dangerously-bypass-approvals-and-sandbox',
            '--skip-git-repo-check',
            '-m', self.model_name,
            '-C', str(working_dir),
        ]

        logging.info(f"Codex Pass2: model={self.model_name}, expect={n_clips} prompts, cwd={working_dir}")
        t0 = time.time()

        _stdout_lines = []
        _stderr_lines = []

        p = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True, encoding='utf-8', errors='replace',
        )

        def _drain_stdout():
            for line in p.stdout:
                _stdout_lines.append(line.rstrip())
        def _drain_stderr():
            for line in p.stderr:
                _stderr_lines.append(line.rstrip())
        threading.Thread(target=_drain_stdout, daemon=True).start()
        threading.Thread(target=_drain_stderr, daemon=True).start()

        _last_size = -1
        _last_prompts = prompts_offset  # инициализируем смещением чтобы не срабатывал сразу
        _file_stable_since = None
        _STABLE_SECS = 15
        _exit_threshold = prompts_offset + n_clips  # ожидаемое итоговое кол-во промптов в файле
        _spinner_chars = '⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
        _spin_i = 0
        _early_exit = False

        # --- мониторинг токенов из Codex session JSONL ---
        _session_file = None
        _last_token_log_time = 0.0
        _last_logged_input_tokens = 0
        _TOKEN_LOG_INTERVAL = 30  # логируем токены каждые 30с

        def _find_session_file():
            """Найти JSONL-файл сессии Codex, созданный после t0."""
            try:
                today = datetime.now()
                session_dir = Path.home() / '.codex' / 'sessions' / str(today.year) / f'{today.month:02d}' / f'{today.day:02d}'
                if not session_dir.exists():
                    return None
                candidates = [
                    f for f in session_dir.glob('rollout-*.jsonl')
                    if f.stat().st_mtime >= t0 - 5
                ]
                if not candidates:
                    return None
                return max(candidates, key=lambda f: f.stat().st_mtime)
            except Exception:
                return None

        def _read_latest_tokens(session_file: Path):
            """Прочитать последний token_count из session JSONL."""
            try:
                lines = session_file.read_text(encoding='utf-8', errors='replace').strip().split('\n')
                for line in reversed(lines):
                    try:
                        ev = json.loads(line)
                        if ev.get('type') == 'event_msg':
                            payload = ev.get('payload', {})
                            if payload.get('type') == 'token_count':
                                usage = payload.get('info', {}).get('total_token_usage', {})
                                return usage.get('input_tokens', 0), usage.get('output_tokens', 0)
                    except Exception:
                        pass
            except Exception:
                pass
            return None

        while True:
            elapsed = time.time() - t0
            mins, secs = int(elapsed) // 60, int(elapsed) % 60
            time_str = f"{mins}м {secs:02d}с" if mins else f"{secs}с"

            # --- мониторинг файла промптов ---
            if prompts_path.exists():
                try:
                    sz = prompts_path.stat().st_size
                    if sz != _last_size:
                        _last_size = sz
                        _file_stable_since = None
                        txt = prompts_path.read_text(encoding='utf-8', errors='replace')
                        # Detect transcript pollution: if file contains VOICEOVER lines, it's not prompts
                        _raw_blocks = [x for x in txt.strip().split('\n\n') if x.strip()]
                        _voiceover_count = sum(1 for b in _raw_blocks if b.strip().startswith('VOICEOVER:') or b.strip().startswith('[CLIP'))
                        if _voiceover_count > len(_raw_blocks) * 0.3:
                            # File contains transcript, not prompts — wipe it
                            logging.warning(f"Pass2: file contains {_voiceover_count}/{len(_raw_blocks)} VOICEOVER blocks — transcript pollution, wiping file")
                            print(f"\n   ⚠️  Файл содержит транскрипцию вместо промптов — очищаю")
                            prompts_path.write_text('', encoding='utf-8')
                            _last_size = 0
                            _last_prompts = prompts_offset
                            _file_stable_since = None
                        else:
                            by_double = _raw_blocks
                            by_single = [x for x in txt.strip().split('\n') if x.strip()]
                            n = len(by_double) if len(by_double) > 1 else len(by_single)
                            if n != _last_prompts:
                                _last_prompts = n
                    else:
                        # размер не изменился
                        if _last_prompts >= _exit_threshold and _last_size > 0:
                            if _file_stable_since is None:
                                _file_stable_since = time.time()
                            elif time.time() - _file_stable_since >= _STABLE_SECS:
                                print(f"   ✅ Все {n_clips} промптов написаны, файл стабилен {_STABLE_SECS}с — завершаем Codex")
                                logging.info(f"Pass2 early exit: {_last_prompts}/{_exit_threshold} prompts, file stable")
                                p.kill()
                                _early_exit = True
                                break
                except Exception:
                    pass

            # --- токены из Codex session JSONL → в лог (не спиннер) ---
            now = time.time()
            if _session_file is None and now - t0 > 5:
                _session_file = _find_session_file()
            if _session_file and now - _last_token_log_time >= _TOKEN_LOG_INTERVAL:
                tokens = _read_latest_tokens(_session_file)
                if tokens:
                    inp, out = tokens
                    if inp != _last_logged_input_tokens:
                        _last_logged_input_tokens = inp
                        print(f"   🔢 GPT токены: {inp:,} input / {out:,} output\n")
                _last_token_log_time = now

            # --- спиннер каждую секунду (GUI перехватывает в нижний лейбл) ---
            spin = _spinner_chars[_spin_i % len(_spinner_chars)]
            _spin_i += 1
            _new_in_chunk = max(0, _last_prompts - prompts_offset)
            extra = f" | {_new_in_chunk}/{n_clips} промптов" if _new_in_chunk > 0 else ""
            sys.stdout.write(f'\r{spin} GPT Pass2: {time_str}{extra}   \n')
            sys.stdout.flush()

            # --- процесс завершился сам ---
            if p.poll() is not None:
                break

            # --- hard timeout ---
            if elapsed > self.timeout:
                p.kill()
                if _last_prompts > 0:
                    logging.warning(f"Pass2 timeout ({self.timeout}s) but {_last_prompts} prompts found — recovering")
                    print(f"   ⏰ Таймаут {self.timeout}s, {_last_prompts}/{n_clips} промптов в файле — берём")
                    break
                proc_stderr = '\n'.join(_stderr_lines[-20:])
                logging.warning(f"Pass2 timeout ({self.timeout}s), 0 prompts. stderr: {proc_stderr[:300]}")
                print(f"   ⚠️  Таймаут {self.timeout}s, файл промптов пуст")
                break  # выйдет в post-loop → вернёт prompts_offset → ретрай чанка

            time.sleep(1)

        elapsed = time.time() - t0
        mins, secs = int(elapsed) // 60, int(elapsed) % 60
        print(f"   ⏱  Codex Pass2: {mins}м {secs:02d}с")

        # Если файл не создан или пустой — 0 промптов, вернём наверх для ретрая
        if not prompts_path.exists() or prompts_path.stat().st_size == 0:
            proc_stderr = '\n'.join(_stderr_lines[-10:])
            logging.warning(f"Pass2: файл промптов не создан. stderr: {proc_stderr[:300]}")
            print(f"   ⚠️  Codex не создал файл промптов")
            return prompts_offset  # вернуть предыдущее кол-во — чанк ретрайнется

        txt = prompts_path.read_text(encoding='utf-8', errors='replace')

        # ── Transcript pollution check ──
        _blocks = [x for x in txt.strip().split('\n\n') if x.strip()]
        _vo_count = sum(1 for b in _blocks if b.strip().startswith('VOICEOVER:') or b.strip().startswith('[CLIP'))
        if _blocks and _vo_count > len(_blocks) * 0.3:
            logging.error(f"Pass2: file contains {_vo_count}/{len(_blocks)} VOICEOVER/CLIP blocks — GPT wrote transcript instead of prompts")
            print(f"   ❌ Файл содержит транскрипцию ({_vo_count} VOICEOVER блоков) вместо промптов — GPT не создал визуальных промптов")
            prompts_path.write_text('', encoding='utf-8')
            return 0

        # Нормализация разделителей: если промпты через \n — конвертируем в \n\n
        by_double = _blocks
        by_single = [x for x in txt.strip().split('\n') if x.strip()]
        if len(by_double) <= 1 and len(by_single) > 1:
            # Codex написал по одному промпту на строку — нормализуем
            normalized = '\n\n'.join(x.strip() for x in by_single)
            prompts_path.write_text(normalized, encoding='utf-8')
            txt = normalized
            logging.info(f"Pass2: normalized {len(by_single)} prompts from \\n to \\n\\n")

        count = len([x for x in txt.strip().split('\n\n') if x.strip()])
        logging.info(f"Codex Pass2 done: {count} prompts in file, elapsed={elapsed:.1f}s")
        return count

    # =========================================================================
    # PASS 1 — MONTAGE PLAN
    # =========================================================================

    def _run_pass1(
        self,
        transcription_path: Path,
        style_guide_path: Path,
        output_dir: Path,
        project_name: str,
        audio_duration: float,
        transcription: dict,
    ) -> tuple:
        """
        Pass 1: транскрипция + стайлгайд → montage_plan.json.
        Один exec вызов.
        """
        mp_path = output_dir / 'montage_plan.json'
        result_file = output_dir / '_codex_pass1_control.json'

        # Загрузить системную инструкцию
        sys_instr_path = self.prompts_dir / 'director_instruction_pass1.txt'
        pause_guide_path = self.prompts_dir / 'director_pause_guide.txt'

        task_prompt = self._build_pass1_prompt(
            transcription_path, style_guide_path, sys_instr_path,
            pause_guide_path, mp_path, project_name, audio_duration
        )

        print(f"\n🎬 GPT Pass 1: создание монтажного плана...")
        print(f"   Модель: {self.model_name}")
        print(f"   Аудио: {audio_duration:.0f}с ({audio_duration/60:.1f} мин)")

        control = self._run_codex(task_prompt, 'pass1_control.json', result_file, output_dir)

        if control.get('status') != 'ok':
            raise RuntimeError(f"GPT Pass 1 failed: {control.get('error_message', 'unknown')}")

        # Прочитать и провалидировать montage_plan.json
        actual_mp_path = Path(control.get('montage_plan_path', str(mp_path)))
        if not actual_mp_path.exists():
            actual_mp_path = mp_path

        if not actual_mp_path.exists():
            raise RuntimeError(f"montage_plan.json не создан: {actual_mp_path}")

        montage_plan = json.loads(actual_mp_path.read_text(encoding='utf-8'))

        # Нормализация обёртки
        if 'montage_plan' in montage_plan and 'clips' in montage_plan['montage_plan']:
            montage_plan = montage_plan['montage_plan']

        # Валидация через существующий валидатор
        is_valid, errors = validate_montage_plan_json(montage_plan, audio_duration)
        if not is_valid:
            logging.warning(f"GPT montage plan validation: {errors}")
            print(f"   ⚠️  Валидация: {len(errors)} замечаний (авто-коррекция)")
        else:
            print(f"   ✅ Валидация монтажного плана — OK")

        # Проверка ID последовательности
        id_problems = check_clip_id_sequence(montage_plan.get('clips', []))
        if id_problems:
            logging.warning(f"GPT montage plan ID issues: {id_problems}")
            print(f"   ⚠️  ID последовательность: {len(id_problems)} проблем (авто-коррекция)")
            # Авто-коррекция: перенумерация 1..N
            for i, clip in enumerate(montage_plan.get('clips', [])):
                clip['id'] = i + 1
                clip['file'] = f"{i + 1}.mp4"

        # Перезаписать нормализованный план
        mp_path.write_text(
            json.dumps(montage_plan, indent=2, ensure_ascii=False),
            encoding='utf-8'
        )

        clips = montage_plan.get('clips', [])
        _mp_chars = len(mp_path.read_text(encoding='utf-8'))
        print(f"   ✅ Монтажный план: {len(clips)} клипов, {audio_duration:.0f}с")
        print(f"   📊 Plan output: {_mp_chars:,} chars ≈ {_mp_chars // 3:,} tokens")
        return montage_plan, mp_path

    def _build_pass1_prompt(
        self,
        transcription_path: Path,
        style_guide_path: Path,
        sys_instr_path: Path,
        pause_guide_path: Path,
        mp_path: Path,
        project_name: str,
        audio_duration: float,
    ) -> str:
        """Сборка промпта для Pass 1."""
        t_path = transcription_path.as_posix()
        sg_path = style_guide_path.as_posix()
        si_path = sys_instr_path.as_posix()
        pg_path = pause_guide_path.as_posix()
        out_path = mp_path.as_posix()

        clip_min = config.ACTIVE_CLIP_MIN_DURATION
        clip_max = config.ACTIVE_CLIP_MAX_DURATION
        intro_min = config.get_intro_clip_min()
        intro_max = config.get_intro_clip_max()
        intro_block = config.INTRO_BLOCK_DURATION

        return f"""You are a film director creating a montage plan for a documentary.

## SYSTEM INSTRUCTION
Read the director instruction file: {si_path}
Also read the pause guide: {pg_path}

When reading the instruction, apply these substitutions:
- {{clip_min_dur}} = {clip_min}
- {{clip_max_dur}} = {clip_max}
- {{clip_intro_min_dur}} = {intro_min}
- {{clip_intro_max_dur}} = {intro_max}
- {{intro_block_dur}} = {intro_block}

## STYLE GUIDE
Read the style guide file: {sg_path}

## TRANSCRIPTION
Read the transcription file: {t_path}

## PROJECT
Name: {project_name}
Audio duration: {audio_duration:.2f} seconds

## TASK
1. Read ALL files listed above
2. Generate a montage plan following the director instruction rules
3. Write the result as JSON to: {out_path}

The JSON must have this structure:
{{
  "montage_plan": {{
    "audioDuration": {audio_duration:.2f},
    "clips": [
      {{"id": 1, "file": "1.mp4", "startTime": 0.0, "endTime": 7.8}},
      {{"id": 2, "file": "2.mp4", "startTime": 7.8, "endTime": 14.2}},
      ...
    ]
  }}
}}

Rules:
- Each clip duration: {clip_min}–{clip_max} seconds
- Clips must be continuous (no gaps): clip N endTime = clip N+1 startTime
- First clip startTime = 0.0
- Last clip endTime must equal audioDuration ({audio_duration:.2f})
- IDs sequential: 1, 2, 3, ...
- File format: "{{id}}.mp4"

Write the JSON file and then report your status in your final response."""

    # =========================================================================
    # PASS 2 — PROMPTS
    # =========================================================================

    def _run_pass2(
        self,
        mp_path: Path,
        transcription_path: Path,
        style_guide_path: Path,
        output_dir: Path,
        project_name: str,
        montage_plan: dict,
        resume_path: Optional[str] = None,
    ) -> tuple:
        """
        Pass 2: montage_plan + стайлгайд → промпты per clip.
        Возвращает (prompts_path, num_prompts).
        """
        clips = montage_plan.get('clips', [])
        total_clips = len(clips)
        if total_clips == 0:
            print("   ❌ Монтажный план пуст — нечего промптировать")
            return None, 0

        chunk_size = config.GPT_PASS2_CHUNK_SIZE or total_clips

        timestamp = datetime.now().strftime('%Y%m%d_%H%M')
        prompts_path = output_dir / f'{project_name}_prompts_{timestamp}.txt'
        total_prompts = 0
        cursor = 0
        chunk_idx = 0
        _chunk_retries = 0
        _MAX_CHUNK_RETRIES = 3

        # Load transcription fragments for clip cards
        transcription = json.loads(transcription_path.read_text(encoding='utf-8'))
        fragments = transcription.get('transcription', [])

        # Resume: подсчитать существующие промпты
        if resume_path:
            rp = Path(resume_path)
            if rp.exists():
                prompts_path = rp
                existing = rp.read_text(encoding='utf-8').strip().split('\n\n')
                total_prompts = len([p for p in existing if p.strip()])
                cursor = total_prompts
                print(f"   ↩️  Resume: {total_prompts} промптов уже есть, продолжаем с клипа {cursor + 1}")

        while cursor < total_clips:
            chunk_end = min(cursor + chunk_size, total_clips)
            chunk_clips = clips[cursor:chunk_end]
            from_id = chunk_clips[0]['id']
            to_id = chunk_clips[-1]['id']
            n_clips = len(chunk_clips)

            # Build clip cards with voiceover text (like Gemini)
            clip_cards = []
            for clip in chunk_clips:
                cs = clip.get('startTime', 0)
                ce = clip.get('endTime', 0)
                texts = [f['text'] for f in fragments
                         if f.get('start', 0) < ce and f.get('end', 0) > cs]
                text = ' '.join(texts).strip() or '(pause)'
                clip_cards.append(
                    f"[CLIP {clip['id']}] {cs:.1f}–{ce:.1f}s\n"
                    f"VOICEOVER: {text}"
                )
            clip_block = '\n\n'.join(clip_cards)

            # Previous plot context (last 5 clips before this chunk)
            prev_plot = ""
            if cursor > 0:
                prev_start = max(0, cursor - 5)
                plot_lines = []
                for c in clips[prev_start:cursor]:
                    cs, ce = c.get('startTime', 0), c.get('endTime', 0)
                    texts = [f['text'] for f in fragments
                             if f.get('start', 0) < ce and f.get('end', 0) > cs]
                    plot_lines.append(f"Clip {c['id']} ({cs:.1f}-{ce:.1f}s): {' '.join(texts).strip()}")
                prev_plot = '\n'.join(plot_lines)

            # Контекст предыдущих промптов
            prev_sample = ""
            if prompts_path.exists() and total_prompts > 0:
                existing = prompts_path.read_text(encoding='utf-8').strip().split('\n\n')
                prev_sample = '\n\n'.join(existing[-5:])

            task_prompt = self._build_pass2_prompt(
                style_guide_path, prompts_path,
                clip_block, from_id, to_id, n_clips, total_clips,
                prev_sample, prev_plot, total_prompts > 0
            )

            chunk_label = f" (клипы {from_id}–{to_id})" if total_clips > chunk_size else ""
            print(f"\n✍️  GPT Pass 2: генерация промптов{chunk_label}...")

            # Бэкап существующего контента — защита от перезаписи Codex
            _backup_content = None
            if total_prompts > 0 and prompts_path.exists():
                _backup_content = prompts_path.read_text(encoding='utf-8')

            file_total = self._run_codex_pass2(
                task_prompt, prompts_path, n_clips, output_dir,
                prompts_offset=total_prompts,
            )

            # Проверка: Codex не перезаписал предыдущие промпты
            if _backup_content is not None and prompts_path.exists():
                current = prompts_path.read_text(encoding='utf-8')
                _backup_start = _backup_content[:120].strip()
                if _backup_start and not current.startswith(_backup_start[:80]):
                    # Codex перезаписал файл — восстанавливаем
                    merged = _backup_content.rstrip() + '\n\n' + current.strip()
                    prompts_path.write_text(merged, encoding='utf-8')
                    file_total = len([p for p in merged.split('\n\n') if p.strip()])
                    logging.warning(f"Pass2: Codex overwrote file! Restored {total_prompts} prev + appended new → {file_total} total")
                    print(f"   ⚠️  Codex перезаписал файл — восстановлено {file_total} промптов")

            written = file_total - total_prompts  # добавлено в этом чанке
            chunk_idx += 1

            # Output stats (cap display at total_clips to avoid confusion)
            _disp_total = min(file_total, total_clips)
            _disp_written = min(written, n_clips)
            if prompts_path.exists():
                _fsize = prompts_path.stat().st_size
                _chars = len(prompts_path.read_text(encoding='utf-8'))
                _est_tokens = _chars // 3
                print(f"   → Записано: {_disp_written}, всего: {_disp_total}/{total_clips}")
                print(f"   📊 Output: {_chars:,} chars ≈ {_est_tokens:,} tokens ({_fsize:,} bytes)")
            else:
                print(f"   → Записано: {_disp_written}, всего: {_disp_total}/{total_clips}")

            total_prompts = file_total

            if written < n_clips:
                if written == 0:
                    _chunk_retries += 1
                    if _chunk_retries > _MAX_CHUNK_RETRIES:
                        logging.warning(f"Pass2: no progress after {_MAX_CHUNK_RETRIES} retries ({total_prompts}/{total_clips}) — stopping")
                        print(f"   ❌ {_MAX_CHUNK_RETRIES} попыток без прогресса — останавливаюсь")
                        break
                    logging.warning(f"Pass2: no progress ({total_prompts}/{total_clips}) — retry {_chunk_retries}/{_MAX_CHUNK_RETRIES}")
                    print(f"   🔄 0 промптов — ретрай чанка ({_chunk_retries}/{_MAX_CHUNK_RETRIES})...")
                    time.sleep(5)
                    continue
                # Частичная запись (таймаут?) — продолжаем со следующего клипа
                logging.warning(f"Pass2 partial chunk: {written}/{n_clips}, resuming from clip {total_prompts + 1}")
                print(f"   ⚡ Частичная запись {written}/{n_clips} — продолжаем с клипа {total_prompts + 1}")
                cursor = total_prompts
                continue

            _chunk_retries = 0  # успешный чанк — сброс ретраев
            cursor = chunk_end

            if chunk_end >= total_clips:
                break

        # Финальная валидация
        if prompts_path.exists():
            actual = prompts_path.read_text(encoding='utf-8').strip().split('\n\n')
            actual_count = len([p for p in actual if p.strip()])
            if actual_count != total_prompts:
                logging.warning(f"Prompts count mismatch: control={total_prompts}, file={actual_count}")
                total_prompts = actual_count

            # Trim если больше чем клипов
            if total_prompts > total_clips:
                logging.warning(f"Overprompt: {total_prompts}>{total_clips}, trimming")
                all_p = [p for p in actual if p.strip()]
                prompts_path.write_text(
                    '\n\n'.join(all_p[:total_clips]),
                    encoding='utf-8'
                )
                total_prompts = total_clips

        print(f"\n✅ GPT Pass 2 завершён: {total_prompts}/{total_clips} промптов")
        return prompts_path if total_prompts > 0 else None, total_prompts

    def _build_pass2_prompt(
        self,
        style_guide_path: Path,
        prompts_path: Path,
        clip_block: str,
        from_id: int,
        to_id: int,
        n_clips: int,
        total_clips: int,
        prev_sample: str,
        prev_plot: str,
        append_mode: bool,
    ) -> str:
        """Сборка промпта для Pass 2 с clip cards (как Gemini)."""
        prev_section = ""
        if prev_sample:
            prev_section = f"""
## PREVIOUS PROMPTS (for style consistency — continue in the same format)
{prev_sample}
"""
        plot_section = ""
        if prev_plot:
            plot_section = f"""
## PREVIOUS SCENE CONTEXT (what was just visualized)
{prev_plot}
"""

        write_mode = "Append to the existing file (do NOT overwrite previous content)." if append_mode else "Create a new file."

        return f"""You are a film director writing visual prompts for image generation.

## STYLE GUIDE
Read the style guide file: {style_guide_path.as_posix()}
{plot_section}{prev_section}
## CLIPS TO PROCESS ({n_clips} clips, {from_id}–{to_id} out of {total_clips} total)

{clip_block}

## TASK
Write one visual image-generation prompt per clip. You are writing prompts for an AI image generator (Banana/Imagen/DALL-E class). The generator does NOT understand narrative text — it needs a precise visual description of a single frozen frame.

⚠️ CRITICAL: DO NOT copy, quote, paraphrase, or embed the voiceover text into the prompt. DO NOT write "visualize this narrated moment:" followed by the script text. The voiceover tells you WHAT IS HAPPENING — your job is to describe WHAT THE CAMERA SEES as a detailed visual composition for an AI image generator.

The image generator does NOT understand narrative text, foreign languages, or abstract concepts. It ONLY understands concrete visual descriptions in English: objects, people, lighting, textures, colors, composition.

## PROMPT STRUCTURE

Each prompt MUST follow this block structure as ONE continuous line:

`[PERIOD, YEAR] [LOCATION] [CAMERA ANGLE]: [PRIMARY SUBJECT — appearance, posture, clothing, expression, action] [SUBJECT MOOD — emotion visible in body language] [SECONDARY ELEMENTS — other people, objects, props in frame] [SCENE INTERACTION — what is happening between elements] [LIGHTING & ATMOSPHERE] [STYLE from style guide] [NEGATIVE PROMPT from style guide]`

### BLOCK-BY-BLOCK GUIDE:

1. **PERIOD & SETTING** — historical era, year range, geographic region (e.g. "Colonial Caribbean, 1695", "Viking-era North Atlantic, 900 AD")
2. **LOCATION** — specific place, not generic (e.g. "cramped below-deck chart room of a weathered brig, salt-stained oak walls, low ceiling with hanging lanterns" — NOT just "a ship")
3. **CAMERA ANGLE** — from style guide rotation: wide → medium → close-up → cycle
4. **PRIMARY SUBJECT** — who/what is center-frame. Describe VISUALLY: age, build, skin, clothing fabric, hair, facial expression, hand position, posture, specific action (e.g. "a gaunt 40-year-old navigator in a salt-crusted linen coat, squinting through a brass cross-staff aimed at Polaris, deep sun-creases around his eyes")
5. **SUBJECT MOOD & INTENT** — emotion shown through VISIBLE body language (e.g. "tense concentration, jaw clenched, knuckles white on the instrument" — NOT "he feels worried")
6. **SECONDARY ELEMENTS** — other people, objects, props visible (e.g. "two sleeping crew members in rope hammocks behind him, a tallow candle guttering on the chart table, an unrolled parchment map weighted down with a compass")
7. **SCENE INTERACTION** — the core visual action or tension between elements (e.g. "his finger traces a line on the map while his eyes dart between the star and the horizon")
8. **LIGHTING & ATMOSPHERE** — light source, color temperature, mood (e.g. "cold silver starlight from above mixing with warm amber lantern glow from below, sea mist diffusing the edges")
9. **STYLE** — from style guide: photorealistic, textures, depth of field, composition
10. **NEGATIVE PROMPT** — from style guide: what to avoid

### GOOD EXAMPLE:
```
Colonial Caribbean, 1695. Cramped below-deck chart room of a weathered pirate brig, salt-stained oak planks, low ceiling with a swinging oil lantern. Close-up shot. A gaunt 40-year-old navigator in a threadbare linen shirt, deep sun-creases around squinting eyes, calloused fingers gripping a brass divider against a yellowed parchment sea chart. Intense focus, lips pressed thin, brow furrowed — a man calculating whether 200 lives survive tomorrow. Behind him: a half-empty hourglass, a knotted rope log-line coiled on a nail, a crude wooden cross-staff leaning against the bulkhead. His divider tip rests on an ink-drawn coastline while his gaze measures the distance to a question mark labeled "aquí hay monstruos." Warm amber lantern glow from above, cool blue moonlight leaking through a deck seam, cigarette-thick dust motes in the light shaft. Photorealistic prestige-TV composition, tactile salt-worn surfaces, shallow depth of field on the divider tip. No modern instruments, no GPS, no clean surfaces, no fantasy elements, single full-frame continuous camera view edge-to-edge
```

### BAD EXAMPLE (DO NOT DO THIS):
```
Cinematic scene, visualize only this narrated moment: Imagina que es medianoche. El barco cruje bajo tus pies. ❌ THIS IS SCRIPT TEXT, NOT A VISUAL PROMPT
```

## DIVERSITY RULES:
- Each prompt MUST show a DIFFERENT visual composition — change location, subject, framing, or action
- NEVER repeat the same establishing shot for consecutive clips
- If 3 consecutive clips discuss the same topic, show it from 3 different angles: environment → character → object detail
- Vary between: landscape/environment, character portrait, object close-up, action moment, atmospheric wide
- Every prompt must be >50 words of visual description (not counting negative prompt)
- NO "Narration:" tags, NO voiceover text, NO script quotes, NO comments about duration

LANGUAGE: Write ALL prompts in English regardless of voiceover language.

STRICT OUTPUT RULES:
- Each prompt = ONE continuous line, no line breaks inside the prompt
- Prompts separated by ONE blank line between them
- Exactly {n_clips} prompts, one per clip
- NO numbering, NO clip IDs, NO headers in the output
- Camera angle rotation: wide → medium → close-up → wide (cycle)
- Each prompt must end with: "single full-frame continuous camera view edge-to-edge"

⚠️ CRITICAL FILE WRITING INSTRUCTION:
You MUST use your file-write tool to write the prompts to this exact path:
  {prompts_path.as_posix()}

{write_mode}
Write prompts to the file as you generate them — do NOT accumulate all prompts in memory before writing. Write each prompt to the file immediately as you create it.
DO NOT output the prompts in your response text — write them ONLY to the file above.
Your final response must be valid JSON matching the output schema: {{"status": "done"}}"""


# =========================================================================
# Wrapper function — аналог direct_project() для GptDirector
# =========================================================================

def gpt_direct_project(
    transcription_path: str,
    style_guide_path: str,
    output_dir: str,
    project_name: str = "Untitled",
    model_name: Optional[str] = None,
    two_pass: bool = False,
    prompts_only: bool = False,
    resume_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Wrapper: создаёт GptDirector и запускает analyze()."""
    director = GptDirector(model_name=model_name)
    return director.analyze(
        transcription_path, style_guide_path, output_dir, project_name,
        two_pass=two_pass, prompts_only=prompts_only, resume_path=resume_path,
    )
