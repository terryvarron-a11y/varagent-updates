"""
Модуль режиссирования из текстового сценария (без аудио/транскрипции).
Два режима: проза и screenplay. Синтетические таймстемпы. Без audioDuration.
"""
from google import genai
from google.genai import types
import json
import logging
import re
import sys
import threading
import time
import traceback
from pathlib import Path
from typing import Optional, Dict, Any, Tuple
from datetime import datetime

import config
from modules.textio import read_user_text
from modules.validator import validate_montage_plan_json, check_clip_id_sequence


def _run_with_spinner(fn, message='', *args, **kwargs):
    result = [None]
    error  = [None]
    done   = threading.Event()

    def target():
        try:
            result[0] = fn(*args, **kwargs)
        except Exception as e:
            error[0] = e
        finally:
            done.set()

    t = threading.Thread(target=target, daemon=True)
    t.start()

    chars = ['⠋','⠙','⠹','⠸','⠼','⠴','⠦','⠧','⠇','⠏']
    i = 0
    while not done.is_set():
        sys.stdout.write(f'\r{chars[i % len(chars)]} {message}   ')
        sys.stdout.flush()
        time.sleep(0.1)
        i += 1
    sys.stdout.write('\r' + ' ' * (len(message) + 8) + '\r')
    sys.stdout.flush()

    if error[0]:
        raise error[0]
    return result[0]


def _save_raw_response(output_dir: Path, text: str, suffix: str = ''):
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    name = f'gemini_raw_response_{ts}{suffix}.txt'
    path = output_dir / name
    path.write_text(text, encoding='utf-8', errors='replace')
    logging.debug(f'Raw response saved: {path}')


def script_direct_project(
    script_path: str,
    style_guide_path: str,
    output_dir: str,
    project_name: str = 'Untitled',
    script_type: str = 'prose',
    two_pass: bool = False,
    model_name: Optional[str] = None,
) -> Dict[str, Any]:
    """Хелпер: создаёт ScriptDirector backend (claude_code|claude_api|gemini) и запускает analyze()."""
    backend = getattr(config, 'DIRECTOR_BACKEND', 'gemini')
    if backend in ('claude', 'claude_code'):
        from modules.claude_code_script_director import ClaudeCodeScriptDirector
        director = ClaudeCodeScriptDirector(model_name=model_name)
    elif backend in ('claude_api', 'anthropic'):
        from modules.claude_api_script_director import ClaudeApiScriptDirector
        director = ClaudeApiScriptDirector(model_name=model_name)
    elif backend == 'gpt' and getattr(config, 'GPT_PROVIDER', '') in (
        'deepseek', 'openrouter', 'meta_muse', 'cliproxy', 'codex_reseller',
        'gpt_nexus',
    ):
        from modules.chat_script_director import ChatScriptDirector
        director = ChatScriptDirector(model_name=model_name)
    else:
        director = GeminiScriptDirector(model_name=model_name)
    return director.analyze(
        script_path=script_path,
        style_guide_path=style_guide_path,
        output_dir=output_dir,
        project_name=project_name,
        script_type=script_type,
        two_pass=two_pass,
    )


class GeminiScriptDirector:
    """Режиссёр для текстовых сценариев (без аудио). Синтетические таймстемпы."""

    def __init__(self, api_key: Optional[str] = None, model_name: Optional[str] = None):
        self.api_key = api_key or config.GEMINI_API_KEY
        self.model_name = model_name or config.GEMINI_MODEL

        if not self.api_key:
            raise ValueError("Gemini API ключ не указан")

        self.client = genai.Client(api_key=self.api_key)
        self.input_tokens = 0
        self.output_tokens = 0

    # =========================================================================
    # ГЛАВНЫЙ МЕТОД
    # =========================================================================

    def analyze(
        self,
        script_path: str,
        style_guide_path: str,
        output_dir: str,
        project_name: str = 'Untitled',
        script_type: str = 'prose',   # 'prose' | 'screenplay'
        two_pass: bool = False,
    ) -> Dict[str, Any]:
        script_path = Path(script_path)
        style_guide_path = Path(style_guide_path)
        output_dir = Path(output_dir)

        if not script_path.exists():
            raise FileNotFoundError(f"Сценарий не найден: {script_path}")
        if not style_guide_path.exists():
            raise FileNotFoundError(f"Style guide не найден: {style_guide_path}")

        print(f"\n🎬 Режиссура сценария: {project_name}")
        print(f"   Тип: {script_type}  |  Режим: {'2-pass' if (two_pass or config.GEMINI_TWO_PASS) else '1-pass'}")
        print("=" * 60)

        script_text = read_user_text(script_path)
        style_guide = read_user_text(style_guide_path)

        output_dir.mkdir(parents=True, exist_ok=True)

        if two_pass or config.GEMINI_TWO_PASS:
            return self._analyze_two_pass(script_text, style_guide, output_dir, project_name, script_type)
        else:
            return self._analyze_one_pass(script_text, style_guide, output_dir, project_name, script_type)

    # =========================================================================
    # ОДНОПРОХОДНЫЙ РЕЖИМ
    # =========================================================================

    def _analyze_one_pass(
        self,
        script_text: str,
        style_guide: str,
        output_dir: Path,
        project_name: str,
        script_type: str,
    ) -> Dict[str, Any]:
        print("📝 Формирование промпта (1-pass)...")
        sys_instr, user_content = self._create_prompt_one_pass(script_text, style_guide, project_name, script_type)

        print(f"🤖 Отправка запроса к Gemini ({self.model_name})...")
        response, cost_info = self._make_api_call(user_content, system_instruction=sys_instr)
        self._print_cost(cost_info)
        _save_raw_response(output_dir, response.text)

        print("\n📝 Парсинг ответа...")
        # Use a fake empty transcription so we can reuse _parse_json_only validation
        fake_transcription: Dict[str, Any] = {'audioDuration': 0, 'transcription': []}
        montage_plan = self._parse_json_only(response.text, output_dir, fake_transcription)
        prompts_results = self._parse_prompts_only(response.text, output_dir, montage_plan, project_name)

        results: Dict[str, Any] = {}
        results.update(prompts_results)
        results['montage_plan'] = output_dir / 'montage_plan.json'

        all_costs = [cost_info] if cost_info else []
        num_clips = len(montage_plan.get('clips', []))
        num_prompts = prompts_results.get('num_prompts', 0)

        # Auto-completion if prompts < clips
        if num_prompts < num_clips and num_clips > 0:
            main_path = prompts_results.get('prompts')
            for attempt in range(1, 4):
                if num_prompts >= num_clips:
                    break
                missing = num_clips - num_prompts
                from_id = num_prompts + 1
                print(f"\n🔁 Авто-дополнение ({attempt}/3): клипы {from_id}–{num_clips} ({missing} шт)...")
                prev_sample = None
                if main_path and main_path.exists():
                    full = main_path.read_text(encoding='utf-8')
                    all_p = [c.strip() for c in full.split('\n\n') if c.strip()]
                    prev_sample = all_p[-5:] if all_p else None
                prompt_cont = self._create_prompt_pass2_chunk(
                    montage_plan, style_guide, from_id, num_clips, num_prompts, prev_sample
                )
                resp_cont, cost_cont = self._make_api_call(
                    prompt_cont, pass2_mode=True,
                    spinner_msg=f"Gemini дополняет (попытка {attempt})"
                )
                self._print_cost(cost_cont, label=f"дополнения {attempt}")
                if cost_cont:
                    all_costs.append(cost_cont)
                if not resp_cont or not resp_cont.text:
                    continue
                _save_raw_response(output_dir, resp_cont.text, suffix=f'_cont{attempt}')
                cont_montage = {'clips': [c for c in montage_plan.get('clips', [])
                                          if c['id'] >= from_id and c['id'] <= num_clips]}
                cont_res = self._parse_prompts_only(resp_cont.text, output_dir, cont_montage, project_name)
                cont_path = cont_res.get('prompts')
                if cont_path and cont_path.exists() and main_path and main_path.exists():
                    cont_text = cont_path.read_text(encoding='utf-8').strip()
                    with open(main_path, 'a', encoding='utf-8') as f:
                        f.write('\n\n' + cont_text)
                    cont_path.unlink()
                    full = main_path.read_text(encoding='utf-8')
                    num_prompts = len([c.strip() for c in full.split('\n\n') if c.strip()])
                    results['num_prompts'] = num_prompts
                    print(f"   → Итого промптов: {num_prompts} / {num_clips}")

        self._finalize_costs(all_costs, output_dir, project_name,
                             num_prompts=results.get('num_prompts', num_prompts),
                             num_clips=num_clips, results=results)

        print(f"\n✅ Режиссура сценария завершена (1-pass)!")
        for k, v in results.items():
            if k not in ('cost', 'num_prompts', 'num_clips'):
                print(f"   • {k}: {v}")
        return results

    # =========================================================================
    # ДВУХПРОХОДНЫЙ РЕЖИМ
    # =========================================================================

    def _analyze_two_pass(
        self,
        script_text: str,
        style_guide: str,
        output_dir: Path,
        project_name: str,
        script_type: str,
    ) -> Dict[str, Any]:
        results: Dict[str, Any] = {}

        # === ПРОХОД 1: JSON план ===
        print(f"\n🎬 ПРОХОД 1/2: Монтажный план (JSON)...")
        sys_instr, user_pass1 = self._create_prompt_pass1(script_text, style_guide, project_name, script_type)
        print(f"🤖 Отправка запроса к Gemini ({self.model_name})...")
        response1, cost1 = self._make_api_call(user_pass1, system_instruction=sys_instr,
                                               spinner_msg="Gemini думает (проход 1/2)")
        self._print_cost(cost1, label="прохода 1")
        _save_raw_response(output_dir, response1.text, suffix='_pass1')

        fake_transcription: Dict[str, Any] = {'audioDuration': 0, 'transcription': []}
        montage_plan = self._parse_json_only(response1.text, output_dir, fake_transcription, pass_num=1)

        if not montage_plan.get('clips'):
            for _retry in range(1, 3):
                print(f"\n⚠️  Pass 1 пуст. Повтор {_retry}/2...")
                response1, cost1_r = self._make_api_call(user_pass1, system_instruction=sys_instr,
                                                          spinner_msg=f"Gemini retry {_retry}/2")
                self._print_cost(cost1_r, label=f"retry {_retry}")
                if cost1_r:
                    cost1 = cost1_r
                _save_raw_response(output_dir, response1.text, suffix=f'_pass1_retry{_retry}')
                montage_plan = self._parse_json_only(response1.text, output_dir, fake_transcription, pass_num=1)
                if montage_plan.get('clips'):
                    break
            else:
                raise ValueError("Pass 1 не вернул монтажный план после 3 попыток.")

        pass1_costs = [c for c in [cost1] if c]
        num_clips = len(montage_plan['clips'])
        print(f"   ✓ Pass 1: {num_clips} клипов")

        # === ПРОХОД 2: Промпты (с чанкованием) ===
        prompts_results, pass2_costs = self._run_pass2(
            montage_plan, style_guide, project_name, output_dir, pass_label="2/2"
        )
        results.update(prompts_results)
        results['montage_plan'] = output_dir / 'montage_plan.json'

        all_costs = pass1_costs + pass2_costs
        num_prompts = prompts_results.get('num_prompts', 0)

        self._finalize_costs(all_costs, output_dir, project_name,
                             num_prompts=num_prompts, num_clips=num_clips, results=results)

        print(f"\n✅ Режиссура сценария завершена (2-pass)!")
        for k, v in results.items():
            if k not in ('cost', 'num_prompts', 'num_clips'):
                print(f"   • {k}: {v}")
        return results

    # =========================================================================
    # PASS 2: цикл по чанкам с roll-forward курсором
    # =========================================================================

    def _run_pass2(
        self,
        montage_plan: dict,
        style_guide: str,
        project_name: str,
        output_dir: Path,
        pass_label: str = "2/2",
    ) -> Tuple[Dict[str, Any], list]:
        clips = montage_plan.get('clips', [])
        total_clips = len(clips)
        chunk_size = config.PROMPT_CHUNK_SIZE if config.PROMPT_CHUNK_SIZE > 0 else total_clips

        all_costs = []
        main_prompts_path = None
        total_prompts = 0
        MAX_CONTINUATION = 3
        PREV_SAMPLE_SIZE = 5

        cursor = 0
        chunk_idx = 0

        while cursor < total_clips:
            chunk_end = min(cursor + chunk_size, total_clips)
            chunk_clips = clips[cursor:chunk_end]
            from_id = chunk_clips[0]['id']
            to_id = chunk_clips[-1]['id']
            is_last_chunk = (chunk_end >= total_clips)
            chunk_label = f"чанк {chunk_idx + 1}" if total_clips > chunk_size else ""

            if chunk_label:
                print(f"\n✍️  ПРОХОД {pass_label}: промпты — {chunk_label} (клипы {from_id}–{to_id})...")
            else:
                print(f"\n✍️  ПРОХОД {pass_label}: Генерация промптов ({total_clips} шт)...")
            print(f"🤖 Отправка запроса к Gemini ({self.model_name})...")

            prev_sample = None
            if cursor > 0 and main_prompts_path and main_prompts_path.exists():
                prev_text = main_prompts_path.read_text(encoding='utf-8')
                prev_all = [c.strip() for c in prev_text.split('\n\n') if c.strip()]
                prev_sample = prev_all[-PREV_SAMPLE_SIZE:] if prev_all else None

            prev_plot_context = None
            if cursor > 0:
                done_clips = clips[:cursor]
                prev_plot_context = '\n'.join(
                    f"Клип {c['id']} ({c.get('startTime',0):.1f}-{c.get('endTime',0):.1f}с): {c.get('description','—')}"
                    for c in done_clips
                )

            chunk_montage = {'clips': chunk_clips}
            prompt2 = self._create_prompt_chunk(
                chunk_clips, style_guide, from_id, to_id, total_clips,
                prev_sample=prev_sample,
                prev_plot_context=prev_plot_context,
            )
            spinner_msg = f"Gemini думает (проход {pass_label}{', ' + chunk_label if chunk_label else ''})"
            response2, cost2 = self._make_api_call(prompt2, pass2_mode=True, spinner_msg=spinner_msg)
            self._print_cost(cost2, label=f"прохода {pass_label}{' ' + chunk_label if chunk_label else ''}")

            if cost2:
                all_costs.append(cost2)

            if not response2 or not response2.text:
                print(f"   ❌ Gemini вернул пустой ответ")
                break

            _save_raw_response(output_dir, response2.text,
                               suffix=f'_pass2_chunk{chunk_idx + 1}' if total_clips > chunk_size else '_pass2')

            print("\n📝 Парсинг промптов...")
            chunk_results = self._parse_prompts_only(response2.text, output_dir, chunk_montage, project_name)
            chunk_path = chunk_results.get('prompts')
            chunk_prompts = chunk_results.get('num_prompts', 0)

            # Rollback для не-последних чанков
            if not is_last_chunk and chunk_prompts > 0:
                _rollback = config.CONT_ROLLBACK_SIZE
                if _rollback > 0 and chunk_prompts > _rollback and chunk_path and chunk_path.exists():
                    rollback_to = chunk_prompts - _rollback
                    _full = chunk_path.read_text(encoding='utf-8')
                    _kept = [c.strip() for c in _full.split('\n\n') if c.strip()][:rollback_to]
                    chunk_path.write_text('\n\n'.join(_kept), encoding='utf-8')
                    chunk_prompts = rollback_to

            # Continuation для последнего чанка
            if is_last_chunk and chunk_prompts < len(chunk_clips):
                for cont_attempt in range(1, MAX_CONTINUATION + 1):
                    if chunk_prompts >= len(chunk_clips):
                        break
                    missing = len(chunk_clips) - chunk_prompts
                    cont_from_id = from_id + chunk_prompts
                    print(f"\n🔁 Авто-дополнение ({cont_attempt}/{MAX_CONTINUATION}): "
                          f"клипы {cont_from_id}–{to_id} ({missing} шт)...")
                    cont_clips = [c for c in chunk_clips if c['id'] >= cont_from_id and c['id'] <= to_id]
                    cont_prev = None
                    _src = chunk_path if chunk_path and chunk_path.exists() else main_prompts_path
                    if _src and _src.exists():
                        _all = [c.strip() for c in _src.read_text(encoding='utf-8').split('\n\n') if c.strip()]
                        cont_prev = _all[-PREV_SAMPLE_SIZE:] if _all else None
                    cont_plot = None
                    done_so_far = clips[:cursor + chunk_prompts]
                    if done_so_far:
                        cont_plot = '\n'.join(
                            f"Клип {c['id']} ({c.get('startTime',0):.1f}-{c.get('endTime',0):.1f}с): {c.get('description','—')}"
                            for c in done_so_far
                        )
                    prompt_cont = self._create_prompt_chunk(
                        cont_clips, style_guide, cont_from_id, to_id, total_clips,
                        is_continuation=True, already_done=from_id + chunk_prompts - 1,
                        prev_sample=cont_prev, prev_plot_context=cont_plot,
                    )
                    resp_cont, cost_cont = self._make_api_call(
                        prompt_cont, pass2_mode=True,
                        spinner_msg=f"Gemini дополняет (попытка {cont_attempt})"
                    )
                    self._print_cost(cost_cont, label=f"дополнения (попытка {cont_attempt})")
                    if cost_cont:
                        all_costs.append(cost_cont)
                    if not resp_cont or not resp_cont.text:
                        continue
                    _save_raw_response(output_dir, resp_cont.text, suffix=f'_pass2_cont{cont_attempt}')
                    cont_montage2 = {'clips': cont_clips}
                    cont_res = self._parse_prompts_only(resp_cont.text, output_dir, cont_montage2, project_name)
                    cont_path = cont_res.get('prompts')
                    if cont_path and cont_path.exists():
                        if chunk_path is None or not chunk_path.exists():
                            chunk_path = cont_path
                            chunk_prompts = len([c.strip() for c in chunk_path.read_text(encoding='utf-8').split('\n\n') if c.strip()])
                        else:
                            cont_text = cont_path.read_text(encoding='utf-8').strip()
                            with open(chunk_path, 'a', encoding='utf-8') as f:
                                f.write('\n\n' + cont_text)
                            cont_path.unlink()
                            chunk_prompts = len([c.strip() for c in chunk_path.read_text(encoding='utf-8').split('\n\n') if c.strip()])
                        print(f"   → Итого: {chunk_prompts} / {len(chunk_clips)}")

            # Аккумуляция в основной файл
            if chunk_path and chunk_path.exists() and chunk_prompts > 0:
                if main_prompts_path is None:
                    main_prompts_path = chunk_path
                    total_prompts = chunk_prompts
                else:
                    chunk_text = chunk_path.read_text(encoding='utf-8').strip()
                    with open(main_prompts_path, 'a', encoding='utf-8') as f:
                        f.write('\n\n' + chunk_text)
                    chunk_path.unlink()
                    total_prompts = len([c.strip() for c in main_prompts_path.read_text(encoding='utf-8').split('\n\n') if c.strip()])

            cursor += chunk_prompts
            chunk_idx += 1

            if chunk_prompts == 0:
                print(f"\n❌ Чанк {chunk_idx} вернул 0 промптов — прерывание")
                break

        results = {
            'prompts': main_prompts_path,
            'num_prompts': total_prompts,
            'num_clips': total_clips,
        }
        return results, all_costs

    # =========================================================================
    # ФОРМИРОВАНИЕ ПРОМПТОВ
    # =========================================================================

    def _load_sys_instr(self, script_type: str) -> str:
        """Загружает и подставляет плейсхолдеры в system instruction."""
        prompts_dir = Path(__file__).parent.parent / 'prompts'
        fname = 'script_director_prose.txt' if script_type == 'prose' else 'script_director_screenplay.txt'
        with open(prompts_dir / fname, 'r', encoding='utf-8') as f:
            sys_instr = (f.read()
                .replace('{clip_min_dur}',      str(config.ACTIVE_CLIP_MIN_DURATION))
                .replace('{clip_max_dur}',      str(config.ACTIVE_CLIP_MAX_DURATION))
                .replace('{clip_intro_max_dur}',str(config.get_intro_clip_max()))
                .replace('{clip_intro_min_dur}',str(config.get_intro_clip_min()))
                .replace('{intro_block_dur}',   str(config.INTRO_BLOCK_DURATION))
            )
        from modules.infographic_markup import infographic_markup_directive
        return sys_instr + infographic_markup_directive()

    def _create_prompt_one_pass(
        self,
        script_text: str,
        style_guide: str,
        project_name: str,
        script_type: str,
    ) -> Tuple[str, str]:
        sys_instr = self._load_sys_instr(script_type)
        if getattr(config, 'INFOGRAPHIC_ENABLED', False):
            from modules.infographic_markup import default_infographic_style
            sys_instr += (
                "\nFor clips marked source=\"infographic\", create a static information graphic. "
                "Use this fallback only when the style guide has no infographic section:\n"
                f"{default_infographic_style()}\n"
                "Do not use camera movement language for infographic prompts.\n"
            )
        user_content = f"""## ВХОДНЫЕ ДАННЫЕ

# ПРОЕКТ: {project_name}

# ВИЗУАЛЬНЫЙ СТИЛЬ
{style_guide}

# СЦЕНАРИЙ
{script_text}

---

Верни ответ ТОЛЬКО в формате:
```json
{{"montage_plan": ...}}
```
```text
=== PROMPTS.TXT ===
[промпт 1]

[промпт 2]
...
```
"""
        return sys_instr, user_content

    def _create_prompt_pass1(
        self,
        script_text: str,
        style_guide: str,
        project_name: str,
        script_type: str,
    ) -> Tuple[str, str]:
        sys_instr = self._load_sys_instr(script_type)
        user_content = f"""## ВХОДНЫЕ ДАННЫЕ

# ПРОЕКТ: {project_name}

# СЦЕНАРИЙ
{script_text}

---

Верни ТОЛЬКО JSON монтажный план. Промпты будут запрошены отдельно.
"""
        return sys_instr, user_content

    def _create_prompt_chunk(
        self,
        chunk_clips: list,
        style_guide: str,
        from_id: int,
        to_id: int,
        total_clips: int,
        is_continuation: bool = False,
        already_done: int = 0,
        prev_sample: Optional[list] = None,
        prev_plot_context: Optional[str] = None,
    ) -> str:
        n = len(chunk_clips)
        clips_json = json.dumps({'clips': chunk_clips}, ensure_ascii=False)
        from modules.infographic_markup import infographic_pass2_directive
        _infographic_ids = [str(c['id']) for c in chunk_clips if c.get('source') == 'infographic']
        infographic_rule = (
            "\n[INFOGRAPHIC CLIP IDS]\n" + ', '.join(_infographic_ids)
            + infographic_pass2_directive()
            if _infographic_ids else ''
        )

        # Маппинг: клип → description из montage_plan
        clip_lines = [
            f"Клип {c['id']} ({c.get('startTime',0):.1f}-{c.get('endTime',0):.1f}с): {c.get('description','—')}"
            for c in chunk_clips
        ]
        clip_mapping = '\n'.join(clip_lines)

        if is_continuation:
            header = (
                f"Ты режиссёр визуального контента. Ты уже написал Veo3-промпты для клипов 1–{already_done}.\n"
                f"Теперь напиши промпты для оставшихся клипов {from_id}–{to_id}."
            )
        elif from_id == 1 and to_id == total_clips:
            header = "Ты режиссёр визуального контента. На первом проходе ты создал монтажный план.\nТеперь напиши Veo3-промпты для каждого клипа."
        else:
            header = (
                f"Ты режиссёр визуального контента. На первом проходе ты создал монтажный план.\n"
                f"Теперь напиши Veo3-промпты для клипов {from_id}–{to_id} (часть {from_id}–{to_id} из {total_clips})."
            )

        prev_plot_block = ""
        if prev_plot_context:
            prev_plot_block = f"""
# ПРЕДЫДУЩИЙ СЮЖЕТ (уже визуализировано — соблюдай консистентность персонажей и деталей)
{prev_plot_context}

"""

        prev_sample_block = ""
        if prev_sample:
            sample_lines = '\n\n'.join(prev_sample)
            prev_sample_block = f"""
# ПРИМЕРЫ СТИЛЯ (последние промпты — для консистентности)
Продолжай в том же формате и стиле:
{sample_lines}

"""

        return f"""{header}

# ВИЗУАЛЬНЫЙ СТИЛЬ
{style_guide}
{infographic_rule}
{prev_plot_block}{prev_sample_block}
# ДАННЫЕ КЛИПОВ {from_id}–{to_id}
```json
{clips_json}
```

# СОДЕРЖАНИЕ КАЖДОГО КЛИПА (из description монтажного плана)
{clip_mapping}

---

ВИЗУАЛЬНОЕ РАЗНООБРАЗИЕ — ОБЯЗАТЕЛЬНО:
- Если содержание текущей сцены похоже на предыдущую (похожая локация, действие, персонажи) — ОБЯЗАТЕЛЬНО смени ракурс: wide→close-up, другой угол, другой план.
- НИКОГДА не повторяй одинаковый визуальный образ для двух соседних клипов.
- Чередуй: общий план (Wide) → средний (Medium) → крупный (Close-up) → обратно.

Напиши ровно {n} промптов — по одному на каждый клип ({from_id}–{to_id}).
Каждый промпт — ОДНА СПЛОШНАЯ СТРОКА без переносов внутри.
Промпты разделяй ПУСТОЙ СТРОКОЙ.

Верни ответ ТОЛЬКО в этом формате:

```text
=== PROMPTS.TXT ===
[промпт для клипа {from_id}]

[промпт для клипа {from_id + 1 if n > 1 else from_id}]

...

[промпт для клипа {to_id}]
```

КРИТИЧЕСКИ ВАЖНО:
- Ровно {n} промптов
- Каждый промпт — ОДНА СТРОКА
- Разделяй ПУСТОЙ СТРОКОЙ между промптами
- НЕ добавляй нумерацию
"""

    def _create_prompt_pass2_chunk(
        self,
        montage_plan: dict,
        style_guide: str,
        from_id: int,
        to_id: int,
        already_done: int,
        prev_sample: Optional[list] = None,
    ) -> str:
        clips = [c for c in montage_plan.get('clips', [])
                 if c['id'] >= from_id and c['id'] <= to_id]
        return self._create_prompt_chunk(
            clips, style_guide, from_id, to_id, len(montage_plan.get('clips', [])),
            is_continuation=True, already_done=already_done, prev_sample=prev_sample
        )

    # =========================================================================
    # API ВЫЗОВ (зеркало из director.py)
    # =========================================================================

    def _make_api_call(
        self,
        prompt: str,
        pass2_mode: bool = False,
        spinner_msg: str = "Gemini думает",
        system_instruction: str = ''
    ) -> Tuple[Any, Optional[dict]]:
        generation_config = types.GenerateContentConfig(
            temperature=0.7,
            top_p=0.8,
            top_k=40,
            max_output_tokens=65536,
        )
        if system_instruction:
            generation_config.system_instruction = system_instruction

        model_lower = self.model_name.lower()
        if 'gemini-3' in model_lower:
            is_flash = 'flash' in model_lower
            is_3_1 = '3.1' in model_lower
            if is_flash or is_3_1:
                level_map = {'low': 'low', 'medium': 'medium', 'high': 'high'}
                default = 'medium'
            else:
                level_map = {'low': 'low', 'medium': 'high', 'high': 'high'}
                default = 'high'
            if pass2_mode:
                raw_level = config.GEMINI_THINKING_LEVEL_PASS2 or 'low'
            else:
                raw_level = config.GEMINI_THINKING_LEVEL or default
            thinking_level = level_map.get(raw_level, default)
            generation_config.thinking_config = types.ThinkingConfig(thinking_level=thinking_level)
            print(f"   Thinking Level: {thinking_level} (Gemini 3.x)")
        elif 'gemini-2' in model_lower:
            if pass2_mode:
                if config.GEMINI_THINKING_BUDGET_PASS2 > 0:
                    thinking_budget = config.GEMINI_THINKING_BUDGET_PASS2
                else:
                    thinking_budget = 8000 if '2.5-pro' in model_lower else 0
            elif config.GEMINI_THINKING_BUDGET > 0:
                thinking_budget = config.GEMINI_THINKING_BUDGET
            elif '2.5-pro' in model_lower:
                budget_map = {'low': 10000, 'medium': 20000, 'high': 32768}
                thinking_budget = budget_map.get(config.GEMINI_THINKING_LEVEL, 20000)
            else:
                budget_map = {'low': 1024, 'medium': 8192, 'high': 24576}
                thinking_budget = budget_map.get(config.GEMINI_THINKING_LEVEL, 8192)
            generation_config.thinking_config = types.ThinkingConfig(thinking_budget=thinking_budget)
            print(f"   Thinking Budget: {thinking_budget:,} токенов (Gemini 2.x)")

        max_retries = 3
        retry_delays = [30, 60, 120]
        last_error = None
        response = None
        for attempt in range(max_retries + 1):
            msg = spinner_msg if attempt == 0 else f"{spinner_msg} (попытка {attempt + 1}/{max_retries + 1})"
            try:
                response = _run_with_spinner(
                    self.client.models.generate_content,
                    message=msg,
                    model=self.model_name,
                    contents=prompt,
                    config=generation_config,
                )
                break
            except Exception as e:
                err_str = str(e)
                is_503 = '503' in err_str or 'UNAVAILABLE' in err_str.upper()
                is_disconnect = (
                    'RemoteProtocolError' in type(e).__name__ or
                    'Server disconnected' in err_str or
                    'RemoteDisconnected' in err_str
                )
                if (is_503 or is_disconnect) and attempt < max_retries:
                    reason = "503 UNAVAILABLE" if is_503 else "Server disconnected"
                    delay = retry_delays[attempt]
                else:
                    raise
                logging.warning(f"Script director API: {reason} (попытка {attempt + 1}): {e}")
                print(f"\n   ⚠️  {reason}. Повтор через {delay}с...")
                for remaining in range(delay, 0, -1):
                    sys.stdout.write(f'\r   ⏳ Ожидание: {remaining}с   ')
                    sys.stdout.flush()
                    time.sleep(1)
                sys.stdout.write('\r' + ' ' * 40 + '\r')
                sys.stdout.flush()
                last_error = e
        if response is None:
            raise last_error

        cost_info = None
        um = getattr(response, 'usage_metadata', None)
        if um is not None:
            input_tokens    = getattr(um, 'prompt_token_count',     0) or 0
            output_tokens   = getattr(um, 'candidates_token_count', 0) or 0
            thinking_tokens = getattr(um, 'thoughts_token_count',   0) or 0
            self.input_tokens  = input_tokens
            self.output_tokens = output_tokens
            total_output_tokens = output_tokens + thinking_tokens
            cost_estimate = config.estimate_cost(input_tokens, total_output_tokens, self.model_name)
            pricing = config.get_model_pricing(self.model_name)
            thinking_cost    = (thinking_tokens / 1_000_000) * pricing['output']
            output_cost_only = (output_tokens   / 1_000_000) * pricing['output']
            cost_info = {
                'input_tokens':        input_tokens,
                'output_tokens':       output_tokens,
                'thinking_tokens':     thinking_tokens,
                'total_output_tokens': total_output_tokens,
                'input_cost':          cost_estimate['input_cost'],
                'output_cost':         output_cost_only,
                'thinking_cost':       thinking_cost,
                'total_cost':          cost_estimate['total_cost'],
            }
        if cost_info:
            logging.info(
                f"Script director API OK | in={cost_info['input_tokens']:,} "
                f"out={cost_info['output_tokens']:,} "
                f"think={cost_info['thinking_tokens']:,} "
                f"cost=${cost_info['total_cost']:.4f}"
            )

        if not getattr(response, 'text', None):
            try:
                candidates = getattr(response, 'candidates', []) or []
                for i, cand in enumerate(candidates):
                    fr = getattr(cand, 'finish_reason', None)
                    logging.warning(f"Script director empty text: candidate[{i}] finish_reason={fr}")
                    print(f"   ⚠️  finish_reason={fr}")
            except Exception:
                pass

        return response, cost_info

    # =========================================================================
    # ПАРСИНГ
    # =========================================================================

    def _parse_json_only(
        self,
        response_text: str,
        output_dir: Path,
        transcription: Dict[str, Any],
        pass_num: Optional[int] = None
    ) -> dict:
        """Парсит JSON из ответа. Возвращает montage_plan dict (без audioDuration)."""
        output_dir.mkdir(parents=True, exist_ok=True)
        montage_plan = {}

        montage_plan_match = re.search(r'\{.*?"clips"\s*:', response_text, re.DOTALL)
        if not montage_plan_match:
            code_block_match = re.search(
                r'```json\s*\n?\s*(\{[^`]*?"clips"[^`]*?\})\s*```?',
                response_text, re.DOTALL
            )
            if code_block_match:
                montage_plan_match = code_block_match

        if montage_plan_match:
            json_text = montage_plan_match.group(1) if montage_plan_match.lastindex else montage_plan_match.group(0)
            if not montage_plan_match.lastindex:
                start = response_text.find('{')
                depth = 0
                end = -1
                for i in range(start, len(response_text)):
                    ch = response_text[i]
                    if ch == '{': depth += 1
                    elif ch == '}':
                        depth -= 1
                        if depth == 0:
                            end = i
                            break
                if end >= start:
                    json_text = response_text[start:end + 1]
                else:
                    json_text = response_text[start:]
                    last_complete = json_text.rfind('},')
                    if last_complete > 0:
                        json_text = json_text[:last_complete + 2].rstrip(',') + ']\n'
                    open_braces  = json_text.count('{')
                    close_braces = json_text.count('}')
                    missing = open_braces - close_braces
                    if missing > 0:
                        json_text = json_text + ('}\n' * missing)

            try:
                data = json.loads(json_text)
                if "montage_plan" in data:
                    montage_plan = data["montage_plan"]
                else:
                    montage_plan = data
            except json.JSONDecodeError as e:
                logging.error(f"Script director JSON parse error: {e}")
                raise

            # Normalize file paths to vid_img/N.mp4
            clips = montage_plan.get('clips', [])
            for clip in clips:
                cid = clip.get('id', 0)
                if 'file' not in clip or not clip['file']:
                    clip['file'] = f'vid_img/{cid}.mp4'
                elif not clip['file'].startswith('vid_img/'):
                    clip['file'] = f'vid_img/{cid}.mp4'

            # Validate ID sequence
            id_problems = check_clip_id_sequence(clips)
            if id_problems:
                print(f"\n⚠️  Сбой нумерации ({len(id_problems)} позиций) — перенумерация...")
                for i, clip in enumerate(clips):
                    clip['id']   = i + 1
                    clip['file'] = f'vid_img/{i + 1}.mp4'
                print(f"   ✓ Перенумерация: 1..{len(clips)}")
                montage_plan['clips'] = clips

            output_path = output_dir / 'montage_plan.json'
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(montage_plan, f, ensure_ascii=False, indent=2)

            num = len(clips)
            label = f" (проход {pass_num})" if pass_num else ""
            print(f"   ✓ montage_plan.json{label} — {num} клипов")
        else:
            print("\n⚠️  Не найден montage_plan в ответе!")

        return montage_plan

    def _parse_prompts_only(
        self,
        response_text: str,
        output_dir: Path,
        montage_plan: dict,
        project_name: str,
    ) -> Dict[str, Any]:
        """Парсит промпты из ответа."""
        output_dir.mkdir(parents=True, exist_ok=True)
        results = {}
        raw_prompts = None

        prompts_match = re.search(
            r'=== PROMPTS\.TXT ===\s*\n(.*?)$',
            response_text, re.DOTALL
        )
        if prompts_match:
            raw_prompts = prompts_match.group(1).strip()
            raw_prompts = re.sub(r'\n```\s*$', '', raw_prompts).strip()

        if not raw_prompts:
            json_end_match = re.search(r'```\s*\n+(.*)', response_text, re.DOTALL)
            if json_end_match:
                candidate = json_end_match.group(1).strip()
                candidate = re.sub(r'^=== PROMPTS\.TXT ===\s*\n', '', candidate)
                candidate = re.sub(r'\n```\s*$', '', candidate).strip()
                if candidate:
                    raw_prompts = candidate

        if raw_prompts:
            chunks = [c.strip() for c in raw_prompts.split('\n\n') if c.strip()]
            prompt_list = [c for c in chunks if not c.startswith('```')]

            num_clips = len(montage_plan.get('clips', []))

            if num_clips > 0 and len(prompt_list) < num_clips:
                _fixed = []
                for p in prompt_list:
                    if '\n' in p:
                        sub_parts = [s.strip() for s in p.split('\n') if s.strip()]
                        long_parts = [s for s in sub_parts if len(s) > 100]
                        if len(long_parts) > 1:
                            _fixed.extend(long_parts)
                            continue
                    _fixed.append(p)
                if len(_fixed) != len(prompt_list):
                    prompt_list = _fixed

            overprompt = num_clips > 0 and len(prompt_list) > num_clips
            if overprompt:
                extra = len(prompt_list) - num_clips
                print(f"\n⚠️  OVERPROMPT: {len(prompt_list)} промптов, ожидалось {num_clips} (+{extra} лишних)")

            if num_clips > 0 and len(prompt_list) < num_clips:
                missing = num_clips - len(prompt_list)
                print(f"\n⚠️  ВНИМАНИЕ: {len(prompt_list)} промптов, клипов {num_clips} (недостаёт {missing})")

            prompts_text = '\n\n'.join(prompt_list)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            overprompt_tag = '_OVERPROMPT' if overprompt else ''
            prompts_filename = f'{project_name}_prompts_{timestamp}{overprompt_tag}.txt'
            output_path = output_dir / prompts_filename
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(prompts_text)
            results['prompts'] = output_path
            results['num_prompts'] = len(prompt_list)
            results['num_clips'] = num_clips
            print(f"   ✓ {prompts_filename} ({len(prompt_list)} промптов)")
        else:
            logging.warning("Script director: prompts block not found in response")
            print("\n[WARN] Prompts block not found in response")

        return results

    # =========================================================================
    # ВСПОМОГАТЕЛЬНЫЕ: стоимость и логи
    # =========================================================================

    def _print_cost(self, cost_info: Optional[dict], label: str = ""):
        print()
        if cost_info:
            header = f"💰 Стоимость {label} ({self.model_name}):" if label else f"💰 Стоимость ({self.model_name}):"
            print(header)
            print(f"   Input:              {cost_info['input_tokens']:>8,} токенов  = ${cost_info['input_cost']:.5f}")
            print(f"   Output (text):      {cost_info['output_tokens']:>8,} токенов  = ${cost_info['output_cost']:.5f}")
            if cost_info.get('thinking_tokens'):
                print(f"   Output (thinking):  {cost_info['thinking_tokens']:>8,} токенов  = ${cost_info['thinking_cost']:.5f}")
            total = cost_info['total_cost']
            suffix = "  (менее 1 цента)" if total < 0.01 else ""
            print(f"   {'─' * 52}")
            print(f"   ИТОГО:                                    ${total:.5f}{suffix}")
        else:
            print("⚠️  usage_metadata недоступен — стоимость неизвестна")

    def _write_token_log(self, cost_info: dict, output_dir: Path, project_name: str,
                         num_prompts: int = 0, num_clips: int = 0):
        output_dir.mkdir(parents=True, exist_ok=True)
        output_total_cost = cost_info['output_cost'] + cost_info['thinking_cost']
        prompts_line = f"Промптов создано:       {num_prompts} / {num_clips}\n" if num_clips > 0 else ""
        token_report = f"""
================================================================================
ОТЧЁТ ОБ ИСПОЛЬЗОВАНИИ ТОКЕНОВ (Script Director)
================================================================================
Проект: {project_name}
Модель: {self.model_name}
Дата: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
{prompts_line}
ТОКЕНЫ:
  Input:                  {cost_info['input_tokens']:>10,}   = ${cost_info['input_cost']:.5f}
  Output (text):          {cost_info['output_tokens']:>10,}   = ${cost_info['output_cost']:.5f}
  Output (thinking):      {cost_info['thinking_tokens']:>10,}   = ${cost_info['thinking_cost']:.5f}
  ─────────────────────────────────────────────────
  Output всего:           {cost_info['total_output_tokens']:>10,}   = ${output_total_cost:.5f}
  ─────────────────────────────────────────────────
  ИТОГО:                                          ${cost_info['total_cost']:.5f}
================================================================================
"""
        log_path = output_dir / f'{project_name}_log.txt'
        with open(log_path, 'w', encoding='utf-8', errors='replace') as f:
            f.write(token_report)

        try:
            from modules.queue import append_run_log
            append_run_log(output_dir, project_name, 'SCRIPT_DIRECTOR', {
                'Модель:':       self.model_name,
                'Клипов:':       num_clips,
                'Промптов:':     f'{num_prompts} / {num_clips}' if num_clips else num_prompts,
                'Input токены:': f"{cost_info['input_tokens']:,}   = ${cost_info['input_cost']:.5f}",
                'Output токены:':f"{cost_info['total_output_tokens']:,}   = ${output_total_cost:.5f}",
                'ИТОГО:':        f"${cost_info['total_cost']:.5f}",
            })
        except Exception:
            pass

    def _update_cost_log(self, cost_info: dict, project_name: str) -> dict:
        log_path = Path(__file__).parent.parent / 'cost_log.json'
        key_id = self.api_key[-8:] if len(self.api_key) >= 8 else self.api_key
        if log_path.exists():
            with open(log_path, 'r', encoding='utf-8') as f:
                log_data = json.load(f)
        else:
            log_data = {}
        if key_id not in log_data:
            log_data[key_id] = {'api_key_id': key_id, 'total_cost': 0.0, 'total_runs': 0, 'runs': []}
        entry = log_data[key_id]
        entry['runs'].append({
            'timestamp':      datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'project':        project_name,
            'model':          self.model_name,
            'cost':           cost_info['total_cost'],
            'input_tokens':   cost_info['input_tokens'],
            'output_tokens':  cost_info['output_tokens'],
            'thinking_tokens':cost_info.get('thinking_tokens', 0),
        })
        entry['total_cost'] = round(entry['total_cost'] + cost_info['total_cost'], 8)
        entry['total_runs'] += 1
        with open(log_path, 'w', encoding='utf-8') as f:
            json.dump(log_data, f, ensure_ascii=False, indent=2)
        return entry

    def _finalize_costs(self, all_costs: list, output_dir: Path, project_name: str,
                        num_prompts: int, num_clips: int, results: dict):
        n_passes = len(all_costs)
        if n_passes >= 2:
            keys = ['input_tokens','output_tokens','thinking_tokens','total_output_tokens',
                    'input_cost','output_cost','thinking_cost','total_cost']
            total_cost = {k: sum(c.get(k, 0) for c in all_costs) for k in keys}
            label = f"ИТОГО за {n_passes} прохода"
            self._print_cost(total_cost, label=label)
        elif n_passes == 1:
            total_cost = all_costs[0]
        else:
            return

        self._write_token_log(total_cost, output_dir, project_name,
                              num_prompts=num_prompts, num_clips=num_clips)
        cumulative = self._update_cost_log(total_cost, project_name)
        key_id = self.api_key[-8:] if len(self.api_key) >= 8 else self.api_key
        print(f"\n📊 Затраты по ключу ...{key_id} ({self.model_name}):")
        print(f"   Этот прогон:    ${total_cost['total_cost']:.5f}")
        print(f"   Прогонов всего: {cumulative['total_runs']}")
        print(f"   {'─' * 40}")
        print(f"   НАКОПЛЕНО:      ${cumulative['total_cost']:.5f}")
        results['cost'] = total_cost
