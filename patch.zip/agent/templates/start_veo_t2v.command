#!/bin/bash
# START_VEO_T2V.COMMAND - VeoNonStop Text-to-Video (t2v)
# Run: double-click this file in Finder

PROJECT_NAME="{project_name}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
AGENT_DIR="$(cd "$SCRIPT_DIR/../../agent" && pwd)"

chmod +x *.command *.sh 2>/dev/null

if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e "tell app \"Terminal\" to do script \"cd '$SCRIPT_DIR' && exec '$0'\""
    exit 0
fi

echo ""
echo "========================================================================"
echo "  VeoNonStop TEXT-TO-VIDEO (t2v)"
echo "  Project: $PROJECT_NAME"
echo "========================================================================"
echo ""

# Aspect ratio
echo "  Select aspect ratio:"
echo "    [1] 16:9   landscape, default"
echo "    [2] 9:16   portrait"
echo "    [3] 1:1    square"
echo ""
read -p "  Aspect [1/2/3] (Enter = 1): " RATIO_CHOICE
RATIO="16:9"
case "$RATIO_CHOICE" in
    2) RATIO="9:16" ;;
    3) RATIO="1:1" ;;
esac
echo "    Selected: $RATIO"
echo ""

# Parallel
read -p "  Parallel [1-24] (Enter = 12): " PARALLEL
PARALLEL="${PARALLEL:-12}"
echo "    Selected: $PARALLEL"
echo ""

# Clip IDs
read -p "  Clip IDs (e.g. 1,2,3 or Enter for all): " IDS_INPUT
IDS_ARG=""
if [ -n "$IDS_INPUT" ]; then
    IDS_ARG="--ids $IDS_INPUT"
    echo "    Clips: $IDS_INPUT"
else
    echo "    Clips: ALL"
fi
echo ""

# Prompt source
echo "  Prompt source:"
echo "    [1] Director prompts (per-clip)"
echo "    [2] Single prompt for all clips"
echo ""
read -p "  Prompt [1/2] (Enter = 1): " PROMPT_CHOICE
PROMPT_ARG=""
if [ "$PROMPT_CHOICE" = "2" ]; then
    read -p "  Enter prompt: " PROMPT_INPUT
    if [ -n "$PROMPT_INPUT" ]; then
        PROMPT_ARG="--prompt \"$PROMPT_INPUT\""
        echo "    Prompt: single"
    else
        echo "    Prompt: per-clip"
    fi
else
    echo "    Prompt: per-clip"
fi
echo ""

# Confirm
echo "========================================================================"
echo "  SUMMARY:"
echo "    Project:  $PROJECT_NAME"
echo "    Mode:     t2v (text-to-video)"
echo "    Ratio:    $RATIO"
echo "    Parallel: $PARALLEL"
echo "========================================================================"
echo ""
read -p "  Start? (y/n): " CONFIRM
if [ "$CONFIRM" != "y" ] && [ "$CONFIRM" != "Y" ]; then
    echo "  Cancelled."
    exit 0
fi

echo ""
echo "  Starting text-to-video..."
echo ""

cd "$AGENT_DIR"

eval python agent.py img2video \
    --project "$PROJECT_NAME" \
    --mode "t2v" \
    --ratio "$RATIO" \
    --parallel "$PARALLEL" $IDS_ARG $PROMPT_ARG

EXIT_CODE=$?
echo ""
if [ $EXIT_CODE -ne 0 ]; then
    echo "[ERROR] t2v generation failed. See log above."
else
    echo "========================================================================"
    echo "  DONE. Output: $SCRIPT_DIR/vid_img/"
    echo "========================================================================"
fi
echo ""
read -p "Press Enter to close..."
