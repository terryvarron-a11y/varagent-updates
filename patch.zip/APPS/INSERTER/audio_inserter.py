"""
Audio Inserter — вклейка аудиотрека в видео без перекодирования видео.

Видео-поток копируется (-c:v copy), аудио миксуется через filter_complex
(переэнкодится в AAC — иначе вклейку сделать нельзя).

Зависимости: только stdlib + ffmpeg в PATH.
"""

import os
import array
import random
import json
import re
import colorsys
import random
import shutil
import subprocess
import sys
import threading
import tempfile
import tkinter as tk
from datetime import datetime, timedelta, timezone
from tkinter import filedialog, messagebox, ttk

APP_BUILD = "2026-06-03-mix-timing-volume"

try:
    from PIL import Image, ImageDraw, ImageFont, ImageTk
    _PIL_OK = True
except Exception:
    _PIL_OK = False


def probe_duration(path: str) -> float:
    """Возвращает длительность файла в секундах через ffprobe. 0.0 если не удалось."""
    try:
        creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        r = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", path],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            creationflags=creationflags,
        )
        return float(r.stdout.strip())
    except Exception:
        return 0.0


def human_size(num_bytes: int | float) -> str:
    try:
        n = float(num_bytes)
    except (TypeError, ValueError):
        return "?"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024.0 or unit == "TB":
            return f"{n:.1f} {unit}" if unit != "B" else f"{int(n)} B"
        n /= 1024.0
    return f"{n:.1f} TB"


def probe_media(path: str) -> dict:
    """Возвращает ffprobe JSON по потокам/формату.
    Запрашиваем расширенный список полей: profile, level, bitrate, color, b-frames,
    channel_layout, time_base — всё что нужно для точного матчинга при перекодировании insert."""
    creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    r = subprocess.run(
        [
            "ffprobe", "-v", "error",
            "-show_entries",
            "format=duration:stream=index,codec_type,codec_name,profile,level,bit_rate,"
            "width,height,pix_fmt,avg_frame_rate,r_frame_rate,time_base,"
            "color_range,color_space,color_transfer,color_primaries,field_order,"
            "has_b_frames,sample_rate,channels,channel_layout,sample_fmt",
            "-of", "json",
            path,
        ],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        creationflags=creationflags,
    )
    if r.returncode != 0:
        raise RuntimeError((r.stderr or "ffprobe failed").strip())
    return json.loads(r.stdout or "{}")


def first_stream(info: dict, codec_type: str) -> dict | None:
    for stream in info.get("streams", []):
        if stream.get("codec_type") == codec_type:
            return stream
    return None


def build_video_encode_args(main_video_stream: dict, fps_arg: str, pix_fmt: str,
                            v_encoder: str, v_extra: list) -> list:
    """Сборка ffmpeg -c:v + параметров с честным матчингом ИЗ ffprobe оригинала:
    profile / level / bitrate / GOP / CFR-VFR / color params / field_order.
    Каждый флаг — копия соответствующего поля исходника (не наугад)."""
    args = ["-c:v", v_encoder, *v_extra, "-pix_fmt", pix_fmt, "-r", fps_arg, "-preset", "fast"]

    # Profile (libx264/libx265)
    prof = (main_video_stream.get("profile") or "").lower()
    profile_arg = None
    if v_encoder == "libx264":
        if "high 4:4:4" in prof: profile_arg = "high444"
        elif "high 4:2:2" in prof: profile_arg = "high422"
        elif "high 10" in prof: profile_arg = "high10"
        elif "high" in prof: profile_arg = "high"
        elif "main" in prof: profile_arg = "main"
        elif "baseline" in prof: profile_arg = "baseline"
    elif v_encoder == "libx265":
        if "main 10" in prof: profile_arg = "main10"
        elif "main 4:4:4" in prof: profile_arg = "main444-8"
        elif "main" in prof: profile_arg = "main"
    if profile_arg:
        args += ["-profile:v", profile_arg]

    # Level (ffprobe: "41" → ffmpeg "-level:v 41")
    level_raw = main_video_stream.get("level")
    try:
        level_int = int(level_raw)
        if level_int > 0:
            args += ["-level:v", str(level_int)]
    except (TypeError, ValueError):
        pass

    # Bitrate + ratecontrol. Fallback на CRF=18 если bitrate не доступен.
    bitrate_raw = main_video_stream.get("bit_rate")
    try:
        br_int = int(bitrate_raw)
        if br_int > 0:
            args += ["-b:v", str(br_int),
                     "-maxrate", str(int(br_int * 1.5)),
                     "-bufsize", str(int(br_int * 2))]
        else:
            args += ["-crf", "18"]
    except (TypeError, ValueError):
        args += ["-crf", "18"]

    # GOP/keyframe interval ~fps*2 (без -x264-params/x265-params которые ломают timestamps).
    try:
        fps_num, _ = parse_fps(fps_arg)
        if fps_num > 0:
            gop = max(1, int(round(fps_num * 2)))
            args += ["-g", str(gop), "-keyint_min", str(gop), "-sc_threshold", "0"]
    except Exception:
        pass

    # CFR vs VFR: если avg_frame_rate ≈ r_frame_rate → CFR. Иначе VFR.
    # ffprobe выдаёт оба поля как "N/D" строки.
    def _rate_to_float(s):
        if not s or "/" not in str(s):
            return None
        try:
            n, d = str(s).split("/")
            d = float(d)
            return float(n) / d if d > 0 else None
        except Exception:
            return None
    avg_f = _rate_to_float(main_video_stream.get("avg_frame_rate"))
    r_f = _rate_to_float(main_video_stream.get("r_frame_rate"))
    if avg_f is not None and r_f is not None and avg_f > 0 and r_f > 0:
        # Допуск 0.5% — типичные CFR файлы дают идеальное совпадение, VFR расходится сильнее.
        if abs(avg_f - r_f) / max(avg_f, r_f) < 0.005:
            args += ["-fps_mode", "cfr"]
        else:
            args += ["-fps_mode", "vfr"]

    # Color metadata — критично для color matching на стыке (особенно для HDR/Rec.2020)
    color_range = main_video_stream.get("color_range")
    if color_range in ("tv", "pc"):
        args += ["-color_range", color_range]
    color_space = main_video_stream.get("color_space")
    if color_space and color_space not in ("unknown", "reserved"):
        args += ["-colorspace", color_space]
    color_transfer = main_video_stream.get("color_transfer")
    if color_transfer and color_transfer not in ("unknown", "reserved"):
        args += ["-color_trc", color_transfer]
    color_primaries = main_video_stream.get("color_primaries")
    if color_primaries and color_primaries not in ("unknown", "reserved"):
        args += ["-color_primaries", color_primaries]

    # Field order (progressive vs interlaced). У 99% mp4 фильмов = progressive.
    field_order = main_video_stream.get("field_order")
    if field_order == "progressive":
        # для libx264 progressive — дефолт, явно не указываем (иначе warning).
        pass
    elif field_order in ("tt", "bb", "tb", "bt"):
        # Interlaced — оставляем дефолт энкодера; форсить interlaced при перекодировании
        # без явного запроса юзера = плохая идея (можем испортить чистый прогрессив).
        pass

    return args


def build_audio_encode_args(main_audio_stream: dict, a_encoder: str,
                            sample_rate: str, channels: str, fallback_bitrate: str = "192k") -> list:
    """Сборка ffmpeg -c:a с честным матчингом ИЗ ffprobe оригинала:
    bitrate / sample_rate / channels / channel_layout / profile / sample_fmt."""
    args = ["-c:a", a_encoder]

    # Bitrate (например 128000) → -b:a 128000. Fallback если не доступен.
    bitrate_raw = main_audio_stream.get("bit_rate")
    try:
        br_int = int(bitrate_raw)
        if br_int > 0:
            args += ["-b:a", str(br_int)]
        else:
            args += ["-b:a", fallback_bitrate]
    except (TypeError, ValueError):
        args += ["-b:a", fallback_bitrate]

    args += ["-ar", sample_rate, "-ac", channels]

    # Channel layout (stereo / 5.1 / 7.1 / mono) — для совпадения с before/after.
    ch_layout = main_audio_stream.get("channel_layout")
    if ch_layout and ch_layout not in ("unknown", "0 channels"):
        args += ["-channel_layout", ch_layout]

    # Profile (для AAC: LC / HE / HE-v2 / Main / LD). ffmpeg принимает aac_low/aac_he/...
    if a_encoder == "aac":
        prof_a = (main_audio_stream.get("profile") or "").strip()
        # ffprobe варианты: "LC", "HE-AAC", "HE-AACv2", "Main", "LD"
        prof_map = {
            "LC": "aac_low",
            "HE-AAC": "aac_he",
            "HE-AACv2": "aac_he_v2",
            "Main": "aac_main",
            "LD": "aac_ld",
            "ELD": "aac_eld",
        }
        if prof_a in prof_map:
            args += ["-profile:a", prof_map[prof_a]]

    # Sample format (fltp / s16 / s32p / ...) — формат сэмплов на входе в кодек.
    # AAC обычно требует fltp; mp3 — s16p. Если задано в оригинале — копируем.
    sample_fmt = main_audio_stream.get("sample_fmt")
    if sample_fmt and sample_fmt not in ("none", "unknown"):
        args += ["-sample_fmt", sample_fmt]

    return args


def find_keyframe_at_or_after(video_path: str, t: float, scan_window: float = 30.0) -> float | None:
    """Возвращает таймстамп первого video keyframe в окне [t .. t+scan_window], или None."""
    try:
        creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        cmd = [
            "ffprobe", "-v", "error",
            "-select_streams", "v:0",
            "-read_intervals", f"{max(0.0, t):.3f}%+{scan_window:.3f}",
            "-show_entries", "packet=pts_time,flags",
            "-of", "csv=p=0",
            video_path,
        ]
        r = subprocess.run(
            cmd, capture_output=True, text=True,
            encoding="utf-8", errors="replace", creationflags=creationflags,
        )
        for line in r.stdout.splitlines():
            parts = [p.strip() for p in line.split(",")]
            if len(parts) < 2:
                continue
            try:
                pts_time = float(parts[0])
            except ValueError:
                continue
            flags = parts[1]
            if "K" in flags and pts_time + 0.001 >= t:
                return pts_time
    except Exception:
        pass
    return None


def parse_fps(rate: str | None) -> tuple[float, str]:
    rate = (rate or "0/0").strip()
    if "/" in rate:
        a, b = rate.split("/", 1)
        try:
            num = float(a)
            den = float(b)
            if den > 0 and num > 0:
                return num / den, rate
        except Exception:
            pass
    try:
        value = float(rate)
        if value > 0:
            return value, rate
    except Exception:
        pass
    return 30.0, "30"


def concat_file_line(path: str) -> str:
    # ffmpeg concat demuxer accepts forward slashes on Windows and backslash-escaped quotes.
    normalized = os.path.abspath(path).replace("\\", "/").replace("'", "\\'")
    return f"file '{normalized}'"


def fake_metadata_args() -> list[str]:
    created = datetime.now(timezone.utc) - timedelta(
        days=random.randint(7, 720),
        seconds=random.randint(0, 86_399),
    )
    title = random.choice([
        "Sequence Export",
        "Final Render",
        "Edited Master",
        "Timeline Output",
        "Project Render",
    ])
    tool = random.choice([
        "Video Exporter",
        "Media Encoder",
        "Timeline Renderer",
        "NLE Export",
        "Render Service",
    ])
    comment = random.choice([
        "Edited video file",
        "Rendered media",
        "Timeline export",
        "Delivery master",
        "Processed video",
    ])
    return [
        "-map_metadata", "-1",
        "-metadata", f"title={title} {random.randint(1000, 9999)}",
        "-metadata", f"artist={tool}",
        "-metadata", f"comment={comment}",
        "-metadata", f"creation_time={created.strftime('%Y-%m-%dT%H:%M:%S.000000Z')}",
        "-metadata", f"encoded_by={tool}",
    ]


SILENCE_START_RE = re.compile(r"silence_start:\s*([0-9.]+)")
SILENCE_END_RE = re.compile(r"silence_end:\s*([0-9.]+)\s*\|\s*silence_duration:\s*([0-9.]+)")


def detect_silence_windows(
    path: str,
    center: float,
    radius: float,
    min_duration: float,
    noise_db: float,
    total_duration: float | None = None,
) -> list[tuple[float, float]]:
    window_start = max(0.0, center - radius)
    window_end = center + radius
    if total_duration and total_duration > 0:
        window_end = min(total_duration, window_end)
    if window_end <= window_start:
        return []

    creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    audio_filter = (
        f"atrim=start={window_start:.3f}:end={window_end:.3f},"
        f"asetpts=PTS-STARTPTS,"
        f"silencedetect=noise={noise_db}dB:d={min_duration:.3f}"
    )
    proc = subprocess.run(
        [
            "ffmpeg", "-hide_banner", "-nostats",
            "-i", path,
            "-vn",
            "-af", audio_filter,
            "-f", "null",
            "-",
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
        creationflags=creationflags,
    )
    if proc.returncode != 0:
        tail = ((proc.stderr or "") + "\n" + (proc.stdout or ""))[-2500:]
        raise RuntimeError(f"silencedetect failed\n\n{tail}")

    windows: list[tuple[float, float]] = []
    current_start: float | None = None
    for line in (proc.stderr or "").splitlines():
        start_match = SILENCE_START_RE.search(line)
        if start_match:
            current_start = window_start + float(start_match.group(1))
            continue

        end_match = SILENCE_END_RE.search(line)
        if end_match:
            end_abs = window_start + float(end_match.group(1))
            duration = float(end_match.group(2))
            start_abs = current_start if current_start is not None else end_abs - duration
            start_abs = max(window_start, start_abs)
            end_abs = min(window_end, end_abs)
            if end_abs - start_abs >= min_duration * 0.8:
                windows.append((start_abs, end_abs))
            current_start = None

    if current_start is not None and window_end - current_start >= min_duration * 0.8:
        windows.append((max(window_start, current_start), window_end))

    return windows


def choose_silence_cut(windows: list[tuple[float, float]], target: float) -> float | None:
    if not windows:
        return None

    def score(item: tuple[float, float]) -> tuple[float, float]:
        start, end = item
        if start <= target <= end:
            return (0.0, end - start)
        return (min(abs(target - start), abs(target - end)), -(end - start))

    start, end = min(windows, key=score)
    if start <= target <= end:
        return target
    return (start + end) / 2.0


def find_quietest_cut(
    path: str,
    center: float,
    radius: float,
    segment_duration: float,
    step: float,
    total_duration: float | None = None,
    sample_rate: int = 8000,
) -> float | None:
    """Find the center of the quietest local audio segment around a target point."""
    window_start = max(0.0, center - radius)
    window_end = center + radius
    if total_duration and total_duration > 0:
        window_end = min(total_duration, window_end)
    if window_end <= window_start:
        return None

    window_len = window_end - window_start
    creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    proc = subprocess.run(
        [
            "ffmpeg", "-hide_banner", "-loglevel", "error",
            "-ss", f"{window_start:.3f}",
            "-t", f"{window_len:.3f}",
            "-i", path,
            "-vn",
            "-ac", "1",
            "-ar", str(sample_rate),
            "-f", "s16le",
            "-",
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        creationflags=creationflags,
    )
    if proc.returncode != 0:
        tail = (proc.stderr or b"")[-2500:].decode("utf-8", errors="replace")
        raise RuntimeError(f"quiet-audio scan failed\n\n{tail}")

    samples = array.array("h")
    samples.frombytes(proc.stdout or b"")
    if sys.byteorder != "little":
        samples.byteswap()
    if not samples:
        return None

    segment_samples = max(1, int(round(segment_duration * sample_rate)))
    segment_samples = min(segment_samples, len(samples))
    step_samples = max(1, int(round(step * sample_rate)))
    limit = len(samples) - segment_samples

    prefix = [0]
    for sample in samples:
        prefix.append(prefix[-1] + sample * sample)

    positions = list(range(0, limit + 1, step_samples))
    if positions[-1] != limit:
        positions.append(limit)

    best_pos = 0
    best_energy: int | None = None
    target_offset = int(round((center - window_start) * sample_rate))
    for pos in positions:
        energy = prefix[pos + segment_samples] - prefix[pos]
        if best_energy is None or energy < best_energy:
            best_energy = energy
            best_pos = pos
        elif energy == best_energy:
            old_dist = abs((best_pos + segment_samples // 2) - target_offset)
            new_dist = abs((pos + segment_samples // 2) - target_offset)
            if new_dist < old_dist:
                best_pos = pos

    cut = window_start + (best_pos + segment_samples / 2.0) / sample_rate
    return max(window_start, min(window_end, cut))


# ---------- Цветокор-превью (палитра сэмплов) ----------
# Эталоны сгруппированы 3 ряда × 5 колонок: серая шкала / чистые цвета / реальные эталоны.
# Реагируют на все 19 цветокор-ползунков. Математика приближённая к ffmpeg (не точная):
# направление и силу изменений показывает корректно.

_PP_SAMPLES = [
    [("BG", (13, 13, 13)),   ("Темн", (64, 64, 64)),   ("Сред", (128, 128, 128)),
     ("Светл", (191, 191, 191)), ("Белый", (242, 242, 242))],
    [("Кр", (217, 38, 38)),  ("Зел", (38, 191, 64)),   ("Син", (38, 76, 217)),
     ("Циан", (38, 191, 191)), ("Маг", (217, 51, 178))],
    [("Кожа", (199, 148, 115)), ("Лист", (82, 128, 46)), ("Небо", (140, 178, 242)),
     ("Тёпл", (217, 166, 89)),  ("Тень", (46, 56, 89))],
]


def _pp_simulate_colorcorr(rgb, opts):
    """Применяет к (R,G,B) [0..255] весь цветокор-конвейер. Возвращает (R,G,B) [0..255].

    Порядок (как в ffmpeg-цепи): hue → colorbalance → eq (gamma per-channel + weight,
    brightness, contrast, saturation). Это приближение к ffmpeg — для UI-превью хватает."""
    r, g, b = rgb[0] / 255.0, rgb[1] / 255.0, rgb[2] / 255.0

    # 1. hue + hue_sat_mul
    hd = float(opts.get('hue_deg', 0) or 0)
    hs = float(opts.get('hue_sat_mul', 1) or 1)
    if abs(hd) > 0.001 or abs(hs - 1.0) > 0.001:
        h, s, v = colorsys.rgb_to_hsv(r, g, b)
        h = (h + hd / 360.0) % 1.0
        s = max(0.0, min(1.0, s * hs))
        r, g, b = colorsys.hsv_to_rgb(h, s, v)

    # 2. colorbalance — тональные маски (приближение к ffmpeg)
    luma = 0.2126 * r + 0.7152 * g + 0.0722 * b
    sw = max(0.0, 1.0 - 2.0 * luma)
    mw = 1.0 - abs(2.0 * luma - 1.0)
    hw = max(0.0, 2.0 * luma - 1.0)
    r += sw * float(opts.get('cb_shad_r', 0) or 0) + mw * float(opts.get('cb_mid_r', 0) or 0) + hw * float(opts.get('cb_high_r', 0) or 0)
    g += sw * float(opts.get('cb_shad_g', 0) or 0) + mw * float(opts.get('cb_mid_g', 0) or 0) + hw * float(opts.get('cb_high_g', 0) or 0)
    b += sw * float(opts.get('cb_shad_b', 0) or 0) + mw * float(opts.get('cb_mid_b', 0) or 0) + hw * float(opts.get('cb_high_b', 0) or 0)

    # 3. gamma per-channel + weight (комбинирую global × per-channel)
    gw = float(opts.get('gamma_weight', 1) or 1)
    g_glob = float(opts.get('gamma', 1) or 1)
    g_r = float(opts.get('gamma_r', 1) or 1) * g_glob
    g_g = float(opts.get('gamma_g', 1) or 1) * g_glob
    g_b = float(opts.get('gamma_b', 1) or 1) * g_glob
    def _gam(c, gp):
        c = max(0.0, c)
        if gp <= 0:
            return c
        c_corr = c ** (1.0 / gp)
        return (1.0 - gw) * c + gw * c_corr
    r, g, b = _gam(r, g_r), _gam(g, g_g), _gam(b, g_b)

    # 4. contrast
    c = float(opts.get('contrast', 1) or 1)
    r = (r - 0.5) * c + 0.5
    g = (g - 0.5) * c + 0.5
    b = (b - 0.5) * c + 0.5

    # 5. brightness
    br = float(opts.get('brightness', 0) or 0)
    r += br; g += br; b += br

    # 6. saturation
    s = float(opts.get('saturation', 1) or 1)
    if abs(s - 1.0) > 0.001:
        luma = 0.299 * r + 0.587 * g + 0.114 * b
        r = luma + (r - luma) * s
        g = luma + (g - luma) * s
        b = luma + (b - luma) * s

    r = max(0.0, min(1.0, r))
    g = max(0.0, min(1.0, g))
    b = max(0.0, min(1.0, b))
    return (int(round(r * 255)), int(round(g * 255)), int(round(b * 255)))


def _fmt_time_tag(seconds: float) -> str:
    """Тег времени для имени файла: '01h23m45s' (часы опускаются, если 0): '23m45s'.

    Используется чтобы юзер сразу видел точку вставки в имени файла."""
    total = max(0, int(round(seconds)))
    h = total // 3600
    m = (total % 3600) // 60
    s = total % 60
    if h > 0:
        return f"{h:02d}h{m:02d}m{s:02d}s"
    return f"{m:02d}m{s:02d}s"


def parse_time(s: str) -> float:
    """Принимает '12.5' или 'MM:SS(.ms)' или 'HH:MM:SS(.ms)'."""
    s = s.strip()
    if ":" in s:
        parts = s.split(":")
        if len(parts) == 2:
            return int(parts[0]) * 60 + float(parts[1])
        if len(parts) == 3:
            return int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])
        raise ValueError(f"Неверный формат времени: {s}")
    return float(s)


def ass_time(seconds: float) -> str:
    """ASS timestamp: H:MM:SS.cc."""
    centiseconds = max(0, int(round(seconds * 100)))
    hours = centiseconds // 360000
    minutes = (centiseconds // 6000) % 60
    secs = (centiseconds // 100) % 60
    cs = centiseconds % 100
    return f"{hours}:{minutes:02d}:{secs:02d}.{cs:02d}"


def timeline_timecode(seconds: float) -> str:
    """Позиция в итоговом видео для перемотки: H:MM:SS (если >= часа) или MM:SS."""
    total = max(0, int(round(seconds)))
    h = total // 3600
    m = (total % 3600) // 60
    s = total % 60
    if h > 0:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"


def ass_escape_text(text: str) -> str:
    return (text or "").replace("{", "(").replace("}", ")").replace("\n", r"\N")


def ffmpeg_filter_path(path: str) -> str:
    p = os.path.abspath(path).replace("\\", "/")
    # This string goes to ffmpeg as a direct subprocess arg, not through a shell.
    # Escape libavfilter separators for legacy filter path args.
    out = []
    for ch in p:
        if ch == ":":
            out.append("\\\\:")
        elif ch in "\\' ,[]=;":
            out.append("\\" + ch)
        else:
            out.append(ch)
    return "".join(out)


def choose_self_insert_start(cut_start: float, insert_duration: float, main_duration: float, source_side: str) -> float:
    """Pick a source-video segment near the insert point without scanning the whole movie."""
    cut_start = max(0.0, min(cut_start, max(0.0, main_duration)))
    insert_duration = max(0.1, insert_duration)
    latest = max(0.0, main_duration - insert_duration)

    if source_side == "after":
        if cut_start <= latest:
            return cut_start
        return max(0.0, min(cut_start - insert_duration, latest))

    if cut_start >= insert_duration:
        return max(0.0, min(cut_start - insert_duration, latest))
    if cut_start <= latest:
        return cut_start
    return max(0.0, min(cut_start, latest))


def pause_info_ass_layout(position: str, height: int) -> tuple[int, int]:
    key = (position or "center").strip().lower()
    aliases = {
        "top": "top", "up": "top", "upper": "top", "вверху": "top", "верх": "top", "сверху": "top",
        "center": "center", "middle": "center", "центр": "center", "по центру": "center",
        "bottom": "bottom", "down": "bottom", "lower": "bottom", "внизу": "bottom", "низ": "bottom", "снизу": "bottom",
    }
    key = aliases.get(key, "center")
    alignment = {"top": 8, "center": 5, "bottom": 2}[key]
    margin_v = 0 if key == "center" else max(36, int(height * 0.08))
    return alignment, margin_v


def write_pause_info_ass(path: str, duration: float, width: int, height: int,
                         title: str, prefix: str, resume_at_seconds: float,
                         position: str = "center") -> None:
    """Статичный информер рекламной паузы (одна строка на весь сегмент).

    Вместо бегущего обратного отсчёта (ломался в copy-режиме из-за посекундной
    нарезки Dialogue) — показывает фиксированную ПОЗИЦИЮ в итоговом видео, на
    которую зритель может перемотать, чтобы продолжить фильм:
        {title}
        {prefix} HH:MM:SS
    resume_at_seconds — абсолютная позиция начала продолжения (after-сегмента)
    в итоговом ролике = (start - trim_start) + duration."""
    title = ass_escape_text(title.strip() or "РЕКЛАМНАЯ ПАУЗА")
    prefix = ass_escape_text(prefix.strip() or "Продолжение начнётся в:")
    font_size = max(28, int(height * 0.062))
    timer_size = max(24, int(height * 0.047))
    outline = max(2, int(height * 0.003))
    alignment, margin_v = pause_info_ass_layout(position, height)

    lines = [
        "[Script Info]",
        "ScriptType: v4.00+",
        f"PlayResX: {width}",
        f"PlayResY: {height}",
        "ScaledBorderAndShadow: yes",
        "",
        "[V4+ Styles]",
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
        f"Style: PauseTitle,Arial,{font_size},&H00FFFFFF,&H000000FF,&H00000000,&H8A000000,-1,0,0,0,100,100,0,0,3,{outline},0,{alignment},70,70,{margin_v},1",
        f"Style: PauseTimer,Arial,{timer_size},&H00FFFFFF,&H000000FF,&H00000000,&H8A000000,0,0,0,0,100,100,0,0,3,{outline},0,{alignment},70,70,{margin_v},1",
        "",
        "[Events]",
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
    ]

    # Одна статичная строка [0 .. duration] — не движется, не зависит от fps.
    tc = timeline_timecode(resume_at_seconds)
    text = f"{title}\\N{{\\fs{timer_size}}}{prefix} {tc}"
    lines.append(f"Dialogue: 0,{ass_time(0)},{ass_time(max(0.1, duration))},PauseTitle,,0,0,{margin_v},,{text}")

    with open(path, "w", encoding="utf-8-sig", newline="\n") as f:
        f.write("\n".join(lines))
        f.write("\n")


def _load_pause_font(size: int, bold: bool = False):
    if not _PIL_OK:
        raise RuntimeError("Pillow is required to render pause text overlay.")
    names = [
        "/System/Library/Fonts/Supplemental/Arial Bold.ttf" if bold else "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/Library/Fonts/Arial Bold.ttf" if bold else "/Library/Fonts/Arial.ttf",
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/segoeuib.ttf" if bold else "C:/Windows/Fonts/segoeui.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for name in names:
        try:
            return ImageFont.truetype(name, size=size)
        except Exception:
            pass
    return ImageFont.load_default()


def _text_size(draw, text: str, font, stroke_width: int = 0) -> tuple[int, int]:
    box = draw.textbbox((0, 0), text, font=font, stroke_width=stroke_width)
    return max(1, box[2] - box[0]), max(1, box[3] - box[1])


def write_pause_info_png(path: str, width: int, height: int,
                         title: str, prefix: str, resume_at_seconds: float,
                         position: str = "center") -> None:
    """Render pause info into a transparent PNG, avoiding ffmpeg subtitles/libass."""
    if not _PIL_OK:
        raise RuntimeError("Pillow is required to render pause text overlay.")

    title_text = (title or "").strip() or "РЕКЛАМНАЯ ПАУЗА"
    prefix_text = (prefix or "").strip() or "Продолжение начнётся в:"
    timer_text = f"{prefix_text} {timeline_timecode(resume_at_seconds)}"

    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    max_text_w = int(width * 0.86)
    title_size = max(28, int(height * 0.062))
    timer_size = max(24, int(height * 0.047))
    stroke = max(2, int(height * 0.003))

    for _ in range(12):
        title_font = _load_pause_font(title_size, bold=True)
        timer_font = _load_pause_font(timer_size, bold=False)
        tw, th = _text_size(draw, title_text, title_font, stroke)
        mw, mh = _text_size(draw, timer_text, timer_font, stroke)
        if max(tw, mw) <= max_text_w or (title_size <= 20 and timer_size <= 18):
            break
        title_size = max(20, int(title_size * 0.92))
        timer_size = max(18, int(timer_size * 0.92))

    gap = max(10, int(height * 0.018))
    pad_x = max(26, int(width * 0.025))
    pad_y = max(18, int(height * 0.020))
    group_w = max(tw, mw) + pad_x * 2
    group_h = th + gap + mh + pad_y * 2
    x0 = max(0, int((width - group_w) / 2))

    key = (position or "center").strip().lower()
    if key in {"top", "up", "upper", "вверху", "верх", "сверху"}:
        y0 = max(0, int(height * 0.08))
    elif key in {"bottom", "down", "lower", "внизу", "низ", "снизу"}:
        y0 = min(height - group_h, height - group_h - max(0, int(height * 0.08)))
    else:
        y0 = int((height - group_h) / 2)
    y0 = max(0, min(height - group_h, y0))

    box = [x0, y0, min(width, x0 + group_w), min(height, y0 + group_h)]
    radius = max(8, int(height * 0.012))
    try:
        draw.rounded_rectangle(box, radius=radius, fill=(0, 0, 0, 135),
                               outline=(255, 255, 255, 70), width=max(1, stroke // 2))
    except Exception:
        draw.rectangle(box, fill=(0, 0, 0, 135))

    title_x = int((width - tw) / 2)
    title_y = y0 + pad_y
    timer_x = int((width - mw) / 2)
    timer_y = title_y + th + gap
    draw.text((title_x, title_y), title_text, font=title_font, fill=(255, 255, 255, 255),
              stroke_width=stroke, stroke_fill=(0, 0, 0, 230))
    draw.text((timer_x, timer_y), timer_text, font=timer_font, fill=(255, 255, 255, 255),
              stroke_width=stroke, stroke_fill=(0, 0, 0, 230))
    img.save(path)


def append_outro(main_path: str, outro_path: str, out_path: str,
                 run_checked, status_cb=None) -> None:
    """Приклеить авторку (outro) к концу готового фильма через concat -c copy.

    main_path остаётся copy (не перекодируется). outro перекодируется под
    параметры main (size / fps / codec / profile / bitrate / pix_fmt + audio),
    иначе concat демюксер дрожит на стыке. Если у авторки нет аудиодорожки —
    подставляем тишину (anullsrc + -shortest), иначе concat падает на
    несовпадении набора потоков.

    run_checked(cmd, label) — колбэк запуска ffmpeg с проверкой кода возврата.
    """
    def _say(msg):
        if status_cb:
            status_cb(msg)

    _say("Probe фильма/авторки...")
    main_info = probe_media(main_path)
    outro_info = probe_media(outro_path)
    mv = first_stream(main_info, "video")
    ma = first_stream(main_info, "audio")
    ov = first_stream(outro_info, "video")
    if not mv:
        raise RuntimeError("В основном файле нет видеопотока (append outro).")
    if not ov:
        raise RuntimeError("В файле авторки нет видеопотока.")
    outro_has_audio = first_stream(outro_info, "audio") is not None

    width = int(mv.get("width") or 0)
    height = int(mv.get("height") or 0)
    if width <= 0 or height <= 0:
        raise RuntimeError("Не удалось прочитать размер основного видео (append outro).")
    pix_fmt = (mv.get("pix_fmt") or "yuv420p").strip() or "yuv420p"
    if pix_fmt.lower() in {"unknown", "none"}:
        pix_fmt = "yuv420p"
    _, fps_arg = parse_fps(mv.get("avg_frame_rate") or mv.get("r_frame_rate"))

    vcodec = (mv.get("codec_name") or "").lower()
    if vcodec == "h264":
        v_encoder, v_extra = "libx264", []
    elif vcodec == "hevc":
        v_encoder, v_extra = "libx265", ["-tag:v", "hvc1"]
    else:
        raise RuntimeError(f"Append outro поддерживает H.264/HEVC основного видео, получено: {vcodec or 'unknown'}.")

    if ma:
        acodec = (ma.get("codec_name") or "").lower()
        sample_rate = str(ma.get("sample_rate") or "48000")
        channels = str(ma.get("channels") or "2")
    else:
        acodec, sample_rate, channels = "aac", "48000", "2"
    a_encoder = "libmp3lame" if acodec == "mp3" else "aac"

    v_enc_args = build_video_encode_args(mv, fps_arg, pix_fmt, v_encoder, v_extra)
    a_enc_args = build_audio_encode_args(ma or {}, a_encoder, sample_rate, channels)

    # FPS задаётся фильтром fps= в vf (ниже). Поэтому убираем -r / -fps_mode / -fpsmax
    # из encode-args: у склеенного main avg_frame_rate «грязный» (после concat),
    # build_video_encode_args мог поставить -fps_mode vfr, а -r + non-CFR fps_mode =
    # «contradictory» ошибка ffmpeg. Фильтр fps= даёт чистый CFR без конфликта.
    def _strip_pair(args, *flags):
        out, i = [], 0
        while i < len(args):
            if args[i] in flags:
                i += 2  # пропускаем флаг + его значение
            else:
                out.append(args[i]); i += 1
        return out
    v_enc_args = _strip_pair(v_enc_args, "-r", "-fps_mode", "-fpsmax")

    seg_ext = os.path.splitext(out_path)[1].lower()
    if seg_ext not in {".mp4", ".m4v", ".mov", ".mkv"}:
        seg_ext = ".mp4"

    folder = os.path.dirname(os.path.abspath(out_path)) or "."
    temp_dir = tempfile.mkdtemp(prefix="outro_", dir=folder)
    success = False
    try:
        outro_conf = os.path.join(temp_dir, f"outro_conformed{seg_ext}")
        vf = (
            f"scale={width}:{height}:force_original_aspect_ratio=decrease,"
            f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,"
            f"setsar=1,fps={fps_arg},format={pix_fmt}"
        )
        _say("Conform авторки под параметры фильма...")
        if outro_has_audio:
            conf_cmd = [
                "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                "-i", outro_path,
                "-vf", vf,
                "-map", "0:v:0", "-map", "0:a:0",
                "-af", f"aresample={sample_rate}",
                *v_enc_args, *a_enc_args,
                "-movflags", "+faststart", outro_conf,
            ]
        else:
            # У авторки нет звука — генерим тишину той же длины (-shortest обрежет).
            conf_cmd = [
                "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                "-i", outro_path,
                "-f", "lavfi", "-i", f"anullsrc=channel_layout=stereo:sample_rate={sample_rate}",
                "-vf", vf,
                "-map", "0:v:0", "-map", "1:a:0",
                *v_enc_args, *a_enc_args,
                "-shortest",
                "-movflags", "+faststart", outro_conf,
            ]
        run_checked(conf_cmd, "outro conform")

        concat_list = os.path.join(temp_dir, "outro_concat.txt")
        with open(concat_list, "w", encoding="utf-8") as f:
            f.write(concat_file_line(main_path) + "\n")
            f.write(concat_file_line(outro_conf) + "\n")

        _say("Финальный concat с авторкой (-c copy)...")
        concat_cmd = [
            "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
            "-f", "concat", "-safe", "0",
            "-i", concat_list,
            "-map", "0",
            "-c", "copy",
            *fake_metadata_args(),
        ]
        if seg_ext in {".mp4", ".m4v", ".mov"}:
            concat_cmd += ["-movflags", "+faststart"]
        concat_cmd.append(out_path)
        run_checked(concat_cmd, "outro concat")
        success = True
    finally:
        if success:
            shutil.rmtree(temp_dir, ignore_errors=True)


# ====================================================================
# POST-PROCESS — финальный реэнкод с эффектами
# Применяется к ГОТОВОМУ файлу (после concat+outro). Один ffmpeg-проход,
# композитный vf и af. Все нейтральные значения = no-op (без эффекта).
# ====================================================================

def _pp_safe_crop_vf(opts, width, height):
    pct = float(opts.get("crop_percent", 0) or 0)
    if pct <= 0:
        return None
    factor = 1.0 - pct / 100.0
    cw = max(2, int(width * factor) // 2 * 2)
    ch = max(2, int(height * factor) // 2 * 2)
    return f"crop={cw}:{ch}:(iw-ow)/2:(ih-oh)/2,scale={width}:{height}"


def _pp_jitter_vf(opts, width, height, fps):
    amp_x = float(opts.get("jitter_x", 0) or 0)
    amp_y = float(opts.get("jitter_y", 0) or 0)
    zoom_amp = float(opts.get("zoom_amplitude", 0) or 0)
    if amp_x <= 0 and amp_y <= 0 and zoom_amp <= 0:
        return None
    period_x = max(0.5, float(opts.get("jitter_period_x", 17.5) or 17.5))
    period_y = max(0.5, float(opts.get("jitter_period_y", 15.5) or 15.5))
    zoom_period = max(0.5, float(opts.get("zoom_period", 18) or 18))
    margin = max(amp_x, amp_y, 6.0) + 2.0
    fps = max(1.0, float(fps or 25))
    left_base = margin
    right_base = max(left_base + 2.0, float(width) - margin)
    top_base = margin
    bottom_base = max(top_base + 2.0, float(height) - margin)
    dx = f"{amp_x:.6f}*sin(2*PI*on/{fps * period_x:.6f})"
    dy = f"{amp_y:.6f}*cos(2*PI*on/{fps * period_y:.6f})"
    if zoom_amp > 0:
        zf = zoom_amp / 100.0
        zx = f"{width * zf * 0.25:.6f}*(1+sin(2*PI*on/{fps * zoom_period:.6f}))"
        zy = f"{height * zf * 0.25:.6f}*(1+sin(2*PI*on/{fps * zoom_period:.6f}))"
    else:
        zx = zy = "0"
    left = f"{left_base:.6f}+{dx}+{zx}"
    right = f"{right_base:.6f}+{dx}-{zx}"
    top = f"{top_base:.6f}+{dy}+{zy}"
    bottom = f"{bottom_base:.6f}+{dy}-{zy}"
    return (
        f"perspective=x0='{left}':y0='{top}':"
        f"x1='{right}':y1='{top}':"
        f"x2='{left}':y2='{bottom}':"
        f"x3='{right}':y3='{bottom}':"
        "sense=source:eval=frame:interpolation=cubic"
    )


def _pp_letterbox_vf(opts, height):
    if not opts.get("letterbox_enabled"):
        return None
    pct = float(opts.get("letterbox_height_pct", 8) or 8)
    bar = max(2, int(height * pct / 100))
    return (
        f"drawbox=x=0:y=0:w=iw:h={bar}:color=black:t=fill,"
        f"drawbox=x=0:y=ih-{bar}:w=iw:h={bar}:color=black:t=fill"
    )


def _pp_noise_blur_vf(opts):
    noise = int(opts.get("noise_strength", 0) or 0)
    blur = float(opts.get("blur_amount", 0) or 0)
    if noise <= 0 and abs(blur) < 0.001:
        return None
    parts = []
    if noise > 0:
        parts.append(f"noise=alls={noise}:allf=t+u")
    if abs(blur) > 0.001:
        parts.append(f"unsharp=3:3:{blur:.3f}:3:3:{blur:.3f}")
    return ",".join(parts)


def _pp_color_vf(opts):
    """Расширенный цветокор: hue + colorbalance(shadows/midtones/highlights) + eq."""
    parts = []
    hue_deg = float(opts.get("hue_deg", 0) or 0)
    hue_sat = float(opts.get("hue_sat_mul", 1) or 1)
    if abs(hue_deg) > 0.001 or abs(hue_sat - 1.0) > 0.001:
        parts.append(f"hue=h={hue_deg:.3f}:s={hue_sat:.3f}")
    cb_keys = [("cb_shad_r", "rs"), ("cb_shad_g", "gs"), ("cb_shad_b", "bs"),
               ("cb_mid_r", "rm"), ("cb_mid_g", "gm"), ("cb_mid_b", "bm"),
               ("cb_high_r", "rh"), ("cb_high_g", "gh"), ("cb_high_b", "bh")]
    cb_vals = [(ff, float(opts.get(k, 0) or 0)) for k, ff in cb_keys]
    if any(abs(v) > 0.001 for _, v in cb_vals):
        parts.append("colorbalance=" + ":".join(f"{ff}={v:.4f}" for ff, v in cb_vals))
    eq_parts = []
    for key, label, neutral in [
        ("brightness", "brightness", 0.0),
        ("contrast", "contrast", 1.0),
        ("saturation", "saturation", 1.0),
        ("gamma", "gamma", 1.0),
        ("gamma_r", "gamma_r", 1.0),
        ("gamma_g", "gamma_g", 1.0),
        ("gamma_b", "gamma_b", 1.0),
        ("gamma_weight", "gamma_weight", 1.0),
    ]:
        v = float(opts.get(key, neutral) or neutral)
        if abs(v - neutral) > 0.001:
            eq_parts.append(f"{label}={v:.4f}")
    if eq_parts:
        parts.append("eq=" + ":".join(eq_parts))
    return ",".join(parts) if parts else None


def _pp_vfr_vf(opts):
    amp_ms = float(opts.get("vfr_amplitude_ms", 0) or 0)
    if amp_ms <= 0:
        return None
    period = max(1.0, float(opts.get("vfr_period_frames", 10) or 10))
    amp_sec = amp_ms / 1000.0
    return f"setpts='PTS+{amp_sec:.6f}/TB*sin(N/{period:.3f})'"


def _pp_audio_af(opts):
    parts = []
    eq_gain = float(opts.get("audio_eq_gain_db", 0) or 0)
    if abs(eq_gain) > 0.001:
        parts.append(f"equalizer=f=3500:t=q:w=1.3:g={eq_gain:.3f}")
    echo_delay = float(opts.get("audio_echo_delay_ms", 0) or 0)
    if echo_delay > 0:
        echo_decay = float(opts.get("audio_echo_decay", 0.025) or 0.025)
        parts.append(f"aecho=0.80:0.90:{echo_delay:.3f}:{echo_decay:.4f}")
    return ",".join(parts) if parts else None


def apply_postprocess(in_path, out_path, opts, run_checked, status_cb=None):
    """Финальный реэнкод с набором эффектов.

    opts — dict с ключами:
      crop_percent, jitter_x, jitter_y, jitter_period_x/y, zoom_amplitude,
      zoom_period, letterbox_enabled, letterbox_height_pct, noise_strength,
      blur_amount, brightness, contrast, saturation, gamma, gamma_r/g/b,
      gamma_weight, hue_deg, hue_sat_mul, cb_shad_r/g/b, cb_mid_r/g/b,
      cb_high_r/g/b, vfr_amplitude_ms, vfr_period_frames, audio_eq_gain_db,
      audio_echo_delay_ms, audio_echo_decay, logo_enabled, logo_path,
      logo_corner ("TL"|"TR"|"BL"|"BR"), logo_margin (px), logo_scale (0..1),
      crf (default 18), preset (default "fast").

    Все нейтральные значения = пропуск соответствующей части. Если ВСЕ
    эффекты выключены → просто реэнкод (можно избежать, но сейчас оставляем
    для единообразия)."""
    def _say(m):
        if status_cb: status_cb(m)

    _say("Postprocess: probe...")
    probe = probe_media(in_path)
    mv = first_stream(probe, "video")
    ma = first_stream(probe, "audio")
    if not mv:
        raise RuntimeError("postprocess: нет видеопотока во входе.")
    w = int(mv.get("width") or 0)
    h = int(mv.get("height") or 0)
    if w <= 0 or h <= 0:
        raise RuntimeError("postprocess: не удалось прочитать размер видео.")
    _, fps_arg = parse_fps(mv.get("avg_frame_rate") or mv.get("r_frame_rate"))
    try:
        fps_val = float(eval(fps_arg)) if "/" in fps_arg else float(fps_arg)
    except Exception:
        fps_val = 25.0

    # vf-цепь (без логотипа — logo overlay делается через filter_complex отдельно)
    vf_parts = []
    for fn in (
        lambda: _pp_safe_crop_vf(opts, w, h),
        lambda: _pp_jitter_vf(opts, w, h, fps_val),
        lambda: _pp_letterbox_vf(opts, h),
        lambda: _pp_noise_blur_vf(opts),
        lambda: _pp_color_vf(opts),
        lambda: _pp_vfr_vf(opts),
    ):
        s = fn()
        if s:
            vf_parts.append(s)
    vf_chain = ",".join(vf_parts) if vf_parts else None
    af_chain = _pp_audio_af(opts)

    logo_enabled = bool(opts.get("logo_enabled"))
    logo_path = (opts.get("logo_path") or "").strip()
    if logo_enabled and (not logo_path or not os.path.isfile(logo_path)):
        raise RuntimeError("postprocess: logo_enabled=True, но logo_path не найден.")

    crf = int(opts.get("crf", 18) or 18)
    preset = str(opts.get("preset", "fast") or "fast")
    use_vfr_mode = float(opts.get("vfr_amplitude_ms", 0) or 0) > 0

    cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
           "-i", str(in_path)]

    if logo_enabled:
        # filter_complex: video chain → [base]; logo scaled → [lg]; overlay → [vout]
        cmd += ["-i", logo_path]
        corner = (opts.get("logo_corner", "TR") or "TR").upper()
        margin = int(opts.get("logo_margin", 20) or 20)
        scale_k = float(opts.get("logo_scale", 0.12) or 0.12)
        # Если включены чёрные шторы — у верхнего и нижнего края есть полосы
        # высотой letterbox_height_pct% от высоты кадра. Логотип должен
        # уходить ВНУТРЬ видимой области, а не лежать на шторах.
        lb_on = bool(opts.get("letterbox_enabled"))
        lb_pct = float(opts.get("letterbox_height_pct", 0) or 0) if lb_on else 0.0
        # Дополнительный ручной сдвиг ВНУТРЬ кадра от выбранного края.
        ox = int(opts.get("logo_offset_x", 0) or 0)
        oy = int(opts.get("logo_offset_y", 0) or 0)
        m_x = margin + ox
        m_y_top = f"({lb_pct:.3f}/100*main_h+{margin}+{oy})"
        m_y_bot = f"({lb_pct:.3f}/100*main_h+{margin}+{oy})"
        pos = {
            "TL": f"{m_x}:{m_y_top}",
            "TR": f"main_w-overlay_w-{m_x}:{m_y_top}",
            "BL": f"{m_x}:main_h-overlay_h-{m_y_bot}",
            "BR": f"main_w-overlay_w-{m_x}:main_h-overlay_h-{m_y_bot}",
        }.get(corner, f"main_w-overlay_w-{m_x}:{m_y_top}")
        base_chain = vf_chain if vf_chain else "null"
        # scale2ref: масштабируем лого относительно ШИРИНЫ КАДРА (а не своего PNG).
        # w='iw*K' — iw здесь это width REF (base), то есть main_w.
        filter_complex = (
            f"[0:v]{base_chain}[basef];"
            f"[1:v][basef]scale2ref=w='iw*{scale_k:.4f}':h='-1'[lg][base];"
            f"[base][lg]overlay={pos}[vout]"
        )
        cmd += ["-filter_complex", filter_complex, "-map", "[vout]"]
    else:
        if vf_chain:
            cmd += ["-vf", vf_chain]
        cmd += ["-map", "0:v:0"]

    # audio
    if ma:
        cmd += ["-map", "0:a:0"]
        if af_chain:
            cmd += ["-af", af_chain]
        cmd += ["-c:a", "aac", "-b:a", "160k"]
    else:
        cmd += ["-an"]

    # video encode
    cmd += ["-c:v", "libx264", "-preset", preset, "-crf", str(crf),
            "-pix_fmt", "yuv420p"]
    if use_vfr_mode:
        cmd += ["-fps_mode", "vfr"]
    cmd += ["-movflags", "+faststart", str(out_path)]

    _say(f"Postprocess: ffmpeg ({len(vf_parts)} video-эффектов, audio={'+' if af_chain else '-'}, logo={'+' if logo_enabled else '-'})")
    run_checked(cmd, "postprocess")


class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        # ===== Тема ttkbootstrap (cosmo — чистая профессиональная) =====
        self._tb_tooltip_cls = None
        try:
            from ttkbootstrap import Style as _TBStyle
            try:
                from ttkbootstrap.widgets import ToolTip as _TBToolTip
            except Exception:
                from ttkbootstrap.tooltip import ToolTip as _TBToolTip  # старый путь
            _tbs = _TBStyle(theme="cosmo")
            self._tb_tooltip_cls = _TBToolTip

            # Палитра для tk.Scale (в tk нет отдельного цвета ручки —
            # ручка красится через `bg` Scale-виджета, отдельно от родителя):
            _BG = "#dde3eb"        # фон GUI — мягкий серо-голубой
            _TROUGH = "#b6bfc9"    # рельс — чуть темнее фона
            _HANDLE = "#2780E3"    # ручка ползунка — фирменный синий cosmo
            _BORDER = "#2780E3"    # обводка вокруг Scale — тот же синий
            self._BG_COLOR = _BG
            self._TROUGH_COLOR = _TROUGH
            self._HANDLE_COLOR = _HANDLE
            self._BORDER_COLOR = _BORDER
            # Все TFrame-производные включая LabelFrame красим в _BG —
            # вкладки и панели должны быть ОДНОГО цвета, без белых дыр.
            for sname in ("TFrame", "TLabel", "TLabelframe", "TLabelframe.Label",
                          "TCheckbutton", "TRadiobutton", "TNotebook",
                          "TNotebook.Tab", "TSeparator", "Treeview"):
                try: _tbs.configure(sname, background=_BG)
                except Exception: pass
            # Toggle-чекбоксы (bootstyle success-round-toggle и др.) идут через
            # отдельные стили *.Roundtoggle.Toolbutton. У них по дефолту белый
            # фон у текста — переопределяем и заодно делаем шрифт крупнее,
            # чтобы юзеру было удобнее попадать мышкой.
            _toggle_font = ("Segoe UI", 11, "bold")
            for color in ("success", "primary", "info", "warning", "danger",
                          "secondary", "default"):
                for sname in (f"{color}.Roundtoggle.Toolbutton",
                              f"{color}.Toolbutton",
                              f"{color}.TCheckbutton"):
                    try: _tbs.configure(sname, background=_BG, font=_toggle_font)
                    except Exception: pass

            # Шрифт оставлен дефолтным — глобальный bump уменьшал визуальное качество
            # (выглядит дешевле). Если потом понадобится — менять точечно по виджетам.
            try: root.configure(bg=_BG)
            except Exception: pass
            # Глобальный X-resource: задаёт цвет рельса всем tk.Scale в приложении.
            # Параметры troughColor/background передаваемые в конструктор tk.Scale на
            # Windows-Tk + ttkbootstrap часто игнорируются — option_add ставит их
            # на уровне Tk-ресурсов до создания виджетов.
            try:
                root.option_add("*Scale.troughColor", _TROUGH)
                root.option_add("*Scale.background", _HANDLE)  # ручка средне-серая
                root.option_add("*Scale.highlightThickness", 0)
                root.option_add("*Scale.highlightBackground", _BORDER)
                root.option_add("*Scale.highlightColor", _BORDER)
                root.option_add("*Scale.borderWidth", 0)
                root.option_add("*Scale.activeBackground", "#2780E3")
            except Exception: pass
        except Exception:
            pass

        root.title(f"Audio Inserter [{APP_BUILD}]")
        root.geometry("1200x780")
        root.resizable(True, True)
        root.minsize(960, 620)

        self.video_path = tk.StringVar()
        self.audio_path = tk.StringVar()
        self.insert_video_path = tk.StringVar()
        # Точка вставки — ДВА способа задания одновременно:
        #   • текстовое поле (секунды / ЧЧ:ММ:СС) — start_time
        #   • ползунок 0..100% от длины фильма          — start_percent
        # Активный режим определяется тем, что юзер тронул последним
        # (_insert_active_mode = "time" | "percent"). Без radio-кнопок.
        self.start_time = tk.StringVar(value="0")
        self.start_percent = tk.DoubleVar(value=0.0)
        self._insert_active_mode = "time"
        self.duration = tk.StringVar(value="10")
        self.insert_video_start = tk.StringVar(value="0")
        self.use_source_insert = tk.BooleanVar(value=False)
        self.source_insert_side = tk.StringVar(value="before")
        self.overlay_timer = tk.BooleanVar(value=False)
        self.pause_title = tk.StringVar(value="РЕКЛАМНАЯ ПАУЗА")
        self.pause_prefix = tk.StringVar(value="Продолжение начнётся в:")
        self.pause_position = tk.StringVar(value="center")
        self.mode = tk.StringVar(value="expand")
        self.snap_silence = tk.BooleanVar(value=False)
        self.silence_radius = tk.StringVar(value="200")
        self.silence_min = tk.StringVar(value="0.35")
        self.quiet_step = tk.StringVar(value="0.05")
        self.duck = tk.IntVar(value=30)
        self._duck_mix_last = 30  # last value used in mix mode (restored when leaving expand)
        self.track_vol = tk.IntVar(value=100)
        self.full_track = tk.BooleanVar(value=False)

        # Audio track start offset (с какой секунды композиции начинать вставку)
        self.audio_track_start = tk.StringVar(value="0")

        # Outro (авторка) — приклеить внешний ролик к концу фильма (после trim)
        self.outro_enabled = tk.BooleanVar(value=False)
        self.outro_path = tk.StringVar()

        # ===== Postprocess (Перекод с эффектами) =====
        # ДЕФОЛТЫ — мягкая уникализация (взято из thesis-UI скриншота):
        # видео ощутимо не портится, но цифровой отпечаток меняется.
        self.pp_enabled = tk.BooleanVar(value=False)
        # Safe area crop
        self.pp_crop_percent = tk.DoubleVar(value=6.0)
        # Spatio-temporal jitter
        self.pp_jitter_x = tk.DoubleVar(value=10.0)
        self.pp_jitter_y = tk.DoubleVar(value=11.0)
        self.pp_jitter_period_x = tk.DoubleVar(value=17.5)
        self.pp_jitter_period_y = tk.DoubleVar(value=15.5)
        self.pp_zoom_amplitude = tk.DoubleVar(value=3.7)
        self.pp_zoom_period = tk.DoubleVar(value=18.0)
        # Noise / blur
        self.pp_noise_strength = tk.IntVar(value=4)
        self.pp_blur_amount = tk.DoubleVar(value=0.0)
        # Color — базовое (контраст и насыщенность чуть-чуть как на скрине)
        self.pp_brightness = tk.DoubleVar(value=0.0)
        self.pp_contrast = tk.DoubleVar(value=1.05)
        self.pp_saturation = tk.DoubleVar(value=1.05)
        # Color — гамма (нейтрально)
        self.pp_gamma = tk.DoubleVar(value=1.0)
        self.pp_gamma_r = tk.DoubleVar(value=1.0)
        self.pp_gamma_g = tk.DoubleVar(value=1.0)
        self.pp_gamma_b = tk.DoubleVar(value=1.0)
        self.pp_gamma_weight = tk.DoubleVar(value=1.0)
        # Color — тон (нейтрально)
        self.pp_hue_deg = tk.DoubleVar(value=0.0)
        self.pp_hue_sat_mul = tk.DoubleVar(value=1.0)
        # Color balance — тени / средние / света (нейтрально, тонкая ручка для юзера)
        self.pp_cb_shad_r = tk.DoubleVar(value=0.0)
        self.pp_cb_shad_g = tk.DoubleVar(value=0.0)
        self.pp_cb_shad_b = tk.DoubleVar(value=0.0)
        self.pp_cb_mid_r = tk.DoubleVar(value=0.0)
        self.pp_cb_mid_g = tk.DoubleVar(value=0.0)
        self.pp_cb_mid_b = tk.DoubleVar(value=0.0)
        self.pp_cb_high_r = tk.DoubleVar(value=0.0)
        self.pp_cb_high_g = tk.DoubleVar(value=0.0)
        self.pp_cb_high_b = tk.DoubleVar(value=0.0)
        # VFR timing jitter — мягкие 2.3мс/10 кадров (из скрина)
        self.pp_vfr_amplitude_ms = tk.DoubleVar(value=2.3)
        self.pp_vfr_period_frames = tk.IntVar(value=10)
        # Audio shift — лёгкое EQ + микро-эхо (как на скрине)
        self.pp_audio_eq_gain_db = tk.DoubleVar(value=-3.5)
        self.pp_audio_echo_delay_ms = tk.DoubleVar(value=3.5)
        self.pp_audio_echo_decay = tk.DoubleVar(value=0.025)
        # Чекбоксы по группам эффектов — независимое включение/выключение каждой
        # группы. По дефолту все OFF (на холодном запуске у юзера всё чисто;
        # после «Сохранить как дефолт» подхватываются его настройки из JSON).
        self.pp_grp_crop = tk.BooleanVar(value=False)
        self.pp_grp_jitter = tk.BooleanVar(value=False)
        self.pp_grp_zoom = tk.BooleanVar(value=False)
        self.pp_grp_noise = tk.BooleanVar(value=False)
        self.pp_grp_color = tk.BooleanVar(value=False)
        self.pp_grp_vfr = tk.BooleanVar(value=False)
        self.pp_grp_audio = tk.BooleanVar(value=False)

        # Logo overlay (off by default)
        self.pp_logo_enabled = tk.BooleanVar(value=False)
        self.pp_logo_path = tk.StringVar()
        self.pp_logo_corner = tk.StringVar(value="TR")
        self.pp_logo_margin = tk.IntVar(value=20)
        # Масштаб логотипа храним в процентах (8.0..50.0) — так юзеру читаемо в UI.
        # В opts ffmpeg-фильтра уходит как доля (делится на 100 в _collect_pp_options).
        self.pp_logo_scale = tk.DoubleVar(value=12.0)
        # Доп. ручной сдвиг лого от выбранного угла (в пикселях). 0 = строго в углу.
        # Положительные значения уводят логотип ВНУТРЬ кадра от соответствующего края.
        self.pp_logo_offset_x = tk.IntVar(value=0)
        self.pp_logo_offset_y = tk.IntVar(value=0)
        # Letterbox (off by default)
        self.pp_letterbox_enabled = tk.BooleanVar(value=False)
        self.pp_letterbox_height_pct = tk.DoubleVar(value=8.0)
        # Encode
        self.pp_crf = tk.IntVar(value=23)
        self.pp_preset = tk.StringVar(value="fast")

        # Trim video feature
        self.trim_enabled = tk.BooleanVar(value=False)
        self.trim_start = tk.StringVar(value="0")
        self.trim_end = tk.StringVar(value="")

        # Применяем сохранённые пользовательские дефолты (если есть) — перезапишет
        # значения «мягкой уникализации» тем, что юзер сохранил кнопкой ранее.
        self._pp_load_user_defaults_if_any()

        # ===== Tooltip helper: ttkbootstrap ToolTip для hover (розовая плашка) =====
        ToolTipCls = self._tb_tooltip_cls
        def _tip(widget, text):
            if not text:
                return
            if ToolTipCls is not None:
                try:
                    ToolTipCls(widget, text=text, bootstyle="info-inverse", wraplength=460)
                    return
                except Exception:
                    pass
            # Fallback на свой Toplevel (если ttkbootstrap.tooltip недоступен)
            state = {"win": None}
            def show(_e):
                if state["win"]: return
                win = tk.Toplevel(widget); win.wm_overrideredirect(True)
                win.attributes("-topmost", True)
                try: win.wm_geometry(f"+{widget.winfo_rootx()+18}+{widget.winfo_rooty()+widget.winfo_height()+4}")
                except Exception: pass
                tk.Label(win, text=text, bg="#2b3947", fg="#f4f6f8",
                         padx=10, pady=6, wraplength=480, justify="left",
                         font=("Segoe UI", 9), relief="solid", borderwidth=1).pack()
                state["win"] = win
            def hide(_e):
                if state["win"]:
                    try: state["win"].destroy()
                    except Exception: pass
                    state["win"] = None
            widget.bind("<Enter>", show); widget.bind("<Leave>", hide)
        self._tip = _tip

        def _q_label(parent, hint):
            """Иконка-информер 'ⓘ'. Hover = всплывашка, клик = диалог с тем же текстом."""
            lbl = ttk.Label(parent, text="ⓘ", cursor="hand2", bootstyle="primary")
            _tip(lbl, hint)
            if hint:
                lbl.bind("<Button-1>", lambda e: messagebox.showinfo("Подсказка", hint))
            return lbl

        # ===== Notebook =====
        # ===== Верхняя панель: главный чекбокс перекода + кнопки управления значениями =====
        topbar = ttk.Frame(root, padding=(10, 6, 10, 0))
        topbar.pack(fill="x")
        # Большая кнопка-тоггл: включить/выключить весь перекод с эффектами.
        # При клике меняем pp_enabled и обновляем внешний вид (зелёная если ON,
        # серый outline если OFF).
        self.pp_enable_btn = ttk.Button(topbar, command=lambda: self._toggle_pp_enabled(),
                                        padding=(14, 8))
        self.pp_enable_btn.pack(side="left", padx=(2, 12))
        def _refresh_pp_btn(*_):
            try:
                on = bool(self.pp_enabled.get())
                if on:
                    self.pp_enable_btn.configure(
                        text="✓ Перекод с эффектами ВКЛ",
                        bootstyle="success")
                else:
                    self.pp_enable_btn.configure(
                        text="○ Перекод с эффектами ВЫКЛ",
                        bootstyle="secondary-outline")
            except Exception:
                pass
        try: self.pp_enabled.trace_add("write", lambda *_a: _refresh_pp_btn())
        except Exception: pass
        _refresh_pp_btn()
        ttk.Button(topbar, text="💾 Сохранить как дефолт",
                   command=self._pp_save_user_defaults,
                   bootstyle="info-outline").pack(side="right", padx=4)
        ttk.Button(topbar, text="↺ Мой дефолт",
                   command=self._pp_apply_user_defaults,
                   bootstyle="info-outline").pack(side="right", padx=4)
        ttk.Button(topbar, text="Мягкая уникализация",
                   command=self._pp_load_soft_defaults,
                   bootstyle="info-outline").pack(side="right", padx=4)
        ttk.Button(topbar, text="Сбросить эффекты в 0",
                   command=self._pp_reset_defaults,
                   bootstyle="secondary-outline").pack(side="right", padx=4)

        nb = ttk.Notebook(root)
        nb.pack(fill="both", expand=True, padx=10, pady=(8, 4))

        # При клике на «Эффекты вставки» автоматически переключаем режим на
        # expand — иначе контролы там в disabled и ничего не сделать без
        # ручного переключения mode на главной вкладке. Юзабилити-фикс.
        def _on_tab_change(_e=None):
            try:
                txt = nb.tab(nb.select(), "text").strip()
            except Exception:
                return
            if "Эффекты вставки" in txt and self.mode.get() != "expand":
                self.mode.set("expand")
                try: self.toggle_mode()
                except Exception: pass
        nb.bind("<<NotebookTabChanged>>", _on_tab_change)


        def _make_tab(title):
            """Вкладка со scrollable canvas внутри. Возвращает inner-фрейм.
            inner всегда растянут на высоту Canvas — никакой белой дыры под
            содержимым: его фон (override TFrame) покрывает всю область.
            Outer-фрейм (то что реально добавляется в nb) сохраняется как
            inner._tab_outer — это нужно чтобы nb.tab(outer, ...) находил
            вкладку (по inner Notebook не ищет)."""
            tab = ttk.Frame(nb)
            nb.add(tab, text=title)
            _bg = getattr(self, "_BG_COLOR", "#dde3eb")
            canvas = tk.Canvas(tab, highlightthickness=0, bg=_bg, bd=0)
            sb = ttk.Scrollbar(tab, orient="vertical", command=canvas.yview)
            inner = ttk.Frame(canvas, padding=8)
            def _on_inner_cfg(_e):
                canvas.configure(scrollregion=canvas.bbox("all"))
            def _on_canvas_cfg(e):
                # Inner всегда минимум на высоту Canvas — чтобы под контентом
                # не было видно Canvas-фона (если override не подхватился).
                content_h = inner.winfo_reqheight()
                canvas.itemconfigure(cwin, width=e.width,
                                     height=max(content_h, e.height))
            cwin = canvas.create_window((0, 0), window=inner, anchor="nw")
            inner.bind("<Configure>", _on_inner_cfg)
            canvas.bind("<Configure>", _on_canvas_cfg)
            canvas.configure(yscrollcommand=sb.set)
            canvas.pack(side="left", fill="both", expand=True)
            sb.pack(side="right", fill="y")
            def _wheel(ev):
                canvas.yview_scroll(-1 * (ev.delta // 120), "units")
            canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", _wheel))
            canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))
            inner._tab_outer = tab
            return inner

        def _make_tab_pinned_right(title, right_width=280, left_width=620):
            """Вкладка с двумя зонами: слева — scrollable inner (фиксированной
            ширины, ровно под ползунки), справа — ЗАКРЕПЛЁННАЯ правая колонка
            (не скроллится). Обе колонки прижаты слева — без зазора между ними.
            Возвращает (left_inner, right_pinned)."""
            tab = ttk.Frame(nb)
            nb.add(tab, text=title)
            _bg = getattr(self, "_BG_COLOR", "#dde3eb")
            # Слева: scrollable canvas фиксированной ширины
            left_wrap = ttk.Frame(tab, width=left_width)
            left_wrap.pack(side="left", fill="y", anchor="nw")
            left_wrap.pack_propagate(False)
            # Справа сразу за left: pinned-фрейм (фиксированной ширины)
            right_pin = ttk.Frame(tab, padding=8, width=right_width)
            right_pin.pack(side="left", fill="y", anchor="nw")
            right_pin.pack_propagate(False)
            canvas = tk.Canvas(left_wrap, highlightthickness=0, bg=_bg, bd=0)
            sb = ttk.Scrollbar(left_wrap, orient="vertical", command=canvas.yview)
            inner = ttk.Frame(canvas, padding=8)
            def _on_inner_cfg(_e):
                canvas.configure(scrollregion=canvas.bbox("all"))
            def _on_canvas_cfg(e):
                content_h = inner.winfo_reqheight()
                canvas.itemconfigure(cwin, width=e.width,
                                     height=max(content_h, e.height))
            cwin = canvas.create_window((0, 0), window=inner, anchor="nw")
            inner.bind("<Configure>", _on_inner_cfg)
            canvas.bind("<Configure>", _on_canvas_cfg)
            canvas.configure(yscrollcommand=sb.set)
            canvas.pack(side="left", fill="both", expand=True)
            sb.pack(side="right", fill="y")
            def _wheel(ev):
                canvas.yview_scroll(-1 * (ev.delta // 120), "units")
            canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", _wheel))
            canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))
            inner._tab_outer = tab
            return inner, right_pin

        # ============================================================
        # TAB 1 — Inserter (видео, аудио, режим, параметры вставки, trim)
        # ============================================================
        t1 = _make_tab("  Inserter  ")

        # Files
        files_box = ttk.LabelFrame(t1, text="Файлы")
        files_box.pack(fill="x", padx=10, pady=6)
        def _file_row(parent, label_text, var, cmd):
            row = ttk.Frame(parent); row.pack(fill="x", padx=8, pady=4)
            ttk.Label(row, text=label_text, width=8, anchor="w").pack(side="left")
            ttk.Entry(row, textvariable=var).pack(side="left", fill="x", expand=True, padx=4)
            ttk.Button(row, text="Выбрать…", command=cmd, width=12).pack(side="left")
        _file_row(files_box, "Видео:", self.video_path, self.pick_video)
        _file_row(files_box, "Аудио:", self.audio_path, self.pick_audio)

        # Mode
        mode_box = ttk.LabelFrame(t1, text="Режим склейки")
        mode_box.pack(fill="x", padx=10, pady=6)
        ttk.Radiobutton(mode_box,
                        text="Фон/микс поверх оригинала — трек микшируется со звуком фильма",
                        variable=self.mode, value="mix",
                        command=self.toggle_mode).pack(anchor="w", padx=10, pady=(6, 2))
        ttk.Radiobutton(mode_box,
                        text="Раздвинуть таймлайн — фильм РАЗРЕЗАЕТСЯ, вставка появляется в точке вставки (финальная склейка copy)",
                        variable=self.mode, value="expand",
                        command=self.toggle_mode).pack(anchor="w", padx=10, pady=(0, 6))

        # Insert params (точка / длительность / старт трека)
        ins_box = ttk.LabelFrame(t1, text="Параметры вставки")
        ins_box.pack(fill="x", padx=10, pady=6)

        # Точка вставки: два способа сразу. Активен тот, что юзер тронул последним.
        # — текстовое поле «сек или ЧЧ:ММ:СС»
        # — ползунок 0..100% от длительности фильма
        # Активная строка выделена жирно, неактивная — приглушена.
        rr_t = ttk.Frame(ins_box); rr_t.pack(fill="x", padx=8, pady=(4, 1))
        self._insert_lbl_time = ttk.Label(rr_t, text="Точка вставки (сек или ЧЧ:ММ:СС):",
                                          width=32, anchor="w")
        self._insert_lbl_time.pack(side="left")
        self._insert_entry_time = ttk.Entry(rr_t, textvariable=self.start_time, width=18)
        self._insert_entry_time.pack(side="left", padx=4)
        _q_label(rr_t, "Можно ввести время в секундах (8400) или ЧЧ:ММ:СС (02:20:00). "
                       "Если двинешь ползунок ниже — активным станет процент.").pack(side="left", padx=4)

        rr_p = ttk.Frame(ins_box); rr_p.pack(fill="x", padx=8, pady=(1, 4))
        self._insert_lbl_pct = ttk.Label(rr_p, text="…или % от длины фильма:",
                                         width=32, anchor="w")
        self._insert_lbl_pct.pack(side="left")
        _scl = tk.Scale(rr_p, from_=0, to=100, orient="horizontal",
                        variable=self.start_percent, resolution=0.5, length=320,
                        bg=_BG, troughcolor=_TROUGH, highlightthickness=0, bd=0,
                        showvalue=0, sliderrelief="flat", sliderlength=18,
                        activebackground="#2780E3")
        try: _scl.configure(troughcolor=_TROUGH, bg=_HANDLE)
        except Exception: pass
        _scl.pack(side="left", padx=4)
        self._insert_pct_val_lbl = ttk.Label(rr_p, width=14, anchor="w")
        self._insert_pct_val_lbl.pack(side="left", padx=(2, 6))
        _q_label(rr_p, "Двинь ползунок — активным станет процент. При сборке "
                       "пересчитывается в секунды через длительность видео. "
                       "С включённым поиском тишины — найдётся ближайшая пауза.").pack(side="left", padx=4)

        # Колбэки переключения активного режима + индикатор подписи в %.
        def _refresh_pct_label(*_):
            try:
                pct = float(self.start_percent.get())
            except Exception:
                pct = 0.0
            v = self.video_path.get().strip()
            tcode = ""
            if v and os.path.isfile(v):
                d = probe_duration(v)
                if d > 0:
                    sec = d * pct / 100.0
                    tcode = f"  ≈ {_fmt_time_tag(sec)}"
            try: self._insert_pct_val_lbl.config(text=f"{pct:.1f}%{tcode}")
            except Exception: pass

        def _apply_active_style():
            # Активный — обычный шрифт; неактивный — серый. Без жирного, чтобы layout не плыл.
            active_fg = "#222"
            idle_fg = "#a0a0a0"
            try:
                if self._insert_active_mode == "time":
                    self._insert_lbl_time.config(foreground=active_fg)
                    self._insert_lbl_pct.config(foreground=idle_fg)
                else:
                    self._insert_lbl_time.config(foreground=idle_fg)
                    self._insert_lbl_pct.config(foreground=active_fg)
            except Exception:
                pass

        def _activate_time(_event=None):
            self._insert_active_mode = "time"
            _apply_active_style()
        def _activate_percent(_event=None):
            self._insert_active_mode = "percent"
            _refresh_pct_label()
            _apply_active_style()
        def _on_time_changed(*_):
            _activate_time()
        def _on_pct_changed(*_):
            _refresh_pct_label()
            _apply_active_style()
        def _on_pct_user_changed(_value=None):
            _activate_percent()

        try: self.start_time.trace_add("write", _on_time_changed)
        except Exception: pass
        try: self.start_percent.trace_add("write", _on_pct_changed)
        except Exception: pass
        try: self.video_path.trace_add("write", lambda *_a: _refresh_pct_label())
        except Exception: pass
        try: _scl.configure(command=_on_pct_user_changed)
        except Exception: pass
        try:
            for _seq in ("<ButtonPress-1>", "<B1-Motion>", "<ButtonRelease-1>", "<KeyPress>", "<MouseWheel>"):
                _scl.bind(_seq, _activate_percent, add="+")
        except Exception:
            pass
        try:
            for _seq in ("<FocusIn>", "<ButtonPress-1>", "<KeyPress>"):
                self._insert_entry_time.bind(_seq, _activate_time, add="+")
        except Exception:
            pass
        _refresh_pct_label()
        _apply_active_style()

        rr = ttk.Frame(ins_box); rr.pack(fill="x", padx=8, pady=4)
        ttk.Label(rr, text="Длительность вставки (сек):", width=32, anchor="w").pack(side="left")
        self.duration_entry = ttk.Entry(rr, textvariable=self.duration, width=18)
        self.duration_entry.pack(side="left", padx=4)
        ttk.Checkbutton(rr, text="Full track (вся длина трека)",
                        variable=self.full_track, command=self._toggle_full_track).pack(side="left", padx=10)
        _q_label(rr, "Сколько секунд вклеить. Full track = взять полную длительность аудио (после старта трека).").pack(side="left", padx=4)

        rr = ttk.Frame(ins_box); rr.pack(fill="x", padx=8, pady=4)
        ttk.Label(rr, text="Старт трека (сек или ЧЧ:ММ:СС):", width=32, anchor="w").pack(side="left")
        ttk.Entry(rr, textvariable=self.audio_track_start, width=18).pack(side="left", padx=4)
        _q_label(rr, "С какой секунды композиции начинать вставку (по умолчанию 0 — с начала трека). Полезно если в начале аудио тишина или интро, которое не нужно.").pack(side="left", padx=4)

        # Volumes
        vol_box = ttk.LabelFrame(t1, text="Громкости")
        vol_box.pack(fill="x", padx=10, pady=6)

        # Громкость оригинала
        rr = ttk.Frame(vol_box); rr.pack(fill="x", padx=10, pady=4)
        ttk.Label(rr, text="Громкость оригинала в зоне вставки:", width=38, anchor="w").pack(side="left")
        self.duck_scale = tk.Scale(rr, from_=0, to=100, orient="horizontal",
                                   variable=self.duck, length=320,
                                   bg=_HANDLE, troughcolor=_TROUGH, highlightthickness=0, bd=0,
                                   showvalue=0, sliderrelief="flat", sliderlength=18,
                                   activebackground="#2780E3")
        try: self.duck_scale.configure(troughcolor=_TROUGH, bg=_HANDLE, highlightthickness=0)
        except Exception: pass
        _duck_lbl = ttk.Label(rr, width=6, anchor="e")
        def _duck_upd(*_): _duck_lbl.config(text=f"{int(self.duck.get())}%")
        try: self.duck.trace_add("write", lambda *_: _duck_upd())
        except Exception: pass
        self.duck_scale.pack(side="left", padx=6)
        _duck_upd()
        _duck_lbl.pack(side="left", padx=(2, 6))
        _q_label(rr, ("Насколько приглушить оригинальный звук фильма в момент вставки. "
                      "В режиме «Раздвинуть» оригинал в зоне вставки отсутствует — слайдер блокируется на 0.\n"
                      "• Полностью заглушить: 0%\n• Стандарт «фон под трек»: 25–35%\n"
                      "• Оригинал + трек на равных: 70–80%\n• Не глушить: 100%")).pack(side="left", padx=4)

        # Громкость трека
        rr = ttk.Frame(vol_box); rr.pack(fill="x", padx=10, pady=4)
        ttk.Label(rr, text="Громкость вклеиваемого трека:", width=38, anchor="w").pack(side="left")
        _trk_scl = tk.Scale(rr, from_=0, to=200, orient="horizontal",
                            variable=self.track_vol, length=320,
                            bg=_HANDLE, troughcolor=_TROUGH, highlightthickness=0, bd=0,
                            showvalue=0, sliderrelief="flat", sliderlength=18,
                            activebackground="#2780E3")
        try: _trk_scl.configure(troughcolor=_TROUGH, bg=_HANDLE, highlightthickness=0)
        except Exception: pass
        _trk_lbl = ttk.Label(rr, width=6, anchor="e")
        def _trk_upd(*_): _trk_lbl.config(text=f"{int(self.track_vol.get())}%")
        try: self.track_vol.trace_add("write", lambda *_: _trk_upd())
        except Exception: pass
        _trk_scl.pack(side="left", padx=6)
        _trk_upd()
        _trk_lbl.pack(side="left", padx=(2, 6))
        _q_label(rr, ("Громкость вставляемого аудио.\n"
                      "• 100% — исходный уровень трека\n"
                      "• 70–90% — мягкая подкладка\n"
                      "• 150%+ — рискует клиппингом, лучше нормализуй трек заранее")).pack(side="left", padx=4)

        # Snap silence
        snap_box = ttk.LabelFrame(t1, text="Поиск тихого места рядом с точкой")
        snap_box.pack(fill="x", padx=10, pady=6)
        rr = ttk.Frame(snap_box); rr.pack(fill="x", padx=8, pady=4)
        ttk.Checkbutton(rr, text="Сдвинуть точку вставки на ближайший тихий участок",
                        variable=self.snap_silence).pack(side="left")
        _q_label(rr, "Алгоритм найдёт самое тихое место в локальном окне ±N сек и поставит вставку туда — стык получится мягче. Помни: точка может уехать на ±N секунд от заданной.").pack(side="left", padx=8)
        rr = ttk.Frame(snap_box); rr.pack(fill="x", padx=8, pady=4)
        ttk.Label(rr, text="Окно ± сек:").pack(side="left")
        ttk.Entry(rr, textvariable=self.silence_radius, width=8).pack(side="left", padx=(2, 12))
        ttk.Label(rr, text="Длина анализа, сек:").pack(side="left")
        ttk.Entry(rr, textvariable=self.silence_min, width=8).pack(side="left", padx=(2, 4))
        _q_label(rr, "Эти значения уже подобраны оптимально — менять не нужно.\n"
                     "Длина анализа: окно усреднения громкости, по которому определяется "
                     "«тихий участок». 0.35 сек — баланс между точностью и устойчивостью.").pack(side="left", padx=(0, 12))
        ttk.Label(rr, text="Шаг, сек:").pack(side="left")
        ttk.Entry(rr, textvariable=self.quiet_step, width=8).pack(side="left", padx=(2, 4))
        _q_label(rr, "Эти значения уже подобраны оптимально — менять не нужно.\n"
                     "Шаг сканирования: с какой частотой алгоритм проверяет окна. "
                     "0.05 сек — достаточно плотно, чтобы не пропустить короткие паузы.").pack(side="left", padx=(0, 8))

        # Trim
        trim_box = ttk.LabelFrame(t1, text="Обрезка видео (без перекодирования)")
        trim_box.pack(fill="x", padx=10, pady=6)
        rr = ttk.Frame(trim_box); rr.pack(fill="x", padx=8, pady=4)
        ttk.Checkbutton(rr, text="Обрезать видео",
                        variable=self.trim_enabled, command=self.toggle_trim).pack(side="left")
        _q_label(rr, "Сколько отрезать с начала и/или с конца фильма. Резка по keyframe — copy без перекодирования. Точка вставки задаётся в координатах ОРИГИНАЛА (до трима).").pack(side="left", padx=8)
        rr = ttk.Frame(trim_box); rr.pack(fill="x", padx=8, pady=4)
        ttk.Label(rr, text="Отрезать с начала (сек или ЧЧ:ММ:СС):", width=32, anchor="w").pack(side="left")
        self.trim_start_entry = ttk.Entry(rr, textvariable=self.trim_start, width=18, state="disabled")
        self.trim_start_entry.pack(side="left", padx=4)
        rr = ttk.Frame(trim_box); rr.pack(fill="x", padx=8, pady=4)
        ttk.Label(rr, text="Конец обрезки (пусто = до конца):", width=32, anchor="w").pack(side="left")
        self.trim_end_entry = ttk.Entry(rr, textvariable=self.trim_end, width=18, state="disabled")
        self.trim_end_entry.pack(side="left", padx=4)

        # ============================================================
        # TAB 2 — Эффекты вставки (insert video / source / таймер)
        # ============================================================
        t2 = _make_tab("  Эффекты вставки  ")

        ext_box = ttk.LabelFrame(t2, text="Внешний видеофайл для вставки")
        ext_box.pack(fill="x", padx=10, pady=6)
        rr = ttk.Frame(ext_box); rr.pack(fill="x", padx=8, pady=4)
        ttk.Label(rr, text="Файл insert-видео:", width=18, anchor="w").pack(side="left")
        self.insert_video_entry = ttk.Entry(rr, textvariable=self.insert_video_path, state="disabled")
        self.insert_video_entry.pack(side="left", fill="x", expand=True, padx=4)
        self.insert_video_btn = ttk.Button(rr, text="Выбрать…", command=self.pick_insert_video,
                                           width=12, state="disabled")
        self.insert_video_btn.pack(side="left")
        rr = ttk.Frame(ext_box); rr.pack(fill="x", padx=8, pady=4)
        ttk.Label(rr, text="Старт в insert-видео (сек):", width=24, anchor="w").pack(side="left")
        self.insert_video_start_entry = ttk.Entry(rr, textvariable=self.insert_video_start,
                                                  width=14, state="disabled")
        self.insert_video_start_entry.pack(side="left", padx=4)
        _q_label(rr, "С какой секунды внешнего insert-видео начинать вставку.").pack(side="left", padx=4)

        self.source_insert_frame = ttk.LabelFrame(t2, text="Вместо внешнего файла — фрагмент из самого фильма")
        self.source_insert_frame.pack(fill="x", padx=10, pady=6)
        self.source_insert_check = ttk.Checkbutton(
            self.source_insert_frame,
            text="В режиме «Раздвинуть» брать insert-фрагмент из самого фильма",
            variable=self.use_source_insert, command=self.toggle_mode, state="disabled")
        self.source_insert_check.pack(anchor="w", padx=10, pady=(6, 2))
        rr = ttk.Frame(self.source_insert_frame); rr.pack(fill="x", padx=10, pady=(0, 6))
        ttk.Label(rr, text="Фрагмент:").pack(side="left", padx=(0, 8))
        self.source_before_radio = ttk.Radiobutton(rr, text="до точки вставки",
                                                   variable=self.source_insert_side,
                                                   value="before", state="disabled")
        self.source_before_radio.pack(side="left", padx=4)
        self.source_after_radio = ttk.Radiobutton(rr, text="после точки вставки",
                                                  variable=self.source_insert_side,
                                                  value="after", state="disabled")
        self.source_after_radio.pack(side="left", padx=4)

        self.overlay_timer_frame = ttk.LabelFrame(t2, text="Рекламный таймер поверх insert-сегмента")
        self.overlay_timer_frame.pack(fill="x", padx=10, pady=6)
        self.overlay_timer_check = ttk.Checkbutton(
            self.overlay_timer_frame,
            text="Наложить текст + статичную позицию перемотки на insert-видео",
            variable=self.overlay_timer, command=self.toggle_mode, state="disabled")
        self.overlay_timer_check.pack(anchor="w", padx=10, pady=(6, 2))
        rr = ttk.Frame(self.overlay_timer_frame); rr.pack(fill="x", padx=10, pady=(0, 6))
        ttk.Label(rr, text="Текст (заголовок):", width=22, anchor="w").pack(side="left")
        self.pause_title_entry = ttk.Entry(rr, textvariable=self.pause_title, width=30, state="disabled")
        self.pause_title_entry.pack(side="left", padx=4)
        rr = ttk.Frame(self.overlay_timer_frame); rr.pack(fill="x", padx=10, pady=(0, 6))
        ttk.Label(rr, text="Текст времени (префикс):", width=22, anchor="w").pack(side="left")
        self.pause_prefix_entry = ttk.Entry(rr, textvariable=self.pause_prefix, width=30, state="disabled")
        self.pause_prefix_entry.pack(side="left", padx=4)
        rr = ttk.Frame(self.overlay_timer_frame); rr.pack(fill="x", padx=10, pady=(0, 6))
        ttk.Label(rr, text="Положение текста:", width=22, anchor="w").pack(side="left")
        self.pause_pos_top_radio = ttk.Radiobutton(
            rr, text="Вверху", variable=self.pause_position, value="top", state="disabled")
        self.pause_pos_top_radio.pack(side="left", padx=4)
        self.pause_pos_center_radio = ttk.Radiobutton(
            rr, text="По центру", variable=self.pause_position, value="center", state="disabled")
        self.pause_pos_center_radio.pack(side="left", padx=4)
        self.pause_pos_bottom_radio = ttk.Radiobutton(
            rr, text="Внизу", variable=self.pause_position, value="bottom", state="disabled")
        self.pause_pos_bottom_radio.pack(side="left", padx=4)
        _q_label(self.overlay_timer_frame,
                 "Позиция перемотки в итоговом видео — куда перемотать чтобы продолжить фильм. Сама позиция считается автоматически и пишется в кадр статично (не бегущим таймером).").pack(anchor="w", padx=10, pady=(0, 6))

        # ============================================================
        # TAB 3 — Авторка (outro)
        # ============================================================
        t3 = _make_tab("  Авторка  ")

        self.outro_frame = ttk.LabelFrame(t3, text="Приклеить авторку (outro) в конец фильма")
        self.outro_frame.pack(fill="x", padx=10, pady=10)
        ttk.Checkbutton(self.outro_frame,
                        text="Приклеить авторку к концу (после обрезки; свой звук авторки сохраняется)",
                        variable=self.outro_enabled, command=self.toggle_outro).pack(anchor="w", padx=10, pady=(8, 4))
        rr = ttk.Frame(self.outro_frame); rr.pack(fill="x", padx=10, pady=(0, 8))
        ttk.Label(rr, text="Файл авторки:", width=14, anchor="w").pack(side="left")
        self.outro_entry = ttk.Entry(rr, textvariable=self.outro_path, state="disabled")
        self.outro_entry.pack(side="left", fill="x", expand=True, padx=4)
        self.outro_btn = ttk.Button(rr, text="Выбрать…", command=self.pick_outro, width=12, state="disabled")
        self.outro_btn.pack(side="left")
        ttk.Label(self.outro_frame,
                  text="Авторка перекодируется под параметры фильма (размер/fps/кодек), фильм остаётся copy. Стык чистый.",
                  foreground="#8a8a8a", wraplength=900, justify="left").pack(anchor="w", padx=10, pady=(0, 8))

        # ============================================================
        # TABs 4-8 — Перекод (постпроцесс) разбит на 5 верхних вкладок
        # для удобства: не листать длинный список ради одной настройки.
        # Главный чекбокс «Включить перекод» — в top bar над всем Notebook.
        # ============================================================
        t4_geom = _make_tab("  Геометрия  ")   # Safe-crop + Jitter
        # Шум + Цвет — особая вкладка: правая колонка с превью закреплена (не скроллится).
        # Превью на кадре ~ 320×180 + палитра ~ 280 → итого ~620 ширины. left 580.
        t4_color, _cc_right_pinned = _make_tab_pinned_right("  Шум + Цвет  ",
                                                            right_width=620,
                                                            left_width=580)
        t4_vfr = _make_tab("  VFR  ")                # VFR jitter (отдельная вкладка)
        t4_audio = _make_tab("  Звук  ")             # Audio shift (отдельная вкладка)
        # Лого + Шторы — тоже с закреплённым превью кадра справа (реал-тайм)
        t4_logo, _logo_right_pinned = _make_tab_pinned_right("  Лого + Шторы  ",
                                                             right_width=360,
                                                             left_width=620)

        # Карта эффект-вкладок: outer-tab → (базовое_имя, [список BooleanVar групп])
        # Используем outer-frame (inner._tab_outer), потому что Notebook ищет
        # вкладку только по outer-Frame, который добавлен через nb.add().
        self._tab_effect_groups = [
            (t4_geom._tab_outer,  "Геометрия",   [self.pp_grp_crop, self.pp_grp_jitter, self.pp_grp_zoom]),
            (t4_color._tab_outer, "Шум + Цвет",  [self.pp_grp_noise, self.pp_grp_color]),
            (t4_vfr._tab_outer,   "VFR",         [self.pp_grp_vfr]),
            (t4_audio._tab_outer, "Звук",        [self.pp_grp_audio]),
            (t4_logo._tab_outer,  "Лого + Шторы",[self.pp_logo_enabled, self.pp_letterbox_enabled]),
        ]

        # Иконки-квадратики для индикации состояния группы в табе.
        # Зелёный (success cosmo #28a745) = всё ON; жёлтый = частично; серый = всё OFF.
        self._tab_icons = {}
        if _PIL_OK:
            try:
                def _mk_icon(color):
                    # антиалиас: рисуем большой → ресайз вниз, без обводки
                    from PIL import ImageDraw
                    big = Image.new("RGBA", (56, 56), (0, 0, 0, 0))
                    d = ImageDraw.Draw(big)
                    d.ellipse((2, 2, 54, 54), fill=color)
                    im = big.resize((14, 14), Image.LANCZOS)
                    return ImageTk.PhotoImage(im)
                self._tab_icons = {
                    "on":   _mk_icon("#28a745"),  # зелёный
                    "half": _mk_icon("#ffd60a"),  # чистый жёлтый
                    "off":  _mk_icon("#c0c5cc"),  # серый
                }
            except Exception:
                self._tab_icons = {}

        def _refresh_tab_indicators(*_a):
            for outer, base, vars_list in self._tab_effect_groups:
                try:
                    any_on = any(bool(v.get()) for v in vars_list)
                    all_on = all(bool(v.get()) for v in vars_list)
                except Exception:
                    any_on, all_on = True, True
                if all_on:
                    key, sym = "on", "✓"
                elif any_on:
                    key, sym = "half", "◐"
                else:
                    key, sym = "off", "○"
                try:
                    if self._tab_icons.get(key) is not None:
                        nb.tab(outer, text=f"  {base}  ",
                               image=self._tab_icons[key], compound="left")
                    else:
                        nb.tab(outer, text=f"  {sym} {base}  ")
                except Exception:
                    pass
        # Хук на каждый BooleanVar
        for _bv in (self.pp_grp_crop, self.pp_grp_jitter, self.pp_grp_zoom,
                    self.pp_grp_noise, self.pp_grp_color, self.pp_grp_vfr,
                    self.pp_grp_audio, self.pp_logo_enabled, self.pp_letterbox_enabled):
            try: _bv.trace_add("write", _refresh_tab_indicators)
            except Exception: pass
        _refresh_tab_indicators()

        # Double-click по табу → toggle всех групп этой вкладки.
        def _on_tab_double_click(ev):
            try:
                idx = nb.index(f"@{ev.x},{ev.y}")
                tab_path = nb.tabs()[idx]
            except Exception:
                return
            for outer, base, vars_list in self._tab_effect_groups:
                if str(outer) == str(tab_path):
                    any_on = any(bool(v.get()) for v in vars_list)
                    new_val = not any_on
                    for v in vars_list:
                        try: v.set(new_val)
                        except Exception: pass
                    return
        nb.bind("<Double-Button-1>", _on_tab_double_click)
        t4_codec = _make_tab("  Кодек  ")          # CRF + Preset
        # Лог — без скролл-canvas: Text сам со скроллом, тянется до низа.
        t_log = ttk.Frame(nb, padding=8)
        nb.add(t_log, text="  Лог  ")

        # ===== Helpers: ряд «название — слайдер — значение — ⓘ» =====
        # Используем tk.Scale (а не ttk.Scale) чтобы рельс был ЯВНО темнее фона
        # — ttkbootstrap/ttk-стили не позволяют надёжно переопределить troughcolor.
        _BG = getattr(self, "_BG_COLOR", "#dde3eb")
        _TROUGH = getattr(self, "_TROUGH_COLOR", "#6a7686")
        def _slider_row(parent, label, var, frm, to, resolution, hint=None, width=260, int_mode=False):
            row = ttk.Frame(parent); row.pack(fill="x", padx=10, pady=3)
            ttk.Label(row, text=label, width=22, anchor="w").pack(side="left")
            val_lbl = ttk.Label(row, width=8, anchor="e")
            def _fmt(v):
                try: fv = float(v)
                except Exception: return str(v)
                if int_mode: return f"{int(round(fv))}"
                if resolution >= 1:    return f"{fv:.0f}"
                elif resolution >= 0.1: return f"{fv:.1f}"
                elif resolution >= 0.01: return f"{fv:.2f}"
                else: return f"{fv:.3f}"
            def _on_change(*_): val_lbl.config(text=_fmt(var.get()))
            scl = tk.Scale(row, from_=frm, to=to,
                           resolution=(1 if int_mode else resolution),
                           orient="horizontal", variable=var, length=width,
                           bg=_BG, troughcolor=_TROUGH,
                           highlightthickness=1, highlightbackground="#9ba6b3", bd=0,
                           showvalue=0, sliderrelief="flat",
                           sliderlength=18, activebackground="#2780E3")
            # Дублируем настройку через .configure — иногда initial-параметры
            # игнорируются Tk при наличии ttkbootstrap-стилизации.
            try: scl.configure(troughcolor=_TROUGH, bg=_HANDLE, highlightthickness=0)
            except Exception: pass
            try: var.trace_add("write", lambda *_: _on_change())
            except Exception: pass
            scl.pack(side="left", padx=6)
            _on_change()
            val_lbl.pack(side="left", padx=(2, 6))
            if hint:
                _q_label(row, hint).pack(side="left", padx=4)

        # Хелпер: добавляет крупный toggle-Checkbutton первой строкой LabelFrame'а.
        def _grp_toggle(parent, var, label="Применять эту группу эффектов"):
            row = ttk.Frame(parent)
            row.pack(fill="x", padx=10, pady=(8, 4), anchor="w")
            ttk.Checkbutton(row, text=label, variable=var,
                            bootstyle="success-round-toggle",
                            padding=(2, 4)).pack(side="left")

        # 1. Safe area crop
        f1 = ttk.LabelFrame(t4_geom, text="Safe area crop — лёгкая обрезка краёв с возвратом к размеру")
        f1.pack(fill="x", padx=10, pady=4)
        _grp_toggle(f1, self.pp_grp_crop)
        _slider_row(f1, "Обрезка %:", self.pp_crop_percent, 0, 8, 0.1,
                    hint=("Обрезает края на % и масштабирует обратно к исходному размеру. "
                          "Меняет пиксельную сетку без видимой смены сюжета — простой и надёжный "
                          "способ обойти pHash/aHash детекторы.\n"
                          "• Мягко: 2–4%\n"
                          "• Стандарт (мягкая уникализация): 6%\n"
                          "• Жёстко: 7–8% (могут стать заметны срезы по краям)\n"
                          "• 0 = эффект выключен."))

        # 2. Spatio-temporal jitter — два toggle (warp + zoom) первой строкой
        f2 = ttk.LabelFrame(t4_geom, text="Spatio-temporal jitter — субпиксельный warp + микрозум")
        f2.pack(fill="x", padx=10, pady=4)
        _row2 = ttk.Frame(f2); _row2.pack(fill="x", padx=10, pady=(8, 4), anchor="w")
        ttk.Checkbutton(_row2, text="Применять warp (jitter)", variable=self.pp_grp_jitter,
                        bootstyle="success-round-toggle", padding=(2, 4)).pack(side="left", padx=(0, 24))
        ttk.Checkbutton(_row2, text="Применять микрозум", variable=self.pp_grp_zoom,
                        bootstyle="success-round-toggle", padding=(2, 4)).pack(side="left")
        _slider_row(f2, "Jitter X (px):", self.pp_jitter_x, 0, 24, 0.5,
                    hint=("Микро-смещение кадра по горизонтали по синусоиде с заданным периодом. "
                          "Сильно ломает temporal/flow-метрики, не задевает aHash.\n"
                          "• Мягко: 4–8 px\n• Стандарт: 10 px\n• Сильно: 16–24 px (видно на статичных кадрах)\n"
                          "• 0 = выкл."))
        _slider_row(f2, "Jitter Y (px):", self.pp_jitter_y, 0, 16, 0.5,
                    hint=("Микро-смещение по вертикали. Тот же принцип что Jitter X.\n"
                          "• Мягко: 4–8 px • Стандарт: 11 px • Сильно: 14–16 px • 0 = выкл."))
        _slider_row(f2, "Период X (сек):", self.pp_jitter_period_x, 2, 20, 0.5,
                    hint=("Сколько секунд занимает полный цикл колебания по X. Короткий период = "
                          "видимая дрожь, длинный = почти незаметно но эффект всё ещё работает.\n"
                          "• Рекомендуется: 12–18 сек (стандарт 17.5)\n"
                          "• Не делать одинаковым с Период Y — лучше когда X и Y расходятся."))
        _slider_row(f2, "Период Y (сек):", self.pp_jitter_period_y, 2, 20, 0.5,
                    hint="Период колебания по Y. Стандарт 15.5 сек. Лучше слегка отличаться от Период X.")
        _slider_row(f2, "Микрозум %:", self.pp_zoom_amplitude, 0, 5, 0.1,
                    hint=("Лёгкое пульсирующее увеличение/уменьшение масштаба.\n"
                          "• Мягко: 1.5–2.5%\n• Стандарт: 3.7%\n• Сильно: 4.5–5% (видимое 'дыхание' кадра)\n"
                          "• 0 = выкл."))
        _slider_row(f2, "Период зума (сек):", self.pp_zoom_period, 3, 20, 0.5,
                    hint=("Сколько секунд занимает один цикл микрозума (приближение → удаление → возврат).\n"
                          "• Быстро (3–8 сек): видимое «дыхание» кадра, может укачивать\n"
                          "• Стандарт: 15–18 сек (спокойное, незаметное)\n"
                          "• Медленно (19–20 сек): практически невидимо, но эффект всё ещё работает на метриках"))

        # 3. Micro noise / blur
        f3 = ttk.LabelFrame(t4_color, text="Micro noise / blur — мягкий шум и резкость/мягкость")
        f3.pack(fill="x", padx=10, pady=4)
        _grp_toggle(f3, self.pp_grp_noise)
        _slider_row(f3, "Шум:", self.pp_noise_strength, 0, 10, 1, int_mode=True,
                    hint=("Сила пиксельного шума, добавляемого каждый кадр.\n"
                          "• Мягко: 2–3 (почти незаметно)\n"
                          "• Стандарт: 4 (видно только на однотонных фонах)\n"
                          "• Сильно: 6–10 (выглядит как старый ТВ-сигнал)\n"
                          "• 0 = выкл."))
        _slider_row(f3, "Резкость / блюр:", self.pp_blur_amount, -0.4, 0.4, 0.02,
                    hint=("Параметр unsharp: положительное = резче, отрицательное = размытие.\n"
                          "• Мягко: ±0.1\n• Средне: ±0.2–0.25\n• Сильно: ±0.35–0.4 (заметная картинка)\n"
                          "• 0 = выкл."))

        # Левая колонка (со слайдерами) идёт в скроллируемый inner t4_color.
        # Правая колонка с палитрой и превью — _cc_right_pinned, она ЗАКРЕПЛЕНА
        # за вкладкой и не скроллится вместе со слайдерами.
        cc_left = t4_color
        cc_right = _cc_right_pinned

        # 4. Color — базовое (toggle сразу для всего цветокора: базовое + гамма + Hue + cb)
        f4 = ttk.LabelFrame(cc_left, text="Цветокор — базовое (toggle включает весь цветокор)")
        f4.pack(fill="x", padx=10, pady=4)
        _grp_toggle(f4, self.pp_grp_color, label="Применять весь цветокор")
        _slider_row(f4, "Brightness:", self.pp_brightness, -0.5, 0.5, 0.01,
                    hint=("Яркость. 0 = нейтрально.\n"
                          "• Мягко: ±0.03–0.05 (зрителю незаметно, метрики реагируют)\n"
                          "• Сильно: ±0.15+ (явно темнее/светлее)"))
        _slider_row(f4, "Contrast:", self.pp_contrast, 0.5, 2.0, 0.01,
                    hint=("Контраст. 1.0 = нейтрально.\n"
                          "• Мягко: 1.03–1.08 (стандарт 1.05)\n"
                          "• Заметно: 1.15+ или ниже 0.9"))
        _slider_row(f4, "Saturation:", self.pp_saturation, 0, 3.0, 0.01,
                    hint=("Насыщенность цвета. 1.0 = как было, 0 = ч/б, >1 = сочнее.\n"
                          "• Мягко: 1.03–1.08 (стандарт 1.05)\n"
                          "• Кинолук: 0.85–0.95 (приглушённые тона)\n"
                          "• Сильно: 1.3+ (мультяшно)"))

        # 5. Гамма
        f5 = ttk.LabelFrame(cc_left, text="Цветокор — гамма")
        f5.pack(fill="x", padx=10, pady=4)
        _slider_row(f5, "Gamma:", self.pp_gamma, 0.4, 2.5, 0.01,
                    hint=("Общая гамма-коррекция средних тонов. 1.0 = нейтрально.\n"
                          "• Мягко: 0.95–1.05\n"
                          "• Светлее средние тона: 1.1–1.2\n"
                          "• Темнее (кинематографично): 0.8–0.9"))
        _slider_row(f5, "Gamma R:", self.pp_gamma_r, 0.4, 2.5, 0.01,
                    hint=("Гамма красного канала. 1.0 = нейтрально.\n"
                          "• Тёплый оттенок: 1.05–1.15\n"
                          "• Холодный (зелёно-синий): 0.85–0.95"))
        _slider_row(f5, "Gamma G:", self.pp_gamma_g, 0.4, 2.5, 0.01,
                    hint="Гамма зелёного канала. 1.0 = нейтрально. ±0.05 — мягкий сдвиг.")
        _slider_row(f5, "Gamma B:", self.pp_gamma_b, 0.4, 2.5, 0.01,
                    hint=("Гамма синего канала. 1.0 = нейтрально.\n"
                          "• Холодный (синие тени): 1.05–1.15\n"
                          "• Тёплый (приглушить синий): 0.85–0.95"))
        _slider_row(f5, "Gamma weight:", self.pp_gamma_weight, 0, 1.0, 0.01,
                    hint=("Степень влияния гамма-коррекции на изображение. 1 = полностью, "
                          "0 = выключает гамма-коррекцию (даже если Gamma ≠ 1). "
                          "Полезно для мягкой подстройки силы эффекта."))

        # 6. Hue
        f6 = ttk.LabelFrame(cc_left, text="Цветокор — тон (Hue)")
        f6.pack(fill="x", padx=10, pady=4)
        _slider_row(f6, "Hue (°):", self.pp_hue_deg, -180, 180, 1, int_mode=False,
                    hint=("Поворот цветового тона по кругу. 0 = без изменений.\n"
                          "• Мягко (незаметно зрителю): ±3–8°\n"
                          "• Заметный сдвиг: ±15–30°\n"
                          "• ±90° и выше — радикально меняет цвета (зелёные становятся розовыми и т.п.)"))
        _slider_row(f6, "Hue Sat. mul:", self.pp_hue_sat_mul, 0, 3, 0.05,
                    hint=("Множитель насыщенности (применяется до eq=saturation).\n"
                          "• 1.0 = нейтрально\n• 0.5 = вполовину менее насыщенный\n"
                          "• 0 = ч/б\n• 1.5+ = очень насыщенно"))

        # 7. Color balance
        f7 = ttk.LabelFrame(cc_left, text="Color balance — баланс по теням / средним / светам (×R, G, B)")
        f7.pack(fill="x", padx=10, pady=4)
        for label, var in [
            ("Тени R:", self.pp_cb_shad_r), ("Тени G:", self.pp_cb_shad_g), ("Тени B:", self.pp_cb_shad_b),
            ("Средние R:", self.pp_cb_mid_r), ("Средние G:", self.pp_cb_mid_g), ("Средние B:", self.pp_cb_mid_b),
            ("Света R:", self.pp_cb_high_r), ("Света G:", self.pp_cb_high_g), ("Света B:", self.pp_cb_high_b),
        ]:
            _slider_row(f7, label, var, -1, 1, 0.02)
        ttk.Label(f7, text="Малые значения (±0.05–0.1) дают «тёплый» или «холодный» оттенок без видимой порчи. 0 = выкл.",
                  foreground="#8a8a8a", wraplength=900).pack(anchor="w", padx=10, pady=(2, 4))

        # Live-палитра в правой колонке. Реагирует на все цветокор-ползунки.
        self._build_pp_palette(cc_right)

        # 8. VFR jitter
        f8 = ttk.LabelFrame(t4_vfr, text="VFR timing jitter — неровный frame timing")
        f8.pack(fill="x", padx=10, pady=4)
        _grp_toggle(f8, self.pp_grp_vfr, label="Применять VFR jitter")
        _slider_row(f8, "Амплитуда (мс):", self.pp_vfr_amplitude_ms, 0, 5, 0.1,
                    hint=("Каждый кадр показывается чуть раньше или позже ровного шага — "
                          "на ±1–5 мс. Длина и скорость ролика не меняются, кадры просто "
                          "идут с неровным интервалом. Это настоящий переменный фреймрейт, "
                          "а не визуальный фильтр; глазу незаметно, но детекторы, ищущие "
                          "дубликаты по ровному ритму кадров, — сбиваются.\n"
                          "• Мягко: 1–2 мс\n• Стандарт: 2.3 мс\n• Сильно: 4–5 мс (на низком "
                          "fps может стать видна неровность)\n• 0 = выкл."))
        _slider_row(f8, "Период (кадры):", self.pp_vfr_period_frames, 3, 60, 1, int_mode=True,
                    hint=("Частота смены длины кадров. Маленький — соседние кадры сильно "
                          "отличаются по сдвигу (острая волна). Большой — сдвиг меняется "
                          "плавно, соседние кадры почти одинаковы, но за длинный отрезок "
                          "видео он медленно гуляет (плавная волна).\n"
                          "Чем выше частота волны — тем сильнее путаем детектор. Чем "
                          "плавнее волна — тем мягче влияние.\n"
                          "• Короткий (3–10): высокая частота — сильнее ломает детекторы\n"
                          "• Стандарт: 10\n"
                          "• Длинный (30–60): низкая частота — мягче, медленнее цикл"))

        # 9. Audio
        f9 = ttk.LabelFrame(t4_audio, text="Audio signal shift")
        f9.pack(fill="x", padx=10, pady=4)
        _grp_toggle(f9, self.pp_grp_audio, label="Применять обработку звука")
        _slider_row(f9, "EQ 3.5 кГц (dB):", self.pp_audio_eq_gain_db, -6, 6, 0.1,
                    hint=("Узкополосный equalizer на 3.5 кГц (1/3 октавы). Слух почти не замечает, "
                          "но спектральный отпечаток меняется.\n"
                          "• Стандарт: −3.5 dB (мягкая уникализация)\n"
                          "• Мягко: ±1–2 dB\n"
                          "• Сильно: ±5–6 dB (заметно на голосе)\n"
                          "• 0 = выкл."))
        _slider_row(f9, "Эхо задержка (мс):", self.pp_audio_echo_delay_ms, 0, 20, 0.5,
                    hint=("Микро-эхо (фильтр aecho): задержка отражения в мс.\n"
                          "• <3 мс: на слух нет\n• 3–6 мс (стандарт 3.5): «комната»\n"
                          "• 10–20 мс: явное эхо\n• 0 = выкл."))
        _slider_row(f9, "Эхо decay:", self.pp_audio_echo_decay, 0, 0.1, 0.005,
                    hint=("Затухание эха (0 = нет эха, 1 = полное повторение).\n"
                          "• Стандарт: 0.025 (едва слышно)\n• Мягко: 0.02–0.04\n"
                          "• Заметно: 0.06+"))

        # 10. Logo
        f10 = ttk.LabelFrame(t4_logo, text="Логотип в углу")
        f10.pack(fill="x", padx=10, pady=4)
        rr = ttk.Frame(f10); rr.pack(fill="x", padx=8, pady=2)
        ttk.Checkbutton(rr, text="Наложить логотип", variable=self.pp_logo_enabled).pack(side="left")
        _q_label(rr, "PNG с альфой рекомендуется. Масштабируется по ширине кадра.").pack(side="left", padx=8)
        rr = ttk.Frame(f10); rr.pack(fill="x", padx=8, pady=2)
        ttk.Label(rr, text="Файл:", width=8, anchor="w").pack(side="left")
        ttk.Entry(rr, textvariable=self.pp_logo_path).pack(side="left", fill="x", expand=True, padx=4)
        ttk.Button(rr, text="Выбрать…", command=self.pick_pp_logo, width=12).pack(side="left")
        rr = ttk.Frame(f10); rr.pack(fill="x", padx=8, pady=2)
        ttk.Label(rr, text="Угол:", width=8, anchor="w").pack(side="left")
        for code, lbl in (("TL", "↖ верх-лево"), ("TR", "↗ верх-право"),
                          ("BL", "↙ низ-лево"), ("BR", "↘ низ-право")):
            ttk.Radiobutton(rr, text=lbl, variable=self.pp_logo_corner, value=code).pack(side="left", padx=6)
        _slider_row(f10, "Отступ (px):", self.pp_logo_margin, 0, 100, 1, int_mode=True,
                    hint="Отступ логотипа от края кадра в пикселях. 15–30 — стандарт для FullHD.")
        _slider_row(f10, "Масштаб (%):", self.pp_logo_scale, 5, 50, 1, int_mode=True,
                    hint=("Ширина логотипа в % от ширины кадра.\n"
                          "• Скромно: 8–10%\n"
                          "• Стандарт: 12% (заметно, но не доминирует)\n"
                          "• Крупно: 18–25% (для брендинга)"))
        _slider_row(f10, "Доп. сдвиг X (px):", self.pp_logo_offset_x, -300, 400, 1, int_mode=True,
                    hint="Дополнительный сдвиг лого по горизонтали относительно края.\n"
                         "• Положительное = ВНУТРЬ кадра\n"
                         "• Отрицательное = НАРУЖУ за край (полезно для круглых лого "
                         "в прозрачном PNG — увести прозрачные поля за границу кадра).")
        _slider_row(f10, "Доп. сдвиг Y (px):", self.pp_logo_offset_y, -300, 400, 1, int_mode=True,
                    hint="Дополнительный сдвиг лого по вертикали относительно края.\n"
                         "• Положительное = ВНУТРЬ кадра\n"
                         "• Отрицательное = НАРУЖУ за край (поверх шторок или за пределы).\n"
                         "Учитывает шторы — отсчёт от границы видимой области.")

        # 11. Letterbox
        f11 = ttk.LabelFrame(t4_logo, text="Чёрные шторы (letterbox)")
        f11.pack(fill="x", padx=10, pady=4)
        rr = ttk.Frame(f11); rr.pack(fill="x", padx=8, pady=2)
        ttk.Checkbutton(rr, text="Наложить чёрные полосы сверху и снизу",
                        variable=self.pp_letterbox_enabled).pack(side="left")
        _q_label(rr, ("Кинематографические шторы. Накладываются drawbox-фильтром поверх кадра "
                      "(изображение под ними остаётся в файле, не обрезается). "
                      "Полезно: меняет визуальный отпечаток, имитирует 'киноформат', "
                      "помогает скрыть субтитры/таймкоды из оригинала.")).pack(side="left", padx=8)
        _slider_row(f11, "Высота полосы %:", self.pp_letterbox_height_pct, 2, 15, 0.5,
                    hint=("Высота одной полосы как % от высоты кадра.\n"
                          "• 4–6%: тонкая рамка, как у некоторых ТВ-каналов\n"
                          "• 8% (стандарт): соотношение ~2.0:1, кинематографично\n"
                          "• 12–15%: широкий 'cinemascope' (2.39:1)"))

        # Превью кадра (закреплено справа от ползунков на этой вкладке).
        # Обновляется реал-тайм при изменении лого/шторок (через тот же
        # _pp_preview_run_chain что и на вкладке Шум + Цвет).
        if not hasattr(self, "_pp_preview_labels"):
            self._pp_preview_labels = []
        self._build_pp_preview_block(_logo_right_pinned)

        # 12. Кодек
        f12 = ttk.LabelFrame(t4_codec, text="Кодек финального реэнкода")
        f12.pack(fill="x", padx=10, pady=4)
        _slider_row(f12, "CRF (качество):", self.pp_crf, 14, 28, 1, int_mode=True,
                    hint=("Constant Rate Factor для libx264. Меньше = лучше качество, больше файл.\n"
                          "• 14–16: визуально идеально, файл огромный\n"
                          "• 17–19: очень хорошо (стандарт 18 для архива)\n"
                          "• 20–23: хорошо (23 = ffmpeg default, ютуб-качество)\n"
                          "• 24–28: видимое падение качества (для черновиков)"))
        rr = ttk.Frame(f12); rr.pack(fill="x", padx=8, pady=4)
        ttk.Label(rr, text="Preset:", width=22, anchor="w").pack(side="left")
        ttk.Combobox(rr, textvariable=self.pp_preset,
                     values=["ultrafast", "superfast", "veryfast", "faster", "fast", "medium", "slow", "veryslow"],
                     width=14, state="readonly").pack(side="left", padx=4)
        _q_label(rr, ("Скорость кодирования vs эффективность сжатия (при том же CRF).\n"
                      "• ultrafast/superfast: быстро, файл крупнее\n"
                      "• fast (стандарт): разумный баланс — рекомендуется\n"
                      "• medium: ffmpeg default, медленнее на ~30%, файл меньше\n"
                      "• slow/veryslow: ещё меньше файл, но в 2–4× медленнее")).pack(side="left", padx=4)

        # ============================================================
        # Лог: история сообщений статуса (всё, что пишется в self.status)
        # ============================================================
        log_top = ttk.Frame(t_log); log_top.pack(fill="x", padx=8, pady=(0, 4))
        ttk.Button(log_top, text="Очистить", command=self._log_clear,
                   bootstyle="secondary-outline", width=14).pack(side="left", padx=2)
        ttk.Button(log_top, text="Сохранить лог…", command=self._log_save,
                   bootstyle="secondary-outline", width=18).pack(side="left", padx=2)
        ttk.Button(log_top, text="Копировать всё", command=self._log_copy,
                   bootstyle="secondary-outline", width=18).pack(side="left", padx=2)
        ttk.Checkbutton(log_top, text="Автопрокрутка",
                        variable=tk.BooleanVar(value=True) if not hasattr(self, "log_autoscroll")
                        else self.log_autoscroll,
                        bootstyle="round-toggle").pack(side="right", padx=4)
        # переменная отдельно (Checkbutton выше связан, но нам нужна ссылка)
        if not hasattr(self, "log_autoscroll"):
            self.log_autoscroll = tk.BooleanVar(value=True)

        log_wrap = ttk.Frame(t_log); log_wrap.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.log_text = tk.Text(log_wrap, wrap="word", height=8,
                                bg="#1e1e1e", fg="#dcdcdc",
                                insertbackground="#dcdcdc",
                                font=("Consolas", 9),
                                relief="flat", bd=0,
                                highlightthickness=1, highlightbackground="#2780E3",
                                state="disabled")
        log_sb = ttk.Scrollbar(log_wrap, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=log_sb.set)
        self.log_text.pack(side="left", fill="both", expand=True)
        log_sb.pack(side="right", fill="y")

        # Перехват self.status.config: каждое обновление статуса дублируется в лог.
        # Делается ровно после создания self.status (см. ниже — bottom-блок), поэтому
        # реально патч устанавливается в _install_status_logger() и вызывается там.

        # ============================================================
        # BOTTOM (общий для всех вкладок) — Run + Progress + Open btns + Status
        # ============================================================
        bottom = ttk.Frame(root, padding=(12, 6, 12, 10))
        bottom.pack(fill="x")
        self.run_btn = ttk.Button(bottom, text="▶  Собрать", command=self.on_run,
                                  bootstyle="success", padding=(20, 12))
        self.run_btn.pack(fill="x", pady=(0, 6))
        # Динамический текст кнопки в зависимости от чекбокса «Включить перекод».
        # OFF → «Собрать быстро (без реэнкода)»; ON → «Собрать с реэнкодом».
        def _refresh_run_btn(*_):
            try:
                if self.pp_enabled.get():
                    self.run_btn.config(text="▶  СОБРАТЬ С REENCODE (С ЭФФЕКТАМИ)")
                else:
                    self.run_btn.config(text="▶  СОБРАТЬ БЫСТРО (БЕЗ ЭФФЕКТОВ)")
            except Exception:
                pass
        try: self.pp_enabled.trace_add("write", lambda *_a: _refresh_run_btn())
        except Exception: pass
        _refresh_run_btn()
        self.progress = ttk.Progressbar(bottom, orient="horizontal",
                                        mode="determinate", maximum=1000,
                                        bootstyle="success-striped")
        self.progress.pack(fill="x", pady=4)
        btns_row = ttk.Frame(bottom); btns_row.pack(fill="x", pady=4)
        self.open_file_btn = ttk.Button(btns_row, text="Открыть файл", command=self.open_file,
                                        state="disabled", width=18, bootstyle="secondary-outline")
        self.open_file_btn.pack(side="left", padx=(0, 6))
        self.open_folder_btn = ttk.Button(btns_row, text="Открыть папку", command=self.open_folder,
                                          state="disabled", width=18, bootstyle="secondary-outline")
        self.open_folder_btn.pack(side="left")
        self.status = ttk.Label(bottom, text="Готов.", anchor="w", bootstyle="secondary")
        self.status.pack(fill="x", pady=(6, 0))

        self.last_output: str | None = None

        # Перехват status.config — каждое обновление статуса дублируется во вкладку «Лог».
        self._install_status_logger()
        self._log_line("=== Audio Inserter запущен ===")
        try:
            self.toggle_mode()
            self.toggle_trim()
            self.toggle_outro()
            self._toggle_full_track()
        except Exception:
            pass

    # ---------- Log tab helpers ----------
    def _install_status_logger(self):
        """Оборачивает self.status.config так, чтобы любой text=... шёл и в self.log_text."""
        _orig = self.status.config
        def _wrapped(*a, **kw):
            if "fg" in kw:
                kw = dict(kw)
                kw.setdefault("foreground", kw.pop("fg"))
            if a and isinstance(a[0], dict) and "fg" in a[0]:
                first = dict(a[0])
                first.setdefault("foreground", first.pop("fg"))
                a = (first, *a[1:])
            txt = kw.get("text")
            if txt is None and a:
                # позиционный config? редко, но на всякий
                first = a[0]
                if isinstance(first, str):
                    txt = first
                elif isinstance(first, dict):
                    txt = first.get("text")
            if txt:
                self._log_line(str(txt))
            return _orig(*a, **kw)
        self.status.config = _wrapped
        self.status.configure = _wrapped

    def _log_line(self, msg: str):
        """Добавить строку в Text-виджет лога (thread-safe). Без перевода строки в msg — сами добавим."""
        if not hasattr(self, "log_text") or self.log_text is None:
            return
        ts = datetime.now().strftime("%H:%M:%S")
        line = f"[{ts}] {msg}\n"
        def _do():
            try:
                self.log_text.configure(state="normal")
                self.log_text.insert("end", line)
                if getattr(self, "log_autoscroll", None) and self.log_autoscroll.get():
                    self.log_text.see("end")
                self.log_text.configure(state="disabled")
            except Exception:
                pass
        try:
            self.root.after(0, _do)
        except Exception:
            _do()

    def _log_clear(self):
        try:
            self.log_text.configure(state="normal")
            self.log_text.delete("1.0", "end")
            self.log_text.configure(state="disabled")
        except Exception:
            pass

    def _log_save(self):
        path = filedialog.asksaveasfilename(
            title="Сохранить лог",
            defaultextension=".log",
            filetypes=[("Log file", "*.log"), ("Text", "*.txt"), ("All", "*.*")],
            initialfile=f"audio_inserter_{datetime.now():%Y%m%d_%H%M%S}.log",
        )
        if not path:
            return
        try:
            data = self.log_text.get("1.0", "end-1c")
            with open(path, "w", encoding="utf-8") as f:
                f.write(data)
            messagebox.showinfo("Лог сохранён", path)
        except Exception as e:
            messagebox.showerror("Ошибка", str(e))

    def _log_copy(self):
        try:
            data = self.log_text.get("1.0", "end-1c")
            self.root.clipboard_clear()
            self.root.clipboard_append(data)
            self.status.config(text="Лог скопирован в буфер обмена.")
        except Exception as e:
            messagebox.showerror("Ошибка", str(e))

    # ---------- Цветокор палитра (live preview) ----------
    def _build_pp_palette(self, parent):
        """Палитра 3×5 цветовых блоков справа от слайдеров. Реагирует на все цветокор-ползунки."""
        if not _PIL_OK:
            ttk.Label(parent, text="(PIL не найден — палитра-превью недоступна)",
                      foreground="#a0a0a0").pack(anchor="n", padx=4, pady=8)
            return

        wrap = ttk.LabelFrame(parent, text="Превью цветокора")
        wrap.pack(side="left", anchor="n", padx=2, pady=4, fill="y")
        info = ttk.Label(wrap, text="Реагирует на все цветокор-ползунки.\nПриближение — направление и силу видно.",
                         foreground="#7a7a7a", justify="left")
        info.pack(anchor="w", padx=6, pady=(4, 4))

        grid = ttk.Frame(wrap); grid.pack(padx=6, pady=(0, 6))
        self._pp_palette_cells = []  # (label_widget, base_rgb, photoimage_ref)
        cell = 38
        for row_idx, row in enumerate(_PP_SAMPLES):
            for col_idx, (name, rgb) in enumerate(row):
                cwrap = ttk.Frame(grid)
                cwrap.grid(row=row_idx * 2, column=col_idx, padx=2, pady=2)
                lbl_img = ttk.Label(cwrap)
                lbl_img.pack()
                lbl_name = ttk.Label(cwrap, text=name, foreground="#6a6a6a", anchor="center")
                lbl_name.pack()
                self._pp_palette_cells.append((lbl_img, rgb, [None]))  # [None] = mutable photo-ref slot
            # spacing row
        self._pp_palette_cell_size = cell

        # trace_add на каждую цветокор-Var → лёгкий debounce (after_idle)
        self._pp_palette_pending = False
        def _trigger(*_a):
            # Обновить лёгкую палитру (мгновенно)
            if not self._pp_palette_pending:
                self._pp_palette_pending = True
                self.root.after(40, self._refresh_pp_palette)
            # И превью реального кадра (с debounce, в фоне)
            try:
                self._pp_preview_schedule_refresh(immediate=False)
            except Exception:
                pass
        # Цветокор-Var
        color_vars = (self.pp_brightness, self.pp_contrast, self.pp_saturation,
                      self.pp_gamma, self.pp_gamma_r, self.pp_gamma_g, self.pp_gamma_b,
                      self.pp_gamma_weight, self.pp_hue_deg, self.pp_hue_sat_mul,
                      self.pp_cb_shad_r, self.pp_cb_shad_g, self.pp_cb_shad_b,
                      self.pp_cb_mid_r, self.pp_cb_mid_g, self.pp_cb_mid_b,
                      self.pp_cb_high_r, self.pp_cb_high_g, self.pp_cb_high_b)
        # Эффект-Var, влияющие на vf-цепь (без VFR/audio — они не видны в одном кадре)
        effect_vars = (self.pp_crop_percent,
                       self.pp_jitter_x, self.pp_jitter_y,
                       self.pp_jitter_period_x, self.pp_jitter_period_y,
                       self.pp_zoom_amplitude, self.pp_zoom_period,
                       self.pp_noise_strength, self.pp_blur_amount,
                       self.pp_letterbox_enabled, self.pp_letterbox_height_pct,
                       self.pp_logo_enabled, self.pp_logo_path,
                       self.pp_logo_corner, self.pp_logo_margin, self.pp_logo_scale,
                       self.pp_logo_offset_x, self.pp_logo_offset_y)
        for var in color_vars + effect_vars:
            try:
                var.trace_add("write", _trigger)
            except Exception:
                pass

        # начальный рендер
        self.root.after(50, self._refresh_pp_palette)

        # Превью кадра — СЛЕВА от палитры (pack(before=wrap)).
        # Виджет создаётся через хелпер _build_pp_preview_block (общий для всех вкладок,
        # на которые тоже нужно живое превью). Регистрирует свой Label в self._pp_preview_labels.
        if not hasattr(self, "_pp_preview_labels"):
            self._pp_preview_labels = []
        self._build_pp_preview_block(parent, place_before=wrap)

    def _build_pp_preview_block(self, parent, place_before=None):
        """LabelFrame с кнопкой «🎞 Превью на случайном кадре» и слотом-Label под кадр.
        Регистрирует Label в self._pp_preview_labels — все экземпляры обновляются
        одновременно при изменении ползунков или клике кнопки."""
        rf_wrap = ttk.LabelFrame(parent, text="Превью на кадре видео")
        if place_before is not None:
            rf_wrap.pack(side="left", anchor="n", padx=(2, 8), pady=4, fill="y",
                         before=place_before)
        else:
            rf_wrap.pack(side="left", anchor="n", padx=2, pady=4, fill="y")
        ttk.Label(rf_wrap,
                  text="Точное превью на случайном кадре из видео.\n"
                       "Повторный клик = новый случайный кадр.\n"
                       "Реагирует на ползунки с задержкой ≈1 секунда.",
                  foreground="#7a7a7a", justify="left").pack(anchor="w", padx=6, pady=(4, 2))
        ttk.Button(rf_wrap, text="🎞 Превью на случайном кадре",
                   command=self._pp_preview_real_frame,
                   bootstyle="info-outline").pack(anchor="w", padx=6, pady=(2, 4))
        lbl = ttk.Label(rf_wrap, text="(нажми кнопку — здесь покажется кадр)",
                        foreground="#9a9a9a", anchor="center", cursor="hand2",
                        justify="center")
        lbl.pack(padx=6, pady=(2, 2))
        lbl.bind("<Button-1>", lambda _e: self._pp_preview_open_fullsize())
        ttk.Label(rf_wrap, text="клик по кадру — чтобы увидеть в большом окне",
                  foreground="#7a7a7a", anchor="center", justify="center").pack(padx=6, pady=(0, 6))
        self._pp_preview_labels.append(lbl)
        # Совместимость со старым кодом — оставляем self._pp_preview_label = первый Label.
        if not hasattr(self, "_pp_preview_label") or self._pp_preview_label is None:
            self._pp_preview_label = lbl

    def _pp_preview_open_fullsize(self):
        """Открыть полноразмерное превью в отдельном окне."""
        img = getattr(self, "_pp_preview_full_img", None)
        if img is None:
            return  # ещё не было прогона — нечего показывать
        win = tk.Toplevel(self.root)
        win.title("Превью на кадре — полный размер")
        # Если кадр больше 90% экрана — даунскейлим до этого размера
        try:
            sw = self.root.winfo_screenwidth()
            sh = self.root.winfo_screenheight()
        except Exception:
            sw, sh = 1920, 1080
        max_w = int(sw * 0.9)
        max_h = int(sh * 0.9)
        show = img.copy()
        if show.width > max_w or show.height > max_h:
            show.thumbnail((max_w, max_h), Image.LANCZOS)
        photo = ImageTk.PhotoImage(show)
        lbl = ttk.Label(win, image=photo)
        lbl.image = photo  # удерживаем ссылку
        lbl.pack(padx=4, pady=4)
        # Esc или клик по картинке закрывают
        win.bind("<Escape>", lambda _e: win.destroy())
        lbl.bind("<Button-1>", lambda _e: win.destroy())

    def _pp_preview_real_frame(self):
        """Кнопка: извлекает НОВЫЙ случайный кадр из выбранного видео,
        затем сразу прогоняет через текущую vf-цепь."""
        if not _PIL_OK:
            messagebox.showerror("Нет PIL", "Pillow не установлен — превью недоступно.")
            return
        video = self.video_path.get().strip()
        if not video or not os.path.isfile(video):
            messagebox.showwarning("Нет видео",
                                   "Сначала выбери видеофайл на вкладке Inserter.")
            return
        dur = probe_duration(video)
        if dur <= 0:
            messagebox.showerror("Ошибка", "Не удалось определить длительность видео (ffprobe).")
            return

        seek = random.uniform(dur * 0.03, dur * 0.97)
        tmp_dir = tempfile.gettempdir()
        tmp_src = os.path.join(tmp_dir, f"ai_preview_src_{os.getpid()}.png")
        cf = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        try:
            subprocess.run(
                ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                 "-ss", f"{seek:.3f}", "-i", video, "-frames:v", "1", "-an", tmp_src],
                check=True, creationflags=cf,
                stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        except subprocess.CalledProcessError as e:
            err = (e.stderr or b"").decode(errors="replace")[:500]
            messagebox.showerror("ffmpeg", f"Не удалось извлечь кадр:\n{err}")
            return
        except FileNotFoundError:
            messagebox.showerror("ffmpeg", "ffmpeg не найден в PATH.")
            return
        if not os.path.isfile(tmp_src):
            messagebox.showerror("Ошибка", "Кадр не создан.")
            return

        self._pp_preview_src_path = tmp_src
        self._pp_preview_src_seek = seek
        # Снять размер кадра
        try:
            with Image.open(tmp_src) as im:
                self._pp_preview_src_size = im.size
        except Exception:
            self._pp_preview_src_size = (1920, 1080)

        # Сразу применить текущие эффекты (в фоне)
        self._pp_preview_schedule_refresh(immediate=True)

    def _pp_preview_schedule_refresh(self, immediate=False):
        """Debounce-планировщик: если за следующие 350мс не будет новых изменений,
        запустится фоновый ffmpeg-прогон по уже извлечённому кадру."""
        if not getattr(self, "_pp_preview_src_path", None):
            return  # ещё не нажимали кнопку — нечего обновлять
        if getattr(self, "_pp_preview_busy", False):
            # ffmpeg идёт прямо сейчас — пометим что нужен ещё один прогон после
            self._pp_preview_dirty = True
            return
        # отменим предыдущий запланированный after, если был
        prev = getattr(self, "_pp_preview_after_id", None)
        if prev is not None:
            try: self.root.after_cancel(prev)
            except Exception: pass
            self._pp_preview_after_id = None
        delay = 0 if immediate else 350
        self._pp_preview_after_id = self.root.after(delay, self._pp_preview_run_chain)

    def _pp_preview_run_chain(self):
        """Запускает ffmpeg-прогон vf-цепи в фоне; результат кидает в Label через after()."""
        self._pp_preview_after_id = None
        src = getattr(self, "_pp_preview_src_path", None)
        if not src or not os.path.isfile(src):
            return
        opts = self._collect_pp_options()
        src_w, src_h = getattr(self, "_pp_preview_src_size", (1920, 1080))
        vf_parts = []
        for fn in (
            lambda: _pp_safe_crop_vf(opts, src_w, src_h),
            lambda: _pp_jitter_vf(opts, src_w, src_h, 25.0),
            lambda: _pp_letterbox_vf(opts, src_h),
            lambda: _pp_noise_blur_vf(opts),
            lambda: _pp_color_vf(opts),
        ):
            try:
                s = fn()
                if s: vf_parts.append(s)
            except Exception:
                pass
        vf_chain = ",".join(vf_parts) if vf_parts else None
        logo_enabled = opts.get("logo_enabled") and opts.get("logo_path") and os.path.isfile(opts["logo_path"] or "")
        seek_val = getattr(self, "_pp_preview_src_seek", 0.0)
        n_eff = len(vf_parts) + (1 if logo_enabled else 0)

        self._pp_preview_busy = True
        self._pp_preview_dirty = False

        def _worker():
            tmp_dir = tempfile.gettempdir()
            tmp_out = os.path.join(tmp_dir, f"ai_preview_out_{os.getpid()}.png")
            tmp_logo = os.path.join(tmp_dir, f"ai_preview_logo_{os.getpid()}.png")
            cf = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            final_path = src
            try:
                if vf_chain:
                    subprocess.run(
                        ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                         "-i", src, "-vf", vf_chain, "-frames:v", "1", tmp_out],
                        check=True, creationflags=cf,
                        stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
                    final_path = tmp_out
                if logo_enabled:
                    corner = (opts.get("logo_corner", "TR") or "TR").upper()
                    margin = int(opts.get("logo_margin", 20) or 20)
                    scale_k = float(opts.get("logo_scale", 0.12) or 0.12)
                    # Учитываем шторы — лого внутрь видимой области + ручной сдвиг X/Y
                    lb_on = bool(opts.get("letterbox_enabled"))
                    lb_pct = float(opts.get("letterbox_height_pct", 0) or 0) if lb_on else 0.0
                    ox = int(opts.get("logo_offset_x", 0) or 0)
                    oy = int(opts.get("logo_offset_y", 0) or 0)
                    m_x = margin + ox
                    offy = f"({lb_pct:.3f}/100*main_h+{margin}+{oy})"
                    pos = {
                        "TL": f"{m_x}:{offy}",
                        "TR": f"main_w-overlay_w-{m_x}:{offy}",
                        "BL": f"{m_x}:main_h-overlay_h-{offy}",
                        "BR": f"main_w-overlay_w-{m_x}:main_h-overlay_h-{offy}",
                    }.get(corner, f"main_w-overlay_w-{m_x}:{offy}")
                    # scale2ref — масштаб лого относительно ширины КАДРА (см. apply_postprocess)
                    fc = (f"[1:v][0:v]scale2ref=w='iw*{scale_k:.4f}':h='-1'[lg][base];"
                          f"[base][lg]overlay={pos}[vout]")
                    subprocess.run(
                        ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                         "-i", final_path, "-i", opts["logo_path"],
                         "-filter_complex", fc, "-map", "[vout]",
                         "-frames:v", "1", tmp_logo],
                        check=True, creationflags=cf,
                        stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
                    final_path = tmp_logo
                img = Image.open(final_path).convert("RGB")
                # Полноразмерный кадр сохраняем отдельно (для клика-увеличения),
                # в превью идёт уменьшенная копия 320×180.
                full_img = img.copy()
                img.thumbnail((320, 180), Image.LANCZOS)
                photo_ready = img  # PhotoImage создадим в main thread (Tk не thread-safe)
            except Exception as e:
                photo_ready = None
                full_img = None
                err_text = str(e)[:200]
            else:
                err_text = None

            def _apply():
                self._pp_preview_busy = False
                if photo_ready is not None:
                    try:
                        photo = ImageTk.PhotoImage(photo_ready)
                        # Обновляем ВСЕ зарегистрированные preview-Label'ы (на всех вкладках)
                        for _lbl in getattr(self, "_pp_preview_labels", []):
                            try: _lbl.configure(image=photo, text="")
                            except Exception: pass
                        self._pp_preview_photo_ref = photo
                        self._pp_preview_full_img = full_img  # для клика-увеличения
                        self.status.config(text=f"Превью: t={seek_val:.1f}s ({n_eff} эффектов)")
                    except Exception:
                        pass
                else:
                    self.status.config(text=f"Превью: ошибка ({err_text or '?'})")
                # если за время прогона пришли новые изменения — запускаем ещё раз
                if getattr(self, "_pp_preview_dirty", False):
                    self._pp_preview_schedule_refresh(immediate=False)
            try:
                self.root.after(0, _apply)
            except Exception:
                pass

        threading.Thread(target=_worker, daemon=True).start()

    def _refresh_pp_palette(self):
        self._pp_palette_pending = False
        if not _PIL_OK or not hasattr(self, "_pp_palette_cells"):
            return
        try:
            opts = {
                "brightness": self.pp_brightness.get(),
                "contrast": self.pp_contrast.get(),
                "saturation": self.pp_saturation.get(),
                "gamma": self.pp_gamma.get(),
                "gamma_r": self.pp_gamma_r.get(),
                "gamma_g": self.pp_gamma_g.get(),
                "gamma_b": self.pp_gamma_b.get(),
                "gamma_weight": self.pp_gamma_weight.get(),
                "hue_deg": self.pp_hue_deg.get(),
                "hue_sat_mul": self.pp_hue_sat_mul.get(),
                "cb_shad_r": self.pp_cb_shad_r.get(), "cb_shad_g": self.pp_cb_shad_g.get(), "cb_shad_b": self.pp_cb_shad_b.get(),
                "cb_mid_r":  self.pp_cb_mid_r.get(),  "cb_mid_g":  self.pp_cb_mid_g.get(),  "cb_mid_b":  self.pp_cb_mid_b.get(),
                "cb_high_r": self.pp_cb_high_r.get(), "cb_high_g": self.pp_cb_high_g.get(), "cb_high_b": self.pp_cb_high_b.get(),
            }
        except Exception:
            return
        size = getattr(self, "_pp_palette_cell_size", 38)
        for (lbl, base_rgb, ref_slot) in self._pp_palette_cells:
            try:
                out_rgb = _pp_simulate_colorcorr(base_rgb, opts)
                img = Image.new("RGB", (size, size), out_rgb)
                photo = ImageTk.PhotoImage(img)
                lbl.configure(image=photo)
                ref_slot[0] = photo  # удерживаем ссылку — иначе GC съест и квадрат пропадёт
            except Exception:
                continue

    def open_file(self):
        if not self.last_output or not os.path.isfile(self.last_output):
            return
        try:
            if os.name == "nt":
                os.startfile(self.last_output)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", self.last_output])
            else:
                subprocess.Popen(["xdg-open", self.last_output])
        except Exception as e:
            messagebox.showerror("Ошибка", str(e))

    def open_folder(self):
        if not self.last_output or not os.path.isfile(self.last_output):
            return
        folder = os.path.dirname(self.last_output)
        try:
            if os.name == "nt":
                # explorer /select подсвечивает сам файл в папке
                subprocess.Popen(["explorer", "/select,", os.path.normpath(self.last_output)])
            elif sys.platform == "darwin":
                subprocess.Popen(["open", "-R", self.last_output])
            else:
                subprocess.Popen(["xdg-open", folder])
        except Exception as e:
            messagebox.showerror("Ошибка", str(e))

    def pick_video(self):
        path = filedialog.askopenfilename(
            title="Видео",
            filetypes=[("Видео", "*.mp4 *.mov *.mkv *.avi *.webm *.m4v"), ("Все файлы", "*.*")],
        )
        if path:
            self.video_path.set(path)

    def pick_audio(self):
        path = filedialog.askopenfilename(
            title="Аудио",
            filetypes=[("Аудио", "*.mp3 *.wav *.aac *.m4a *.flac *.ogg *.opus"), ("Все файлы", "*.*")],
        )
        if path:
            self.audio_path.set(path)
            self.audio_track_start.set("0")

    def pick_insert_video(self):
        path = filedialog.askopenfilename(
            title="Видео для insert-сегмента",
            filetypes=[("Видео", "*.mp4 *.mov *.mkv *.avi *.webm *.m4v"), ("Все файлы", "*.*")],
        )
        if path:
            self.insert_video_path.set(path)

    def toggle_mode(self):
        """Enable/disable insert-video controls based on selected mode."""
        is_expand = self.mode.get() == "expand"
        use_source = bool(self.use_source_insert.get())
        overlay = bool(self.overlay_timer.get())
        external_state = "normal" if is_expand and not use_source else "disabled"
        expand_state = "normal" if is_expand else "disabled"
        source_radio_state = "normal" if is_expand and use_source else "disabled"
        timer_text_state = "normal" if is_expand and overlay else "disabled"
        self.insert_video_entry.config(state=external_state)
        self.insert_video_btn.config(state=external_state)
        self.insert_video_start_entry.config(state=external_state)
        self.source_insert_check.config(state=expand_state)
        self.overlay_timer_check.config(state=expand_state)
        for widget in (self.source_before_radio, self.source_after_radio):
            widget.config(state=source_radio_state)
        for widget in (
            self.pause_title_entry,
            self.pause_prefix_entry,
            self.pause_pos_top_radio,
            self.pause_pos_center_radio,
            self.pause_pos_bottom_radio,
        ):
            widget.config(state=timer_text_state)
        # Громкость оригинала: в expand оригинал в момент вклейки отсутствует, ставим 0
        # и блокируем слайдер — наглядно показываем, что оригинала не будет.
        # При возврате в mix восстанавливаем последнее введённое юзером значение.
        if is_expand:
            if self.duck.get() != 0:
                self._duck_mix_last = self.duck.get()
            self.duck.set(0)
            self.duck_scale.config(state="disabled")
        else:
            self.duck_scale.config(state="normal")
            if self.duck.get() == 0 and getattr(self, "_duck_mix_last", None):
                self.duck.set(self._duck_mix_last)
            if not self.full_track.get() and (self.duration.get().strip() in {"", "10", "10.0"}):
                self.full_track.set(True)
                self._toggle_full_track()

    def toggle_trim(self):
        """Enable/disable trim inputs based on checkbox."""
        state = "normal" if self.trim_enabled.get() else "disabled"
        self.trim_start_entry.config(state=state)
        self.trim_end_entry.config(state=state)

    def toggle_outro(self):
        """Enable/disable outro file inputs based on checkbox."""
        state = "normal" if self.outro_enabled.get() else "disabled"
        self.outro_entry.config(state=state)
        self.outro_btn.config(state=state)

    def pick_outro(self):
        path = filedialog.askopenfilename(
            title="Видео авторки (outro)",
            filetypes=[("Видео", "*.mp4 *.mov *.mkv *.avi *.webm *.m4v"), ("Все файлы", "*.*")],
        )
        if path:
            self.outro_path.set(path)

    def pick_pp_logo(self):
        path = filedialog.askopenfilename(
            title="Логотип (PNG с альфой рекомендуется)",
            filetypes=[("Изображения", "*.png *.jpg *.jpeg *.webp"), ("Все файлы", "*.*")],
        )
        if path:
            self.pp_logo_path.set(path)

    def _pp_reset_defaults(self):
        """Вернуть все pp_* значения к НЕЙТРАЛЬНЫМ (фактически отключает все эффекты)."""
        # Снимаем все toggle-чекбоксы групп
        for v in (self.pp_grp_crop, self.pp_grp_jitter, self.pp_grp_zoom,
                  self.pp_grp_noise, self.pp_grp_color, self.pp_grp_vfr,
                  self.pp_grp_audio):
            try: v.set(False)
            except Exception: pass
        self.pp_crop_percent.set(0.0)
        self.pp_jitter_x.set(0.0); self.pp_jitter_y.set(0.0)
        self.pp_jitter_period_x.set(17.5); self.pp_jitter_period_y.set(15.5)
        self.pp_zoom_amplitude.set(0.0); self.pp_zoom_period.set(18.0)
        self.pp_noise_strength.set(0); self.pp_blur_amount.set(0.0)
        self.pp_brightness.set(0.0); self.pp_contrast.set(1.0); self.pp_saturation.set(1.0)
        self.pp_gamma.set(1.0); self.pp_gamma_r.set(1.0); self.pp_gamma_g.set(1.0)
        self.pp_gamma_b.set(1.0); self.pp_gamma_weight.set(1.0)
        self.pp_hue_deg.set(0.0); self.pp_hue_sat_mul.set(1.0)
        for v in (self.pp_cb_shad_r, self.pp_cb_shad_g, self.pp_cb_shad_b,
                  self.pp_cb_mid_r, self.pp_cb_mid_g, self.pp_cb_mid_b,
                  self.pp_cb_high_r, self.pp_cb_high_g, self.pp_cb_high_b):
            v.set(0.0)
        self.pp_vfr_amplitude_ms.set(0.0); self.pp_vfr_period_frames.set(10)
        self.pp_audio_eq_gain_db.set(0.0); self.pp_audio_echo_delay_ms.set(0.0)
        self.pp_audio_echo_decay.set(0.025)
        self.pp_logo_enabled.set(False); self.pp_logo_path.set("")
        self.pp_logo_corner.set("TR"); self.pp_logo_margin.set(20); self.pp_logo_scale.set(12.0)
        self.pp_logo_offset_x.set(0); self.pp_logo_offset_y.set(0)
        self.pp_letterbox_enabled.set(False); self.pp_letterbox_height_pct.set(8.0)
        self.pp_crf.set(23); self.pp_preset.set("fast")

    def _pp_load_soft_defaults(self):
        """Сбросить к «мягкой уникализации» (значения со скрина thesis-UI)."""
        self.pp_crop_percent.set(6.0)
        self.pp_jitter_x.set(10.0); self.pp_jitter_y.set(11.0)
        self.pp_jitter_period_x.set(17.5); self.pp_jitter_period_y.set(15.5)
        self.pp_zoom_amplitude.set(3.7); self.pp_zoom_period.set(18.0)
        self.pp_noise_strength.set(4); self.pp_blur_amount.set(0.0)
        self.pp_brightness.set(0.0); self.pp_contrast.set(1.05); self.pp_saturation.set(1.05)
        self.pp_gamma.set(1.0); self.pp_gamma_r.set(1.0); self.pp_gamma_g.set(1.0)
        self.pp_gamma_b.set(1.0); self.pp_gamma_weight.set(1.0)
        self.pp_hue_deg.set(0.0); self.pp_hue_sat_mul.set(1.0)
        for v in (self.pp_cb_shad_r, self.pp_cb_shad_g, self.pp_cb_shad_b,
                  self.pp_cb_mid_r, self.pp_cb_mid_g, self.pp_cb_mid_b,
                  self.pp_cb_high_r, self.pp_cb_high_g, self.pp_cb_high_b):
            v.set(0.0)
        self.pp_vfr_amplitude_ms.set(2.3); self.pp_vfr_period_frames.set(10)
        self.pp_audio_eq_gain_db.set(-3.5); self.pp_audio_echo_delay_ms.set(3.5)
        self.pp_audio_echo_decay.set(0.025)
        # шторы (letterbox) — юзер-чойс, к уникализации не относится; пресет их не трогает
        self.pp_crf.set(23); self.pp_preset.set("fast")

    @staticmethod
    def _user_defaults_path():
        return os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "audio_inserter_user_defaults.json")

    def _pp_save_user_defaults(self):
        """Сохранить текущие значения как пользовательские дефолты (JSON рядом со скриптом).
        При следующем запуске GUI они автоматически подхватятся."""
        data = self._collect_pp_options()
        # Дополнительно — audio_track_start (тоже хочется запоминать)
        data["_audio_track_start"] = self.audio_track_start.get()
        data["_pp_enabled"] = bool(self.pp_enabled.get())
        # И состояния всех toggle-чекбоксов групп (чтобы не нужно было снова
        # включать после перезапуска).
        data["_grp_crop"]   = bool(self.pp_grp_crop.get())
        data["_grp_jitter"] = bool(self.pp_grp_jitter.get())
        data["_grp_zoom"]   = bool(self.pp_grp_zoom.get())
        data["_grp_noise"]  = bool(self.pp_grp_noise.get())
        data["_grp_color"]  = bool(self.pp_grp_color.get())
        data["_grp_vfr"]    = bool(self.pp_grp_vfr.get())
        data["_grp_audio"]  = bool(self.pp_grp_audio.get())
        try:
            with open(self._user_defaults_path(), "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            messagebox.showinfo("Сохранено",
                                f"Текущие значения сохранены как дефолт:\n{self._user_defaults_path()}\n\n"
                                "При следующем запуске они применятся автоматически.")
        except Exception as e:
            messagebox.showerror("Ошибка сохранения", str(e))

    def _toggle_pp_enabled(self):
        """Переключатель главного «Включить перекод с эффектами» по клику кнопки."""
        try: self.pp_enabled.set(not bool(self.pp_enabled.get()))
        except Exception: pass

    def _pp_apply_user_defaults(self):
        """Применить пользовательские дефолты прямо сейчас (без перезапуска).
        Если файла дефолтов ещё нет — сказать юзеру что сначала надо «Сохранить как дефолт»."""
        path = self._user_defaults_path()
        if not os.path.isfile(path):
            messagebox.showwarning(
                "Нет сохранённого дефолта",
                "Файл пользовательских дефолтов ещё не создан.\n\n"
                "Сначала настрой эффекты как тебе нравится и нажми "
                "«💾 Сохранить как дефолт» — потом эту кнопку можно будет использовать "
                "для быстрого возврата к своим значениям.")
            return
        self._pp_load_user_defaults_if_any()
        self.status.config(text=f"Применён пользовательский дефолт: {path}")

    def _pp_load_user_defaults_if_any(self):
        """Если файл пользовательских дефолтов есть — применить."""
        path = self._user_defaults_path()
        if not os.path.isfile(path):
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            return
        # Маппинг ключей JSON → tk.*Var атрибут
        m = {
            "crop_percent": "pp_crop_percent",
            "jitter_x": "pp_jitter_x", "jitter_y": "pp_jitter_y",
            "jitter_period_x": "pp_jitter_period_x", "jitter_period_y": "pp_jitter_period_y",
            "zoom_amplitude": "pp_zoom_amplitude", "zoom_period": "pp_zoom_period",
            "noise_strength": "pp_noise_strength", "blur_amount": "pp_blur_amount",
            "brightness": "pp_brightness", "contrast": "pp_contrast", "saturation": "pp_saturation",
            "gamma": "pp_gamma", "gamma_r": "pp_gamma_r", "gamma_g": "pp_gamma_g",
            "gamma_b": "pp_gamma_b", "gamma_weight": "pp_gamma_weight",
            "hue_deg": "pp_hue_deg", "hue_sat_mul": "pp_hue_sat_mul",
            "cb_shad_r": "pp_cb_shad_r", "cb_shad_g": "pp_cb_shad_g", "cb_shad_b": "pp_cb_shad_b",
            "cb_mid_r": "pp_cb_mid_r", "cb_mid_g": "pp_cb_mid_g", "cb_mid_b": "pp_cb_mid_b",
            "cb_high_r": "pp_cb_high_r", "cb_high_g": "pp_cb_high_g", "cb_high_b": "pp_cb_high_b",
            "vfr_amplitude_ms": "pp_vfr_amplitude_ms", "vfr_period_frames": "pp_vfr_period_frames",
            "audio_eq_gain_db": "pp_audio_eq_gain_db",
            "audio_echo_delay_ms": "pp_audio_echo_delay_ms",
            "audio_echo_decay": "pp_audio_echo_decay",
            "logo_enabled": "pp_logo_enabled", "logo_path": "pp_logo_path",
            "logo_corner": "pp_logo_corner", "logo_margin": "pp_logo_margin",
            "logo_scale": "pp_logo_scale",
            "logo_offset_x": "pp_logo_offset_x",
            "logo_offset_y": "pp_logo_offset_y",
            "letterbox_enabled": "pp_letterbox_enabled",
            "letterbox_height_pct": "pp_letterbox_height_pct",
            "crf": "pp_crf", "preset": "pp_preset",
        }
        for k, v in data.items():
            if k.startswith("_"):
                continue
            attr = m.get(k)
            if attr and hasattr(self, attr):
                try:
                    getattr(self, attr).set(v)
                except Exception:
                    pass
        # Спец-ключи
        if "_audio_track_start" in data:
            try: self.audio_track_start.set(data["_audio_track_start"])
            except Exception: pass
        if "_pp_enabled" in data:
            try: self.pp_enabled.set(bool(data["_pp_enabled"]))
            except Exception: pass
        # Восстановление toggle-чекбоксов групп
        for k, attr in (("_grp_crop",   "pp_grp_crop"),
                        ("_grp_jitter", "pp_grp_jitter"),
                        ("_grp_zoom",   "pp_grp_zoom"),
                        ("_grp_noise",  "pp_grp_noise"),
                        ("_grp_color",  "pp_grp_color"),
                        ("_grp_vfr",    "pp_grp_vfr"),
                        ("_grp_audio",  "pp_grp_audio")):
            if k in data and hasattr(self, attr):
                try: getattr(self, attr).set(bool(data[k]))
                except Exception: pass

    def _collect_pp_options(self):
        """Собрать dict из всех pp_* для apply_postprocess().
        Учитывает toggle-чекбоксы групп: выключенная группа = нейтральные значения,
        её фильтр в ffmpeg-цепи не появляется."""
        gC = bool(self.pp_grp_crop.get())
        gJ = bool(self.pp_grp_jitter.get())
        gZ = bool(self.pp_grp_zoom.get())
        gN = bool(self.pp_grp_noise.get())
        gCol = bool(self.pp_grp_color.get())
        gV = bool(self.pp_grp_vfr.get())
        gA = bool(self.pp_grp_audio.get())
        return {
            "crop_percent":     self.pp_crop_percent.get()      if gC   else 0.0,
            "jitter_x":         self.pp_jitter_x.get()          if gJ   else 0.0,
            "jitter_y":         self.pp_jitter_y.get()          if gJ   else 0.0,
            "jitter_period_x":  self.pp_jitter_period_x.get(),
            "jitter_period_y":  self.pp_jitter_period_y.get(),
            "zoom_amplitude":   self.pp_zoom_amplitude.get()    if gZ   else 0.0,
            "zoom_period":      self.pp_zoom_period.get(),
            "noise_strength":   self.pp_noise_strength.get()    if gN   else 0,
            "blur_amount":      self.pp_blur_amount.get()       if gN   else 0.0,
            "brightness":       self.pp_brightness.get()        if gCol else 0.0,
            "contrast":         self.pp_contrast.get()          if gCol else 1.0,
            "saturation":       self.pp_saturation.get()        if gCol else 1.0,
            "gamma":            self.pp_gamma.get()             if gCol else 1.0,
            "gamma_r":          self.pp_gamma_r.get()           if gCol else 1.0,
            "gamma_g":          self.pp_gamma_g.get()           if gCol else 1.0,
            "gamma_b":          self.pp_gamma_b.get()           if gCol else 1.0,
            "gamma_weight":     self.pp_gamma_weight.get()      if gCol else 1.0,
            "hue_deg":          self.pp_hue_deg.get()           if gCol else 0.0,
            "hue_sat_mul":      self.pp_hue_sat_mul.get()       if gCol else 1.0,
            "cb_shad_r": self.pp_cb_shad_r.get() if gCol else 0.0,
            "cb_shad_g": self.pp_cb_shad_g.get() if gCol else 0.0,
            "cb_shad_b": self.pp_cb_shad_b.get() if gCol else 0.0,
            "cb_mid_r":  self.pp_cb_mid_r.get()  if gCol else 0.0,
            "cb_mid_g":  self.pp_cb_mid_g.get()  if gCol else 0.0,
            "cb_mid_b":  self.pp_cb_mid_b.get()  if gCol else 0.0,
            "cb_high_r": self.pp_cb_high_r.get() if gCol else 0.0,
            "cb_high_g": self.pp_cb_high_g.get() if gCol else 0.0,
            "cb_high_b": self.pp_cb_high_b.get() if gCol else 0.0,
            "vfr_amplitude_ms":  self.pp_vfr_amplitude_ms.get()  if gV else 0.0,
            "vfr_period_frames": self.pp_vfr_period_frames.get(),
            "audio_eq_gain_db":     self.pp_audio_eq_gain_db.get()     if gA else 0.0,
            "audio_echo_delay_ms":  self.pp_audio_echo_delay_ms.get()  if gA else 0.0,
            "audio_echo_decay":     self.pp_audio_echo_decay.get(),
            "logo_enabled": self.pp_logo_enabled.get(),
            "logo_path": self.pp_logo_path.get(),
            "logo_corner": self.pp_logo_corner.get(),
            "logo_margin": self.pp_logo_margin.get(),
            "logo_scale": float(self.pp_logo_scale.get()) / 100.0,
            "logo_offset_x": int(self.pp_logo_offset_x.get()),
            "logo_offset_y": int(self.pp_logo_offset_y.get()),
            "letterbox_enabled": self.pp_letterbox_enabled.get(),
            "letterbox_height_pct": self.pp_letterbox_height_pct.get(),
            "crf": self.pp_crf.get(),
            "preset": self.pp_preset.get(),
        }

    def _toggle_full_track(self):
        """Disable duration Entry when full-track checkbox is on."""
        self.duration_entry.config(
            state="disabled" if self.full_track.get() else "normal"
        )

    def on_run(self):
        video = self.video_path.get().strip()
        audio = self.audio_path.get().strip()

        if not video or not os.path.isfile(video):
            messagebox.showerror("Ошибка", "Выберите существующий видеофайл.")
            return
        if not audio or not os.path.isfile(audio):
            messagebox.showerror("Ошибка", "Выберите существующий аудиофайл.")
            return

        try:
            # Точка вставки: смотрим что юзер тронул последним — поле тайминга
            # или ползунок процентов.
            if self._insert_active_mode == "percent":
                vid_dur = probe_duration(video)
                if vid_dur <= 0:
                    messagebox.showerror("Ошибка",
                        "Не удалось определить длительность видео (ffprobe). "
                        "Введи точку вставки в секундах вручную или проверь файл.")
                    return
                pct = max(0.0, min(100.0, float(self.start_percent.get())))
                start = vid_dur * pct / 100.0
            else:
                start = parse_time(self.start_time.get())
            if self.full_track.get():
                dur = probe_duration(audio)
                if dur <= 0:
                    messagebox.showerror("Ошибка", "Не удалось определить длительность аудио (ffprobe).")
                    return
            else:
                dur = parse_time(self.duration.get())
        except Exception as e:
            messagebox.showerror("Ошибка", f"Неверное время/длительность: {e}")
            return

        if start < 0 or dur <= 0:
            messagebox.showerror("Ошибка", "Начало >= 0, длительность > 0.")
            return

        duck_pct = self.duck.get()
        duck_volume = max(0.0, duck_pct / 100.0)
        track_volume = max(0.0, self.track_vol.get() / 100.0)

        # Audio track start offset (с какой секунды композиции брать вставку)
        try:
            track_start_offset = parse_time(self.audio_track_start.get().strip() or "0")
        except Exception as e:
            messagebox.showerror("Ошибка", f"Неверный «Старт трека»: {e}")
            return
        if track_start_offset < 0:
            messagebox.showerror("Ошибка", "Старт трека должен быть >= 0.")
            return
        _audio_dur_for_offset = probe_duration(audio)
        if _audio_dur_for_offset > 0 and track_start_offset >= _audio_dur_for_offset:
            messagebox.showerror(
                "Ошибка",
                f"Старт трека ({track_start_offset:.2f}s) >= длительности аудио ({_audio_dur_for_offset:.2f}s). "
                "Поставьте старт трека 0 или выберите более длинный трек.",
            )
            return
        # full-track совместимость с offset: эффективная длительность = audio_dur - offset
        if self.full_track.get():
            _adur = _audio_dur_for_offset
            if _adur > 0 and track_start_offset >= _adur:
                messagebox.showerror("Ошибка",
                                     f"Старт трека ({track_start_offset:.2f}s) >= длительности аудио ({_adur:.2f}s).")
                return
            if _adur > 0:
                dur = max(0.0, _adur - track_start_offset)
                if dur <= 0:
                    messagebox.showerror("Ошибка", "После применения старта трека длительность <= 0.")
                    return

        # Авторка (outro) — общая для обоих режимов, применяется последним шагом
        outro_path = None
        if self.outro_enabled.get():
            outro_path = self.outro_path.get().strip()
            if not outro_path or not os.path.isfile(outro_path):
                messagebox.showerror("Ошибка", "Включена авторка, но файл не выбран или не существует.")
                return

        # Postprocess (перекод) — собрать опции если включён
        pp_options = None
        if self.pp_enabled.get():
            pp_options = self._collect_pp_options()
            if pp_options.get("logo_enabled"):
                _lp = (pp_options.get("logo_path") or "").strip()
                if not _lp or not os.path.isfile(_lp):
                    messagebox.showerror("Ошибка", "Постпроцесс: логотип включён, но файл не выбран/не существует.")
                    return

        if self.mode.get() == "expand":
            use_self_insert = bool(self.use_source_insert.get())
            insert_video = self.insert_video_path.get().strip()
            if not use_self_insert:
                if not insert_video or not os.path.isfile(insert_video):
                    messagebox.showerror("Ошибка", "Выберите существующий insert-видеофайл.")
                    return
            # Trim в expand-режиме (семантика как в mix-ветке):
            #   trim_start — СКОЛЬКО ОТРЕЗАТЬ С НАЧАЛА фильма (например, 13 → пропустить первые 13 сек).
            #   trim_end   — СКОЛЬКО ОТРЕЗАТЬ С КОНЦА фильма (например, 60 → отрезать последние 60 сек).
            # Пусто/0 = не отрезать. Внутри _run_expand_insert конвертим в абсолютные таймштампы.
            expand_trim_start = None
            expand_trim_end = None
            if self.trim_enabled.get():
                try:
                    _ts = self.trim_start.get().strip()
                    # Пустое поле → None (нет обрезки), 0 → 0.0 (явно с начала)
                    expand_trim_start = parse_time(_ts) if _ts else None
                    _te = self.trim_end.get().strip()
                    expand_trim_end = parse_time(_te) if _te else None
                except Exception as e:
                    messagebox.showerror("Ошибка", f"Неверное время обрезки: {e}")
                    return
                if expand_trim_start is not None and expand_trim_start < 0:
                    messagebox.showerror("Ошибка", "Начало обрезки должно быть >= 0.")
                    return
                if expand_trim_end is not None and expand_trim_end < 0:
                    messagebox.showerror("Ошибка", "Конец обрезки должен быть >= 0.")
                    return
                if expand_trim_start is not None and expand_trim_start >= start:
                    messagebox.showerror(
                        "Ошибка",
                        f"Начало обрезки ({expand_trim_start}s) >= точки вставки ({start}s). "
                        "Точка вставки попала в обрезанную часть.",
                    )
                    return
                if expand_trim_end is not None and expand_trim_end <= start:
                    messagebox.showerror(
                        "Ошибка",
                        f"Конец обрезки ({expand_trim_end}s) <= точки вставки ({start}s). "
                        "Точка вставки попала в обрезанную часть.",
                    )
                    return
            insert_video_start = 0.0
            if not use_self_insert:
                try:
                    insert_video_start = parse_time(self.insert_video_start.get())
                except Exception as e:
                    messagebox.showerror("Ошибка", f"Неверный старт в insert-видео: {e}")
                    return
                if insert_video_start < 0:
                    messagebox.showerror("Ошибка", "Старт в insert-видео должен быть >= 0.")
                    return
            silence_options = None
            if self.snap_silence.get():
                try:
                    silence_radius = float(self.silence_radius.get().strip())
                    silence_min = float(self.silence_min.get().strip())
                    quiet_step = float(self.quiet_step.get().strip())
                except Exception as e:
                    messagebox.showerror("Ошибка", f"Неверные настройки поиска тихого участка: {e}")
                    return
                if silence_radius <= 0 or silence_min <= 0 or quiet_step <= 0:
                    messagebox.showerror("Ошибка", "Окно поиска, длина анализа и шаг должны быть > 0.")
                    return
                silence_options = {
                    "radius": silence_radius,
                    "segment_duration": silence_min,
                    "step": quiet_step,
                }

            base, ext = os.path.splitext(video)
            ext = ext or ".mp4"
            _tag = _fmt_time_tag(start)
            out = f"{base}_at{_tag}_inserted{ext}"
            i = 1
            while os.path.exists(out):
                out = f"{base}_at{_tag}_inserted_{i}{ext}"
                i += 1

            params = {
                "video": video,
                "audio": audio,
                "insert_video": insert_video,
                "start": start,
                "duration": dur,
                "insert_video_start": insert_video_start,
                "track_volume": track_volume,
                "silence_options": silence_options,
                "use_self_insert": use_self_insert,
                "self_insert_source": self.source_insert_side.get(),
                "overlay_timer": bool(self.overlay_timer.get()),
                "pause_title": self.pause_title.get(),
                "pause_prefix": self.pause_prefix.get(),
                "pause_position": self.pause_position.get(),
                "trim_start": expand_trim_start,
                "trim_end": expand_trim_end,
                "outro_path": outro_path,
                "track_start_offset": track_start_offset,
                "postprocess": pp_options,
                "out": out,
            }

            self.run_btn.config(state="disabled")
            self.open_file_btn.config(state="disabled")
            self.open_folder_btn.config(state="disabled")
            self.progress["value"] = 0
            self.status.config(text=f"Insert-сборка... -> {out}", fg="#1565C0")
            threading.Thread(target=self._run_expand_insert, args=(params,), daemon=True).start()
            return

        original_start = start

        # Parse trim settings
        trim_ss = None
        trim_to = None
        if self.trim_enabled.get():
            try:
                trim_ss = parse_time(self.trim_start.get())
                if self.trim_end.get().strip():
                    trim_to = parse_time(self.trim_end.get())
            except Exception as e:
                messagebox.showerror("Ошибка", f"Неверное время обрезки: {e}")
                return

        mix_start = original_start
        if self.trim_enabled.get():
            trim_base = float(trim_ss or 0.0)
            trim_limit = float(trim_to) if trim_to is not None else None
            mix_start = original_start - trim_base
            if mix_start < -0.001:
                messagebox.showerror(
                    "Ошибка тайминга mix",
                    "Точка вставки попала в отрезанное начало видео. Поставьте ее после начала обрезки.",
                )
                return
            if trim_limit is not None and original_start >= trim_limit - 0.001:
                messagebox.showerror(
                    "Ошибка тайминга mix",
                    "Точка вставки вне итогового обрезанного видео. Поставьте ее до конца обрезки.",
                )
                return
            mix_start = max(0.0, mix_start)
        mix_end = mix_start + dur
        start_ms = int(round(mix_start * 1000))

        base, ext = os.path.splitext(video)
        suffix = "_trimmed" if self.trim_enabled.get() else ""
        _tag = _fmt_time_tag(start)
        out = f"{base}{suffix}_at{_tag}_mixed{ext}"
        i = 1
        while os.path.exists(out):
            out = f"{base}{suffix}_at{_tag}_mixed_{i}{ext}"
            i += 1

        # [1:a]: берём трек с track_start_offset (по дефолту 0), длительностью dur,
        # сбрасываем PTS, понижаем громкость trk-vol, сдвигаем на start_ms.
        # [0:a]: понижаем громкость оригинала только в окне [start..end].
        # amix normalize=0 — без авто-деления на N (иначе всё станет тише).
        _atrim_start = float(track_start_offset)
        _atrim_end = _atrim_start + float(dur)
        filter_complex = (
            f"[1:a]atrim={_atrim_start:.3f}:{_atrim_end:.3f},asetpts=PTS-STARTPTS,"
            f"aresample=async=1:first_pts=0,"
            f"volume={track_volume},"
            f"adelay={start_ms}:all=1[ains];"
            f"[0:a]volume=enable='between(t,{mix_start},{mix_end})':volume={duck_volume}[aorig];"
            f"[aorig][ains]amix=inputs=2:duration=first:normalize=0[aout]"
        )
        self._log_line(
            "MIX params: "
            f"start_mode={self._insert_active_mode} "
            f"start={original_start:.3f}s mix_start={mix_start:.3f}s "
            f"duration={dur:.3f}s start_ms={start_ms} "
            f"track_volume={track_volume:.3f} duck_volume={duck_volume:.3f} "
            f"full_track={bool(self.full_track.get())} "
            f"track_offset={track_start_offset:.3f}s percent={float(self.start_percent.get()):.1f}"
        )
        self._log_line(f"MIX filter: {filter_complex}")

        cmd = [
            "ffmpeg", "-y",
            "-hide_banner", "-loglevel", "error",
            "-progress", "pipe:1", "-nostats",
        ]

        # Add trim parameters BEFORE input (for fast seeking with -c copy)
        if trim_ss is not None:
            cmd.extend(["-ss", str(trim_ss)])
        if trim_to is not None:
            cmd.extend(["-to", str(trim_to)])

        cmd.extend([
            "-i", video,
            "-i", audio,
            "-filter_complex", filter_complex,
            "-map", "0:v",
            "-map", "[aout]",
            "-c:v", "copy",
            "-c:a", "aac",
            "-b:a", "192k",
            *fake_metadata_args(),
            "-movflags", "+faststart",
            out,
        ])

        total = probe_duration(video)
        self.run_btn.config(state="disabled")
        self.open_file_btn.config(state="disabled")
        self.open_folder_btn.config(state="disabled")
        self.progress["value"] = 0
        self.status.config(text=f"Сборка… → {out}", fg="#1565C0")

        threading.Thread(target=self._run_ffmpeg, args=(cmd, out, total),
                         kwargs={"outro_path": outro_path, "postprocess": pp_options},
                         daemon=True).start()

    def _set_progress(self, frac: float):
        v = max(0.0, min(1.0, frac)) * 1000.0
        self.progress["value"] = v

    def _run_cmd_checked(self, cmd, label: str):
        creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=creationflags,
        )
        if proc.returncode != 0:
            tail = ((proc.stderr or "") + "\n" + (proc.stdout or ""))[-3500:]
            raise RuntimeError(f"{label} failed\n\n{tail}")

    def _run_expand_insert(self, params: dict):
        temp_dir = None
        try:
            video = params["video"]
            audio = params["audio"]
            insert_video = params.get("insert_video") or ""
            start = float(params["start"])
            dur = float(params["duration"])
            insert_video_start = float(params["insert_video_start"])
            track_volume = float(params["track_volume"])
            silence_options = params.get("silence_options")
            use_self_insert = bool(params.get("use_self_insert"))
            self_insert_source = str(params.get("self_insert_source") or "before").lower()
            overlay_timer = bool(params.get("overlay_timer"))
            pause_title = str(params.get("pause_title") or "РЕКЛАМНАЯ ПАУЗА")
            pause_prefix = str(params.get("pause_prefix") or "Продолжение через")
            pause_position = str(params.get("pause_position") or "center")
            trim_start = params.get("trim_start")    # None если trim выкл, иначе float (>= 0)
            trim_end = params.get("trim_end")        # None если trim выкл / "до конца"
            track_start_offset = float(params.get("track_start_offset") or 0.0)
            pp_options = params.get("postprocess")   # None | dict
            out = params["out"]

            folder = os.path.dirname(video) or "."
            temp_dir = tempfile.mkdtemp(prefix="audio_insert_", dir=folder)

            # --- Build log (рядом с output) — пишем все шаги для диагностики ---
            log_path = f"{out}.build.log"

            def _hms(sec):
                try:
                    sec = float(sec)
                except (TypeError, ValueError):
                    return str(sec)
                neg = "-" if sec < 0 else ""
                sec = abs(int(round(sec)))
                return f"{neg}{sec // 3600:02d}:{(sec % 3600) // 60:02d}:{sec % 60:02d}"

            def _log(msg):
                try:
                    with open(log_path, "a", encoding="utf-8") as _lf:
                        _lf.write(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}\n")
                except Exception:
                    pass

            def _run_logged(cmd, label):
                """ffmpeg-шаг с записью команды и полной ошибки (stderr) в лог."""
                _log(f"RUN [{label}]: {' '.join(cmd)}")
                try:
                    self._run_cmd_checked(cmd, label)
                except Exception as _e:
                    _log(f"FAIL [{label}]:\n{_e}")
                    raise

            try:
                open(log_path, "w", encoding="utf-8").close()
            except Exception:
                pass
            _log("=== EXPAND INSERT BUILD LOG ===")
            _log(f"app_build = {APP_BUILD}")
            _log("timer_overlay_impl = png+overlay (no ffmpeg subtitles/libass)")
            _log(f"video      = {video}")
            _log(f"audio      = {audio}")
            _log(f"insert_vid = {insert_video!r} (use_self_insert={use_self_insert})")
            _log(f"out        = {out}")
            _log(f"start (в координатах ОРИГИНАЛА) = {start:.3f}s ({_hms(start)})")
            _log(f"duration   = {dur:.3f}s")
            _log(f"insert_video_start = {insert_video_start:.3f}s")
            _log(f"trim_start = {trim_start}  trim_end = {trim_end}")
            _log(f"overlay_timer={overlay_timer}  pause_position={pause_position}  snap_silence={'on' if silence_options else 'off'}  outro={'on' if params.get('outro_path') else 'off'}")

            self.root.after(0, lambda: self.status.config(text="Probe main/insert media...", fg="#1565C0"))
            main_info = probe_media(video)
            insert_info = None if use_self_insert else probe_media(insert_video)

            main_video = first_stream(main_info, "video")
            main_audio = first_stream(main_info, "audio")
            insert_video_stream = None if use_self_insert else first_stream(insert_info, "video")
            if not main_video:
                raise RuntimeError("Main file has no video stream.")
            if not main_audio:
                raise RuntimeError("Main file has no audio stream. Copy-concat insert mode needs matching audio in all parts.")
            if not use_self_insert and not insert_video_stream:
                raise RuntimeError("Insert file has no video stream.")

            main_dur = float(main_info.get("format", {}).get("duration") or probe_duration(video) or 0.0)
            insert_dur = 0.0
            if not use_self_insert:
                insert_dur = float(insert_info.get("format", {}).get("duration") or probe_duration(insert_video) or 0.0)
            _log(f"main_dur   = {main_dur:.3f}s ({_hms(main_dur)})")
            _log(f"insert_dur = {insert_dur:.3f}s")
            if main_dur <= 0:
                raise RuntimeError("Cannot read main video duration.")
            if start > main_dur + 0.05:
                raise RuntimeError(f"Insert start is outside main video duration ({main_dur:.2f}s).")
            if silence_options:
                radius = float(silence_options["radius"])
                segment_duration = float(silence_options["segment_duration"])
                step = float(silence_options["step"])
                self.root.after(
                    0,
                    lambda: self.status.config(
                        text=f"Searching quiet spot near {start:.2f}s (window ±{radius:.2f}s)...",
                        fg="#1565C0",
                    ),
                )
                _log(f"SNAP: ищем тишину в окне [{_hms(max(0,start-radius))} .. {_hms(start+radius)}] (±{radius:.0f}s)")
                snapped = find_quietest_cut(video, start, radius, segment_duration, step, main_dur)
                if snapped is not None:
                    old_start = start
                    start = max(0.0, min(main_dur, snapped))
                    _log(f"SNAP: точка вставки сдвинута {old_start:.2f}s ({_hms(old_start)}) -> {start:.2f}s ({_hms(start)})")
                    self.root.after(
                        0,
                        lambda: self.status.config(
                            text=f"Quiet cut: {old_start:.2f}s -> {start:.2f}s",
                            fg="#1565C0",
                        ),
                    )
                else:
                    _log("SNAP: тихого места не найдено, используем точную метку")
                    self.root.after(
                        0,
                        lambda: self.status.config(
                            text=f"No quiet spot found near {start:.2f}s, using exact mark.",
                            fg="#1565C0",
                        ),
                    )
            if not use_self_insert and insert_dur > 0 and insert_video_start + dur > insert_dur + 0.05:
                raise RuntimeError(
                    f"Insert video is too short for this segment: need {insert_video_start + dur:.2f}s, "
                    f"has {insert_dur:.2f}s."
                )

            try:
                main_size = os.path.getsize(video)
                trim_a = float(trim_start) if trim_start is not None else 0.0
                trim_b = float(trim_end) if trim_end is not None else main_dur
                kept_dur = max(0.0, min(main_dur, trim_b) - max(0.0, trim_a))
                kept_ratio = kept_dur / main_dur if main_dur > 0 else 1.0
                main_kept_est = int(main_size * kept_ratio)
                insert_est = int((main_size / max(main_dur, 1.0)) * dur * 1.5)
                outro_est = 0
                if params.get("outro_path"):
                    try:
                        od = probe_duration(params.get("outro_path"))
                        outro_est = int((main_size / max(main_dur, 1.0)) * max(0.0, od) * 1.5)
                    except Exception:
                        outro_est = 0
                final_est = max(1, main_kept_est + insert_est + outro_est)
                required_free = int(final_est * 3.15 + 2 * 1024 * 1024 * 1024)
                free_now = shutil.disk_usage(folder).free
                _log(f"SPACE: free={human_size(free_now)} estimated_required={human_size(required_free)}")
                if free_now < required_free:
                    raise RuntimeError(
                        "Недостаточно свободного места для insert-сборки.\n\n"
                        f"Свободно на диске: {human_size(free_now)}\n"
                        f"Нужно примерно: {human_size(required_free)}\n\n"
                        "Почему так много: при ошибке временные файлы теперь НЕ удаляются, "
                        "поэтому для безопасной сборки нужны before/insert/after, TS-копии и финальный MP4.\n"
                        "Освободи место и запусти сборку снова."
                    )
            except RuntimeError:
                raise
            except Exception as _space_err:
                _log(f"SPACE: preflight skipped ({_space_err})")

            width = int(main_video.get("width") or 0)
            height = int(main_video.get("height") or 0)
            if width <= 0 or height <= 0:
                raise RuntimeError("Cannot read main video size.")
            pix_fmt = (main_video.get("pix_fmt") or "yuv420p").strip()
            if not pix_fmt or pix_fmt.lower() in {"unknown", "none"}:
                pix_fmt = "yuv420p"

            _, fps_arg = parse_fps(main_video.get("avg_frame_rate") or main_video.get("r_frame_rate"))
            vcodec = (main_video.get("codec_name") or "").lower()
            if vcodec == "h264":
                v_encoder = "libx264"
                v_extra = []
            elif vcodec == "hevc":
                v_encoder = "libx265"
                v_extra = ["-tag:v", "hvc1"]
            else:
                raise RuntimeError(f"Copy insert mode currently supports H.264/HEVC main video, got: {vcodec or 'unknown'}.")

            acodec = (main_audio.get("codec_name") or "").lower()
            if acodec == "aac":
                a_encoder = "aac"
                a_extra = ["-b:a", "192k"]
            elif acodec == "mp3":
                a_encoder = "libmp3lame"
                a_extra = ["-b:a", "192k"]
            else:
                raise RuntimeError(f"Copy insert mode currently supports AAC/MP3 main audio, got: {acodec or 'unknown'}.")

            sample_rate = str(main_audio.get("sample_rate") or "48000")
            channels = str(main_audio.get("channels") or "2")
            # Готовим единый набор encode-параметров (profile/level/bitrate/GOP/timescale) —
            # одинаково для head, full-reencode и insert. Иначе concat демюксер дрожит на стыках.
            v_enc_args = build_video_encode_args(main_video, fps_arg, pix_fmt, v_encoder, v_extra)
            a_enc_args = build_audio_encode_args(main_audio, a_encoder, sample_rate, channels)
            seg_ext = ".mp4" if os.path.splitext(out)[1].lower() in {".mp4", ".m4v", ".mov", ""} else os.path.splitext(out)[1]
            before = os.path.join(temp_dir, f"before{seg_ext}")
            insert_ready = os.path.join(temp_dir, f"insert{seg_ext}")
            after = os.path.join(temp_dir, f"after{seg_ext}")
            concat_list = os.path.join(temp_dir, "concat.txt")
            segments = []

            # before-сегмент: от trim_start (или 0) до start. Чистый copy через fast seek.
            # Trim ±точность ближайшего keyframe (физика -c copy, без перекодирования).
            before_start = float(trim_start) if trim_start is not None else 0.0
            before_len = start - before_start
            _log(f"BEFORE: оригинал[{_hms(before_start)} .. {_hms(start)}] len={before_len:.2f}s")
            if before_len > 0.05:
                self.root.after(0, lambda: self.status.config(text="Copy before segment...", fg="#1565C0"))
                self.root.after(0, self._set_progress, 0.08)
                before_cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error"]
                if before_start > 0.05:
                    before_cmd.extend(["-ss", f"{before_start:.3f}"])
                before_cmd.extend([
                    "-i", video,
                    "-t", f"{before_len:.3f}",
                    "-map", "0:v:0", "-map", "0:a:0?",
                    "-c", "copy",
                    "-avoid_negative_ts", "make_zero",
                    before,
                ])
                _run_logged(before_cmd, "before segment")
                segments.append(before)
                _bsz = os.path.getsize(before) if os.path.exists(before) else 0
                _log(f"BEFORE done: size={_bsz}B dur={probe_duration(before):.2f}s")
            else:
                _log(f"BEFORE: ПРОПУЩЕН (len={before_len:.2f}s <= 0.05) — точка вставки в самом начале")

            if use_self_insert:
                source_start = choose_self_insert_start(start, dur, main_dur, self_insert_source)
                source_label = "with timer" if overlay_timer else "no timer"
                self.root.after(
                    0,
                    lambda: self.status.config(
                        text=f"Build source-video insert ({source_label}) from {source_start:.2f}s...",
                        fg="#1565C0",
                    ),
                )
                insert_input = video
            else:
                source_start = insert_video_start
                source_label = "external + timer" if overlay_timer else "external"
                self.root.after(
                    0,
                    lambda: self.status.config(
                        text=f"Conform insert video/audio ({source_label})...",
                        fg="#1565C0",
                    ),
                )
                insert_input = insert_video
            self.root.after(0, self._set_progress, 0.28)
            vf = (
                f"scale={width}:{height}:force_original_aspect_ratio=decrease,"
                f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,"
                f"setsar=1,fps={fps_arg},format={pix_fmt}"
            )
            timer_png = None
            if overlay_timer:
                timer_png = os.path.join(temp_dir, "pause_timer.png")
                # Позиция в итоговом видео, где начинается продолжение (after-сегмент):
                # before-сегмент имеет длину before_len, дальше идёт пауза dur, потом after.
                resume_at = before_len + dur
                write_pause_info_png(timer_png, width, height, pause_title, pause_prefix, resume_at, pause_position)
            # audio с track_start_offset (с какой секунды композиции брать вставку).
            # -ss ПЕРЕД -i — быстрый seek; -stream_loop -1 циклит если трек короче.
            _audio_input_args = ["-stream_loop", "-1"]
            if track_start_offset > 0:
                _audio_input_args += ["-ss", f"{track_start_offset:.3f}"]
            _audio_input_args += ["-i", audio]
            if timer_png:
                filter_complex = f"[0:v]{vf}[base];[base][2:v]overlay=0:0:format=auto[vout]"
                insert_cmd = [
                    "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                    "-ss", f"{source_start:.3f}", "-i", insert_input,
                    *_audio_input_args,
                    "-loop", "1", "-i", timer_png,
                    "-t", f"{dur:.3f}",
                    "-filter_complex", filter_complex,
                    "-map", "[vout]", "-map", "1:a:0",
                    "-af", f"volume={track_volume},aresample={sample_rate}",
                    *v_enc_args,
                    *a_enc_args,
                    "-movflags", "+faststart",
                    insert_ready,
                ]
            else:
                insert_cmd = [
                    "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                    "-ss", f"{source_start:.3f}", "-i", insert_input,
                    *_audio_input_args,
                    "-t", f"{dur:.3f}",
                    "-map", "0:v:0", "-map", "1:a:0",
                    "-vf", vf,
                    "-af", f"volume={track_volume},aresample={sample_rate}",
                    *v_enc_args,
                    *a_enc_args,
                    "-movflags", "+faststart",
                    insert_ready,
                ]
            _log(f"INSERT: source={'фильм' if use_self_insert else 'внешний файл'} input={insert_input!r} source_start={source_start:.2f}s dur={dur:.2f}s timer={overlay_timer}")
            _run_logged(insert_cmd, "insert segment (matched params)")
            segments.append(insert_ready)
            _isz = os.path.getsize(insert_ready) if os.path.exists(insert_ready) else 0
            _log(f"INSERT done: size={_isz}B dur={probe_duration(insert_ready):.2f}s (ожидаем ~{dur:.2f}s)")

            # after-сегмент: от start до trim_end (или конца)
            after_end = float(trim_end) if trim_end is not None else main_dur
            after_len = after_end - start
            _log(f"AFTER: оригинал[{_hms(start)} .. {_hms(after_end)}] len={after_len:.2f}s")
            if after_len > 0.05:
                self.root.after(0, lambda: self.status.config(text="Copy after segment...", fg="#1565C0"))
                self.root.after(0, self._set_progress, 0.68)
                after_cmd = [
                    "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                    "-i", video,
                    "-ss", f"{start:.3f}",
                ]
                if trim_end is not None:
                    after_cmd.extend(["-to", f"{after_end:.3f}"])
                after_cmd.extend([
                    # output-seek (-ss ПОСЛЕ -i) обнуляет PTS от 0 → нет «66 часов».
                    # БЕЗ -copyinkf: ffmpeg отбрасывает кадры до первого keyframe ≥ start,
                    # поэтому after стартует с чистого keyframe — нет битых P/B-кадров,
                    # видео не сыпется и перематывается. Минус: до keyframe режется
                    # доля секунды (обычно < 1-2с).
                    "-map", "0:v:0", "-map", "0:a:0?",
                    "-c", "copy",
                    "-avoid_negative_ts", "make_zero",
                    after,
                ])
                _run_logged(after_cmd, "after segment")
                segments.append(after)
                _asz = os.path.getsize(after) if os.path.exists(after) else 0
                _log(f"AFTER done: size={_asz}B dur={probe_duration(after):.2f}s")
            else:
                _log("AFTER: ПРОПУЩЕН (len <= 0.05)")

            # Авторка (outro) — ЧЕТВЁРТЫЙ сегмент в ОБЩИЙ concat (не отдельный второй
            # concat поверх готового файла: тот разъезжал timestamps до десятков часов
            # на VFR-результате склейки). conform под параметры ОРИГИНАЛА (fps_arg тут
            # чистый), как insert — поэтому общий concat остаётся ровным.
            outro_path = params.get("outro_path")
            if outro_path:
                self.root.after(0, lambda: self.status.config(text="Conform авторки (outro)...", fg="#1565C0"))
                self.root.after(0, self._set_progress, 0.80)
                outro_seg = os.path.join(temp_dir, f"outro{seg_ext}")
                outro_has_audio = first_stream(probe_media(outro_path), "audio") is not None
                ovf = (
                    f"scale={width}:{height}:force_original_aspect_ratio=decrease,"
                    f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,"
                    f"setsar=1,fps={fps_arg},format={pix_fmt}"
                )
                if outro_has_audio:
                    outro_cmd = [
                        "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                        "-i", outro_path,
                        "-vf", ovf,
                        "-map", "0:v:0", "-map", "0:a:0",
                        "-af", f"aresample={sample_rate}",
                        *v_enc_args, *a_enc_args,
                        "-movflags", "+faststart", outro_seg,
                    ]
                else:
                    # У авторки нет звука — тишина (anullsrc + -shortest до длины видео).
                    outro_cmd = [
                        "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                        "-i", outro_path,
                        "-f", "lavfi", "-i", f"anullsrc=channel_layout=stereo:sample_rate={sample_rate}",
                        "-vf", ovf,
                        "-map", "0:v:0", "-map", "1:a:0",
                        *v_enc_args, *a_enc_args,
                        "-shortest",
                        "-movflags", "+faststart", outro_seg,
                    ]
                _log(f"OUTRO: conform {outro_path!r} has_audio={outro_has_audio}")
                _run_logged(outro_cmd, "outro segment")
                segments.append(outro_seg)
                _osz = os.path.getsize(outro_seg) if os.path.exists(outro_seg) else 0
                _log(f"OUTRO done: size={_osz}B dur={probe_duration(outro_seg):.2f}s")

            _log(f"SEGMENTS ({len(segments)}): " + ", ".join(os.path.basename(s) for s in segments))

            # MPEG-TS склейка. mp4-concat теряет video последнего reencode-сегмента
            # (outro) из-за конфликта timebase/moov между copy- и reencode-кусками.
            # TS не имеет moov/edit-list — склеивается надёжно. Каждый сегмент → .ts
            # (copy + annexb), затем concat .ts → mp4 (aac_adtstoasc возвращает AAC
            # из ADTS в формат mp4).
            _vbsf = "hevc_mp4toannexb" if v_encoder == "libx265" else "h264_mp4toannexb"
            try:
                resume_bat = os.path.join(temp_dir, "resume_final_concat.bat")
                resume_concat = "concat_resume.txt"
                with open(resume_bat, "w", encoding="utf-8", newline="\r\n") as rb:
                    rb.write("@echo off\n")
                    rb.write("chcp 65001 >nul\n")
                    rb.write("title Audio Inserter resume final concat\n")
                    rb.write("cd /d \"%~dp0\"\n")
                    rb.write("echo Resuming final concat from saved temp segments...\n")
                    rb.write("echo.\n")
                    for _si, _seg in enumerate(segments):
                        rb.write(f"del /q \"seg_{_si}.ts\" >nul 2>&1\n")
                        rb.write(
                            f"ffmpeg -y -hide_banner -loglevel error -i \"{os.path.basename(_seg)}\" "
                            f"-map 0:v:0 -map 0:a:0? -c copy -bsf:v {_vbsf} -f mpegts \"seg_{_si}.ts\"\n"
                        )
                        rb.write("if errorlevel 1 goto fail\n")
                    rb.write(f"> \"{resume_concat}\" echo file 'seg_0.ts'\n")
                    for _si in range(1, len(segments)):
                        rb.write(f">> \"{resume_concat}\" echo file 'seg_{_si}.ts'\n")
                    rb.write(
                        f"ffmpeg -y -hide_banner -loglevel error -f concat -safe 0 -i \"{resume_concat}\" "
                        "-map 0 -c copy "
                    )
                    if a_encoder == "aac":
                        rb.write("-bsf:a aac_adtstoasc ")
                    if os.path.splitext(out)[1].lower() in {".mp4", ".m4v", ".mov", ""}:
                        rb.write("-movflags +faststart ")
                    rb.write(f"\"{out}\"\n")
                    rb.write("if errorlevel 1 goto fail\n")
                    rb.write("echo.\n")
                    rb.write(f"echo Done: {out}\n")
                    rb.write("pause\n")
                    rb.write("exit /b 0\n")
                    rb.write(":fail\n")
                    rb.write("echo.\n")
                    rb.write("echo Resume failed. Free more disk space and run this file again.\n")
                    rb.write("pause\n")
                    rb.write("exit /b 1\n")
                _log(f"RESUME: saved {resume_bat}")
            except Exception as _resume_err:
                _log(f"RESUME: could not write resume_final_concat.bat: {_resume_err}")

            self.root.after(0, lambda: self.status.config(text="Готовлю сегменты к склейке (TS)...", fg="#1565C0"))
            self.root.after(0, self._set_progress, 0.86)
            ts_segments = []
            for _si, _seg in enumerate(segments):
                _tsf = os.path.join(temp_dir, f"seg_{_si}.ts")
                _run_logged(
                    ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                     "-i", _seg, "-map", "0:v:0", "-map", "0:a:0?",
                     "-c", "copy", "-bsf:v", _vbsf, "-f", "mpegts", _tsf],
                    f"ts convert seg{_si}",
                )
                ts_segments.append(_tsf)

            with open(concat_list, "w", encoding="utf-8") as f:
                f.write("\n".join(concat_file_line(path) for path in ts_segments))
                f.write("\n")

            self.root.after(0, lambda: self.status.config(text="Final concat (TS → mp4)...", fg="#1565C0"))
            self.root.after(0, self._set_progress, 0.92)
            concat_cmd = [
                "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                "-f", "concat",
                "-safe", "0",
                "-i", concat_list,
                "-map", "0",
                "-c", "copy",
            ]
            if a_encoder == "aac":
                concat_cmd += ["-bsf:a", "aac_adtstoasc"]
            concat_cmd += [*fake_metadata_args()]
            if os.path.splitext(out)[1].lower() in {".mp4", ".m4v", ".mov", ""}:
                concat_cmd.extend(["-movflags", "+faststart"])
            concat_cmd.append(out)
            _run_logged(concat_cmd, "final concat (TS)")
            _log(f"CONCAT done -> out dur={probe_duration(out):.2f}s ({_hms(probe_duration(out))})")
            _log(f">>> ПОЗИЦИЯ ВСТАВКИ В ИТОГОВОМ ФАЙЛЕ: {_hms(before_len)} .. {_hms(before_len + dur)} <<<")

            # Точку вставки двигают snap/keyframe/trim — поэтому пишем РЕАЛЬНЫЙ тайминг
            # вставки прямо в имя файла, чтобы сразу было видно где смотреть.
            try:
                _ins_tc = _hms(before_len).replace(":", "-")
                _b, _e = os.path.splitext(out)
                _named = f"{_b}_встройка_{_ins_tc}{_e}"
                if os.path.abspath(_named) != os.path.abspath(out):
                    if os.path.exists(_named):
                        os.remove(_named)
                    os.replace(out, _named)
                    out = _named
                    _log(f"Файл переименован с таймингом вставки: {os.path.basename(out)}")
            except Exception as _rn_err:
                _log(f"Не удалось дописать тайминг в имя: {_rn_err}")

            # Постпроцесс (перекод с эффектами) — финальный реэнкод, если включён.
            if pp_options:
                _pp_tmp = f"{os.path.splitext(out)[0]}.pre_pp{os.path.splitext(out)[1]}"
                try:
                    if os.path.exists(_pp_tmp):
                        os.remove(_pp_tmp)
                    os.replace(out, _pp_tmp)
                    self.root.after(0, lambda: self.status.config(text="Перекод с эффектами...", fg="#1565C0"))
                    _log("POSTPROCESS: применяю перекод с эффектами")
                    apply_postprocess(
                        _pp_tmp, out, pp_options, self._run_cmd_checked,
                        status_cb=lambda m: self.root.after(0, lambda: self.status.config(text=m, fg="#1565C0")),
                    )
                    _log(f"POSTPROCESS done -> dur={probe_duration(out):.2f}s")
                    try: os.remove(_pp_tmp)
                    except Exception: pass
                except Exception as _pe:
                    _log(f"POSTPROCESS FAILED: {_pe}")
                    # Восстанавливаем основной результат
                    if os.path.exists(_pp_tmp):
                        if os.path.exists(out):
                            try: os.remove(out)
                            except Exception: pass
                        os.replace(_pp_tmp, out)
                    raise

            shutil.rmtree(temp_dir, ignore_errors=True)
            temp_dir = None

            self.last_output = out
            self.root.after(0, self._set_progress, 1.0)
            self.root.after(0, lambda: self.open_file_btn.config(state="normal"))
            self.root.after(0, lambda: self.open_folder_btn.config(state="normal"))
            self.root.after(0, lambda: self.status.config(text=f"Готово: {out}", fg="#2E7D32"))
            self.root.after(0, lambda: messagebox.showinfo("Готово", f"Сохранено:\n{out}"))
        except FileNotFoundError:
            self.root.after(0, lambda: messagebox.showerror(
                "ffmpeg не найден",
                "Установите ffmpeg и добавьте в PATH.",
            ))
            self.root.after(0, lambda: self.status.config(text="ffmpeg не найден в PATH.", fg="#C62828"))
        except Exception as e:
            detail = str(e)
            try:
                _log(f"EXCEPTION: {detail}")
            except Exception:
                pass
            if temp_dir:
                detail += f"\n\nTemp files left for debug:\n{temp_dir}"
            self.root.after(0, lambda: self.status.config(text="Ошибка insert-сборки (см. диалог).", fg="#C62828"))
            self.root.after(0, lambda: messagebox.showerror("Insert error", detail))
        finally:
            self.root.after(0, lambda: self.run_btn.config(state="normal"))

    def _run_ffmpeg(self, cmd, out, total_sec: float, outro_path: str | None = None,
                    postprocess: dict | None = None):
        try:
            creationflags = 0
            if os.name == "nt":
                creationflags = subprocess.CREATE_NO_WINDOW  # скрыть консоль ffmpeg

            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                creationflags=creationflags,
            )

            if total_sec <= 0:
                # длительность неизвестна — переключим прогрессбар в indeterminate
                self.root.after(0, lambda: self.progress.config(mode="indeterminate"))
                self.root.after(0, self.progress.start, 80)

            # читаем -progress: пары key=value, разделитель — пустая строка / 'progress=end'
            for line in proc.stdout:
                line = line.strip()
                if not line or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                if k == "out_time_ms" and total_sec > 0:
                    try:
                        sec = int(v) / 1_000_000.0  # вопреки имени, это микросекунды
                        self.root.after(0, self._set_progress, sec / total_sec)
                    except ValueError:
                        pass
                elif k == "progress" and v == "end":
                    self.root.after(0, self._set_progress, 1.0)

            stderr_tail = proc.stderr.read() if proc.stderr else ""
            rc = proc.wait()

            if total_sec <= 0:
                self.root.after(0, self.progress.stop)
                self.root.after(0, lambda: self.progress.config(mode="determinate"))
                self.root.after(0, self._set_progress, 1.0 if rc == 0 else 0.0)

            if rc == 0 and os.path.isfile(out):
                # Авторка: основной микс готов в `out`. Переносим его во временный
                # файл и приклеиваем outro, финал снова пишем в `out`.
                if outro_path:
                    try:
                        base_o, ext_o = os.path.splitext(out)
                        main_tmp = f"{base_o}.pre_outro{ext_o}"
                        if os.path.exists(main_tmp):
                            os.remove(main_tmp)
                        os.replace(out, main_tmp)
                        self.root.after(0, lambda: self.status.config(text="Приклеиваю авторку...", fg="#1565C0"))
                        append_outro(
                            main_tmp, outro_path, out, self._run_cmd_checked,
                            status_cb=lambda m: self.root.after(0, lambda: self.status.config(text=m, fg="#1565C0")),
                        )
                        os.remove(main_tmp)
                    except Exception as _oe:
                        # Outro упал — НЕ теряем основной микс: возвращаем его в out.
                        try:
                            if os.path.exists(main_tmp):
                                if os.path.exists(out):
                                    os.remove(out)
                                os.replace(main_tmp, out)
                        except Exception:
                            pass
                        _msg = f"Микс готов (сохранён без авторки), но авторку приклеить не удалось:\n{_oe}"
                        self.root.after(0, lambda: self.status.config(text="Микс готов, авторка не приклеилась (см. диалог).", fg="#C62828"))
                        self.root.after(0, lambda: messagebox.showerror("Outro error", _msg))
                        self.root.after(0, lambda: self.open_file_btn.config(state="normal"))
                        self.root.after(0, lambda: self.open_folder_btn.config(state="normal"))
                        self.last_output = out
                        self.root.after(0, lambda: self.run_btn.config(state="normal"))
                        return
                # Постпроцесс (перекод с эффектами) — после outro / основного микса
                if postprocess:
                    try:
                        _pp_tmp = f"{os.path.splitext(out)[0]}.pre_pp{os.path.splitext(out)[1]}"
                        if os.path.exists(_pp_tmp):
                            os.remove(_pp_tmp)
                        os.replace(out, _pp_tmp)
                        self.root.after(0, lambda: self.status.config(text="Перекод с эффектами...", fg="#1565C0"))
                        apply_postprocess(
                            _pp_tmp, out, postprocess, self._run_cmd_checked,
                            status_cb=lambda m: self.root.after(0, lambda: self.status.config(text=m, fg="#1565C0")),
                        )
                        try: os.remove(_pp_tmp)
                        except Exception: pass
                    except Exception as _ppe:
                        # postprocess упал — возвращаем основной микс
                        try:
                            if os.path.exists(_pp_tmp):
                                if os.path.exists(out):
                                    os.remove(out)
                                os.replace(_pp_tmp, out)
                        except Exception:
                            pass
                        self.root.after(0, lambda: self.status.config(text="Микс готов, постпроцесс не удался (см. диалог).", fg="#C62828"))
                        self.root.after(0, lambda: messagebox.showerror("Postprocess error", str(_ppe)))
                        self.root.after(0, lambda: self.open_file_btn.config(state="normal"))
                        self.root.after(0, lambda: self.open_folder_btn.config(state="normal"))
                        self.last_output = out
                        self.root.after(0, lambda: self.run_btn.config(state="normal"))
                        return
                self.last_output = out
                self.root.after(0, lambda: self.open_file_btn.config(state="normal"))
                self.root.after(0, lambda: self.open_folder_btn.config(state="normal"))
                self.root.after(0, lambda: self.status.config(text=f"Готово: {out}", fg="#2E7D32"))
                self.root.after(0, lambda: messagebox.showinfo("Готово", f"Сохранено:\n{out}"))
            else:
                tail = (stderr_tail or "")[-2500:]
                self.root.after(0, lambda: self.status.config(text="Ошибка ffmpeg (см. диалог).", fg="#C62828"))
                self.root.after(0, lambda: messagebox.showerror("FFmpeg error", tail or "Unknown error"))
        except FileNotFoundError:
            self.root.after(0, lambda: messagebox.showerror(
                "ffmpeg не найден",
                "Установите ffmpeg и добавьте в PATH (https://ffmpeg.org/)."
            ))
            self.root.after(0, lambda: self.status.config(text="ffmpeg не найден в PATH.", fg="#C62828"))
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("Ошибка", str(e)))
        finally:
            self.root.after(0, lambda: self.run_btn.config(state="normal"))


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
