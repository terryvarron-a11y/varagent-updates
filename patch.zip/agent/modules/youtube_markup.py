"""Pass 1 directive for the opt-in YouTube Footage stage."""
from __future__ import annotations

import config


def youtube_markup_directive() -> str:
    if not getattr(config, "YOUTUBE_FOOTAGE_ENABLED", False):
        return ""

    target_pct = int(float(getattr(config, "YOUTUBE_RATIO_TARGET", 0.0)) * 100)
    max_fragment = float(getattr(config, "YOUTUBE_MAX_FRAGMENT_SEC", 3.0))
    return f"""

---

## YOUTUBE FOOTAGE MARKUP

An optional downstream stage can replace selected clips with real documentary
or user-provided footage. Target about {target_pct}% of clips. Mark only clips
where moving real footage is semantically stronger than generated imagery.

Good candidates:
- real events, demonstrations, disasters, transport, work, crowds;
- places, landscapes, streets, machines, archival-looking movement;
- actions that benefit from visible motion.

Do not mark:
- named people or exact historical claims when the footage would be misleading;
- fictional or impossible scenes;
- clips where a still image or infographic is clearly better.

If suitable, add only:
  "source": "youtube_pending"

Do not invent download URLs, timestamps, video IDs, or provider fields. The
YouTube stage creates those after Pass 1.
Maximum moving excerpt per selected source is {max_fragment:g} seconds; this is
not a project-wide limit for one source video.
"""
