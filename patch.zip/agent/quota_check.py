"""
quota_check.py — проверяет остаток квоты FastGen API vs количество нужных клипов.

Usage:
  python quota_check.py <project_name>
  python quota_check.py <project_name> --ids 1,2,3

Output (stdout):
  remaining=<N>    (число оставшихся генераций в этом часу, или ? если неизвестно)
  needed=<N>       (сколько клипов нужно сгенерировать)
  has_backup=<0|1> (есть ли FASTGEN_API_KEY_BACKUP в .env)

Exit codes:
  0 - квоты хватает (или неизвестно — пускаем без предупреждения)
  2 - квоты НЕ хватает, резервный ключ есть
  3 - квоты НЕ хватает, резервного ключа нет
  1 - ошибка (проект не найден, промпты не найдены)
"""
import sys
import os
from pathlib import Path

if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

sys.path.insert(0, str(Path(__file__).parent))

import config
from extract_prompt import extract_all_prompts, find_prompts_file
from modules.fastgen import FastGenClient, parse_usage_remaining


def main():
    if len(sys.argv) < 2:
        print("Usage: quota_check.py <project_name> [--ids 1,2,3]", file=sys.stderr)
        sys.exit(1)

    project_name = sys.argv[1]
    base_dir = Path(__file__).parent.parent
    project_dir = base_dir / 'projects' / project_name

    if not project_dir.exists():
        print(f"ERROR: Project not found: {project_dir}", file=sys.stderr)
        sys.exit(1)

    # Парсим --ids если есть
    clip_ids = None
    if '--ids' in sys.argv:
        idx = sys.argv.index('--ids')
        if idx + 1 < len(sys.argv):
            try:
                clip_ids = set(int(x.strip()) for x in sys.argv[idx + 1].split(','))
            except ValueError:
                pass  # игнорируем некорректный формат

    # Считаем нужные клипы
    prompts_file = find_prompts_file(str(project_dir))
    if not prompts_file:
        print(f"ERROR: No prompts file in {project_dir}", file=sys.stderr)
        sys.exit(1)

    all_prompts = extract_all_prompts(prompts_file)
    if not all_prompts:
        print(f"ERROR: No prompts parsed", file=sys.stderr)
        sys.exit(1)

    if clip_ids:
        needed = len([k for k in all_prompts if k in clip_ids])
    else:
        needed = len(all_prompts)

    use_backup = '--backup-key' in sys.argv
    has_backup = 1 if config.FASTGEN_API_KEY_BACKUP else 0

    # Выбираем ключ для проверки
    if use_backup:
        api_key = config.FASTGEN_API_KEY_BACKUP
    else:
        api_key = config.FASTGEN_API_KEY

    # Проверяем квоту выбранного ключа
    remaining = None
    if api_key:
        try:
            client = FastGenClient(api_key=api_key)
            usage = client.get_usage()
            remaining = parse_usage_remaining(usage)
        except Exception:
            pass  # не смогли получить — unknown

    # Вывод
    print(f"remaining={'?' if remaining is None else remaining}")
    print(f"needed={needed}")
    print(f"has_backup={has_backup}")

    # Exit code
    if remaining is None:
        sys.exit(0)  # неизвестно — пропускаем проверку
    if remaining >= needed:
        sys.exit(0)  # хватает
    if not use_backup and has_backup:
        sys.exit(2)  # не хватает, есть резерв
    sys.exit(3)      # не хватает, резерва нет (или уже используем backup)


if __name__ == '__main__':
    main()
