#!/bin/bash
# VARAGENT - Emergency macOS Fix
# Fixes broken installation where agent/ subfolders were not updated correctly.
# Double-click this file in Finder to run.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[ -f "$SCRIPT_DIR/.venv/bin/activate" ] && source "$SCRIPT_DIR/.venv/bin/activate"
cd "$SCRIPT_DIR"

echo ""
echo "================================================================"
echo " VARAGENT - Emergency macOS Fix"
echo " Restoring agent/ subfolders..."
echo "================================================================"
echo ""

if ! command -v python3 &>/dev/null; then
    echo " [ERROR] python3 not found. Run install.command first."
    echo ""
    read -p "Press Enter to exit..." DUMMY
    exit 1
fi

python3 << 'PYEOF'
import zipfile, io, pathlib, urllib.request, sys

PATCH_URL = 'https://raw.githubusercontent.com/terryvarron-a11y/varagent-updates/main/patch.zip'
SKIP = {'projects/', '.env', 'agent/.env', 'publisher.py'}

root = pathlib.Path('.')
print(' Downloading patch from GitHub...')
try:
    with urllib.request.urlopen(PATCH_URL, timeout=60) as r:
        patch_bytes = r.read()
except Exception as e:
    print(f' [ERROR] Download failed: {e}')
    sys.exit(1)

print(' Installing files...')
count = 0
with zipfile.ZipFile(io.BytesIO(patch_bytes)) as zf:
    for name in zf.namelist():
        if any(name.startswith(s) for s in SKIP):
            continue
        dest = root / pathlib.Path(name)   # pathlib handles / correctly on macOS
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(zf.read(name))
        count += 1
        print(f'   {name}')

print(f'')
print(f' [OK] Installed {count} files.')
print(f' [OK] Run varagent.command to start.')
PYEOF

EXIT_CODE=$?
if [ $EXIT_CODE -ne 0 ]; then
    echo ""
    echo " [ERROR] Fix failed. See error above."
    echo ""
fi

echo ""
read -p "Press Enter to exit..." DUMMY
