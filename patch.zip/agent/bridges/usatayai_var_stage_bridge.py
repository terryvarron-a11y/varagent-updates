#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
usatayai_var_stage_bridge.py — v55.31
Stable stage-level bridge for Usataya Lentyayka -> VAR.

Goal:
  Let an external app use selected VAR brains without running the VAR GUI:
    1) external Whisper/SRT -> VAR transcription.json
    2) VAR director/prompter -> montage_plan.json + *_prompts_*.txt
    3) external generator results -> VAR vid_img/
    4) VAR video_concat.py -> optional usatayai_bridge.py final dobivka

This file does not replace VAR internals. It is a thin command-line adapter.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

VAR_DIR = Path(__file__).resolve().parent
AGENT_DIR = VAR_DIR / "agent"
if str(AGENT_DIR) not in sys.path:
    sys.path.insert(0, str(AGENT_DIR))


def log(msg: str) -> None:
    print(f"[USATAYAI-STAGE-BRIDGE] {msg}", flush=True)


def srt_timestamp_to_seconds(value: str) -> float:
    value = value.strip().replace(".", ",")
    hms, ms = value.split(",", 1)
    h, m, s = [int(x) for x in hms.split(":")]
    return h * 3600 + m * 60 + s + int((ms + "000")[:3]) / 1000.0


def seconds_to_srt(seconds: float) -> str:
    seconds = max(0.0, float(seconds))
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    ms = int(round((seconds - int(seconds)) * 1000))
    if ms >= 1000:
        s += 1
        ms -= 1000
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def srt_to_transcription(srt_path: Path, audio_path: Optional[Path] = None, language: str = "auto") -> Dict[str, Any]:
    text = srt_path.read_text(encoding="utf-8-sig", errors="replace")
    blocks = [b.strip() for b in re.split(r"\n{2,}", text) if b.strip()]
    items: List[Dict[str, Any]] = []
    for block in blocks:
        lines = [l.strip() for l in block.splitlines() if l.strip()]
        tc_line = next((l for l in lines if "-->" in l), None)
        if not tc_line:
            continue
        idx = lines.index(tc_line)
        try:
            t0, t1 = [x.strip().split()[0] for x in tc_line.split("-->", 1)]
            start = srt_timestamp_to_seconds(t0)
            end = srt_timestamp_to_seconds(t1)
            body = " ".join(lines[idx + 1:]).strip()
        except Exception:
            continue
        if body and end > start:
            items.append({"id": len(items) + 1, "text": body, "start": round(start, 3), "end": round(end, 3)})

    if not items:
        raise ValueError(f"SRT has no valid subtitle blocks: {srt_path}")

    duration = items[-1]["end"]
    if audio_path and audio_path.exists():
        try:
            r = subprocess.run(
                ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", str(audio_path)],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=30,
            )
            val = float((r.stdout or "").strip() or 0.0)
            if val > duration:
                duration = val
        except Exception:
            pass

    return {"audioDuration": round(duration, 3), "language": language, "transcription": items}


def transcription_to_srt(transcription_path: Path, out_path: Path) -> Path:
    data = json.loads(transcription_path.read_text(encoding="utf-8-sig"))
    lines = []
    for i, seg in enumerate(data.get("transcription", []), start=1):
        text = str(seg.get("text") or "").strip()
        if not text:
            continue
        lines.extend([
            str(i),
            f"{seconds_to_srt(float(seg.get('start', 0)))} --> {seconds_to_srt(float(seg.get('end', 0)))}",
            text,
            "",
        ])
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(lines), encoding="utf-8-sig")
    return out_path


def cmd_prepare_transcription(args: argparse.Namespace) -> int:
    project_dir = Path(args.project_dir).expanduser().resolve()
    project_dir.mkdir(parents=True, exist_ok=True)
    srt_path = Path(args.srt).expanduser().resolve()
    audio_path = Path(args.audio).expanduser().resolve() if args.audio else None
    out = Path(args.output).expanduser().resolve() if args.output else project_dir / "transcription.json"
    data = srt_to_transcription(srt_path, audio_path, args.language)
    out.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    srt_copy = project_dir / "SRT" / "subtitles.srt"
    srt_copy.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(str(srt_path), str(srt_copy))
    log(f"transcription.json saved: {out}")
    log(f"SRT copied: {srt_copy}")
    print(f"RESULT_TRANSCRIPTION:{out}", flush=True)
    return 0


def cmd_direct(args: argparse.Namespace) -> int:
    project_dir = Path(args.project_dir).expanduser().resolve()
    project_dir.mkdir(parents=True, exist_ok=True)
    transcription = Path(args.transcription).expanduser().resolve() if args.transcription else project_dir / "transcription.json"
    style = Path(args.style).expanduser().resolve()
    if not transcription.exists():
        raise FileNotFoundError(f"transcription.json not found: {transcription}")
    if not style.exists():
        raise FileNotFoundError(f"style guide not found: {style}")

    import config as var_config
    if args.backend:
        setattr(var_config, "DIRECTOR_BACKEND", args.backend)
    if args.model:
        setattr(var_config, "GEMINI_MODEL", args.model)
    from modules.director import direct_project

    results = direct_project(
        str(transcription),
        str(style),
        str(project_dir),
        args.project_name or project_dir.name,
        model_name=args.model,
        two_pass=bool(args.two_pass),
        prompts_only=bool(args.prompts_only),
        resume_path=args.resume_path,
    )
    log("director done")
    for k, v in results.items():
        log(f"{k}: {v}")
    print(f"RESULT_PROJECT:{project_dir}", flush=True)
    if (project_dir / "montage_plan.json").exists():
        print(f"RESULT_MONTAGE_PLAN:{project_dir / 'montage_plan.json'}", flush=True)
    prompts = sorted([p for p in project_dir.glob("*_prompts_*.txt") if "OVERPROMPT" not in p.name], key=lambda p: p.stat().st_mtime)
    if prompts:
        print(f"RESULT_PROMPTS:{prompts[-1]}", flush=True)
    return 0


def cmd_export_prompts(args: argparse.Namespace) -> int:
    project_dir = Path(args.project_dir).expanduser().resolve()
    out = Path(args.output).expanduser().resolve() if args.output else project_dir / "usatayai_prompts_manifest.json"
    agent_extract = AGENT_DIR / "extract_prompt.py"
    if str(AGENT_DIR) not in sys.path:
        sys.path.insert(0, str(AGENT_DIR))
    try:
        from extract_prompt import find_prompts_file, extract_all_prompts
    except Exception as e:
        raise RuntimeError(f"cannot import VAR extract_prompt.py: {e}")
    pf = args.prompts_file or find_prompts_file(str(project_dir))
    if not pf:
        raise FileNotFoundError(f"prompts file not found in {project_dir}")
    prompts = extract_all_prompts(pf)
    plan_path = project_dir / "montage_plan.json"
    plan = json.loads(plan_path.read_text(encoding="utf-8-sig")) if plan_path.exists() else {}
    payload = {
        "project_dir": str(project_dir),
        "montage_plan": str(plan_path) if plan_path.exists() else "",
        "prompts_file": str(pf),
        "clips": plan.get("clips", []),
        "prompts": {str(k): v for k, v in prompts.items()},
    }
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    log(f"prompts manifest saved: {out}")
    print(f"RESULT_PROMPTS_MANIFEST:{out}", flush=True)
    return 0


def _numeric_id_from_name(path: Path) -> Optional[int]:
    m = re.search(r"(?<!\d)(\d{1,4})(?!\d)", path.stem)
    return int(m.group(1)) if m else None


def cmd_import_clips(args: argparse.Namespace) -> int:
    project_dir = Path(args.project_dir).expanduser().resolve()
    src_dir = Path(args.source_dir).expanduser().resolve()
    dest_dir = project_dir / "vid_img"
    dest_dir.mkdir(parents=True, exist_ok=True)
    exts = {".mp4", ".mov", ".mkv", ".avi", ".png", ".jpg", ".jpeg", ".webp"}
    files = [p for p in src_dir.iterdir() if p.is_file() and p.suffix.lower() in exts and not p.name.startswith("._")]
    if not files:
        raise FileNotFoundError(f"no generated clips/images found in {src_dir}")
    copied = 0
    for p in sorted(files):
        cid = _numeric_id_from_name(p)
        if cid is None:
            continue
        dest = dest_dir / f"{cid:03d}{p.suffix.lower()}"
        shutil.copy2(str(p), str(dest))
        copied += 1
    log(f"imported clips: {copied} -> {dest_dir}")
    print(f"RESULT_VID_IMG:{dest_dir}", flush=True)
    return 0



def _resolve_bridge_manifest(args: argparse.Namespace, project_dir: Path) -> Optional[Path]:
    """Возвращает manifest добивки для Коршун→VAR.

    Основной путь приходит из samovar_viet_post_concat.py через --bridge-manifest.
    Резерв нужен на случай старого runner или ручного запуска: пробуем env и project/_tmp.
    """
    raw_values = [getattr(args, "bridge_manifest", None), os.environ.get("USATAYAI_BRIDGE_MANIFEST")]
    for raw in raw_values:
        if not raw:
            continue
        p = Path(str(raw)).expanduser()
        if p.exists() and p.is_file():
            return p.resolve()

    candidates: List[Path] = []
    for root in (project_dir / "_tmp", project_dir):
        if not root.exists():
            continue
        for pat in ("samovar_viet_manifest_*.json", "samovar_nonstop_manifest_*.json"):
            candidates.extend(root.glob(pat))
    candidates = [p for p in candidates if p.is_file()]
    if not candidates:
        return None
    candidates.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return candidates[0].resolve()


def _raw_concat_output_path(project_dir: Path, final_output: Path) -> Path:
    raw_dir = project_dir / "_var_concat_temp"
    raw_dir.mkdir(parents=True, exist_ok=True)
    safe_stem = re.sub(r"[^\w\-. ]+", "_", final_output.stem, flags=re.UNICODE).strip(" ._") or "var_concat"
    return raw_dir / f"{safe_stem}_raw.mp4"


def cmd_concat(args: argparse.Namespace) -> int:
    project_dir = Path(args.project_dir).expanduser().resolve()
    plan = Path(args.montage_plan).expanduser().resolve() if args.montage_plan else project_dir / "montage_plan.json"
    output = Path(args.output).expanduser().resolve() if args.output else project_dir / "result.mp4"
    audio = Path(args.audio).expanduser().resolve() if args.audio else None

    bridge_manifest = _resolve_bridge_manifest(args, project_dir)
    using_usataya_bridge = bridge_manifest is not None

    # v55.30: если включён Usataya bridge, родной VAR concat пишет только сырой промежуточный
    # файл в project/_var_concat_temp. Финальный файл в READY/выходную папку создаёт уже
    # usatayai_bridge.py. Поэтому original_audio/temp больше не валятся в папку выхода.
    video_concat_output = _raw_concat_output_path(project_dir, output) if using_usataya_bridge else output

    cmd = [
        sys.executable,
        str(VAR_DIR / "video_concat.py"),
        str(plan),
        "-o", str(video_concat_output),
        "--fps", str(args.fps),
        "-b", args.bitrate,
    ]
    if audio:
        cmd += ["-a", str(audio)]
    if args.resolution:
        cmd += ["-r", str(args.resolution)]
    if args.no_gpu:
        cmd += ["--no-gpu"]
    if args.force_amd:
        cmd += ["--force-amd"]

    env = dict(os.environ)
    # Внутренний --usatayai-bridge-manifest в video_concat НЕ передаём специально.
    # Иначе video_concat опять будет считать args.output финальным и создавать
    # *_original_audio.wav около READY. Bridge запускаем сами ниже.
    env.pop("USATAYAI_BRIDGE_MANIFEST", None)

    if using_usataya_bridge:
        log(f"bridge manifest: {bridge_manifest}")
        log(f"raw VAR concat output: {video_concat_output}")
        log(f"final output after Usataya bridge: {output}")
    else:
        log("bridge manifest: none, plain VAR concat")

    # v55.28/55.29: video_concat.py не должен ждать input() про temp_processed.
    # Пускаем его с закрытым stdin; тогда его штатная защита non-TTY удаляет temp автоматически.
    log("running concat: " + " ".join(cmd))
    proc = subprocess.Popen(cmd, cwd=str(project_dir), stdin=subprocess.DEVNULL, env=env)
    rc = proc.wait()
    if rc != 0:
        return rc

    if using_usataya_bridge:
        if not video_concat_output.exists():
            raise FileNotFoundError(f"raw VAR concat output not found: {video_concat_output}")
        try:
            if str(VAR_DIR) not in sys.path:
                sys.path.insert(0, str(VAR_DIR))
            from usatayai_bridge import run_bridge_if_requested
            log("applying Usataya final bridge...")
            run_bridge_if_requested(
                str(bridge_manifest),
                str(video_concat_output),
                str(output),
                str(audio) if audio else None,
                bitrate=args.bitrate,
                fps=int(args.fps),
                encoder_type="cpu",
                codec="libx264",
            )
            log("Usataya final bridge done")
        except Exception as exc:
            log(f"Usataya final bridge failed: {exc}")
            return 1
        try:
            shutil.rmtree(str(video_concat_output.parent), ignore_errors=True)
        except Exception:
            pass

    if output.exists():
        print(f"RESULT_VIDEO:{output}", flush=True)
    else:
        log(f"WARN: output not found after concat: {output}")
    return 0

def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description="Usataya Lentyayka stage bridge for VAR")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("prepare-transcription", help="external SRT -> VAR transcription.json")
    p.add_argument("--project-dir", required=True)
    p.add_argument("--srt", required=True)
    p.add_argument("--audio", default=None)
    p.add_argument("--language", default="auto")
    p.add_argument("--output", default=None)
    p.set_defaults(func=cmd_prepare_transcription)

    p = sub.add_parser("direct", help="run VAR director/prompter on existing transcription.json")
    p.add_argument("--project-dir", required=True)
    p.add_argument("--transcription", default=None)
    p.add_argument("--style", required=True)
    p.add_argument("--project-name", default=None)
    p.add_argument("--backend", choices=["gemini", "gpt"], default=None)
    p.add_argument("--model", default=None)
    p.add_argument("--two-pass", action="store_true")
    p.add_argument("--prompts-only", action="store_true")
    p.add_argument("--resume-path", default=None)
    p.set_defaults(func=cmd_direct)

    p = sub.add_parser("export-prompts", help="VAR prompts -> JSON manifest for external generator")
    p.add_argument("--project-dir", required=True)
    p.add_argument("--prompts-file", default=None)
    p.add_argument("--output", default=None)
    p.set_defaults(func=cmd_export_prompts)

    p = sub.add_parser("import-clips", help="external generated clips/images -> project/vid_img/001.mp4")
    p.add_argument("--project-dir", required=True)
    p.add_argument("--source-dir", required=True)
    p.set_defaults(func=cmd_import_clips)

    p = sub.add_parser("concat", help="run VAR video_concat.py, optionally with usatayai final bridge")
    p.add_argument("--project-dir", required=True)
    p.add_argument("--montage-plan", default=None)
    p.add_argument("--output", default=None)
    p.add_argument("--audio", default=None)
    p.add_argument("--bridge-manifest", default=None)
    p.add_argument("--fps", type=int, default=60)
    p.add_argument("--bitrate", default="10M")
    p.add_argument("--resolution", default=None)
    p.add_argument("--no-gpu", action="store_true")
    p.add_argument("--force-amd", action="store_true")
    p.set_defaults(func=cmd_concat)
    return ap


def main() -> int:
    ns = build_parser().parse_args()
    return int(ns.func(ns))


if __name__ == "__main__":
    raise SystemExit(main())
