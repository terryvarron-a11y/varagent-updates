#!/bin/bash
# START_VEONON_GEN.COMMAND - VeoNonStop video generation (macOS - double click, modes: i2v/t2v/components)
# Run: double-click this file in Finder

PROJECT_NAME="{project_name}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
AGENT_DIR="$(cd "$SCRIPT_DIR/../../agent" && pwd)"

# Auto-set execute permissions
chmod +x *.command *.sh 2>/dev/null
[ -f "$SCRIPT_DIR/.venv/bin/activate" ] && source "$SCRIPT_DIR/.venv/bin/activate"

# Open Terminal.app for interactive mode
if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e "tell app \"Terminal\" to do script \"cd '$SCRIPT_DIR' && exec '$0'\""
    exit 0
fi

echo ""
echo "========================================================================"
echo "  STAGE 3.5: VIDEO GENERATION (VeoNonStop)"
echo "  Project: $PROJECT_NAME"
echo "========================================================================"
echo ""

# Mode selection
echo "  Video generation mode:"
echo "    [1] i2v        - image-to-video (animate images from generated/)"
echo "    [2] t2v        - text-to-video (from prompts, no images)"
echo "    [3] components - text-to-video + references from ref/"
echo ""
read -p "  Mode [1/2/3] (Enter = 1): " MODE_CHOICE
MODE="i2v"
case "$MODE_CHOICE" in
    2) MODE="t2v" ;;
    3) MODE="components" ;;
esac
echo "    Selected: $MODE"
echo ""

# Aspect ratio
echo "  Select aspect ratio:"
echo "    [1] 16:9   landscape, default"
echo "    [2] 9:16   portrait"
echo "    [3] 1:1    square"
echo ""
read -p "  Aspect [1/2/3] (Enter = 1): " RATIO_CHOICE
RATIO="16:9"
case "$RATIO_CHOICE" in
    2) RATIO="9:16" ;;
    3) RATIO="1:1" ;;
esac
echo "    Selected: $RATIO"
echo ""

# Check server slots (key1= / key2= / key3= / key4= lines)
SLOTS_RAW=$(python "$AGENT_DIR/check_slots.py" 2>/dev/null)
echo "$SLOTS_RAW"
KEY1_SLOTS=$(echo "$SLOTS_RAW" | grep '^key1=' | cut -d'=' -f2)
KEY2_SLOTS=$(echo "$SLOTS_RAW" | grep '^key2=' | cut -d'=' -f2)
KEY3_SLOTS=$(echo "$SLOTS_RAW" | grep '^key3=' | cut -d'=' -f2)
KEY4_SLOTS=$(echo "$SLOTS_RAW" | grep '^key4=' | cut -d'=' -f2)
KEY1_SLOTS="${KEY1_SLOTS:-0}"
KEY2_SLOTS="${KEY2_SLOTS:-0}"
KEY3_SLOTS="${KEY3_SLOTS:-0}"
KEY4_SLOTS="${KEY4_SLOTS:-0}"
KEY_TOTAL=$(( KEY1_SLOTS + KEY2_SLOTS + KEY3_SLOTS + KEY4_SLOTS ))
echo ""

# Key selection
echo "  Select API key:"
echo "    [1] Key1  ($KEY1_SLOTS slots)    (default)"
[ "$KEY2_SLOTS" -gt 0 ] 2>/dev/null && echo "    [2] Key2  ($KEY2_SLOTS slots)"
[ "$KEY3_SLOTS" -gt 0 ] 2>/dev/null && echo "    [3] Key3  ($KEY3_SLOTS slots)"
[ "$KEY4_SLOTS" -gt 0 ] 2>/dev/null && echo "    [4] Key4  ($KEY4_SLOTS slots)"
[ "$KEY_TOTAL" -gt "$KEY1_SLOTS" ] 2>/dev/null && echo "    [A] All   ($KEY_TOTAL slots total)"
echo ""
read -p "  Key [1/2/3/4/A] (Enter = 1): " KEY_CHOICE
KEY_SLOT="1"
KEY_LABEL="Key1"
KEY_DEFAULT_PARALLEL="$KEY1_SLOTS"
case "$KEY_CHOICE" in
    2) KEY_SLOT="2"; KEY_LABEL="Key2"; KEY_DEFAULT_PARALLEL="$KEY2_SLOTS"; echo "    Selected: Key2" ;;
    3) KEY_SLOT="3"; KEY_LABEL="Key3"; KEY_DEFAULT_PARALLEL="$KEY3_SLOTS"; echo "    Selected: Key3" ;;
    4) KEY_SLOT="4"; KEY_LABEL="Key4"; KEY_DEFAULT_PARALLEL="$KEY4_SLOTS"; echo "    Selected: Key4" ;;
    [aA]) KEY_SLOT="all"; KEY_LABEL="All"; KEY_DEFAULT_PARALLEL="$KEY_TOTAL"; echo "    Selected: All" ;;
    *) echo "    Selected: Key1" ;;
esac
echo ""

# Parallel
[ "$KEY_DEFAULT_PARALLEL" -eq 0 ] 2>/dev/null && KEY_DEFAULT_PARALLEL=12
read -p "  Parallel workers (Enter = $KEY_DEFAULT_PARALLEL, key slots = $KEY_DEFAULT_PARALLEL): " PARALLEL
PARALLEL="${PARALLEL:-$KEY_DEFAULT_PARALLEL}"
echo "    Selected: $PARALLEL"
echo ""

# Clip IDs
read -p "  Clip IDs (e.g. 1,2,3 or Enter for all): " IDS_INPUT
IDS_ARG=""
if [ -n "$IDS_INPUT" ]; then
    IDS_ARG="--ids $IDS_INPUT"
    echo "    Clips: $IDS_INPUT"
else
    echo "    Clips: ALL"
fi
echo ""

# Single prompt
read -p "  Single prompt for all clips (Enter = per-clip): " PROMPT_INPUT
PROMPT_ARG=""
if [ -n "$PROMPT_INPUT" ]; then
    PROMPT_ARG="--prompt \"$PROMPT_INPUT\""
    echo "    Prompt: single"
else
    echo "    Prompt: per-clip"
fi
echo ""

# Confirm
echo "========================================================================"
echo "  SUMMARY:"
echo "    Project:  $PROJECT_NAME"
echo "    Mode:     $MODE"
echo "    Key:      $KEY_LABEL"
echo "    Ratio:    $RATIO"
echo "    Parallel: $PARALLEL"
echo "========================================================================"
echo ""
read -p "  Start? (y/n): " CONFIRM
if [ "$CONFIRM" != "y" ] && [ "$CONFIRM" != "Y" ]; then
    echo "  Cancelled."
    exit 0
fi

echo ""
echo "  Starting video generation..."
echo ""

cd "$AGENT_DIR"

eval python agent.py img2video \
    --project "$PROJECT_NAME" \
    --mode "$MODE" \
    --ratio "$RATIO" \
    --parallel "$PARALLEL" \
    --key-slot "$KEY_SLOT" $IDS_ARG $PROMPT_ARG

EXIT_CODE=$?
echo ""
if [ $EXIT_CODE -ne 0 ]; then
    echo "[ERROR] Video generation failed. See log above."
else
    echo "========================================================================"
    echo "  DONE. Output: $SCRIPT_DIR/vid_img/"
    echo "========================================================================"
fi
echo ""
read -p "Press Enter to close..."
