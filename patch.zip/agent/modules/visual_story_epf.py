"""EPF, archive fallback and asset materialization for Auto Visual Story."""
from __future__ import annotations

import json
import logging
import os
import shutil
import time
from pathlib import Path
from typing import Any

import config

logger = logging.getLogger(__name__)


def _generated_asset(project: Path, clip_id: int) -> Path | None:
    files = sorted((project / "generated").glob(f"{clip_id:03d}.*"))
    return files[0] if files else None


def _copy_reused_asset(project: Path, source_id: int, target_id: int) -> Path:
    source = _generated_asset(project, source_id)
    if source is None:
        raise FileNotFoundError(
            f"reuse_previous source asset is missing for clip {source_id}"
        )
    target = project / "generated" / f"{target_id:03d}{source.suffix.lower()}"
    target.parent.mkdir(parents=True, exist_ok=True)
    for old in target.parent.glob(f"{target_id:03d}.*"):
        old.unlink()
    try:
        os.link(source, target)
    except OSError:
        shutil.copy2(source, target)
    return target


def _clip_selection(plan: dict[str, Any]):
    from modules.real_photo import ClipSelection

    return ClipSelection(
        clip_id=int(plan["scene_id"]),
        search_query=str(plan.get("search_query") or "").strip(),
        search_query_local="",
        preferred_type="photo",
        preferred_sources=list(getattr(
            config,
            "REAL_PHOTO_SOURCES",
            ["wikimedia", "nasa", "loc", "archive"],
        )),
        reasoning=str(plan.get("reason") or ""),
        confidence=str(plan.get("confidence") or ""),
        query_provider="auto_visual_story",
        query_path="primary",
    )


def _apply_epf_metadata(
    montage: dict[str, Any],
    plans_by_id: dict[int, dict[str, Any]],
    epf_summary: dict[str, Any],
) -> None:
    ingested = {
        int(item["clip_id"]): item
        for item in epf_summary.get("ingest", {}).get("results", [])
        if item.get("status") == "ingested"
    }
    for clip in montage.get("clips", []):
        clip_id = int(clip["id"])
        if clip_id not in ingested:
            continue
        plan = plans_by_id[clip_id]
        clip["source"] = "real_photo"
        clip["file"] = f"generated/{clip_id:03d}.jpg"
        clip["real_meta"] = {
            "archive": "extreme_picture_finder",
            "title": plan.get("search_query", ""),
            "license": "unknown",
            "author": "",
            "page_url": "",
            "credit_text": "Extreme Picture Finder",
        }


def _run_archive_fallback(
    project: Path,
    unresolved_plans: list[dict[str, Any]],
) -> dict[str, Any]:
    if not unresolved_plans:
        return {"rendered": 0, "selected": 0}
    from modules.real_photo import RealPhotoProcessor

    selections = [_clip_selection(plan) for plan in unresolved_plans]
    processor = RealPhotoProcessor(
        project_dir=project,
        target_ratio=1.0,
        min_ratio=1.0,
        max_ratio=1.0,
        sources=list(getattr(
            config,
            "REAL_PHOTO_SOURCES",
            ["wikimedia", "nasa", "loc", "archive"],
        )),
        target_w=1920,
        target_h=1080,
        fps=getattr(config, "VIDEO_FPS", 60),
    )
    old_bridge = getattr(config, "REAL_PHOTO_EPF_BRIDGE", False)
    config.REAL_PHOTO_EPF_BRIDGE = False
    try:
        return processor.process_phase(selections)
    finally:
        config.REAL_PHOTO_EPF_BRIDGE = old_bridge


def _load_montage(project: Path) -> dict[str, Any]:
    return json.loads(
        (project / "montage_plan.json").read_text(encoding="utf-8-sig")
    )


def _save_montage(project: Path, montage: dict[str, Any]) -> None:
    (project / "montage_plan.json").write_text(
        json.dumps(montage, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def _run_stock_for_visual_story(
    project: Path,
    plans: list[dict[str, Any]],
    montage: dict[str, Any],
) -> tuple[dict[str, Any], set[int]]:
    """Run only the Stock slice explicitly allocated by Auto Visual Story."""
    if not getattr(config, "STOCK_ENABLED", False):
        return {"enabled": False, "selected": 0, "resolved": [], "unresolved": []}, set()

    from modules.stock_prompter import StockQuery
    from modules.stock_search import _scan_local_library
    from modules.stock_stage import (
        StockProcessor,
        _enabled_sources,
        _match_local_by_words,
    )

    sources = list(_enabled_sources())
    stock_plans = [
        p for p in plans
        if p.get("visual_strategy") == "new_search"
        and str(p.get("preferred_source") or "").lower()
        in {"stock", "local", "stock_photo", "stock_video"}
    ]
    if not stock_plans or not sources:
        return {
            "enabled": True,
            "sources": sources,
            "selected": len(stock_plans),
            "resolved": [],
            "unresolved": [int(p["scene_id"]) for p in stock_plans],
        }, {int(p["scene_id"]) for p in stock_plans}

    processor = StockProcessor(
        project,
        target_w=1920,
        target_h=1080,
        fps=getattr(config, "VIDEO_FPS", 60),
    )
    processor.queries = {
        int(p["scene_id"]): StockQuery(
            clip_id=int(p["scene_id"]),
            query=str(p.get("search_query") or p.get("visual_intent") or "").strip(),
            media="photo" if str(p.get("media_type") or "").lower() == "photo" else "video",
            query_by="auto_visual_story",
            query_path="visual_plan",
        )
        for p in stock_plans
    }

    library = str(getattr(config, "STOCK_LIBRARY_DIR", "") or "").strip().strip('"')
    if library and "local" in sources:
        items = _scan_local_library(Path(library).expanduser())
        for clip_id, local_file in _match_local_by_words(
            list(processor.queries.values()), items, Path(library).expanduser()
        ).items():
            processor.queries[clip_id].local_file = local_file

    resolved: list[int] = []
    unresolved: set[int] = set()
    for p in stock_plans:
        clip_id = int(p["scene_id"])
        clip = next(c for c in montage["clips"] if int(c["id"]) == clip_id)
        preferred = str(p.get("preferred_source") or "").lower()
        primary = "local" if preferred == "local" and "local" in sources else sources[0]
        result = processor.process_clip(clip, primary, sources)
        if result.get("status") == "ok":
            resolved.append(clip_id)
        else:
            unresolved.add(clip_id)
            clip.pop("source", None)
    processor.write_credits()
    _save_montage(project, montage)
    return {
        "enabled": True,
        "sources": sources,
        "selected": len(stock_plans),
        "resolved": resolved,
        "unresolved": sorted(unresolved),
    }, unresolved


def materialize_visual_assets(
    *,
    project_dir: str | Path,
    plans: list[dict[str, Any]],
    fallback: str,
    provider: str | None = None,
    model: str | None = None,
    mock_assets: bool = False,
) -> dict[str, Any]:
    project = Path(project_dir).resolve()
    story = project / "visual_story"
    generated = project / "generated"
    generated.mkdir(parents=True, exist_ok=True)
    montage = _load_montage(project)
    plans_by_id = {int(plan["scene_id"]): plan for plan in plans}
    epf_summary: dict[str, Any] = {}

    if mock_assets:
        from PIL import Image, ImageDraw

        for plan in plans:
            clip_id = int(plan["scene_id"])
            target = generated / f"{clip_id:03d}.jpg"
            image = Image.new("RGB", (1280, 720), (26 + clip_id * 17 % 120, 48, 72))
            draw = ImageDraw.Draw(image)
            draw.text((40, 40), f"Visual Story clip {clip_id}", fill="white")
            image.save(target, quality=90)
            clip = montage["clips"][clip_id - 1]
            clip["source"] = "real_photo"
            clip["file"] = f"generated/{clip_id:03d}.jpg"
            clip["real_meta"] = {
                "archive": "mock",
                "title": plan.get("visual_intent", ""),
                "license": "test-only",
                "credit_text": "",
            }
        _save_montage(project, montage)
        summary = {
            "mode": "mock",
            "resolved": sorted(plans_by_id),
            "unresolved": [],
        }
        (story / "selection_manifest.json").write_text(
            json.dumps(summary, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return summary

    stock_summary, stock_unresolved = _run_stock_for_visual_story(
        project, plans, montage
    )
    youtube_plans = [
        plan for plan in plans
        if plan.get("visual_strategy") == "new_search"
        and str(plan.get("preferred_source") or "").lower() == "youtube"
    ]
    youtube_summary: dict[str, Any] = {
        "enabled": bool(getattr(config, "YOUTUBE_FOOTAGE_ENABLED", False)),
        "selected": len(youtube_plans),
        "resolved": [],
        "unresolved": [],
    }
    youtube_unresolved: set[int] = set()
    if youtube_plans and getattr(config, "YOUTUBE_FOOTAGE_ENABLED", False):
        try:
            from modules.clip_sources import apply_clip_source_delta
            from modules.youtube_stage import run_youtube_stage

            for plan in youtube_plans:
                clip_id = int(plan["scene_id"])
                apply_clip_source_delta(
                    project / "montage_plan.json",
                    {clip_id: {"source": "youtube_pending"}},
                    log=lambda message: logger.info("[visual-story/youtube] %s", message),
                )
            yt_result = run_youtube_stage(
                project,
                target_w=1920,
                target_h=1080,
                fps=getattr(config, "VIDEO_FPS", 60),
                deadline_ts=None,
            )
            youtube_summary.update(yt_result)
            youtube_summary["resolved"] = [
                int(plan["scene_id"])
                for plan in youtube_plans
                if (project / "vid_img" / f"{int(plan['scene_id']):03d}.mp4").exists()
            ]
            youtube_unresolved = {
                int(plan["scene_id"])
                for plan in youtube_plans
                if int(plan["scene_id"]) not in youtube_summary["resolved"]
            }
        except Exception as exc:
            logger.warning("Auto Visual Story YouTube failed: %s", exc)
            youtube_summary["error"] = str(exc)
            youtube_unresolved = {int(plan["scene_id"]) for plan in youtube_plans}
            for clip_id in youtube_unresolved:
                try:
                    from modules.clip_sources import apply_clip_source_delta
                    apply_clip_source_delta(
                        project / "montage_plan.json",
                        {clip_id: {"source": "real_photo_pending"}},
                        log=lambda message: logger.info("[visual-story/youtube] %s", message),
                    )
                except Exception:
                    pass
    elif youtube_plans:
        youtube_unresolved = {int(plan["scene_id"]) for plan in youtube_plans}
        for clip_id in youtube_unresolved:
            clip = montage["clips"][clip_id - 1]
            clip["source"] = "real_photo_pending"
        _save_montage(project, montage)

    search_plans = [
        plan for plan in plans
        if plan.get("visual_strategy") == "new_search"
        and (
            str(plan.get("preferred_source") or "").lower()
            not in {"stock", "local", "stock_photo", "stock_video", "youtube"}
            or int(plan["scene_id"]) in stock_unresolved
            or int(plan["scene_id"]) in youtube_unresolved
        )
        and _generated_asset(project, int(plan["scene_id"])) is None
    ]
    if search_plans:
        selections = [_clip_selection(plan) for plan in search_plans]
        try:
            from agent.tools.extreme_picture_finder_bridge import run_automatic_job
        except ImportError:
            from tools.extreme_picture_finder_bridge import run_automatic_job
        try:
            epf_summary = run_automatic_job(
                project,
                selections,
                provider=provider,
                model=model,
                timeout_sec=getattr(config, "VISUAL_STORY_EPF_TIMEOUT", 180),
                deadline_ts=time.time() + (
                    getattr(config, "VISUAL_STORY_EPF_TIMEOUT", 180)
                    * max(1, len(selections))
                ),
            )
        except Exception as exc:
            logger.warning("Auto Visual Story EPF failed: %s", exc)
            epf_summary = {"error": str(exc), "ingest": {"results": []}}
        montage = _load_montage(project)
        _apply_epf_metadata(montage, plans_by_id, epf_summary)
        _save_montage(project, montage)

    unresolved_new = [
        plan for plan in search_plans
        if _generated_asset(project, int(plan["scene_id"])) is None
    ]
    archive_summary: dict[str, Any] = {}
    if unresolved_new and fallback in {"archive", "reuse_previous"}:
        archive_summary = _run_archive_fallback(project, unresolved_new)

    montage = _load_montage(project)
    unresolved: list[dict[str, Any]] = []
    for plan in plans:
        clip_id = int(plan["scene_id"])
        clip = montage["clips"][clip_id - 1]
        if plan.get("visual_strategy") == "reuse_previous":
            reuse_id = int(plan.get("reuse_clip_id") or clip_id - 1)
            try:
                target = _copy_reused_asset(project, reuse_id, clip_id)
                previous = montage["clips"][reuse_id - 1]
                clip["source"] = previous.get("source") or "real_photo"
                clip["file"] = f"generated/{target.name}"
                if previous.get("real_meta"):
                    clip["real_meta"] = dict(previous["real_meta"])
                clip["visual_story"]["reuse_clip_id"] = reuse_id
            except Exception as exc:
                unresolved.append({"clip_id": clip_id, "error": str(exc)})
        elif _generated_asset(project, clip_id) is None:
            if (
                str(clip.get("source") or "") in {"youtube", "youtube_video"}
                and (project / "vid_img" / f"{clip_id:03d}.mp4").exists()
            ):
                clip["file"] = f"vid_img/{clip_id:03d}.mp4"
                continue
            if fallback == "reuse_previous" and clip_id > 1:
                try:
                    target = _copy_reused_asset(project, clip_id - 1, clip_id)
                    previous = montage["clips"][clip_id - 2]
                    clip["source"] = previous.get("source") or "real_photo"
                    clip["file"] = f"generated/{target.name}"
                    if previous.get("real_meta"):
                        clip["real_meta"] = dict(previous["real_meta"])
                    clip["visual_story"]["fallback"] = "reuse_previous"
                    continue
                except Exception:
                    pass
            unresolved.append({
                "clip_id": clip_id,
                "query": plan.get("search_query", ""),
                "error": "No EPF or archive asset was materialized",
            })
        else:
            asset = _generated_asset(project, clip_id)
            clip["file"] = f"generated/{asset.name}"
            if str(clip.get("source") or "").endswith("_pending"):
                clip["source"] = "real_photo"

    _save_montage(project, montage)
    resolved = [
        int(plan["scene_id"])
        for plan in plans
        if _generated_asset(project, int(plan["scene_id"])) is not None
    ]
    summary = {
        "mode": "live",
        "fallback": fallback,
        "resolved": resolved,
        "unresolved": unresolved,
        "stock": stock_summary,
        "youtube": youtube_summary,
        "epf": epf_summary,
        "archive": archive_summary,
    }
    (story / "selection_manifest.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (story / "unresolved.json").write_text(
        json.dumps({"items": unresolved}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return summary
