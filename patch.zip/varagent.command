#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
chmod +x "$SCRIPT_DIR"/*.command 2>/dev/null

# Открываем в новом окне терминала если запущено двойным кликом
if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e 'tell app "Terminal" to do script "cd '\'''"$SCRIPT_DIR"'\'' && bash '\'''"$SCRIPT_DIR/varagent.command"'\'' ; exit"'
    exit 0
fi

cd "$SCRIPT_DIR"

# Проверяем tkinter
python3 -c "import tkinter" 2>/dev/null
if [ $? -ne 0 ]; then
    echo ""
    echo "[ERROR] tkinter not found."
    echo "Install: brew install python-tk"
    echo ""
    read -p "Press Enter to exit..."
    exit 1
fi

# Авто-установка недостающих пакетов
python3 -c "import requests" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "[INFO] Installing missing packages..."
    python3 -m pip install requests python-dotenv tqdm colorama 2>/dev/null || pip3 install requests python-dotenv tqdm colorama
fi

python3 "$SCRIPT_DIR/varagent.py" "$@"

if [ $? -ne 0 ]; then
    echo ""
    echo "[ERROR] VarAgent exited with error."
    read -p "Press Enter to exit..."
fi
