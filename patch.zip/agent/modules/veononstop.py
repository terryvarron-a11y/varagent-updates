"""
VeoNonStop API Client — видеогенерация и генерация изображений.

Эндпоинты:
  Видео:
    POST /video/image-to-video     — оживление картинки
    POST /video/text-to-video      — видео из текста
    POST /video/multi-image-to-video — видео из текста + несколько референсных картинок
  Картинки:
    POST /image/generate           — Imagen 3.5 (text-to-image)
    POST /image/banana/generate    — Banana Pro (text-to-image + optional style refs)
    POST /image/banana/upscale     — Upscale до 4K
  Статус/Download:
    GET  /video/status/:taskId
    GET  /image/status/:taskId
    GET  /video/download/:taskId?video_index=0

Документация: https://veononstop.org/api-docs.html
"""

import sys
import base64
import subprocess
import time
import logging
import requests
from pathlib import Path
from typing import Optional, Dict, List, Any


def _verify_video_integrity(path: Path) -> bool:
    """Быстрая проверка скачанного видеофайла через ffprobe.
    Возвращает True если файл валиден (есть видео-стрим и положительная длительность).
    Нужно потому что download может завершиться "успешно" (write без exception),
    но payload оказаться truncated/corrupt — VEO cloud-relay иногда такое отдаёт.
    """
    try:
        if not path.exists() or path.stat().st_size < 1024:
            return False
        res = subprocess.run(
            ['ffprobe', '-v', 'error',
             '-select_streams', 'v:0',
             '-show_entries', 'stream=codec_type:format=duration',
             '-of', 'default=noprint_wrappers=1:nokey=1',
             str(path)],
            capture_output=True, text=True, timeout=15,
        )
        out = (res.stdout or '').strip().splitlines()
        # Ожидаем как минимум codec_type=video и duration > 0
        has_video = any(line.strip() == 'video' for line in out)
        dur = 0.0
        for line in out:
            line = line.strip()
            try:
                dur = max(dur, float(line))
            except ValueError:
                continue
        return has_video and dur > 0.0
    except Exception:
        return False

# Ensure agent/ dir is on sys.path (config.py lives there)
_agent_dir = str(Path(__file__).resolve().parent.parent)
if _agent_dir not in sys.path:
    sys.path.insert(0, _agent_dir)

import config

# Поддерживаемые форматы изображений
IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.webp'}

# MIME-типы по расширению
MIME_TYPES = {
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.webp': 'image/webp',
}


class BananaResult(str):
    """str subclass carrying upscale metadata. str(result) == path."""
    def __new__(cls, path: str, media_id: str = '', project_id: str = ''):
        obj = str.__new__(cls, path)
        obj.media_id = media_id
        obj.project_id = project_id
        return obj


class VeoNonStopError(Exception):
    """Базовая ошибка VeoNonStop API"""
    pass


class VeoNonStopTimeoutError(VeoNonStopError):
    """Таймаут ожидания задачи"""
    pass


class VeoNonStopGenerationError(VeoNonStopError):
    """Задача завершилась с ошибкой"""
    pass


class VeoNonStopRateLimitError(VeoNonStopError):
    """429 — превышен лимит запросов"""
    pass


class VeoNonStopTokenExpiredError(VeoNonStopError):
    """TOKEN_EXPIRED — временная ошибка авторизации на стороне сервера"""
    pass


class VeoNonStopHungError(VeoNonStopError):
    """Task stuck in session_init/uploading > hung_timeout seconds"""
    pass


def _image_to_base64(image_path: str) -> tuple:
    """
    Читает изображение и возвращает (base64_string, mime_type).
    API поддерживает JPEG, PNG, WebP — отправляем в оригинальном формате
    без конвертации, чтобы минимизировать размер тела запроса.
    (JPEG ~1MB vs PNG ~5-8MB → write timeout при больших PNG)
    """
    path = Path(image_path)
    if not path.exists():
        raise FileNotFoundError(f"Image not found: {image_path}")

    mime = MIME_TYPES.get(path.suffix.lower(), 'image/png')
    with open(path, 'rb') as f:
        b64 = base64.b64encode(f.read()).decode('utf-8')
    return b64, mime


def _load_ref_images(ref_dir: str) -> List[Dict[str, str]]:
    """
    Загружает все изображения из папки ref/ как массив
    [{image_base64, mime_type}, ...] для multi-image-to-video и banana.
    Форматы не конвертируются — отправляются как есть (JPEG, PNG, WebP).
    """
    ref_path = Path(ref_dir)
    if not ref_path.exists():
        return []

    images = []
    for f in sorted(ref_path.iterdir(), key=lambda p: p.name.lower()):
        if f.is_file() and f.suffix.lower() in IMAGE_EXTENSIONS:
            b64, mime = _image_to_base64(str(f))
            images.append({'name': f.stem, 'image_base64': b64, 'mime_type': mime})
    return images


class VeoNonStopClient:
    """Клиент VeoNonStop API"""

    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        self.api_key = api_key or config.VEONONSTOP_API_KEY
        self.base_url = base_url or config.VEONONSTOP_API_BASE
        self.headers = {
            'X-API-Key': self.api_key,
            'Content-Type': 'application/json',
        }
        # For localhost desk backend: bypass system proxy (HTTPS_PROXY env breaks 127.0.0.1)
        is_local = ('localhost' in self.base_url) or ('127.0.0.1' in self.base_url)
        self.proxies = {'http': None, 'https': None} if is_local else None
        if not self.api_key:
            raise ValueError("VEONONSTOP_API_KEY not set in .env")

    # ==================================================================
    # Видео: submit
    # ==================================================================

    def submit_image_to_video(
        self,
        image_path: str,
        prompt: str,
        aspect_ratio: Optional[str] = None,
        count: int = 1,
    ) -> str:
        """
        Оживить картинку → видео (image-to-video).

        Returns:
            taskId для поллинга
        """
        b64, mime = _image_to_base64(image_path)
        body = {
            'prompt': prompt,
            'image_base64': b64,
            'mime_type': mime,
            'aspect_ratio': aspect_ratio or config.VEONONSTOP_ASPECT_RATIO,
            'count': count,
        }
        return self._submit('/video/image-to-video', body)

    def submit_text_to_video(
        self,
        prompt: str,
        aspect_ratio: Optional[str] = None,
        count: int = 1,
    ) -> str:
        """
        Видео из текста (text-to-video).

        Returns:
            taskId для поллинга
        """
        body = {
            'prompt': prompt,
            'aspect_ratio': aspect_ratio or config.VEONONSTOP_ASPECT_RATIO,
            'count': count,
        }
        return self._submit('/video/text-to-video', body)

    def submit_multi_image_to_video(
        self,
        image_paths: List[str],
        prompt: str,
        aspect_ratio: Optional[str] = None,
        count: int = 1,
    ) -> str:
        """
        Видео из текста + референсные картинки (components).

        Args:
            image_paths: Список путей к изображениям-референсам
            prompt: Текстовый промпт
        Returns:
            taskId для поллинга
        """
        images = []
        for p in image_paths:
            b64, mime = _image_to_base64(p)
            images.append({'name': Path(p).stem, 'image_base64': b64, 'mime_type': mime})

        body = {
            'prompt': prompt,
            'images': images,
            'aspect_ratio': aspect_ratio or config.VEONONSTOP_ASPECT_RATIO,
            'count': count,
        }
        return self._submit('/video/multi-image-to-video', body)

    def submit_multi_image_to_video_from_ref_dir(
        self,
        ref_dir: str,
        prompt: str,
        aspect_ratio: Optional[str] = None,
        count: int = 1,
    ) -> str:
        """
        Components: загружает все картинки из ref/ и шлёт multi-image-to-video.
        """
        images = _load_ref_images(ref_dir)
        if not images:
            raise FileNotFoundError(f"No reference images found in {ref_dir}")

        body = {
            'prompt': prompt,
            'images': images,
            'aspect_ratio': aspect_ratio or config.VEONONSTOP_ASPECT_RATIO,
            'count': count,
        }
        return self._submit('/video/multi-image-to-video', body)

    def submit_batch_frame(
        self,
        start_image_path: str,
        end_image_path: str,
        prompt: str,
        aspect_ratio: Optional[str] = None,
        count: int = 1,
    ) -> str:
        """
        Batch-frame: переход между двумя кадрами (start → end).
        POST /video/batch-frame

        Returns:
            taskId для поллинга
        """
        start_b64, _ = _image_to_base64(start_image_path)
        end_b64, _ = _image_to_base64(end_image_path)
        body = {
            'prompt': prompt,
            'start_image_base64': start_b64,
            'end_image_base64': end_b64,
            'aspect_ratio': aspect_ratio or config.VEONONSTOP_ASPECT_RATIO,
            'count': count,
        }
        return self._submit('/video/batch-frame', body)

    def submit_upsample_video(
        self,
        media_generation_id: str,
        aspect_ratio: Optional[str] = None,
    ) -> str:
        """
        Upsample (upscale) видео.
        POST /video/upsample

        Args:
            media_generation_id: из completed video result (videos[].mediaGenerationId)
        Returns:
            taskId для поллинга
        """
        body = {
            'media_generation_id': media_generation_id,
            'aspect_ratio': aspect_ratio or config.VEONONSTOP_ASPECT_RATIO,
        }
        return self._submit('/video/upsample', body)

    # ==================================================================
    # Картинки: submit
    # ==================================================================

    def submit_imagen(
        self,
        prompt: str,
        aspect_ratio: Optional[str] = None,
    ) -> str:
        """
        Imagen 3.5 text-to-image (синхронный API).

        Returns:
            mediaGenerationId
        """
        body = {
            'prompt': prompt,
            'aspect_ratio': aspect_ratio or config.VEONONSTOP_ASPECT_RATIO,
        }
        return self._submit('/image/generate', body)

    def generate_imagen(
        self,
        prompt: str,
        output_path: str,
        aspect_ratio: Optional[str] = None,
    ) -> str:
        """
        Imagen 3.5 — /image/generate возвращает только mediaGenerationId без URL.
        По доке VeoNonStop: для получения изображения нужно использовать Banana.
        Fallback: вызываем generate_banana с model_key по умолчанию.

        Returns:
            путь к сохранённому файлу
        """
        logging.info("generate_imagen: /image/generate не возвращает URL, fallback на banana")
        return self.generate_banana(
            prompt=prompt,
            output_path=output_path,
            aspect_ratio=aspect_ratio,
        )

    def submit_banana(
        self,
        prompt: str,
        aspect_ratio: Optional[str] = None,
        num_images: int = 1,
        model_key: Optional[str] = None,
        reference_images: Optional[List[Dict[str, str]]] = None,
    ) -> str:
        """
        Banana Pro text-to-image (+ optional style references).

        Args:
            reference_images: [{image_base64, mime_type}, ...] для стиль-трансфера
        Returns:
            taskId для поллинга
        """
        body = {
            'prompt': prompt,
            'aspect_ratio': aspect_ratio or config.VEONONSTOP_ASPECT_RATIO,
            'num_images': num_images,
            'model_key': model_key or config.VEONONSTOP_BANANA_MODEL,
        }
        if reference_images:
            body['reference_images'] = reference_images
        return self._submit('/image/banana/generate', body)

    def generate_banana(
        self,
        prompt: str,
        output_path: str,
        aspect_ratio: Optional[str] = None,
        num_images: int = 1,
        model_key: Optional[str] = None,
        reference_images: Optional[List[Dict[str, str]]] = None,
        use_all_ref_images: bool = False,
    ) -> str:
        """
        Banana Pro — синхронная генерация + скачивание.
        API возвращает media[].fifeUrl прямо в ответе.

        Returns:
            путь к сохранённому файлу
        """
        body = {
            'prompt': prompt,
            'aspect_ratio': aspect_ratio or config.VEONONSTOP_ASPECT_RATIO,
            'num_images': num_images,
            'model_key': model_key or config.VEONONSTOP_BANANA_MODEL,
        }
        if reference_images:
            body['reference_images'] = reference_images
            if use_all_ref_images:
                body['use_all_ref_images'] = True

        logging.info(
            f"generate_banana: prompt={prompt[:60]!r}  refs={len(reference_images) if reference_images else 0}"
            f"  use_all_ref_images={use_all_ref_images}"
            f"  model={body['model_key']}  aspect={body['aspect_ratio']}"
        )

        url = f"{self.base_url}/image/banana/generate"
        resp = requests.post(url, headers=self.headers, proxies=self.proxies, json=body, timeout=300)

        if resp.status_code not in (200, 201) and 'TOKEN_EXPIRED' in resp.text:
            raise VeoNonStopTokenExpiredError(f"Token expired: {resp.text}")
        if resp.status_code == 429 or (resp.status_code not in (200, 201) and 'RATE_LIMIT' in resp.text):
            raise VeoNonStopRateLimitError(f"Rate limit exceeded (429): {resp.text[:300]}")
        if resp.status_code >= 500:
            raise VeoNonStopTimeoutError(
                f"Server error ({resp.status_code}): {resp.text}"
            )
        if resp.status_code not in (200, 201):
            raise VeoNonStopError(
                f"Submit /image/banana/generate failed ({resp.status_code}): {resp.text}"
            )

        resp_json = resp.json()
        data = resp_json.get('data', resp_json) if isinstance(resp_json.get('data'), dict) else resp_json

        # Сохраняем project_id для upscale и matched_references для дебага
        self._last_project_id = data.get('project_id')
        matched = data.get('matched_references')
        if matched is not None:
            matched_count = matched if isinstance(matched, int) else len(matched)
            logging.info(f"Banana matched_references ({matched_count} refs matched by server): {matched}")
        elif reference_images:
            logging.warning("Banana matched_references: absent in response (refs may not have been applied)")

        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)

        _proj_id = self._last_project_id or ''

        # Banana returns media[] with fifeUrl
        media = data.get('media', [])
        if media and isinstance(media, list):
            item = media[0]
            _mid = item.get('mediaGenerationId', '')
            fife_url = item.get('fifeUrl') or item.get('url') or item.get('image_url')
            if fife_url:
                self._download_url(fife_url, out)
                logging.info(f"Banana generated -> {output_path}")
                return BananaResult(str(out), media_id=_mid, project_id=_proj_id)
            if _mid:
                # Fallback: poll + download
                self.poll_image_status(_mid)
                self.download_image(_mid, str(out))
                logging.info(f"Banana generated (polled) -> {output_path}")
                return BananaResult(str(out), media_id=_mid, project_id=_proj_id)

        # Fallback: try old flow
        task_id = data.get('mediaGenerationId') or data.get('taskId') or data.get('task_id')
        if task_id:
            self.poll_image_status(task_id)
            self.download_image(task_id, str(out))
            logging.info(f"Banana generated (polled fallback) -> {output_path}")
            return BananaResult(str(out), media_id=task_id, project_id=_proj_id)

        raise VeoNonStopError(f"Cannot extract image from banana response: {resp_json}")

    def submit_banana_with_refs(
        self,
        prompt: str,
        ref_dir: str,
        aspect_ratio: Optional[str] = None,
        num_images: int = 1,
        model_key: Optional[str] = None,
    ) -> str:
        """Banana Pro + загрузка reference_images из папки ref/."""
        refs = _load_ref_images(ref_dir)
        return self.submit_banana(
            prompt=prompt,
            aspect_ratio=aspect_ratio,
            num_images=num_images,
            model_key=model_key,
            reference_images=refs or None,
        )

    def upscale_banana(
        self,
        media_id: str,
        project_id: str,
        output_path: str,
        target_resolution: str = None,
    ) -> str:
        """
        Upscale изображения через Banana.
        POST /image/banana/upscale

        target_resolution: UPSAMPLE_IMAGE_RESOLUTION_2K (default) | UPSAMPLE_IMAGE_RESOLUTION_4K

        Returns:
            путь к сохранённому файлу
        """
        body = {
            'media_id': media_id,
            'project_id': project_id,
        }
        if target_resolution:
            body['target_resolution'] = target_resolution
        url = f"{self.base_url}/image/banana/upscale"
        resp = requests.post(url, headers=self.headers, proxies=self.proxies, json=body, timeout=120)

        if resp.status_code not in (200, 201) and 'TOKEN_EXPIRED' in resp.text:
            raise VeoNonStopTokenExpiredError(f"Token expired: {resp.text}")
        if resp.status_code == 429 or (resp.status_code not in (200, 201) and 'RATE_LIMIT' in resp.text):
            raise VeoNonStopRateLimitError(f"Rate limit exceeded (429): {resp.text[:300]}")
        if resp.status_code not in (200, 201):
            raise VeoNonStopError(
                f"Upscale failed ({resp.status_code}): {resp.text[:200]}"
            )

        resp_json = resp.json()
        data = resp_json.get('data', resp_json) if isinstance(resp_json.get('data'), dict) else resp_json
        encoded = data.get('encodedImage')
        if not encoded:
            raise VeoNonStopError(f"No encodedImage in upscale response: {resp_json}")

        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        with open(out, 'wb') as f:
            f.write(base64.b64decode(encoded))

        logging.info(f"Upscaled {media_id} -> {output_path}")
        return str(out)

    # ==================================================================
    # Общее: submit / poll / download
    # ==================================================================

    def _submit(self, endpoint: str, body: dict) -> str:
        """Отправить POST-запрос и вернуть taskId."""
        url = f"{self.base_url}{endpoint}"
        # Таймаут (connect, read): 30s на подключение, 120s на передачу
        # base64-картинки могут быть несколько MB → write timeout при 60s
        resp = requests.post(url, headers=self.headers, proxies=self.proxies, json=body, timeout=(30, 120))

        if resp.status_code not in (200, 201) and 'TOKEN_EXPIRED' in resp.text:
            raise VeoNonStopTokenExpiredError(f"Token expired: {resp.text}")
        if resp.status_code == 429 or (resp.status_code not in (200, 201) and 'RATE_LIMIT' in resp.text):
            raise VeoNonStopRateLimitError(f"Rate limit exceeded (429): {resp.text[:300]}")
        if resp.status_code not in (200, 201):
            raise VeoNonStopError(
                f"Submit {endpoint} failed ({resp.status_code}): {resp.text}"
            )

        resp_json = resp.json()
        # API may return {"success": true, "data": {"task_id": "..."}} or flat {"taskId": "..."}
        data = resp_json.get('data', resp_json) if isinstance(resp_json.get('data'), dict) else resp_json
        task_id = data.get('taskId') or data.get('task_id') or data.get('id') or data.get('mediaGenerationId')
        if not task_id:
            raise VeoNonStopError(f"No taskId in response: {resp_json}")

        logging.info(f"VeoNonStop submitted {endpoint} -> taskId={task_id}")
        return task_id

    def poll_video_status(
        self,
        task_id: str,
        timeout: Optional[int] = None,
        interval: Optional[int] = None,
        hung_timeout: int = 120,
    ) -> dict:
        """
        Поллить статус видеозадачи до завершения.

        Returns:
            Полный ответ API при completed
        Raises:
            VeoNonStopTimeoutError, VeoNonStopGenerationError, VeoNonStopHungError
        """
        return self._poll(f'/video/status/{task_id}', task_id, timeout, interval, hung_timeout=hung_timeout)

    def poll_image_status(
        self,
        task_id: str,
        timeout: Optional[int] = None,
        interval: Optional[int] = None,
        verbose: bool = False,
    ) -> dict:
        """Поллить статус задачи генерации изображения.
        verbose=True — печатать каждую смену статуса (для preflight-этапов в GUI)."""
        return self._poll(f'/image/status/{task_id}', task_id, timeout, interval, verbose=verbose)

    def _poll(
        self,
        endpoint: str,
        task_id: str,
        timeout: Optional[int] = None,
        interval: Optional[int] = None,
        hung_timeout: int = 120,
        verbose: bool = False,
    ) -> dict:
        """Общий метод поллинга."""
        timeout = timeout or config.VEONONSTOP_POLL_TIMEOUT
        interval = interval or config.VEONONSTOP_POLL_INTERVAL
        url = f"{self.base_url}{endpoint}"
        deadline = time.time() + timeout

        # Hung detection: track time spent in session_init/uploading
        _hung_state: Optional[str] = None
        _hung_since: float = 0.0
        _consecutive_404 = 0
        _last_verbose_status: Optional[str] = None  # для verbose — печатаем только смены статуса

        def _is_module_shutdown() -> bool:
            """Возвращает True если любой из верхнеуровневых модулей запросил shutdown.
            Lazy import'ы — избегаем circular dependency."""
            try:
                import veo_video as _vv
                if getattr(_vv, '_shutdown_requested', None) and _vv._shutdown_requested.is_set():
                    return True
            except Exception:
                pass
            try:
                import imggen as _ig
                if getattr(_ig, '_shutdown_event', None) and _ig._shutdown_event.is_set():
                    return True
            except Exception:
                pass
            try:
                import fastgen as _fg
                if getattr(_fg, '_flowultra_shutdown_event', None) and _fg._flowultra_shutdown_event.is_set():
                    return True
            except Exception:
                pass
            return False

        while time.time() < deadline:
            # Shutdown check — чтобы Stop/Hard Stop реально обрывал зависшие pollers.
            if _is_module_shutdown():
                raise VeoNonStopGenerationError(f"Task {task_id} polling aborted — shutdown requested")
            try:
                resp = requests.get(url, headers=self.headers, proxies=self.proxies, timeout=30)
            except requests.RequestException as e:
                logging.warning(f"Poll {task_id}: network error — {e}")
                if verbose:
                    print(f"  [POLL {task_id[:10]}] network error: {str(e)[:80]}", flush=True)
                time.sleep(interval)
                continue

            if resp.status_code == 404:
                _consecutive_404 += 1
                logging.warning(f"Poll {task_id}: HTTP 404 ({_consecutive_404}/3)")
                if verbose:
                    print(f"  [POLL {task_id[:10]}] HTTP 404 ({_consecutive_404}/3)", flush=True)
                if _consecutive_404 >= 3:
                    raise VeoNonStopGenerationError(
                        f"Task {task_id} lost — 3x HTTP 404 (server dropped the task)")
                time.sleep(10)
                continue
            _consecutive_404 = 0  # reset on any non-404 response

            if resp.status_code != 200:
                logging.warning(f"Poll {task_id}: HTTP {resp.status_code}")
                if verbose:
                    print(f"  [POLL {task_id[:10]}] HTTP {resp.status_code}", flush=True)
                time.sleep(interval)
                continue

            resp_json = resp.json()
            # Handle nested {"success": true, "data": {...}} or flat {...}
            data = resp_json.get('data', resp_json) if isinstance(resp_json.get('data'), dict) else resp_json
            status = (data.get('status') or '').lower()

            if verbose and status != _last_verbose_status:
                _el = int(time.time() - (deadline - timeout))
                print(f"  [POLL {task_id[:10]}] status={status or 'unknown'} ({_el}s)", flush=True)
                _last_verbose_status = status

            if status == 'completed':
                return data
            elif status in ('failed', 'error', 'cancelled'):
                error_msg = data.get('error') or data.get('message') or 'Unknown error'
                raise VeoNonStopGenerationError(
                    f"Task {task_id} failed: {error_msg}"
                )
            elif status == 'queued':
                if _hung_state != 'queued':
                    logging.info(f"Task {task_id}: queued (waiting for server slot)...")
                    _hung_state = 'queued'
            elif status in ('session_init', 'uploading'):
                if _hung_state != status:
                    _hung_state = status
                    _hung_since = time.time()
                    logging.info(f"Task {task_id}: {status}")
                elif time.time() - _hung_since > hung_timeout:
                    raise VeoNonStopHungError(
                        f"Task {task_id} hung in '{status}' for >{hung_timeout}s"
                    )
            else:
                # generating / polling / pending — reset hung tracker
                _hung_state = None

                # показываем прогресс если есть (только для count>1)
                progress = data.get('progress')
                if progress and isinstance(progress, dict):
                    total = progress.get('total', 0)
                    completed_cnt = progress.get('completed', 0)
                    if total > 1:
                        pct = int(completed_cnt / total * 100)
                        print(f"    task {task_id[:8]}... {status} [{completed_cnt}/{total}] {pct}%")
                        logging.info(f"Task {task_id}: {status} [{completed_cnt}/{total}]")

            time.sleep(interval)

        raise VeoNonStopTimeoutError(
            f"Task {task_id} timed out after {timeout}s"
        )

    def download_video(
        self,
        task_id: str,
        output_path: str,
        video_index: int = 0,
    ) -> str:
        """
        Скачать готовое видео по taskId.

        Internal retry (up to 3 attempts with backoff 5/10/20s): когда upstream
        Google → cloud-relay → us stream обрывается/таймаутит, часто помогает подождать
        и запросить повторно — Google к тому времени уже успевает дофинализировать видео.
        На наших плечах сэкономлено: не пересоздавать задачу из-за проблем со скачкой.

        Returns:
            Путь к сохранённому файлу
        """
        url = f"{self.base_url}/video/download/{task_id}"
        params = {'video_index': video_index}
        _backoffs = [5, 10, 20]  # retry after Nth fail: wait 5/10/20s before re-try
        _last_err: Optional[Exception] = None
        _integrity_retried = False  # один перескач при broken-bitstream, потом raise → resubmit

        for _att in range(1, 4):
            try:
                # connect=30s (fast fail on dead host), read=300s (tolerate slow streaming
                # from upstream Google → veononstop.org cloud relay → us).
                resp = requests.get(url, headers=self.headers, proxies=self.proxies, params=params,
                                    timeout=(30, 300), stream=True)
                if resp.status_code != 200:
                    # 5xx / stream-aborted: retry; 4xx: fail fast
                    if resp.status_code >= 500 and _att < 3:
                        _delay = _backoffs[_att - 1]
                        logging.warning(
                            f"Download video {task_id} attempt {_att}/3: HTTP {resp.status_code} "
                            f"{resp.text[:120]} — retry in {_delay}s"
                        )
                        time.sleep(_delay)
                        continue
                    raise VeoNonStopError(
                        f"Download video {task_id} failed ({resp.status_code}): {resp.text[:200]}"
                    )

                out = Path(output_path)
                out.parent.mkdir(parents=True, exist_ok=True)
                try:
                    with open(out, 'wb') as f:
                        for chunk in resp.iter_content(chunk_size=8192):
                            if chunk:
                                f.write(chunk)
                except (requests.exceptions.ChunkedEncodingError,
                        requests.exceptions.ConnectionError,
                        requests.exceptions.ReadTimeout) as _se:
                    # Stream broke mid-download — remove partial + retry
                    try:
                        out.unlink(missing_ok=True)
                    except Exception:
                        pass
                    if _att < 3:
                        _delay = _backoffs[_att - 1]
                        logging.warning(
                            f"Download video {task_id} attempt {_att}/3: stream broken ({_se.__class__.__name__}) "
                            f"— retry in {_delay}s"
                        )
                        time.sleep(_delay)
                        _last_err = _se
                        continue
                    raise VeoNonStopError(
                        f"Download video {task_id} failed: stream broken after 3 attempts: {_se}"
                    )
                # Integrity check: ffprobe должен вернуть duration > 0 и хотя бы один видеострим.
                # Даже успешно "скачавшиеся" файлы бывают побитыми на уровне bitstream'а
                # (VEO/cloud-relay иногда отдаёт truncated payload, который пишется без stream-exception).
                # Политика: один перескач того же task_id, и если опять битый — raise, пусть
                # вызывающий (veo_video.py) делает resubmit новой генерации.
                if not _verify_video_integrity(out):
                    try:
                        out.unlink(missing_ok=True)
                    except Exception:
                        pass
                    if not _integrity_retried:
                        _integrity_retried = True
                        logging.warning(
                            f"Download video {task_id}: integrity check failed "
                            f"(ffprobe empty/invalid) — one re-download in 5s"
                        )
                        time.sleep(5)
                        _last_err = VeoNonStopError("downloaded file failed ffprobe integrity check")
                        continue
                    raise VeoNonStopError(
                        f"Download video {task_id} failed integrity check after re-download"
                    )
                # Successful download
                break
            except VeoNonStopError:
                raise
            except requests.exceptions.RequestException as _re:
                if _att < 3:
                    _delay = _backoffs[_att - 1]
                    logging.warning(
                        f"Download video {task_id} attempt {_att}/3: {_re.__class__.__name__} "
                        f"{str(_re)[:120]} — retry in {_delay}s"
                    )
                    time.sleep(_delay)
                    _last_err = _re
                    continue
                raise VeoNonStopError(f"Download video {task_id} failed after 3 attempts: {_re}")

        logging.info(f"Downloaded video {task_id} -> {output_path}")
        return str(out)

    def download_image(
        self,
        task_id: str,
        output_path: str,
    ) -> str:
        """
        Скачать сгенерированное изображение по taskId.
        Ответ API содержит base64 или прямую ссылку — обрабатываем оба варианта.

        Returns:
            Путь к сохранённому файлу
        """
        # Сначала получаем статус (в нём будет result с картинкой)
        status = self.poll_image_status(task_id, timeout=10, interval=2)
        result = status.get('result') or status.get('images') or status.get('output')

        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)

        if isinstance(result, list) and result:
            item = result[0]
            # Может быть base64 строка или URL
            if isinstance(item, str):
                if item.startswith('data:') or not item.startswith('http'):
                    # base64
                    b64 = item.split(',', 1)[-1] if ',' in item else item
                    with open(out, 'wb') as f:
                        f.write(base64.b64decode(b64))
                else:
                    # URL — скачиваем
                    self._download_url(item, out)
            elif isinstance(item, dict):
                url = item.get('url') or item.get('image_url')
                b64 = item.get('image_base64') or item.get('base64')
                if b64:
                    with open(out, 'wb') as f:
                        f.write(base64.b64decode(b64))
                elif url:
                    self._download_url(url, out)
                else:
                    raise VeoNonStopError(f"Cannot extract image from result item: {item}")
        elif isinstance(result, str):
            if result.startswith('http'):
                self._download_url(result, out)
            else:
                b64 = result.split(',', 1)[-1] if ',' in result else result
                with open(out, 'wb') as f:
                    f.write(base64.b64decode(b64))
        else:
            raise VeoNonStopError(f"Unexpected image result format: {type(result)} — {status}")

        logging.info(f"Downloaded image {task_id} -> {output_path}")
        return str(out)

    def cancel_task(self, task_id: str) -> bool:
        """
        Отменить задачу и немедленно освободить слот.
        POST /video/cancel/:taskId

        Работает для статусов: pending, queued, session_init, uploading, generating, polling.

        Returns:
            True если успешно отменено
        """
        url = f"{self.base_url}/video/cancel/{task_id}"
        try:
            resp = requests.post(url, headers=self.headers, proxies=self.proxies, timeout=15)
            if resp.status_code in (200, 201):
                logging.info(f"Task {task_id} cancelled successfully")
                return True
            logging.warning(f"Cancel task {task_id} failed ({resp.status_code}): {resp.text[:100]}")
            return False
        except Exception as e:
            logging.warning(f"Cancel task {task_id} error: {e}")
            return False

    def cancel_all_tasks(self) -> int:
        """
        POST /video/cancel-all — отменить ВСЕ активные задачи и освободить все слоты.
        Экстренный сброс зомби-тасков с прошлого прогона.

        Returns:
            Количество отменённых задач (0 если нет активных или ошибка)
        """
        url = f"{self.base_url}/video/cancel-all"
        try:
            resp = requests.post(url, headers=self.headers, proxies=self.proxies, timeout=15)
            if resp.status_code in (200, 201):
                data = resp.json().get('data', {})
                count = data.get('cancelled_count', 0)
                tasks = data.get('tasks', [])
                logging.warning(f"cancel-all: {count} tasks cancelled: {tasks}")
                return count
            logging.warning(f"cancel-all failed ({resp.status_code}): {resp.text[:100]}")
            return 0
        except Exception as e:
            logging.warning(f"cancel-all error: {e}")
            return 0

    def cancel_all_image_tasks(self) -> int:
        """
        POST /image/cancel-all — отменить ВСЕ активные задачи генерации изображений.
        Освобождает слоты banana/imagen занятые предыдущим прогоном.

        Returns:
            Количество отменённых задач (0 если нет активных или ошибка)
        """
        url = f"{self.base_url}/image/cancel-all"
        try:
            resp = requests.post(url, headers=self.headers, proxies=self.proxies, timeout=15)
            if resp.status_code in (200, 201):
                data = resp.json().get('data', {})
                count = data.get('cancelled_count', 0)
                tasks = data.get('tasks', [])
                logging.warning(f"image cancel-all: {count} tasks cancelled: {tasks}")
                return count
            logging.warning(f"image cancel-all failed ({resp.status_code}): {resp.text[:100]}")
            return 0
        except Exception as e:
            logging.warning(f"image cancel-all error: {e}")
            return 0

    def get_account_info(self) -> dict:
        """
        GET /account/info — информация об аккаунте.
        Возвращает: username, plan, max_cookies (concurrent tasks), expiration.
        """
        url = f"{self.base_url}/account/info"
        resp = requests.get(url, headers=self.headers, proxies=self.proxies, timeout=15)
        if resp.status_code != 200:
            raise VeoNonStopError(f"Account info failed ({resp.status_code}): {resp.text[:200]}")
        resp_json = resp.json()
        return resp_json.get('data', resp_json) if isinstance(resp_json.get('data'), dict) else resp_json

    def get_account_usage(self) -> dict:
        """GET /account/usage - real-time active/queued task counters."""
        url = f"{self.base_url}/account/usage"
        resp = requests.get(url, headers=self.headers, proxies=self.proxies, timeout=15)
        if resp.status_code != 200:
            raise VeoNonStopError(f"Account usage failed ({resp.status_code}): {resp.text[:200]}")
        resp_json = resp.json()
        return resp_json.get('data', resp_json) if isinstance(resp_json.get('data'), dict) else resp_json

    def _download_url(self, url: str, output_path: Path):
        """Скачать файл по URL."""
        # Bypass proxy for localhost downloads (desk backend)
        dl_proxies = {'http': None, 'https': None} if ('localhost' in url or '127.0.0.1' in url) else None
        resp = requests.get(url, timeout=120, stream=True, proxies=dl_proxies)
        if resp.status_code != 200:
            raise VeoNonStopError(f"Download URL failed ({resp.status_code}): {url}")
        with open(output_path, 'wb') as f:
            for chunk in resp.iter_content(chunk_size=8192):
                f.write(chunk)
