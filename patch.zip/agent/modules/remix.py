"""
kieai.py — Kie.ai Qwen image-edit ремиксер.

Standalone модуль (не зависит от FastGenClient).
Используется как основной ремиксер вместо Grok:
  - remix_ref_kieai()  — ref-remix (с даунскейлом до ~480p для экономии)
  - remix_i2v_kieai()  — i2v-remix (без даунскейла — качество важно для финального видео)
"""

import json
import logging
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

import requests

# Авто-установка Pillow (нужен для resize/сжатия рефов — используется обоими движками)
try:
    from PIL import Image as _pil_check  # noqa: F401
except ImportError:
    subprocess.run([sys.executable, '-m', 'pip', 'install', 'pillow', '-q'], check=False)

import config
from vision_checks import run_all_checks

# ──────────────────────────────────────────────────────────────────────────────
# Консольные цвета
# ──────────────────────────────────────────────────────────────────────────────
_YELLOW = '\033[33m'
_RED    = '\033[31m'
_GREEN  = '\033[32m'
_RESET  = '\033[0m'

# ──────────────────────────────────────────────────────────────────────────────
# Дефолтные промпты (если файл не найден)
# ──────────────────────────────────────────────────────────────────────────────
_DEFAULT_REF_REMIX = (
    "Remake this photo in graphic novel / comic book art style. "
    "Preserve the exact facial features, face structure and likeness precisely. "
    "Change only the art rendering style, not the face or identity."
)
_DEFAULT_I2V_REMIX = (
    "Same scene from a different camera angle. "
    "Use medium shot or wide shot. Avoid direct face close-up. "
    "Keep same lighting, mood and composition."
)


# ──────────────────────────────────────────────────────────────────────────────
# Вспомогательные функции
# ──────────────────────────────────────────────────────────────────────────────

def _load_prompt(filename: str, default: str) -> str:
    """Читает промпт из agent/prompts/{filename}. Fallback — default."""
    p = Path(__file__).parent.parent / 'prompts' / filename
    try:
        return p.read_text('utf-8').strip() if p.exists() else default
    except Exception:
        return default


def _resize_for_ref_remix(image_path: str) -> str:
    """
    Приводит короткую сторону к 512px (апскейл если < 512, даунскейл если > 512).
    512px — минимальное требование qwen/image-edit по каждой стороне;
    даунскейл до минимума снижает стоимость (Kie.ai тарифицирует по пикселям).
    Возвращает путь к temp-файлу или оригинал если короткая сторона уже == 512.
    Используется ТОЛЬКО для ref-remix, не для i2v.
    """
    try:
        from PIL import Image
        img = Image.open(image_path)
        w, h = img.size
        target = 512
        if min(w, h) == target:
            return image_path
        scale = target / min(w, h)
        new_size = (int(w * scale), int(h * scale))
        img_resized = img.resize(new_size, Image.LANCZOS)
        if img_resized.mode in ('RGBA', 'LA', 'P'):
            img_resized = img_resized.convert('RGB')
        tmp_path = Path(image_path).parent / (Path(image_path).stem + '_kieai_512p_tmp.jpg')
        img_resized.save(str(tmp_path), 'JPEG', quality=88)
        action = 'upscaled' if scale > 1 else 'downscaled'
        logging.info(f"kieai: {action} {Path(image_path).name} {w}x{h} -> {new_size[0]}x{new_size[1]}")
        return str(tmp_path)
    except ImportError:
        logging.warning("kieai: Pillow not installed — skipping resize, sending original size")
        return image_path
    except Exception as e:
        logging.warning(f"kieai: resize failed ({e}) — sending original")
        return image_path


def _upload_image(image_path: str) -> str:
    """
    Загружает локальный файл на Kie.ai CDN через stream upload (multipart/form-data).
    Возвращает публичный downloadUrl для использования в createTask.
    """
    ext = image_path.lower().rsplit('.', 1)[-1]
    mime = {
        'jpg': 'image/jpeg', 'jpeg': 'image/jpeg',
        'png': 'image/png', 'webp': 'image/webp',
    }.get(ext, 'image/jpeg')
    headers = {'Authorization': f'Bearer {config.KIE_AI_API_KEY}'}
    with open(image_path, 'rb') as f:
        r = requests.post(
            'https://kieai.redpandaai.co/api/file-stream-upload',
            files={'file': (Path(image_path).name, f, mime)},
            data={'uploadPath': 'remix-refs'},
            headers=headers,
            timeout=60,
        )
    logging.info(f"kieai upload: status={r.status_code} body={r.text[:300]}")
    r.raise_for_status()
    resp = r.json()
    if not resp.get('success'):
        raise RuntimeError(f"Kie.ai upload failed: {resp.get('msg')} (code={resp.get('code')})")
    url = resp['data']['downloadUrl']
    logging.info(f"kieai: uploaded {Path(image_path).name} -> {url}")
    return url


def _poll_task(task_id: str, timeout: int = 300) -> str:
    """Поллинг задачи Kie.ai до успеха, возвращает URL результирующего изображения."""
    headers = {'Authorization': f'Bearer {config.KIE_AI_API_KEY}'}
    deadline = time.time() + timeout
    while time.time() < deadline:
        r = requests.get(
            'https://api.kie.ai/api/v1/jobs/recordInfo',
            params={'taskId': task_id}, headers=headers, timeout=30,
        )
        r.raise_for_status()
        resp_body = r.json()
        d = resp_body.get('data', {})
        state = d.get('state', '')
        logging.info(f"kieai poll: taskId={task_id} state={state} raw={json.dumps(resp_body)[:400]}")
        if state == 'success':
            result_json = json.loads(d.get('resultJson', '{}'))
            urls = result_json.get('resultUrls', [])
            if not urls:
                raise RuntimeError(f"Kie.ai task {task_id}: success but no resultUrls in resultJson={d.get('resultJson','')[:200]}")
            return urls[0]
        if state == 'fail':
            raise RuntimeError(
                f"Kie.ai task {task_id} failed: {d.get('failMsg', 'unknown')} "
                f"(code={d.get('failCode', '')})"
            )
        time.sleep(5)
    raise RuntimeError(f"Kie.ai task {task_id} timed out after {timeout}s")


def _edit_image(image_path: str, prompt: str, image_size: str = 'landscape_16_9',
                guidance_scale: float = 5.0,
                num_inference_steps: int = 35) -> str:
    """
    Полный цикл: upload -> createTask (sync_mode=true) -> вернуть URL результата.
    Если сервер вернул taskId (async) — уходим в поллинг.
    image_size: preset для Kie.ai (square|square_hd|portrait_4_3|portrait_16_9|landscape_4_3|landscape_16_9).
    Дефолт kie.ai — landscape_4_3, поэтому передаём явно.
    guidance_scale: 5 — чуть выше дефолта (4) чтобы промпт доходил, но без потери реализма.
    num_inference_steps: 25 — дефолт API.
    """
    image_url = _upload_image(image_path)
    headers = {
        'Authorization': f'Bearer {config.KIE_AI_API_KEY}',
        'Content-Type': 'application/json',
    }
    body = {
        'model': 'qwen/image-edit',
        'input': {
            'prompt': prompt,
            'image_url': image_url,
            'image_size': image_size,
            'guidance_scale': guidance_scale,
            'num_inference_steps': num_inference_steps,
            'sync_mode': True,
        },
    }
    r = requests.post(
        'https://api.kie.ai/api/v1/jobs/createTask',
        json=body, headers=headers, timeout=120,
    )
    r.raise_for_status()
    resp = r.json()
    logging.info(f"kieai createTask: status={r.status_code} body={json.dumps(resp)[:500]}")

    # Сервер вернул ошибку в body (code != 200)
    if resp.get('code') and resp['code'] != 200:
        raise RuntimeError(f"Kie.ai createTask error: {resp.get('msg')} (code={resp['code']})")

    # Async: сервер вернул taskId — поллим
    task_id = resp.get('taskId') or (resp.get('data') or {}).get('taskId')
    if task_id:
        logging.info(f"kieai: async task {task_id}, polling...")
        return _poll_task(task_id)

    # sync_mode: результат инлайн
    urls = (resp.get('data') or {}).get('resultUrls') or []
    if urls:
        return urls[0]

    raise RuntimeError(f"Kie.ai: unexpected response format: {json.dumps(resp)[:400]}")


def _save_remix_log(log_path: str, image_name: str, flags: dict,
                    prompt: str, output_path: str, error: str = None) -> None:
    """Дописывает запись о ремиксе в remix_debug.log проекта."""
    try:
        import datetime
        ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        with open(log_path, 'a', encoding='utf-8') as f:
            f.write(f"\n{'=' * 60}\n")
            f.write(f"[{ts}] {image_name}\n")
            if flags:
                for k, v in flags.items():
                    f.write(f"{k}: {'YES' if v else 'NO'}\n")
            else:
                f.write("flags: none\n")
            f.write(f"Prompt: {prompt}\n")
            if error:
                f.write(f"Result: FAIL — {error}\n")
            else:
                f.write(f"Result: OK -> {Path(output_path).name}\n")
    except Exception as _e:
        logging.debug(f"kieai: remix log write failed: {_e}")


_MAX_REF_BYTES = 2 * 1024 * 1024  # 2 MB — лимит для загрузки в FastGen Storage


def _compress_to_max_size(path: Path, max_bytes: int = _MAX_REF_BYTES) -> None:
    """Если файл > max_bytes — пережимает JPEG с понижением quality до вписывания в лимит."""
    if path.stat().st_size <= max_bytes:
        return
    try:
        from PIL import Image
        import io
        img = Image.open(path)
        if img.mode in ('RGBA', 'LA', 'P'):
            img = img.convert('RGB')
        for quality in (85, 75, 65, 55, 45, 35):
            buf = io.BytesIO()
            img.save(buf, 'JPEG', quality=quality, optimize=True)
            data = buf.getvalue()
            if len(data) <= max_bytes:
                path.write_bytes(data)
                logging.info(f"kieai: compressed {path.name} to {len(data)//1024}KB (q={quality})")
                return
        # Последний шанс — уменьшаем разрешение вдвое
        w, h = img.size
        img2 = img.resize((w // 2, h // 2), Image.LANCZOS)
        buf = io.BytesIO()
        img2.save(buf, 'JPEG', quality=55, optimize=True)
        data = buf.getvalue()
        path.write_bytes(data)
        logging.info(f"kieai: compressed+resized {path.name} to {len(data)//1024}KB")
    except Exception as e:
        logging.warning(f"kieai: compress failed for {path.name}: {e}")


def _save_from_url(url: str, output_path: str, compress_ref: bool = False) -> None:
    """Скачивает изображение по URL и сохраняет. Если compress_ref=True — сжимает до 2MB."""
    r = requests.get(url, timeout=60)
    r.raise_for_status()
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(r.content)
    size_kb = len(r.content) // 1024
    logging.info(f"kieai: saved result -> {path.name} ({size_kb}KB)")
    if compress_ref and len(r.content) > _MAX_REF_BYTES:
        logging.warning(f"kieai: {path.name} is {size_kb}KB > 2MB limit — compressing...")
        _compress_to_max_size(path)


def _remix(image_path: str, output_path: str, prompt: str, label: str,
           image_size: str = 'landscape_16_9', compress_ref: bool = False) -> str:
    """
    Обёртка с retry: 3 попытки на весь цикл (upload + submit + poll + save).
    Задержки: 10s / 20s между попытками.
    """
    from fastgen import _flowultra_shutdown_event
    last_err = None
    for attempt in range(1, 4):
        if _flowultra_shutdown_event.is_set():
            raise InterruptedError(f"Kie.ai {label} aborted by shutdown")
        try:
            print(f"  {_YELLOW}[KIEAI {label}]{_RESET} {Path(image_path).name} (attempt {attempt}/3)")
            result_url = _edit_image(image_path, prompt, image_size=image_size)
            _save_from_url(result_url, output_path, compress_ref=compress_ref)
            logging.info(f"kieai {label}: {Path(image_path).name} -> {output_path} OK")
            return output_path
        except Exception as e:
            last_err = e
            if attempt < 3:
                wait = 10 * attempt  # 10s, 20s
                logging.warning(
                    f"kieai {label} attempt {attempt}/3 failed: {e}. Retry in {wait}s..."
                )
                print(
                    f"  {_YELLOW}[KIEAI {label}]{_RESET} attempt {attempt}/3 failed: {e}. "
                    f"Retry in {wait}s..."
                )
                for _ in range(wait):
                    if _flowultra_shutdown_event.is_set():
                        raise InterruptedError(f"Kie.ai {label} aborted during retry wait")
                    time.sleep(1)

    raise RuntimeError(f"Kie.ai {label} failed after 3 attempts: {last_err}")


# ──────────────────────────────────────────────────────────────────────────────
# Публичный API
# ──────────────────────────────────────────────────────────────────────────────

def remix_ref_kieai(image_path: str, output_path: str) -> str:
    """
    Ремикс реф-изображения через Kie.ai qwen/image-edit.
    Приводит короткую сторону к 512px (мин. требование API + экономия на пикселях).
    Промпт берётся из ref_remix_prompt.txt.
    """
    prompt = _load_prompt('ref_remix_prompt.txt', _DEFAULT_REF_REMIX)
    resized_path = _resize_for_ref_remix(image_path)
    try:
        return _remix(resized_path, output_path, prompt, 'REF REMIX', image_size='square_hd', compress_ref=True)
    finally:
        # Удаляем temp-файл ресайза если он создавался
        if resized_path != image_path and os.path.exists(resized_path):
            try:
                os.remove(resized_path)
            except Exception:
                pass


def remix_i2v_kieai(image_path: str, output_path: str, log_path: str = None, hint: str = None) -> str:
    """
    Ремикс i2v-изображения через Kie.ai qwen/image-edit.
    БЕЗ даунскейла — результат идёт в финальный ролик через Veo.
    Промпт берётся из i2v_remix_prompt.txt.

    Args:
        hint: targeted instruction from Google error reason. If provided → used directly,
              Vision checks SKIPPED. If None → Vision checks run and their addition used.

    Если передан log_path — пишет запись в remix_debug.log.
    """
    prompt = _load_prompt('i2v_remix_prompt.txt', _DEFAULT_I2V_REMIX)
    if hint:
        flags = {'google_hint': True}
        prompt = prompt + ' ' + hint
    else:
        flags, addition = run_all_checks(image_path)
        if addition:
            prompt = prompt + addition
    try:
        result = _remix(image_path, output_path, prompt, 'I2V REMIX')
        if log_path:
            _save_remix_log(log_path, Path(image_path).name, flags, prompt, result)
        return result
    except Exception as e:
        if log_path:
            _save_remix_log(log_path, Path(image_path).name, flags, prompt, output_path, error=str(e))
        raise


# ──────────────────────────────────────────────────────────────────────────────
# Routing API — маршрутизация между KieAI и Grok по config.REMIX_ENGINE
# ──────────────────────────────────────────────────────────────────────────────

def _safe_err(e: Exception, max_len: int = 300) -> str:
    """Обрезает HTML/JS мусор из сообщения исключения перед логированием."""
    s = str(e)
    if '<!DOCTYPE' in s or '<html' in s.lower():
        s = s[:200].split('<')[0].strip() or 'server returned HTML'
        s += ' (HTML truncated)'
    return s[:max_len]


def _grok_ref_remix_with_retry(image_path: str, output_path: str, max_attempts: int = 3,
                                 api_key: Optional[str] = None, key_label: str = 'Key1') -> str:
    """Grok ref remix with retries on a specific API key. Raises on total failure."""
    from fastgen import FastGenClient, _flowultra_shutdown_event
    fc = FastGenClient(api_key=api_key) if api_key else FastGenClient()
    last_err = None
    for attempt in range(1, max_attempts + 1):
        if _flowultra_shutdown_event.is_set():
            raise InterruptedError(f"Grok REF REMIX [{key_label}] aborted by shutdown")
        try:
            print(f"  {_YELLOW}[GROK REF REMIX {key_label}]{_RESET} {Path(image_path).name} (attempt {attempt}/{max_attempts})")
            result = fc.remix_ref_grok(image_path, output_path)
            logging.info(f"Grok REF REMIX [{key_label}]: {Path(image_path).name} -> {output_path} OK")
            return result
        except Exception as e:
            last_err = e
            err_str = str(e)
            # "cancelled by user" из cancel_all_tasks — не ретраим
            if 'cancelled by user' in err_str.lower() or _flowultra_shutdown_event.is_set():
                raise InterruptedError(f"Grok REF REMIX [{key_label}] cancelled by user")
            if '403' in err_str and ('DOCTYPE' in err_str or 'html' in err_str.lower()):
                raise  # Cloudflare down — caller handles fallback
            if attempt < max_attempts:
                wait = 5 * attempt
                logging.warning(f"Grok REF REMIX [{key_label}] attempt {attempt}/{max_attempts} failed: {_safe_err(e)}. Retry in {wait}s...")
                print(f"  {_YELLOW}[GROK REF REMIX {key_label}]{_RESET} attempt {attempt}/{max_attempts} failed: {_safe_err(e)}. Retry in {wait}s...")
                # Interruptible sleep
                for _ in range(wait):
                    if _flowultra_shutdown_event.is_set():
                        raise InterruptedError(f"Grok REF REMIX [{key_label}] aborted during retry wait")
                    time.sleep(1)
    raise RuntimeError(f"Grok REF REMIX [{key_label}] failed after {max_attempts} attempts: {_safe_err(last_err)}")


def _grok_ref_remix_key_chain(image_path: str, output_path: str) -> str:
    """
    Grok ref remix fallback chain:
      Key1 (3 attempts) → pause 10s → Key2 (3 attempts) → pause 30s → Key1 (3 attempts) → raise.

    Если Key2 не сконфигурирован — fallback сразу падает с исключением Key1.
    Caller (remix_ref) дальше ловит и переключается на KieAI.
    """
    from fastgen import _flowultra_shutdown_event
    key1 = config.FASTGEN_API_KEY
    key2 = getattr(config, 'FASTGEN_API_KEY_2', '')

    def _interruptible_sleep(secs: int, tag: str):
        for _ in range(secs):
            if _flowultra_shutdown_event.is_set():
                raise InterruptedError(f"Grok chain aborted during {tag} pause")
            time.sleep(1)

    # Phase 1: Key1
    if _flowultra_shutdown_event.is_set():
        raise InterruptedError("Grok chain aborted before Key1")
    try:
        return _grok_ref_remix_with_retry(image_path, output_path, api_key=key1, key_label='Key1')
    except InterruptedError:
        raise  # не ретраим, пропускаем наверх
    except Exception as e1:
        logging.warning(f"Grok chain phase 1 (Key1) failed: {_safe_err(e1)}")

    if not key2 or key2 == key1:
        raise RuntimeError(f"Grok Key1 failed and no Key2 configured: {_safe_err(e1)}")

    # Phase 2: 10s pause → Key2
    print(f"  {_YELLOW}[GROK CHAIN]{_RESET} Key1 failed → pause 10s → Key2...")
    logging.info("Grok chain: phase 1 failed, waiting 10s before Key2")
    _interruptible_sleep(10, '10s-before-Key2')
    try:
        return _grok_ref_remix_with_retry(image_path, output_path, api_key=key2, key_label='Key2')
    except InterruptedError:
        raise
    except Exception as e2:
        logging.warning(f"Grok chain phase 2 (Key2) failed: {_safe_err(e2)}")

    # Phase 3: 30s pause → back to Key1
    print(f"  {_YELLOW}[GROK CHAIN]{_RESET} Key2 failed → pause 30s → Key1 retry...")
    logging.info("Grok chain: phase 2 failed, waiting 30s before Key1 retry")
    _interruptible_sleep(30, '30s-before-Key1-retry')
    try:
        return _grok_ref_remix_with_retry(image_path, output_path, api_key=key1, key_label='Key1-retry')
    except InterruptedError:
        raise
    except Exception as e3:
        logging.error(f"Grok chain phase 3 (Key1-retry) failed: {_safe_err(e3)}")
        raise  # all 3 Grok phases exhausted → caller falls back to KieAI


def remix_ref(image_path: str, output_path: str) -> str:
    """
    Route ref remix to configured engine (kieai or grok).

    REMIX_ENGINE=grok: Grok chain (Key1 → pause 10s → Key2 → pause 30s → Key1) → KieAI → raise.
    REMIX_ENGINE=kieai: KieAI → Grok chain (1 attempt per key) → raise.
    """
    if config.REMIX_ENGINE == 'grok':
        try:
            return _grok_ref_remix_key_chain(image_path, output_path)
        except Exception as e:
            logging.warning(f"Grok chain exhausted: {_safe_err(e)}. Fallback → KieAI")
            print(f"  {_YELLOW}[GROK→KIEAI FALLBACK]{_RESET} {Path(image_path).name}")
            return remix_ref_kieai(image_path, output_path)
    else:
        # KieAI primary → Grok fallback (single key, 1 attempt) → raise
        try:
            return remix_ref_kieai(image_path, output_path)
        except Exception as e:
            logging.warning(f"KieAI REF REMIX failed: {_safe_err(e)}. Fallback → Grok (1 attempt)")
            print(f"  {_YELLOW}[KIEAI→GROK FALLBACK]{_RESET} {Path(image_path).name}")
            try:
                return _grok_ref_remix_with_retry(image_path, output_path, max_attempts=1,
                                                   api_key=config.FASTGEN_API_KEY, key_label='Key1')
            except Exception as e2:
                logging.error(f"Grok fallback REF REMIX also failed: {_safe_err(e2)}")
                raise


def _grok_i2v_remix_with_retry(image_path: str, output_path: str, prompt: str,
                                flags=None, log_path: str = None, max_attempts: int = 3) -> str:
    """Grok i2v remix with retries. Raises on total failure."""
    from fastgen import FastGenClient
    fc = FastGenClient()
    last_err = None
    for attempt in range(1, max_attempts + 1):
        try:
            print(f"  {_YELLOW}[GROK I2V REMIX]{_RESET} {Path(image_path).name} (attempt {attempt}/{max_attempts})")
            result = fc._grok_edit_and_save(image_path, output_path, prompt)
            logging.info(f"Grok I2V REMIX: {Path(image_path).name} -> {output_path} OK")
            if log_path and flags is not None:
                _save_remix_log(log_path, Path(image_path).name, flags, prompt, result)
            return result
        except Exception as e:
            last_err = e
            err_str = str(e)
            if '403' in err_str and ('DOCTYPE' in err_str or 'html' in err_str.lower()):
                raise  # Cloudflare down — caller handles fallback
            if attempt < max_attempts:
                wait = 5 * attempt
                logging.warning(f"Grok I2V REMIX attempt {attempt}/{max_attempts} failed: {_safe_err(e)}. Retry in {wait}s...")
                print(f"  {_YELLOW}[GROK I2V REMIX]{_RESET} attempt {attempt}/{max_attempts} failed: {_safe_err(e)}. Retry in {wait}s...")
                time.sleep(wait)
    if log_path and flags is not None:
        _save_remix_log(log_path, Path(image_path).name, flags, prompt, output_path, error=_safe_err(last_err))
    raise RuntimeError(f"Grok I2V REMIX failed after {max_attempts} attempts: {_safe_err(last_err)}")


def remix_i2v(image_path: str, output_path: str, log_path: str = None, hint: str = None) -> str:
    """
    Route i2v remix to configured engine (kieai or grok).
    Fallback chain: primary engine → alt engine (1 attempt) → raise.

    Args:
        hint: targeted remix instruction derived from Google error reason.
              If provided → used as the prompt addition, Vision checks SKIPPED.
              If None  → existing Vision-checks-based addition is used.
    """
    def _build_prompt_and_flags():
        """Return (prompt, flags_dict) honoring the hint-vs-Vision distinction."""
        base = _load_prompt('i2v_remix_prompt.txt', _DEFAULT_I2V_REMIX)
        if hint:
            return base + ' ' + hint, {'google_hint': True}
        _flags, _addition = run_all_checks(image_path)
        return (base + _addition) if _addition else base, _flags

    if config.REMIX_ENGINE == 'grok':
        prompt, flags = _build_prompt_and_flags()
        try:
            return _grok_i2v_remix_with_retry(image_path, output_path, prompt, flags, log_path)
        except Exception as e:
            logging.warning(f"Grok I2V REMIX failed: {_safe_err(e)}. Fallback → KieAI")
            print(f"  {_YELLOW}[GROK→KIEAI FALLBACK]{_RESET} {Path(image_path).name}")
            return remix_i2v_kieai(image_path, output_path, log_path, hint=hint)
    else:
        # KieAI primary → Grok fallback (1 attempt) → raise
        try:
            return remix_i2v_kieai(image_path, output_path, log_path, hint=hint)
        except Exception as e:
            logging.warning(f"KieAI I2V REMIX failed: {_safe_err(e)}. Fallback → Grok (1 attempt)")
            print(f"  {_YELLOW}[KIEAI→GROK FALLBACK]{_RESET} {Path(image_path).name}")
            prompt, flags = _build_prompt_and_flags()
            try:
                return _grok_i2v_remix_with_retry(image_path, output_path, prompt, flags, log_path, max_attempts=1)
            except Exception as e2:
                logging.error(f"Grok fallback I2V REMIX also failed: {_safe_err(e2)}")
                raise
