@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

REM ============================================================================
REM RUN_DOGENERATOR.BAT - Find missing clips and generate them via FastGen
REM ============================================================================
REM Usage:
REM   run_dogenerator.bat
REM   run_dogenerator.bat <project_name>
REM ============================================================================

REM --- Always run from own directory so relative paths work ---
cd /d "%~dp0"

echo.
echo ================================================================================
echo  DOGENERATOR: Find and generate missing FastGen clips
echo ================================================================================
echo.

REM --- Determine project name ---
set "PROJECT=%~1"

if "%PROJECT%"=="" (
    echo  Available projects:
    echo.
    for /d %%p in ("projects\*") do (
        echo    %%~nxp
    )
    echo.
    set /p "PROJECT=Enter project name: "
    echo.
)

if "%PROJECT%"=="" (
    echo  [ERROR] No project specified.
    pause
    exit /b 1
)

if not exist "projects\%PROJECT%" (
    echo  [ERROR] Project not found: projects\%PROJECT%
    pause
    exit /b 1
)

REM --- Run missing clips finder ---
echo  Project: %PROJECT%
echo  Scanning generated\ folder...
echo.

set "TMPFILE=%TEMP%\dogenerator_missing_%RANDOM%.txt"

python agent\find_missing_clips.py "%PROJECT%" > "%TMPFILE%" 2>&1
set "PY_EXIT=%ERRORLEVEL%"

if %PY_EXIT% EQU 1 (
    echo  [ERROR] Could not scan project:
    type "%TMPFILE%"
    del "%TMPFILE%" 2>nul
    echo.
    pause
    exit /b 1
)

if %PY_EXIT% EQU 2 (
    echo  [OK] Nothing to generate - all clips already exist in generated\
    del "%TMPFILE%" 2>nul
    echo.
    pause
    exit /b 0
)

REM --- Parse output: line1=total, line2=missing_count, line3=ids_csv ---
set "LINE_NUM=0"
set "TOTAL_COUNT="
set "MISSING_COUNT="
set "MISSING_IDS="

for /f "usebackq tokens=* delims=" %%L in ("%TMPFILE%") do (
    set /a LINE_NUM+=1
    if !LINE_NUM! EQU 1 set "TOTAL_COUNT=%%L"
    if !LINE_NUM! EQU 2 set "MISSING_COUNT=%%L"
    if !LINE_NUM! EQU 3 set "MISSING_IDS=%%L"
)

echo  Total prompts:  %TOTAL_COUNT%
echo  Missing clips:  %MISSING_COUNT%
echo.
echo ================================================================================
echo  MISSING CLIPS:
echo ================================================================================
echo.

set "LINE_NUM=0"
for /f "usebackq tokens=* delims=" %%L in ("%TMPFILE%") do (
    set /a LINE_NUM+=1
    if !LINE_NUM! GTR 3 (
        echo   %%L
    )
)

del "%TMPFILE%" 2>nul

echo.
echo ================================================================================
echo  IDs to generate: %MISSING_IDS%
echo ================================================================================
echo.

REM ============================================================================
REM  ENGINE SELECTION
REM ============================================================================

echo  Select engine:
echo    [1] NANO PRO FLOW    GEM_PIX_2   - best quality, Flow API
echo    [2] NANO BANANA 2    NARWHAL     - Nano Banana 2, Flow API v4
echo    [3] NANO PRO GEMINI  GEMINI      - Gemini native, fast
echo    [4] GROK             GROK        - Grok, 4 variants
echo    [5] NANO             GEM_PIX     - basic, Flow API
echo    [6] IMAGEN_3_5_FLOW  IMAGEN_3_5  - Imagen 4, Flow API
echo    [7] WHISK            WHISK       - Whisk, categorized refs
echo.
set "MODEL=GEM_PIX_2"
set /p MODEL_CHOICE="  Engine [1-7] (Enter = GEM_PIX_2): "
if "!MODEL_CHOICE!"=="1" set "MODEL=GEM_PIX_2"
if "!MODEL_CHOICE!"=="2" set "MODEL=NARWHAL"
if "!MODEL_CHOICE!"=="3" set "MODEL=GEMINI"
if "!MODEL_CHOICE!"=="4" set "MODEL=GROK"
if "!MODEL_CHOICE!"=="5" set "MODEL=GEM_PIX"
if "!MODEL_CHOICE!"=="6" set "MODEL=IMAGEN_3_5"
if "!MODEL_CHOICE!"=="7" set "MODEL=WHISK"
echo    Selected: !MODEL!
echo.

REM --- Aspect ratio ---
echo  Select aspect ratio:
echo    [1] landscape  16:9, recommended for video
echo    [2] portrait   9:16
echo    [3] square     1:1
echo.
set "ASPECT=landscape"
set /p ASPECT_CHOICE="  Aspect [1/2/3] (Enter = landscape): "
if "!ASPECT_CHOICE!"=="2" set "ASPECT=portrait"
if "!ASPECT_CHOICE!"=="3" set "ASPECT=square"
echo    Selected: !ASPECT!
echo.

REM --- Parallel threads ---
set "PARALLEL=10"
set /p PARALLEL_INPUT="  Parallel [1-10] (Enter = 10): "
if not "!PARALLEL_INPUT!"=="" set "PARALLEL=!PARALLEL_INPUT!"
echo    Selected: !PARALLEL!
echo.

REM --- Reference mode ---
set "MODE_ARG="
if exist "projects\%PROJECT%\ref" (
    echo  ref/ folder found!
    echo    [1] Auto-detect
    echo    [2] Flow  - flat refs, up to 10
    echo    [3] Whisk - subject/scene/style categories
    echo.
    set /p MODE_CHOICE="  Ref mode [1/2/3] (Enter = auto): "
    if "!MODE_CHOICE!"=="2" set "MODE_ARG=--mode flow"
    if "!MODE_CHOICE!"=="3" set "MODE_ARG=--mode whisk"
    echo.
) else (
    echo  No ref/ folder - generating without references
    echo.
)

REM ============================================================================
REM  QUOTA CHECK
REM ============================================================================

set "TMPQ=%TEMP%\quota_check_%RANDOM%.txt"
cd /d "%~dp0\agent"
python quota_check.py "%PROJECT%" --ids "%MISSING_IDS%" > "%TMPQ%" 2>nul
set "QC_EXIT=%ERRORLEVEL%"
cd /d "%~dp0"

set "QC_REMAINING=?"
set "QC_NEEDED=?"
set "QC_HAS_BACKUP=0"
for /f "tokens=1,2 delims==" %%a in (%TMPQ%) do (
    if "%%a"=="remaining"  set "QC_REMAINING=%%b"
    if "%%a"=="needed"     set "QC_NEEDED=%%b"
    if "%%a"=="has_backup" set "QC_HAS_BACKUP=%%b"
)
del "%TMPQ%" 2>nul

set "BACKUP_ARG="
set "QC_CHOICE="

if %QC_EXIT% EQU 2 (
    echo ================================================================================
    echo  [WARN] QUOTA: remaining=!QC_REMAINING!, needed=!QC_NEEDED! - NOT ENOUGH
    echo    [1] Use BACKUP API key - FASTGEN_API_KEY_BACKUP from .env
    echo    [2] Continue with MAIN key anyway -- default --
    echo    [3] Cancel
    echo ================================================================================
    echo.
    set /p QC_CHOICE="  Choice [1/2/3] (Enter = main key): "
    if "!QC_CHOICE!"=="1" set "BACKUP_ARG=--backup-key"
    if "!QC_CHOICE!"=="3" (
        echo  Cancelled.
        pause
        exit /b 0
    )
    echo.
) else if %QC_EXIT% EQU 3 (
    echo ================================================================================
    echo  [WARN] QUOTA: remaining=!QC_REMAINING!, needed=!QC_NEEDED! - NOT ENOUGH
    echo         No backup key in .env - FASTGEN_API_KEY_BACKUP not set
    echo    [1] Continue with main key anyway -- default --
    echo    [2] Cancel
    echo ================================================================================
    echo.
    set /p QC_CHOICE="  Choice [1/2] (Enter = continue): "
    if "!QC_CHOICE!"=="2" (
        echo  Cancelled.
        pause
        exit /b 0
    )
    echo.
) else (
    echo  Quota: !QC_REMAINING! remaining / !QC_NEEDED! needed   [OK]
    echo.
)

if "!BACKUP_ARG!"=="--backup-key" (
    set "TMPQ2=%TEMP%\quota_check2_%RANDOM%.txt"
    cd /d "%~dp0\agent"
    python quota_check.py "%PROJECT%" --ids "%MISSING_IDS%" --backup-key > "!TMPQ2!" 2>nul
    cd /d "%~dp0"
    set "BK_REMAINING=?"
    for /f "tokens=1,2 delims==" %%a in ('type "!TMPQ2!"') do (
        if "%%a"=="remaining" set "BK_REMAINING=%%b"
    )
    del "!TMPQ2!" 2>nul
    echo  Backup key quota: !BK_REMAINING! remaining / !QC_NEEDED! needed
    echo.
)

REM ============================================================================
REM  CONFIRM
REM ============================================================================
echo ================================================================================
echo  SUMMARY:
echo    Project:  %PROJECT%
echo    Clips:    %MISSING_COUNT% missing (%MISSING_IDS%)
echo    Engine:   !MODEL!
echo    Aspect:   !ASPECT!
echo    Parallel: !PARALLEL!
if not "!MODE_ARG!"=="" (echo    Refs:     !MODE_ARG!) else (echo    Refs:     auto)
if not "!BACKUP_ARG!"=="" (echo    API key:  BACKUP) else (echo    API key:  main)
echo ================================================================================
echo.
set /p CONFIRM="  Start? (y/n): "
if /i not "!CONFIRM!"=="y" (
    echo  Cancelled.
    pause
    exit /b 0
)

echo.
echo ================================================================================
echo  Starting generation...
echo ================================================================================
echo.

cd /d "%~dp0\agent"

python agent.py generate ^
    --project "%PROJECT%" ^
    --ids "%MISSING_IDS%" ^
    --model "!MODEL!" ^
    --aspect "!ASPECT!" ^
    --parallel !PARALLEL! !MODE_ARG! !BACKUP_ARG!

set "GEN_EXIT=%ERRORLEVEL%"
cd /d "%~dp0"

echo.
echo ================================================================================
if %GEN_EXIT% NEQ 0 (
    echo  [ERROR] Generation finished with errors. Check:
    echo  projects\%PROJECT%\generation_log.json
) else (
    echo  [OK] Generation complete.
    echo  Output: projects\%PROJECT%\generated\
    echo  Log:    projects\%PROJECT%\generation_log.json
)
echo ================================================================================
echo.
pause
exit /b %GEN_EXIT%
