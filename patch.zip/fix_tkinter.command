#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[ -f "$SCRIPT_DIR/.venv/bin/activate" ] && source "$SCRIPT_DIR/.venv/bin/activate"

echo ""
echo "========================================"
echo " Fix: tkinter for macOS"
echo "========================================"
echo ""

# Activate Homebrew
if [ -f /opt/homebrew/bin/brew ]; then
    eval "$(/opt/homebrew/bin/brew shellenv)"
elif [ -f /usr/local/bin/brew ]; then
    eval "$(/usr/local/bin/brew shellenv)"
fi

# Detect Python version
PY_VER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>/dev/null)
echo " Python version: $PY_VER"
echo ""

# Check if tkinter already works
python3 -c "import tkinter" 2>/dev/null
if [ $? -eq 0 ]; then
    echo " [OK] tkinter already installed. Nothing to do."
    echo ""
    read -p "Press Enter to close..."
    exit 0
fi

echo " Installing python-tk@${PY_VER}..."
echo ""
brew install "python-tk@${PY_VER}"

echo ""
python3 -c "import tkinter" 2>/dev/null
if [ $? -eq 0 ]; then
    echo " [OK] tkinter installed successfully!"
    echo ""
    echo " You can now run varagent.command"
else
    echo " [ERROR] tkinter still not found."
    echo "   Try manually in Terminal:"
    echo "   brew install python-tk@${PY_VER}"
fi

echo ""
read -p "Press Enter to close..."
