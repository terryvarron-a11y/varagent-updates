"""
Модуль режиссерского анализа через Gemini API
Новая библиотека: google-genai
"""
from google import genai
from google.genai import types
import json
import logging
import math
import re
import sys
import threading
import time
import traceback
from pathlib import Path
from typing import Optional, Dict, Any, Tuple
from tqdm import tqdm
from datetime import datetime

import config
from modules.validator import validate_montage_plan_json, check_clip_id_sequence


class GeminiTimeoutError(Exception):
    """Gemini завис дольше заданного таймаута — нужен фоллбэк."""


class _TeeStream:
    """Пишет в оригинальный stdout И в файл одновременно."""
    def __init__(self, original, file_handle):
        self._orig = original
        self._file = file_handle
    def write(self, data):
        self._orig.write(data)
        try:
            self._file.write(data)
            self._file.flush()
        except Exception:
            pass
    def flush(self):
        self._orig.flush()
        try:
            self._file.flush()
        except Exception:
            pass
    def __getattr__(self, name):
        return getattr(self._orig, name)


class GeminiDirector:
    """Режиссерский анализ через Gemini API (google-genai)"""

    def __init__(self, api_key: Optional[str] = None, model_name: Optional[str] = None):
        self.api_key = api_key or config.GEMINI_API_KEY
        self.model_name = model_name or config.GEMINI_MODEL

        if not self.api_key:
            raise ValueError("Gemini API ключ не указан")

        self.client = genai.Client(api_key=self.api_key)
        self.input_tokens = 0
        self.output_tokens = 0

    # =========================================================================
    # ГЛАВНЫЙ МЕТОД
    # =========================================================================

    def analyze(
        self,
        transcription_path: str,
        style_guide_path: str,
        output_dir: str,
        project_name: str = "Untitled",
        two_pass: bool = False,
        prompts_only: bool = False,
        resume_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        transcription_path = Path(transcription_path)
        style_guide_path = Path(style_guide_path)
        output_dir = Path(output_dir)

        if not transcription_path.exists():
            raise FileNotFoundError(f"Транскрипция не найдена: {transcription_path}")
        if not style_guide_path.exists():
            raise FileNotFoundError(f"Style guide не найден: {style_guide_path}")

        print(f"\n🎬 Режиссерский анализ проекта: {project_name}")
        print("=" * 60)

        print("📂 Загрузка транскрипции...")
        with open(transcription_path, 'r', encoding='utf-8') as f:
            transcription = json.load(f)

        # Validate: audioDuration must cover last clip end
        _clips = transcription.get('transcription', [])
        if _clips:
            _last_end = _clips[-1].get('end', 0)
            _aud_dur  = transcription.get('audioDuration', 0)
            if _last_end > _aud_dur:
                print(f"⚠️  audioDuration={_aud_dur:.2f}s < last clip end={_last_end:.2f}s — correcting to {_last_end:.2f}s")
                logging.warning(f"audioDuration corrected: {_aud_dur:.2f} → {_last_end:.2f}")
                transcription['audioDuration'] = _last_end

        print("📂 Загрузка style guide...")
        with open(style_guide_path, 'r', encoding='utf-8') as f:
            style_guide = f.read()

        # Только промпты: читаем готовый montage_plan.json и идём сразу в проход 2
        if prompts_only:
            montage_plan_path = output_dir / 'montage_plan.json'
            if not montage_plan_path.exists():
                raise FileNotFoundError(f"montage_plan.json не найден: {montage_plan_path}")
            with open(montage_plan_path, 'r', encoding='utf-8') as f:
                montage_plan = json.load(f)
            num_clips = len(montage_plan.get('clips', []))
            print(f"\n📝 Парсинг плана...")
            print(f"   ✓ montage_plan.json — {num_clips} клипов")
            logging.info(f"Prompts-only start: project={project_name} clips={num_clips} chunk_size={config.PROMPT_CHUNK_SIZE}")

            prompts_results, all_costs = self._run_pass2(
                montage_plan, transcription, style_guide, project_name, output_dir, pass_label="2/2",
                resume_path=resume_path,
            )
            logging.info(f"Pass 2 done: {prompts_results.get('num_prompts', '?')} prompts saved")

            results = prompts_results
            results['montage_plan'] = montage_plan_path
            num_prompts = prompts_results.get('num_prompts', 0)
            num_clips_result = prompts_results.get('num_clips', num_clips)

            n_passes = len(all_costs)
            if all_costs:
                keys = ['input_tokens','output_tokens','thinking_tokens','total_output_tokens',
                        'input_cost','output_cost','thinking_cost','total_cost']
                total_cost = {k: sum(c.get(k, 0) for c in all_costs) for k in keys}
                if n_passes > 1:
                    label = f"ИТОГО за {n_passes} прохода (вкл. дополнения)"
                    self._print_cost(total_cost, label=label)
                self._write_token_log(total_cost, output_dir, project_name,
                                      num_prompts=num_prompts, num_clips=num_clips_result)
                cumulative = self._update_cost_log(total_cost, project_name)
                key_id = self.api_key[-8:] if len(self.api_key) >= 8 else self.api_key
                print(f"\n📊 Затраты по ключу ...{key_id} ({self.model_name}):")
                print(f"   Этот прогон:    ${total_cost['total_cost']:.5f}")
                print(f"   Прогонов всего: {cumulative['total_runs']}")
                print(f"   {'─' * 40}")
                print(f"   НАКОПЛЕНО:      ${cumulative['total_cost']:.5f}")
                results['cost'] = total_cost

            print(f"\n✅ Промпты сгенерированы!")
            for name, path in results.items():
                if name not in ('cost', 'num_prompts', 'num_clips'):
                    print(f"   • {name}: {path}")
            return results

        # Двухпроходный режим
        if two_pass or config.GEMINI_TWO_PASS:
            results = self._analyze_two_pass(transcription, style_guide, output_dir, project_name)
            print(f"\n✅ Режиссерский анализ завершен (2 прохода)!")
            for name, path in results.items():
                if name != 'cost':
                    print(f"   • {name}: {path}")
            return results

        # Однопроходный режим
        print("📝 Формирование промпта...")
        sys_instr, prompt = self._create_prompt(transcription, style_guide, project_name)

        print(f"🤖 Отправка запроса к Gemini ({self.model_name})...")
        response, cost_info = self._make_api_call(prompt, system_instruction=sys_instr)

        self._print_cost(cost_info)

        print("\n📝 Парсинг ответа...")
        results = self._parse_response(response.text, output_dir, transcription, project_name)

        # Предупреждение: если клипов > PROMPT_CHUNK_SIZE — рекомендуем --two-pass
        _num_clips_check = results.get('num_clips', 0)
        _chunk_size = config.PROMPT_CHUNK_SIZE
        if _chunk_size > 0 and _num_clips_check > _chunk_size:
            print(f"\n⚠️  {_num_clips_check} клипов > PROMPT_CHUNK_SIZE ({_chunk_size}).")
            print(f"   Для лучшего качества используйте --two-pass (чанкование промптов).")
            print(f"   Продолжаю в однопроходном режиме с авто-дополнением + rollback...\n")

        # Авто-дополнение: если промптов меньше чем клипов
        all_costs = [cost_info] if cost_info else []
        num_prompts = results.get('num_prompts', 0)
        num_clips_result = results.get('num_clips', 0)
        main_prompts_path = results.get('prompts')

        if num_prompts < num_clips_result and num_clips_result > 0:
            # Читаем montage_plan.json обратно как dict
            montage_plan_path = output_dir / 'montage_plan.json'
            with open(montage_plan_path, 'r', encoding='utf-8') as f:
                montage_plan = json.load(f)

            MAX_CONTINUATION = 3
            for attempt in range(1, MAX_CONTINUATION + 1):
                if num_prompts >= num_clips_result:
                    break

                # Rollback: на первом continuation убираем последние N "уставших" промптов
                _rollback = config.CONT_ROLLBACK_SIZE
                if attempt == 1 and _rollback > 0 and num_prompts > _rollback:
                    rollback_to = num_prompts - _rollback
                    if main_prompts_path and main_prompts_path.exists():
                        _full = main_prompts_path.read_text(encoding='utf-8')
                        _kept = [c.strip() for c in _full.split('\n\n') if c.strip()][:rollback_to]
                        main_prompts_path.write_text('\n\n'.join(_kept), encoding='utf-8')
                        print(f"   ↩️  Rollback: удалены промпты #{rollback_to + 1}–{num_prompts} "
                              f"({_rollback} 'уставших'), перезапись с #{rollback_to + 1}")
                        num_prompts = rollback_to

                missing = num_clips_result - num_prompts
                from_id = num_prompts + 1
                print(f"\n🔁 Авто-дополнение ({attempt}/{MAX_CONTINUATION}): "
                      f"клипы {from_id}–{num_clips_result} ({missing} шт)...")
                print(f"🤖 Отправка запроса к Gemini ({self.model_name})...")

                # Берём последние 5 промптов из уже усечённого файла (после rollback = "здоровые")
                PREV_SAMPLE_SIZE = 5
                prev_sample = None
                if main_prompts_path and main_prompts_path.exists():
                    _full_for_sample = main_prompts_path.read_text(encoding='utf-8')
                    _all_for_sample = [c.strip() for c in _full_for_sample.split('\n\n') if c.strip()]
                    if _all_for_sample:
                        prev_sample = _all_for_sample[-PREV_SAMPLE_SIZE:]

                prompt_cont = self._create_prompt_continuation(
                    montage_plan, transcription, style_guide, project_name,
                    from_clip_id=from_id, to_clip_id=num_clips_result,
                    already_done=num_prompts,
                    prev_prompts_sample=prev_sample
                )
                response_cont, cost_cont = self._make_api_call(
                    prompt_cont, pass2_mode=True,
                    spinner_msg=f"Gemini дополняет (попытка {attempt})"
                )
                self._print_cost(cost_cont, label=f"дополнения {attempt}")
                if not response_cont or not response_cont.text:
                    logging.warning(f"Cont attempt {attempt}: empty response from Gemini, retrying")
                    print(f"   ⚠️  Gemini вернул пустой ответ (попытка {attempt}), повтор...")
                    continue
                _save_raw_response(output_dir, response_cont.text, suffix=f'_cont{attempt}')

                cont_montage = {'clips': [c for c in montage_plan.get('clips', [])
                                          if c['id'] >= from_id and c['id'] <= num_clips_result]}
                cont_results = self._parse_prompts_only(
                    response_cont.text, output_dir, cont_montage, project_name
                )
                cont_path = cont_results.get('prompts')
                if cont_path and cont_path.exists() and main_prompts_path and main_prompts_path.exists():
                    cont_text = cont_path.read_text(encoding='utf-8').strip()
                    with open(main_prompts_path, 'a', encoding='utf-8') as f:
                        f.write('\n\n' + cont_text)
                    cont_path.unlink()
                    full_text = main_prompts_path.read_text(encoding='utf-8')
                    chunks = [c.strip() for c in full_text.split('\n\n') if c.strip()]
                    num_prompts = len(chunks)
                    results['num_prompts'] = num_prompts
                    print(f"   → Итого промптов: {num_prompts} / {num_clips_result}")

                if cost_cont:
                    all_costs.append(cost_cont)

        # Финальная стоимость
        n_passes = len(all_costs)
        if n_passes >= 2:
            keys = ['input_tokens','output_tokens','thinking_tokens','total_output_tokens',
                    'input_cost','output_cost','thinking_cost','total_cost']
            total_cost = {k: sum(c.get(k, 0) for c in all_costs) for k in keys}
            label = f"ИТОГО за {n_passes} прохода (вкл. дополнения)"
            self._print_cost(total_cost, label=label)
            cost_info = total_cost

        if cost_info:
            self._write_token_log(cost_info, output_dir, project_name,
                                  num_prompts=results.get('num_prompts', 0),
                                  num_clips=results.get('num_clips', 0))
            results['cost'] = cost_info
            cumulative = self._update_cost_log(cost_info, project_name)
            key_id = self.api_key[-8:] if len(self.api_key) >= 8 else self.api_key
            print(f"\n📊 Затраты по ключу ...{key_id} ({self.model_name}):")
            print(f"   Этот прогон:    ${cost_info['total_cost']:.5f}")
            print(f"   Прогонов всего: {cumulative['total_runs']}")
            print(f"   {'─' * 40}")
            print(f"   НАКОПЛЕНО:      ${cumulative['total_cost']:.5f}")

        print(f"\n✅ Режиссерский анализ завершен!")
        for name, path in results.items():
            if name != 'cost':
                print(f"   • {name}: {path}")

        return results

    # =========================================================================
    # ДВУХПРОХОДНЫЙ РЕЖИМ
    # =========================================================================

    def _analyze_two_pass(
        self,
        transcription: dict,
        style_guide: str,
        output_dir: Path,
        project_name: str
    ) -> Dict[str, Any]:
        """Двухпроходный анализ: проход 1 = JSON план, проход 2 = промпты."""
        results = {}

        # === ПРОХОД 1: JSON план ===
        logging.info(f"Pass 1 start: project={project_name} model={self.model_name}")

        audio_duration = transcription.get('audioDuration', 0)
        use_chunked = (
            config.DIRECTOR_PASS1_CHUNK_THRESHOLD > 0
            and audio_duration > config.DIRECTOR_PASS1_CHUNK_THRESHOLD
        )

        if use_chunked:
            total_min   = audio_duration / 60
            chunk_min   = config.DIRECTOR_PASS1_CHUNK_DURATION / 60
            n_chunks    = math.ceil(audio_duration / config.DIRECTOR_PASS1_CHUNK_DURATION)
            print(f"\n🎬 ПРОХОД 1/2: Монтажный план — ЧАНКОВАННЫЙ РЕЖИМ")
            print(f"   Длительность: {total_min:.1f} мин → {n_chunks} чанков по {chunk_min:.0f} мин")
            logging.info(f"Pass 1 chunked: {n_chunks} chunks of {chunk_min:.0f}min")
            montage_plan, pass1_costs = self._run_pass1_chunked(
                transcription, style_guide, output_dir, project_name
            )
        else:
            print(f"\n🎬 ПРОХОД 1/2: Монтажный план (JSON)...")
            print(f"🤖 Отправка запроса к Gemini ({self.model_name})...")
            sys_instr1, prompt1 = self._create_prompt_pass1(transcription, style_guide, project_name)
            response1, cost1 = self._make_api_call(prompt1, system_instruction=sys_instr1,
                                                    spinner_msg="Gemini думает (проход 1/2)")
            self._print_cost(cost1, label="прохода 1")
            _save_raw_response(output_dir, response1.text, suffix='_pass1')

            # Проверка на завершенность JSON
            if response1.text.count('{') != response1.text.count('}'):
                logging.warning(f"Pass 1 JSON incomplete: {response1.text.count('{')} open vs {response1.text.count('}')} close braces")
                print(f"\n⚠️  JSON обрезан! ({response1.text.count('{')} откр. vs {response1.text.count('}')} закр. скобок)")

            print("\n📝 Парсинг плана...")
            montage_plan = self._parse_json_only(response1.text, output_dir, transcription, pass_num=1, project_name=project_name)

            if not montage_plan.get('clips'):
                for _retry in range(1, 3):
                    print(f"\n⚠️  Montage plan not found in response. Retry {_retry}/2...")
                    logging.warning(f"Pass 1 parse failed, retry {_retry}/2")
                    response1, cost1_retry = self._make_api_call(
                        prompt1, system_instruction=sys_instr1,
                        spinner_msg=f"Gemini retry {_retry}/2"
                    )
                    self._print_cost(cost1_retry, label=f"retry {_retry}")
                    _save_raw_response(output_dir, response1.text, suffix=f'_pass1_retry{_retry}')
                    montage_plan = self._parse_json_only(response1.text, output_dir, transcription, pass_num=1, project_name=project_name)
                    if montage_plan.get('clips'):
                        break
                else:
                    raise ValueError(
                        "Pass 1 failed to return a montage plan after 3 attempts.\n"
                        "  Raw responses saved: gemini_raw_response_*_pass1*.txt\n"
                        "  Try: python agent.py direct --transcription transcription.json "
                        "--style <style> --project <name> --prompts-only"
                    )
            pass1_costs = [c for c in [cost1] if c]

        num_clips = len(montage_plan['clips'])
        logging.info(f"Pass 1 done: {num_clips} clips parsed")

        # === ПРОХОД 2: Промпты (с чанкованием) ===
        logging.info(f"Pass 2 start: {num_clips} prompts, model={self.model_name}, chunk_size={config.PROMPT_CHUNK_SIZE}")
        prompts_results, pass2_costs = self._run_pass2(
            montage_plan, transcription, style_guide, project_name, output_dir, pass_label="2/2"
        )
        results.update(prompts_results)
        results['montage_plan'] = output_dir / 'montage_plan.json'
        logging.info(f"Pass 2 done: {prompts_results.get('num_prompts', '?')} prompts saved")

        # Суммарная стоимость (все проходы включая дополнения)
        all_costs = pass1_costs + pass2_costs
        num_prompts = prompts_results.get('num_prompts', 0)
        num_clips_result = prompts_results.get('num_clips', num_clips)
        results['num_prompts'] = num_prompts
        results['num_clips'] = num_clips_result

        n_passes = len(all_costs)
        if all_costs and n_passes >= 2:
            keys = ['input_tokens','output_tokens','thinking_tokens','total_output_tokens',
                    'input_cost','output_cost','thinking_cost','total_cost']
            total_cost = {k: sum(c.get(k, 0) for c in all_costs) for k in keys}
            label = f"ИТОГО за {n_passes} прохода" if n_passes == 2 else f"ИТОГО за {n_passes} прохода (вкл. дополнения)"
            self._print_cost(total_cost, label=label)
            self._write_token_log(total_cost, output_dir, project_name,
                                  num_prompts=num_prompts, num_clips=num_clips_result)
            cumulative = self._update_cost_log(total_cost, project_name)
            key_id = self.api_key[-8:] if len(self.api_key) >= 8 else self.api_key
            print(f"\n📊 Затраты по ключу ...{key_id} ({self.model_name}):")
            print(f"   Этот прогон:    ${total_cost['total_cost']:.5f}")
            print(f"   Прогонов всего: {cumulative['total_runs']}")
            print(f"   {'─' * 40}")
            print(f"   НАКОПЛЕНО:      ${cumulative['total_cost']:.5f}")
            results['cost'] = total_cost

        return results

    # =========================================================================
    # API ВЫЗОВ
    # =========================================================================

    def _make_api_call(
        self,
        prompt: str,
        pass2_mode: bool = False,
        spinner_msg: str = "Gemini думает",
        system_instruction: str = ''
    ) -> Tuple[Any, Optional[dict]]:
        """
        Вызов Gemini API со спиннером и retry при 503.
        pass2_mode=True: минимальный thinking (128 токенов для 2.x, "low" для 3.x).
        system_instruction: системная инструкция, отдельно от contents.
        Возвращает (response, cost_info).
        """
        generation_config = types.GenerateContentConfig(
            temperature=0.7,
            top_p=0.8,
            top_k=40,
            max_output_tokens=65536,
        )
        if system_instruction:
            generation_config.system_instruction = system_instruction

        model_lower = self.model_name.lower()
        if 'gemini-3' in model_lower:
            is_flash = 'flash' in model_lower
            is_3_1 = '3.1' in model_lower
            if is_flash or is_3_1:
                level_map = {'low': 'low', 'medium': 'medium', 'high': 'high'}
                default = 'medium'
            else:
                level_map = {'low': 'low', 'medium': 'high', 'high': 'high'}
                default = 'high'
            if pass2_mode:
                raw_level = config.GEMINI_THINKING_LEVEL_PASS2 or 'low'
            else:
                raw_level = config.GEMINI_THINKING_LEVEL or default
            thinking_level = level_map.get(raw_level, default)
            generation_config.thinking_config = types.ThinkingConfig(
                thinking_level=thinking_level
            )
            print(f"   Thinking Level: {thinking_level} (Gemini 3.x)")
        elif 'gemini-2' in model_lower:
            if pass2_mode:
                if config.GEMINI_THINKING_BUDGET_PASS2 > 0:
                    thinking_budget = config.GEMINI_THINKING_BUDGET_PASS2
                else:
                    # Дефолт: 8000 для Pro, 0 для Flash
                    thinking_budget = 8000 if '2.5-pro' in model_lower else 0
            elif config.GEMINI_THINKING_BUDGET > 0:
                thinking_budget = config.GEMINI_THINKING_BUDGET
            elif '2.5-pro' in model_lower:
                budget_map = {'low': 10000, 'medium': 20000, 'high': 32768}
                thinking_budget = budget_map.get(config.GEMINI_THINKING_LEVEL, 20000)
            else:
                budget_map = {'low': 1024, 'medium': 8192, 'high': 24576}
                thinking_budget = budget_map.get(config.GEMINI_THINKING_LEVEL, 8192)
            generation_config.thinking_config = types.ThinkingConfig(
                thinking_budget=thinking_budget
            )
            print(f"   Thinking Budget: {thinking_budget:,} токенов (Gemini 2.x)")

        # Retry loop при 503
        max_retries = 3
        retry_delays = [30, 60, 90]
        last_error = None
        response = None

        def _gemini_fallback_model(m: str) -> str | None:
            ml = m.lower()
            if 'gemini-3' in ml:
                return 'gemini-2.5-pro'
            if '2.5-pro' in ml:
                return 'gemini-3.1-pro-preview'
            return None

        # _gemini_fallback_model2 removed — gemini-3-pro-preview deprecated 2026-03-09

        def _wait(delay: int):
            for remaining in range(delay, 0, -1):
                sys.stdout.write(f'\r   ⏳ Ожидание: {remaining}с   ')
                sys.stdout.flush()
                time.sleep(1)
            sys.stdout.write('\r' + ' ' * 40 + '\r')
            sys.stdout.flush()

        def _classify_error(e):
            err_str = str(e)
            is_503 = '503' in err_str or 'UNAVAILABLE' in err_str.upper()
            is_disconnect = (
                'RemoteProtocolError' in type(e).__name__ or
                'Server disconnected' in err_str or
                'RemoteProtocolError' in err_str or
                'RemoteDisconnected' in err_str
            )
            is_network = (
                isinstance(e, OSError) and not is_503 and not is_disconnect or
                'nodename nor servname' in err_str or
                'Name or service not known' in err_str or
                'getaddrinfo failed' in err_str or
                'Temporary failure in name resolution' in err_str
            )
            return is_503, is_disconnect, is_network

        GEMINI_TIMEOUT_SEC = 15 * 60  # 15 минут

        for attempt in range(max_retries + 1):
            msg = spinner_msg if attempt == 0 else f"{spinner_msg} (попытка {attempt + 1}/{max_retries + 1})"
            try:
                response = _run_with_spinner(
                    self.client.models.generate_content,
                    message=msg,
                    timeout=GEMINI_TIMEOUT_SEC,
                    model=self.model_name,
                    contents=prompt,
                    config=generation_config,
                )
                break
            except GeminiTimeoutError as e:
                logging.warning(f"Gemini timeout: {self.model_name} завис >15мин — роутим на фелбек")
                print(f"\n   ⏰ Gemini timeout: {self.model_name} думал >15мин — роутим на фелбек модель")
                last_error = e
                break  # сразу к фоллбэку, не ретраим зависшую модель
            except Exception as e:
                is_503, is_disconnect, is_network = _classify_error(e)
                if (is_503 or is_disconnect) and attempt < max_retries:
                    reason = "503 UNAVAILABLE — сервер перегружен" if is_503 else "Server disconnected — обрыв соединения"
                    delay = retry_delays[attempt]
                elif is_network and attempt < max_retries:
                    reason = "Сеть недоступна (DNS/connection error)"
                    delay = [5, 15, 30][attempt]
                else:
                    logging.error(f"Gemini API вызов провалился (attempt {attempt + 1}): {e}")
                    logging.debug(traceback.format_exc())
                    last_error = e
                    break
                logging.warning(f"Gemini API: {reason} (попытка {attempt + 1}/{max_retries + 1}): {e}")
                print(f"\n   ⚠️  {reason}. Повтор через {delay}с... (попытка {attempt + 1}/{max_retries})")
                _wait(delay)
                last_error = e

        # Фелбек на другую модель если все ретраи исчерпаны
        if response is None and last_error is not None:
            def _build_fb_config(fb_name: str):
                cfg = types.GenerateContentConfig(
                    temperature=generation_config.temperature,
                    top_p=generation_config.top_p,
                    top_k=generation_config.top_k,
                    max_output_tokens=generation_config.max_output_tokens,
                )
                if system_instruction:
                    cfg.system_instruction = system_instruction
                fb_l = fb_name.lower()
                if 'gemini-3' in fb_l:
                    level = 'low' if pass2_mode else 'medium'
                    cfg.thinking_config = types.ThinkingConfig(thinking_level=level)
                    print(f"   Thinking Level: {level} (Gemini 3.x fallback)")
                elif 'gemini-2' in fb_l:
                    budget = 8000 if pass2_mode else 20000
                    cfg.thinking_config = types.ThinkingConfig(thinking_budget=budget)
                    print(f"   Thinking Budget: {budget:,} токенов (Gemini 2.x fallback)")
                return cfg

            def _try_fb(fb_name: str, label: str) -> bool:
                nonlocal response, last_error
                fb_cfg = _build_fb_config(fb_name)
                for fb_attempt in range(2):
                    fb_msg = f"{spinner_msg} [{label} {fb_name}]" + (f" попытка {fb_attempt + 1}/2" if fb_attempt else "")
                    try:
                        response = _run_with_spinner(
                            self.client.models.generate_content,
                            message=fb_msg,
                            model=fb_name,
                            contents=prompt,
                            config=fb_cfg,
                        )
                        print(f"   ✅ {label} {fb_name} успешен")
                        logging.info(f"{label} {fb_name} succeeded on attempt {fb_attempt + 1}")
                        return True
                    except Exception as e_fb:
                        is_503_fb, is_dc_fb, _ = _classify_error(e_fb)
                        if (is_503_fb or is_dc_fb) and fb_attempt == 0:
                            print(f"\n   ⚠️  {label} {fb_name} перегружен. Повтор через 60с...")
                            _wait(60)
                        else:
                            logging.error(f"{label} {fb_name} failed: {e_fb}")
                            last_error = e_fb
                            return False
                return False

            # Цепочка фолбеков: original → alt → пауза 150с → original → пауза 300с → alt → падение
            _fb1 = _gemini_fallback_model(self.model_name)  # alt model
            if not _fb1:
                raise last_error

            _orig = self.model_name
            _chain = [
                (_fb1,  'Фелбек 1', 0),
                (_orig, 'Фелбек 2 (retry original)', 150),
                (_fb1,  'Фелбек 3 (retry alt)', 300),
            ]
            _success = False
            for _fb_name, _fb_label, _pause in _chain:
                if _pause > 0:
                    print(f"\n   ⏳ Пауза {_pause}с перед {_fb_label}...")
                    _wait(_pause)
                print(f"\n   🔄 {_fb_label}: → {_fb_name}")
                logging.warning(f"Gemini {_fb_label}: → {_fb_name}")
                if _try_fb(_fb_name, _fb_label):
                    _success = True
                    break
            if not _success:
                raise last_error

        if response is None:
            raise last_error

        # Подсчёт токенов и стоимости
        cost_info = None
        um = getattr(response, 'usage_metadata', None)
        if um is not None:
            input_tokens    = getattr(um, 'prompt_token_count',     0) or 0
            output_tokens   = getattr(um, 'candidates_token_count', 0) or 0
            thinking_tokens = getattr(um, 'thoughts_token_count',   0) or 0
            self.input_tokens  = input_tokens
            self.output_tokens = output_tokens
            total_output_tokens = output_tokens + thinking_tokens
            cost_estimate = config.estimate_cost(input_tokens, total_output_tokens, self.model_name)
            pricing = config.get_model_pricing(self.model_name)
            thinking_cost    = (thinking_tokens / 1_000_000) * pricing['output']
            output_cost_only = (output_tokens   / 1_000_000) * pricing['output']
            cost_info = {
                'input_tokens':        input_tokens,
                'output_tokens':       output_tokens,
                'thinking_tokens':     thinking_tokens,
                'total_output_tokens': total_output_tokens,
                'input_cost':          cost_estimate['input_cost'],
                'output_cost':         output_cost_only,
                'thinking_cost':       thinking_cost,
                'total_cost':          cost_estimate['total_cost'],
            }

        if cost_info:
            logging.info(
                f"Gemini API OK | in={cost_info['input_tokens']:,} "
                f"out={cost_info['output_tokens']:,} "
                f"think={cost_info['thinking_tokens']:,} "
                f"cost=${cost_info['total_cost']:.4f}"
            )
        else:
            logging.info("Gemini API OK | usage_metadata unavailable")

        # Логируем finish_reason если текст пустой (помогает диагностировать блокировки)
        if not getattr(response, 'text', None):
            try:
                candidates = getattr(response, 'candidates', []) or []
                for i, cand in enumerate(candidates):
                    fr = getattr(cand, 'finish_reason', None)
                    safety = getattr(cand, 'safety_ratings', None)
                    logging.warning(f"Gemini empty text: candidate[{i}] finish_reason={fr}, safety_ratings={safety}")
                    print(f"   ⚠️  finish_reason={fr}")
                if not candidates:
                    logging.warning("Gemini empty text: no candidates in response")
                    print(f"   ⚠️  Gemini: no candidates (response={response})")
            except Exception as _diag_e:
                logging.warning(f"Gemini empty text: could not read candidates: {_diag_e}")

        return response, cost_info

    # =========================================================================
    # ВСПОМОГАТЕЛЬНЫЕ: стоимость и логи
    # =========================================================================

    def _print_cost(self, cost_info: Optional[dict], label: str = ""):
        """Вывод стоимости в консоль."""
        print()
        if cost_info:
            header = f"💰 Стоимость {label} ({self.model_name}):" if label else f"💰 Стоимость ({self.model_name}):"
            print(header)
            print(f"   Input:              {cost_info['input_tokens']:>8,} токенов  = ${cost_info['input_cost']:.5f}")
            print(f"   Output (text):      {cost_info['output_tokens']:>8,} токенов  = ${cost_info['output_cost']:.5f}")
            if cost_info.get('thinking_tokens'):
                print(f"   Output (thinking):  {cost_info['thinking_tokens']:>8,} токенов  = ${cost_info['thinking_cost']:.5f}")
            print(f"   {'─' * 52}")
            total = cost_info['total_cost']
            suffix = "  (менее 1 цента)" if total < 0.01 else ""
            print(f"   ИТОГО:                                    ${total:.5f}{suffix}")
        else:
            print("⚠️  usage_metadata недоступен — стоимость неизвестна")

    def _write_token_log(self, cost_info: dict, output_dir: Path, project_name: str,
                         num_prompts: int = 0, num_clips: int = 0):
        """Сохраняет отчёт о токенах в файл проекта."""
        output_dir.mkdir(parents=True, exist_ok=True)
        output_total_cost = cost_info['output_cost'] + cost_info['thinking_cost']

        if num_clips > 0:
            prompts_status = f"{num_prompts} / {num_clips}"
            if num_prompts < num_clips:
                prompts_status += f"  ⚠️  НЕДОСТАЁТ {num_clips - num_prompts} промптов!"
            elif num_prompts == num_clips:
                prompts_status += "  ✓ ВСЕ ПРОМПТЫ СОЗДАНЫ"
            prompts_line = f"Промптов создано:       {prompts_status}\n"
        else:
            prompts_line = ""

        token_report = f"""
================================================================================
ОТЧЁТ ОБ ИСПОЛЬЗОВАНИИ ТОКЕНОВ
================================================================================
Проект: {project_name}
Модель: {self.model_name}
Дата: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
{prompts_line}
ТОКЕНЫ:
  Input:                  {cost_info['input_tokens']:>10,}   = ${cost_info['input_cost']:.5f}
  Output (text):          {cost_info['output_tokens']:>10,}   = ${cost_info['output_cost']:.5f}
  Output (thinking):      {cost_info['thinking_tokens']:>10,}   = ${cost_info['thinking_cost']:.5f}  (тариф output)
  ─────────────────────────────────────────────────
  Output всего:           {cost_info['total_output_tokens']:>10,}   = ${output_total_cost:.5f}
  ─────────────────────────────────────────────────
  ИТОГО:                                          ${cost_info['total_cost']:.5f}
================================================================================
"""
        log_path = output_dir / f'{project_name}_log.txt'
        with open(log_path, 'w', encoding='utf-8', errors='replace') as f:
            f.write(token_report)

        # Дописываем в общий run_log
        from modules.queue import append_run_log
        output_total_cost = cost_info['output_cost'] + cost_info['thinking_cost']
        append_run_log(output_dir, project_name, 'РЕЖИССУРА', {
            'Модель:':       self.model_name,
            'Клипов:':       num_clips,
            'Промптов:':     f'{num_prompts} / {num_clips}' if num_clips else num_prompts,
            'Input токены:': f"{cost_info['input_tokens']:,}   = ${cost_info['input_cost']:.5f}",
            'Output токены:':f"{cost_info['total_output_tokens']:,}   = ${output_total_cost:.5f}",
            'ИТОГО:':        f"${cost_info['total_cost']:.5f}",
        })

    def _update_cost_log(self, cost_info: dict, project_name: str) -> dict:
        """Обновляет накопленный лог затрат по текущему API ключу."""
        log_path = Path(__file__).parent.parent / 'cost_log.json'
        key_id = self.api_key[-8:] if len(self.api_key) >= 8 else self.api_key

        if log_path.exists():
            with open(log_path, 'r', encoding='utf-8') as f:
                log_data = json.load(f)
        else:
            log_data = {}

        if key_id not in log_data:
            log_data[key_id] = {
                'api_key_id': key_id,
                'total_cost': 0.0,
                'total_runs': 0,
                'runs': []
            }

        entry = log_data[key_id]
        entry['runs'].append({
            'timestamp':      datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'project':        project_name,
            'model':          self.model_name,
            'cost':           cost_info['total_cost'],
            'input_tokens':   cost_info['input_tokens'],
            'output_tokens':  cost_info['output_tokens'],
            'thinking_tokens': cost_info.get('thinking_tokens', 0),
        })
        entry['total_cost'] = round(entry['total_cost'] + cost_info['total_cost'], 8)
        entry['total_runs'] += 1

        with open(log_path, 'w', encoding='utf-8') as f:
            json.dump(log_data, f, ensure_ascii=False, indent=2)

        return entry

    # =========================================================================
    # ФОРМИРОВАНИЕ ПРОМПТОВ
    # =========================================================================

    def _create_prompt(
        self,
        transcription: Dict[str, Any],
        style_guide: str,
        project_name: str
    ) -> Tuple[str, str]:
        """Промпт для однопроходного режима (JSON + промпты за один вызов).
        Возвращает (sys_instr, user_content) для раздельной передачи в API."""
        prompts_dir = Path(__file__).parent.parent / 'prompts'
        with open(prompts_dir / 'director_instruction.txt', 'r', encoding='utf-8') as f:
            sys_instr = (f.read()
                .replace('{clip_min_dur}',   str(config.ACTIVE_CLIP_MIN_DURATION))
                .replace('{clip_max_dur}',   str(config.ACTIVE_CLIP_MAX_DURATION))
                .replace('{clip_intro_max_dur}', str(config.get_intro_clip_max()))
                .replace('{clip_intro_min_dur}', str(config.get_intro_clip_min()))
                .replace('{intro_block_dur}', str(config.INTRO_BLOCK_DURATION))
            )
        with open(prompts_dir / 'director_pause_guide.txt', 'r', encoding='utf-8') as f:
            sys_instr += '\n\n---\n\n' + f.read()

        audio_duration = transcription.get('audioDuration', 0)
        fragments = transcription.get('transcription', [])
        transcript_text = "\n".join([
            f"{i}. [{f['start']:.2f}-{f['end']:.2f}] {f['text']}"
            for i, f in enumerate(fragments, 1)
        ])

        user_content = f"""## 📥 ВХОДНЫЕ ДАННЫЕ

# ПРОЕКТ
Название: {project_name}

# ВИЗУАЛЬНЫЙ СТИЛЬ (Style Guide)
{style_guide}

# ТРАНСКРИПЦИЯ ОЗВУЧКИ
Длительность аудио: {audio_duration:.2f} секунд

{transcript_text}

---

## 🎬 НАЧИНАЙ АНАЛИЗ

Верни ответ ТОЛЬКО в этом формате:

```json
{{"montage_plan": ...}}
```

```text
=== PROMPTS.TXT ===
[промпт 1]
[промпт 2]
...
[промпт N]
```

**КРИТИЧЕСКИ ВАЖНО:**
- Количество промптов должно быть РАВНО количеству клипов в montage_plan.json
- Каждый промпт — ОДНА СТРОКА (без разрывов внутри)
- Каждый промпт начинается с новой строки
- НЕ объединяй несколько сцен в один промпт!
- Один клип = Один промпт

**НЕ возвращай director_analysis.md — он ОТКЛЮЧЕН!**
"""
        return sys_instr, user_content

    def _create_prompt_pass1(
        self,
        transcription: Dict[str, Any],
        style_guide: str,
        project_name: str
    ) -> Tuple[str, str]:
        """Промпт для прохода 1: только JSON монтажный план.
        Возвращает (sys_instr, user_content) для раздельной передачи в API."""
        prompts_dir = Path(__file__).parent.parent / 'prompts'
        with open(prompts_dir / 'director_instruction_pass1.txt', 'r', encoding='utf-8') as f:
            sys_instr = (f.read()
                .replace('{clip_min_dur}',   str(config.ACTIVE_CLIP_MIN_DURATION))
                .replace('{clip_max_dur}',   str(config.ACTIVE_CLIP_MAX_DURATION))
                .replace('{clip_intro_max_dur}', str(config.get_intro_clip_max()))
                .replace('{clip_intro_min_dur}', str(config.get_intro_clip_min()))
                .replace('{intro_block_dur}', str(config.INTRO_BLOCK_DURATION))
            )
        with open(prompts_dir / 'director_pause_guide.txt', 'r', encoding='utf-8') as f:
            sys_instr += '\n\n---\n\n' + f.read()

        audio_duration = transcription.get('audioDuration', 0)
        fragments = transcription.get('transcription', [])
        transcript_text = "\n".join([
            f"{i}. [{f['start']:.2f}-{f['end']:.2f}] {f['text']}"
            for i, f in enumerate(fragments, 1)
        ])

        user_content = f"""## 📥 ВХОДНЫЕ ДАННЫЕ

# ПРОЕКТ
Название: {project_name}

# ТРАНСКРИПЦИЯ ОЗВУЧКИ
Длительность аудио: {audio_duration:.2f} секунд

{transcript_text}

---

Верни ТОЛЬКО JSON монтажный план. Промпты для видео будут запрошены отдельно.
"""
        return sys_instr, user_content

    def _create_prompt_pass2(
        self,
        montage_plan: dict,
        transcription: Dict[str, Any],
        style_guide: str,
        project_name: str
    ) -> str:
        """Промпт для прохода 2: только промпты Veo3 на основе готового плана."""
        clips = montage_plan.get('clips', [])
        fragments = transcription.get('transcription', [])

        # Единые карточки: таймкод + озвучка в одном блоке (anti-drift)
        clip_cards = []
        for clip in clips:
            start = clip.get('startTime', 0)
            end   = clip.get('endTime', 0)
            texts = [
                f['text'] for f in fragments
                if f.get('start', 0) < end and f.get('end', 0) > start
            ]
            text = ' '.join(texts).strip() if texts else '(пауза)'
            clip_cards.append(
                f"[CLIP {clip['id']}] {start:.1f}–{end:.1f}с\n"
                f"ОЗВУЧКА: {text}\n"
                f"→ напиши промпт ТОЛЬКО под эту озвучку"
            )

        clip_block = '\n\n'.join(clip_cards)
        n = len(clips)

        return f"""Ты режиссёр визуального контента. На первом проходе ты создал монтажный план.
Теперь напиши Veo3-промпты для каждого клипа.

# ВИЗУАЛЬНЫЙ СТИЛЬ
{style_guide}

# КЛИПЫ (всего {n})

{clip_block}

---

ПРИВЯЗКА К ОЗВУЧКЕ — СТРОГО:
- Промпт для клипа N визуализирует ТОЛЬКО то, что звучит в озвучке этого клипа.
- НЕ забегай вперёд. НЕ показывай события из следующих клипов.
- Если в озвучке клипа N говорят о прогулке по парку — промпт N показывает парк, а НЕ сцену ресторана из клипа N+5.
- Обрабатывай каждый клип ИЗОЛИРОВАННО: прочитал озвучку → написал промпт → перешёл к следующему.

ВИЗУАЛЬНОЕ РАЗНООБРАЗИЕ — ОБЯЗАТЕЛЬНО:
- Если содержание текущей сцены похоже на предыдущую (похожая локация, действие, персонажи) — ОБЯЗАТЕЛЬНО смени ракурс: wide→close-up, другой угол, другой план.
- НИКОГДА не повторяй одинаковый визуальный образ для двух соседних клипов.
- Чередуй: общий план (Wide) → средний (Medium) → крупный (Close-up) → обратно.

Напиши ровно {n} промптов — по одному на каждый клип.
Каждый промпт — ОДНА СПЛОШНАЯ СТРОКА без переносов внутри.
Промпты разделяй ПУСТОЙ СТРОКОЙ.

Верни ответ ТОЛЬКО в этом формате:

```text
=== PROMPTS.TXT ===
[промпт для клипа 1]

[промпт для клипа 2]

...

[промпт для клипа {n}]
```

КРИТИЧЕСКИ ВАЖНО:
- Ровно {n} промптов
- Каждый промпт — ОДНА СТРОКА
- Разделяй ПУСТОЙ СТРОКОЙ между промптами
- НЕ добавляй нумерацию

САМОПРОВЕРКА — перед отправкой ответа пройди по чеклисту:
1. Количество промптов = {n}? Не больше, не меньше.
2. Промпт клипа N описывает ИМЕННО то, что звучит в озвучке клипа N? Нет забегания вперёд?
3. Нет двух соседних клипов с одинаковым ракурсом/планом?
4. Каждый промпт — одна сплошная строка без переносов?
5. Формат: промпты разделены пустой строкой, без нумерации?
"""

    def _create_prompt_continuation(
        self,
        montage_plan: dict,
        transcription: Dict[str, Any],
        style_guide: str,
        project_name: str,
        from_clip_id: int,
        to_clip_id: int,
        already_done: int,
        prev_prompts_sample: Optional[list] = None
    ) -> str:
        """Промпт для дополнения недостающих промптов (клипы from_clip_id..to_clip_id).
        prev_prompts_sample — последние N промптов для консистентности стиля."""
        clips = [c for c in montage_plan.get('clips', [])
                 if c['id'] >= from_clip_id and c['id'] <= to_clip_id]
        fragments = transcription.get('transcription', [])

        # Единые карточки: таймкод + озвучка в одном блоке (anti-drift)
        clip_cards = []
        for clip in clips:
            start = clip.get('startTime', 0)
            end   = clip.get('endTime', 0)
            texts = [f['text'] for f in fragments
                     if f.get('start', 0) < end and f.get('end', 0) > start]
            text = ' '.join(texts).strip() or '(пауза)'
            clip_cards.append(
                f"[CLIP {clip['id']}] {start:.1f}–{end:.1f}с\n"
                f"ОЗВУЧКА: {text}\n"
                f"→ напиши промпт ТОЛЬКО под эту озвучку"
            )

        clip_block = '\n\n'.join(clip_cards)
        n = len(clips)

        # Блок примеров стиля из предыдущих промптов (для консистентности)
        prev_sample_block = ""
        if prev_prompts_sample:
            sample_lines = '\n\n'.join(prev_prompts_sample)
            prev_sample_block = f"""
# ПРИМЕРЫ СТИЛЯ (последние промпты для консистентности)
Продолжай в том же формате и стиле описания:
{sample_lines}

"""

        return f"""Ты режиссёр визуального контента. Ты уже написал Veo3-промпты для клипов 1–{already_done}.
Теперь напиши промпты для оставшихся клипов {from_clip_id}–{to_clip_id}.

# ВИЗУАЛЬНЫЙ СТИЛЬ
{style_guide}
{prev_sample_block}
# КЛИПЫ {from_clip_id}–{to_clip_id}

{clip_block}

---

ПРИВЯЗКА К ОЗВУЧКЕ — СТРОГО:
- Промпт для клипа N визуализирует ТОЛЬКО то, что звучит в озвучке этого клипа.
- НЕ забегай вперёд. НЕ показывай события из следующих клипов.
- Если в озвучке клипа N говорят о прогулке по парку — промпт N показывает парк, а НЕ сцену ресторана из клипа N+5.
- Обрабатывай каждый клип ИЗОЛИРОВАННО: прочитал озвучку → написал промпт → перешёл к следующему.

ВИЗУАЛЬНОЕ РАЗНООБРАЗИЕ — ОБЯЗАТЕЛЬНО:
- Если содержание текущей сцены похоже на предыдущую (похожая локация, действие, персонажи) — ОБЯЗАТЕЛЬНО смени ракурс: wide→close-up, другой угол, другой план.
- НИКОГДА не повторяй одинаковый визуальный образ для двух соседних клипов.
- Чередуй: общий план (Wide) → средний (Medium) → крупный (Close-up) → обратно.

Напиши ровно {n} промптов — по одному на каждый клип ({from_clip_id}–{to_clip_id}).
Каждый промпт — ОДНА СПЛОШНАЯ СТРОКА без переносов внутри.
Промпты разделяй ПУСТОЙ СТРОКОЙ.

Верни ответ ТОЛЬКО в этом формате:

```text
=== PROMPTS.TXT ===
[промпт для клипа {from_clip_id}]

[промпт для клипа {from_clip_id + 1}]

...

[промпт для клипа {to_clip_id}]
```

КРИТИЧЕСКИ ВАЖНО:
- Ровно {n} промптов
- Каждый промпт — ОДНА СТРОКА
- Разделяй ПУСТОЙ СТРОКОЙ между промптами
- НЕ добавляй нумерацию

САМОПРОВЕРКА — перед отправкой ответа пройди по чеклисту:
1. Количество промптов = {n}? Не больше, не меньше.
2. Промпт клипа N описывает ИМЕННО то, что звучит в озвучке клипа N? Нет забегания вперёд?
3. Нет двух соседних клипов с одинаковым ракурсом/планом?
4. Каждый промпт — одна сплошная строка без переносов?
5. Формат: промпты разделены пустой строкой, без нумерации?
"""

    def _create_prompt_chunk(
        self,
        chunk_clips: list,
        transcription: Dict[str, Any],
        style_guide: str,
        from_id: int,
        to_id: int,
        total_clips: int,
        is_continuation: bool = False,
        already_done: int = 0,
        prev_prompts_sample: Optional[list] = None,
        prev_plot_context: Optional[str] = None
    ) -> str:
        """Промпт для одного чанка прохода 2 (from_id..to_id из total_clips).
        prev_prompts_sample — последние N промптов из предыдущего чанка для консистентности стиля.
        prev_plot_context — текст предыдущего сюжета (описание сцен, озвучка) для поддержания контекста.
        """
        fragments = transcription.get('transcription', [])

        # Единые карточки: таймкод + озвучка в одном блоке (anti-drift)
        clip_cards = []
        for clip in chunk_clips:
            start = clip.get('startTime', 0)
            end   = clip.get('endTime', 0)
            texts = [f['text'] for f in fragments
                     if f.get('start', 0) < end and f.get('end', 0) > start]
            text = ' '.join(texts).strip() or '(пауза)'
            clip_cards.append(
                f"[CLIP {clip['id']}] {start:.1f}–{end:.1f}с\n"
                f"ОЗВУЧКА: {text}\n"
                f"→ напиши промпт ТОЛЬКО под эту озвучку"
            )

        clip_block = '\n\n'.join(clip_cards)
        n = len(chunk_clips)

        if is_continuation:
            header = (
                f"Ты режиссёр визуального контента. Ты уже написал Veo3-промпты для клипов 1–{already_done}.\n"
                f"Теперь напиши промпты для оставшихся клипов {from_id}–{to_id}."
            )
        elif from_id == 1 and to_id == total_clips:
            header = "Ты режиссёр визуального контента. На первом проходе ты создал монтажный план.\nТеперь напиши Veo3-промпты для каждого клипа."
        else:
            header = (
                f"Ты режиссёр визуального контента. На первом проходе ты создал монтажный план.\n"
                f"Теперь напиши Veo3-промпты для клипов {from_id}–{to_id} (часть {from_id}–{to_id} из {total_clips})."
            )

        # Блок сюжетного контекста — что уже было визуализировано
        prev_plot_block = ""
        if prev_plot_context:
            prev_plot_block = f"""
# ПРЕДЫДУЩИЙ СЮЖЕТ (что уже было визуализировано в предыдущих частях)
Учитывай этот контекст при создании промптов — персонажи, события, детали должны быть консистентны:
{prev_plot_context}

"""

        # Блок примеров из предыдущего чанка — для консистентности стиля
        prev_sample_block = ""
        if prev_prompts_sample:
            sample_lines = '\n\n'.join(prev_prompts_sample)
            prev_sample_block = f"""
# ПРИМЕРЫ СТИЛЯ (последние промпты предыдущей части — для консистентности)
Продолжай в том же формате и стиле описания:
{sample_lines}

"""

        return f"""{header}

# ВИЗУАЛЬНЫЙ СТИЛЬ
{style_guide}
{prev_plot_block}{prev_sample_block}
# КЛИПЫ {from_id}–{to_id}

{clip_block}

---

ПРИВЯЗКА К ОЗВУЧКЕ — СТРОГО:
- Промпт для клипа N визуализирует ТОЛЬКО то, что звучит в озвучке этого клипа.
- НЕ забегай вперёд. НЕ показывай события из следующих клипов.
- Если в озвучке клипа N говорят о прогулке по парку — промпт N показывает парк, а НЕ сцену ресторана из клипа N+5.
- Обрабатывай каждый клип ИЗОЛИРОВАННО: прочитал озвучку → написал промпт → перешёл к следующему.

ВИЗУАЛЬНОЕ РАЗНООБРАЗИЕ — ОБЯЗАТЕЛЬНО:
- Если содержание текущей сцены похоже на предыдущую (похожая локация, действие, персонажи) — ОБЯЗАТЕЛЬНО смени ракурс: wide→close-up, другой угол, другой план.
- НИКОГДА не повторяй одинаковый визуальный образ для двух соседних клипов.
- Чередуй: общий план (Wide) → средний (Medium) → крупный (Close-up) → обратно.

Напиши ровно {n} промптов — по одному на каждый клип ({from_id}–{to_id}).
Каждый промпт — ОДНА СПЛОШНАЯ СТРОКА без переносов внутри.
Промпты разделяй ПУСТОЙ СТРОКОЙ.

Верни ответ ТОЛЬКО в этом формате:

```text
=== PROMPTS.TXT ===
[промпт для клипа {from_id}]

[промпт для клипа {from_id + 1 if n > 1 else from_id}]

...

[промпт для клипа {to_id}]
```

КРИТИЧЕСКИ ВАЖНО:
- Ровно {n} промптов
- Каждый промпт — ОДНА СТРОКА
- Разделяй ПУСТОЙ СТРОКОЙ между промптами
- НЕ добавляй нумерацию

САМОПРОВЕРКА — перед отправкой ответа пройди по чеклисту:
1. Количество промптов = {n}? Не больше, не меньше.
2. Промпт клипа N описывает ИМЕННО то, что звучит в озвучке клипа N? Нет забегания вперёд?
3. Нет двух соседних клипов с одинаковым ракурсом/планом?
4. Каждый промпт — одна сплошная строка без переносов?
5. Формат: промпты разделены пустой строкой, без нумерации?
"""

    @staticmethod
    def _make_filler_clips(start: float, end: float) -> list:
        """Нарезает диапазон start→end на равные клипы длиной 5–10с (target 7.5с)."""
        gap = end - start
        if gap <= 0:
            return []
        _TARGET = 7.5
        n = max(1, round(gap / _TARGET))
        # Корректируем n чтобы длительность оставалась в 5–10с
        while n > 1 and gap / n < 5:
            n -= 1
        while gap / (n + 1) >= 5:
            n += 1
        dur = gap / n
        fillers = []
        for j in range(n):
            fs = round(start + j * dur, 3)
            fe = round(start + (j + 1) * dur, 3)
            fillers.append({'id': 0, 'file': 'vid_img/0.mp4',
                            'startTime': fs, 'endTime': fe})
        return fillers

    def _autofix_merged_clips(self, clips: list, total_duration: float):
        """
        Авто-починка таймингов после мёржа чанков Pass 1.
        Устраняет гэпы и перекрытия на стыках, фиксирует первый/последний клип.
        Большие гэпы (> max_clip_dur*2) заполняются филлер-клипами 5–10с
        (Pass 2 промптирует их по транскрипции).
        Возвращает (fixed_clips, fixes_log: list[str]).
        """
        if not clips:
            return clips, []

        fixes = []
        _gap_max = config.ACTIVE_CLIP_MAX_DURATION * 2  # порог: 16с по умолчанию

        # 1. Первый клип должен начинаться с 0.0
        if clips[0].get('startTime', 0) > 0.05:
            old = clips[0]['startTime']
            clips[0]['startTime'] = 0.0
            fixes.append(f"Clip {clips[0]['id']}: startTime {old:.3f}→0.000 (first clip)")

        # 2. Прогон по парам: собираем new_clips (для вставки филлеров)
        new_clips = [clips[0]]
        for i in range(1, len(clips)):
            prev, curr = new_clips[-1], clips[i]
            gap = round(curr['startTime'] - prev['endTime'], 3)

            if gap > _gap_max:
                # Большой гэп → филлер-клипы
                fillers = self._make_filler_clips(prev['endTime'], curr['startTime'])
                new_clips.extend(fillers)
                fixes.append(
                    f"Clip {prev['id']}→{curr['id']}: gap {gap:.1f}s → "
                    f"{len(fillers)} filler clips ({gap/len(fillers):.1f}s each)"
                )
                new_clips.append(curr)
            elif gap > 0.05:
                # Малый гэп → растянуть предыдущий клип
                fixes.append(
                    f"Clip {prev['id']}→{curr['id']}: gap {gap:.3f}s → "
                    f"extend clip {prev['id']} endTime {prev['endTime']:.3f}→{curr['startTime']:.3f}"
                )
                prev['endTime'] = curr['startTime']
                new_clips.append(curr)
            elif gap < -0.05:
                # Перекрытие → сдвинуть текущий клип
                old_start = curr['startTime']
                curr['startTime'] = prev['endTime']
                if curr['endTime'] <= curr['startTime']:
                    curr['endTime'] = round(curr['startTime'] + 1.0, 3)
                fixes.append(
                    f"Clip {prev['id']}→{curr['id']}: overlap {abs(gap):.3f}s → "
                    f"move clip {curr['id']} startTime {old_start:.3f}→{curr['startTime']:.3f}"
                )
                new_clips.append(curr)
            else:
                new_clips.append(curr)

        # 3. Последний клип → total_duration
        last = new_clips[-1]
        end_gap = round(total_duration - last.get('endTime', 0), 3)
        if end_gap > _gap_max:
            # Большой хвост → филлер-клипы
            fillers = self._make_filler_clips(last['endTime'], total_duration)
            new_clips.extend(fillers)
            fixes.append(
                f"Clip {last['id']}: end gap {end_gap:.1f}s → "
                f"{len(fillers)} filler clips ({end_gap/len(fillers):.1f}s each)"
            )
        elif end_gap > 0.1:
            old = last['endTime']
            last['endTime'] = round(total_duration, 3)
            fixes.append(f"Clip {last['id']}: endTime {old:.3f}→{total_duration:.3f} (last clip)")

        return new_clips, fixes

    def _run_pass1_chunked(
        self,
        transcription: Dict[str, Any],
        style_guide: str,
        output_dir: Path,
        project_name: str,
    ) -> Tuple[dict, list]:
        """
        Pass 1 с чанкованием транскрипции — для озвучек длиннее DIRECTOR_PASS1_CHUNK_THRESHOLD.
        Делит аудио на чанки по DIRECTOR_PASS1_CHUNK_DURATION секунд, для каждого запускает
        отдельный Gemini-запрос, затем мержит результаты в единый montage_plan.
        Возвращает (merged_montage_plan, all_costs).
        """
        fragments = transcription.get('transcription', [])
        total_duration = transcription.get('audioDuration', 0)
        chunk_dur = config.DIRECTOR_PASS1_CHUNK_DURATION
        total_chunks = math.ceil(total_duration / chunk_dur)

        # sys_instr одинаков для всех чанков — загружаем один раз через холостой вызов
        sys_instr1, _ = self._create_prompt_pass1(transcription, style_guide, project_name)

        all_costs: list = []
        all_clips: list = []
        id_offset = 0

        def _fb_model(m: str) -> str | None:
            """Fallback model chain (copy of _gemini_fallback_model from _make_api_call)."""
            ml = m.lower()
            if 'gemini-3' in ml:
                return 'gemini-2.5-pro'
            if '2.5-pro' in ml:
                return 'gemini-3.1-pro-preview'
            return None

        for chunk_idx in range(total_chunks):
            chunk_start = chunk_idx * chunk_dur
            chunk_end = min(chunk_start + chunk_dur, total_duration)
            chunk_num = chunk_idx + 1
            chunk_dur_actual = chunk_end - chunk_start

            print(f"\n🎬 Pass 1 — чанк {chunk_num}/{total_chunks}: "
                  f"{chunk_start/60:.1f}–{chunk_end/60:.1f} мин "
                  f"({chunk_dur_actual/60:.0f} мин)...")

            # Quality constants (одинаковы для всех подчанков)
            _cmin = config.ACTIVE_CLIP_MIN_DURATION
            _cmax = config.ACTIVE_CLIP_MAX_DURATION
            _dur_tol = 3.0  # допуск сверх min/max

            def _chunk_quality_issues(clips):
                """Возвращает список проблем (строки) или пустой список если всё OK."""
                issues = []
                dur_bad = [
                    f"#{c.get('id')} dur={round(c['endTime']-c['startTime'],2)}s"
                    for c in clips
                    if (c['endTime'] - c['startTime']) < _cmin - _dur_tol
                    or (c['endTime'] - c['startTime']) > _cmax + _dur_tol
                ]
                if dur_bad:
                    issues.append(f"duration violations (>{_dur_tol}s off): {', '.join(dur_bad[:5])}")
                id_bad = [
                    f"pos {i+1} id={c.get('id')}"
                    for i, c in enumerate(clips) if c.get('id') != i + 1
                ]
                if id_bad:
                    issues.append(f"ID sequence broken: {', '.join(id_bad[:5])}")
                # Проверка покрытия: клипы ≥80% длительности подчанка
                if clips and chunk_dur_actual > 0:
                    _last_end = clips[-1].get('endTime', 0)
                    _cov = _last_end / chunk_dur_actual
                    if _cov < 0.8:
                        issues.append(
                            f"coverage {_last_end:.0f}/{chunk_dur_actual:.0f}s "
                            f"({_cov:.0%}) — Gemini did not cover the chunk"
                        )
                return issues

            def _offset_clips(clips_list, offset_time):
                """Offset local-time clips to global + renumber + clamp."""
                for i, clip in enumerate(clips_list):
                    new_id = id_offset + i + 1
                    clip['id']        = new_id
                    clip['file']      = f'vid_img/{new_id}.mp4'
                    clip['startTime'] = round(clip.get('startTime', 0) + offset_time, 3)
                    clip['endTime']   = round(clip.get('endTime',   0) + offset_time, 3)
                    clip['startTime'] = max(clip['startTime'], offset_time)
                    clip['endTime']   = min(clip['endTime'],   chunk_end)
                    if clip['endTime'] <= clip['startTime']:
                        clip['endTime'] = round(clip['startTime'] + 1.0, 3)

            # ── Sub-chunking loop ──────────────────────────────────────
            _MAX_SUB_ITER = 5
            sub_start = chunk_start
            _stall_count = 0
            _using_fallback = False
            _orig_model = self.model_name

            for _sub_iter in range(_MAX_SUB_ITER):
                chunk_dur_actual = chunk_end - sub_start  # эффективная длительность подчанка
                if chunk_dur_actual <= 0:
                    break

                if _sub_iter > 0:
                    print(f"\n   🔄 Подчанк {_sub_iter + 1}/{_MAX_SUB_ITER}: "
                          f"{sub_start/60:.1f}–{chunk_end/60:.1f} мин "
                          f"({chunk_dur_actual/60:.0f} мин остаток)...")

                # Фрагменты для sub_start → chunk_end
                chunk_fragments_raw = [
                    f for f in fragments
                    if f.get('end', 0) > sub_start and f.get('start', 0) < chunk_end
                ]
                if not chunk_fragments_raw:
                    logging.warning(f"Pass 1 chunk {chunk_num} sub {_sub_iter}: no fragments, skipping")
                    print(f"   ⚠️  Нет фрагментов в диапазоне — пропуск")
                    break

                # Нормализуем к началу подчанка (sub_start → 0)
                chunk_fragments = [
                    {
                        **f,
                        'start': round(f['start'] - sub_start, 3),
                        'end':   round(min(f['end'], chunk_end) - sub_start, 3),
                    }
                    for f in chunk_fragments_raw
                ]
                chunk_transcription = {
                    'transcription': chunk_fragments,
                    'audioDuration':  chunk_dur_actual,
                    'language':       transcription.get('language'),
                }

                _, chunk_user_content = self._create_prompt_pass1(
                    chunk_transcription, style_guide, project_name
                )
                chunk_note = (
                    f"\n\n📌 ВАЖНО: это чанк {chunk_num}/{total_chunks} полного аудио "
                    f"({sub_start:.1f}–{chunk_end:.1f}с). "
                    f"Таймкоды нормализованы: 0.00 соответствует {sub_start:.1f}с от начала. "
                    f"audioDuration = {chunk_dur_actual:.2f}с. Генерируй клипы строго в этом диапазоне."
                )
                chunk_user_content += chunk_note

                _sub_label = f"чанк {chunk_num}/{total_chunks}" + (f" подчанк {_sub_iter+1}" if _sub_iter else "")
                print(f"🤖 Отправка запроса к Gemini ({self.model_name})...")
                response, cost = self._make_api_call(
                    chunk_user_content, system_instruction=sys_instr1,
                    spinner_msg=f"Gemini Pass 1 {_sub_label}"
                )
                self._print_cost(cost, label=f"Pass 1 {_sub_label}")
                if cost:
                    all_costs.append(cost)

                _raw_suffix = f'_pass1_chunk{chunk_num}' + (f'_sub{_sub_iter+1}' if _sub_iter else '')
                _save_raw_response(output_dir, response.text, suffix=_raw_suffix)

                print(f"\n📝 Парсинг плана ({_sub_label})...")
                partial_plan = self._parse_json_only(
                    response.text, output_dir, chunk_transcription, pass_num=1, project_name=project_name
                )

                # Quality retry loop (до 3 попыток на каждый подчанк)
                for _retry in range(1, 4):
                    clips_now = partial_plan.get('clips', [])
                    if not clips_now:
                        reason = "empty plan"
                    else:
                        issues = _chunk_quality_issues(clips_now)
                        if not issues:
                            break
                        reason = "; ".join(issues)

                    if _retry == 3:
                        logging.warning(f"Pass 1 {_sub_label}: quality issues after 3 attempts: {reason}")
                        print(f"\n⚠️  {_sub_label}: качество не улучшилось после 3 попыток. Продолжаем.")
                        break

                    logging.warning(f"Pass 1 {_sub_label}: retry {_retry}/3 — {reason}")
                    print(f"\n⚠️  {_sub_label} — проблемы качества ({reason}). Повтор {_retry}/3...")
                    if project_name:
                        from modules.queue import append_run_log
                        append_run_log(output_dir, project_name, f'ЧАНК-{chunk_num}-SUB{_sub_iter+1}-ПОВТОР-{_retry}', {
                            'причина': reason,
                        })
                    response, cost_retry = self._make_api_call(
                        chunk_user_content, system_instruction=sys_instr1,
                        spinner_msg=f"Gemini retry {_sub_label} ({_retry}/3)"
                    )
                    self._print_cost(cost_retry, label=f"retry {_sub_label} ({_retry}/3)")
                    if cost_retry:
                        all_costs.append(cost_retry)
                    _save_raw_response(output_dir, response.text,
                                       suffix=f'{_raw_suffix}_retry{_retry}')
                    partial_plan = self._parse_json_only(
                        response.text, output_dir, chunk_transcription, pass_num=1, project_name=project_name
                    )

                # ── Проверка покрытия и решение о подчанковании ──────
                partial_clips = partial_plan.get('clips', [])

                if not partial_clips:
                    # 0 клипов → курсор не двигается, retry того же подчанка
                    _stall_count += 1
                    logging.warning(f"Pass 1 {_sub_label}: 0 clips, stall {_stall_count}")
                    # Layer 3: фолбек модели при стагнации
                    if _stall_count >= 2 and not _using_fallback:
                        _fb = _fb_model(self.model_name)
                        if _fb:
                            print(f"\n   🔄 Стагнация — фолбек: {self.model_name} → {_fb}")
                            logging.warning(f"Pass 1 {_sub_label}: stall fallback {self.model_name} → {_fb}")
                            self.model_name = _fb
                            _using_fallback = True
                    continue

                last_end_local = partial_clips[-1].get('endTime', 0)

                if last_end_local >= chunk_dur_actual * 0.8:
                    # Покрытие OK → offset все клипы, добавить, выйти из sub-loop
                    _offset_clips(partial_clips, sub_start)
                    all_clips.extend(partial_clips)
                    id_offset += len(partial_clips)
                    _stall_count = 0
                    break
                else:
                    # Частичное покрытие: сохраняем 80%, двигаем курсор
                    trim_local = last_end_local * 0.8
                    kept = [c for c in partial_clips if c.get('startTime', 0) < trim_local]
                    if not kept:
                        kept = partial_clips[:1]  # хотя бы один клип

                    _offset_clips(kept, sub_start)
                    all_clips.extend(kept)
                    id_offset += len(kept)

                    new_sub_start = kept[-1]['endTime']  # глобальное время
                    if new_sub_start <= sub_start + 1.0:
                        _stall_count += 1
                    else:
                        _stall_count = 0
                    sub_start = new_sub_start

                    _cov_pct = last_end_local / chunk_dur_actual
                    print(f"   ⚠️  Покрытие {_cov_pct:.0%} ({last_end_local:.0f}/{chunk_dur_actual:.0f}с) — "
                          f"сохранено {len(kept)} клипов, продолжаем с {sub_start:.1f}с...")
                    logging.info(f"Pass 1 {_sub_label}: partial coverage {_cov_pct:.0%}, "
                                 f"kept {len(kept)} clips, new sub_start={sub_start:.1f}")

                    # Layer 3: фолбек при >3 итераций или стагнации
                    if (_stall_count >= 2 or _sub_iter >= 3) and not _using_fallback:
                        _fb = _fb_model(self.model_name)
                        if _fb:
                            print(f"\n   🔄 {'Стагнация' if _stall_count >= 2 else '>3 подчанков'}"
                                  f" — фолбек: {self.model_name} → {_fb}")
                            logging.warning(f"Pass 1 {_sub_label}: fallback {self.model_name} → {_fb}")
                            self.model_name = _fb
                            _using_fallback = True

            # Восстановить модель после подчанкования
            if _using_fallback:
                self.model_name = _orig_model

            logging.info(f"Pass 1 chunk {chunk_num} done: total clips={id_offset}")
            print(f"   → Чанк {chunk_num}: всего накоплено клипов: {id_offset}")
            print(f"PROGRESS:{chunk_num}/{total_chunks}", flush=True)

        # Мёрж
        merged_clips = all_clips

        # --- Авто-починка таймингов ---
        merged_clips, fixes = self._autofix_merged_clips(merged_clips, total_duration)
        if fixes:
            print(f"\n🔧 Авто-починка таймингов ({len(fixes)} правок):")
            for fix in fixes:
                print(f"   • {fix}")
            logging.info(f"Pass 1 merge autofix: {len(fixes)} fixes")
            for fix in fixes:
                logging.info(f"  AUTOFIX: {fix}")
        else:
            print(f"\n✅ Тайминги стыков: всё OK")

        # --- Проверка ID последовательности ---
        id_problems = check_clip_id_sequence(merged_clips)
        if id_problems:
            logging.warning(f"Pass 1 merge: {len(id_problems)} ID sequence problems — renumbering")
            print(f"\n⚠️  Сбой нумерации ({len(id_problems)} позиций) — перенумеровываю...")
            for i, clip in enumerate(merged_clips):
                clip['id']   = i + 1
                clip['file'] = f'vid_img/{i + 1}.mp4'
            print(f"   ✓ Перенумерация завершена: 1..{len(merged_clips)}")

        # --- Итоговая валидация ---
        is_valid, val_errors = validate_montage_plan_json(
            {'audioDuration': total_duration, 'clips': merged_clips}, total_duration
        )
        if val_errors:
            print(f"\n⚠️  Остаточные предупреждения валидации ({len(val_errors)}):")
            for e in val_errors:
                print(f"   • {e}")
            logging.warning(f"Pass 1 merge validation warnings: {val_errors}")

        # --- Запись в общий run_log ---
        from modules.queue import append_run_log
        autofix_summary = f"{len(fixes)} правок" if fixes else "OK"
        id_fix_summary  = f"перенумеровано {len(merged_clips)} клипов" if id_problems else "OK"
        val_summary     = f"{len(val_errors)} предупреждений" if val_errors else "OK"
        append_run_log(output_dir, project_name, 'ЧАНК-МЁРЖ', {
            'Чанков:':         total_chunks,
            'Клипов итого:':   len(merged_clips),
            'Тайминги (autofix):': autofix_summary,
            'Нумерация (autofix):': id_fix_summary,
            'Валидация:':      val_summary,
        })
        if fixes:
            # Пишем детали правок отдельными строками в run_log
            append_run_log(output_dir, project_name, 'AUTOFIX-ДЕТАЛИ', {
                f'fix_{i+1}': fix for i, fix in enumerate(fixes)
            })
        if val_errors:
            append_run_log(output_dir, project_name, 'ВАЛИДАЦИЯ-ДЕТАЛИ', {
                f'warn_{i+1}': e for i, e in enumerate(val_errors)
            })

        merged = {
            'audioDuration': total_duration,
            'clips': merged_clips,
        }
        merged_path = output_dir / 'montage_plan.json'
        with open(merged_path, 'w', encoding='utf-8') as f:
            json.dump(merged, f, ensure_ascii=False, indent=2)

        print(f"\n✅ Pass 1 завершён: {len(merged_clips)} клипов из {total_chunks} чанков")
        print(f"   ✓ montage_plan.json сохранён ({merged_path})")
        return merged, all_costs

    # =========================================================================

    def _run_pass2(
        self,
        montage_plan: dict,
        transcription: Dict[str, Any],
        style_guide: str,
        project_name: str,
        output_dir: Path,
        pass_label: str = "2/2",
        resume_path: Optional[str] = None,
    ) -> Tuple[Dict[str, Any], list]:
        """
        Выполняет проход 2 (генерация промптов) с динамическим курсором.
        Каждый следующий чанк начинается с того места, где закончился предыдущий.
        Дырки невозможны — если чанк недоделал, следующий подхватит.
        Continuation (is_continuation) используется только для последнего хвоста.
        """
        clips = montage_plan.get('clips', [])
        total_clips = len(clips)
        chunk_size = config.PROMPT_CHUNK_SIZE if config.PROMPT_CHUNK_SIZE > 0 else total_clips

        all_costs = []
        main_prompts_path = None
        total_prompts = 0
        MAX_CONTINUATION = 3
        PREV_SAMPLE_SIZE = 5

        cursor = 0
        chunk_idx = 0

        # Resume: загружаем уже готовые промпты и выставляем курсор
        if resume_path:
            _rp = Path(resume_path)
            if _rp.exists():
                _existing_text = _rp.read_text(encoding='utf-8')
                _existing_count = len([c.strip() for c in _existing_text.split('\n\n') if c.strip()])
                if _existing_count > 0 and _existing_count < total_clips:
                    cursor = _existing_count
                    total_prompts = _existing_count
                    main_prompts_path = _rp
                    print(f"\n🔄 RESUME: {_existing_count} промптов уже готово, продолжаем с клипа {cursor + 1}/{total_clips}")
                    logging.info(f"Pass 2 resume: {_existing_count} existing prompts, cursor={cursor}")

        print(f"PROGRESS:{cursor}/{total_clips}", flush=True)

        while cursor < total_clips:
            chunk_end = min(cursor + chunk_size, total_clips)
            chunk_clips = clips[cursor:chunk_end]
            from_id = chunk_clips[0]['id']
            to_id = chunk_clips[-1]['id']
            is_last_chunk = (chunk_end >= total_clips)
            chunk_label = f"чанк {chunk_idx + 1}" if total_clips > chunk_size else ""

            if chunk_label:
                print(f"\n✍️  ПРОХОД {pass_label}: Генерация промптов — {chunk_label} (клипы {from_id}–{to_id})...")
            else:
                print(f"\n✍️  ПРОХОД {pass_label}: Генерация промптов ({total_clips} шт)...")
            print(f"🤖 Отправка запроса к Gemini ({self.model_name})...")
            logging.info(f"Pass 2 chunk {chunk_idx + 1}: clips {from_id}-{to_id} ({len(chunk_clips)} clips), cursor={cursor}")

            # Берём последние PREV_SAMPLE_SIZE промптов для консистентности стиля
            prev_sample = None
            if cursor > 0 and main_prompts_path and main_prompts_path.exists():
                prev_text = main_prompts_path.read_text(encoding='utf-8')
                prev_all = [c.strip() for c in prev_text.split('\n\n') if c.strip()]
                if prev_all:
                    prev_sample = prev_all[-PREV_SAMPLE_SIZE:]

            # Собираем сюжетный контекст — только последние PREV_SAMPLE_SIZE клипов
            # (весь контекст путает Gemini и она промптит по нарративу вместо стайлгайда)
            prev_plot_context = None
            if cursor > 0:
                fragments = transcription.get('transcription', [])
                done_clips = clips[max(0, cursor - PREV_SAMPLE_SIZE):cursor]
                plot_lines = []
                for c in done_clips:
                    cs = c.get('startTime', 0)
                    ce = c.get('endTime', 0)
                    texts = [f['text'] for f in fragments
                             if f.get('start', 0) < ce and f.get('end', 0) > cs]
                    text = ' '.join(texts).strip() or '(пауза)'
                    plot_lines.append(f"Клип {c['id']} ({cs:.1f}-{ce:.1f}с): {text}")
                prev_plot_context = '\n'.join(plot_lines)

            chunk_montage = {'clips': chunk_clips}
            prompt2 = self._create_prompt_chunk(
                chunk_clips, transcription, style_guide,
                from_id=from_id, to_id=to_id, total_clips=total_clips,
                prev_prompts_sample=prev_sample,
                prev_plot_context=prev_plot_context
            )
            spinner_msg = f"Gemini думает (проход {pass_label}{', ' + chunk_label if chunk_label else ''})"
            response2, cost2 = self._make_api_call(prompt2, pass2_mode=True, spinner_msg=spinner_msg)
            self._print_cost(cost2, label=f"прохода {pass_label}{' ' + chunk_label if chunk_label else ''}")

            if cost2:
                all_costs.append(cost2)

            # Обработка пустого ответа от Gemini
            if not response2 or not response2.text:
                logging.error(f"Chunk {chunk_idx + 1}: Gemini returned empty response")
                print(f"   ❌ Gemini вернул пустой ответ на чанк {chunk_idx + 1}")
                break

            _save_raw_response(output_dir, response2.text,
                               suffix=f'_pass2_chunk{chunk_idx + 1}' if total_clips > chunk_size else '_pass2')

            print("\n📝 Парсинг промптов...")
            chunk_results = self._parse_prompts_only(response2.text, output_dir, chunk_montage, project_name)
            chunk_path = chunk_results.get('prompts')
            chunk_prompts = chunk_results.get('num_prompts', 0)

            logging.info(f"Pass 2 chunk {chunk_idx + 1} done: {chunk_prompts}/{len(chunk_clips)} prompts")

            # Overprompt retry
            if chunk_prompts > len(chunk_clips):
                logging.info(f"Chunk {chunk_idx + 1} overprompt: {chunk_prompts}/{len(chunk_clips)}, retrying...")
                print(f"\n🔁 Overprompt: {chunk_prompts}/{len(chunk_clips)} — перезапрос...")
                print(f"🤖 Отправка запроса к Gemini ({self.model_name})...")

                if chunk_path and chunk_path.exists():
                    chunk_path.unlink()

                spinner_retry = f"Gemini переделывает {chunk_label or 'промпты'} (overprompt retry)"
                response2_retry, cost2_retry = self._make_api_call(prompt2, pass2_mode=True, spinner_msg=spinner_retry)
                self._print_cost(cost2_retry, label=f"retry {chunk_label or 'промптов'}")

                if response2_retry and response2_retry.text:
                    _save_raw_response(output_dir, response2_retry.text,
                                       suffix=f'_pass2_chunk{chunk_idx + 1}_retry')
                    retry_results = self._parse_prompts_only(response2_retry.text, output_dir, chunk_montage, project_name)
                    chunk_path = retry_results.get('prompts')
                    chunk_prompts = retry_results.get('num_prompts', 0)

                if cost2_retry:
                    all_costs.append(cost2_retry)

                if chunk_prompts > len(chunk_clips):
                    extra = chunk_prompts - len(chunk_clips)
                    logging.warning(f"Chunk {chunk_idx + 1} still overprompt: trimming {extra}")
                    print(f"   ✂️  Fallback trim -{extra}.")
                    if chunk_path and chunk_path.exists():
                        full_text = chunk_path.read_text(encoding='utf-8')
                        all_p = [c.strip() for c in full_text.split('\n\n') if c.strip()]
                        chunk_path.write_text('\n\n'.join(all_p[:len(chunk_clips)]), encoding='utf-8')
                        chunk_prompts = len(chunk_clips)
                elif chunk_prompts == len(chunk_clips):
                    print(f"   ✓ Retry успешен: {chunk_prompts}/{len(chunk_clips)}")

            # Rollback для НЕ-последних чанков (даже полных — "уставшие" промпты в конце)
            if not is_last_chunk and chunk_prompts > 0:
                _rollback = config.CONT_ROLLBACK_SIZE
                if _rollback > 0 and chunk_prompts > _rollback \
                        and chunk_path and chunk_path.exists():
                    rollback_to = chunk_prompts - _rollback
                    _full = chunk_path.read_text(encoding='utf-8')
                    _kept = [c.strip() for c in _full.split('\n\n') if c.strip()][:rollback_to]
                    chunk_path.write_text('\n\n'.join(_kept), encoding='utf-8')
                    status = "полный" if chunk_prompts >= len(chunk_clips) else "неполный"
                    print(f"   ↩️  Rollback ({status} чанк): удалены #{from_id + rollback_to}–#{from_id + chunk_prompts - 1} "
                          f"({chunk_prompts - rollback_to} шт), следующий чанк перегенерирует")
                    chunk_prompts = rollback_to

            # Continuation ТОЛЬКО для последнего чанка (хвост)
            if is_last_chunk and chunk_prompts < len(chunk_clips):
                for cont_attempt in range(1, MAX_CONTINUATION + 1):
                    if chunk_prompts >= len(chunk_clips):
                        break

                    # Rollback на первой попытке
                    _rollback = config.CONT_ROLLBACK_SIZE
                    if cont_attempt == 1 and _rollback > 0 and chunk_prompts > _rollback \
                            and chunk_path and chunk_path.exists():
                        rollback_to = chunk_prompts - _rollback
                        _full = chunk_path.read_text(encoding='utf-8')
                        _kept = [c.strip() for c in _full.split('\n\n') if c.strip()][:rollback_to]
                        chunk_path.write_text('\n\n'.join(_kept), encoding='utf-8')
                        print(f"   ↩️  Rollback: удалены #{from_id + rollback_to}–#{from_id + chunk_prompts - 1} ({_rollback} шт)")
                        chunk_prompts = rollback_to

                    missing = len(chunk_clips) - chunk_prompts
                    cont_from_id = from_id + chunk_prompts
                    logging.info(f"Last chunk continuation {cont_attempt}/{MAX_CONTINUATION}: clips {cont_from_id}-{to_id}")
                    print(f"\n🔁 Авто-дополнение ({cont_attempt}/{MAX_CONTINUATION}): "
                          f"клипы {cont_from_id}–{to_id} ({missing} шт)...")
                    print(f"🤖 Отправка запроса к Gemini ({self.model_name})...")

                    cont_clips = [c for c in chunk_clips if c['id'] >= cont_from_id and c['id'] <= to_id]

                    # Примеры стиля для continuation (из уже написанных промптов)
                    cont_prev_sample = None
                    _cont_src = chunk_path if chunk_path and chunk_path.exists() else main_prompts_path
                    if _cont_src and _cont_src.exists():
                        _cont_all = [c.strip() for c in _cont_src.read_text(encoding='utf-8').split('\n\n') if c.strip()]
                        if _cont_all:
                            cont_prev_sample = _cont_all[-PREV_SAMPLE_SIZE:]

                    # Сюжетный контекст для continuation (только последние PREV_SAMPLE_SIZE клипов)
                    cont_plot_context = None
                    _cont_end = cursor + chunk_prompts
                    cont_done_clips = clips[max(0, _cont_end - PREV_SAMPLE_SIZE):_cont_end]
                    if cont_done_clips:
                        fragments = transcription.get('transcription', [])
                        cont_plot_lines = []
                        for c in cont_done_clips:
                            cs = c.get('startTime', 0)
                            ce = c.get('endTime', 0)
                            texts = [f['text'] for f in fragments
                                     if f.get('start', 0) < ce and f.get('end', 0) > cs]
                            text = ' '.join(texts).strip() or '(пауза)'
                            cont_plot_lines.append(f"Клип {c['id']} ({cs:.1f}-{ce:.1f}с): {text}")
                        cont_plot_context = '\n'.join(cont_plot_lines)

                    prompt_cont = self._create_prompt_chunk(
                        cont_clips, transcription, style_guide,
                        from_id=cont_from_id, to_id=to_id, total_clips=total_clips,
                        is_continuation=True, already_done=from_id + chunk_prompts - 1,
                        prev_prompts_sample=cont_prev_sample,
                        prev_plot_context=cont_plot_context
                    )
                    response_cont, cost_cont = self._make_api_call(
                        prompt_cont, pass2_mode=True,
                        spinner_msg=f"Gemini дополняет (попытка {cont_attempt})"
                    )
                    self._print_cost(cost_cont, label=f"дополнения (попытка {cont_attempt})")

                    if cost_cont:
                        all_costs.append(cost_cont)

                    if not response_cont or not response_cont.text:
                        logging.warning(f"Cont attempt {cont_attempt}: empty response")
                        print(f"   ⚠️  Gemini вернул пустой ответ (попытка {cont_attempt}), повтор...")
                        continue

                    _save_raw_response(output_dir, response_cont.text,
                                       suffix=f'_pass2_cont{cont_attempt}')

                    cont_montage = {'clips': cont_clips}
                    cont_results = self._parse_prompts_only(response_cont.text, output_dir, cont_montage, project_name)
                    cont_path = cont_results.get('prompts')

                    if cont_path and cont_path.exists():
                        if chunk_path is None or not chunk_path.exists():
                            chunk_path = cont_path
                            full_text = chunk_path.read_text(encoding='utf-8')
                            chunk_prompts = len([c.strip() for c in full_text.split('\n\n') if c.strip()])
                        else:
                            cont_text = cont_path.read_text(encoding='utf-8').strip()
                            with open(chunk_path, 'a', encoding='utf-8') as f:
                                f.write('\n\n' + cont_text)
                            cont_path.unlink()
                            full_text = chunk_path.read_text(encoding='utf-8')
                            chunk_prompts = len([c.strip() for c in full_text.split('\n\n') if c.strip()])
                        print(f"   → Итого: {chunk_prompts} / {len(chunk_clips)}")

            # Аккумуляция в основной файл
            if chunk_path and chunk_path.exists() and chunk_prompts > 0:
                if main_prompts_path is None:
                    main_prompts_path = chunk_path
                    total_prompts = chunk_prompts
                else:
                    chunk_text = chunk_path.read_text(encoding='utf-8').strip()
                    with open(main_prompts_path, 'a', encoding='utf-8') as f:
                        f.write('\n\n' + chunk_text)
                    chunk_path.unlink()
                    full_text = main_prompts_path.read_text(encoding='utf-8')
                    total_prompts = len([c.strip() for c in full_text.split('\n\n') if c.strip()])

            # Двигаем курсор на РЕАЛЬНОЕ покрытие
            cursor += chunk_prompts
            chunk_idx += 1
            print(f"PROGRESS:{cursor}/{total_clips}", flush=True)

            if total_clips > chunk_size:
                print(f"   → Итого промптов: {total_prompts} / {total_clips}")

            # Защита от бесконечного цикла
            # Для не-последнего чанка: retry (последний уже покрыт continuation loop выше)
            if chunk_prompts == 0:
                if not is_last_chunk:
                    for _cr in range(1, 3):
                        logging.warning(f"Chunk {chunk_idx}: 0 prompts, retry {_cr}/2")
                        print(f"\n⚠️  Чанк {chunk_idx} вернул 0 промптов — повтор {_cr}/2...")
                        print(f"🤖 Отправка запроса к Gemini ({self.model_name})...")
                        resp_cr, cost_cr = self._make_api_call(
                            prompt2, pass2_mode=True,
                            spinner_msg=f"Gemini повтор чанка (попытка {_cr}/2)"
                        )
                        if cost_cr:
                            all_costs.append(cost_cr)
                        if resp_cr and resp_cr.text:
                            _save_raw_response(output_dir, resp_cr.text,
                                               suffix=f'_pass2_chunk{chunk_idx}_retry{_cr}')
                            cr_results = self._parse_prompts_only(
                                resp_cr.text, output_dir, chunk_montage, project_name
                            )
                            chunk_path = cr_results.get('prompts')
                            chunk_prompts = cr_results.get('num_prompts', 0)
                            if chunk_prompts > 0:
                                print(f"   ✓ Повтор {_cr} успешен: {chunk_prompts} промптов")
                                break
                if chunk_prompts == 0:
                    logging.error(f"Chunk {chunk_idx}: 0 prompts after retries, aborting pass 2")
                    print(f"\n❌ Чанк {chunk_idx} вернул 0 промптов после повторов — прерывание")
                    break

        # Финальная валидация
        if total_clips > 0 and total_prompts != total_clips:
            delta = total_prompts - total_clips
            sign = f"+{delta}" if delta > 0 else str(delta)
            logging.warning(f"Final prompt count mismatch: {total_prompts}/{total_clips} ({sign})")
            print(f"\n⚠️  ИТОГО: {total_prompts} промптов / {total_clips} клипов ({sign})")

        if chunk_idx > 1:
            print(f"   Всего чанков: {chunk_idx}")

        results = {
            'prompts': main_prompts_path,
            'num_prompts': total_prompts,
            'num_clips': total_clips,
        }
        return results, all_costs

    # =========================================================================
    # ПАРСИНГ ОТВЕТА
    # =========================================================================

    def _parse_json_only(
        self,
        response_text: str,
        output_dir: Path,
        transcription: Dict[str, Any],
        pass_num: Optional[int] = None,
        project_name: str = None,
    ) -> dict:
        """Парсит только JSON из ответа. Возвращает montage_plan dict."""
        output_dir.mkdir(parents=True, exist_ok=True)
        montage_plan = {}

        # Try raw JSON first - most robust for truncated responses
        montage_plan_match = re.search(r'\{.*?"clips"\s*:', response_text, re.DOTALL)
        
        # Fallback: try code block pattern
        if not montage_plan_match:
            code_block_match = re.search(
                r'```json\s*\n?\s*(\{[^`]*?"clips"[^`]*?\})\s*```?',
                response_text, re.DOTALL
            )
            if code_block_match and code_block_match.lastindex:
                montage_plan_match = code_block_match
                logging.warning("Using code block fallback")
                print("  ℹ️  Using code block fallback...")

        if montage_plan_match:
            # group(1) for code block match, group(0) for raw json fallback
            json_text = montage_plan_match.group(1) if montage_plan_match.lastindex else montage_plan_match.group(0)
            # Find the outermost { } for raw fallback
            if not montage_plan_match.lastindex:
                start = response_text.find('{')
                # Find matching closing brace - iterate from start position
                depth = 0
                end = -1
                for i in range(start, len(response_text)):
                    ch = response_text[i]
                    if ch == '{': 
                        depth += 1
                    elif ch == '}':
                        depth -= 1
                        if depth == 0:
                            end = i
                            break
                if end >= start:
                    json_text = response_text[start:end + 1]
                else:
                    # JSON is truncated — find last complete clip and auto-complete
                    json_text = response_text[start:]
                    
                    # Find the last complete clip object (ends with "},")
                    last_complete_clip = json_text.rfind('},')
                    if last_complete_clip > 0:
                        # Cut after the last complete clip, keeping the comma
                        json_text = json_text[:last_complete_clip + 2]  # include "},"
                        # Replace trailing comma with closing bracket for array
                        json_text = json_text.rstrip(',') + ']\n'
                    
                    # Count braces and add missing closing braces
                    open_braces = json_text.count('{')
                    close_braces = json_text.count('}')
                    missing = open_braces - close_braces
                    if missing > 0:
                        json_text = json_text + ('}\n' * missing)
                        logging.warning(f"JSON truncated: added {missing} closing braces")
                        print(f"  ⚠️  JSON обрезан — добавлено {missing} закрывающих скобок")
            try:
                montage_plan_data = json.loads(json_text)
                if "montage_plan" in montage_plan_data:
                    montage_plan = montage_plan_data["montage_plan"]
                else:
                    montage_plan = montage_plan_data
            except json.JSONDecodeError as e:
                logging.error(f"JSON parse error: {e} | raw[:200]: {json_text[:200]}")
                print(f"\n❌ Ошибка парсинга JSON: {e}")
                print(f"   Сырой JSON: {json_text[:200]}...")
                raise

            is_valid, errors = validate_montage_plan_json(
                montage_plan, transcription.get('audioDuration', 0)
            )
            if not is_valid:
                logging.warning(f"montage_plan validation warnings: {errors}")
                print(f"\n⚠️  Предупреждения montage_plan.json:")
                for error in errors:
                    print(f"   • {error}")
                if project_name:
                    from modules.queue import append_run_log
                    append_run_log(output_dir, project_name, 'ВАЛИДАЦИЯ-ПРЕДУПРЕЖДЕНИЯ', {
                        f'warn_{i+1}': e for i, e in enumerate(errors)
                    })

            # --- Проверка последовательности ID клипов ---
            clips = montage_plan.get('clips', [])
            id_problems = check_clip_id_sequence(clips)
            if id_problems:
                print(f"\n{'='*60}")
                print(f"  ⚠️  ОШИБКА ID: нарушена последовательность 1..N!")
                print(f"  Найдено {len(id_problems)} несоответствий:")
                show = id_problems[:15]
                for p in show:
                    print(f"    • позиция {p['position']:>4}: id={p['actual']!r}  (ожидалось {p['expected']})")
                if len(id_problems) > 15:
                    print(f"    ... ещё {len(id_problems) - 15} ошибок")
                print(f"{'='*60}")
                print()
                try:
                    choice = input("  Исправить автоматически (перенумеровать 1..N)? [y/n]: ").strip().lower()
                except EOFError:
                    choice = 'y'  # неинтерактивный режим — фиксим автоматически
                if choice == 'y':
                    for i, clip in enumerate(clips):
                        clip['id'] = i + 1
                    montage_plan['clips'] = clips
                    print(f"  ✓ ID перенумерованы 1..{len(clips)}")
                else:
                    print(f"  ⚠️  ID оставлены как есть — возможны ошибки в video_concat!")
                print()

            output_path = output_dir / 'montage_plan.json'
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(montage_plan, f, ensure_ascii=False, indent=2)

            num = len(montage_plan.get('clips', []))
            label = f" (проход {pass_num})" if pass_num else ""
            print(f"   ✓ montage_plan.json{label} — {num} клипов")
        else:
            print("\n⚠️  Не найден montage_plan.json в ответе!")

        return montage_plan

    def _parse_prompts_only(
        self,
        response_text: str,
        output_dir: Path,
        montage_plan: dict,
        project_name: str
    ) -> Dict[str, Path]:
        """Парсит только промпты из ответа."""
        output_dir.mkdir(parents=True, exist_ok=True)
        results = {}
        raw_prompts = None

        prompts_match = re.search(
            r'=== PROMPTS\.TXT ===\s*\n(.*?)$',
            response_text, re.DOTALL
        )
        if prompts_match:
            raw_prompts = prompts_match.group(1).strip()
            raw_prompts = re.sub(r'\n```\s*$', '', raw_prompts).strip()

        if not raw_prompts:
            json_end_match = re.search(r'```\s*\n+(.*)', response_text, re.DOTALL)
            if json_end_match:
                candidate = json_end_match.group(1).strip()
                candidate = re.sub(r'^=== PROMPTS\.TXT ===\s*\n', '', candidate)
                candidate = re.sub(r'\n```\s*$', '', candidate).strip()
                if candidate:
                    raw_prompts = candidate

        if raw_prompts:
            chunks = [c.strip() for c in raw_prompts.split('\n\n') if c.strip()]
            prompt_list = [c for c in chunks if not c.startswith('```')]

            num_clips = len(montage_plan.get('clips', []))
            overprompt = False

            # Unsplit: только при дефиците (prompt_count < num_clips).
            # Gemini иногда забывает blank line → два промпта слипаются в один блок.
            # Гейт через num_clips исключает ложное разрезание правильных промптов.
            if num_clips > 0 and len(prompt_list) < num_clips:
                _fixed = []
                for p in prompt_list:
                    if '\n' in p:
                        sub_parts = [s.strip() for s in p.split('\n') if s.strip()]
                        long_parts = [s for s in sub_parts if len(s) > 100]
                        if len(long_parts) > 1:
                            logging.info(f"Unsplit: 1 block → {len(long_parts)} prompts (deficit fix)")
                            _fixed.extend(long_parts)
                            continue
                    _fixed.append(p)
                if len(_fixed) != len(prompt_list):
                    logging.info(f"Prompt unsplit fix: {len(prompt_list)} → {len(_fixed)}")
                    print(f"   🔧 Unsplit: {len(prompt_list)} → {len(_fixed)} (дефицит {num_clips - len(prompt_list)})")
                    prompt_list = _fixed

            # Over-count: помечаем, но НЕ обрезаем — вызывающий код решает (retry/trim)
            if num_clips > 0 and len(prompt_list) > num_clips:
                extra = len(prompt_list) - num_clips
                logging.warning(f"Prompts over-count: got {len(prompt_list)}/{num_clips}, +{extra} extra")
                print(f"\n⚠️  OVERPROMPT: {len(prompt_list)} промптов, ожидалось {num_clips} (+{extra} лишних)")
                overprompt = True

            # Under-count: ответ был обрезан
            if num_clips > 0 and len(prompt_list) < num_clips:
                missing = num_clips - len(prompt_list)
                logging.warning(f"Prompts truncated: got {len(prompt_list)}/{num_clips}, missing {missing}")
                print(f"\n⚠️  ВНИМАНИЕ: Найдено {len(prompt_list)} промптов, но клипов {num_clips}!")
                print(f"   Ответ Gemini был обрезан. Недостаёт: {missing} промптов.")

            prompts_text = '\n\n'.join(prompt_list)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            overprompt_tag = '_OVERPROMPT' if overprompt else ''
            prompts_filename = f'{project_name}_prompts_{timestamp}{overprompt_tag}.txt'
            output_path = output_dir / prompts_filename
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(prompts_text)
            results['prompts'] = output_path
            results['num_prompts'] = len(prompt_list)
            results['num_clips'] = num_clips
            print(f"   ✓ {prompts_filename} ({len(prompt_list)} промптов)")
        else:
            logging.warning("Prompts block not found in Gemini response")
            print("\n[WARN] Prompts block not found in Gemini response")

        return results

    def _parse_response(
        self,
        response_text: str,
        output_dir: Path,
        transcription: Dict[str, Any],
        project_name: str = "Untitled"
    ) -> Dict[str, Path]:
        """Парсинг однопроходного ответа (JSON + промпты)."""
        output_dir.mkdir(parents=True, exist_ok=True)
        results = {}

        # Сырой ответ — сохраняем ПЕРВЫМ делом, до любого парсинга и интерактивных вопросов
        _save_raw_response(output_dir, response_text)

        # JSON
        montage_plan = self._parse_json_only(response_text, output_dir, transcription)

        # Промпты
        prompts_results = self._parse_prompts_only(response_text, output_dir, montage_plan, project_name)
        results.update(prompts_results)
        results['montage_plan'] = output_dir / 'montage_plan.json'

        # 4list_prompts.txt — заморожен
        list_prompts_match = re.search(
            r'```text\s*=== 4LIST_PROMPTS\.TXT ===\s*(.*?)\s*```',
            response_text, re.DOTALL
        )
        if list_prompts_match and False:  # ЗАМОРОЖЕНО
            pass

        # director_analysis.md
        director_match = re.search(
            r'```markdown\s*=== DIRECTOR_ANALYSIS\.MD ===\s*(.*?)\s*```',
            response_text, re.DOTALL
        )
        if director_match and config.GENERATE_DIRECTOR_ANALYSIS:
            director_text = director_match.group(1).strip()
            output_path = output_dir / 'director_analysis.md'
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(director_text)
            results['director_analysis'] = output_path
            print(f"   ✓ director_analysis.md")

        return results


# =============================================================================
# ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
# =============================================================================

def _save_raw_response(output_dir: Path, response_text: str, suffix: str = ''):
    """Сохранить сырой ответ от Gemini для отладки."""
    if response_text is None:
        logging.warning(f"_save_raw_response: response_text is None (suffix={suffix}), skipping")
        return
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    raw_path = output_dir / f'gemini_raw_response_{timestamp}{suffix}.txt'
    with open(raw_path, 'w', encoding='utf-8') as f:
        f.write(response_text)
    print(f"\n💾 Сырой ответ сохранён: {raw_path.name}")


def _run_with_spinner(func, message="Ожидание ответа", timeout=None, **kwargs):
    """
    Запускает блокирующую функцию в отдельном потоке,
    показывая спиннер с таймером в главном потоке.
    timeout: секунды до GeminiTimeoutError (None = без ограничения)
    """
    result_container = [None]
    error_container = [None]
    done_event = threading.Event()

    def target():
        try:
            result_container[0] = func(**kwargs)
        except Exception as e:
            error_container[0] = e
        finally:
            done_event.set()

    thread = threading.Thread(target=target, daemon=True)
    thread.start()

    frames = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
    start_time = time.time()
    i = 0
    timed_out = False

    try:
        while not done_event.is_set():
            elapsed = time.time() - start_time
            if timeout and elapsed >= timeout:
                timed_out = True
                mins = int(elapsed) // 60
                sys.stdout.write(f'\r   ⏰ {message} — TIMEOUT ({mins}м)              \n')
                sys.stdout.flush()
                done_event.set()
                break
            mins = int(elapsed) // 60
            secs = int(elapsed) % 60
            time_str = f"{mins}м {secs:02d}с" if mins > 0 else f"{secs}с"
            sys.stdout.write(f'\r   {frames[i % len(frames)]}  {message}... {time_str}    ')
            sys.stdout.flush()
            time.sleep(0.1)
            i += 1
    except KeyboardInterrupt:
        done_event.set()
        raise
    finally:
        if not timed_out:
            elapsed = time.time() - start_time
            mins = int(elapsed) // 60
            secs = int(elapsed) % 60
            time_str = f"{mins}м {secs:02d}с" if mins > 0 else f"{secs}с"
            sys.stdout.write(f'\r   ✅ {message} — готово за {time_str}              \n')
            sys.stdout.flush()

    if timed_out:
        raise GeminiTimeoutError(f"Gemini timeout: {message} took >{int(timeout//60)}мин")

    if error_container[0]:
        raise error_container[0]

    return result_container[0]


def direct_project(
    transcription_path: str,
    style_guide_path: str,
    output_dir: str,
    project_name: str = "Untitled",
    api_key: Optional[str] = None,
    model_name: Optional[str] = None,
    two_pass: bool = False,
    prompts_only: bool = False,
    resume_path: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Удобная функция для режиссерского анализа.

    Args:
        two_pass: Двухпроходный режим (для длинных проектов > ~15 мин)
        prompts_only: Только проход 2 — читает готовый montage_plan.json и генерирует промпты
        resume_path: Путь к существующему файлу промптов для продолжения (только с prompts_only)
    """
    director = GeminiDirector(api_key=api_key, model_name=model_name)
    return director.analyze(
        transcription_path, style_guide_path, output_dir, project_name,
        two_pass=two_pass, prompts_only=prompts_only, resume_path=resume_path,
    )


if __name__ == '__main__':
    import sys

    if len(sys.argv) < 3:
        print("Использование: python director.py <transcription.json> <style_guide.txt> [output_dir] [project_name] [--two-pass]")
        sys.exit(1)

    transcription_file = sys.argv[1]
    style_guide_file = sys.argv[2]
    output_directory = sys.argv[3] if len(sys.argv) > 3 else 'output'
    project_name = sys.argv[4] if len(sys.argv) > 4 else 'Untitled'
    two_pass = '--two-pass' in sys.argv

    results = direct_project(transcription_file, style_guide_file, output_directory, project_name, two_pass=two_pass)

    print(f"\n✅ Создано файлов: {len(results)}")
    for name, path in results.items():
        print(f"   • {name}: {path}")
