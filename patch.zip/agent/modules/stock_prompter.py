"""
stock_prompter.py — оператор стоковой стадии: пишет поисковые запросы и
сопоставляет локальную библиотеку.

Своя LLM, НЕ режиссёр. Pass 1 только помечает клипы (`source: stock_pending`) —
его задача монтажный план, и всё. Промптаж отдельно, потому что:
  • ответ Pass 1 не должен раздуваться (риск обрезки на длинных роликах);
  • Pass 1 чанкуется (DIRECTOR_PASS1_CHUNK_THRESHOLD) — запросы разъехались бы;
  • режиссёр может быть дорогой моделью, а «lightning storm clouds» напишет дешёвая;
  • режиссёр не знает, что лежит в папке юзера.

Два вызова, а не один
---------------------
1) озвучка клипов          → query + media (video|photo) с учётом пропорции
2) готовые query + файлы   → local_file | null        (только если папка включена)

Почему не одним: в одном модель одновременно сочиняет запрос, классифицирует
media, держит пропорцию по всему ролику, сканирует сотни файлов и следит за
уникальностью — на этом обычно и сыпется (поедет доля или файл уйдёт в два клипа).
Почему во второй вызов идёт query, а не озвучка: query — уже выжимка смысла
(вчетверо короче), ради того и делался, и локал со стоком ищут по ОДНОМУ критерию
→ отбор консистентен.

`local_file: null` — НОРМАЛЬНЫЙ, ожидаемый результат: библиотека юзера маленькая,
и грозы в ней может просто не быть. Это ничего не говорит о качестве query.
Такой клип уходит на сток с тем же запросом — фолбек, а не ошибка.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

import config
from modules.visual_context import compact_context

logger = logging.getLogger(__name__)

# Провайдеры, работающие через прямой chat API (остальные — CLI-агенты)
_CHAT_PROVIDERS = (
    'cliproxy', 'deepseek', 'openrouter', 'meta_muse', 'claude_api',
    'codex_reseller', 'gpt_nexus',
)


@dataclass
class StockQuery:
    clip_id: int
    query: str
    media: str = 'video'          # video | photo
    local_file: str = ''          # путь из библиотеки; пусто = идём на сток
    # Трассировка для stock_query_log.json (отладка качества запросов):
    query_by: str = ''            # 'cliproxy/model' | 'gpt/model' | 'voiceover-fallback'
    query_path: str = 'primary'   # 'primary' | 'fallback'
    fallback_reason: str = ''     # ошибка, на которой упал промптер (если fallback)


def _provider() -> str:
    p = (getattr(config, 'STOCK_PROMPT_PROVIDER', '') or '').strip().lower()
    if p and p != 'auto':
        return p
    # auto → тем же, кем размечал режиссёр; иначе прямой chat
    d = (getattr(config, 'DIRECTOR_BACKEND', '') or '').strip().lower()
    if d in ('gpt', 'openai'):
        gp = (getattr(config, 'GPT_PROVIDER', '') or '').strip().lower()
        return gp if gp in _CHAT_PROVIDERS else 'gpt'
    if d in _CHAT_PROVIDERS or d in ('codex', 'claude_code'):
        return 'gpt' if d == 'codex' else d
    return 'cliproxy'


def _model(provider: str) -> str:
    m = (getattr(config, 'STOCK_PROMPT_MODEL', '') or '').strip()
    if m:
        return m
    return {
        'cliproxy': getattr(config, 'CLIPROXY_MODEL', ''),
        'deepseek': getattr(config, 'DEEPSEEK_MODEL', ''),
        'openrouter': getattr(config, 'OPENROUTER_MODEL', ''),
        'claude_api': getattr(config, 'CLAUDE_API_MODEL', ''),
        'codex_reseller': getattr(config, 'CODEX_RESELLER_MODEL', ''),
        'gpt_nexus': getattr(config, 'GPT_NEXUS_MODEL', ''),
        'meta_muse': getattr(config, 'META_MUSE_MODEL', ''),
    }.get(provider, '')


def _parse_json_loose(raw: str) -> Any:
    """JSON из ответа модели: она любит обернуть в ```json или добавить болтовню."""
    if not raw:
        return None
    txt = raw.strip()
    m = re.search(r'```(?:json)?\s*(.+?)```', txt, re.S)
    if m:
        txt = m.group(1).strip()
    try:
        return json.loads(txt)
    except Exception:
        pass
    for opener, closer in (('[', ']'), ('{', '}')):
        i, j = txt.find(opener), txt.rfind(closer)
        if i >= 0 and j > i:
            try:
                return json.loads(txt[i:j + 1])
            except Exception:
                continue
    return None


def _chat(provider: str, task: str, timeout: int = 300) -> str:
    from modules import chat_client
    return chat_client.chat_completion(
        provider, _model(provider), [{"role": "user", "content": task}],
        max_tokens=None, timeout=timeout,
    ) or ''


# ── Вызов 1: запросы + тип медиа ────────────────────────────────────────────

def _queries_prompt(clips: List[Dict[str, Any]], video_share: float, theme: str = '') -> str:
    payload = []
    for card in clips:
        item = {'id': card['id'], 'voiceover': (card.get('voiceover') or '')[:400]}
        context = compact_context(card)
        if context:
            item['context'] = context
        payload.append(item)
    video_pct = int(video_share * 100)
    theme_block = (
        f"Video theme (background context): {theme}\n"
        "Ground each query in this theme AND the clip's voiceover — what is SEEN in the shot "
        "plus its own time/setting cues. The clip's own cues WIN over the theme. Make it "
        "specific (subject + setting/kind), not one broad word. Use context only to "
        "resolve references or continuity; do not copy neighboring narration into the "
        "query.\n\n"
    ) if (theme or '').strip() else ""
    return (
        "You write stock-footage search queries for a documentary video.\n\n"
        f"{theme_block}"
        "For EACH clip below write:\n"
        "  query — 2-4 ENGLISH words naming what is SEEN in the shot, not what is meant.\n"
        "    Name the concrete visible subject or scene. No proper names, no dates, no\n"
        "    abstractions/metaphors, no camera directions.\n"
        "  media — \"video\" if the scene has motion; \"photo\" if it is static.\n"
        f"    Keep roughly {video_pct}% video / {100 - video_pct}% photo across ALL clips.\n\n"
        f"## CLIPS\n{json.dumps({'clips': payload}, ensure_ascii=False)}\n\n"
        "## OUTPUT\nSTRICT JSON only, no markdown, no commentary:\n"
        '{"items":[{"clip_id":<int>,"query":"<2-4 english words>","media":"video|photo"}]}\n'
        "One entry per clip received — do NOT skip clips. Use only words grounded in the "
        "clip's voiceover and the video theme; do NOT copy any word from these instructions."
    )


def _fallback_queries(clips: List[Dict[str, Any]], video_share: float,
                      reason: str = '') -> List[StockQuery]:
    """LLM недоступна → запросом становится озвучка (стоки её токенизируют).

    Качество ниже, но стадия жива. media раскидываем по пропорции — смысл сцены
    без модели оценить нечем. `reason` — ошибка промптера (для stock_query_log).
    """
    out: List[StockQuery] = []
    for i, c in enumerate(clips):
        vo = (c.get('voiceover') or '').strip()
        out.append(StockQuery(
            clip_id=int(c['id']),
            query=vo[:80] if vo else '',
            media='video' if (i % 10) < int(video_share * 10) else 'photo',
            query_by='voiceover-fallback', query_path='fallback',
            fallback_reason=reason,
        ))
    return [q for q in out if q.query]


def generate_queries(clips: List[Dict[str, Any]], *, video_share: Optional[float] = None,
                     theme: str = '') -> List[StockQuery]:
    """Вызов 1: озвучка → query + media. Провал → озвучка как запрос."""
    if not clips:
        return []
    if video_share is None:
        video_share = float(getattr(config, 'STOCK_VIDEO_SHARE', 0.70) or 0.70)
    provider = _provider()
    task = _queries_prompt(clips, video_share, theme)
    _by = f'{provider}/{_model(provider)}'

    try:
        if provider in _CHAT_PROVIDERS:
            raw = _chat(provider, task)
        else:
            raw = _agent_run(provider, task, 'stock_queries.json')
        data = _parse_json_loose(raw)
        items = (data or {}).get('items') if isinstance(data, dict) else data
        if not items:
            raise ValueError('пустой/непарсимый ответ')
        by_id = {int(c['id']): c for c in clips}
        out: List[StockQuery] = []
        for it in items:
            cid = int(it.get('clip_id') or 0)
            q = (it.get('query') or '').strip()
            if cid not in by_id or not q:
                continue
            media = (it.get('media') or 'video').strip().lower()
            out.append(StockQuery(cid, q, 'photo' if media == 'photo' else 'video',
                                  query_by=_by, query_path='primary'))
        if not out:
            raise ValueError('ни одного валидного запроса')
        missing = [c for c in clips if int(c['id']) not in {q.clip_id for q in out}]
        if missing:
            logger.info("[stock] промптер пропустил %d клип(ов) → озвучка как запрос", len(missing))
            out += _fallback_queries(missing, video_share,
                                     reason=f'{_by}: returned fewer clips than requested')
        return out
    except Exception as exc:
        logger.warning("[stock] промптер (%s) не сработал: %s — озвучка как запрос", provider, exc)
        return _fallback_queries(clips, video_share, reason=f'{_by}: {exc}')


# ── Вызов 2: сопоставление локальной библиотеки ─────────────────────────────

def _local_prompt(queries: List[StockQuery], files: List[str]) -> str:
    q_payload = [{'clip_id': q.clip_id, 'query': q.query, 'media': q.media} for q in queries]
    return (
        "You match a user's own footage library against search queries.\n\n"
        "## LIBRARY FILES (path relative to library root)\n"
        + "\n".join(f"  {f}" for f in files) + "\n\n"
        f"## QUERIES\n{json.dumps({'items': q_payload}, ensure_ascii=False)}\n\n"
        "Rules:\n"
        "  • Judge by file and folder names — they describe the footage.\n"
        "  • Match only if the file REALLY fits the query. A wrong shot is worse than none.\n"
        "  • media must match: video query needs a video file, photo query needs an image.\n"
        "  • Each file may be used for AT MOST ONE clip. Never repeat a file.\n"
        "  • null is a NORMAL answer — the clip will then be taken from stock sites.\n\n"
        "## OUTPUT\nSTRICT JSON only, no markdown, no commentary:\n"
        '{"items":[{"clip_id":<int>,"local_file":"<exact path from list>"|null}]}'
    )


def match_local(queries: List[StockQuery], files: List[str]) -> Optional[Dict[int, str]]:
    """Вызов 2: query + файлы → {clip_id: file}.

    Возвращает:
      {...} / {} — модель отработала; пустой словарь = честное «ничего не подходит»,
                   лезть python-подбором сюда НЕ надо (найдёт мусор по случайному слову);
      None       — модель НЕ отработала (упала/недоступна) → вызывающий может
                   подстраховаться python-подбором, иначе библиотека умрёт вместе с LLM.
    """
    if not queries or not files:
        return {}
    provider = _provider()
    task = _local_prompt(queries, files)
    try:
        if provider in _CHAT_PROVIDERS:
            raw = _chat(provider, task)
        else:
            raw = _agent_run(provider, task, 'stock_local_match.json')
        data = _parse_json_loose(raw)
        if data is None:
            raise ValueError('непарсимый ответ')
        items = data.get('items') if isinstance(data, dict) else data
        if items is None:
            raise ValueError('нет поля items')
        if not items:
            return {}                      # модель ответила «ничего не подходит» — это норма
        known = set(files)
        valid_ids = {q.clip_id for q in queries}
        out: Dict[int, str] = {}
        used: set = set()
        for it in items:
            cid = int(it.get('clip_id') or 0)
            f = it.get('local_file')
            if not f or cid not in valid_ids:
                continue
            f = str(f).strip().replace('\\', '/')
            if f not in known:                     # модель выдумала путь
                logger.info("[stock] промптер вернул несуществующий файл %r — игнорирую", f[:60])
                continue
            if f in used:                          # один файл в два клипа
                logger.info("[stock] файл %r назначен повторно — игнорирую", f[:60])
                continue
            used.add(f)
            out[cid] = f
        return out
    except Exception as exc:
        logger.warning("[stock] сопоставление библиотеки (%s) не сработало: %s — "
                       "подстрахуюсь подбором по словам", provider, exc)
        return None                        # None ≠ {}: вызывающий включит python-фолбек


# ── CLI-агенты (codex / claude_code) ────────────────────────────────────────

def _agent_run(provider: str, task: str, out_name: str) -> str:
    """Агент пишет ответ в файл, мы его читаем. Путь real_photo, но без схем —
    ответ короткий и проверяется парсером."""
    work = Path(getattr(config, 'PROJECTS_DIR', '.')) / '_stock_prompt'
    work.mkdir(parents=True, exist_ok=True)
    out_file = work / out_name
    if out_file.exists():
        out_file.unlink()
    prompt = f"{task}\n\nWrite the JSON to: {out_file.as_posix()}\nNothing else."
    if provider in ('gpt', 'codex'):
        from modules.codex_runner import run_codex_task  # type: ignore
        run_codex_task(prompt, working_dir=work)
    else:
        from modules.claude_code_runner import run_claude_code_task  # type: ignore
        run_claude_code_task(prompt, working_dir=work)
    return out_file.read_text(encoding='utf-8') if out_file.exists() else ''
