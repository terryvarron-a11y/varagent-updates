"""Aggregate Ailink and Nexus balances from local application credentials."""
from __future__ import annotations

import os
import time
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal, InvalidOperation
from pathlib import Path

import requests


AGENT_DIR = Path(__file__).resolve().parents[1]
APP_DIR = AGENT_DIR.parent
WORKSPACE_DIR = APP_DIR.parent

_AILINK_CHAT_URL = "https://ai.ailink1.com/v1/chat/completions"
_NEXUS_MESSAGES_URL = "https://ccmaxshop.de5.net/v1/messages"


def _read_env(path: Path) -> dict[str, str]:
    values = {}
    if not path.exists():
        return values
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return values
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        values[key.strip()] = value.strip().strip("\"'")
    return values


def _split_keys(value: str) -> list[str]:
    return [
        item.strip()
        for item in str(value or "").replace(";", ",").split(",")
        if item.strip()
    ]


def _usage_url(api_url: str) -> str:
    url = str(api_url or "").strip().rstrip("/")
    for suffix in ("/chat/completions", "/messages"):
        if url.endswith(suffix):
            return f"{url[:-len(suffix)]}/usage"
    return f"{url}/usage"


def _number(value) -> Decimal | None:
    if value is None or isinstance(value, bool):
        return None
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return None


def _credential_sources() -> list[dict[str, str]]:
    sources = [
        dict(os.environ),
        _read_env(APP_DIR / ".env"),
        _read_env(AGENT_DIR / ".env"),
        _read_env(WORKSPACE_DIR / "STORY_REWRITER" / ".env"),
    ]
    return [source for source in sources if source]


def _wallets() -> dict[str, list[dict]]:
    providers = {"ailink": [], "nexus": []}
    for env in _credential_sources():
        ailink_url = (
            env.get("CLAUDE_RESELLER_URL")
            or env.get("CODEX_RESELLER_URL")
            or _AILINK_CHAT_URL
        )
        for name in (
            "CLAUDE_RESELLER_API_KEY",
            "CLAUDE_RESELLER_EXTRA_API_KEYS",
            "CODEX_RESELLER_API_KEY",
            "CODEX_RESELLER_EXTRA_API_KEYS",
        ):
            for key in _split_keys(env.get(name, "")):
                providers["ailink"].append({
                    "key": key,
                    "url": ailink_url,
                    "protocol": "openai",
                })

        nexus_url = env.get(
            "CLAUDE_RESELLER_ANTHROPIC_URL", _NEXUS_MESSAGES_URL)
        for name in (
            "CLAUDE_RESELLER_ANTHROPIC_API_KEY",
            "CLAUDE_RESELLER_ANTHROPIC_EXTRA_API_KEYS",
        ):
            for key in _split_keys(env.get(name, "")):
                providers["nexus"].append({
                    "key": key,
                    "url": nexus_url,
                    "protocol": "anthropic",
                })

    for provider, wallets in providers.items():
        unique = []
        seen = set()
        for wallet in wallets:
            key = wallet["key"]
            if key in seen:
                continue
            seen.add(key)
            unique.append(wallet)
        providers[provider] = unique
    return providers


def _fetch_wallet(wallet: dict) -> dict:
    key = wallet["key"]
    headers = {"Authorization": f"Bearer {key}"}
    if wallet.get("protocol") == "anthropic":
        headers["x-api-key"] = key
    try:
        response = requests.get(
            _usage_url(wallet["url"]), headers=headers, timeout=12)
        response.raise_for_status()
        data = response.json()
    except requests.Timeout:
        return {"ok": False, "error": "timeout"}
    except requests.HTTPError as exc:
        code = exc.response.status_code if exc.response is not None else 0
        return {"ok": False, "error": f"HTTP {code}"}
    except Exception as exc:
        return {"ok": False, "error": type(exc).__name__}

    balance = _number(data.get("balance", data.get("remaining")))
    if balance is None:
        return {"ok": False, "error": "balance_missing"}
    today = (data.get("usage") or {}).get("today") or {}
    return {
        "ok": True,
        "balance": balance,
        "today_cost": _number(today.get("actual_cost", today.get("cost"))),
        "today_requests": _number(today.get("requests")),
        "unit": str(data.get("unit") or "USD"),
    }


def _aggregate(provider: str, wallets: list[dict]) -> dict:
    if not wallets:
        return {
            "provider": provider,
            "ok": False,
            "wallets_ok": 0,
            "wallets_total": 0,
            "errors": [],
        }

    with ThreadPoolExecutor(max_workers=min(4, len(wallets))) as pool:
        results = list(pool.map(_fetch_wallet, wallets))

    successful = [result for result in results if result.get("ok")]
    errors = [
        str(result.get("error") or "unknown_error")
        for result in results if not result.get("ok")
    ]
    balance = sum(
        (result["balance"] for result in successful), Decimal("0"))
    today_cost = sum(
        (result.get("today_cost") or Decimal("0") for result in successful),
        Decimal("0"),
    )
    today_requests = sum(
        (result.get("today_requests") or Decimal("0") for result in successful),
        Decimal("0"),
    )
    units = {result.get("unit") or "USD" for result in successful}
    return {
        "provider": provider,
        "ok": bool(successful),
        "partial": 0 < len(successful) < len(wallets),
        "balance": float(balance) if successful else None,
        "today_cost": float(today_cost) if successful else None,
        "today_requests": int(today_requests) if successful else None,
        "unit": units.pop() if len(units) == 1 else "USD",
        "wallets_ok": len(successful),
        "wallets_total": len(wallets),
        "errors": errors,
    }


def fetch_balances() -> dict:
    wallets = _wallets()
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = {
            provider: pool.submit(_aggregate, provider, provider_wallets)
            for provider, provider_wallets in wallets.items()
        }
        providers = {
            provider: future.result()
            for provider, future in futures.items()
        }
    return {
        "ok": any(item.get("ok") for item in providers.values()),
        "providers": providers,
        "updated_at": time.time(),
    }
