"""
Small adapter for the unofficial ``claude-api`` package used by VarAgent GUI.

The upstream package expects a single Cookie header string. Browser exports are
usually JSON, so this module normalizes common export formats into that string.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class ClaudeCookieError(RuntimeError):
    pass


def _cookie_pair(name: str, value: str) -> str:
    return f"{name.strip()}={str(value).strip()}"


def _cookies_from_list(items: list[Any]) -> str:
    pairs: list[str] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        name = item.get("name") or item.get("Name")
        value = item.get("value") or item.get("Value")
        domain = str(item.get("domain") or item.get("Domain") or "")
        if not name or value is None:
            continue
        if domain and "claude.ai" not in domain.lower():
            continue
        pairs.append(_cookie_pair(str(name), str(value)))
    return "; ".join(pairs)


def _cookies_from_dict(data: dict[str, Any]) -> str:
    for key in ("cookie", "Cookie", "cookies_string", "cookie_string"):
        value = data.get(key)
        if isinstance(value, str) and "=" in value:
            return value.strip()

    for key in ("cookies", "Cookies"):
        value = data.get(key)
        if isinstance(value, list):
            return _cookies_from_list(value)
        if isinstance(value, str) and "=" in value:
            return value.strip()

    pairs: list[str] = []
    for name, value in data.items():
        if isinstance(value, (str, int, float)) and name not in {"url", "domain"}:
            pairs.append(_cookie_pair(str(name), str(value)))
    return "; ".join(pairs)


def cookie_string_from_json(path: str | Path) -> str:
    cookie_path = Path(path).expanduser()
    if not cookie_path.exists():
        raise ClaudeCookieError(f"Cookie JSON not found: {cookie_path}")

    raw = cookie_path.read_text(encoding="utf-8-sig", errors="replace").strip()
    if not raw:
        raise ClaudeCookieError(f"Cookie JSON is empty: {cookie_path}")

    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        if "=" in raw:
            return raw
        raise ClaudeCookieError(f"Cookie file is not valid JSON: {cookie_path}")

    if isinstance(data, str):
        cookie = data.strip()
    elif isinstance(data, list):
        cookie = _cookies_from_list(data)
    elif isinstance(data, dict):
        cookie = _cookies_from_dict(data)
    else:
        cookie = ""

    if "=" not in cookie:
        raise ClaudeCookieError("No Claude cookies found in JSON export")
    return cookie


def resolve_cookie(cookie_json: str = "", raw_cookie: str = "") -> str:
    if cookie_json:
        return cookie_string_from_json(cookie_json)
    cookie = (raw_cookie or "").strip()
    if "=" not in cookie:
        raise ClaudeCookieError("Set CLAUDE_COOKIE_JSON or CLAUDE_COOKIE in agent/.env")
    return cookie


class ClaudeChatClient:
    def __init__(self, cookie_json: str = "", raw_cookie: str = ""):
        self.cookie = resolve_cookie(cookie_json, raw_cookie)
        try:
            from claude_api import Client
        except Exception as exc:
            raise RuntimeError("claude-api is not installed. Run: pip install claude-api") from exc
        self.client = Client(self.cookie)

    def new_conversation(self) -> str:
        data = self.client.create_new_chat()
        conversation_id = data.get("uuid") if isinstance(data, dict) else None
        if not conversation_id:
            raise RuntimeError(f"Claude did not return a conversation uuid: {data!r}")
        return conversation_id

    def send(
        self,
        prompt: str,
        conversation_id: str | None = None,
        attachment: str | Path | None = None,
    ) -> tuple[str, str]:
        if not conversation_id:
            conversation_id = self.new_conversation()
        response = self.client.send_message(
            prompt,
            conversation_id,
            attachment=str(attachment) if attachment else None,
        )
        return conversation_id, str(response)

    def list_conversations(self) -> list[dict[str, Any]]:
        data = self.client.list_all_conversations()
        return data if isinstance(data, list) else []
