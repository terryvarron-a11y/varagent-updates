"""
yt_transcriber.py — Транскрибирует видео YouTube канала через AssemblyAI.

Использование из кода:
    from modules.yt_transcriber import run_channel_transcription
    run_channel_transcription(
        channel_url="https://www.youtube.com/@SomeChannel/videos",
        out_dir=Path("projects/channel_subs"),
        max_videos=10,
        sort_mode="latest",   # latest | popular | oldest | random
        ytdlp_path=None,      # auto-detect
        progress_cb=None,     # callback(msg: str, level: str)
        stop_event=None,      # threading.Event для отмены
    )
"""

import os
import sys
import json
import time
import random
import shutil
import threading
import subprocess
import requests
from pathlib import Path
from typing import Optional, Callable

import config


# ── AssemblyAI helpers ───────────────────────────────────────────────────────

_POLL_INTERVAL = 10
_MAX_WAIT = 900  # 15 min max per video


def _ms_to_srt(ms: int) -> str:
    h  = ms // 3_600_000; ms -= h * 3_600_000
    m  = ms // 60_000;    ms -= m * 60_000
    s  = ms // 1_000;     ms -= s * 1_000
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def _words_to_srt(words: list, max_chars: int = 60, max_gap_ms: int = 1000) -> str:
    if not words:
        return ""
    groups, group = [], []
    for w in words:
        if group:
            gap = w["start"] - group[-1]["end"]
            text_so_far = " ".join(x["text"] for x in group)
            if gap > max_gap_ms or len(text_so_far) + len(w["text"]) + 1 > max_chars:
                groups.append(group)
                group = []
        group.append(w)
    if group:
        groups.append(group)

    parts = []
    for i, grp in enumerate(groups, 1):
        start = _ms_to_srt(grp[0]["start"])
        end   = _ms_to_srt(grp[-1]["end"])
        text  = " ".join(w["text"] for w in grp)
        parts.append(f"{i}\n{start} --> {end}\n{text}\n")
    return "\n".join(parts)


def _srt_to_plain(srt_text: str) -> str:
    """Убирает временные метки и номера блоков — чистый текст."""
    lines, out = srt_text.splitlines(), []
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        # пропускаем номер блока (только цифры)
        if line.isdigit():
            i += 1
            continue
        # пропускаем строку с временем (содержит "-->")
        if "-->" in line:
            i += 1
            continue
        if line:
            out.append(line)
        i += 1
    return " ".join(out)


def _upload_audio(file_path: Path, api_key: str) -> str:
    """Загружает аудиофайл в AssemblyAI, возвращает upload_url."""
    with open(file_path, "rb") as f:
        resp = requests.post(
            "https://api.assemblyai.com/v2/upload",
            headers={"authorization": api_key},
            data=f,
            timeout=300,
        )
    resp.raise_for_status()
    return resp.json()["upload_url"]


def _submit_transcription(audio_url: str, api_key: str) -> str:
    """Отправляет задание на транскрипцию, возвращает transcript_id."""
    resp = requests.post(
        "https://api.assemblyai.com/v2/transcript",
        headers={"authorization": api_key, "content-type": "application/json"},
        json={"audio_url": audio_url, "language_detection": True},
        timeout=60,
    )
    resp.raise_for_status()
    return resp.json()["id"]


def _wait_result(transcript_id: str, api_key: str,
                 stop_event: Optional[threading.Event] = None,
                 progress_cb=None) -> dict:
    url = f"https://api.assemblyai.com/v2/transcript/{transcript_id}"
    headers = {"authorization": api_key}
    elapsed = 0
    while elapsed < _MAX_WAIT:
        if stop_event and stop_event.is_set():
            raise InterruptedError("Cancelled")
        resp = requests.get(url, headers=headers, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        status = data["status"]
        if status == "completed":
            return data
        if status == "error":
            raise RuntimeError(f"AssemblyAI error: {data.get('error')}")
        time.sleep(_poll_interval := _POLL_INTERVAL)
        elapsed += _poll_interval
        if progress_cb:
            progress_cb(f"   [{elapsed}s] {status}...", "INFO")
    raise TimeoutError(f"Timeout after {_MAX_WAIT}s")


# ── yt-dlp helpers ───────────────────────────────────────────────────────────

def _find_ytdlp(ytdlp_path: Optional[str] = None) -> str:
    if ytdlp_path and Path(ytdlp_path).exists():
        return ytdlp_path
    # рядом со скриптом varagent.py
    candidates = [
        Path(__file__).parent.parent.parent / "yt-dlp.exe",
        Path(__file__).parent.parent.parent / "yt-dlp",
    ]
    for c in candidates:
        if c.exists():
            return str(c)
    # в PATH
    return "yt-dlp"


def _get_channel_name(channel_url: str, ytdlp: str) -> str:
    """Возвращает реальное имя канала через yt-dlp (%(channel)s)."""
    cmd = [ytdlp, "--flat-playlist", "--playlist-items", "1",
           "--print", "%(channel)s",
           "--cookies-from-browser", "opera", channel_url]
    result = subprocess.run(cmd, capture_output=True, text=True,
                            encoding="utf-8", errors="replace")
    for line in result.stdout.splitlines():
        name = line.strip()
        if name:
            return name
    return ""


def _get_video_list(channel_url: str, ytdlp: str,
                    sort_mode: str = "latest",
                    max_videos: int = 0,
                    progress_cb=None) -> list:
    """Возвращает список видео [{id, title, date, view_count}].
    sort_mode: latest | popular | oldest | random
    max_videos: 0 = все
    """
    cmd = [ytdlp, "--flat-playlist", "--print", "%(id)s\t%(title)s\t%(upload_date)s\t%(view_count)s",
           "--cookies-from-browser", "opera", channel_url]
    if progress_cb:
        progress_cb("Получаем список видео...", "INFO")
    result = subprocess.run(cmd, capture_output=True, text=True,
                            encoding="utf-8", errors="replace")
    videos = []
    for line in result.stdout.splitlines():
        parts = line.strip().split("\t")
        if len(parts) >= 2 and parts[0].strip():
            vid_id = parts[0].strip()
            title  = parts[1].strip() if len(parts) > 1 else vid_id
            date   = parts[2].strip() if len(parts) > 2 else "00000000"
            views  = int(parts[3].strip()) if len(parts) > 3 and parts[3].strip().isdigit() else 0
            videos.append({"id": vid_id, "title": title, "date": date, "views": views})

    if sort_mode == "latest":
        videos.sort(key=lambda v: v["date"], reverse=True)
    elif sort_mode == "oldest":
        videos.sort(key=lambda v: v["date"])
    elif sort_mode == "popular":
        videos.sort(key=lambda v: v["views"], reverse=True)
    elif sort_mode == "random":
        random.shuffle(videos)

    if max_videos and max_videos > 0:
        videos = videos[:max_videos]

    if progress_cb:
        progress_cb(f"Найдено видео: {len(videos)}", "INFO")
    return videos


def _download_audio(vid_id: str, ytdlp: str, tmp_dir: Path,
                    progress_cb=None) -> Path:
    """Скачивает аудио видео в tmp_dir, возвращает путь к файлу."""
    yt_url = f"https://www.youtube.com/watch?v={vid_id}"
    out_tmpl = str(tmp_dir / f"{vid_id}.%(ext)s")
    cmd = [ytdlp,
           "--cookies-from-browser", "opera",
           "--extract-audio", "--audio-format", "mp3", "--audio-quality", "5",
           "--no-playlist",
           "-o", out_tmpl,
           yt_url]
    subprocess.run(cmd, capture_output=True, text=True,
                   encoding="utf-8", errors="replace")
    for ext in ("mp3", "m4a", "opus", "webm", "ogg"):
        p = tmp_dir / f"{vid_id}.{ext}"
        if p.exists():
            return p
    raise RuntimeError("Audio file not found after yt-dlp download")


# ── Main public function ─────────────────────────────────────────────────────

def run_channel_transcription(
    channel_url: str,
    out_dir: Path,
    max_videos: int = 0,
    sort_mode: str = "latest",
    ytdlp_path: Optional[str] = None,
    progress_cb: Optional[Callable] = None,
    stop_event: Optional[threading.Event] = None,
) -> dict:
    """
    Транскрибирует видео YouTube-канала через AssemblyAI.

    Сохраняет в out_dir:
      - {date}_{title}_{id}.srt         — субтитры с метками времени
      - {date}_{title}_{id}.txt         — чистый текст (скрипт)
      - splitscript_{channel_slug}.txt  — все скрипты в одном файле

    Возвращает: {"done": N, "total": M, "srt_dir": str(out_dir)}
    """

    def log(msg, level="INFO"):
        if progress_cb:
            progress_cb(msg, level)

    api_key = getattr(config, "ASSEMBLYAI_API_KEY", "") or os.getenv("ASSEMBLYAI_API_KEY", "")
    if not api_key:
        raise RuntimeError("ASSEMBLYAI_API_KEY не задан в config/.env")

    ytdlp = _find_ytdlp(ytdlp_path)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    tmp_dir = out_dir / "_tmp_audio"
    tmp_dir.mkdir(exist_ok=True)

    # Получаем реальное имя канала и список видео
    channel_name = _get_channel_name(channel_url, ytdlp)
    videos = _get_video_list(channel_url, ytdlp, sort_mode, max_videos, log)
    if not videos:
        log("Нет видео на канале или yt-dlp не смог получить список", "ERROR")
        return {"done": 0, "total": 0, "srt_dir": str(out_dir)}

    # Имя файла сводного скрипта: реальное имя канала
    if channel_name:
        channel_slug = "".join(c if c.isalnum() or c in " _-" else "_" for c in channel_name)[:60].strip()
    else:
        # Fallback: из URL
        channel_slug = channel_url.rstrip("/").split("/")[-1].lstrip("@")[:40]
        channel_slug = "".join(c if c.isalnum() or c in "-_" else "_" for c in channel_slug)
    log(f"Канал: {channel_name or channel_slug}", "INFO")
    split_path = out_dir / f"splitscript_{channel_slug}.txt"

    log(f"Транскрибируем {len(videos)} видео → {out_dir}", "INFO")
    done = 0

    for i, v in enumerate(videos, 1):
        if stop_event and stop_event.is_set():
            log("Остановлено пользователем", "WARNING")
            break

        vid_id = v["id"]
        title  = v["title"]
        date   = v["date"]
        safe   = "".join(c if c.isalnum() or c in " _-" else "_" for c in title)[:80].strip()

        srt_path = out_dir / f"{date}_{safe}_{vid_id}.srt"
        txt_path = out_dir / f"{date}_{safe}_{vid_id}.txt"

        if srt_path.exists() and txt_path.exists():
            log(f"[{i}/{len(videos)}] SKIP (уже есть): {srt_path.name}", "INFO")
            done += 1
            continue

        log(f"[{i}/{len(videos)}] {title[:70]}", "INFO")

        audio_file = None
        try:
            # 1. Скачиваем аудио
            log(f"   Скачиваем аудио...", "INFO")
            audio_file = _download_audio(vid_id, ytdlp, tmp_dir, log)
            sz = audio_file.stat().st_size // 1024
            log(f"   Скачано: {audio_file.name} ({sz} KB)", "INFO")

            # 2. Загружаем в AssemblyAI
            log(f"   Загружаем в AssemblyAI...", "INFO")
            upload_url = _upload_audio(audio_file, api_key)
            log(f"   Загружено OK", "INFO")

            # 3. Транскрибируем
            tid = _submit_transcription(upload_url, api_key)
            log(f"   Транскрибируем ({tid[:8]}...)...", "INFO")
            data = _wait_result(tid, api_key, stop_event, log)
            log("", "INFO")  # clear progress line

            lang     = data.get("language_code", "?")
            duration = data.get("audio_duration", 0)
            words    = data.get("words") or []

            if words:
                srt_text = _words_to_srt(words)
            else:
                text    = data.get("text") or ""
                dur_ms  = int((duration or 0) * 1000)
                srt_text = f"1\n00:00:00,000 --> {_ms_to_srt(dur_ms)}\n{text}\n" if text else ""

            if srt_text:
                srt_path.write_text(srt_text, encoding="utf-8")
                plain = _srt_to_plain(srt_text)
                txt_path.write_text(plain, encoding="utf-8")

                # Дописываем в splitscript
                with open(split_path, "a", encoding="utf-8") as sf:
                    sf.write(f"\n\n{'='*60}\n")
                    sf.write(f"# {title}\n")
                    sf.write(f"# {date} | {lang} | {int(duration or 0)}s\n")
                    sf.write(f"{'='*60}\n\n")
                    sf.write(plain)

                log(f"   OK [{lang}] {len(words)} words → {srt_path.name}", "SUCCESS")
                done += 1
            else:
                log(f"   EMPTY — текст не получен", "WARNING")

        except InterruptedError:
            break
        except Exception as e:
            log(f"   ERROR: {e}", "ERROR")
        finally:
            if audio_file and audio_file.exists():
                try:
                    audio_file.unlink()
                except Exception:
                    pass

        time.sleep(2)

    # Удаляем tmp папку если пустая
    try:
        if tmp_dir.exists() and not any(tmp_dir.iterdir()):
            tmp_dir.rmdir()
    except Exception:
        pass

    log(f"Готово: {done}/{len(videos)} субтитров в {out_dir}", "SUCCESS")
    return {"done": done, "total": len(videos), "srt_dir": str(out_dir)}
