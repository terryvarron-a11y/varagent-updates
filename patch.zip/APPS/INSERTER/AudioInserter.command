#!/bin/bash
# Audio Inserter launcher for macOS.

set -e

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

if [ -x /opt/homebrew/bin/brew ]; then
    eval "$(/opt/homebrew/bin/brew shellenv)"
elif [ -x /usr/local/bin/brew ]; then
    eval "$(/usr/local/bin/brew shellenv)"
fi

VENV_PY="$DIR/.venv/bin/python"

show_error() {
    if command -v osascript >/dev/null 2>&1; then
        osascript -e "display dialog \"$1\" with title \"Audio Inserter\" buttons {\"OK\"} default button \"OK\" with icon stop"
    else
        echo "ERROR: $1"
        read -p "Press Enter to close this window..." _
    fi
}

if [ ! -x "$VENV_PY" ]; then
    show_error "Local Python environment was not found. Run install_mac.command first."
    exit 1
fi

if ! "$VENV_PY" -c "import tkinter, PIL, ttkbootstrap" >/dev/null 2>&1; then
    show_error "Python packages are missing. Run install_mac.command again."
    exit 1
fi

if ! command -v ffmpeg >/dev/null 2>&1; then
    show_error "ffmpeg was not found. Run install_mac.command first."
    exit 1
fi

if ! ffmpeg -hide_banner -filters 2>/dev/null | grep -qE '^[ .A-Z|]*overlay[[:space:]]'; then
    show_error "This ffmpeg build is missing the required overlay filter. Run install_mac.command again."
    exit 1
fi

if [ "${AUDIO_INSERTER_SELF_TEST:-}" = "1" ]; then
    echo "AudioInserter.command self-test OK"
    exit 0
fi

nohup "$VENV_PY" "$DIR/audio_inserter.py" >/dev/null 2>&1 &
disown
exit 0
