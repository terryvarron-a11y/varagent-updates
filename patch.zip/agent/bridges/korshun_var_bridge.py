#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
korshun_var_bridge.py — bridge v55.25

Коршун → VAR stage bridge.
Не трогает код движка VAR. Вызывает уже существующий var/usatayai_var_stage_bridge.py.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, Optional


def _app_root() -> Path:
    return Path(__file__).resolve().parent.parent


def _src_dir() -> Path:
    return Path(__file__).resolve().parent


def _safe_log(log_cb: Optional[Callable[[str, str], None]], message: str, level: str = "info") -> None:
    if log_cb:
        try:
            log_cb(message, level)
            return
        except Exception:
            pass
    print(f"[korshun-var-bridge] {message}", flush=True)


def _var_paths():
    try:
        from var_utils import var_root, get_var_python, build_cert_env
        root = var_root()
        py = get_var_python(prefer_venv=True)
        env = build_cert_env(os.environ)
    except Exception:
        root = _app_root() / "var"
        py = None
        env = dict(os.environ)
    bridge_script = root / "usatayai_var_stage_bridge.py"
    if py is None:
        py = Path(sys.executable)
    return root, bridge_script, Path(py), env


def _run_cmd(cmd: list[str], *, cwd: Path, env: dict, log_cb=None, stop_event=None,
             label: str = "VAR") -> tuple[int, list[str]]:
    _safe_log(log_cb, f"{label}: запуск: " + " ".join(str(x) for x in cmd), "info")
    kwargs = {
        "cwd": str(cwd),
        "env": env,
        "stdout": subprocess.PIPE,
        "stderr": subprocess.STDOUT,
        "text": True,
        "bufsize": 1,
    }
    if sys.platform.startswith("win"):
        kwargs["creationflags"] = 0x08000000  # CREATE_NO_WINDOW
    proc = subprocess.Popen(cmd, **kwargs)
    lines: list[str] = []
    try:
        while True:
            if stop_event is not None:
                try:
                    if stop_event.is_set() and proc.poll() is None:
                        _safe_log(log_cb, f"{label}: остановлено пользователем", "warn")
                        proc.terminate()
                        try:
                            proc.wait(timeout=8)
                        except Exception:
                            proc.kill()
                        return 130, lines
                except Exception:
                    pass
            line = proc.stdout.readline() if proc.stdout else ""
            if line:
                line = line.rstrip("\n")
                lines.append(line)
                _safe_log(log_cb, line, "info")
                continue
            if proc.poll() is not None:
                break
            time.sleep(0.05)
        rc = proc.wait()
        if rc != 0:
            tail = "\n".join(lines[-25:])
            raise RuntimeError(f"{label} завершился с кодом {rc}\n{tail}")
        return rc, lines
    finally:
        try:
            if proc.poll() is None:
                proc.kill()
        except Exception:
            pass


def _result_line(lines: list[str], prefix: str) -> str:
    for line in reversed(lines):
        if line.startswith(prefix):
            return line[len(prefix):].strip()
    return ""


def _numeric_key(value: Any) -> tuple[int, str]:
    s = str(value)
    m = re.search(r"\d+", s)
    return (int(m.group(0)) if m else 10**9, s)


def _write_style(project_dir: Path, settings: Dict[str, Any], log_cb=None) -> Path:
    style_text = str(settings.get("style_text") or "").strip()
    style_path = project_dir / "var_style_guide.txt"
    if style_text:
        style_path.write_text(style_text, encoding="utf-8")
        return style_path

    root, _bridge, _py, _env = _var_paths()
    for candidate in (root / "SG_ALL_usatayai.txt", root / "pipeline_queue" / "SG_ALL_usatayai.txt"):
        if candidate.exists():
            try:
                shutil.copy2(str(candidate), str(style_path))
                _safe_log(log_cb, f"style guide взят из {candidate.name}", "info")
                return style_path
            except Exception:
                pass

    style_path.write_text(
        "Use the transcript timing as the source of truth. "
        "Create visual prompts and a montage plan for a documentary video. "
        "Keep prompts concrete, cinematic and directly tied to the narration.",
        encoding="utf-8",
    )
    _safe_log(log_cb, "style guide не найден, записан минимальный fallback", "warn")
    return style_path


def _seconds_to_srt(seconds: float) -> str:
    seconds = max(0.0, float(seconds))
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    sec = int(seconds % 60)
    ms = int(round((seconds - int(seconds)) * 1000))
    if ms >= 1000:
        sec += 1
        ms -= 1000
    return f"{h:02d}:{m:02d}:{sec:02d},{ms:03d}"


def _transcription_json_to_srt(transcription_path: Path, out_path: Path) -> Path:
    data = json.loads(transcription_path.read_text(encoding="utf-8-sig"))
    rows = []
    for i, seg in enumerate(data.get("transcription", []), start=1):
        text = str(seg.get("text") or "").strip()
        if not text:
            continue
        rows.append(str(i))
        rows.append(f"{_seconds_to_srt(float(seg.get('start', 0)))} --> {_seconds_to_srt(float(seg.get('end', 0)))}")
        rows.append(text)
        rows.append("")
    if not rows:
        raise RuntimeError(f"transcription.json пустой или без текста: {transcription_path}")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(rows), encoding="utf-8-sig")
    return out_path


def _apply_var_settings_to_env(env: dict, settings: Dict[str, Any]) -> dict:
    env = dict(env or {})
    mapping = {
        "language": "ASSEMBLYAI_LANGUAGE_CODE",
        "director_backend": "DIRECTOR_BACKEND",
        "backend": "DIRECTOR_BACKEND",
        "gemini_model": "GEMINI_MODEL",
        "gpt_model": "GPT_MODEL",
        "gpt_chunk_size": "GPT_PASS2_CHUNK_SIZE",
        "clip_mode": "PIPELINE_CLIP_MODE",
        "clip_min": "VIDEO_CLIP_MIN_DURATION",
        "clip_max": "VIDEO_CLIP_MAX_DURATION",
        "intro_duration": "INTRO_BLOCK_DURATION",
        "intro_clip_min": "INTRO_CLIP_MIN_DURATION",
        "intro_clip_max": "INTRO_CLIP_MAX_DURATION",
        "story_mode": "STORY_MODE",
        "render_mode": "PIPELINE_RENDER_MODE",
        "concat_bitrate": "CONCAT_BITRATE",
        "bitrate": "CONCAT_BITRATE",
        "concat_fps": "VIDEO_FPS",
        "fps": "VIDEO_FPS",
        "watermark": "PIPELINE_WATERMARK",
        "logo_mode": "VARAGENT_LOGO_MODE",
        "logo_path": "VARAGENT_LOGO_PATH",
    }
    for key, env_key in mapping.items():
        if settings.get(key) not in (None, ""):
            env[env_key] = str(settings.get(key))
    if settings.get("direction_mode"):
        env["GEMINI_TWO_PASS"] = "true" if str(settings.get("direction_mode")) == "2-pass" else "false"
    if settings.get("two_pass"):
        env["GEMINI_TWO_PASS"] = "true"
    if settings.get("p1_chunk_threshold") not in (None, ""):
        try:
            env["DIRECTOR_PASS1_CHUNK_THRESHOLD"] = str(int(float(settings.get("p1_chunk_threshold"))) * 60)
        except Exception:
            pass
    if settings.get("p1_chunk_duration") not in (None, ""):
        try:
            env["DIRECTOR_PASS1_CHUNK_DURATION"] = str(int(float(settings.get("p1_chunk_duration"))) * 60)
        except Exception:
            pass
    if settings.get("logo_paths"):
        try:
            env["VARAGENT_LOGO_PATHS_JSON"] = json.dumps(list(settings.get("logo_paths") or []), ensure_ascii=False)
        except Exception:
            pass
    return env


def _manifest_to_prompts_txt(manifest_path: Path, out_path: Path) -> Path:
    data = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    prompts = data.get("prompts") or {}
    items: list[tuple[Any, str]] = []
    if isinstance(prompts, dict):
        for k, v in prompts.items():
            if isinstance(v, dict):
                text = str(v.get("prompt") or v.get("text") or v.get("content") or "").strip()
            else:
                text = str(v or "").strip()
            if text:
                items.append((k, text))
    elif isinstance(prompts, list):
        for idx, v in enumerate(prompts, start=1):
            if isinstance(v, dict):
                text = str(v.get("prompt") or v.get("text") or v.get("content") or "").strip()
            else:
                text = str(v or "").strip()
            if text:
                items.append((idx, text))
    items.sort(key=lambda kv: _numeric_key(kv[0]))
    if not items:
        raise RuntimeError(f"VAR prompts manifest пустой: {manifest_path}")
    out_path.write_text("\n\n".join(text for _k, text in items), encoding="utf-8")
    return out_path


def run_var_pipeline_for_korshun(
    *,
    project_dir: Path,
    mp3_path: Path,
    srt_path: Path,
    stem_slug: str,
    settings: Optional[Dict[str, Any]] = None,
    log_cb: Optional[Callable[[str, str], None]] = None,
    stop_event=None,
) -> Dict[str, str]:
    """Запускает этапы VAR для проекта Коршуна и возвращает пути к результатам."""
    settings = dict(settings or {})
    project_dir = Path(project_dir).expanduser().resolve()
    mp3_path = Path(mp3_path).expanduser().resolve()
    if srt_path:
        srt_path = Path(srt_path).expanduser().resolve()
    else:
        srt_path = project_dir / "transcript.srt"
    project_dir.mkdir(parents=True, exist_ok=True)

    var_root, bridge_script, py, env = _var_paths()
    env = _apply_var_settings_to_env(env, settings)
    if not bridge_script.exists():
        raise FileNotFoundError(f"VAR stage bridge не найден: {bridge_script}")

    transcriptor = str(settings.get("transcriptor") or "usataya_whisper").lower().strip()
    transcription_path = project_dir / "transcription.json"
    generated_srt_path = project_dir / "transcript.srt"

    # 1. Транскрипция для VAR.
    if transcriptor in ("assemblyai", "assembly", "assembler", "native_var"):
        _safe_log(log_cb, "AssemblyAI: транскрибация через родной VAR agent.py transcribe", "success")
        agent_py = var_root / "agent" / "agent.py"
        if not agent_py.exists():
            raise FileNotFoundError(f"VAR agent.py не найден: {agent_py}")
        cmd = [
            str(py), str(agent_py), "transcribe",
            "--audio", str(mp3_path),
            "--output", str(transcription_path),
            "--language", str(settings.get("language") or "ru"),
        ]
        _run_cmd(cmd, cwd=var_root / "agent", env=env, log_cb=log_cb, stop_event=stop_event, label="VAR AssemblyAI")
        srt_path = _transcription_json_to_srt(transcription_path, generated_srt_path)
        _safe_log(log_cb, f"AssemblyAI SRT подготовлен: {srt_path.name}", "success")
    else:
        if not srt_path.exists():
            raise FileNotFoundError(f"SRT не найден: {srt_path}")
        cmd = [
            str(py), str(bridge_script), "prepare-transcription",
            "--project-dir", str(project_dir),
            "--srt", str(srt_path),
            "--audio", str(mp3_path),
            "--language", str(settings.get("language") or "auto"),
            "--output", str(transcription_path),
        ]
        _run_cmd(cmd, cwd=var_root, env=env, log_cb=log_cb, stop_event=stop_event, label="VAR prepare-transcription")

    # 2. VAR director/prompter.
    style_path = _write_style(project_dir, settings, log_cb)
    cmd = [
        str(py), str(bridge_script), "direct",
        "--project-dir", str(project_dir),
        "--transcription", str(transcription_path),
        "--style", str(style_path),
        "--project-name", project_dir.name,
    ]
    backend = str(settings.get("director_backend") or settings.get("backend") or "default").strip()
    if backend and backend != "default":
        cmd += ["--backend", backend]
    model = str(settings.get("model") or (settings.get("gpt_model") if backend == "gpt" else settings.get("gemini_model")) or "").strip()
    if model:
        cmd += ["--model", model]
    if bool(settings.get("two_pass")) or str(settings.get("direction_mode") or "") == "2-pass":
        cmd += ["--two-pass"]
    if bool(settings.get("prompts_only")):
        cmd += ["--prompts-only"]

    _rc, direct_lines = _run_cmd(cmd, cwd=var_root, env=env, log_cb=log_cb, stop_event=stop_event, label="VAR direct")
    montage_plan = _result_line(direct_lines, "RESULT_MONTAGE_PLAN:") or str(project_dir / "montage_plan.json")
    montage_path = Path(montage_plan).expanduser()
    if not montage_path.exists():
        try:
            candidates = sorted(
                project_dir.glob("*montage*plan*.json"),
                key=lambda _p: _p.stat().st_mtime,
                reverse=True,
            )
        except Exception:
            candidates = []
        if candidates:
            montage_path = candidates[0]
            montage_plan = str(montage_path)
            _safe_log(log_cb, f"montage_plan найден fallback-поиском: {montage_path.name}", "success")
        else:
            raise RuntimeError(f"VAR director не создал montage_plan.json в проекте: {project_dir}")
    result_prompts = _result_line(direct_lines, "RESULT_PROMPTS:")

    # 3. Export prompts manifest.
    manifest_path = project_dir / "usatayai_prompts_manifest.json"
    cmd = [
        str(py), str(bridge_script), "export-prompts",
        "--project-dir", str(project_dir),
        "--output", str(manifest_path),
    ]
    if result_prompts:
        cmd += ["--prompts-file", result_prompts]
    _run_cmd(cmd, cwd=var_root, env=env, log_cb=log_cb, stop_event=stop_event, label="VAR export-prompts")

    # 4. Convert manifest to flat txt for Усатая generators.
    stamp = datetime.now().strftime("%Y-%m-%d_%H-%M")
    prompts_txt = project_dir / f"{stem_slug}_var_prompts_{stamp}.txt"
    _manifest_to_prompts_txt(manifest_path, prompts_txt)

    return {
        "project_dir": str(project_dir),
        "transcription": str(transcription_path),
        "srt": str(srt_path),
        "montage_plan": str(Path(montage_plan)),
        "prompts_manifest": str(manifest_path),
        "prompts_txt": str(prompts_txt),
        "style_path": str(style_path),
    }
