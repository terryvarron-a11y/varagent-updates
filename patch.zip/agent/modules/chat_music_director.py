"""
Chat Music Director — music-режиссёр через прямой chat/completions API
(deepseek | openrouter). Drop-in вариант MusicDirector без Codex.

Наследует MusicDirector: переиспользует plan() (валидация/нормализация плана),
переопределяет только __init__, _build_prompt (INLINE контент — модель не читает
файлы) и _run_codex (chat-вызов вместо Codex CLI). Транспорт — modules.chat_client.
"""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Optional

import config
from modules import chat_client
from modules.music_director import MusicDirector


class ChatMusicDirector(MusicDirector):
    """Music supervisor через прямой chat API (deepseek | openrouter)."""

    def __init__(self, model_name: Optional[str] = None):
        # backend задаёт провайдера: MUSIC_DIRECTOR_BACKEND или общий GPT_PROVIDER
        self.provider = (getattr(config, 'MUSIC_DIRECTOR_BACKEND', '') or
                         getattr(config, 'GPT_PROVIDER', '')).strip().lower()
        if self.provider in ('gpt', 'openai'):
            self.provider = (getattr(config, 'GPT_PROVIDER', '') or 'openai').strip().lower()
        if self.provider not in (
            'deepseek', 'openrouter', 'meta_muse', 'cliproxy', 'claude_api',
            'codex_reseller', 'gpt_nexus',
        ):
            raise ValueError(f"ChatMusicDirector не поддерживает провайдер: {self.provider}")

        def _valid_override(name) -> bool:
            return bool(name) and 'gemini' not in str(name).lower()

        if self.provider == 'deepseek':
            self.model_name = model_name if _valid_override(model_name) else (config.DEEPSEEK_MODEL or 'deepseek-v4-flash')
            self.web = False
        elif self.provider == 'meta_muse':
            self.model_name = model_name if _valid_override(model_name) else (
                getattr(config, 'META_MUSE_MODEL', '')
                or 'muse-spark-1.2-contributor'
            )
            self.web = False
        elif self.provider == 'cliproxy':
            # CLIProxyAPI отдаёт gemini/claude/grok через локальный прокси — имя модели
            # gemini-специфичное, поэтому _valid_override здесь не применяем.
            self.model_name = getattr(config, 'CLIPROXY_MODEL', '') or 'gemini-3.1-pro-low'
            self.web = False
        elif self.provider == 'claude_api':
            self.model_name = model_name if _valid_override(model_name) else (
                getattr(config, 'CLAUDE_API_MODEL', '') or 'kr/claude-sonnet-4.6')
            self.web = False
        elif self.provider in ('codex_reseller', 'gpt_nexus'):
            self.model_name = model_name if _valid_override(model_name) else (
                getattr(config, 'CODEX_RESELLER_MODEL', '') if self.provider == 'codex_reseller'
                else getattr(config, 'GPT_NEXUS_MODEL', '')
            ) or ('gpt-5.6-terra' if self.provider == 'codex_reseller' else 'gpt-5.5')
            self.web = False
        else:  # openrouter
            self.model_name = model_name if _valid_override(model_name) else (config.OPENROUTER_MODEL or 'openrouter/free')
            self.web = (getattr(config, 'OPENROUTER_WEB_SEARCH', 'disabled') == 'enabled')

        # Music-специфичная модель (если задана) перекрывает провайдерский дефолт —
        # музыкальный план можно писать любой моделью независимо от director'а.
        _mcm = (getattr(config, 'MUSIC_CHAT_MODEL', '') or '').strip()
        if (
            self.provider == 'meta_muse'
            and _mcm == (
                getattr(config, 'META_MUSE_MODEL', '')
                or 'muse-spark-1.2-contributor'
            )
        ):
            self.model_name = _mcm
        elif self.provider != 'meta_muse' and _mcm and 'gemini' not in _mcm.lower():
            self.model_name = _mcm

        self.reasoning_level = getattr(config, 'CHAT_REASONING_LEVEL', 'medium')
        self.max_tokens = max(getattr(config, 'CHAT_MAX_TOKENS', 8000), 16000)
        self.timeout = config.GPT_DIRECTOR_TIMEOUT
        self.schemas_dir = Path(__file__).parent.parent / 'schemas'
        self.prompts_dir = Path(__file__).parent.parent / 'prompts'

        if not chat_client._api_key(self.provider):
            raise ValueError(f"ChatMusicDirector: API ключ для {self.provider} не задан")

    # ---- INLINE prompt (модель не имеет доступа к ФС) ----
    def _build_prompt(
        self,
        sys_instr_path: Path,
        transcription_path: Path,
        montage_plan_path: Path,
        style_guide_path: Path,
        output_path: Path,
        project_name: str,
        audio_duration: float,
    ) -> str:
        def _read(p: Path, fallback: str = "") -> str:
            try:
                return Path(p).read_text(encoding='utf-8-sig')
            except Exception:
                return fallback

        si_text = _read(sys_instr_path, "(music director instruction unavailable)")
        tr_text = _read(transcription_path, "{}")
        mp_text = _read(montage_plan_path, "{}")
        sg_text = _read(style_guide_path, "(style guide unavailable)")
        target_volume_db = float(getattr(config, 'MUSIC_DEFAULT_VOLUME_DB', -21))

        return f"""You are a music director / sound supervisor for a storytelling video.

## SYSTEM INSTRUCTION
{si_text}

Follow ALL rules above — especially:
- Derive each track's genre, instruments, tempo and harmony from the actual content,
  emotion and SPEECH INTONATION of the transcript segment it covers. No generic templates.
- Place every music change exactly on a TONAL SHIFT in the narration, not on a timer.
- For EVERY track write a Russian `text_anchor`: which words/emotion/intonation drove its sound.
- ALL tracks must be `instrumental: true` (no vocals/lyrics/singing).
- Background bed for narration: even, restrained, must not overpower the voice.
  Loudness target {target_volume_db:g} dB (overrides any example in the instruction).
- Track 1 = dynamic intro bed: audible in the first second, first beat at 0:00,
  no silence/slow fade-in; breathtaking hook for 8-12s then settle under narration.
- prefer long 120-240s tracks, max 10 total. prompt/tags in English; mood/title can be Russian.

## TRANSCRIPTION (voiceover with timestamps)
{tr_text}

## MONTAGE PLAN (visual clips structure)
{mp_text}

## STYLE GUIDE (project tone)
{sg_text}

## PROJECT
Name: {project_name}
Audio duration: {audio_duration:.2f} seconds

## TASK
Analyze the narrative arc; plan music tracks whose boundaries land on tonal shifts
(NOT mechanical equal slicing). Derive each track's sound from meaning + intonation,
then write Suno-ready `prompt`/`tags` + Russian `text_anchor`.

Return STRICT JSON (no markdown, no commentary) with this structure:
{{
  "music_plan": {{
    "audioDuration": {audio_duration:.2f},
    "global_volume_db": {target_volume_db:g},
    "tracks": [
      {{
        "id": 1, "startTime": 0.0, "endTime": 95.4,
        "mood": "напряжённое начало",
        "text_anchor": "Завязка про угрозу, низкая веская интонация -> тёмный пульсирующий бэд",
        "genre": "cinematic dark ambient", "energy": "high", "energy_arc": "high->mid",
        "prompt": "dynamic cinematic intro, pulsing percussion, impact on first beat, audible in first second, urgent momentum, tense orchestral stabs, breathtaking hook then settles under narration, no silence before music, no slow fade-in",
        "tags": "dynamic intro, cinematic, tense, urgent, pulsing percussion, instrumental",
        "title": "Opening - Tension",
        "volume_db": {target_volume_db:g}, "hook_seconds": 12,
        "fade_in_ms": 0, "fade_out_ms": 2500, "instrumental": true
      }}
    ]
  }}
}}

## RULES
- All `instrumental: true` (hard rule). Every track has a non-empty Russian `text_anchor`.
- First track startTime = 0.0; first track is a dynamic intro (energy high/mid-high,
  fade_in_ms=0, immediate rhythmic momentum, audible in first second).
- Last track endTime ≈ {audio_duration:.2f}. Adjacent: track[N].endTime == track[N+1].startTime.
- IDs sequential 1,2,3,...; 120 ≤ (endTime-startTime) ≤ 240 when length allows; total 2-10 tracks.
Return ONLY the JSON object. Do NOT create files. Do NOT write scripts."""

    # ---- chat-вызов вместо Codex; записывает music_plan.json сам ----
    def _run_codex(
        self,
        task_prompt: str,
        schema_file: str,
        result_file: Path,
        working_dir: Path,
    ) -> dict:
        print(f"\n[Music] Chat Music Director ({self.provider} / {self.model_name})...")
        t0 = time.time()
        try:
            raw = chat_client.chat_completion(
                self.provider, self.model_name,
                [{"role": "user", "content": task_prompt}],
                max_tokens=self.max_tokens,
                reasoning_level=self.reasoning_level,
                web=self.web, json_mode=True, timeout=self.timeout,
            )
        except chat_client.ChatError as e:
            return {'status': 'error', 'error_message': str(e)}

        plan = self._parse_plan_json(raw)
        if not plan or not (plan.get('tracks') or plan.get('music_plan', {}).get('tracks')):
            (working_dir / '_chat_music_raw.txt').write_text(raw or '', encoding='utf-8')
            return {'status': 'error',
                    'error_message': 'no tracks parsed (raw → _chat_music_raw.txt)'}

        mp_path = working_dir / 'music_plan.json'
        # нормализуем обёртку: всегда пишем {"music_plan": {...}}
        wrapped = plan if 'music_plan' in plan else {'music_plan': plan}
        mp_path.write_text(json.dumps(wrapped, indent=2, ensure_ascii=False), encoding='utf-8')
        print(f"   Chat Music Director: {time.time()-t0:.0f}s")
        return {'status': 'ok', 'music_plan_path': str(mp_path)}

    @staticmethod
    def _parse_plan_json(raw: str) -> dict:
        raw = (raw or '').strip()
        if not raw:
            return {}
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            pass
        s, e = raw.find('{'), raw.rfind('}')
        if s >= 0 and e > s:
            try:
                return json.loads(raw[s:e + 1])
            except json.JSONDecodeError:
                pass
        return {}
