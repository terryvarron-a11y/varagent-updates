#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
chmod +x "$SCRIPT_DIR"/*.command 2>/dev/null
[ -f "$SCRIPT_DIR/.venv/bin/activate" ] && source "$SCRIPT_DIR/.venv/bin/activate"

if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e 'tell app "Terminal" to do script "cd '\''$SCRIPT_DIR'\'' && exec '\''$0'\''"'
    exit 0
fi

clear

echo ""
echo "================================================================================"
echo " 1_INTERACTIVESTART  [Transcription + Direction]  INTERACTIVE MODE"
echo "================================================================================"
echo ""
echo " Transcription language:"
echo "   [1] ru  - Russian     (default)"
echo "   [2] en  - English"
echo "   [3] es  - Spanish"
echo "   [4] de  - German"
echo "   [5] fr  - French"
echo "   [6] pl  - Polish"
echo "   [7] uk  - Ukrainian"
echo "   [8] it  - Italian"
echo "   [9] Other (type manually)"
echo ""

LANG="ru"
echo -n "  Language [1-9] (Enter = ru): "
read LANG_CHOICE

case "$LANG_CHOICE" in
    1|"") LANG="ru" ;;
    2) LANG="en" ;;
    3) LANG="es" ;;
    4) LANG="de" ;;
    5) LANG="fr" ;;
    6) LANG="pl" ;;
    7) LANG="uk" ;;
    8) LANG="it" ;;
    9) echo -n "  Type language code: " && read LANG ;;
esac

echo ""
echo " [OK] Language: $LANG"
echo ""

echo " Direction mode:"
echo "   [1] 1-pass   (fast, up to ~200 clips)"
echo "   [2] 2-pass   (long projects, 200+ clips)"
echo ""

TWO_PASS_FLAG=""
echo -n " Choose [1/2] (Enter = 1): "
read CHOICE
case "$CHOICE" in
    2) TWO_PASS_FLAG="--two-pass"; echo " [OK] 2-pass mode" ;;
    *) TWO_PASS_FLAG=""; echo " [OK] 1-pass mode" ;;
esac

echo ""
ENV_FILE="$SCRIPT_DIR/agent/.env"
DEF_VID_MIN=4; DEF_VID_MAX=8
DEF_SLD_MIN=2; DEF_SLD_MAX=7
INTRO_BLOCK=30; INTRO_MIN=0; INTRO_MAX=0

if [ -f "$ENV_FILE" ]; then
    while IFS='=' read -r KEY VAL; do
        KEY="${KEY// /}"
        case "$KEY" in
            VIDEO_CLIP_MIN_DURATION)     DEF_VID_MIN="$VAL" ;;
            VIDEO_CLIP_MAX_DURATION)     DEF_VID_MAX="$VAL" ;;
            SLIDESHOW_CLIP_MIN_DURATION) DEF_SLD_MIN="$VAL" ;;
            SLIDESHOW_CLIP_MAX_DURATION) DEF_SLD_MAX="$VAL" ;;
            INTRO_BLOCK_DURATION)        INTRO_BLOCK="$VAL" ;;
            INTRO_CLIP_MIN_DURATION)     INTRO_MIN="$VAL" ;;
            INTRO_CLIP_MAX_DURATION)     INTRO_MAX="$VAL" ;;
        esac
    done < "$ENV_FILE"
fi

echo " Clip type:"
echo "   [1] Video      (Veo3 fragments)  ${DEF_VID_MIN}-${DEF_VID_MAX}s  (default)"
echo "   [2] Slideshow  (images)          ${DEF_SLD_MIN}-${DEF_SLD_MAX}s"
echo ""

CLIP_MODE="video"
echo -n " Choose [1/2] (Enter = 1): "
read CLIP_CHOICE
case "$CLIP_CHOICE" in
    2) CLIP_MODE="slideshow"; echo " [OK] Slideshow mode" ;;
    *) CLIP_MODE="video"; echo " [OK] Video mode" ;;
esac

# ============================================================================
# CLIP DURATION
# ============================================================================

if [ "$CLIP_MODE" = "slideshow" ]; then
    DEF_MIN="$DEF_SLD_MIN"; DEF_MAX="$DEF_SLD_MAX"
else
    DEF_MIN="$DEF_VID_MIN"; DEF_MAX="$DEF_VID_MAX"
fi

echo ""
echo " Clip duration:"
echo "   Default: ${DEF_MIN}s - ${DEF_MAX}s  (from .env)"
echo "   [1] Keep defaults  (Enter)"
echo "   [2] Change"
echo ""

CLIP_MIN="$DEF_MIN"; CLIP_MAX="$DEF_MAX"
echo -n " Duration [1/2] (Enter = keep): "
read DUR_CHOICE
if [ "$DUR_CHOICE" = "2" ]; then
    echo -n " Min duration (s): " && read CLIP_MIN
    echo -n " Max duration (s): " && read CLIP_MAX
    echo " [OK] Duration: ${CLIP_MIN}s - ${CLIP_MAX}s"
else
    echo " [OK] Duration: ${DEF_MIN}s - ${DEF_MAX}s (defaults)"
fi

echo ""
echo " Intro block (.env, not changed interactively):"
echo "   First ${INTRO_BLOCK}s of video  /  clips: ${INTRO_MIN}s - ${INTRO_MAX}s"
echo ""

echo "================================================================================"
echo " Starting: lang=$LANG  two-pass=${TWO_PASS_FLAG:-(none)}  clip=$CLIP_MODE  duration=${CLIP_MIN}s-${CLIP_MAX}s"
echo "================================================================================"
echo ""

cd "$SCRIPT_DIR/agent"
python3 agent.py process --run --language "$LANG" $TWO_PASS_FLAG --clip-mode "$CLIP_MODE" --clip-min "$CLIP_MIN" --clip-max "$CLIP_MAX"
RESULT=$?

echo ""
if [ $RESULT -ne 0 ]; then
    echo "================================================================================"
    echo " [ERROR] Pipeline failed!"
    echo "================================================================================"
else
    echo "================================================================================"
    echo " [OK] 1_INTERACTIVESTART complete! Check projects/ folder."
    echo "================================================================================"
    echo " NEXT: Open *_prompts_*.txt and generate video in Veo3"
fi
echo "Press Enter to exit..." && read
exit $RESULT
