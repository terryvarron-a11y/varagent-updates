#!/bin/bash
# START_VEO_IMGGEN.COMMAND - VeoNonStop Image Generation (Imagen/Banana)
# Run: double-click this file in Finder

PROJECT_NAME="{project_name}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
AGENT_DIR="$(cd "$SCRIPT_DIR/../../agent" && pwd)"

chmod +x *.command *.sh 2>/dev/null
[ -f "$SCRIPT_DIR/.venv/bin/activate" ] && source "$SCRIPT_DIR/.venv/bin/activate"

if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e "tell app \"Terminal\" to do script \"cd '$SCRIPT_DIR' && exec '$0'\""
    exit 0
fi

echo ""
echo "========================================================================"
echo "  VeoNonStop IMAGE GENERATION"
echo "  Project: $PROJECT_NAME"
echo "========================================================================"
echo ""

# Mode selection
echo "  Image generator:"
echo "    [1] Imagen 3.5      - fast text-to-image"
echo "    [2] Banana Pro       - text-to-image, high quality"
echo "    [3] Banana Pro + ref - text-to-image with style-reference"
echo ""
read -p "  Generator [1/2/3] (Enter = 1): " MODE_CHOICE
MODE="imagen"
case "$MODE_CHOICE" in
    2) MODE="banana" ;;
    3) MODE="banana_ref" ;;
esac
echo "    Selected: $MODE"
echo ""

# Check ref/ for banana_ref
if [ "$MODE" = "banana_ref" ]; then
    if [ ! -d "$SCRIPT_DIR/ref" ]; then
        echo "  [WARN] ref/ folder not found!"
        read -p "  Continue without refs? (y/n): " REF_CONFIRM
        if [ "$REF_CONFIRM" != "y" ] && [ "$REF_CONFIRM" != "Y" ]; then
            echo "  Cancelled."
            exit 0
        fi
    else
        echo "  ref/ folder found - using as style reference"
        echo ""
    fi
fi

# Aspect ratio
echo "  Select aspect ratio:"
echo "    [1] 16:9   landscape, default"
echo "    [2] 9:16   portrait"
echo "    [3] 1:1    square"
echo ""
read -p "  Aspect [1/2/3] (Enter = 1): " RATIO_CHOICE
RATIO="16:9"
case "$RATIO_CHOICE" in
    2) RATIO="9:16" ;;
    3) RATIO="1:1" ;;
esac
echo "    Selected: $RATIO"
echo ""

# Parallel
read -p "  Parallel workers (Enter = 10): " PARALLEL
PARALLEL="${PARALLEL:-10}"
echo "    Selected: $PARALLEL"
echo ""

# Clip IDs
read -p "  Clip IDs (e.g. 1,2,3 or Enter for all): " IDS_INPUT
IDS_ARG=""
if [ -n "$IDS_INPUT" ]; then
    IDS_ARG="--ids $IDS_INPUT"
    echo "    Clips: $IDS_INPUT"
else
    echo "    Clips: ALL"
fi
echo ""

# Confirm
echo "========================================================================"
echo "  SUMMARY:"
echo "    Project:   $PROJECT_NAME"
echo "    Generator: $MODE"
echo "    Ratio:     $RATIO"
echo "    Parallel:  $PARALLEL"
echo "========================================================================"
echo ""
read -p "  Start? (y/n): " CONFIRM
if [ "$CONFIRM" != "y" ] && [ "$CONFIRM" != "Y" ]; then
    echo "  Cancelled."
    exit 0
fi

echo ""
echo "  Starting image generation..."
echo ""

cd "$AGENT_DIR"

python agent.py generate \
    --project "$PROJECT_NAME" \
    --image-gen "$MODE" \
    --aspect "$RATIO" \
    --parallel "$PARALLEL" $IDS_ARG

EXIT_CODE=$?
echo ""
if [ $EXIT_CODE -ne 0 ]; then
    echo "[ERROR] Image generation failed. See log above."
else
    echo "========================================================================"
    echo "  DONE. Output: $SCRIPT_DIR/generated/"
    echo "========================================================================"
fi
echo ""
read -p "Press Enter to close..."
