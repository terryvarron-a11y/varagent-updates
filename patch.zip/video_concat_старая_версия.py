#!/usr/bin/env python3
"""
ГРУППОВАЯ СКЛЕЙКА - v5 FAST TRIM
• Валидация монтажного плана
• Анализ и заполнение всех гэпов
• Проверка существующих файлов
• Групповая склейка без перекодирования
• Автоисправление финальной синхронизации (быстрое обрезание)
• GPU ускорение
• Логгирование всех операций
• Запрос перед удалением temp папки
"""

import subprocess
import json
import sys
import os
import argparse
from pathlib import Path
from tqdm import tqdm
import platform
import time
import shutil
import logging
from datetime import datetime
import traceback

if platform.system() == 'Windows':
    SUBPROCESS_FLAGS = {'creationflags': 0x08000000}
else:
    SUBPROCESS_FLAGS = {}

# ============================================================================
# НАСТРОЙКА ЛОГГИРОВАНИЯ
# ============================================================================

def setup_logging():
    """Настраивает логгирование в файл и консоль"""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = f'video_concat_{timestamp}.log'

    # Создаём логгер
    logger = logging.getLogger('VideoConcat')
    logger.setLevel(logging.DEBUG)

    # Формат логов
    formatter = logging.Formatter(
        '%(asctime)s | %(levelname)-8s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    # Хендлер для файла (все логи включая DEBUG)
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    # Хендлер для консоли (только WARNING и выше)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.WARNING)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    logger.info("="*80)
    logger.info("НАЧАЛО РАБОТЫ СКРИПТА")
    logger.info("="*80)

    return logger, log_file

# Глобальный логгер
logger = None

# ============================================================================
# ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
# ============================================================================

def get_audio_duration(audio_path):
    """Получает длительность аудиофайла в секундах"""
    try:
        logger.debug(f"Получение длительности аудио: {audio_path}")
        result = subprocess.run(
            ['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
             '-of', 'default=noprint_wrappers=1:nokey=1', audio_path],
            capture_output=True, text=True, check=True, **SUBPROCESS_FLAGS
        )
        duration = float(result.stdout.strip())
        logger.info(f"Длительность аудио: {duration:.2f} сек")
        return duration
    except Exception as e:
        logger.error(f"Ошибка при получении длительности аудио: {e}")
        logger.error(traceback.format_exc())
        print(f"❌ Ошибка при получении длительности аудио: {e}")
        sys.exit(1)

def get_video_duration(video_path):
    """Получает длительность видеофайла в секундах"""
    try:
        result = subprocess.run(
            ['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
             '-of', 'default=noprint_wrappers=1:nokey=1', str(video_path)],
            capture_output=True, text=True, check=True, **SUBPROCESS_FLAGS
        )
        duration = float(result.stdout.strip())
        logger.debug(f"Длительность видео {video_path}: {duration:.2f} сек")
        return duration
    except Exception as e:
        logger.warning(f"Не удалось получить длительность {video_path}: {e}")
        return 0

def get_file_size_mb(file_path):
    """Получает размер файла в МБ"""
    try:
        size = os.path.getsize(file_path) / (1024 * 1024)
        return size
    except:
        return 0

def check_processed_file(file_path, min_size_kb=100):
    """Проверяет что обработанный файл существует и не битый"""
    if not os.path.exists(file_path):
        return False
    if os.path.getsize(file_path) < min_size_kb * 1024:
        logger.debug(f"Файл {file_path} слишком мал")
        return False
    try:
        duration = get_video_duration(file_path)
        return duration > 0
    except:
        return False

def validate_montage_plan(clips, audio_path):
    """Валидация монтажного плана"""
    logger.info("ЭТАП 1: ВАЛИДАЦИЯ МОНТАЖНОГО ПЛАНА")

    print("\n" + "="*80)
    print("📋 ВАЛИДАЦИЯ МОНТАЖНОГО ПЛАНА")
    print("="*80)

    if not clips:
        logger.error("Ошибка: нет clips в плане!")
        print("❌ Ошибка: нет clips в плане!")
        sys.exit(1)

    actual_audio_duration = get_audio_duration(audio_path)
    if actual_audio_duration is None:
        logger.error(f"Не удалось получить длительность аудио: {audio_path}")
        print(f"❌ Не удалось получить длительность аудио: {audio_path}")
        sys.exit(1)
    logger.info(f"Количество clips в плане: {len(clips)}")

    print(f"\n📊 Длительность аудио: {actual_audio_duration:.2f} сек")
    print(f"📊 Количество clips: {len(clips)}")

    first_start = clips[0]['startTime']
    last_end = clips[-1]['endTime']

    logger.info(f"Первый clip начинается: {first_start:.2f} сек")
    logger.info(f"Последний clip заканчивается: {last_end:.2f} сек")

    print(f"\n📊 Покрытие плана:")
    print(f"   • Первый clip: {first_start:.2f} сек")
    print(f"   • Последний clip: {last_end:.2f} сек")
    print(f"   • Аудио: 0.00 - {actual_audio_duration:.2f} сек")

    if first_start > 0.1:
        logger.warning(f"Гэп в начале: {first_start:.2f} сек")
        print(f"\n⚠️  ВНИМАНИЕ: Первый clip начинается с {first_start:.2f}с (будет исправлено)")

    if abs(last_end - actual_audio_duration) > 0.1:
        if last_end < actual_audio_duration:
            logger.warning(f"Гэп в конце: {actual_audio_duration - last_end:.2f} сек")
            print(f"⚠️  ВНИМАНИЕ: Последний clip {last_end:.2f}с < аудио {actual_audio_duration:.2f}с (будет исправлено)")
        else:
            logger.warning(f"Последний clip длиннее аудио на {last_end - actual_audio_duration:.2f} сек")
            print(f"⚠️  ВНИМАНИЕ: Последний clip {last_end:.2f}с > аудио {actual_audio_duration:.2f}с")

    print(f"\n✅ Валидация завершена")
    print("="*80)
    logger.info("Валидация плана завершена успешно")

    return actual_audio_duration

def analyze_gaps(clips, audio_duration):
    """Анализирует все гэпы: в начале, внутри, в конце"""
    logger.info("ЭТАП 2: АНАЛИЗ ГЭПОВ")

    print("\n" + "="*80)
    print("🔍 АНАЛИЗ ГЭПОВ")
    print("="*80)

    gaps_info = []
    corrections = []

    # 1. Проверка начального гэпа
    first_start = clips[0]['startTime']
    if first_start > 0.01:
        gap = first_start
        logger.info(f"ГЭП В НАЧАЛЕ: {gap:.2f} сек")
        gaps_info.append(f"⚠️  ГЭП В НАЧАЛЕ: {gap:.2f} сек (до первого clip)")
        corrections.append({
            'type': 'start_gap',
            'clip_index': 0,
            'original_start': first_start,
            'new_start': 0.0,
            'gap_size': gap
        })

    # 2. Проверка внутренних гэпов
    for i in range(len(clips) - 1):
        end_current = clips[i]['endTime']
        start_next = clips[i+1]['startTime']

        if start_next > end_current + 0.01:
            gap = start_next - end_current
            logger.info(f"ВНУТРЕННИЙ ГЭП #{i+1}: {gap:.2f} сек между clip {clips[i]['id']} и {clips[i+1]['id']}")
            gaps_info.append(f"⚠️  ГЭП #{i+1}: {gap:.2f} сек между clip {clips[i]['id']} и {clips[i+1]['id']}")

            # Всегда растягиваем предыдущий клип чтобы покрыть гэп
            # Это даёт плавное видео без фриз-кадров
            logger.info(f"  → Решение: РЕТАЙМ clip {clips[i]['id']} (+{gap:.2f} сек)")
            corrections.append({
                'type': 'retime_extend',
                'clip_index': i,
                'gap_size': gap,
                'original_duration': end_current - clips[i]['startTime'],
                'new_duration': (end_current - clips[i]['startTime']) + gap
            })

    # 3. Проверка конечного гэпа
    last_end = clips[-1]['endTime']
    if last_end < audio_duration - 0.01:
        gap = audio_duration - last_end
        logger.info(f"ГЭП В КОНЦЕ: {gap:.2f} сек")
        gaps_info.append(f"⚠️  ГЭП В КОНЦЕ: {gap:.2f} сек (после последнего clip)")
        corrections.append({
            'type': 'end_gap',
            'clip_index': len(clips) - 1,
            'original_end': last_end,
            'new_end': audio_duration,
            'gap_size': gap
        })

    # Вывод результатов
    if gaps_info:
        logger.info(f"Найдено гэпов: {len(gaps_info)}")
        print(f"\n📊 Найдено гэпов: {len(gaps_info)}")
        for info in gaps_info:
            print(f"   {info}")

        print(f"\n🔧 План корректировок:")
        for corr in corrections:
            if corr['type'] == 'start_gap':
                print(f"   • Clip {clips[corr['clip_index']]['id']}: РЕТАЙМ начала с {corr['original_start']:.2f}→0.00 (+{corr['gap_size']:.2f}с)")
            elif corr['type'] == 'end_gap':
                print(f"   • Clip {clips[corr['clip_index']]['id']}: РЕТАЙМ конца с {corr['original_end']:.2f}→{corr['new_end']:.2f} (+{corr['gap_size']:.2f}с)")
            elif corr['type'] == 'retime_extend':
                print(f"   • Clip {clips[corr['clip_index']]['id']}: РЕТАЙМ длительности {corr['original_duration']:.2f}→{corr['new_duration']:.2f}с")
    else:
        logger.info("Гэпов не обнаружено")
        print(f"\n✅ Гэпов не обнаружено! План идеален!")

    print("="*80)
    logger.info(f"Анализ гэпов завершен. Корректировок: {len(corrections)}")

    return corrections

def fix_video_audio_sync(video_path, audio_path, temp_dir, encoder_type, codec, bitrate):
    """АВТОМАТИЧЕСКОЕ ИСПРАВЛЕНИЕ рассинхронизации видео и аудио"""
    logger.info("ЭТАП 6: ПРОВЕРКА ФИНАЛЬНОЙ СИНХРОНИЗАЦИИ")
    print("\n" + "="*80)
    print("🔧 ПРОВЕРКА ФИНАЛЬНОЙ СИНХРОНИЗАЦИИ")
    print("="*80)

    video_duration = get_video_duration(video_path)
    audio_duration = get_audio_duration(audio_path)

    logger.info(f"Длительность склеенного видео: {video_duration:.2f} сек")
    logger.info(f"Длительность аудио озвучки: {audio_duration:.2f} сек")

    print(f"\n📊 Длительность склеенного видео: {video_duration:.2f} сек")
    print(f"📊 Длительность аудио озвучки: {audio_duration:.2f} сек")

    diff = video_duration - audio_duration
    print(f"📊 Разница: {diff:.2f} сек")
    logger.info(f"Разница: {diff:.2f} сек")

    # Идеальная синхронизация
    if abs(diff) <= 0.1:
        logger.info("Синхронизация идеальна")
        print(f"\n✅ Отлично! Синхронизация идеальна (разница {abs(diff):.2f} сек)")
        print("="*80)
        return str(video_path)

    # Допустимая рассинхронизация
    if abs(diff) <= 0.5:
        logger.info("Небольшая рассинхронизация, допустима")
        print(f"\n✅ Хорошо! Небольшая рассинхронизация ({abs(diff):.2f} сек)")
        print("="*80)
        return str(video_path)

    # Если видео ДЛИННЕЕ аудио — всегда просто обрезаем без перекодирования
    # (это норма: последний клип мог выходить за границу аудио на любое кол-во секунд)
    if diff > 0:
        logger.info(f"Видео длиннее аудио на {diff:.2f} сек - обрезаем без перекодирования")
        print(f"\n🔧 Видео длиннее аудио на {diff:.2f} сек")
        print(f"   💡 Обрезаем лишнее с конца (без перекодирования)...")

        fixed_video = temp_dir / 'concat_video_trimmed.mp4'
        cmd = [
            'ffmpeg', '-y',
            '-i', str(video_path),
            '-t', str(audio_duration),
            '-c', 'copy',
            str(fixed_video)
        ]
        logger.debug(f"FFmpeg команда: {' '.join(cmd)}")

        start_time = time.time()
        try:
            subprocess.run(cmd, check=True, capture_output=True, **SUBPROCESS_FLAGS)
            elapsed = time.time() - start_time
            logger.info(f"Обрезание выполнено за {elapsed:.1f}с")
            print(f"   ✅ Готово за {elapsed:.1f}с (без перекодирования!)")
        except subprocess.CalledProcessError as e:
            logger.error(f"Ошибка обрезания: {e}")
            logger.error(traceback.format_exc())
            raise

        fixed_duration = get_video_duration(fixed_video)
        final_diff = abs(fixed_duration - audio_duration)
        logger.info(f"Новая длительность видео: {fixed_duration:.2f} сек, разница: {final_diff:.2f} сек")

        print(f"\n✅ Исправление завершено!")
        print(f"   Новая длительность видео: {fixed_duration:.2f} сек")
        print(f"   Разница с аудио: {final_diff:.2f} сек")
        print("="*80)

        return str(fixed_video)

    # Видео КОРОЧЕ аудио на небольшую величину (0.5-5 сек) - freeze frame
    if abs(diff) <= 5.0:
        logger.info(f"Видео короче аудио на {abs(diff):.2f} сек - добавляем freeze frame")
        print(f"\n🔧 Видео короче аудио на {abs(diff):.2f} сек")
        print(f"   Добавляем freeze frame в конец...")

        fixed_video = temp_dir / 'concat_video_trimmed.mp4'
        freeze_duration = abs(diff)
        freeze_frame = temp_dir / 'freeze_frame_end.mp4'

        temp_frame = temp_dir / 'last_frame.png'
        cmd_extract = [
            'ffmpeg', '-y',
            '-sseof', '-1',
            '-i', str(video_path),
            '-update', '1',
            '-q:v', '1',
            str(temp_frame)
        ]
        subprocess.run(cmd_extract, check=True, capture_output=True, **SUBPROCESS_FLAGS)

        encoder_params = get_encoder_params(encoder_type, codec, bitrate)
        cmd_freeze = [
            'ffmpeg', '-y',
            '-loop', '1',
            '-i', str(temp_frame),
            '-t', str(freeze_duration),
            '-r', '60'
        ] + encoder_params + [
            '-an',
            str(freeze_frame)
        ]
        subprocess.run(cmd_freeze, check=True, capture_output=True, **SUBPROCESS_FLAGS)
        temp_frame.unlink()

        concat_list = temp_dir / 'concat_with_freeze.txt'
        with open(concat_list, 'w', encoding='utf-8') as f:
            f.write(f"file '{Path(video_path).absolute()}'\n")
            f.write(f"file '{freeze_frame.absolute()}'\n")

        cmd = [
            'ffmpeg', '-y',
            '-f', 'concat',
            '-safe', '0',
            '-i', str(concat_list),
            '-c', 'copy',
            str(fixed_video)
        ]
        logger.debug(f"FFmpeg команда: {' '.join(cmd)}")

        start_time = time.time()
        try:
            subprocess.run(cmd, check=True, capture_output=True, **SUBPROCESS_FLAGS)
            elapsed = time.time() - start_time
            logger.info(f"Freeze frame добавлен за {elapsed:.1f}с")
            print(f"   ✅ Готово за {elapsed:.1f}с")
        except subprocess.CalledProcessError as e:
            logger.error(f"Ошибка добавления freeze frame: {e}")
            logger.error(traceback.format_exc())
            raise

        fixed_duration = get_video_duration(fixed_video)
        final_diff = abs(fixed_duration - audio_duration)
        logger.info(f"Новая длительность видео: {fixed_duration:.2f} сек, разница: {final_diff:.2f} сек")

        print(f"\n✅ Исправление завершено!")
        print(f"   Новая длительность видео: {fixed_duration:.2f} сек")
        print(f"   Разница с аудио: {final_diff:.2f} сек")
        print("="*80)

        return str(fixed_video)

    # Видео КОРОЧЕ аудио на много (> 5 сек) - нужно замедление (перекодирование)
    logger.warning(f"Видео короче аудио на {abs(diff):.2f} сек - применяю замедление")
    print(f"\n🔧 Видео короче аудио на {abs(diff):.2f} сек")
    print(f"   Применяю замедление (требует перекодирования)...")

    fixed_video = temp_dir / 'concat_video_fixed.mp4'
    encoder_params = get_encoder_params(encoder_type, codec, bitrate)
    speed_factor = video_duration / audio_duration

    if diff < 0:
        logger.info(f"Замедляем видео: {speed_factor:.4f}x")
        print(f"   Видео короче аудио на {abs(diff):.2f} сек")
        print(f"   Замедляем видео: {speed_factor:.4f}x")
    else:
        logger.info(f"Ускоряем видео: {speed_factor:.4f}x")
        print(f"   Видео длиннее аудио на {diff:.2f} сек")
        print(f"   Ускоряем видео: {speed_factor:.4f}x")

    cmd = [
        'ffmpeg', '-y',
        '-i', str(video_path),
        '-filter:v', f'setpts={1/speed_factor}*PTS',
        '-r', '60'
    ] + encoder_params + [
        '-c:a', 'copy',
        str(fixed_video)
    ]

    logger.debug(f"FFmpeg команда: {' '.join(cmd)}")
    print(f"   Обработка (это займёт время)...")

    try:
        subprocess.run(cmd, check=True, capture_output=True, **SUBPROCESS_FLAGS)
        logger.info("Ускорение/замедление выполнено успешно")
    except subprocess.CalledProcessError as e:
        logger.error(f"Ошибка ускорения/замедления: {e}")
        logger.error(traceback.format_exc())
        raise

    fixed_duration = get_video_duration(fixed_video)
    final_diff = abs(fixed_duration - audio_duration)
    logger.info(f"Новая длительность видео: {fixed_duration:.2f} сек, разница: {final_diff:.2f} сек")

    print(f"\n✅ Исправление завершено!")
    print(f"   Новая длительность видео: {fixed_duration:.2f} сек")
    print(f"   Разница с аудио: {final_diff:.2f} сек")
    print("="*80)

    return str(fixed_video)


def detect_gpu_encoder(force_amd=False):
    """Определяет доступный GPU энкодер"""
    logger.debug("Определение доступного GPU энкодера")
    try:
        result = subprocess.run(['ffmpeg', '-hide_banner', '-encoders'],
                              capture_output=True, text=True, **SUBPROCESS_FLAGS)
        if 'h264_amf' in result.stdout:
            logger.info("Обнаружен AMD GPU (h264_amf)")
            return 'amd', 'h264_amf'
        if 'h264_nvenc' in result.stdout and not force_amd:
            logger.info("Обнаружен NVIDIA GPU (h264_nvenc)")
            return 'nvidia', 'h264_nvenc'
        logger.info("GPU не обнаружен, используется CPU (libx264)")
        return 'cpu', 'libx264'
    except Exception as e:
        logger.warning(f"Ошибка определения GPU: {e}")
        return 'cpu', 'libx264'

def get_encoder_params(encoder_type, codec, bitrate='10M'):
    """Возвращает параметры для выбранного энкодера"""
    if encoder_type == 'nvidia':
        return ['-c:v', codec, '-preset', 'p4', '-tune', 'hq', '-b:v', bitrate,
                '-maxrate', bitrate, '-bufsize', f'{int(bitrate[:-1])*2}M',
                '-profile:v', 'high', '-pix_fmt', 'yuv420p']
    elif encoder_type == 'amd':
        return ['-c:v', codec, '-quality', 'speed', '-b:v', bitrate,
                '-maxrate', bitrate, '-bufsize', f'{int(bitrate[:-1])*2}M',
                '-profile:v', 'high', '-pix_fmt', 'yuv420p']
    else:
        return ['-c:v', codec, '-preset', 'medium', '-b:v', bitrate,
                '-maxrate', bitrate, '-bufsize', f'{int(bitrate[:-1])*2}M',
                '-profile:v', 'high', '-pix_fmt', 'yuv420p']

def create_freeze_frame(source_video, output_video, duration, encoder_type, codec, bitrate):
    """Создаёт freeze frame из последнего кадра источника"""
    logger.debug(f"Создание freeze frame из {source_video} длительностью {duration:.2f} сек")

    encoder_params = get_encoder_params(encoder_type, codec, bitrate)
    temp_frame = output_video.parent / f'temp_frame_{output_video.stem}.png'

    try:
        cmd_extract = [
            'ffmpeg', '-y',
            '-sseof', '-1',
            '-i', str(source_video),
            '-update', '1',
            '-q:v', '1',
            str(temp_frame)
        ]
        logger.debug(f"Извлечение последнего кадра: {' '.join(cmd_extract)}")
        subprocess.run(cmd_extract, check=True, capture_output=True, **SUBPROCESS_FLAGS)

        cmd_create = [
            'ffmpeg', '-y',
            '-loop', '1',
            '-i', str(temp_frame),
            '-t', str(duration),
            '-r', '60'
        ] + encoder_params + [
            '-an',
            str(output_video)
        ]
        logger.debug(f"Создание видео из кадра: {' '.join(cmd_create)}")
        subprocess.run(cmd_create, check=True, capture_output=True, **SUBPROCESS_FLAGS)

        temp_frame.unlink()
        logger.info(f"Freeze frame создан: {output_video}")
    except Exception as e:
        logger.error(f"Ошибка создания freeze frame: {e}")
        logger.error(traceback.format_exc())
        raise

def build_atempo_chain(speed_factor):
    """
    Создаёт цепочку atempo фильтров для ускорения/замедления аудио.
    FFmpeg atempo поддерживает только 0.5-2.0, для больших значений нужна цепочка.
    
    atempo=2.0 → аудио в 2 раза быстрее (длительность /2)
    atempo=0.5 → аудио в 2 раза медленнее (длительность *2)
    
    speed_factor — во сколько раз нужно ускорить (>1 = быстрее, <1 = медленнее).
    atempo = speed_factor напрямую (НЕ 1/speed_factor!)
    """
    target_atempo = speed_factor  # БЕЗ инверсии!

    if 0.5 <= target_atempo <= 2.0:
        return f'atempo={target_atempo:.5f}'

    chain = []
    current = target_atempo

    if current > 2.0:
        # Ускорение больше 2x: цепочка atempo=2.0
        while current > 2.0:
            chain.append('atempo=2.0')
            current /= 2.0
        chain.append(f'atempo={current:.5f}')
    elif current < 0.5:
        # Замедление больше 2x: цепочка atempo=0.5
        while current < 0.5:
            chain.append('atempo=0.5')
            current *= 2.0
        chain.append(f'atempo={current:.5f}')

    return ','.join(chain)

def process_video(input_file, output_file, target_duration, encoder_type, codec, bitrate):
    """Обрабатывает видео с ретаймингом до нужной длительности"""
    logger.debug(f"Ретайминг {input_file} → {output_file} (целевая длительность: {target_duration:.2f} сек)")

    try:
        result = subprocess.run(
            ['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
             '-of', 'default=noprint_wrappers=1:nokey=1', input_file],
            capture_output=True, text=True, **SUBPROCESS_FLAGS
        )
        current_duration = float(result.stdout.strip())
        speed_factor = current_duration / target_duration

        logger.debug(f"Текущая длительность: {current_duration:.2f} сек, speed_factor: {speed_factor:.4f}")

        encoder_params = get_encoder_params(encoder_type, codec, bitrate)
        cmd = ['ffmpeg', '-y', '-nostdin', '-i', input_file,
               '-filter:v', f'setpts=PTS/{speed_factor}',
               '-filter:a', build_atempo_chain(speed_factor),
               '-r', '60'] + encoder_params + ['-c:a', 'aac', '-b:a', '192k',
               '-t', str(target_duration), output_file]

        subprocess.run(cmd, check=True, capture_output=True, **SUBPROCESS_FLAGS)

        # Проверка результата
        result_duration = get_video_duration(output_file)
        diff = abs(result_duration - target_duration)
        logger.info(f"Clip {os.path.basename(input_file)}: {current_duration:.2f}с → {result_duration:.2f}с (цель {target_duration:.2f}с, разница {diff:.3f}с)")

        if diff > 0.1:
            logger.warning(f"⚠️  Разница {diff:.2f}с превышает 0.1с!")

        logger.debug(f"Ретайминг завершен: {output_file}")
    except Exception as e:
        logger.error(f"Ошибка ретайминга {input_file}: {e}")
        logger.error(traceback.format_exc())
        raise

def group_concat(file_list, output_file, temp_dir, group_size=50):
    """ГРУППОВАЯ СКЛЕЙКА"""
    logger.info("ЭТАП 5: ГРУППОВАЯ СКЛЕЙКА")
    logger.info(f"Всего файлов: {len(file_list)}, размер группы: {group_size}")

    print(f"\n🔗 ГРУППОВАЯ СКЛЕЙКА {len(file_list)} файлов...")
    print(f"   💡 Размер группы: {group_size} файлов")

    num_groups = (len(file_list) + group_size - 1) // group_size
    print(f"   📊 Групп: {num_groups}")
    print()

    chunk_files = []
    start_time = time.time()

    print(f"📦 Этап 1: Склейка групп")
    for group_idx in range(num_groups):
        start_idx = group_idx * group_size
        end_idx = min(start_idx + group_size, len(file_list))
        group_files = file_list[start_idx:end_idx]

        chunk_file = temp_dir / f'chunk_{group_idx+1:02d}.mp4'

        logger.info(f"Склейка группы {group_idx+1}/{num_groups}: файлы {start_idx+1}-{end_idx}")

        concat_list = temp_dir / f'group_{group_idx+1}.txt'
        with open(concat_list, 'w', encoding='utf-8') as f:
            for fpath in group_files:
                f.write(f"file '{Path(fpath).absolute()}'\n")

        print(f"   Группа {group_idx+1}/{num_groups}: файлы {start_idx+1}-{end_idx} → chunk_{group_idx+1:02d}.mp4", end=" ")

        cmd = ['ffmpeg', '-y', '-f', 'concat', '-safe', '0',
               '-i', str(concat_list), '-c', 'copy', '-reset_timestamps', '1', str(chunk_file)]

        group_start = time.time()
        try:
            subprocess.run(cmd, check=True, capture_output=True, **SUBPROCESS_FLAGS)
            elapsed = time.time() - group_start
            print(f"✅ ({elapsed:.1f}с)")
            chunk_files.append(str(chunk_file))
            concat_list.unlink()
            logger.info(f"Группа {group_idx+1} склеена за {elapsed:.1f}с")
        except subprocess.CalledProcessError as e:
            print(f"❌")
            logger.error(f"Ошибка склейки группы {group_idx+1}: {e}")
            logger.error(traceback.format_exc())
            raise

    print()
    print(f"🔗 Этап 2: Склейка {len(chunk_files)} чанков...")
    logger.info(f"Склейка {len(chunk_files)} чанков в финальный файл")

    final_concat_list = temp_dir / 'final_chunks.txt'
    with open(final_concat_list, 'w', encoding='utf-8') as f:
        for chunk in chunk_files:
            f.write(f"file '{Path(chunk).absolute()}'\n")

    cmd = ['ffmpeg', '-y', '-f', 'concat', '-safe', '0',
           '-i', str(final_concat_list), '-c', 'copy', '-reset_timestamps', '1', str(output_file)]

    try:
        subprocess.run(cmd, check=True, capture_output=True, **SUBPROCESS_FLAGS)
        final_concat_list.unlink()
        print(f"   ✅ Готово!")
        logger.info("Финальная склейка чанков завершена")
    except subprocess.CalledProcessError as e:
        logger.error(f"Ошибка финальной склейки: {e}")
        logger.error(traceback.format_exc())
        raise

    for chunk in chunk_files:
        Path(chunk).unlink()

    elapsed = time.time() - start_time
    final_size = get_file_size_mb(output_file)

    logger.info(f"Групповая склейка завершена: размер {final_size:.0f} MB, время {elapsed/60:.1f} мин")

    print(f"\n   ✅ Склейка завершена!")
    print(f"      💾 Размер: {final_size:.0f} MB")
    print(f"      ⏱️  Время: {elapsed/60:.1f} мин")
    print()

def run_ffmpeg_with_progress(cmd, total_duration, description="Processing"):
    """Запускает FFmpeg с прогресс-баром"""
    logger.debug(f"Запуск FFmpeg с прогресс-баром: {description}")

    cmd_with_progress = cmd + ['-progress', 'pipe:1']
    # stderr=DEVNULL — иначе deadlock при переполнении буфера
    process = subprocess.Popen(cmd_with_progress, stdout=subprocess.PIPE,
                              stderr=subprocess.DEVNULL, universal_newlines=True,
                              **SUBPROCESS_FLAGS)

    start_time = time.time()
    got_any_progress = False
    last_refresh = start_time

    with tqdm(total=total_duration, desc=description, unit="s",
              bar_format='{l_bar}{bar}| {n:.1f}/{total:.1f}s [{elapsed}]') as pbar:
        last_time = 0
        for line in process.stdout:
            line = line.strip()

            # FFmpeg 7.x: out_time_us (микросекунды)
            # FFmpeg 6.x: out_time_ms (тоже микросекунды, несмотря на имя)
            if line.startswith('out_time_us=') or line.startswith('out_time_ms='):
                try:
                    val = line.split('=')[1]
                    if val and val != 'N/A':
                        time_s = int(val) / 1000000.0
                        delta = time_s - last_time
                        if delta > 0:
                            pbar.update(delta)
                            last_time = time_s
                            got_any_progress = True
                except (ValueError, IndexError):
                    pass

            # Fallback: парсим out_time=HH:MM:SS.ffffff
            elif line.startswith('out_time=') and not got_any_progress:
                try:
                    val = line.split('=')[1]
                    if val and val != 'N/A':
                        parts = val.split(':')
                        time_s = float(parts[0]) * 3600 + float(parts[1]) * 60 + float(parts[2])
                        delta = time_s - last_time
                        if delta > 0:
                            pbar.update(delta)
                            last_time = time_s
                except (ValueError, IndexError):
                    pass

            # Обновляем отображение каждую секунду чтобы elapsed-таймер тикал
            now = time.time()
            if now - last_refresh >= 1.0:
                pbar.refresh()
                last_refresh = now

    process.wait()

    elapsed = time.time() - start_time
    logger.info(f"{description} завершено за {elapsed:.1f}с (прогресс отслеживался: {got_any_progress})")

    if process.returncode != 0:
        logger.error(f"FFmpeg завершился с ошибкой: returncode={process.returncode}")
        raise subprocess.CalledProcessError(process.returncode, cmd)

def ask_delete_temp_folder(temp_dir):
    """Спрашивает пользователя об удалении временной папки"""
    print(f"\n🧹 Временная папка: {temp_dir}")
    print(f"   💾 Размер: {sum(f.stat().st_size for f in temp_dir.rglob('*') if f.is_file()) / (1024*1024):.0f} MB")
    print()

    while True:
        response = input("Удалить временную папку? (y/n): ").strip().lower()
        if response in ['y', 'yes', 'д', 'да']:
            logger.info("Пользователь выбрал удалить temp папку")
            try:
                shutil.rmtree(temp_dir)
                print("   ✅ Папка удалена")
                logger.info("Временная папка удалена")
            except Exception as e:
                print(f"   ⚠️  Ошибка удаления: {e}")
                logger.error(f"Ошибка удаления temp папки: {e}")
            break
        elif response in ['n', 'no', 'н', 'нет']:
            logger.info("Пользователь выбрал оставить temp папку")
            print(f"   ✅ Папка сохранена: {temp_dir.absolute()}")
            break
        else:
            print("   ⚠️  Введите 'y' (да) или 'n' (нет)")

# ============================================================================
# MAIN
# ============================================================================

def main():
    global logger

    parser = argparse.ArgumentParser(description='Групповая склейка - ФИНАЛЬНАЯ ВЕРСИЯ')
    parser.add_argument('plan', help='Путь к montage_plan.json')
    parser.add_argument('-o', '--output', default='result.mp4', help='Выходной файл')
    parser.add_argument('-a', '--audio', default=None, help='Аудио озвучка (по умолчанию ищется любой .wav/.mp3 файл)')
    parser.add_argument('-b', '--bitrate', default='10M', help='Битрейт видео')
    parser.add_argument('-g', '--group-size', type=int, default=50, help='Размер группы для склейки')
    parser.add_argument('--no-gpu', action='store_true', help='Использовать CPU вместо GPU')
    parser.add_argument('--force-amd', action='store_true', help='Принудительно использовать AMD GPU')
    parser.add_argument('--force-reprocess', action='store_true', help='Переобработать все файлы')
    args = parser.parse_args()

    # НАСТРОЙКА ЛОГГИРОВАНИЯ
    logger, log_file = setup_logging()

    logger.info(f"Параметры запуска:")
    logger.info(f"  plan: {args.plan}")
    logger.info(f"  output: {args.output}")
    logger.info(f"  audio: {args.audio}")
    logger.info(f"  bitrate: {args.bitrate}")
    logger.info(f"  group_size: {args.group_size}")
    logger.info(f"  no_gpu: {args.no_gpu}")
    logger.info(f"  force_amd: {args.force_amd}")
    logger.info(f"  force_reprocess: {args.force_reprocess}")

    print("="*80)
    print("🎬 ГРУППОВАЯ СКЛЕЙКА - v5 FAST TRIM")
    print("="*80)
    print(f"\n📝 Лог-файл: {log_file}")

    # Определение энкодера
    encoder_type, codec = ('cpu', 'libx264') if args.no_gpu else detect_gpu_encoder(args.force_amd)

    if encoder_type == 'nvidia':
        print("\n✅ NVIDIA GPU - h264_nvenc")
    elif encoder_type == 'amd':
        print("\n✅ AMD GPU - h264_amf")
    else:
        print("\nℹ️  CPU - libx264")

    print(f"📊 Битрейт: {args.bitrate}")
    print(f"📋 План: {args.plan}")

    # Загрузка плана
    try:
        logger.info(f"Загрузка плана: {args.plan}")
        with open(args.plan, 'r', encoding='utf-8') as f:
            plan = json.load(f)
        logger.info("План загружен успешно")
    except (FileNotFoundError, json.JSONDecodeError) as e:
        logger.error(f"Ошибка загрузки плана: {e}")
        logger.error(traceback.format_exc())
        print(f"❌ Ошибка загрузки плана: {e}")
        sys.exit(1)

    clips = plan.get('clips', [])
    if not clips:
        logger.error("Нет clips в плане")
        print("❌ Нет clips в плане!")
        sys.exit(1)

    # Поиск аудиофайла если не указан
    audio_file = args.audio
    if audio_file is None:
        # Ищем любой аудиофайл в текущей директории
        for ext in ['*.wav', '*.mp3', '*.flac', '*.m4a', '*.aac']:
            found = list(Path('.').glob(ext))
            if found:
                audio_file = str(found[0])
                break
    
    if audio_file is None or not os.path.exists(audio_file):
        logger.error(f"Аудио файл не найден")
        print(f"❌ Аудио файл не найден!")
        print(f"   Положите .wav, .mp3, .flac, .m4a или .aac в папку проекта")
        print(f"   Или укажите явно: -a имя_файла.wav")
        sys.exit(1)
    
    logger.info(f"Используемый аудиофайл: {audio_file}")

    try:
        # ЭТАП 1: ВАЛИДАЦИЯ ПЛАНА
        audio_duration = validate_montage_plan(clips, audio_file)

        # ЭТАП 2: АНАЛИЗ ГЭПОВ
        corrections = analyze_gaps(clips, audio_duration)

        temp_dir = Path('temp_processed')
        temp_dir.mkdir(exist_ok=True)
        logger.info(f"Создана временная папка: {temp_dir.absolute()}")

        # Применяем корректировки к clips
        corrected_clips = clips.copy()
        for corr in corrections:
            idx = corr['clip_index']
            if corr['type'] == 'start_gap':
                corrected_clips[idx] = {
                    **corrected_clips[idx],
                    'startTime': 0.0,
                    'original_startTime': corrected_clips[idx]['startTime']
                }
            elif corr['type'] == 'end_gap':
                corrected_clips[idx] = {
                    **corrected_clips[idx],
                    'endTime': audio_duration,
                    'original_endTime': corrected_clips[idx]['endTime']
                }
            elif corr['type'] == 'retime_extend':
                corrected_clips[idx] = {
                    **corrected_clips[idx],
                    'endTime': corrected_clips[idx]['endTime'] + corr['gap_size'],
                    'original_endTime': corrected_clips[idx]['endTime']
                }

        # ЭТАП 3: ПРОВЕРКА СУЩЕСТВУЮЩИХ ФАЙЛОВ
        logger.info("ЭТАП 3: ПРОВЕРКА СУЩЕСТВУЮЩИХ ФАЙЛОВ")
        existing_files = {}
        if not args.force_reprocess:
            print(f"\n🔍 Проверка существующих файлов...")
            with tqdm(total=len(corrected_clips), desc="Проверка", unit="файл") as pbar:
                for clip in corrected_clips:
                    clip_id = clip['id']
                    target_duration = clip['endTime'] - clip['startTime']
                    output_file = temp_dir / f"processed_{clip_id}.mp4"

                    if check_processed_file(output_file):
                        actual_dur = get_video_duration(output_file)
                        if abs(actual_dur - target_duration) < 0.1:
                            existing_files[clip_id] = str(output_file)
                            logger.debug(f"Файл {clip_id} уже готов")

                    pbar.update(1)

            logger.info(f"Найдено готовых файлов: {len(existing_files)}")
            logger.info(f"Требуют обработки: {len(corrected_clips) - len(existing_files)}")

            print(f"   ✅ Найдено готовых: {len(existing_files)}")
            print(f"   🔄 Требуют обработки: {len(corrected_clips) - len(existing_files)}")
        else:
            logger.info("Режим force_reprocess - все файлы будут переобработаны")
            print(f"\n⚠️  Режим --force-reprocess: переобработка всех файлов")

        # ЭТАП 4: ОБРАБОТКА КЛИПОВ
        logger.info("ЭТАП 4: РЕТАЙМИНГ ФРАГМЕНТОВ")
        files_to_process = []
        for clip in corrected_clips:
            if clip['id'] not in existing_files:
                files_to_process.append(clip)

        if files_to_process:
            logger.info(f"Требуют ретайминга: {len(files_to_process)} файлов")
            print(f"\n🔄 Ретайминг {len(files_to_process)} фрагментов...")
            with tqdm(total=len(files_to_process), desc="Ретайминг", unit="файл") as pbar:
                for clip in files_to_process:
                    clip_id = clip['id']
                    target_duration = clip['endTime'] - clip['startTime']
                    output_file = temp_dir / f"processed_{clip_id}.mp4"

                    try:
                        process_video(clip['file'], str(output_file), target_duration,
                                    encoder_type, codec, args.bitrate)
                        existing_files[clip_id] = str(output_file)
                        pbar.update(1)
                    except Exception as e:
                        logger.error(f"Критическая ошибка обработки clip {clip_id}: {e}")
                        print(f"\n❌ Ошибка обработки: {e}")
                        sys.exit(1)
        else:
            logger.info("Все файлы уже обработаны")
            print(f"\n✅ Все файлы уже обработаны")

        # Формируем упорядоченный список обработанных файлов
        print(f"\n📦 Формирование финального списка файлов...")
        logger.info("Формирование финального списка файлов")
        processed_files_ordered = []

        for i, clip in enumerate(corrected_clips):
            clip_id = clip['id']
            processed_files_ordered.append(existing_files[clip_id])

        logger.info(f"Всего файлов для склейки: {len(processed_files_ordered)}")
        print(f"   ✅ Всего файлов для склейки: {len(processed_files_ordered)}")

        # ЭТАП 5: ГРУППОВАЯ СКЛЕЙКА
        temp_video = temp_dir / 'concat_video.mp4'
        group_concat(processed_files_ordered, temp_video, temp_dir, args.group_size)

        # ЭТАП 6: АВТОИСПРАВЛЕНИЕ ФИНАЛЬНОЙ СИНХРОНИЗАЦИИ
        temp_video = fix_video_audio_sync(temp_video, audio_file, temp_dir,
                                          encoder_type, codec, args.bitrate)

        # ЭТАП 7: ИЗВЛЕЧЕНИЕ ОРИГИНАЛЬНОГО АУДИО
        logger.info("ЭТАП 7: ИЗВЛЕЧЕНИЕ ОРИГИНАЛЬНОГО АУДИО")
        print(f"\n🔊 Извлечение оригинального аудио...")
        original_audio = args.output.replace('.mp4', '_original_audio.wav')
        try:
            subprocess.run(['ffmpeg', '-y', '-i', str(temp_video),
                           '-vn', '-acodec', 'pcm_s16le', original_audio],
                          check=True, capture_output=True, **SUBPROCESS_FLAGS)
            logger.info(f"Оригинальное аудио извлечено: {original_audio}")
            print(f"   ✅ {original_audio}")
        except Exception as e:
            logger.warning(f"Не удалось извлечь оригинальное аудио: {e}")
            print(f"   ⚠️  Не удалось")

        # ЭТАП 8: ЗАМЕНА АУДИО (оптимизированный — 2 шага)
        logger.info("ЭТАП 8: ЗАМЕНА АУДИО НА ОЗВУЧКУ")

        # Шаг 8a: Предварительное кодирование аудио WAV → AAC (быстро, маленький файл)
        print(f"\n🎵 Замена аудио на озвучку...")
        pre_encoded_audio = temp_dir / 'narration_aac.m4a'
        print(f"   Шаг 1/2: Кодирование аудио WAV → AAC...")
        cmd_aac = ['ffmpeg', '-y', '-i', audio_file,
                   '-c:a', 'aac', '-b:a', '192k', str(pre_encoded_audio)]
        try:
            run_ffmpeg_with_progress(cmd_aac, audio_duration, "AAC кодирование")
            logger.info(f"Аудио предварительно закодировано")
        except subprocess.CalledProcessError as e:
            logger.error(f"Ошибка кодирования аудио: {e}")
            raise

        # Шаг 8b: Мультиплексирование видео + аудио (оба -c copy, чистый I/O)
        # Без кодирования — только чтение/запись, максимальная скорость диска
        print(f"   Шаг 2/2: Сборка видео + аудио (без перекодирования)...")
        cmd_mux = ['ffmpeg', '-y', '-i', str(temp_video), '-i', str(pre_encoded_audio),
                   '-map', '0:v', '-map', '1:a', '-c:v', 'copy',
                   '-c:a', 'copy', '-shortest', args.output]

        run_ffmpeg_with_progress(cmd_mux, audio_duration, "Сборка")
        logger.info(f"Финальный файл создан: {args.output}")

        # Удаляем промежуточный аудиофайл
        try:
            pre_encoded_audio.unlink()
        except:
            pass

        # ЭТАП 9: ОЧИСТКА (С ВОПРОСОМ)
        logger.info("ЭТАП 9: ОЧИСТКА")
        ask_delete_temp_folder(temp_dir)

        # ФИНАЛ
        print("\n" + "="*80)
        print("✅ ГОТОВО!")
        print("="*80)
        print(f"\n📹 Видео: {args.output}")
        print(f"   • FPS: 60")
        print(f"   • Битрейт: {args.bitrate}")
        print(f"   • Кодек: {codec} ({encoder_type.upper()})")
        print(f"\n🔊 Оригинальное аудио: {original_audio}")
        print(f"🎵 Озвучка: {audio_file}")
        print(f"\n📝 Лог-файл: {log_file}")
        print("="*80)

        logger.info("="*80)
        logger.info("СКРИПТ ЗАВЕРШЁН УСПЕШНО")
        logger.info("="*80)

    except Exception as e:
        logger.critical("КРИТИЧЕСКАЯ ОШИБКА!")
        logger.critical(f"Ошибка: {e}")
        logger.critical(traceback.format_exc())
        print(f"\n❌ КРИТИЧЕСКАЯ ОШИБКА: {e}")
        print(f"\n📝 Подробности в лог-файле: {log_file}")
        sys.exit(1)

if __name__ == '__main__':
    main()
