"""
Strict stock background-music provider for monetized YouTube workflows.

No local music is generated here. The provider only uses audio files that were
already downloaded and verified by evidence in the project. The final mixer
already loops short tracks and trims long tracks to the music_plan timeline.
"""
from __future__ import annotations

import json
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

import config
from modules.music_plan_utils import normalize_music_plan


STRICT_POLICY = (
    "content_id_blocked; only exact-track verified stock music is allowed; "
    "no local fallback generation"
)
AUDIO_EXTS = {".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg"}
SAFE_CONTENT_ID_VALUES = {
    "no_content_id",
    "verified_no_content_id",
    "none",
    "not_registered",
    "content_id_free",
}


def generate_safe_music_for_project(
    project_dir: str | Path,
    *,
    plan_path: str | Path | None = None,
    provider: str | None = None,
    force: bool = False,
) -> Dict[str, Any]:
    project_dir = Path(project_dir).resolve()
    plan_path = Path(plan_path) if plan_path else project_dir / "music_plan.json"
    provider = _normalize_provider(provider or getattr(config, "MUSIC_PROVIDER", "safe_stock"))

    plan = _load_plan(plan_path)
    plan = normalize_music_plan(
        plan,
        float(plan.get("audioDuration", 0) or 0),
        min_track_duration=getattr(config, "MUSIC_MIN_TRACK_DURATION", 120),
        max_track_duration=getattr(config, "MUSIC_MAX_TRACK_DURATION", 240),
        max_tracks=getattr(config, "MUSIC_MAX_TRACKS", 10),
    )

    manifest: Dict[str, Any] = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "policy": STRICT_POLICY,
        "provider_requested": provider,
        "provider_used": "safe_stock",
        "allow_content_id": bool(getattr(config, "MUSIC_ALLOW_CONTENT_ID", False)),
        "items": [],
        "rejections": [],
        "notes": [],
    }

    if provider in {"procedural", "local", "ffmpeg"}:
        manifest["provider_used"] = "none"
        manifest["rejections"].append({
            "provider": provider,
            "reason": "Local/procedural background music is disabled for this workflow.",
        })
        _mark_no_verified_music(plan)
        _save_plan(plan_path, plan)
        _write_evidence(project_dir, manifest)
        return _summary(0, 0, len(_active_tracks(plan)), "none")

    if provider == "pexels":
        manifest["rejections"].append({
            "provider": "pexels",
            "reason": "Pexels official API is photos/videos; no supported music library.",
        })

    candidates = _collect_verified_stock(project_dir, manifest)
    if not candidates:
        manifest["provider_used"] = "none"
        manifest["notes"].append(
            "No verified stock music found. Put checked tracks into project/music_stock/ "
            "with .json evidence containing content_id_status=verified_no_content_id."
        )
        _mark_no_verified_music(plan)
        _save_plan(plan_path, plan)
        _write_evidence(project_dir, manifest)
        print("   [safe_stock] No verified music found - continuing without background music")
        return _summary(0, 0, len(_active_tracks(plan)), "none")

    selected = _assign_stock_tracks(project_dir, plan, candidates, manifest, force=force)
    _save_plan(plan_path, plan)
    _write_evidence(project_dir, manifest)
    print(f"   [safe_stock] Selected {selected} verified stock track slot(s)")
    return _summary(selected, 0, len(_active_tracks(plan)), "safe_stock")


def _collect_verified_stock(project_dir: Path, manifest: Dict[str, Any]) -> List[Dict[str, Any]]:
    roots = [
        project_dir / "music_stock",
        project_dir / "stock_music",
    ]
    candidates: List[Dict[str, Any]] = []
    for root in roots:
        if not root.exists():
            continue
        shared_manifest = _load_shared_manifest(root)
        for audio_path in sorted(p for p in root.rglob("*") if p.suffix.lower() in AUDIO_EXTS):
            evidence = _load_track_evidence(audio_path, shared_manifest)
            if not evidence:
                manifest["rejections"].append({
                    "file": str(audio_path.relative_to(project_dir)),
                    "reason": "missing JSON evidence sidecar",
                })
                continue
            status = str(evidence.get("content_id_status") or evidence.get("content_id") or "").strip().lower()
            if status not in SAFE_CONTENT_ID_VALUES:
                manifest["rejections"].append({
                    "file": str(audio_path.relative_to(project_dir)),
                    "reason": f"content_id_status is not safe: {status or 'missing'}",
                })
                continue
            if not _has_license_evidence(evidence):
                manifest["rejections"].append({
                    "file": str(audio_path.relative_to(project_dir)),
                    "reason": "missing license/source/page evidence",
                })
                continue
            candidates.append({
                "path": audio_path,
                "evidence": evidence,
                "keywords": _candidate_keywords(audio_path, evidence),
            })
    return candidates


def _assign_stock_tracks(
    project_dir: Path,
    plan: Dict[str, Any],
    candidates: List[Dict[str, Any]],
    manifest: Dict[str, Any],
    *,
    force: bool,
) -> int:
    music_dir = project_dir / "music"
    music_dir.mkdir(parents=True, exist_ok=True)
    tracks = _active_tracks(plan)
    selected = 0
    for track in tracks:
        tid = int(track.get("id") or 0)
        if tid <= 0:
            continue
        best = _best_candidate_for_track(track, candidates)
        src = best["path"]
        suffix = src.suffix.lower()
        target = music_dir / f"{tid}{suffix}"
        if force or not target.exists():
            shutil.copy2(src, target)
        track["file"] = target.name
        track["source"] = str((best["evidence"].get("source") or best["evidence"].get("provider") or "stock")).lower()
        track["license"] = best["evidence"].get("license") or best["evidence"].get("license_name") or "stock license"
        track["license_url"] = best["evidence"].get("license_url") or best["evidence"].get("page_url")
        track["page_url"] = best["evidence"].get("page_url") or best["evidence"].get("url")
        track["content_id_status"] = "verified_no_content_id"
        track["attribution_required"] = bool(best["evidence"].get("attribution_required", False))
        track["stock_music_file"] = str(src.relative_to(project_dir))
        track.pop("suno_clip_ids", None)
        track.pop("suno_durations", None)
        manifest["items"].append({
            "track_id": tid,
            "file": f"music/{target.name}",
            "source_file": str(src.relative_to(project_dir)),
            "source": track["source"],
            "license": track["license"],
            "license_url": track.get("license_url"),
            "page_url": track.get("page_url"),
            "content_id_status": "verified_no_content_id",
            "fit": "ffmpeg mixer loops short files and trims long files to the planned slot",
        })
        selected += 1
    return selected


def _mark_no_verified_music(plan: Dict[str, Any]) -> None:
    for track in _active_tracks(plan):
        track["file"] = "__no_verified_stock__.mp3"
        track["source"] = "none"
        track["content_id_status"] = "no_verified_stock_found"
        track["attribution_required"] = False
        track.pop("suno_clip_ids", None)
        track.pop("suno_durations", None)


def _best_candidate_for_track(track: Dict[str, Any], candidates: List[Dict[str, Any]]) -> Dict[str, Any]:
    track_words = _words(" ".join(
        str(track.get(k) or "") for k in ("title", "genre", "mood", "energy", "tags", "prompt")
    ))
    if not track_words:
        return candidates[0]
    scored = []
    for idx, cand in enumerate(candidates):
        score = len(track_words & cand["keywords"])
        scored.append((score, -idx, cand))
    scored.sort(reverse=True, key=lambda item: (item[0], item[1]))
    return scored[0][2]


def _candidate_keywords(audio_path: Path, evidence: Dict[str, Any]) -> set[str]:
    fields = [
        audio_path.stem,
        evidence.get("title", ""),
        evidence.get("mood", ""),
        evidence.get("genre", ""),
        evidence.get("tags", ""),
        evidence.get("description", ""),
    ]
    return _words(" ".join(str(x) for x in fields))


def _words(text: str) -> set[str]:
    return {w for w in re.findall(r"[a-zа-я0-9]{3,}", text.lower())}


def _load_shared_manifest(root: Path) -> Dict[str, Any]:
    for name in ("music_stock_manifest.json", "manifest.json"):
        path = root / name
        if path.exists():
            try:
                raw = json.loads(path.read_text(encoding="utf-8-sig"))
                return raw if isinstance(raw, dict) else {}
            except Exception:
                return {}
    return {}


def _load_track_evidence(audio_path: Path, shared_manifest: Dict[str, Any]) -> Dict[str, Any] | None:
    for sidecar in (audio_path.with_suffix(audio_path.suffix + ".json"), audio_path.with_suffix(".json")):
        if sidecar.exists():
            try:
                raw = json.loads(sidecar.read_text(encoding="utf-8-sig"))
                return raw if isinstance(raw, dict) else None
            except Exception:
                return None
    entries = shared_manifest.get("tracks") or shared_manifest.get("items") or []
    for entry in entries if isinstance(entries, list) else []:
        if not isinstance(entry, dict):
            continue
        names = {
            str(entry.get("file") or ""),
            str(entry.get("filename") or ""),
            str(entry.get("path") or ""),
        }
        if audio_path.name in names or str(audio_path.relative_to(audio_path.parents[1])) in names:
            return entry
    return None


def _has_license_evidence(evidence: Dict[str, Any]) -> bool:
    if evidence.get("license") or evidence.get("license_name"):
        return bool(evidence.get("page_url") or evidence.get("url") or evidence.get("license_url"))
    return False


def _write_evidence(project_dir: Path, manifest: Dict[str, Any]) -> None:
    music_dir = project_dir / "music"
    music_dir.mkdir(parents=True, exist_ok=True)
    (music_dir / "music_safe_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    lines: List[str] = [
        "Background music rights evidence",
        f"Policy: {manifest['policy']}",
        f"Provider used: {manifest.get('provider_used') or 'none'}",
        "",
    ]
    if manifest.get("items"):
        lines.append("Tracks:")
        for item in manifest["items"]:
            lines.append(
                f"- {item['file']}: {item['source']}; {item['license']}; "
                f"Content ID: {item['content_id_status']}; {item.get('page_url') or ''}"
            )
    if manifest.get("rejections"):
        lines.extend(["", "Rejected stock sources:"])
        for rej in manifest["rejections"]:
            src = rej.get("file") or rej.get("provider") or "stock"
            lines.append(f"- {src}: {rej['reason']}")
    lines.extend([
        "",
        "If no tracks are listed above, the final render should continue without background music.",
        "Short accepted tracks are looped; long accepted tracks are trimmed by the final ffmpeg mixer.",
    ])
    (music_dir / "music_attribution.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def _load_plan(plan_path: Path) -> Dict[str, Any]:
    if not plan_path.exists():
        raise FileNotFoundError(f"music_plan.json not found: {plan_path}")
    raw = json.loads(plan_path.read_text(encoding="utf-8-sig"))
    if isinstance(raw, dict) and isinstance(raw.get("music_plan"), dict):
        return raw["music_plan"]
    if isinstance(raw, dict):
        return raw
    raise ValueError(f"Invalid music_plan.json: {plan_path}")


def _save_plan(plan_path: Path, plan: Dict[str, Any]) -> None:
    plan_path.write_text(
        json.dumps({"music_plan": plan}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def _active_tracks(plan: Dict[str, Any]) -> List[Dict[str, Any]]:
    return [
        t for t in plan.get("tracks", []) or []
        if isinstance(t, dict) and (t.get("genre") or "").lower() != "silence"
    ]


def _summary(ok: int, skipped: int, total: int, provider: str) -> Dict[str, Any]:
    return {
        "ok": ok,
        "skipped": skipped,
        "failed": 0,
        "fallback": 0,
        "total": total,
        "provider": provider,
    }


def _normalize_provider(provider: str) -> str:
    provider = (provider or "safe_stock").strip().lower().replace("-", "_")
    aliases = {
        "safe": "safe_stock",
        "stock_safe": "safe_stock",
        "pixabay": "safe_stock",
        "stock": "safe_stock",
    }
    return aliases.get(provider, provider)
