@echo off
setlocal
title Audio Inserter
cd /d "%~dp0"

call :find_python
if not defined PYTHON_CMD (
    echo Python 3.10+ was not found.
    echo.
    echo Run install_win.bat first, or install Python from:
    echo   https://www.python.org/downloads/
    echo.
    echo During setup enable:
    echo   Add Python to PATH
    echo   py launcher
    echo.
    pause
    exit /b 1
)

%PYTHON_CMD% -c "import PIL, ttkbootstrap" >nul 2>&1
if errorlevel 1 (
    echo Missing Python packages: Pillow / ttkbootstrap.
    echo.
    echo Run install_win.bat, then run AudioInserter.bat again.
    echo.
    echo Manual install:
    echo   %PYTHON_CMD% -m pip install --user Pillow ttkbootstrap
    echo.
    pause
    exit /b 1
)

where ffmpeg >nul 2>&1
if errorlevel 1 (
    echo Warning: ffmpeg was not found in PATH.
    echo The app can open, but video processing will not work until ffmpeg is installed.
    echo.
)

if "%AUDIO_INSERTER_SELF_TEST%"=="1" (
    echo AudioInserter.bat self-test OK.
    echo Python command: %PYTHON_CMD%
    exit /b 0
)

%PYTHON_CMD% "%~dp0audio_inserter.py"
if errorlevel 1 (
    echo.
    echo Audio Inserter exited with an error. See the error text above.
    echo.
    pause
    exit /b 1
)
exit /b 0

:find_python
for %%C in ("py -3.14" "py -3.13" "py -3.12" "py -3.11" "py -3.10" "py -3" "python" "python3") do (
    call :try_python %%~C
    if defined PYTHON_CMD exit /b 0
)
exit /b 1

:try_python
set "CANDIDATE=%*"
%CANDIDATE% -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>&1
if errorlevel 1 exit /b 1
set "PYTHON_CMD=%CANDIDATE%"
exit /b 0
