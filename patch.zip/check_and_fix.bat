@echo off
chcp 866 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo ================================================================================
echo  SCENAGENT RTG - CHECKER + AUTO-FIX
echo ================================================================================
echo.

set "ERRORS=0"
set "PYTHON_CMD=python"
set "FIX_PYTHON=0"
set "FIX_PIP=0"
set "FIX_PACKAGES=0"
set "FIX_FFMPEG=0"
set "FIX_ENV=0"

REM ============================================================================
REM 1. PYTHON
REM ============================================================================
echo [1/5] Python...

python --version >nul 2>&1
if not errorlevel 1 (
    for /f "tokens=2" %%v in ('python --version 2^>^&1') do set PYVER=%%v
    echo  [OK] Python !PYVER!
    goto :py_ok
)

py --version >nul 2>&1
if not errorlevel 1 (
    for /f "tokens=2" %%v in ('py --version 2^>^&1') do set PYVER=%%v
    echo  [OK] Python !PYVER! (py launcher)
    set "PYTHON_CMD=py"
    goto :py_ok
)

echo  [ERROR] Python not found!
set "FIX_PYTHON=1"
set /a ERRORS+=1

:py_ok

REM ============================================================================
REM 2. PIP
REM ============================================================================
echo.
echo [2/5] pip...

%PYTHON_CMD% -m pip --version >nul 2>&1
if not errorlevel 1 (
    echo  [OK] pip available
    goto :packages
)

echo  [ERROR] pip not found!
set "FIX_PIP=1"
set /a ERRORS+=1

:packages
REM ============================================================================
REM 3. PACKAGES
REM ============================================================================
echo.
echo [3/5] Python packages...

set "PKG_LIST="
set "PKG_ERRORS=0"

%PYTHON_CMD% -c "import assemblyai" 2>nul || (echo   [MISS] assemblyai & set "PKG_LIST=!PKG_LIST! assemblyai" & set /a PKG_ERRORS+=1)
%PYTHON_CMD% -c "import google.genai" 2>nul || (echo   [MISS] google.genai & set "PKG_LIST=!PKG_LIST! google-genai" & set /a PKG_ERRORS+=1)
%PYTHON_CMD% -c "import dotenv" 2>nul || (echo   [MISS] python-dotenv & set "PKG_LIST=!PKG_LIST! python-dotenv" & set /a PKG_ERRORS+=1)
%PYTHON_CMD% -c "import tqdm" 2>nul || (echo   [MISS] tqdm & set "PKG_LIST=!PKG_LIST! tqdm" & set /a PKG_ERRORS+=1)
%PYTHON_CMD% -c "import httpx" 2>nul || (echo   [MISS] httpx & set "PKG_LIST=!PKG_LIST! httpx" & set /a PKG_ERRORS+=1)
%PYTHON_CMD% -c "import pydantic" 2>nul || (echo   [MISS] pydantic & set "PKG_LIST=!PKG_LIST! pydantic" & set /a PKG_ERRORS+=1)

if !PKG_ERRORS! gtr 0 (
    echo  [WARN] Missing:!PKG_LIST!
    set "FIX_PACKAGES=1"
) else (
    echo  [OK] All packages installed
)
set /a ERRORS+=!PKG_ERRORS!

REM ============================================================================
REM 4. FFMPEG
REM ============================================================================
echo.
echo [4/5] FFmpeg...

ffmpeg -version >nul 2>&1
if not errorlevel 1 (
    echo  [OK] FFmpeg installed
    goto :env_check
)

echo  [ERROR] FFmpeg not found!
set "FIX_FFMPEG=1"
set /a ERRORS+=1

:env_check
REM ============================================================================
REM 5. .ENV
REM ============================================================================
echo.
echo [5/5] .env file...

if exist "agent\.env" (
    echo  [OK] agent\.env exists
    goto :summary
)

echo  [ERROR] agent\.env not found!
set "FIX_ENV=1"
set /a ERRORS+=1

:summary
REM ============================================================================
REM ASK TO FIX
REM ============================================================================
echo.
echo ================================================================================
echo  RESULT: %ERRORS% error(s) found
echo ================================================================================
echo.

if %ERRORS%==0 (
    echo  [OK] All components ready!
    echo.
    goto :end
)

echo  Problems found:
if %FIX_PYTHON%==1 echo    - Python not installed
if %FIX_PIP%==1 echo    - pip not available
if %FIX_PACKAGES%==1 echo    - Missing packages:!PKG_LIST!
if %FIX_FFMPEG%==1 echo    - FFmpeg not installed
if %FIX_ENV%==1 echo    - agent\.env not found
echo.

if %FIX_PYTHON%==1 (
    echo  [!] Python must be installed manually first!
    echo      https://www.python.org/downloads/
    echo      Check "Add Python to PATH" during installation!
    echo.
)

echo ================================================================================
echo  AUTO-FIX AVAILABLE
echo ================================================================================
echo.
echo  Do you want to install missing components automatically?
echo.
echo  Y - Yes, install everything missing
echo  N - No, exit
echo.
set /p "CHOICE=Your choice (Y/N): "

if /i "!CHOICE!"=="Y" goto :fix_all
if /i "!CHOICE!"=="YES" goto :fix_all
if /i "!CHOICE!"=="N" goto :exit
if /i "!CHOICE!"=="NO" goto :exit

echo  Invalid choice. Exiting.
goto :exit

:fix_all
echo.
echo ================================================================================
echo  STARTING AUTO-FIX...
echo ================================================================================
echo.

REM --- Fix PIP ---
if %FIX_PIP%==1 (
    echo [FIX] Installing pip via ensurepip...
    %PYTHON_CMD% -m ensurepip --upgrade
    if errorlevel 1 (
        echo  [ERROR] Failed to install pip!
    ) else (
        echo  [OK] pip installed
    )
    echo.
)

REM --- Fix PACKAGES ---
if %FIX_PACKAGES%==1 (
    echo [FIX] Installing missing packages...
    %PYTHON_CMD% -m pip install --upgrade pip --trusted-host pypi.org --trusted-host files.pythonhosted.org
    %PYTHON_CMD% -m pip install assemblyai google-genai python-dotenv tqdm httpx pydantic ^
        --trusted-host pypi.org ^
        --trusted-host files.pythonhosted.org
    if errorlevel 1 (
        echo  [WARN] Some packages may have failed to install
        echo  Try mirror: %PYTHON_CMD% -m pip install assemblyai google-genai python-dotenv tqdm httpx pydantic ^
        echo      --index-url https://pypi.tuna.tsinghua.edu.cn/simple ^
        echo      --trusted-host pypi.tuna.tsinghua.edu.cn
    ) else (
        echo  [OK] Packages installed
    )
    echo.
)

REM --- Fix FFMPEG ---
if %FIX_FFMPEG%==1 (
    echo [FIX] Installing FFmpeg...
    
    winget --version >nul 2>&1
    if not errorlevel 1 (
        echo  Using winget...
        winget install --id Gyan.FFmpeg --silent --accept-package-agreements --accept-source-agreements
        if not errorlevel 1 (
            echo  [OK] FFmpeg installed via winget
            echo  [!] May need terminal restart to work
            goto :ffmpeg_done
        )
    )
    
    choco --version >nul 2>&1
    if not errorlevel 1 (
        echo  Using chocolatey...
        choco install ffmpeg -y
        if not errorlevel 1 (
            echo  [OK] FFmpeg installed via chocolatey
            echo  [!] May need terminal restart to work
            goto :ffmpeg_done
        )
    )
    
    echo  [WARN] winget/choco not available. Install FFmpeg manually:
    echo    1. Download: https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip
    echo    2. Extract to C:\ffmpeg
    echo    3. Add C:\ffmpeg\bin to PATH
    
    :ffmpeg_done
    echo.
)

REM --- Fix .ENV ---
if %FIX_ENV%==1 (
    echo [FIX] Creating agent\.env...
    if exist "agent\.env.example" (
        copy "agent\.env.example" "agent\.env" >nul
        echo  [OK] Created from template
        echo  [!] Don't forget to fill in API keys in agent\.env!
    ) else (
        echo  [WARN] agent\.env.example not found. Creating empty agent\.env...
        (
            echo ASSEMBLYAI_API_KEY=
            echo GEMINI_API_KEY=
            echo FASTGEN_API_KEY=
        ) > "agent\.env"
        echo  [OK] Created empty agent\.env - fill in your API keys!
    )
    echo.
)

echo ================================================================================
echo  AUTO-FIX COMPLETED
echo ================================================================================
echo.
echo  Please restart terminal and run check_install.bat again to verify.
echo.

:end
echo ================================================================================
pause
exit /b 0

:exit
echo.
echo  Exiting without changes.
echo ================================================================================
pause
exit /b 1
