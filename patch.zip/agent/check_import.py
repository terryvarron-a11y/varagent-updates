from modules import veo_video as img2video
print("img2video file:", img2video.__file__)

# Check if _count_error exists
import inspect
source = inspect.getsource(img2video._run_phase)
if '_count_error' in source:
    print("OK: _count_error found in _run_phase")
else:
    print("ERROR: _count_error NOT found in _run_phase")

if 'worker_id' in source:
    print("OK: worker_id found in _run_phase")
else:
    print("ERROR: worker_id NOT found in _run_phase")
