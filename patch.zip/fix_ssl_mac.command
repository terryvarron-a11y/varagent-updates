#!/bin/bash
# ============================================================================
# VARAGENT SSL Fix для Mac
# ============================================================================
# Устанавливает certifi и обновляет VARAGENT для исправления SSL ошибки
# ============================================================================

cd "$(dirname "$0")"

echo "=========================================="
echo " VARAGENT SSL Fix для Mac"
echo "=========================================="
echo ""

# Устанавливаем certifi
echo "[1/3] Установка certifi..."
python3 -m pip install --upgrade certifi
if [ $? -ne 0 ]; then
    echo "ОШИБКА: не удалось установить certifi"
    echo "Попробуйте вручную: python3 -m pip install certifi"
    read -p "Нажмите Enter для выхода..."
    exit 1
fi
echo "✓ certifi установлен"
echo ""

# Переустанавливаем зависимости
echo "[2/3] Обновление зависимостей..."
python3 -m pip install -r agent/requirements.txt --upgrade
if [ $? -ne 0 ]; then
    echo "ПРЕДУПРЕЖДЕНИЕ: не все зависимости обновлены"
fi
echo ""

# Запускаем обновление
echo "[3/3] Загрузка обновления VARAGENT..."
if [ -f "update.command" ]; then
    bash update.command
else
    python3 -c "
import sys
sys.path.insert(0, 'agent')
from modules import updater
from pathlib import Path

root = Path('.')
print('Проверка обновлений...')
info = updater.check_updates(root)
if info.get('error'):
    print(f'Ошибка: {info[\"error\"]}')
    sys.exit(1)

if info['available']:
    print(f'Доступна версия: {info[\"version\"]}')
    print('Установка...')
    result = updater.install_update(root)
    if result['ok']:
        print(f'✓ Обновление установлено ({len(result[\"installed\"])} файлов)')
        print('Перезапустите VARAGENT')
    else:
        print(f'Ошибка: {result[\"error\"]}')
        sys.exit(1)
else:
    print('Обновлений нет')
"
fi

echo ""
echo "=========================================="
echo "✓ Готово!"
echo "=========================================="
read -p "Нажмите Enter для выхода..."
