"""User-editable I2V parallax prompt templates and deterministic selection."""

from __future__ import annotations

import re
import zlib
from pathlib import Path

import config


def load_parallax_templates(path: Path | None = None) -> dict[int, str]:
    """Read numbered templates from the shared editable text file."""
    prompt_path = path or (Path(config.BASE_DIR).parent / "паралакс промпты.txt")
    text = prompt_path.read_text(encoding="utf-8-sig")
    parts = re.split(r"\n-{20,}\s*\n", text)
    templates: dict[int, str] = {}
    for index, part in enumerate(parts[:-1]):
        match = re.search(r"ПРОМПТ\s+([1-3])", part, flags=re.IGNORECASE)
        if not match:
            continue
        template = parts[index + 1].strip()
        if template:
            templates[int(match.group(1))] = template
    return templates


# «Случайно»: клипы получают разные шаблоны вперемешку, а не один на всех.
PARALLAX_RANDOM = 0

PARALLAX_NAMES = {
    PARALLAX_RANDOM: 'вперемешку',
    1: 'сбалансированный',
    2: 'строгий (двигается только камера)',
    3: 'механический',
}


def parallax_method_name(method: int) -> str:
    try:
        return PARALLAX_NAMES.get(int(method), '?')
    except (TypeError, ValueError):
        return '?'


def parallax_method_for_clip(clip_id: int, method: int) -> int:
    """Какой шаблон достаётся клипу.

    При обычном выборе — он же для всех. При «вперемешку» шаблон выводится из
    номера клипа: разные клипы получают разные, но КОНКРЕТНЫЙ клип всегда один
    и тот же. Настоящий `random` тут не годится — при повторе генерации того же
    клипа шаблон бы сменился, и результат перестал бы воспроизводиться.
    """
    try:
        method = int(method)
    except (TypeError, ValueError):
        return 1
    if method != PARALLAX_RANDOM:
        return method
    try:
        seed = int(clip_id)
    except (TypeError, ValueError):
        return 1
    # crc32 вместо остатка от деления: остаток дал бы ровную карусель
    # 1-2-3-1-2-3 по соседним клипам, а нужен именно разнобой.
    return zlib.crc32(str(seed).encode('utf-8')) % 3 + 1


def selected_parallax_prompt(method: int, path: Path | None = None) -> str:
    templates = load_parallax_templates(path)
    try:
        method = int(method)
    except (TypeError, ValueError):
        method = 1
    if method not in templates:
        method = 1
    if not templates.get(method):
        raise ValueError("No usable parallax prompt template was found")
    return templates[method]


def use_parallax_for_clip(
    clip_id: int,
    mix_with_perclip: bool,
    *,
    every_n: int = 2,
) -> bool:
    """Use every Nth clip in mixed mode; stable across retries."""
    if not mix_with_perclip:
        return True
    try:
        every_n = max(1, int(every_n))
    except (TypeError, ValueError):
        every_n = 2
    return int(clip_id) % every_n == 0


def select_every_n_clip_ids(clip_ids, every_n: int) -> list[int]:
    """Select every Nth clip from an already ordered eligible-image list."""
    try:
        every_n = max(1, int(every_n))
    except (TypeError, ValueError):
        every_n = 2
    ids = []
    for clip_id in clip_ids:
        try:
            ids.append(int(clip_id))
        except (TypeError, ValueError):
            continue
    return [
        clip_id
        for ordinal, clip_id in enumerate(ids, start=1)
        if ordinal % every_n == 0
    ]
