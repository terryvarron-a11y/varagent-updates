"""
Проверка ключа VeoNonStop API
"""
import urllib.request
import json

# Ключ для проверки
API_KEY = 'veo_a08c8b8bf0223e697ed26b58de212696848a593f8e6cbae8'

# VeoNonStop API endpoints
BASE_URL = 'https://veononstop.org/api/v1'

endpoints = [
    f'{BASE_URL}/account/info',
]

headers = {
    'X-API-Key': API_KEY,
    'User-Agent': 'varagent-api-check',
}

for url in endpoints:
    print(f'\n=== Проверка: {url} ===\n')
    try:
        req = urllib.request.Request(url, headers=headers)
        resp = urllib.request.urlopen(req, timeout=10)
        data = json.loads(resp.read())
        print(json.dumps(data, indent=2, ensure_ascii=False))
        break  # Успех
    except urllib.error.HTTPError as e:
        print(f'HTTP Error: {e.code}')
        try:
            print(f'Response: {e.read().decode()}')
        except:
            pass
    except Exception as e:
        print(f'Error: {e}')
