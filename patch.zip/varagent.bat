@echo off
chcp 65001 >nul
title VarAgent GUI
cd /d "%~dp0"
python varagent.py %*
if errorlevel 1 pause
