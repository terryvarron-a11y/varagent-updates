@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

REM ============================================================================
REM 1_INTERACTIVESTART.BAT - Start from transcription stage (Interactive Mode)
REM Stage 1: Transcription -> Direction  (audio already in ready_to_go\)
REM ============================================================================

echo.
echo ================================================================================
echo  1_INTERACTIVESTART  [Transcription + Direction]  INTERACTIVE MODE
echo ================================================================================
echo.

REM ============================================================================
REM  READ .ENV DEFAULTS
REM ============================================================================

set "ENV_FILE=%~dp0agent\.env"
set "DEF_VID_MIN=4"
set "DEF_VID_MAX=8"
set "DEF_SLD_MIN=2"
set "DEF_SLD_MAX=7"
set "INTRO_BLOCK=30"
set "INTRO_MIN=0"
set "INTRO_MAX=0"
set "DEF_TWO_PASS=true"
set "DEF_LANG=ru"
set "DEF_CLIP_MODE=video"

for /f "usebackq tokens=1,* delims==" %%A in ("%ENV_FILE%") do (
    set "KEY=%%A"
    set "VAL=%%B"
    set "KEY=!KEY: =!"
    if "!KEY!"=="VIDEO_CLIP_MIN_DURATION"     set "DEF_VID_MIN=!VAL!"
    if "!KEY!"=="VIDEO_CLIP_MAX_DURATION"     set "DEF_VID_MAX=!VAL!"
    if "!KEY!"=="SLIDESHOW_CLIP_MIN_DURATION" set "DEF_SLD_MIN=!VAL!"
    if "!KEY!"=="SLIDESHOW_CLIP_MAX_DURATION" set "DEF_SLD_MAX=!VAL!"
    if "!KEY!"=="INTRO_BLOCK_DURATION"        set "INTRO_BLOCK=!VAL!"
    if "!KEY!"=="INTRO_CLIP_MIN_DURATION"     set "INTRO_MIN=!VAL!"
    if "!KEY!"=="INTRO_CLIP_MAX_DURATION"     set "INTRO_MAX=!VAL!"
    if "!KEY!"=="GEMINI_TWO_PASS"             set "DEF_TWO_PASS=!VAL!"
    if "!KEY!"=="ASSEMBLYAI_LANGUAGE_CODE"    set "DEF_LANG=!VAL!"
    if "!KEY!"=="PIPELINE_CLIP_MODE"          set "DEF_CLIP_MODE=!VAL!"
)

REM ============================================================================
REM  LANGUAGE
REM ============================================================================

echo  Transcription language:
echo.
echo    [1] ru  - Russian     (default)
echo    [2] en  - English
echo    [3] es  - Spanish
echo    [4] de  - German
echo    [5] fr  - French
echo    [6] pl  - Polish
echo    [7] uk  - Ukrainian
echo    [8] it  - Italian
echo    [9] Other (type manually)
echo.

set "LANG=!DEF_LANG!"
set /p LANG_CHOICE="  Language [1-9] (Enter = !DEF_LANG!): "

if "!LANG_CHOICE!"=="1" set "LANG=ru"
if "!LANG_CHOICE!"=="2" set "LANG=en"
if "!LANG_CHOICE!"=="3" set "LANG=es"
if "!LANG_CHOICE!"=="4" set "LANG=de"
if "!LANG_CHOICE!"=="5" set "LANG=fr"
if "!LANG_CHOICE!"=="6" set "LANG=pl"
if "!LANG_CHOICE!"=="7" set "LANG=uk"
if "!LANG_CHOICE!"=="8" set "LANG=it"
if not "!LANG_CHOICE!"=="9" goto :skip_lang_manual
set /p LANG="  Type language code (en, ru, es, de, fr, pl, uk, it, pt, zh, ja, ko): "
:skip_lang_manual

echo.
echo  [OK] Language: !LANG!
echo.

REM ============================================================================
REM  DIRECTION MODE
REM ============================================================================

echo  Direction mode:
echo.
set "DEF_PASS_LABEL=2-pass"
if /i "!DEF_TWO_PASS!"=="false" set "DEF_PASS_LABEL=1-pass"

echo    [1] 1-pass   (fast, up to ~200 clips)
echo    [2] 2-pass   (recommended, 200+ clips)
echo.
echo    Default from .env: !DEF_PASS_LABEL!
echo.

set "TWO_PASS_FLAG=--two-pass"
if /i "!DEF_TWO_PASS!"=="false" set "TWO_PASS_FLAG="

set /p "CHOICE=Choose [1/2] (Enter = !DEF_PASS_LABEL!): "

if "!CHOICE!"=="1" (
    set "TWO_PASS_FLAG="
    echo.
    echo  [OK] 1-pass mode
) else if "!CHOICE!"=="2" (
    set "TWO_PASS_FLAG=--two-pass"
    echo.
    echo  [OK] 2-pass mode
) else (
    echo.
    echo  [OK] !DEF_PASS_LABEL! mode (default)
)

REM ============================================================================
REM  CLIP MODE
REM ============================================================================

echo.
echo  Clip type:
echo.
echo    [1] Video      (Veo3 fragments)  !DEF_VID_MIN!-!DEF_VID_MAX!s
echo    [2] Slideshow  (images)          !DEF_SLD_MIN!-!DEF_SLD_MAX!s
echo.
echo    Default from .env: !DEF_CLIP_MODE!
echo.

set "CLIP_MODE=!DEF_CLIP_MODE!"
set /p "CLIP_CHOICE=Choose [1/2] (Enter = !DEF_CLIP_MODE!): "

if "!CLIP_CHOICE!"=="1" (
    set "CLIP_MODE=video"
    echo.
    echo  [OK] Video mode
) else if "!CLIP_CHOICE!"=="2" (
    set "CLIP_MODE=slideshow"
    echo.
    echo  [OK] Slideshow mode
) else (
    echo.
    echo  [OK] !DEF_CLIP_MODE! (default)
)

REM ============================================================================
REM  CLIP DURATION
REM ============================================================================

if "!CLIP_MODE!"=="slideshow" (
    set "DEF_MIN=!DEF_SLD_MIN!"
    set "DEF_MAX=!DEF_SLD_MAX!"
) else (
    set "DEF_MIN=!DEF_VID_MIN!"
    set "DEF_MAX=!DEF_VID_MAX!"
)

echo.
echo  Clip duration:
echo    Default: !DEF_MIN!s - !DEF_MAX!s  (from .env)
echo.
echo    [1] Keep defaults  (Enter)
echo    [2] Change
echo.

set "CLIP_MIN=!DEF_MIN!"
set "CLIP_MAX=!DEF_MAX!"
set /p "DUR_CHOICE=  Duration [1/2] (Enter = keep): "
if "!DUR_CHOICE!"=="2" (
    set /p "CLIP_MIN=  Min duration (s): "
    set /p "CLIP_MAX=  Max duration (s): "
    echo.
    echo  [OK] Duration: !CLIP_MIN!s - !CLIP_MAX!s
) else (
    echo.
    echo  [OK] Duration: !DEF_MIN!s - !DEF_MAX!s (defaults)
)

REM ============================================================================
REM  INTRO BLOCK
REM ============================================================================

echo.
echo  Intro block:
echo    Default: first !INTRO_BLOCK!s of video  /  clips: !INTRO_MIN!s - !INTRO_MAX!s
echo.
echo    [1] Keep defaults  (Enter)
echo    [2] Change
echo.

set /p "INTRO_CHOICE=  Intro [1/2] (Enter = keep): "
if "!INTRO_CHOICE!"=="2" (
    set /p "INTRO_BLOCK=  Intro block duration (s): "
    set /p "INTRO_MIN=  Intro clip min (s): "
    set /p "INTRO_MAX=  Intro clip max (s): "
    echo.
    echo  [OK] Intro: first !INTRO_BLOCK!s  /  clips: !INTRO_MIN!s - !INTRO_MAX!s
) else (
    echo.
    echo  [OK] Intro: defaults ^(!INTRO_BLOCK!s / !INTRO_MIN!-!INTRO_MAX!s^)
)

REM ============================================================================
REM  START
REM ============================================================================

echo.
echo ================================================================================
echo  Starting pipeline...
echo  Language: !LANG!   Two-pass: !TWO_PASS_FLAG!   Clip: !CLIP_MODE!   Duration: !CLIP_MIN!s-!CLIP_MAX!s
echo  Intro: first !INTRO_BLOCK!s  /  clips: !INTRO_MIN!s-!INTRO_MAX!s
echo ================================================================================
echo.

cd /d "%~dp0agent"

set INTRO_BLOCK_DURATION=!INTRO_BLOCK!
set INTRO_CLIP_MIN_DURATION=!INTRO_MIN!
set INTRO_CLIP_MAX_DURATION=!INTRO_MAX!

python agent.py process --run --language !LANG! !TWO_PASS_FLAG! --clip-mode !CLIP_MODE! --clip-min !CLIP_MIN! --clip-max !CLIP_MAX!

if errorlevel 1 (
    echo.
    echo [ERROR] Pipeline failed!
    pause
    exit /b 1
)

echo.
echo ================================================================================
echo  [OK] 1_INTERACTIVESTART complete! Check projects\ folder.
echo ================================================================================
pause
