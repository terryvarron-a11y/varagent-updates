"""Pass 1 directive for AI-generated static infographic clips."""
from __future__ import annotations

import config
from pathlib import Path


def infographic_markup_directive() -> str:
    """Return the optional Pass 1 source-markup directive."""
    if not getattr(config, 'INFOGRAPHIC_ENABLED', False):
        return ''

    target_pct = int(float(getattr(config, 'INFOGRAPHIC_RATIO_TARGET', 0.15)) * 100)
    max_pct = int(float(getattr(config, 'INFOGRAPHIC_RATIO_MAX', 0.25)) * 100)
    return f"""

---

## INFOGRAPHIC MARKUP

The user enabled a dedicated AI infographic route. It generates a SINGLE STILL
image and never sends it to Veo/VideoGen. Mark only clips that become clearer
as a diagram, chart, map, timeline, comparison, labelled process, or structured
data visualization.

GOOD candidates:
- Statistics, quantities, rankings, proportions, before/after comparisons
- Dates, chronological sequences, historical timelines, evolution/process flows
- Geography, routes, maps, scale comparisons, systems and causal relationships
- Clear explanatory lists where a visual hierarchy communicates the point faster

DO NOT mark:
- Character drama, emotional moments, action, dialogue, landscapes, atmosphere
- A named person/place that needs an authentic Real Photo
- Generic modern footage suitable for Stock
- Any clip already marked for Real Photo or Stock
- Consecutive clips unless the narration genuinely requires separate diagrams

Target: about {target_pct}% of all clips. This is a user-controlled upper-bound
goal, not a quota to force. Never exceed {max_pct}% and never replace a stronger
cinematic, archival, or stock choice merely to fill it.

If a clip qualifies, add exactly:
  "source": "infographic"

The style guide may contain an INFOGRAPHIC / ИНФОГРАФИКА section. If it does not,
Pass 2 will use the user's editable default infographic style. Only MARK here;
do not write a prompt, chart data, or extra source fields.
"""


def default_infographic_style() -> str:
    """Load the GUI-editable fallback style used when a style guide lacks one."""
    path = Path(__file__).resolve().parent.parent / 'prompts' / 'infographic_default_style.txt'
    try:
        text = path.read_text(encoding='utf-8-sig').strip()
        if text:
            return text
    except OSError:
        pass
    return (
        'Clean editorial infographic, strong hierarchy, readable large labels, '
        'limited palette, generous spacing, no decorative clutter, no watermark.'
    )


def infographic_pass2_directive() -> str:
    """Inline rule for legacy Gemini/script Pass 2 prompts."""
    return f"""

INFOGRAPHIC RULE:
- A clip marked `source: "infographic"` is a STATIC information graphic, not a film shot.
- Turn its voiceover into one useful diagram, timeline, chart, map, comparison, labelled process, or data composition.
- Use an explicit infographic section from the style guide when present; otherwise use this default:
  {default_infographic_style()}
- No camera angle, actors, cinematic action, motion, lens language, 3D render, or tiny unreadable text.
- Do not append the normal continuous-camera ending for infographic clips.
"""
