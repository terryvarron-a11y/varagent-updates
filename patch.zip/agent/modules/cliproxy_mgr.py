"""
cliproxy_mgr.py — управление локальным CLIProxyAPI для варагента.

CLIProxyAPI даёт Gemini 3.1 Pro через Antigravity OAuth (обход выжженной API-квоты).
Этот модуль инкапсулирует всё, что раньше делалось вручную (winget, config.yaml,
запуск сервера, login, health) — чтобы GUI мог авторизовать в один клик, как Codex/Claude.

Ключевые нюансы (проверены эмпирически):
- Сервер слушает :8317, OpenAI-совместимый /v1/chat/completions.
- Логин с конфигом БЕЗ proxy-url → callback-listener :51121, браузер завершает сам.
  С proxy-url логин уходит в ручной paste-режим — поэтому для логина отдельный конфиг.
- Все Gemini-запросы (API) идут через сервер С proxy-url (гео-прокси, если задан).
- Новый Google-аккаунт может требовать одноразовой верификации (ссылка от Google).
"""
from __future__ import annotations

import os
import sys
import shutil
import socket
import subprocess
import time
from pathlib import Path
from typing import Optional

PROXY_PORT = 8317
CALLBACK_PORT = 51121
LOCAL_KEY = "varagent-cliproxy-local"

# creationflags: скрыть консольное окно на Windows
_NOWIN = {"creationflags": 0x08000000} if sys.platform == "win32" else {}


def _home() -> Path:
    return Path(os.path.expanduser("~"))


def config_dir() -> Path:
    d = _home() / ".cli-proxy-api"
    d.mkdir(parents=True, exist_ok=True)
    return d


def config_path() -> Path:
    return config_dir() / "config.yaml"


def login_config_path() -> Path:
    """Отдельный конфиг для логина — БЕЗ proxy-url (иначе paste-режим)."""
    return config_dir() / "config_login.yaml"


def auth_files() -> list[Path]:
    """JSON-файлы авторизации (antigravity-<email>.json и т.п.), кроме служебных."""
    d = config_dir()
    return [f for f in d.glob("*.json")
            if not f.name.startswith("_") and not f.name.startswith("config")]


# ─────────────────────────────────────────────────────────────────────────────
# Поиск / установка бинарника
# ─────────────────────────────────────────────────────────────────────────────

def find_exe() -> Optional[Path]:
    """cli-proxy-api.exe: PATH → winget packages → bundled в дистрибутиве."""
    # 1) PATH (winget добавляет алиас cli-proxy-api)
    w = shutil.which("cli-proxy-api")
    if w:
        return Path(w)
    # 2) winget packages
    if sys.platform == "win32":
        base = _home() / "AppData" / "Local" / "Microsoft" / "WinGet" / "Packages"
        if base.exists():
            hits = list(base.glob("LuisPater.CLIProxyAPI_*/cli-proxy-api.exe"))
            if hits:
                return hits[0]
    # 3) bundled рядом с варагентом (portable)
    here = Path(__file__).resolve().parent.parent.parent  # VARAGENT_API/
    for cand in (here / "CLIProxyAPI" / "cli-proxy-api.exe",
                 here / "cli-proxy-api.exe",
                 here / "cli-proxy-api"):
        if cand.exists():
            return cand
    return None


def install_via_winget(log=print) -> bool:
    """winget install LuisPater.CLIProxyAPI. Возвращает True при успехе."""
    if sys.platform != "win32":
        log("Автоустановка через winget только на Windows — поставьте cli-proxy-api вручную.")
        return False
    if not shutil.which("winget"):
        log("winget не найден — поставьте cli-proxy-api вручную или обновите Windows.")
        return False
    log("Устанавливаю CLIProxyAPI через winget...")
    try:
        subprocess.run(
            ["winget", "install", "--id", "LuisPater.CLIProxyAPI", "--source", "winget",
             "--accept-source-agreements", "--accept-package-agreements", "--disable-interactivity"],
            timeout=300, **_NOWIN,
        )
    except Exception as e:
        log(f"winget install error: {e}")
    return find_exe() is not None


# ─────────────────────────────────────────────────────────────────────────────
# Конфиги
# ─────────────────────────────────────────────────────────────────────────────

def write_config(proxy_url: str = "") -> Path:
    """Основной конфиг сервера (порт 8317, локальный ключ, опц. гео-прокси)."""
    lines = [
        "# CLIProxyAPI config для VARAGENT (авто-сгенерён GUI). Gemini 3.1 Pro via Antigravity.",
        'host: "127.0.0.1"',
        f"port: {PROXY_PORT}",
        'auth-dir: "~/.cli-proxy-api"',
        "api-keys:",
        f'  - "{LOCAL_KEY}"',
        "remote-management:",
        "  allow-remote: false",
        '  secret-key: ""',
        "debug: false",
        "request-retry: 3",
    ]
    pu = (proxy_url or "").strip()
    if pu:
        lines.append(f'# Гео-прокси: все запросы к Google/Antigravity идут через этот IP')
        lines.append(f'proxy-url: "{pu}"')
    cfg = config_path()
    cfg.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return cfg


def read_proxy_url() -> str:
    """Текущий proxy-url из config.yaml (для показа в GUI). '' если нет."""
    cfg = config_path()
    if not cfg.exists():
        return ""
    try:
        for line in cfg.read_text(encoding="utf-8").splitlines():
            s = line.strip()
            if s.startswith("proxy-url:"):
                val = s.split(":", 1)[1].strip().strip('"').strip("'")
                return val
    except Exception:
        pass
    return ""


def write_login_config() -> Path:
    """Конфиг для ЛОГИНА — БЕЗ proxy-url (браузерный callback-listener, без paste)."""
    lines = [
        'host: "127.0.0.1"',
        f"port: {PROXY_PORT + 1}",  # 8318, чтобы не конфликтовать с сервером
        'auth-dir: "~/.cli-proxy-api"',
        "api-keys:",
        f'  - "{LOCAL_KEY}"',
        "debug: false",
    ]
    cfg = login_config_path()
    cfg.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return cfg


# ─────────────────────────────────────────────────────────────────────────────
# Сервер
# ─────────────────────────────────────────────────────────────────────────────

def is_server_running() -> bool:
    """True если что-то слушает :8317."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1.0)
        return s.connect_ex(("127.0.0.1", PROXY_PORT)) == 0


def start_server(proxy_url: str = "", log=print) -> bool:
    """Запустить сервер (если не запущен). Возвращает True если слушает :8317."""
    if is_server_running():
        return True
    exe = find_exe()
    if not exe:
        log("cli-proxy-api не найден — нажмите Antigravity Login (поставится автоматически).")
        return False
    write_config(proxy_url)
    try:
        subprocess.Popen(
            [str(exe), "-config", str(config_path())],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,
            **_NOWIN,
        )
    except Exception as e:
        log(f"Не удалось запустить cli-proxy-api: {e}")
        return False
    for _ in range(15):
        if is_server_running():
            log(f"CLIProxyAPI сервер запущен на :{PROXY_PORT}")
            return True
        time.sleep(0.5)
    log("CLIProxyAPI сервер не поднялся за 7с.")
    return False


def restart_server(proxy_url: str = "", log=print) -> bool:
    """Перезапуск (подхватить новый proxy-url / свежий токен)."""
    stop_server()
    time.sleep(1.0)
    return start_server(proxy_url, log=log)


def stop_server():
    """Убить процессы cli-proxy-api (сервер + login)."""
    if sys.platform == "win32":
        try:
            subprocess.run(["taskkill", "/F", "/IM", "cli-proxy-api.exe"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **_NOWIN)
        except Exception:
            pass
    else:
        try:
            subprocess.run(["pkill", "-f", "cli-proxy-api"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────────────────────
# Авторизация / статус
# ─────────────────────────────────────────────────────────────────────────────

def is_authorized() -> bool:
    """Есть ли валидный токен (файл auth + сервер отдаёт непустой список моделей)."""
    if not auth_files():
        return False
    try:
        import requests
        r = requests.get(f"http://127.0.0.1:{PROXY_PORT}/v1/models",
                         headers={"Authorization": f"Bearer {LOCAL_KEY}"}, timeout=6)
        if r.status_code == 200:
            data = r.json().get("data") or []
            return len(data) > 0
    except Exception:
        pass
    return False


# Провайдеры OAuth-логина: флаг cli-proxy-api + префикс имени auth-файла.
# Проверено по исходникам CLIProxyAPI 7.2.77:
#   antigravity → antigravity-<email>.json (callback :51121)
#   claude      → claude-<email>.json      (callback :54545, OAuth через claude.ai, подписка Pro/Max)
#   xai         → xai-<email>.json         (callback :56121, device-code, на будущее)
_LOGIN_PROVIDERS = {
    "antigravity": {"flag": "-antigravity-login", "prefixes": ("antigravity-", "gemini-", "aistudio-")},
    "claude":      {"flag": "-claude-login",      "prefixes": ("claude-", "anthropic-")},
    "xai":         {"flag": "-xai-login",         "prefixes": ("xai-", "grok-")},
}


def authorized_email(provider: Optional[str] = None) -> Optional[str]:
    """Email из имени auth-файла. provider=None → любой известный провайдер;
    provider='claude'/'antigravity'/'xai' → только его auth-файл."""
    if provider:
        prefixes = _LOGIN_PROVIDERS.get(provider, {}).get("prefixes", ())
    else:
        prefixes = tuple(p for v in _LOGIN_PROVIDERS.values() for p in v["prefixes"])
    for f in auth_files():
        name = f.stem
        for pref in prefixes:
            if name.startswith(pref):
                return name[len(pref):]
    return None


def has_auth(provider: str) -> bool:
    """Есть ли auth-файл конкретного провайдера (claude/antigravity/xai)."""
    return authorized_email(provider) is not None


def login_command(provider: str = "antigravity") -> Optional[list[str]]:
    """Аргументы запуска логина (в терминале). Конфиг БЕЗ прокси → браузерный callback.
    provider: antigravity (Gemini) | claude (подписка Pro/Max) | xai (Grok)."""
    exe = find_exe()
    if not exe:
        return None
    flag = _LOGIN_PROVIDERS.get(provider, _LOGIN_PROVIDERS["antigravity"])["flag"]
    write_login_config()
    return [str(exe), flag, "-config", str(login_config_path())]


def test_proxy(proxy_url: str, timeout: int = 25) -> tuple[bool, str]:
    """Проверка гео-прокси: возвращает (ok, текст об исходящем IP или ошибка)."""
    pu = (proxy_url or "").strip()
    if not pu:
        return True, "Прокси не задан — прямое соединение."
    curl = shutil.which("curl") or "curl"
    # socks5h/http — DNS через прокси (важно для IPv6-прокси)
    scheme_proxy = pu.replace("socks5://", "socks5h://", 1) if pu.startswith("socks5://") else pu
    try:
        r = subprocess.run(
            [curl, "-s", "--max-time", str(timeout), "--proxy", scheme_proxy, "https://ifconfig.co/json"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", **_NOWIN,
        )
        out = (r.stdout or "").strip()
        if out and ("ip" in out.lower()):
            import json as _json
            try:
                j = _json.loads(out)
                return True, f"IP {j.get('ip','?')} | {j.get('country','?')} ({j.get('city','')})"
            except Exception:
                return True, out[:200]
        return False, f"Прокси не ответил: {(r.stderr or out or 'нет данных')[:200]}"
    except Exception as e:
        return False, f"Ошибка проверки прокси: {e}"
