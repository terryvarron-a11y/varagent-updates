#!/bin/bash
# ============================================================================
# Clears GITHUB_TOKEN in agent/.env
# The distributed token expired; GitHub answers 404 to requests carrying it,
# so the Update button fails. The repo is public - no token is needed at all.
# ============================================================================
cd "$(dirname "${BASH_SOURCE[0]}")" || exit 1

echo ""
echo "  VarAgent - repairing the update check"
echo "  ====================================="
echo ""

# Folder name does not matter. Look next to this file, one level up, inside any
# subfolder holding varagent.py, and finally in the macOS install location.
ENV_FILE=""
for CANDIDATE in "agent/.env" "../agent/.env"; do
    [ -f "$CANDIDATE" ] && ENV_FILE="$CANDIDATE" && break
done

if [ -z "$ENV_FILE" ]; then
    for DIR in */; do
        if [ -f "${DIR}agent/.env" ] && [ -f "${DIR}varagent.py" ]; then
            ENV_FILE="${DIR}agent/.env"
            break
        fi
    done
fi

if [ -z "$ENV_FILE" ] && [ -f "$HOME/Library/Application Support/VARAGENT/agent/.env" ]; then
    ENV_FILE="$HOME/Library/Application Support/VARAGENT/agent/.env"
fi

if [ -z "$ENV_FILE" ]; then
    echo "  [ERROR] agent/.env not found."
    echo ""
    echo "  Put fix_updates.command INTO the VarAgent folder - the one that holds"
    echo "  varagent.command - and run it again. The folder name does not matter."
    echo ""
    read -r -p "Press Enter to close..."
    exit 1
fi

echo "  Found: $ENV_FILE"
echo ""

if ! grep -q '^GITHUB_TOKEN=' "$ENV_FILE"; then
    echo "  Line GITHUB_TOKEN not found - nothing to clear."
    echo ""
    read -r -p "Press Enter to close..."
    exit 2
fi

if grep -qE '^GITHUB_TOKEN=[[:space:]]*$' "$ENV_FILE"; then
    echo "  Token is already empty - nothing to do."
    echo ""
    read -r -p "Press Enter to close..."
    exit 3
fi

cp "$ENV_FILE" "${ENV_FILE}.bak_token"
# -i '' — BSD sed on macOS wants an explicit empty suffix
sed -i '' -E 's/^GITHUB_TOKEN=.*$/GITHUB_TOKEN=/' "$ENV_FILE" 2>/dev/null \
    || sed -i -E 's/^GITHUB_TOKEN=.*$/GITHUB_TOKEN=/' "$ENV_FILE"

echo "  Token cleared. Backup: ${ENV_FILE}.bak_token"
echo ""
echo "  Done. Start VarAgent and press \"Check\" on the Donate tab."
echo ""
read -r -p "Press Enter to close..."
