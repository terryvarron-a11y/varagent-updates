"""
TTS модуль — озвучка текста через четыре сервиса:
  - voiceapi.csv666.ru        (X-API-Key, template_uuid)
  - voicer.mat3u.com          (Bearer token, ElevenLabs voice_id)
  - api.qw1voicegencore.pro   (X-API-Key, voice_id из каталога, своя очередь)
  - api.lumean.app             (X-API-KEY, TTS template UUID)

Голос/шаблон выбирается в GUI или пресете через TTS_VOICE_ID.
Файл сценария содержит только текст озвучки и читается целиком.
"""
from __future__ import annotations

import logging
import time
import zipfile
import requests
from pathlib import Path
from typing import Optional
from tqdm import tqdm

import config
from modules.textio import read_user_text

logger = logging.getLogger(__name__)


# ============================================================================
# ПАРСЕР ФАЙЛА СЦЕНАРИЯ
# ============================================================================

def parse_script_file(script_path: Path) -> tuple[str, str]:
    """Прочитать сценарий целиком с голосом, выбранным в GUI/пресете."""
    return read_script_for_tts(Path(script_path))


# ============================================================================
# БАЗОВЫЙ КЛИЕНТ
# ============================================================================

def _extract_audio_from_zip(zip_path: Path, output_dir: Path) -> Path:
    """
    Извлекает основной аудиофайл из ZIP.
    ZIP от TTS сервисов может содержать: чанки (chunk_001.mp3...) + склеенный файл (merged/full/result).
    Берём самый большой .mp3 — это склеенный файл.
    """
    audio_exts = {'.mp3', '.wav', '.m4a', '.aac', '.flac'}
    with zipfile.ZipFile(zip_path, 'r') as zf:
        zf.extractall(output_dir)
        audio_files = []
        for info in zf.infolist():
            p = output_dir / info.filename
            if p.suffix.lower() in audio_exts and p.is_file():
                audio_files.append(p)

    if not audio_files:
        raise RuntimeError(f"ZIP не содержит аудиофайлов: {zip_path}")

    # Берём самый большой файл — это склеенный результат
    best = max(audio_files, key=lambda f: f.stat().st_size)
    print(f"   ZIP: извлечено {len(audio_files)} файл(ов), основной: {best.name} ({best.stat().st_size // 1024} KB)")
    return best


class BaseTTSClient:
    POLL_INTERVAL = 5   # секунд между проверками статуса
    POLL_TIMEOUT  = 600 # секунд максимального ожидания

    def synthesize(self, text: str, voice_id: str, output_path: Path) -> Path:
        raise NotImplementedError

    def _wait_for_completion(self, task_id, status_fn, done_statuses, error_statuses) -> str:
        """Polling до готовности задачи."""
        elapsed = 0
        last_status = None
        transient_errors = 0
        with tqdm(desc="TTS: ожидание", unit="с", dynamic_ncols=True) as pbar:
            while elapsed < self.POLL_TIMEOUT:
                try:
                    status = status_fn(task_id)
                    transient_errors = 0
                except requests.RequestException as exc:
                    transient_errors += 1
                    print(
                        f"   TTS: временная ошибка проверки статуса "
                        f"({transient_errors}/3): {exc}"
                    )
                    if transient_errors >= 3:
                        raise
                    delay = min(float(self.POLL_INTERVAL), 5.0)
                    time.sleep(delay)
                    elapsed += delay
                    pbar.update(delay)
                    continue
                if status != last_status:
                    pbar.set_postfix(status=status)
                    last_status = status
                if status in done_statuses:
                    pbar.update(elapsed)
                    return status
                if status in error_statuses:
                    raise RuntimeError(f"TTS задача провалилась со статусом: {status}")
                time.sleep(self.POLL_INTERVAL)
                elapsed += self.POLL_INTERVAL
                pbar.update(self.POLL_INTERVAL)
        raise TimeoutError(f"TTS задача не завершилась за {self.POLL_TIMEOUT}с")


# ============================================================================
# СЕРВИС 1: voiceapi.csv666.ru
# ============================================================================

class CSV666Client(BaseTTSClient):
    """
    API: voiceapi.csv666.ru
    Auth: X-API-Key header
    Voice: задаётся через template_uuid (голос привязан к шаблону)
    """
    BASE_URL = 'https://voiceapi.csv666.ru'

    def __init__(self, api_key: str = None):
        self.api_key = api_key or config.TTS_API_KEY_CSV666
        if not self.api_key:
            raise ValueError("TTS_API_KEY_CSV666 не задан в .env")
        self.headers = {'X-API-Key': self.api_key}

    def _find_template_uuid(self, voice_id: str) -> Optional[str]:
        """
        Ищет шаблон пользователя с данным voice_id в настройках.
        Если не найден — использует voice_id напрямую как template_uuid.
        """
        try:
            r = requests.get(f'{self.BASE_URL}/templates', headers=self.headers, timeout=15)
            r.raise_for_status()
            templates = r.json()
            for tmpl in templates:
                settings = tmpl.get('settings', {})
                # Ищем совпадение voice_id в любом поле settings
                if (settings.get('voice_id') == voice_id
                        or settings.get('voice') == voice_id
                        or str(tmpl.get('uuid', '')) == voice_id):
                    return tmpl['uuid']
        except Exception as e:
            print(f"   [WARN] Не удалось загрузить шаблоны csv666: {e}")
        # Fallback: считаем что voice_id — это уже template_uuid
        return voice_id

    def _get_status(self, task_id) -> str:
        r = requests.get(f'{self.BASE_URL}/tasks/{task_id}/status',
                         headers=self.headers, timeout=15)
        r.raise_for_status()
        return r.json().get('status', 'unknown')

    def synthesize(self, text: str, voice_id: str, output_path: Path) -> Path:
        template_uuid = self._find_template_uuid(voice_id)
        print(f"   csv666: template_uuid = {template_uuid}")

        payload = {
            'text': text,
            'template_uuid': template_uuid,
            'chunk_size': config.TTS_CSV666_CHUNK_SIZE,
        }

        r = requests.post(f'{self.BASE_URL}/tasks', json=payload,
                          headers=self.headers, timeout=30)
        r.raise_for_status()
        task_id = r.json()['task_id']
        print(f"   csv666: task_id = {task_id}")

        # Ждём готовности
        self._wait_for_completion(
            task_id,
            status_fn=self._get_status,
            done_statuses={'ending', 'ending_processed'},
            error_statuses={'error', 'error_handled'},
        )

        # Скачиваем результат
        r = requests.get(f'{self.BASE_URL}/tasks/{task_id}/result',
                         headers=self.headers, timeout=120, stream=True)
        r.raise_for_status()

        # Определяем формат по Content-Type (сервер может вернуть ZIP даже если просили mp3)
        ct = r.headers.get('Content-Type', '')
        is_zip = 'zip' in ct or config.TTS_CSV666_OUTPUT_FORMAT == 'zip'
        dl_suffix = '.zip' if is_zip else '.mp3'
        dl_path = output_path.with_suffix(dl_suffix)

        with open(dl_path, 'wb') as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)

        # Если ZIP — извлекаем основной аудиофайл
        if dl_path.suffix == '.zip' or zipfile.is_zipfile(dl_path):
            extract_dir = dl_path.parent / f'{dl_path.stem}_extracted'
            extract_dir.mkdir(exist_ok=True)
            audio = _extract_audio_from_zip(dl_path, extract_dir)
            # Копируем основной файл на место
            final = output_path.with_suffix(audio.suffix)
            audio.replace(final)
            print(f"   csv666: сохранено → {final}")
            return final

        print(f"   csv666: сохранено → {dl_path}")
        return dl_path


# ============================================================================
# СЕРВИС 2: voicer.mat3u.com
# ============================================================================

class Mat3uClient(BaseTTSClient):
    """
    API: voicer.mat3u.com
    Auth: Authorization: Bearer token
    Voice: ElevenLabs voice_id
    """
    BASE_URL = 'https://voicer.mat3u.com/api/v1'

    def __init__(self, api_key: str = None):
        self.api_key = api_key or config.TTS_API_KEY_MAT3U
        if not self.api_key:
            raise ValueError("TTS_API_KEY_MAT3U не задан в .env")
        self.headers = {'Authorization': f'Bearer {self.api_key}'}

    def _get_status(self, task_id: str) -> str:
        r = requests.get(f'{self.BASE_URL}/voice/status/{task_id}',
                         headers=self.headers, timeout=15)
        r.raise_for_status()
        return r.json().get('status', 'unknown')

    def synthesize(self, text: str, voice_id: str, output_path: Path) -> Path:
        payload = {
            'text': text,
            'voice_id': voice_id,
            'model_id': config.TTS_MAT3U_MODEL_ID,
            'split_type': config.TTS_MAT3U_SPLIT_TYPE,
            'max_chunk_length': config.TTS_MAT3U_MAX_CHUNK_LENGTH,
            'split_output': config.TTS_MAT3U_SPLIT_OUTPUT,
            'auto_pause_enabled': config.TTS_MAT3U_AUTO_PAUSE_ENABLED,
            'auto_pause_duration': config.TTS_MAT3U_AUTO_PAUSE_DURATION,
            'auto_pause_frequency': config.TTS_MAT3U_AUTO_PAUSE_FREQUENCY,
        }

        r = requests.post(f'{self.BASE_URL}/voice/synthesize', json=payload,
                          headers=self.headers, timeout=30)
        r.raise_for_status()
        data = r.json()
        task_id = data['task_id']
        chunks = data.get('chunks_count', '?')
        print(f"   mat3u: task_id = {task_id}, chunks = {chunks}")

        # Ждём готовности
        self._wait_for_completion(
            task_id,
            status_fn=self._get_status,
            done_statuses={'completed'},
            error_statuses={'failed'},
        )

        # Скачиваем результат
        r = requests.get(f'{self.BASE_URL}/voice/download/{task_id}',
                         headers=self.headers, timeout=120, stream=True)
        r.raise_for_status()

        # Определяем расширение по Content-Type
        ct = r.headers.get('Content-Type', '')
        if 'zip' in ct:
            dl_suffix = '.zip'
        elif 'mpeg' in ct or 'mp3' in ct:
            dl_suffix = '.mp3'
        else:
            dl_suffix = '.mp3'

        dl_path = output_path.with_suffix(dl_suffix)
        with open(dl_path, 'wb') as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)

        # Если ZIP (split_output=true) — извлекаем основной аудиофайл
        if dl_path.suffix == '.zip' or zipfile.is_zipfile(dl_path):
            extract_dir = dl_path.parent / f'{dl_path.stem}_extracted'
            extract_dir.mkdir(exist_ok=True)
            audio = _extract_audio_from_zip(dl_path, extract_dir)
            final = output_path.with_suffix(audio.suffix)
            audio.replace(final)
            print(f"   mat3u: сохранено → {final}")
            return final

        print(f"   mat3u: сохранено → {dl_path}")
        return dl_path


# ============================================================================
# СЕРВИС 3: api.qw1voicegencore.pro (Voicegen)
# ============================================================================

class VoicegenClient(BaseTTSClient):
    """
    API: api.qw1voicegencore.pro
    Auth: X-API-Key header
    Voice: voice_id из каталога (client/voice-catalog, 2400+ голосов)

    Отличия от соседей:
      • у сервиса СВОЯ очередь — задачи можно ставить пачкой, не дожидаясь
        предыдущей (используется в пакетной озвучке);
      • движок и стабильность задаются на задачу (elevenLabsV3 и т.п.);
      • длинный текст сервис делит сам (chunk_size + thread_count).
    """

    def __init__(self, api_key: str = None, base_url: str = None):
        self.api_key = api_key or config.TTS_API_KEY_VOICEGEN
        if not self.api_key:
            raise ValueError("TTS_API_KEY_VOICEGEN не задан в .env")
        self.base = (base_url or config.TTS_VOICEGEN_BASE_URL).rstrip('/')
        self.headers = {'X-API-Key': self.api_key}

    def _url(self, path: str) -> str:
        return f"{self.base}/{path.lstrip('/')}"

    def _task_data(self, task_id: str) -> dict:
        """Данные задачи.

        ВАЖНО: ответ приходит обёрткой {ok, task, tasks, queue} — сама задача
        лежит ВНУТРИ 'task'. Чтение с верхнего уровня даёт None, и поллинг
        зависает навсегда (этот баг был в VOICEGEN_GUI: в интерфейсе стояло
        «None 0%», а задача якобы шла).
        """
        r = requests.get(self._url(f'client/tasks/{task_id}'),
                         headers=self.headers, timeout=30)
        r.raise_for_status()
        payload = r.json()
        inner = payload.get('task')
        return inner if isinstance(inner, dict) else payload

    def _get_status(self, task_id: str) -> str:
        # Пустой статус превращаем в 'unknown': так он не совпадёт ни с
        # успехом, ни с ошибкой, но и не притворится нормальным ходом работы.
        return str(self._task_data(task_id).get('status') or 'unknown')

    def voice_catalog(self) -> list:
        """Каталог голосов — для выбора в интерфейсе."""
        r = requests.get(self._url('client/voice-catalog'),
                         headers=self.headers, timeout=60)
        r.raise_for_status()
        return r.json().get('voices', [])

    def create_task(self, text: str, voice_id: str, filename: str) -> str:
        """Поставить задачу в очередь сервиса. Возвращает task_id."""
        payload = {
            'text': text,
            'voice_id': voice_id,
            'voice_engine': config.TTS_VOICEGEN_ENGINE,
            'voice_engine_settings': {
                'stability': float(config.TTS_VOICEGEN_STABILITY),
            },
            'filename': filename,
            'chunk_size': int(config.TTS_VOICEGEN_CHUNK_SIZE),
            'delay_between_chunks': float(
                config.TTS_VOICEGEN_DELAY_BETWEEN_CHUNKS),
            'thread_count': int(config.TTS_VOICEGEN_THREAD_COUNT),
            'auto_start': True,
        }
        r = requests.post(self._url('client/tasks'), json=payload,
                          headers=self.headers, timeout=60)
        r.raise_for_status()
        task = (r.json().get('task') or {})
        task_id = task.get('task_id') or task.get('id')
        if not task_id:
            raise RuntimeError(f"voicegen: сервис не вернул task_id: {r.text[:200]}")
        return str(task_id)

    def download_task(self, task_id: str, output_path: Path) -> Path:
        """Скачать готовый файл задачи."""
        r = requests.get(self._url(f'client/tasks/{task_id}/download'),
                         headers=self.headers, timeout=180, stream=True)
        r.raise_for_status()
        dl_path = output_path.with_suffix('.mp3')
        dl_path.parent.mkdir(parents=True, exist_ok=True)
        with open(dl_path, 'wb') as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)
        return dl_path

    def synthesize(self, text: str, voice_id: str, output_path: Path) -> Path:
        task_id = self.create_task(text, voice_id, output_path.name)
        print(f"   voicegen: task_id = {task_id}, символов = {len(text)}")

        self._wait_for_completion(
            task_id,
            status_fn=self._get_status,
            done_statuses={'done', 'completed'},
            # 'unknown' в ошибки НЕ добавляем: сервис отдаёт его в первые
            # секунды, пока задача только заводится. От вечного ожидания
            # защищает POLL_TIMEOUT базового класса.
            error_statuses={'error', 'failed', 'cancelled'},
        )

        final = self.download_task(task_id, output_path)
        size_kb = final.stat().st_size // 1024
        if not size_kb:
            raise RuntimeError(f"voicegen: скачан пустой файл {final}")
        print(f"   voicegen: сохранено → {final} ({size_kb} КБ)")
        return final


# ============================================================================
# СЕРВИС 4: api.lumean.app (Lumean Public API)
# ============================================================================

class LumeanClient(BaseTTSClient):
    """Lumean asynchronous TTS orders.

    Lumean does not accept a voice directly on POST /orders. The voice lives
    inside the selected ElevenLabs template, whose UUID is supplied by
    ``TTS_VOICE_ID`` from the GUI/preset.
    """

    def __init__(self, api_key: str = None, base_url: str = None):
        self.api_key = api_key or config.TTS_API_KEY_LUMEAN
        if not self.api_key:
            raise ValueError("TTS_API_KEY_LUMEAN не задан в .env")
        self.base = (base_url or config.TTS_LUMEAN_BASE_URL).rstrip('/')
        self.headers = {
            'X-API-KEY': self.api_key,
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        }
        self.POLL_INTERVAL = max(1.0, float(config.TTS_LUMEAN_POLL_INTERVAL))
        self.POLL_TIMEOUT = max(120, int(config.TTS_LUMEAN_POLL_TIMEOUT))

    def _url(self, path: str) -> str:
        return f"{self.base}/{path.lstrip('/')}"

    @staticmethod
    def _data(payload):
        if isinstance(payload, dict) and 'data' in payload:
            return payload.get('data')
        return payload

    def _json(self, method: str, path: str, payload=None, timeout=60):
        response = requests.request(
            method, self._url(path), headers=self.headers, json=payload,
            timeout=timeout)
        try:
            body = response.json()
        except ValueError:
            body = {}
        if not response.ok:
            reason = body.get('reason') if isinstance(body, dict) else ''
            message = body.get('message') if isinstance(body, dict) else ''
            detail = f"{reason}: {message}" if reason and message else (message or response.text[:500])
            raise RuntimeError(f"Lumean HTTP {response.status_code}: {detail}")
        if isinstance(body, dict) and body.get('success') is False:
            raise RuntimeError(f"Lumean: {body.get('message') or 'запрос отклонён'}")
        return self._data(body)

    def _get_order(self, order_id: str) -> dict:
        data = self._json('GET', f'orders/{order_id}', timeout=60)
        return data if isinstance(data, dict) else {}

    def templates(self) -> list[dict]:
        """Return the user's root TTS templates for the GUI selector."""
        data = self._json('GET', 'templates', timeout=60)
        return [item for item in data if isinstance(item, dict)] if isinstance(data, list) else []

    def template(self, template_id: str) -> dict:
        """Return one TTS template by UUID."""
        template_id = str(template_id or '').strip()
        if not template_id:
            return {}
        data = self._json('GET', f'templates/{template_id}', timeout=60)
        return data if isinstance(data, dict) else {}

    @staticmethod
    def template_voice_id(template: dict) -> str:
        """Extract the provider voice ID stored inside a Lumean template."""
        config_data = template.get('config') if isinstance(template, dict) else {}
        if not isinstance(config_data, dict):
            return ''
        tts_settings = config_data.get('tts_settings')
        if not isinstance(tts_settings, dict):
            return ''
        return str(tts_settings.get('voice_id') or '').strip()

    @staticmethod
    def template_preview_url(template: dict) -> str:
        """Use a direct preview URL if Lumean adds one to the template schema."""
        if not isinstance(template, dict):
            return ''
        config_data = template.get('config')
        tts_settings = (
            config_data.get('tts_settings')
            if isinstance(config_data, dict)
            else {}
        )
        for source in (template, tts_settings):
            if not isinstance(source, dict):
                continue
            for key in ('preview_url', 'sample_url', 'audio_preview_url'):
                value = str(source.get(key) or '').strip()
                if value:
                    return value
        return ''

    def describe_template(self, template_id: str) -> dict:
        """Человекочитаемое описание шаблона для лога.

        В логе стояло только `Voice ID: <uuid>`, и это вводило в заблуждение:
        для Lumean это UUID ШАБЛОНА, а не голоса — голос лежит внутри шаблона
        (улов 01.09.2026). Достаём то, что человек выбирал глазами: название
        шаблона, движок, модель и идентификатор голоса.

        Имени голоса тут нет и не будет: Lumean хранит в шаблоне только его ID,
        а ElevenLabs по этому ID из нашего региона не отвечает — на запрос
        приходит HTTP 200 с HTML-страницей о блокировке (проверено 01.09.2026).
        Идентификатора достаточно. Любая осечка не должна мешать озвучке:
        вернём то, что успели собрать.
        """
        info: dict = {}
        try:
            template = self.template(template_id)
        except Exception as exc:                                   # noqa: BLE001
            logger.debug("Lumean: шаблон %s не описан: %s", template_id, exc)
            return info
        if not isinstance(template, dict):
            return info
        info['template_name'] = str(template.get('name') or '').strip()
        service = template.get('service')
        if isinstance(service, dict):
            info['engine'] = str(service.get('display_name')
                                 or service.get('name') or '').strip()
        cfg = template.get('config')
        tts_settings = cfg.get('tts_settings') if isinstance(cfg, dict) else None
        if isinstance(tts_settings, dict):
            info['model'] = str(tts_settings.get('model_id') or '').strip()
        voice_id = self.template_voice_id(template)
        if voice_id:
            info['voice_id'] = voice_id
        return info

    @staticmethod
    def _result_files(order: dict) -> list[str]:
        result = order.get('result') if isinstance(order, dict) else {}
        if not isinstance(result, dict):
            return []
        files = result.get('files')
        return [str(x).strip() for x in files if str(x).strip()] if isinstance(files, list) else []

    @staticmethod
    def _failed_items(order: dict) -> list[dict]:
        items = order.get('items') if isinstance(order, dict) else []
        return [x for x in items if isinstance(x, dict) and
                str(x.get('status') or '').lower() == 'failed'] if isinstance(items, list) else []

    def _wait_order(self, order_id: str) -> dict:
        deadline = time.time() + self.POLL_TIMEOUT
        last_status = ''
        retried_failed = False
        terminal = {'completed', 'result_delivered', 'failed', 'compensated', 'cancelled'}
        while time.time() < deadline:
            order = self._get_order(order_id)
            status = str(order.get('status') or '').lower()
            if status != last_status:
                print(f"   lumean: order {order_id[:12]}… status={status or '?'}")
                last_status = status
            if status in terminal:
                if status in {'completed', 'result_delivered'}:
                    return order
                raise RuntimeError(f"Lumean заказ завершился статусом: {status}")
            if status == 'partially_completed' and not retried_failed:
                # Technical failed chunks can be retried without creating a
                # second full order. Policy-flagged chunks remain visible.
                failed = self._failed_items(order)
                if failed:
                    self._json('POST', f'orders/{order_id}/items/retry-failed', {}, timeout=60)
                    print(f"   lumean: повторяю неудачные чанки: {len(failed)}")
                    retried_failed = True
                else:
                    raise RuntimeError(
                        "Lumean заказ частично завершён: есть чанки, "
                        "которые нельзя автоматически повторить")
            elif status == 'partially_completed' and retried_failed:
                raise RuntimeError(
                    "Lumean заказ остался partially_completed после повтора "
                    "технических чанков")
            time.sleep(self.POLL_INTERVAL)
        raise TimeoutError(f"Lumean заказ не завершился за {self.POLL_TIMEOUT}с")

    def _download_result(self, storage_path: str, output_path: Path) -> Path:
        data = self._json('POST', 'storage/url', {'path': storage_path, 'download': True}, timeout=60)
        url = str((data or {}).get('url') or '') if isinstance(data, dict) else ''
        if not url:
            raise RuntimeError("Lumean не вернул временную ссылку на аудио")
        response = requests.get(url, timeout=600, stream=True)
        response.raise_for_status()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with output_path.open('wb') as handle:
            for chunk in response.iter_content(chunk_size=1024 * 1024):
                if chunk:
                    handle.write(chunk)
        if output_path.stat().st_size <= 0:
            raise RuntimeError(f"Lumean скачал пустой файл: {output_path}")
        return output_path

    def synthesize(self, text: str, voice_id: str, output_path: Path) -> Path:
        template_id = str(voice_id or '').strip()
        if not template_id:
            raise ValueError("Для Lumean нужен template UUID в первой строке сценария или TTS_VOICE_ID")
        order = self._json(
            'POST', 'orders',
            {'template_id': template_id, 'input_text': str(text or '')},
            timeout=120)
        order_id = str((order or {}).get('id') or '') if isinstance(order, dict) else ''
        if not order_id:
            raise RuntimeError(f"Lumean не вернул order id: {order}")
        print(f"   lumean: order_id = {order_id}, символов = {len(text)}")
        completed = self._wait_order(order_id)
        files = self._result_files(completed)
        if not files:
            raise RuntimeError("Lumean завершил заказ, но result.files пуст")
        return self._download_result(files[0], Path(output_path).with_suffix('.mp3'))


# ============================================================================
# ФАБРИКА
# ============================================================================

def get_tts_client(service: str = None) -> BaseTTSClient:
    """Возвращает клиент нужного сервиса."""
    svc = (service or config.TTS_SERVICE).lower()
    if svc == 'csv666':
        return CSV666Client()
    elif svc == 'mat3u':
        return Mat3uClient()
    elif svc == 'voicegen':
        return VoicegenClient()
    elif svc == 'lumean':
        return LumeanClient()
    else:
        raise ValueError(
            f"Неизвестный TTS сервис: {svc}. "
            f"Допустимые: csv666, mat3u, voicegen, lumean")


def read_script_for_tts(script_path: Path) -> tuple[str, str]:
    """Вернуть выбранный в GUI голос/шаблон и полный текст сценария."""
    content = read_user_text(Path(script_path)).strip()
    if not content:
        raise ValueError(f"Файл сценария пустой: {script_path}")
    voice_id = str(getattr(config, 'TTS_VOICE_ID', '') or '').strip()
    if not voice_id:
        raise ValueError(
            "Голос/шаблон не выбран. Выберите его в GUI или задайте TTS_VOICE_ID.")
    return voice_id, content


def run_tts_batch(jobs: list, service: str = None, log=print) -> dict:
    """Озвучить ПАЧКУ сценариев разом. Возвращает {script_path: audio_path}.

    jobs — список пар (script_path, output_path).

    Зачем: у Voicegen своя очередь, и он принимает все задачи сразу. Раньше
    файлы шли строго по одному — следующий ждал, пока доиграет предыдущий,
    хотя сервис в это время простаивал. На пачке из десятка сценариев это
    десятки лишних минут.

    Работает только для voicegen: у соседних сервисов нет разделения
    «создать задачу» и «забрать результат», поэтому для них честно падаем на
    последовательный путь — вызывающий это увидит по пустому ответу.
    """
    svc = (service or config.TTS_SERVICE).lower()
    if svc != 'voicegen' or not jobs:
        return {}

    client = get_tts_client(svc)
    results = {}
    queue = list(jobs)
    pending = {}          # task_id → (script_path, output_path)

    def submit(script_path, output_path):
        """Поставить одну задачу в очередь сервиса."""
        try:
            voice_id, text = read_script_for_tts(Path(script_path))
            task_id = client.create_task(text, voice_id, Path(output_path).name)
            pending[task_id] = (script_path, output_path)
            log(f"   ⏳ {Path(script_path).name}: задача {task_id[:8]}… поставлена")
            return True
        except Exception as exc:
            log(f"   ✗ {Path(script_path).name}: не поставилась — {exc}")
            return False

    def collect(task_id):
        """Забрать готовую задачу. True — задача закрыта (успех или отказ)."""
        script_path, output_path = pending[task_id]
        try:
            status = client._get_status(task_id)
        except Exception as exc:
            log(f"   ⚠ {Path(script_path).name}: статус недоступен — {exc}")
            return False
        if status in ('done', 'completed'):
            try:
                final = client.download_task(task_id, Path(output_path))
                results[str(script_path)] = final
                log(f"   ✓ {Path(script_path).name} → {final.name} "
                    f"({final.stat().st_size // 1024} КБ)")
            except Exception as exc:
                log(f"   ✗ {Path(script_path).name}: не скачалось — {exc}")
            pending.pop(task_id, None)
            return True
        if status in ('error', 'failed', 'cancelled'):
            log(f"   ✗ {Path(script_path).name}: сервис вернул статус «{status}»")
            pending.pop(task_id, None)
            return True
        return False

    # ПЕРВЫЙ СЦЕНАРИЙ — В ОДИНОЧКУ. Монтаж ждёт именно его, а воркеры сервиса
    # делятся между задачами: поставь всё разом — и первый будет готов позже,
    # чем если бы озвучивался один. Поэтому пачку запускаем только ПОСЛЕ него.
    first_deadline = time.time() + 1800
    while queue:
        script_path, output_path = queue.pop(0)
        if not submit(script_path, output_path):
            continue          # не поставилась — берём следующий как первый
        while pending and time.time() < first_deadline:
            if collect(next(iter(pending))):
                break
            time.sleep(BaseTTSClient.POLL_INTERVAL)
        break

    if not queue:
        return results

    # ОСТАЛЬНЫЕ — пачкой в фоне: монтаж уже идёт по первому сценарию, и к
    # моменту, когда он попросит следующий, тот обычно уже готов.
    window = max(1, int(getattr(config, 'TTS_BATCH_PARALLEL', 2)))
    log(f"   ▸ Первый готов — ставлю остальные ({len(queue)}), окно {window}")

    deadline = time.time() + max(900, 240 * len(queue))
    while (queue or pending) and time.time() < deadline:
        while queue and len(pending) < window:
            script_path, output_path = queue.pop(0)
            submit(script_path, output_path)
        for task_id in list(pending):
            collect(task_id)
        if queue or pending:
            time.sleep(BaseTTSClient.POLL_INTERVAL)

    for task_id, (script_path, _o) in pending.items():
        log(f"   ✗ {Path(script_path).name}: не дождались готовности")
    return results


def run_tts(script_path: Path, output_path: Path, service: str = None) -> Path:
    """
    Высокоуровневая функция: читает файл сценария → генерирует аудио → возвращает путь.

    Args:
        script_path:  путь к .txt файлу с текстом сценария
        output_path:  желаемый путь к выходному файлу (расширение может измениться)
        service:      'csv666' | 'mat3u' | None (из .env)

    Returns:
        Путь к скачанному аудиофайлу
    """
    # Единая точка чтения: голос берётся только из GUI/пресета.
    voice_id, text = read_script_for_tts(script_path)
    source = "GUI/пресет"

    print(f"\n🎙️  TTS: {script_path.name}")
    print(f"   Сервис:   {service or config.TTS_SERVICE}")

    client = get_tts_client(service)

    # Что именно выбрал человек. Раньше печаталось только `Voice ID: <uuid>`, а
    # у Lumean это UUID ШАБЛОНА, не голоса — по логу нельзя было понять, каким
    # голосом озвучено (улов 01.09.2026). Описание достаём у того клиента, кто
    # умеет; остальные печатают строку как раньше.
    described = False
    describe = getattr(client, 'describe_template', None)
    if callable(describe):
        info = describe(voice_id) or {}
        if info.get('template_name'):
            print(f"   Шаблон:   {info['template_name']}  ({voice_id})")
            described = True
        engine_line = ', '.join(x for x in (info.get('engine'), info.get('model')) if x)
        if engine_line:
            print(f"   Движок:   {engine_line}")
        if info.get('voice_id'):
            print(f"   Голос:    {info['voice_id']}")
    if not described:
        print(f"   Voice ID: {voice_id}  ({source})")
    print(f"   Символов: {len(text)}")

    return client.synthesize(text, voice_id, output_path)
