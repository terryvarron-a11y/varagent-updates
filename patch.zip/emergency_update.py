#!/usr/bin/env python3
"""
Emergency updater для VARAGENT — обходит SSL ошибку в старом updater.py
Использует только стандартную библиотеку Python 3.x
"""
import urllib.request
import urllib.error
import ssl
import zipfile
import io
import json
from pathlib import Path
import sys
import hashlib

GITHUB_REPO = 'terryvarron-a11y/varagent-updates'
PATCH_URL = f'https://raw.githubusercontent.com/{GITHUB_REPO}/main/patch.zip'
VERSION_URL = f'https://raw.githubusercontent.com/{GITHUB_REPO}/main/version.json'
SKIP_ON_INSTALL = {'projects/', '.env', 'agent/.env', 'publisher.py'}


def create_ssl_context():
    """Создает SSL context с отключенной проверкой."""
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    except Exception:
        return ssl._create_unverified_context()


def fetch(url, timeout=30):
    """Скачивает данные по URL."""
    ctx = create_ssl_context()
    req = urllib.request.Request(url, headers={'User-Agent': 'varagent-emergency-updater'})
    try:
        response = urllib.request.urlopen(req, timeout=timeout, context=ctx)
        return response.read()
    except urllib.error.URLError as e:
        print(f"Ошибка загрузки {url}: {e}")
        sys.exit(1)


def main():
    print("=" * 60)
    print(" VARAGENT Emergency Update")
    print("=" * 60)
    print()
    print("Этот скрипт обходит SSL ошибку в старом updater.py")
    print("и устанавливает последнее обновление напрямую с GitHub.")
    print()

    root = Path(__file__).parent

    # Получаем version.json
    print("[1/4] Загрузка version.json...")
    try:
        version_data = json.loads(fetch(VERSION_URL))
        version = version_data.get('version', 'unknown')
        print(f"      Доступная версия: {version}")
    except Exception as e:
        print(f"      Предупреждение: не удалось загрузить version.json ({e})")
        version = 'unknown'

    print()

    # Скачиваем patch.zip
    print("[2/4] Загрузка patch.zip...")
    patch_bytes = fetch(PATCH_URL, timeout=120)
    print(f"      Скачано {len(patch_bytes)} байт")
    print()

    # Устанавливаем файлы
    print("[3/4] Установка файлов...")
    installed = []
    with zipfile.ZipFile(io.BytesIO(patch_bytes)) as zf:
        for name in zf.namelist():
            # Пропускаем защищённые пути
            if any(name.startswith(s) for s in SKIP_ON_INSTALL):
                continue
            dest = root / Path(name)
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(zf.read(name))
            installed.append(name)
            if len(installed) % 20 == 0:
                print(f"      Установлено {len(installed)} файлов...")

    print(f"      Готово. Установлено файлов: {len(installed)}")
    print()

    # Очистка __pycache__
    print("[4/4] Очистка кеша Python...")
    import shutil
    cache_count = 0
    for cache_dir in root.rglob('__pycache__'):
        try:
            shutil.rmtree(cache_dir)
            cache_count += 1
        except Exception:
            pass
    print(f"      Удалено {cache_count} __pycache__ директорий")
    print()

    print("=" * 60)
    print(f"✓ Обновление установлено: {version}")
    print("=" * 60)
    print()
    print("Теперь можно использовать обычный updater.")
    print("Перезапустите VARAGENT.")
    print()

    # Установка certifi для будущих обновлений
    print("Установка certifi для надёжной работы updater...")
    try:
        import subprocess
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'certifi', '--quiet'])
        print("✓ certifi установлен")
    except Exception as e:
        print(f"⚠ Не удалось установить certifi: {e}")
        print("  Вы можете установить вручную: pip install certifi")

    print()
    input("Нажмите Enter для выхода...")


if __name__ == '__main__':
    main()
