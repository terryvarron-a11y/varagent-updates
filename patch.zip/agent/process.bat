@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

REM ============================================================================
REM PROCESS.BAT - Пост-обработка видео после генерации в Veo3
REM ============================================================================
REM
REM ЭТОТ ФАЙЛ ЗАПУСКАЕТСЯ ПОСЛЕ ТОГО КАК:
REM 1. Вы сгенерировали видео в Veo3 по prompts.txt
REM 2. Скачали все видеофайлы в папку проекта
REM
REM ЧТО ДЕЛАЕТ ЭТОТ СКРИПТ:
REM 1. Переименовывает veo3_generation_*.mp4 / veo3_*.mp4 → 1.mp4, 2.mp4, ...
REM 2. ПРОВЕРЯЕТ наличие всех фрагментов по montage_plan.json
REM 3. При отсутствии - выводит промпт недостающего фрагмента
REM 4. Запускает video_concat.py для склейки (если все файлы на месте)
REM 5. Очищает временные файлы (опционально)
REM
REM ПОДДЕРЖИВАЕМЫЕ ФОРМАТЫ ИСХОДНЫХ ФАЙЛОВ:
REM - veo3_generation_*.mp4 / .mov
REM - veo3_*.mp4 / .mov
REM - scene_*.mp4 / .mov
REM - fragment_*.mp4 / .mov
REM ============================================================================

echo.
echo ================================================================================
REM ОБРАБОТКА ВИДЕОПРОЕКТА
echo ================================================================================
echo.

REM ============================================================================
REM ПАРАМЕТРЫ (РЕДАКТИРУЙ ЗДЕСЬ)
REM ============================================================================

REM Разрешение финального видео (если требуется перекодирование)
set RESOLUTION=1920x1080

REM Битрейт видео
set BITRATE=10M

REM GPU режим:
REM   --force-amd    = Принудительно AMD GPU
REM   --no-gpu       = Использовать CPU
REM   (пусто)        = Автоопределение (NVIDIA → AMD → CPU)
set GPU_MODE=--force-amd

REM Кодирование:
REM   true  = С перекодированием (медленнее, но лучше контроль качества)
REM   false = Без перекодирования (быстрее, stream copy)
set ENCODE=true

REM Размер группы для склейки (оптимизация для больших проектов)
set GROUP_SIZE=50

echo Параметры обработки:
echo   Разрешение:    %RESOLUTION%
echo   Битрейт:       %BITRATE%
echo   GPU режим:     %GPU_MODE%
echo   Кодирование:   %ENCODE%
echo   Размер группы: %GROUP_SIZE%
echo.

REM ============================================================================
REM ПРОВЕРКА ФАЙЛОВ
REM ============================================================================

echo [0/6] Проверка файлов...

if not exist "montage_plan.json" (
    echo.
    echo ❌ ОШИБКА: montage_plan.json не найден!
    echo    Запустите сначала: agent run --audio narration.wav --style style_guide.txt
    echo.
    pause
    exit /b 1
)

if not exist "narration.wav" (
    echo.
    echo ❌ ОШИБКА: narration.wav не найден!
    echo.
    pause
    exit /b 1
)

if not exist "prompts.txt" (
    echo.
    echo ⚠️  prompts.txt не найден (не критично, но не будет вывода промптов)
)

echo.

REM ============================================================================
REM ШАГ 1: ПЕРЕИМЕНОВАНИЕ ВИДЕО
REM ============================================================================

echo [1/6] Переименование видеофайлов...
echo.

REM Проверка: есть ли файлы для переименования (поддержка разных форматов)
set VEO_COUNT=0
for %%f in (veo3_generation_*.mp4 veo3_generation_*.mov veo3_*.mp4 veo3_*.mov scene_*.mp4 scene_*.mov fragment_*.mp4 fragment_*.mov) do (
    set /a VEO_COUNT+=1
)

if %VEO_COUNT% GTR 0 (
    REM Запуск переименования
    if exist "rename_videos.py" (
        echo    Найдено файлов Veo3: %VEO_COUNT%
        echo.
        echo    Предпросмотр переименования...
        python "rename_videos.py" --dry-run
        if errorlevel 1 (
            echo.
            echo ❌ ОШИБКА предпросмотра переименования!
            pause
            exit /b 1
        )

        echo.
        echo    Предпросмотр успешен. Выполняю переименование...
        python "rename_videos.py"
        if errorlevel 1 (
            echo.
            echo ❌ ОШИБКА переименования!
            pause
            exit /b 1
        )

        echo    ✅ Переименование завершено
    ) else (
        echo    ❌ rename_videos.py не найден в папке проекта!
        echo       Скрипт должен находиться в той же папке что и process.bat
        pause
        exit /b 1
    )
) else (
    echo    ℹ️  Файлы Veo3 не найдены (возможно уже переименованы)
    echo    ℹ️  Проверка наличия переименованных файлов...
    
    set RENAMED_COUNT=0
    for %%f in (1.mp4 2.mp4 3.mp4 4.mp4 5.mp4 6.mp4 7.mp4 8.mp4 9.mp4 10.mp4) do (
        if exist "%%f" set /a RENAMED_COUNT+=1
    )
    
    if !RENAMED_COUNT! GTR 0 (
        echo    ✅ Найдено переименованных файлов: !RENAMED_COUNT!
    ) else (
        echo    ⚠️  Не найдено ни файлов Veo3, ни переименованных файлов
    )
)

echo.

REM ============================================================================
REM ШАГ 2: ЧТЕНИЕ MONTAGE_PLAN.JSON
REM ============================================================================

echo [2/6] Чтение монтажного плана...
echo.

REM Используем Python для парсинга JSON
python -c "import json; data=json.load(open('montage_plan.json')); clips=[str(c['id']) for c in data['clips']]; print(','.join(clips)); print(clips[-1])" > temp_clip_ids.txt

set /p CLIP_IDS=<temp_clip_ids.txt
set /p LAST_CLIP_ID=<temp_clip_ids.txt

REM Получаем последний ID клипа
for /f "tokens=2 delims=," %%a in ("%CLIP_IDS%") do set LAST_CLIP_ID=%%a

REM Подсчитываем количество клипов
set CLIP_COUNT=0
for %%i in (%CLIP_IDS%) do set /a CLIP_COUNT+=1

echo    Найдено клипов в montage_plan.json: %CLIP_COUNT%
echo    Диапазон ID: 1 - %LAST_CLIP_ID%

del temp_clip_ids.txt

echo.

REM ============================================================================
REM ШАГ 3: ПРОВЕРКА НАЛИЧИЯ ВСЕХ ФРАГМЕНТОВ
REM ============================================================================

echo [3/6] Проверка наличия видеофрагментов...
echo.

set MISSING_COUNT=0
set MISSING_IDS=

REM Проверяем каждый файл от 1 до LAST_CLIP_ID
for /L %%i in (1,1,%LAST_CLIP_ID%) do (
    if not exist "%%i.mp4" (
        set /a MISSING_COUNT+=1
        set MISSING_IDS=!MISSING_IDS! %%i
    )
)

if %MISSING_COUNT% GTR 0 (
    echo.
    echo ❌ ОБНАРУЖЕНЫ ОТСУТСТВУЮЩИЕ ФРАГМЕНТЫ: %MISSING_IDS%
    echo.
    echo    Найдено: %MISSING_COUNT% из %LAST_CLIP_ID%
    echo.

    REM ============================================================================
    REM ШАГ 3.5: ВЫВОД ПРОМПТОВ ДЛЯ ОТСУТСТВУЮЩИХ ФРАГМЕНТОВ
    REM ============================================================================

    if exist "prompts.txt" (
        echo ================================================================================
        echo 📋 ПРОМПТЫ ДЛЯ ОТСУТСТВУЮЩИХ ФРАГМЕНТОВ
        echo ================================================================================
        echo.
        echo 💡  Скопируйте эти промпты в Veo3 для генерации недостающих фрагментов
        echo.

        for %%i in (%MISSING_IDS%) do (
            echo ================================================================================
            echo ФРАГМЕНТ #%%i ^(ОТСУТСТВУЕТ^)
            echo ================================================================================
            echo.

            REM Извлекаем промпт для конкретного фрагмента
            if exist "extract_prompt.py" (
                python extract_prompt.py %%i
            ) else (
                echo ⚠️  extract_prompt.py не найден, открывайте prompts.txt вручную
            )

            echo.
        )

        echo ================================================================================
        echo.
        echo 🔄 СЛЕДУЮЩИЕ ДЕЙСТВИЯ:
        echo    1. Скопируйте промпты выше
        echo    2. Сгенерируйте недостающие фрагменты в Veo3
        echo    3. Скачайте файлы в эту папку
        echo    4. Запустите process.bat повторно
        echo.
    ) else (
        echo ⚠️  prompts.txt не найден!
        echo    Откройте prompts.txt и найдите промпты для фрагментов:%MISSING_IDS%
        echo.
    )

    pause
    exit /b 1
)

echo    ✅ Все фрагменты на месте (%LAST_CLIP_ID% из %LAST_CLIP_ID%)
echo.

REM ============================================================================
REM ШАГ 4: ВАЛИДАЦИЯ МОНТАЖНОГО ПЛАНА
REM ============================================================================

echo [4/6] Валидация монтажного плана...
echo.

if exist "..\agent\agent.py" (
    python "..\agent\agent.py" validate --montage-plan montage_plan.json
    if errorlevel 1 (
        echo.
        echo ❌ ОШИБКА валидации montage_plan.json!
        echo    Проверьте файл вручную.
        echo.
        pause
        exit /b 1
    )
    echo    ✅ Валидация пройдена
) else (
    echo    ℹ️  agent.py не найден, пропускаю валидацию...
)

echo.

REM ============================================================================
REM ШАГ 5: СКЛЕЙКА ВИДЕО
REM ============================================================================

echo [5/6] Склейка видео...
echo.

REM Определение пути к video_concat.py
if exist "..\0_video_concat_groups_v5_FAST_TRIM.py" (
    set CONCAT_SCRIPT=..\0_video_concat_groups_v5_FAST_TRIM.py
) else if exist "..\video_concat.py" (
    set CONCAT_SCRIPT=..\video_concat.py
) else (
    echo.
    echo ❌ ОШИБКА: video_concat.py не найден!
    echo.
    pause
    exit /b 1
)

echo    Скрипт склейки: %CONCAT_SCRIPT%
echo.

REM Формирование команды
set CONCAT_CMD=python "%CONCAT_SCRIPT%" montage_plan.json -o result.mp4 -b %BITRATE% -g %GROUP_SIZE% %GPU_MODE%

if "%ENCODE%"=="false" (
    set CONCAT_CMD=!CONCAT_CMD! --no-encode
)

echo    Команда: !CONCAT_CMD!
echo.

REM Запуск склейки
!CONCAT_CMD!

if errorlevel 1 (
    echo.
    echo ❌ ОШИБКА склейки!
    echo    Проверьте лог-файл video_concat_*.log
    echo.
    pause
    exit /b 1
)

echo    ✅ Склейка завершена

echo.

REM ============================================================================
REM ШАГ 6: ПРОВЕРКА РЕЗУЛЬТАТА
REM ============================================================================

echo [6/6] Проверка результата...
echo.

if exist "result.mp4" (
    for %%A in ("result.mp4") do set RESULT_SIZE=%%~zA
    set /a RESULT_SIZE_MB=!RESULT_SIZE! / 1024 / 1024
    
    echo    ✅ result.mp4 создан
    echo       Размер: !RESULT_SIZE_MB! MB
) else (
    echo    ❌ ОШИБКА: result.mp4 не создан!
    echo.
    pause
    exit /b 1
)

if exist "result_original_audio.wav" (
    echo    ✅ result_original_audio.wav создан
)

echo.

REM ============================================================================
REM ФИНАЛ
REM ============================================================================

echo ================================================================================
echo ✅ ГОТОВО!
echo ================================================================================
echo.
echo 📹 Финальное видео: result.mp4
echo 🔊 Оригинальное аудио: result_original_audio.wav
echo.
echo СЛЕДУЮЩИЕ ШАГИ:
echo   • Откройте result.mp4 и проверьте качество
echo   • При необходимости выполните цветокоррекцию в видеоредакторе
echo   • Опубликуйте видео
echo.
echo ================================================================================
pause
