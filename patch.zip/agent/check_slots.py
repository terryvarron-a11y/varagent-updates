"""Quick check: VeoNonStop account slots for key1 and key2 (if set)."""
import os
import sys
import requests
from pathlib import Path
from dotenv import load_dotenv

env_path = Path(__file__).resolve().parent / '.env'
load_dotenv(env_path)


def query_key(api_key: str, label: str):
    try:
        resp = requests.get(
            'https://veononstop.org/api/v1/account/info',
            headers={'X-API-Key': api_key},
            timeout=10,
        )
        if resp.status_code == 200:
            data = resp.json().get('data', resp.json())
            ct   = int(data.get('concurrent_tasks', data.get('max_cookies', 0)))
            plan = data.get('plan', '?')
            return ct, plan
        else:
            return 0, f'http_{resp.status_code}'
    except Exception as e:
        return 0, f'err'


keys = [
    ('key1', os.getenv('VEONONSTOP_API_KEY', ''),   os.getenv('VEONONSTOP_KEY1_NAME', 'Key1')),
    ('key2', os.getenv('VEONONSTOP_API_KEY_2', ''),  os.getenv('VEONONSTOP_KEY2_NAME', 'Key2')),
    ('key3', os.getenv('VEONONSTOP_API_KEY_3', ''),  os.getenv('VEONONSTOP_KEY3_NAME', 'Key3')),
    ('key4', os.getenv('VEONONSTOP_API_KEY_4', ''),  os.getenv('VEONONSTOP_KEY4_NAME', 'Key4')),
]

if not keys[0][1]:
    print('  [!] VEONONSTOP_API_KEY not set')
    for tag, _, _ in keys:
        print(f'{tag}=0')
    print('total=0')
    sys.exit(0)

total = 0
slots = {}
for tag, api_key, label in keys:
    if api_key:
        ct, plan = query_key(api_key, label)
        total += ct
        slots[tag] = ct
        print(f'  {label}: {ct} concurrent tasks  ({plan})')
    else:
        slots[tag] = 0

if sum(1 for t, a, _ in keys if a) > 1:
    print(f'  ------------------------------------')
    print(f'  Total: {total} concurrent tasks')

# Machine-readable lines for bat parsing
for tag, _, _ in keys:
    print(f'{tag}={slots[tag]}')
print(f'total={total}')
