# pipeline.bat — Full Automated Pipeline

## Pipeline Flow

```
                    pipeline.bat
                        |
            +-----------+-----------+
            |                       |
     [1] From script          [2] From audio
            |                       |
     +------+------+               |
     |  STAGE 0    |               |
     |  TTS        |               |
     |  script.txt |               |
     |  -> audio   |               |
     +------+------+               |
            |                       |
            +----------+------------+
                       |
                +------+------+
                |  STAGE 1    |
                |  Transcript |
                |  AssemblyAI |
                |  audio->txt |
                +------+------+
                       |
                +------+------+
                |  STAGE 1    |
                |  Direction  |
                |  Gemini     |
                |  montage    |
                |  plan +     |
                |  prompts    |
                +------+------+
                       |
            +----------+-----------+
            |                      |
     FastGen / VeoNonStop      Skip (t2v)
            |                      |
     +------+------+              |
     |  STAGE 3    |              |
     |  Image Gen  |              |
     |  -> generated/             |
     +------+------+              |
            |                      |
            +----------+-----------+
                       |
                +------+------+
                |  STAGE 3.5  |
                |  Video Gen  |
                |  VeoNonStop |
                |  i2v / t2v  |
                |  -> vid_img/|
                +------+------+
                       |
                +------+------+
                |  STAGE 2    |
                |  Auto       |
                |  Concat     |
                |  FFmpeg     |
                |  -> .mp4    |
                +------+------+
                       |
                    [DONE]
```

## UX: Guided Setup with Defaults

Each settings block uses a **one-line defaults summary** pattern:

```
--- TRANSCRIPTION + DIRECTION ---
Defaults: lang=ru  mode=1-pass  clips=video  duration=4-8s
Accept? [Enter=yes / c=change]:
```

- **Enter** = accept entire block, move on
- **c** = expand full questionnaire for each parameter

Minimum keypresses for default run: **4 Enters** (start + T&D + video + confirm).

## Settings Blocks

### 1. Start Point
```
[1] From script (.txt in pipeline_queue) — TTS then pipeline
[2] From audio  (.mp3/.wav in pipeline_queue) — skip TTS
```

### 2. TTS (only if start = script)
```
Defaults: service=mat3u  model=eleven_multilingual_v2  split=smart
[Enter=accept / c=change]

  Expanded:
  - TTS service: mat3u / csv666
  - Model: eleven_multilingual_v2 / v3 / turbo / flash
  - Split type: smart / sentences / paragraphs / max_length
```

### 3. Transcription + Direction
```
Defaults: lang=ru  mode=1-pass  clips=video  duration=4-8s
[Enter=accept / c=change]

  Expanded:
  - Language: ru / en / es / de / fr / it / pt / zh / pl
  - Direction mode: 1-pass (fast) / 2-pass (chunked, 200+ clips)
  - Clip type: video (Veo3) / slideshow (static images)
  - Duration: min-max seconds
```

### 4. Image Generation
```
[1] FastGen    (Gemini/GemPix/Grok/Narwhal)
[2] VeoNonStop (Imagen/Banana)
[3] Skip       (for text-to-video mode)

  If FastGen selected:
  Defaults: model=GEMINI  aspect=landscape  parallel=10
  [Enter=accept / c=change]

    Expanded:
    - Model: GEMINI / GEM_PIX_2 / GEM_PIX / GROK / NARWHAL / IMAGEN_3_5
    - Aspect: landscape / portrait / square
    - Parallel workers
```

### 5. Video Generation
```
  If images selected → auto i2v (animate images)
  If skip images:
    [1] Text-to-video (t2v)
    [2] Text-to-video + references (t2v + ref/)

  Defaults: ratio=16:9  parallel=4
  [Enter=accept / c=change]

    Expanded:
    - Aspect ratio: 16:9 / 9:16 / 1:1
    - Parallel workers
```

### 6. Summary + Confirm
```
================================================================================
 PIPELINE SUMMARY
================================================================================

 Start:       From audio (skip TTS)
 Language:    ru
 Direction:   1-pass
 Clips:       video (4-8s)
 Image gen:   FastGen (GEMINI, landscape, x10)
 Video gen:   FastGen images + i2v (ratio=16:9, x4)
 Auto concat: yes

================================================================================
 Start pipeline? [Enter=yes / n=cancel]:
```

## Output Structure (per project)

```
projects/
  FLOW_projectname_20260313_143022/
    montage_plan.json        — montage plan (clips, timing, metadata)
    *_prompts_*.txt          — image/video prompts
    transcription.json       — raw transcription
    generated/               — generated images (stage 3)
      001.png, 002.png ...
    vid_img/                 — video fragments (stage 3.5)
      001.mp4, 002.mp4 ...
    projectname.mp4          — FINAL VIDEO (auto-concat)
    VEO_AUDIO.wav            — original audio
```

## Post-Action Mapping

| Image Gen | Video Gen | post-action value |
|-----------|-----------|-------------------|
| FastGen   | i2v       | `fastgen_i2v`     |
| VeoNonStop| i2v       | `veo_i2v`         |
| Skip      | t2v       | `t2v`             |
| Skip      | t2v+refs  | `components`      |

## Environment Override

pipeline.bat sets OS environment variables before calling Python.
Since `python-dotenv` does NOT override existing env vars,
bat-set values take precedence over `.env` file defaults.
