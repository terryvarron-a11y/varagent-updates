# -*- coding: utf-8 -*-
"""Установка и обновление YouTube-модуля: yt-dlp + JavaScript-рантайм.

Зачем это отдельной кнопкой
---------------------------
1. `yt-dlp.exe` НЕ едет с обновлениями софта — он исключён из патча как крупный
   бинарник (`publisher.EXCLUDE_NAMES`). У пользователя остаётся файл из
   первоначального дистрибутива, а ютуб ломает совместимость каждые пару
   месяцев: старый yt-dlp отвечает 403 и стадия молча даёт ноль роликов.

2. Свежий yt-dlp требует JavaScript-рантайм. Без него он пишет:
   «No supported JavaScript runtime could be found … YouTube extraction without
   a JS runtime has been deprecated, and some formats may be missing» — часть
   форматов пропадает, ссылки на поток не проходят проверку подписи, и это ещё
   один источник 403. Проверено 29.08: на машине разработчика стоял Node, и
   потому всё работало; у пользователей рантайма нет вовсе.

Что ставим и почему deno, а не Node
-----------------------------------
yt-dlp по умолчанию ищет ТОЛЬКО deno: `JS Challenge Providers: bun
(unavailable), deno (unavailable), node (unavailable)`. Установленный Node он
берёт лишь при явном `--js-runtimes node`. Поэтому:

  • есть deno (системный или наш) → ничего не качаем, yt-dlp найдёт его сам;
  • есть Node → качать не нужно, добавляем флаг `--js-runtimes node:путь`;
  • нет ничего → качаем deno, один файл, кладём в `agent/tools/`.

Так пользователю не нужно ставить Node руками, а системный Node не пропадает
зря.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import zipfile
from pathlib import Path
from typing import Callable, Optional

import urllib.request

YTDLP_URL = "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe"
DENO_API = "https://api.github.com/repos/denoland/deno/releases/latest"
DENO_ASSET = "deno-x86_64-pc-windows-msvc.zip"

ROOT = Path(__file__).resolve().parents[2]      # папка софта
TOOLS_DIR = Path(__file__).resolve().parent      # agent/tools
_UA = {"User-Agent": "varagent-youtube-setup/1.0"}
_NO_WINDOW = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}


def ytdlp_path() -> Path:
    """Куда кладём и откуда берём yt-dlp — корень софта, как и раньше."""
    return ROOT / "yt-dlp.exe"


def bundled_deno() -> Path:
    return TOOLS_DIR / ("deno.exe" if os.name == "nt" else "deno")


def _version_of(executable: str | Path) -> str:
    try:
        done = subprocess.run([str(executable), "--version"], capture_output=True,
                              text=True, timeout=30, **_NO_WINDOW)
        return (done.stdout or "").strip().splitlines()[0].strip()
    except Exception:                                          # noqa: BLE001
        return ""


def find_js_runtime() -> tuple[str, str]:
    """(вид, путь) первого доступного рантайма или ('', '').

    Порядок: наш deno → системный deno → системный Node. Наш первый, потому что
    он заведомо совместим и не зависит от того, что пользователь поставил.
    """
    local = bundled_deno()
    if local.is_file():
        return "deno", str(local)
    for kind in ("deno", "node"):
        found = shutil.which(kind)
        if found:
            return kind, found
    return "", ""


def js_runtime_args() -> list[str]:
    """Аргументы yt-dlp для JS-рантайма. Пусто — если добавлять нечего.

    Для deno флаг не нужен (yt-dlp включает его по умолчанию), но путь всё же
    передаём, когда deno наш: иначе он не в PATH и не будет найден.
    """
    kind, path = find_js_runtime()
    if not kind:
        return []
    if kind == "deno" and path == str(bundled_deno()):
        return ["--js-runtimes", f"deno:{path}"]
    if kind == "deno":
        return []                                  # системный deno найдётся сам
    return ["--js-runtimes", f"node:{path}"]       # Node только явным флагом


def status() -> dict:
    """Что сейчас установлено — для интерфейса и логов."""
    ytdlp = ytdlp_path()
    kind, path = find_js_runtime()
    return {
        "ytdlp_path": str(ytdlp),
        "ytdlp_exists": ytdlp.is_file(),
        "ytdlp_version": _version_of(ytdlp) if ytdlp.is_file() else "",
        "runtime_kind": kind,
        "runtime_path": path,
        "runtime_version": _version_of(path) if path else "",
    }


def _download(url: str, target: Path, progress: Callable[[str], None],
              label: str) -> None:
    """Скачать во временный файл и заменить одним движением.

    Пишем рядом и переименовываем: оборванная закачка не должна оставить
    покалеченный yt-dlp.exe вместо рабочего.
    """
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(target.suffix + ".part")
    request = urllib.request.Request(url, headers=_UA)
    with urllib.request.urlopen(request, timeout=120) as response:
        total = int(response.headers.get("Content-Length") or 0)
        done = 0
        step = max(1, total // 10) if total else 0
        next_mark = step
        with tmp.open("wb") as handle:
            while True:
                chunk = response.read(512 * 1024)
                if not chunk:
                    break
                handle.write(chunk)
                done += len(chunk)
                if step and done >= next_mark:
                    progress(f"   {label}: {done / 1024 / 1024:.0f} из "
                             f"{total / 1024 / 1024:.0f} МБ")
                    next_mark += step
    if target.exists():
        target.unlink()
    tmp.replace(target)


def install(progress: Optional[Callable[[str], None]] = None) -> dict:
    """Поставить свежий yt-dlp и, если нужно, JS-рантайм.

    Возвращает тот же словарь, что `status()`, — уже после установки.
    """
    say = progress or (lambda _message: None)
    say("YouTube-модуль: скачиваю свежий yt-dlp…")
    try:
        _download(YTDLP_URL, ytdlp_path(), say, "yt-dlp")
        say(f"   yt-dlp обновлён: {_version_of(ytdlp_path()) or 'версия не определилась'}")
    except Exception as exc:                                   # noqa: BLE001
        say(f"   yt-dlp скачать не вышло: {type(exc).__name__}: {exc}")

    kind, path = find_js_runtime()
    if kind:
        say(f"   JavaScript-рантайм уже есть: {kind} ({_version_of(path) or path})")
    else:
        say("YouTube-модуль: рантайма нет, скачиваю deno (~40 МБ)…")
        try:
            import json

            request = urllib.request.Request(DENO_API, headers=_UA)
            with urllib.request.urlopen(request, timeout=60) as response:
                release = json.load(response)
            asset = next((a for a in release.get("assets", [])
                          if a.get("name") == DENO_ASSET), None)
            if asset is None:
                raise RuntimeError(f"в релизе {release.get('tag_name')} нет {DENO_ASSET}")
            archive = TOOLS_DIR / DENO_ASSET
            _download(asset["browser_download_url"], archive, say, "deno")
            with zipfile.ZipFile(archive) as zf:
                names = [n for n in zf.namelist() if n.lower().endswith("deno.exe")]
                if not names:
                    raise RuntimeError("в архиве deno нет deno.exe")
                with zf.open(names[0]) as src, bundled_deno().open("wb") as dst:
                    shutil.copyfileobj(src, dst)
            archive.unlink(missing_ok=True)
            say(f"   deno установлен: {_version_of(bundled_deno()) or bundled_deno()}")
        except Exception as exc:                               # noqa: BLE001
            say(f"   deno поставить не вышло: {type(exc).__name__}: {exc}")

    final = status()
    if final["ytdlp_exists"] and final["runtime_kind"]:
        say("YouTube-модуль готов: yt-dlp %s + %s" % (
            final["ytdlp_version"] or "?", final["runtime_kind"]))
    else:
        say("YouTube-модуль установлен НЕ полностью — смотри сообщения выше")
    return final


if __name__ == "__main__":
    install(progress=print)
