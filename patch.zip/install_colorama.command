#!/bin/bash
cd "$(dirname "${BASH_SOURCE[0]}")"

echo ""
echo "Installing colorama..."
pip3 install colorama
echo ""
echo "Done. Press Enter to close."
read
