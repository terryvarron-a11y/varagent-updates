Codex CLI — needed for GPT Director mode
=========================================

WINDOWS:
  1. Download: https://github.com/openai/codex/releases
  2. Pick: codex-x86_64-pc-windows-msvc.exe
  3. Put the .exe file into THIS folder (Codex/)

MAC:
  1. Install via Homebrew:
     brew install openai/tap/codex
  2. Find the binary path:
     which codex
  3. Copy or symlink it into THIS folder (Codex/), or set
     CODEX_EXE_PATH in agent/.env to the full path, e.g.:
     CODEX_EXE_PATH=/opt/homebrew/bin/codex

After setup, restart VARAGENT and press "Codex Login (browser)".
