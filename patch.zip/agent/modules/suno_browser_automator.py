"""
Browser-driven Suno generation.

This mode avoids the brittle browser-cookie HTTP Create call. A real browser
opens suno.com/create, the user logs in once in the persistent Playwright
profile, and the script drives the visible UI. It does not solve or bypass
captchas; if Suno asks for a manual challenge, the user must complete it.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests


STUDIO_BASE = "https://studio-api-prod.suno.com"
CREATE_URL = "https://suno.com/create"


class SunoBrowserError(RuntimeError):
    pass


class SunoBrowserAutomator:
    def __init__(
        self,
        project_dir: str | Path,
        *,
        profile_dir: str | Path | None = None,
        headless: bool = False,
        slow_mo_ms: int = 80,
        browser: str = "chromium",
    ):
        self.project_dir = Path(project_dir).resolve()
        self.plan_path = self.project_dir / "music_plan.json"
        self.music_dir = self.project_dir / "music"
        self.music_raw_dir = self.music_dir / "raw"
        self.profile_dir = Path(profile_dir) if profile_dir else (
            Path(__file__).resolve().parents[1] / "temp" / "suno_browser_profile"
        )
        self.headless = headless
        self.slow_mo_ms = slow_mo_ms
        self.browser = browser
        self._playwright = None
        self._context = None
        self._page = None

        self.music_dir.mkdir(parents=True, exist_ok=True)
        self.music_raw_dir.mkdir(parents=True, exist_ok=True)
        self.profile_dir.mkdir(parents=True, exist_ok=True)

    def close(self) -> None:
        try:
            if self._context:
                try:
                    self._context.close()
                except Exception as exc:
                    print(f"Warning: failed to close Playwright context cleanly: {exc}")
        finally:
            self._context = None
            self._page = None
            if self._playwright:
                try:
                    self._playwright.stop()
                except Exception as exc:
                    print(f"Warning: failed to stop Playwright cleanly: {exc}")
                self._playwright = None

    def login(self, timeout_sec: int = 300) -> None:
        page = self._page_or_start()
        page.goto(CREATE_URL, wait_until="domcontentloaded", timeout=90000)
        print(f"Opened Suno browser profile: {self.profile_dir}")
        print("If Suno asks for login or verification, complete it in the browser window.")
        if self._wait_for_create_ui(page, timeout_sec=timeout_sec):
            print("Suno create UI detected.")
            return
        raise SunoBrowserError(
            "Suno create UI was not detected. Log in/complete verification in the opened browser, "
            "then run the command again."
        )

    def generate_all(
        self,
        *,
        force: bool = False,
        max_tracks: Optional[int] = None,
        login_timeout_sec: int = 300,
    ) -> Dict[str, int]:
        plan = self._load_plan()
        tracks = [
            t for t in plan.get("tracks", [])
            if (t.get("genre") or "").lower() != "silence"
            and (t.get("prompt") or "").strip()
        ]
        if max_tracks:
            tracks = tracks[:max_tracks]

        page = self._page_or_start()
        page.goto(CREATE_URL, wait_until="domcontentloaded", timeout=90000)
        if not self._wait_for_create_ui(page, timeout_sec=login_timeout_sec):
            raise SunoBrowserError(
                "Suno create UI was not detected. Finish login/verification in the browser and retry."
            )

        ok = skipped = failed = 0
        for idx, track in enumerate(tracks, 1):
            tid = int(track.get("id") or idx)
            target = self.music_dir / f"{tid}.mp3"
            has_suno_audio = bool(track.get("suno_clip_ids")) and not track.get("fallback")
            if target.exists() and not force and has_suno_audio:
                print(f"[{idx}/{len(tracks)}] Track {tid}: exists - skip")
                skipped += 1
                continue

            prompt = _build_browser_prompt(track)
            print(f"\n[{idx}/{len(tracks)}] Track {tid}: Suno browser Create")
            print(f"   Prompt: {prompt[:140]}")
            try:
                clip_ids, auth_headers = self._create_from_ui(page, prompt)
                print(f"   Created clips: {', '.join(cid[:8] for cid in clip_ids)}")
                clips = self._wait_for_clips(clip_ids, auth_headers)
                target_sec = _track_target_duration(track)
                durations, selected_variant = self._download_variants(tid, clips, target_sec=target_sec)
                track["suno_clip_ids"] = clip_ids
                track["suno_durations"] = durations
                track["selected_variant"] = selected_variant
                track["file"] = f"{tid}.mp3"
                track.pop("fallback", None)
                ok += 1
                self._save_plan(plan)
            except Exception as exc:
                failed += 1
                print(f"   FAILED: {exc}")
                # Stop on the first failure to avoid burning attempts/rate-limit.
                break

        self._save_plan(plan)
        return {"ok": ok, "skipped": skipped, "failed": failed, "total": len(tracks)}

    def _page_or_start(self):
        if self._page:
            return self._page
        try:
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            raise SunoBrowserError(
                "Playwright is not installed. Run: python -m pip install playwright && "
                "python -m playwright install chromium"
            ) from exc

        self._playwright = sync_playwright().start()
        launcher = getattr(self._playwright, self.browser)
        self._context = launcher.launch_persistent_context(
            user_data_dir=str(self.profile_dir),
            headless=self.headless,
            slow_mo=self.slow_mo_ms,
            accept_downloads=True,
            viewport={"width": 1440, "height": 950},
            args=["--disable-blink-features=AutomationControlled"],
        )
        self._page = self._context.pages[0] if self._context.pages else self._context.new_page()
        self._page.set_default_timeout(30000)
        return self._page

    def _wait_for_create_ui(self, page, timeout_sec: int) -> bool:
        deadline = time.time() + timeout_sec
        while time.time() < deadline:
            try:
                if page.evaluate(_CREATE_FORM_READY_JS):
                    return True
            except Exception:
                pass
            time.sleep(2)
        return False

    def _create_from_ui(self, page, prompt: str) -> tuple[List[str], Dict[str, str]]:
        page.goto(CREATE_URL, wait_until="domcontentloaded", timeout=90000)
        if not self._wait_for_create_ui(page, timeout_sec=90):
            raise SunoBrowserError("Suno Song Description field was not detected after loading Create.")
        self._accept_cookies_if_present(page)
        self._fill_create_form(page, prompt)

        with page.expect_response(
            lambda r: "/api/generate" in r.url and r.request.method == "POST",
            timeout=90000,
        ) as response_info:
            if not self._click_create_button(page):
                raise SunoBrowserError("Could not find/click Suno Create button")

        response = response_info.value
        req_headers = response.request.headers
        auth_headers = _headers_from_generate_request(req_headers)
        body_text = response.text()
        if response.status != 200:
            raise SunoBrowserError(f"Suno Create returned {response.status}: {body_text[:500]}")
        try:
            data = response.json()
        except Exception as exc:
            raise SunoBrowserError(f"Suno Create returned non-JSON: {body_text[:500]}") from exc

        clips = data.get("clips") or []
        clip_ids = [c.get("id") for c in clips if c.get("id")]
        if not clip_ids:
            raise SunoBrowserError(f"Suno Create did not return clip ids: {data}")
        return clip_ids, auth_headers

    def _click_create_button(self, page) -> bool:
        """Prefer a real Playwright click; Suno ignores synthetic DOM clicks in some UI builds."""
        try:
            button = page.locator('button[aria-label="Create song"]').last
            button.wait_for(state="visible", timeout=10000)
            if not button.is_enabled(timeout=3000):
                return False
            button.scroll_into_view_if_needed(timeout=5000)
            button.click(timeout=10000)
            return True
        except Exception:
            return bool(page.evaluate(_CLICK_CREATE_JS))

    def _accept_cookies_if_present(self, page) -> None:
        try:
            button = page.get_by_role("button", name=re.compile("accept all cookies", re.I))
            if button.count() > 0:
                button.first.click(timeout=3000)
                page.wait_for_timeout(500)
        except Exception:
            pass

    def _fill_create_form(self, page, prompt: str) -> None:
        field = page.locator("textarea:visible").first
        try:
            field.wait_for(state="visible", timeout=60000)
        except Exception as exc:
            raise SunoBrowserError("Could not find the Suno Song Description field") from exc

        field.click()
        try:
            field.fill(prompt, timeout=30000)
        except Exception:
            page.keyboard.press("Control+A")
            page.keyboard.type(prompt, delay=1)
        page.wait_for_timeout(500)

        # Nudge React/Slate-style controlled inputs if fill() updated DOM but not app state.
        try:
            field.press("End")
            page.keyboard.type(" ", delay=1)
            page.keyboard.press("Backspace")
        except Exception:
            pass

        try:
            instrumental = page.get_by_role("button", name=re.compile("instrumental", re.I)).first
            if instrumental.count() > 0:
                state = instrumental.get_attribute("aria-pressed")
                classes = instrumental.get_attribute("class") or ""
                if state != "true" and "active" not in classes.lower():
                    instrumental.click(timeout=5000)
                    page.wait_for_timeout(500)
        except Exception:
            pass

        if not self._wait_for_create_enabled(page):
            prompt_value = ""
            try:
                prompt_value = field.input_value(timeout=3000)
            except Exception:
                pass
            raise SunoBrowserError(
                "Suno Create button stayed disabled after filling the prompt "
                f"(field length {len(prompt_value)})."
            )

    def _wait_for_create_enabled(self, page, timeout_sec: int = 20) -> bool:
        deadline = time.time() + timeout_sec
        while time.time() < deadline:
            try:
                enabled = page.evaluate(_CREATE_ENABLED_JS)
                if enabled:
                    return True
            except Exception:
                pass
            time.sleep(0.5)
        return False

    def _wait_for_clips(
        self,
        clip_ids: List[str],
        headers: Dict[str, str],
        *,
        timeout_sec: int = 420,
        poll_sec: int = 10,
    ) -> List[Dict[str, Any]]:
        deadline = time.time() + timeout_sec
        last_status = ""
        while time.time() < deadline:
            clips = self._fetch_clips(clip_ids, headers)
            by_id = {c.get("id"): c for c in clips}
            ordered = [by_id.get(cid, {}) for cid in clip_ids]
            statuses = ", ".join(f"{cid[:8]}:{c.get('status', '?')}" for cid, c in zip(clip_ids, ordered))
            if statuses != last_status:
                print(f"   Status: {statuses}")
                last_status = statuses
            if ordered and all(c.get("status") == "complete" and c.get("audio_url") for c in ordered):
                return ordered
            if any(c.get("status") == "error" for c in ordered):
                raise SunoBrowserError(f"Suno returned error status: {ordered}")
            time.sleep(poll_sec)
        raise SunoBrowserError(f"Timed out waiting for clips after {timeout_sec}s")

    def _fetch_clips(self, clip_ids: List[str], headers: Dict[str, str]) -> List[Dict[str, Any]]:
        body = {
            "filters": {
                "ids": {"presence": "True", "clipIds": list(clip_ids)},
            },
            "limit": len(clip_ids),
        }
        resp = requests.post(
            f"{STUDIO_BASE}/api/feed/v3",
            headers=headers,
            data=json.dumps(body, separators=(",", ":")),
            timeout=30,
        )
        if resp.status_code != 200:
            raise SunoBrowserError(f"/feed/v3 {resp.status_code}: {resp.text[:300]}")
        data = resp.json()
        if isinstance(data, list):
            return data
        return data.get("clips") or data.get("items") or data.get("feed") or []

    def _download_variants(
        self,
        track_id: int,
        clips: List[Dict[str, Any]],
        *,
        target_sec: float = 120.0,
    ) -> tuple[List[float], int]:
        raw_dir = self.music_raw_dir / str(track_id)
        raw_dir.mkdir(parents=True, exist_ok=True)
        durations: List[float] = []
        for variant_idx, clip in enumerate(clips, 1):
            url = clip.get("audio_url")
            if not url:
                raise SunoBrowserError(f"No audio_url for clip {clip.get('id')}")
            dst = raw_dir / f"v{variant_idx}.mp3"
            with requests.get(url, stream=True, timeout=120) as resp:
                if resp.status_code != 200:
                    raise SunoBrowserError(f"Download {url} -> {resp.status_code}")
                with open(dst, "wb") as f:
                    for chunk in resp.iter_content(chunk_size=65536):
                        if chunk:
                            f.write(chunk)
            dur = float((clip.get("metadata") or {}).get("duration") or 0)
            durations.append(dur)
            print(f"   Downloaded v{variant_idx}: {dur:.1f}s -> {dst.relative_to(self.project_dir)}")

        selected_variant = _choose_variant(durations, target_sec=target_sec)
        chosen = raw_dir / f"v{selected_variant}.mp3"
        if chosen.exists():
            _copy_selected_music(
                chosen,
                self.music_dir / f"{track_id}.mp3",
                intro_dynamic=bool(self._track_by_id(track_id).get("intro_dynamic")),
            )
            print(f"   Selected v{selected_variant} for track {track_id}")
        return durations, selected_variant

    def _track_by_id(self, track_id: int) -> Dict[str, Any]:
        try:
            plan = self._load_plan()
            return next((t for t in plan.get("tracks", []) if int(t.get("id") or 0) == track_id), {})
        except Exception:
            return {}

    def _load_plan(self) -> Dict[str, Any]:
        if not self.plan_path.exists():
            raise FileNotFoundError(f"music_plan.json not found: {self.plan_path}")
        data = json.loads(self.plan_path.read_text(encoding="utf-8-sig"))
        if "music_plan" in data and "tracks" in data["music_plan"]:
            return data["music_plan"]
        return data

    def _save_plan(self, plan: Dict[str, Any]) -> None:
        self.plan_path.write_text(
            json.dumps({"music_plan": plan}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )


def _build_browser_prompt(track: Dict[str, Any]) -> str:
    parts = []
    for key in ("prompt", "tags"):
        text = str(track.get(key) or "").strip()
        if text:
            parts.append(text)
    prompt = ", ".join(parts)
    if track.get("intro_dynamic"):
        low_intro = prompt.lower()
        intro_bits = []
        if "dynamic cinematic intro" not in low_intro:
            intro_bits.append("dynamic cinematic intro")
        if "starts immediately" not in low_intro:
            intro_bits.append("starts immediately with pulsing percussion")
        if "audible in the first second" not in low_intro:
            intro_bits.append("impact hit on the first beat, audible in the first second")
        if "no quiet opening" not in low_intro:
            intro_bits.append("no silence before the music, no slow fade-in, no quiet opening")
        if "settles under narration" not in low_intro:
            intro_bits.append("first 8-12 seconds are breathtaking, then settles under narration")
        if intro_bits:
            prompt = ", ".join(intro_bits + [prompt])
    low = prompt.lower()
    if "instrumental" not in low:
        prompt += ", instrumental"
    if "no vocals" not in low and "without vocals" not in low:
        prompt += ", no vocals, no lyrics"
    return prompt.strip(" ,")


def _copy_selected_music(src: Path, dst: Path, *, intro_dynamic: bool = False) -> None:
    """Copy the selected variant, trimming leading silence so it starts immediately."""
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        shutil.copy2(src, dst)
        return

    threshold = "-45dB" if intro_dynamic else "-50dB"
    start_duration = "0.03" if intro_dynamic else "0.05"
    temp = dst.with_name(f"{dst.stem}__trimmed{dst.suffix}")
    cmd = [
        ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
        "-i", str(src),
        "-af",
        (
            "silenceremove="
            f"start_periods=1:start_duration={start_duration}:start_threshold={threshold}"
        ),
        "-c:a", "libmp3lame", "-b:a", "192k",
        str(temp),
    ]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
        if proc.returncode != 0 or not temp.exists() or temp.stat().st_size <= 0:
            raise RuntimeError((proc.stderr or "").strip()[-500:])
        if dst.exists():
            dst.unlink()
        temp.replace(dst)
    except Exception as exc:
        print(f"   Warning: leading-silence trim failed for {src.name}: {exc}")
        if temp.exists():
            try:
                temp.unlink()
            except OSError:
                pass
        shutil.copy2(src, dst)


def _track_target_duration(track: Dict[str, Any]) -> float:
    for key in ("duration", "duration_sec", "length_sec"):
        try:
            value = float(track.get(key) or 0)
            if value > 0:
                return value
        except (TypeError, ValueError):
            pass
    try:
        start = float(track.get("start_sec") or track.get("startTime") or track.get("start") or 0)
        end = float(track.get("end_sec") or track.get("endTime") or track.get("end") or 0)
        if end > start:
            return end - start
    except (TypeError, ValueError):
        pass
    return 120.0


def _choose_variant(durations: List[float], *, target_sec: float) -> int:
    if not durations:
        return 1
    usable = [
        (idx, dur)
        for idx, dur in enumerate(durations, 1)
        if dur >= 120.0
    ]
    if usable:
        return min(usable, key=lambda item: abs(item[1] - target_sec))[0]
    return max(enumerate(durations, 1), key=lambda item: item[1])[0]


def _headers_from_generate_request(headers: Dict[str, str]) -> Dict[str, str]:
    out = {
        "User-Agent": headers.get("user-agent") or headers.get("User-Agent") or "",
        "Accept": "*/*",
        "Accept-Language": headers.get("accept-language") or "en-US,en;q=0.9",
        "Origin": "https://suno.com",
        "Referer": "https://suno.com/",
        "Content-Type": "application/json",
    }
    for source, dest in (
        ("authorization", "Authorization"),
        ("device-id", "Device-Id"),
        ("browser-token", "Browser-Token"),
        ("sec-fetch-dest", "Sec-Fetch-Dest"),
        ("sec-fetch-mode", "Sec-Fetch-Mode"),
        ("sec-fetch-site", "Sec-Fetch-Site"),
        ("priority", "Priority"),
    ):
        value = headers.get(source) or headers.get(dest)
        if value:
            out[dest] = value
    if "Authorization" not in out:
        raise SunoBrowserError("Suno Create request did not include Authorization header")
    return out


def generate_for_project_browser(
    project_dir: str,
    *,
    force: bool = False,
    profile_dir: Optional[str] = None,
    headless: bool = False,
    max_tracks: Optional[int] = None,
    login_only: bool = False,
    login_timeout_sec: int = 300,
) -> Dict[str, int]:
    automator = SunoBrowserAutomator(
        project_dir=project_dir,
        profile_dir=profile_dir,
        headless=headless,
    )
    try:
        if login_only:
            automator.login(timeout_sec=login_timeout_sec)
            return {"ok": 0, "skipped": 0, "failed": 0, "total": 0}
        return automator.generate_all(
            force=force,
            max_tracks=max_tracks,
            login_timeout_sec=login_timeout_sec,
        )
    finally:
        automator.close()


_FILL_PROMPT_JS = r"""
(text) => {
  const visible = (el) => {
    const r = el.getBoundingClientRect();
    const s = window.getComputedStyle(el);
    return r.width > 80 && r.height > 20 && s.visibility !== 'hidden' && s.display !== 'none';
  };
  const candidates = Array.from(document.querySelectorAll('textarea, input[type="text"], [contenteditable="true"]'))
    .filter(visible)
    .filter(el => !el.disabled && !el.readOnly)
    .sort((a, b) => {
      const ar = a.getBoundingClientRect();
      const br = b.getBoundingClientRect();
      const score = (el, r) => {
        const label = [
          el.getAttribute('placeholder') || '',
          el.getAttribute('aria-label') || '',
          el.getAttribute('name') || '',
          el.innerText || ''
        ].join(' ').toLowerCase();
        let bonus = 0;
        if (label.includes('describe') || label.includes('song') || label.includes('prompt')) bonus += 100000;
        if (label.includes('lyrics')) bonus -= 80000;
        return r.width * r.height + bonus;
      };
      return score(b, br) - score(a, ar);
    });
  const el = candidates[0];
  if (!el) return false;
  el.scrollIntoView({block: 'center'});
  el.focus();
  if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    setter.call(el, text);
  } else {
    el.textContent = text;
  }
  el.dispatchEvent(new InputEvent('input', {bubbles: true, inputType: 'insertText', data: text}));
  el.dispatchEvent(new Event('change', {bubbles: true}));
  return true;
}
"""


_CREATE_FORM_READY_JS = r"""
() => {
  const visible = (el) => {
    const r = el.getBoundingClientRect();
    const s = window.getComputedStyle(el);
    return r.width > 80 && r.height > 40 && s.visibility !== 'hidden' && s.display !== 'none';
  };
  const textarea = Array.from(document.querySelectorAll('textarea')).find(visible);
  const create = Array.from(document.querySelectorAll('button, [role="button"]')).find((b) => {
    const r = b.getBoundingClientRect();
    const s = window.getComputedStyle(b);
    if (r.width <= 20 || r.height <= 20 || s.visibility === 'hidden' || s.display === 'none') return false;
    const txt = (b.innerText || b.textContent || b.getAttribute('aria-label') || '').trim().toLowerCase();
    const aria = (b.getAttribute('aria-label') || '').trim().toLowerCase();
    return aria === 'create song' || txt === 'create';
  });
  return !!textarea && !!create;
}
"""


_CREATE_ENABLED_JS = r"""
() => {
  const visible = (el) => {
    const r = el.getBoundingClientRect();
    const s = window.getComputedStyle(el);
    return r.width > 20 && r.height > 20 && s.visibility !== 'hidden' && s.display !== 'none';
  };
  const buttons = Array.from(document.querySelectorAll('button, [role="button"]')).filter(visible);
  const btn = buttons.find(b => {
    const txt = (b.innerText || b.textContent || b.getAttribute('aria-label') || '').trim().toLowerCase();
    const aria = (b.getAttribute('aria-label') || '').trim().toLowerCase();
    return aria === 'create song' || txt === 'create';
  });
  if (!btn) return false;
  return !btn.disabled && btn.getAttribute('aria-disabled') !== 'true';
}
"""


_CLICK_CREATE_JS = r"""
() => {
  const visible = (el) => {
    const r = el.getBoundingClientRect();
    const s = window.getComputedStyle(el);
    return r.width > 20 && r.height > 20 && s.visibility !== 'hidden' && s.display !== 'none';
  };
  const buttons = Array.from(document.querySelectorAll('button, [role="button"]')).filter(visible);
  const createButtons = buttons.filter(b => {
    const txt = (b.innerText || b.textContent || b.getAttribute('aria-label') || '').trim().toLowerCase();
    const aria = (b.getAttribute('aria-label') || '').trim().toLowerCase();
    const disabled = b.disabled || b.getAttribute('aria-disabled') === 'true';
    return !disabled && (aria === 'create song' || txt === 'create');
  });
  const btn = createButtons[createButtons.length - 1];
  if (!btn) return false;
  btn.scrollIntoView({block: 'center'});
  btn.click();
  return true;
}
"""
