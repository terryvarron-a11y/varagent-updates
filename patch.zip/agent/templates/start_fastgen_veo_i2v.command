#!/bin/bash
# START_FASTGEN_VEO_I2V.COMMAND - FastGen images + VeoNonStop animate (i2v)
# Run: double-click this file in Finder

PROJECT_NAME="{project_name}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
AGENT_DIR="$(cd "$SCRIPT_DIR/../../agent" && pwd)"

chmod +x *.command *.sh 2>/dev/null

if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e "tell app \"Terminal\" to do script \"cd '$SCRIPT_DIR' && exec '$0'\""
    exit 0
fi

echo ""
echo "========================================================================"
echo "  PIPELINE: FastGen images -> VeoNonStop animate (i2v)"
echo "  Project: $PROJECT_NAME"
echo "========================================================================"
echo ""

# --- STEP 1: FastGen settings ---
echo "  --- STEP 1: FastGen Image Generation ---"
echo ""

DEFAULT_MODEL="{default_model}"
echo "  Default engine (from .env): $DEFAULT_MODEL"
echo ""
echo "  Select engine:"
echo "    [1] NANO PRO FLOW    GEM_PIX_2   - best quality, Flow API"
echo "    [2] NANO PRO GEMINI  GEMINI      - Gemini native, fast"
echo "    [3] GROK             GROK        - Grok, 4 variants"
echo "    [4] NANO             GEM_PIX     - basic, Flow API"
echo "    [5] IMAGEN_3_5_FLOW  IMAGEN_3_5  - Imagen 4, Flow API"
echo "    [6] WHISK            WHISK       - Whisk, categorized refs"
echo ""
read -p "  Engine [1-6] (Enter = $DEFAULT_MODEL): " MODEL_CHOICE
MODEL="$DEFAULT_MODEL"
case "$MODEL_CHOICE" in
    1) MODEL="GEM_PIX_2" ;;
    2) MODEL="GEMINI" ;;
    3) MODEL="GROK" ;;
    4) MODEL="GEM_PIX" ;;
    5) MODEL="IMAGEN_3_5" ;;
    6) MODEL="WHISK" ;;
esac
echo "    Selected: $MODEL"
echo ""

echo "  Select aspect ratio:"
echo "    [1] landscape  16:9"
echo "    [2] portrait   9:16"
echo "    [3] square     1:1"
echo ""
read -p "  Aspect [1/2/3] (Enter = 1): " ASPECT_CHOICE
ASPECT="landscape"
case "$ASPECT_CHOICE" in
    2) ASPECT="portrait" ;;
    3) ASPECT="square" ;;
esac
echo "    Selected: $ASPECT"
echo ""

# Map for VeoNonStop
VEO_RATIO="16:9"
case "$ASPECT" in
    portrait) VEO_RATIO="9:16" ;;
    square) VEO_RATIO="1:1" ;;
esac

read -p "  FastGen parallel [1-10] (Enter = 10): " FG_PARALLEL
FG_PARALLEL="${FG_PARALLEL:-10}"
echo "    Selected: $FG_PARALLEL"
echo ""

# Clip IDs
read -p "  Clip IDs (e.g. 1,2,3 or Enter for all): " IDS_INPUT
IDS_ARG=""
if [ -n "$IDS_INPUT" ]; then
    IDS_ARG="--ids $IDS_INPUT"
    echo "    Clips: $IDS_INPUT"
else
    echo "    Clips: ALL"
fi
echo ""

# --- API key selection ---
BACKUP_ARG=""
KEY_LABEL="main"
ENV_FILE="$AGENT_DIR/.env"
HAS_BK=$(grep -i "FASTGEN_API_KEY_BACKUP" "$ENV_FILE" 2>/dev/null | cut -d= -f2 | tr -d ' ')
if [ -n "$HAS_BK" ]; then
    echo "  API key:"
    echo "    [1] Main key -- default --"
    echo "    [2] Backup key"
    echo ""
    read -p "  Key [1/2] (Enter = main): " KEY_CHOICE
    if [ "$KEY_CHOICE" = "2" ]; then
        BACKUP_ARG="--backup-key"
        KEY_LABEL="BACKUP"
    fi
    echo "    Selected: $KEY_LABEL"
    echo ""
fi

# --- Reference mode ---
MODE_ARG=""
DETECTED_MODE=""
if [ -d "$SCRIPT_DIR/ref" ]; then
    echo "  ref/ folder found!"
    echo "    [1] Auto-detect"
    echo "    [2] Flow  - flat refs, up to 10"
    echo "    [3] Whisk - subject/scene/style categories"
    echo ""
    read -p "  Ref mode [1/2/3] (Enter = auto): " REF_MODE_CHOICE
    case "$REF_MODE_CHOICE" in
        2) MODE_ARG="--mode flow" ;;
        3) MODE_ARG="--mode whisk" ;;
    esac
    if [ -z "$MODE_ARG" ]; then
        DETECTED_MODE=$(cd "$AGENT_DIR" && python detect_ref_mode.py "$PROJECT_NAME" 2>/dev/null)
        echo "    Auto-detected: ${DETECTED_MODE:-unknown}"
    else
        echo "    Mode: $MODE_ARG"
    fi
    echo ""
else
    echo "  No ref/ folder - generating without references"
    echo ""
fi

# --- Quota check ---
cd "$AGENT_DIR"
TMPQ=$(mktemp /tmp/quota_check.XXXXXX)
IDS_FOR_QUOTA=""
[ -n "$IDS_INPUT" ] && IDS_FOR_QUOTA="--ids $IDS_INPUT"
python quota_check.py "$PROJECT_NAME" $IDS_FOR_QUOTA $BACKUP_ARG > "$TMPQ" 2>/dev/null
QC_EXIT=$?
QC_REMAINING=$(grep "^remaining=" "$TMPQ" | cut -d= -f2)
QC_NEEDED=$(grep "^needed=" "$TMPQ" | cut -d= -f2)
rm -f "$TMPQ"

if [ $QC_EXIT -eq 2 ] && [ -z "$BACKUP_ARG" ]; then
    echo "========================================================================"
    echo "  [WARN] QUOTA: remaining=$QC_REMAINING, needed=$QC_NEEDED - NOT ENOUGH"
    echo "    [1] Use BACKUP API key"
    echo "    [2] Continue with MAIN key anyway -- default --"
    echo "    [3] Cancel"
    echo "========================================================================"
    echo ""
    read -p "  Choice [1/2/3] (Enter = main): " QC_CHOICE
    if [ "$QC_CHOICE" = "1" ]; then
        BACKUP_ARG="--backup-key"
        KEY_LABEL="BACKUP"
    elif [ "$QC_CHOICE" = "3" ]; then
        echo "  Cancelled."
        exit 0
    fi
    echo ""
elif [ $QC_EXIT -eq 3 ]; then
    echo "  [WARN] QUOTA: remaining=$QC_REMAINING, needed=$QC_NEEDED - NOT ENOUGH (no backup key)"
    read -p "  Continue anyway? (y/n, Enter = y): " QC_CHOICE
    [ "$QC_CHOICE" = "n" ] && exit 0
    echo ""
else
    echo "  Quota: $QC_REMAINING remaining / $QC_NEEDED needed   [OK]"
    echo ""
fi

BK_REMAINING=""
if [ "$BACKUP_ARG" = "--backup-key" ]; then
    TMPQ2=$(mktemp /tmp/quota_check2.XXXXXX)
    python quota_check.py "$PROJECT_NAME" $IDS_FOR_QUOTA --backup-key > "$TMPQ2" 2>/dev/null
    BK_REMAINING=$(grep "^remaining=" "$TMPQ2" | cut -d= -f2)
    rm -f "$TMPQ2"
    echo "  Backup key quota: $BK_REMAINING remaining / $QC_NEEDED needed"
    echo ""
fi

# --- Check existing generated/ images ---
GEN_DIR="$SCRIPT_DIR/generated"
EXISTING_COUNT=0
[ -d "$GEN_DIR" ] && EXISTING_COUNT=$(ls "$GEN_DIR"/*.png 2>/dev/null | wc -l | tr -d ' ')
if [ "$EXISTING_COUNT" -gt 0 ]; then
    echo "========================================================================"
    echo "  Found $EXISTING_COUNT images already in generated/"
    echo "    [1] Continue -- generate only missing -- default --"
    echo "    [2] Regenerate ALL -- delete existing"
    echo "========================================================================"
    echo ""
    read -p "  Choice [1/2] (Enter = continue): " REGEN_CHOICE
    if [ "$REGEN_CHOICE" = "2" ]; then
        rm -f "$GEN_DIR"/*.png
        echo "  Deleted. Starting from scratch."
    else
        echo "  Continuing -- existing files will be skipped."
    fi
    echo ""
fi

# --- STEP 2: VeoNonStop settings ---
echo "  --- STEP 2: VeoNonStop Animate Settings ---"
echo ""

read -p "  VeoNonStop parallel [1-24] (Enter = 12): " VEO_PARALLEL
VEO_PARALLEL="${VEO_PARALLEL:-12}"
echo "    Selected: $VEO_PARALLEL"
echo ""

echo "  Prompt source for video animation:"
echo "    [1] Director prompts (per-clip)"
echo "    [2] Single prompt for all clips"
echo ""
read -p "  Prompt [1/2] (Enter = 1): " PROMPT_CHOICE
PROMPT_ARG=""
if [ "$PROMPT_CHOICE" = "2" ]; then
    read -p "  Enter prompt: " PROMPT_INPUT
    if [ -n "$PROMPT_INPUT" ]; then
        PROMPT_ARG="--prompt \"$PROMPT_INPUT\""
    fi
fi
echo ""

# Summary
echo "========================================================================"
echo "  SUMMARY:"
echo "    Project:  $PROJECT_NAME"
echo "    Step 1:   FastGen ($MODEL, $ASPECT, parallel=$FG_PARALLEL)"
echo "    Step 2:   VeoNonStop i2v ($VEO_RATIO, parallel=$VEO_PARALLEL)"
[ -n "$IDS_INPUT" ] && echo "    Clips:    $IDS_INPUT" || echo "    Clips:    ALL"
if [ -n "$MODE_ARG" ]; then
    echo "    Refs:     $MODE_ARG"
elif [ -n "$DETECTED_MODE" ]; then
    echo "    Refs:     auto ($DETECTED_MODE)"
else
    echo "    Refs:     none"
fi
[ "$BACKUP_ARG" = "--backup-key" ] && echo "    API key:  BACKUP  quota=$BK_REMAINING" || echo "    API key:  main    quota=$QC_REMAINING"
echo "========================================================================"
echo ""
read -p "  Start? (y/n): " CONFIRM
if [ "$CONFIRM" != "y" ] && [ "$CONFIRM" != "Y" ]; then
    echo "  Cancelled."
    exit 0
fi

echo ""
echo "========================================================================"
echo "  STEP 1/2: FastGen image generation..."
echo "========================================================================"
echo ""

cd "$AGENT_DIR"

python agent.py generate \
    --project "$PROJECT_NAME" \
    --image-gen "fastgen" \
    --model "$MODEL" \
    --aspect "$ASPECT" \
    --parallel "$FG_PARALLEL" $IDS_ARG $MODE_ARG $BACKUP_ARG

if [ $? -ne 0 ]; then
    echo ""
    echo "[ERROR] FastGen failed. Pipeline stopped."
    read -p "Press Enter to close..."
    exit 1
fi

echo ""
echo "========================================================================"
echo "  STEP 2/2: VeoNonStop image-to-video..."
echo "========================================================================"
echo ""

eval python agent.py img2video \
    --project "$PROJECT_NAME" \
    --mode "i2v" \
    --ratio "$VEO_RATIO" \
    --parallel "$VEO_PARALLEL" $IDS_ARG $PROMPT_ARG

EXIT_CODE=$?
echo ""
if [ $EXIT_CODE -ne 0 ]; then
    echo "[ERROR] VeoNonStop i2v failed. Check generated/ images are OK."
else
    echo "========================================================================"
    echo "  DONE! Pipeline complete."
    echo "    Images:  $SCRIPT_DIR/generated/"
    echo "    Videos:  $SCRIPT_DIR/vid_img/"
    echo "========================================================================"
fi
echo ""
read -p "Press Enter to close..."
