#!/bin/bash
# VARAGENT - Update
# Works even if varagent.py fails to launch.
# Run: double-click this file in Finder

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo ""
echo "================================================================"
echo " VARAGENT - Update"
echo " Works even if varagent.py fails to launch."
echo "================================================================"
echo ""

# Find Python 3.10+ (Homebrew first, then system)
PY=""
if [ -f /opt/homebrew/bin/brew ]; then
    eval "$(/opt/homebrew/bin/brew shellenv)"
elif [ -f /usr/local/bin/brew ]; then
    eval "$(/usr/local/bin/brew shellenv)"
fi
for _p in /opt/homebrew/bin/python3 /usr/local/bin/python3 python3; do
    _v=$("$_p" -c "import sys; print(sys.version_info.minor)" 2>/dev/null)
    if [ -n "$_v" ] && [ "$_v" -ge 10 ] 2>/dev/null; then
        PY="$_p"
        break
    fi
done
if [ -z "$PY" ]; then
    # Fallback: any python3
    if command -v python3 &>/dev/null; then
        PY="python3"
    else
        echo " [ERROR] python3 not found. Run install.command first."
        echo ""
        read -p "Press Enter to exit..." DUMMY
        exit 1
    fi
fi
echo " Using: $PY ($($PY --version 2>&1))"

TMP_PY="$(mktemp /tmp/varagent_update_XXXXXX.py)"

cat > "$TMP_PY" << 'PYEOF'
import sys, pathlib
p = pathlib.Path('.')
sys.path.insert(0, str(p / 'agent'))
from modules import updater as u
i = u.check_updates(p)
if i.get('error'):
    print('[ERROR]', i['error'])
    sys.exit(1)
if not i['available']:
    print('[OK] Already up to date: v' + i['version'])
    sys.exit(0)
print('Available: v' + i['version'])
for line in i.get('changelog', []):
    print(' *', line)
print()
res = u.install_update(p, lambda m: print(' ', m))
if not res['ok']:
    print('[ERROR]', res['error'])
    sys.exit(1)
print('[OK] Updated. Run varagent.command.')
PYEOF

# Self-heal: always fetch latest updater.py before running
echo " Fetching latest updater..."
curl -fsSL "https://raw.githubusercontent.com/terryvarron-a11y/varagent-updates/main/agent/modules/updater.py" -o "$SCRIPT_DIR/agent/modules/updater.py" 2>/dev/null && echo " [OK] updater.py refreshed" || echo " [WARN] could not fetch updater.py, using local"

echo ""
echo " Checking for updates..."
echo ""
$PY "$TMP_PY"
EXIT_CODE=$?
rm -f "$TMP_PY"

if [ $EXIT_CODE -eq 1 ]; then
    echo ""
    echo " [ERROR] Update failed. See error above."
    echo ""
    read -p "Press Enter to exit..." DUMMY
    exit 1
fi

echo ""
echo " Run varagent.command"
echo ""
read -p "Press Enter to exit..." DUMMY
