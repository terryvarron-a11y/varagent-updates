#!/usr/bin/env python3
"""
ФОТО-СЛАЙДШОУ - v1
• Ken Burns эффект: чередование отдаление/приближение по чётности ID клипа
  Нечётный ID (1,3,5...) → отдаление: начинаем зумом ×1.43 (видно 70%), уходим на ×1.0 (видно 100%)
  Чётный  ID (2,4,6...)  → приближение: начинаем ×1.0, уходим на ×1.43
  Максимальная обрезка: 30% (зум не более ×1.43)
• Переходы xfade определяются динамически из доступных в установленном FFmpeg
• Читает montage_plan.json (startTime / endTime)
• Ищет картинки в generated/{id:03d}.png|jpg или {id}.png|jpg
• GPU ускорение (NVENC / AMF / libx264 fallback)
"""

import subprocess
import json
import sys
import os
import re
import uuid
import argparse
import threading
from pathlib import Path
from tqdm import tqdm
import platform
import time
import shutil
import logging
from datetime import datetime
import traceback

if platform.system() == 'Windows':
    SUBPROCESS_FLAGS = {'creationflags': 0x08000000}
else:
    SUBPROCESS_FLAGS = {}

logger = None

# Предпочтительные xfade-переходы (в порядке предпочтения)
# Определяются динамически при первом вызове get_xfade_transitions()
_PREFERRED_TRANSITIONS = ['smoothleft', 'smoothright', 'distance', 'dissolve', 'fade']
_xfade_transitions_cache = None  # заполняется при первом вызове


def detect_xfade_transitions():
    """
    Динамически определяет доступные xfade-переходы в установленном FFmpeg.
    Возвращает подмножество _PREFERRED_TRANSITIONS, доступное в данной сборке.
    Fallback: ['fade', 'dissolve'].
    """
    try:
        result = subprocess.run(
            ['ffmpeg', '-h', 'filter=xfade'],
            capture_output=True, text=True, timeout=10, **SUBPROCESS_FLAGS
        )
        output = result.stdout + result.stderr
        available = set()
        # Строки вида: "     name   N   ..FV....... description"
        for match in re.finditer(r'^\s{3,}(\w+)\s+-?\d+\s+\.\.', output, re.MULTILINE):
            name = match.group(1)
            # пропустить имена опций самого фильтра
            if name not in ('transition', 'duration', 'offset', 'expr', 'custom'):
                available.add(name)
        chosen = [t for t in _PREFERRED_TRANSITIONS if t in available]
        return chosen if chosen else ['fade', 'dissolve']
    except Exception:
        return ['fade', 'dissolve']


def get_xfade_transitions():
    """Возвращает список доступных xfade-переходов (кешируется после первого вызова)."""
    global _xfade_transitions_cache
    if _xfade_transitions_cache is None:
        _xfade_transitions_cache = detect_xfade_transitions()
        if logger:
            logger.info(f"xfade переходы (из FFmpeg): {_xfade_transitions_cache}")
    return _xfade_transitions_cache

# Границы Ken Burns: ×1.0 = полный кадр, ×1.43 ≈ 1/0.7 = обрезка 30%
KB_MIN_ZOOM = 1.0
KB_MAX_ZOOM = 1.43


def _zoom_supersample() -> int:
    """Во сколько раз считать движение крупнее финального кадра: 1 / 2 / 3.

    Настройка `ZOOM_SUPERSAMPLE` (та же, что в video_concat.py). Умолчание — 2;
    1 — прежнее поведение. Зачем крупнее: `scale` выдаёт целое число пикселей, и при
    медленном наезде картинка стоит через кадр, а потом прыгает — это и есть
    дрожание. Считая крупнее и ужимая в конце, мы делаем шаг субпиксельным.
    """
    try:
        value = int(os.getenv('ZOOM_SUPERSAMPLE', '2') or '2')
    except (TypeError, ValueError):
        value = 2
    return min(3, max(1, value))

# ============================================================================
# ЛОГГИРОВАНИЕ
# ============================================================================

def setup_logging():
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = f'photo_concat_{timestamp}.log'

    _logger = logging.getLogger('PhotoConcat')
    _logger.setLevel(logging.DEBUG)

    formatter = logging.Formatter(
        '%(asctime)s | %(levelname)-8s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    fh = logging.FileHandler(log_file, encoding='utf-8')
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(formatter)
    _logger.addHandler(fh)

    ch = logging.StreamHandler()
    ch.setLevel(logging.WARNING)
    ch.setFormatter(formatter)
    _logger.addHandler(ch)

    _logger.info("="*80)
    _logger.info("НАЧАЛО РАБОТЫ ФОТО-СЛАЙДШОУ")
    _logger.info("="*80)

    return _logger, log_file


# ============================================================================
# ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
# ============================================================================

def get_audio_duration(audio_path):
    try:
        result = subprocess.run(
            ['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
             '-of', 'default=noprint_wrappers=1:nokey=1', str(audio_path)],
            capture_output=True, text=True, check=True, **SUBPROCESS_FLAGS
        )
        duration = float(result.stdout.strip())
        logger.info(f"Длительность аудио: {duration:.2f} сек")
        return duration
    except Exception as e:
        logger.error(f"Ошибка получения длительности аудио: {e}")
        print(f"❌ Ошибка получения длительности аудио: {e}")
        sys.exit(1)


def get_video_duration(video_path):
    try:
        result = subprocess.run(
            ['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
             '-of', 'default=noprint_wrappers=1:nokey=1', str(video_path)],
            capture_output=True, text=True, check=True, **SUBPROCESS_FLAGS
        )
        return float(result.stdout.strip())
    except Exception:
        return 0.0


def get_file_size_mb(file_path):
    try:
        return os.path.getsize(str(file_path)) / (1024 * 1024)
    except Exception:
        return 0.0


def _test_encoder(codec):
    try:
        cmd = [
            'ffmpeg', '-hide_banner', '-loglevel', 'error',
            '-f', 'lavfi', '-i', 'nullsrc=s=64x64:d=0.1',
            '-c:v', codec, '-frames:v', '1', '-f', 'null', '-'
        ]
        r = subprocess.run(cmd, capture_output=True, timeout=10, **SUBPROCESS_FLAGS)
        return r.returncode == 0
    except Exception:
        return False


def detect_gpu_encoder(force_amd=False):
    logger.debug("Определение GPU энкодера")
    try:
        result = subprocess.run(
            ['ffmpeg', '-hide_banner', '-encoders'],
            capture_output=True, text=True, **SUBPROCESS_FLAGS
        )
        if 'h264_amf' in result.stdout and _test_encoder('h264_amf'):
            logger.info("AMD GPU (h264_amf)")
            return 'amd', 'h264_amf'
        if 'h264_nvenc' in result.stdout and not force_amd and _test_encoder('h264_nvenc'):
            logger.info("NVIDIA GPU (h264_nvenc)")
            return 'nvidia', 'h264_nvenc'
        logger.info("CPU (libx264)")
        return 'cpu', 'libx264'
    except Exception as e:
        logger.warning(f"Ошибка определения GPU: {e}")
        return 'cpu', 'libx264'


def get_encoder_params(encoder_type, codec, bitrate='10M'):
    bval = int(bitrate.rstrip('M')) if bitrate.endswith('M') else 10
    buf = f'{bval * 2}M'
    if encoder_type == 'nvidia':
        return ['-c:v', codec, '-preset', 'p4', '-tune', 'hq',
                '-b:v', bitrate, '-maxrate', bitrate, '-bufsize', buf,
                '-profile:v', 'high', '-pix_fmt', 'yuv420p']
    elif encoder_type == 'amd':
        return ['-c:v', codec, '-quality', 'speed',
                '-b:v', bitrate, '-maxrate', bitrate, '-bufsize', buf,
                '-profile:v', 'high', '-pix_fmt', 'yuv420p']
    else:
        return ['-c:v', codec, '-preset', 'medium',
                '-b:v', bitrate, '-maxrate', bitrate, '-bufsize', buf,
                '-profile:v', 'high', '-pix_fmt', 'yuv420p']


def run_ffmpeg_with_progress(cmd, total_duration, description="Processing"):
    logger.debug(f"FFmpeg: {description}")
    cmd_with_progress = cmd + ['-progress', 'pipe:1']
    process = subprocess.Popen(
        cmd_with_progress, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        universal_newlines=True, **SUBPROCESS_FLAGS
    )

    # Drain stderr в фоне (иначе буфер может заполниться и заблокировать процесс)
    stderr_lines = []

    def _read_stderr():
        for line in process.stderr:
            stderr_lines.append(line)

    stderr_thread = threading.Thread(target=_read_stderr, daemon=True)
    stderr_thread.start()

    start_time = time.time()
    got_any = False
    last_refresh = start_time

    if total_duration is None or total_duration <= 0:
        bar_fmt = '{l_bar}{bar}| {n:.1f}s [{elapsed}]'
        tqdm_total = None
    else:
        bar_fmt = '{l_bar}{bar}| {n:.1f}/{total:.1f}s [{elapsed}]'
        tqdm_total = total_duration

    with tqdm(total=tqdm_total, desc=description, unit="s", bar_format=bar_fmt) as pbar:
        last_t = 0
        for line in process.stdout:
            line = line.strip()
            if line.startswith('out_time_us=') or line.startswith('out_time_ms='):
                try:
                    val = line.split('=')[1]
                    if val and val != 'N/A':
                        time_s = int(val) / 1_000_000.0
                        delta = time_s - last_t
                        if delta > 0:
                            pbar.update(delta)
                            last_t = time_s
                            got_any = True
                except (ValueError, IndexError):
                    pass
            now = time.time()
            if now - last_refresh >= 1.0:
                pbar.refresh()
                last_refresh = now

    process.wait()
    stderr_thread.join(timeout=2)
    elapsed = time.time() - start_time
    logger.info(f"{description} завершено за {elapsed:.1f}с (прогресс: {got_any})")

    if process.returncode != 0:
        stderr_text = ''.join(stderr_lines)
        logger.error(f"FFmpeg ошибка returncode={process.returncode}")
        if stderr_text:
            logger.error(f"FFmpeg stderr:\n{stderr_text[-1500:]}")
        raise subprocess.CalledProcessError(process.returncode, cmd)


def ask_delete_temp_folder(temp_dir):
    temp_dir = Path(temp_dir)
    if not temp_dir.exists():
        return
    try:
        size_mb = sum(
            f.stat().st_size for f in temp_dir.rglob('*') if f.is_file()
        ) / (1024 * 1024)
    except Exception:
        size_mb = 0
    print(f"\n🧹 Временная папка: {temp_dir}")
    print(f"   💾 Размер: {size_mb:.0f} MB")
    print()
    while True:
        response = input("Удалить временную папку? (y/n): ").strip().lower()
        if response in ['y', 'yes', 'д', 'да']:
            try:
                shutil.rmtree(temp_dir)
                print("   ✅ Папка удалена")
                logger.info("Временная папка удалена")
            except Exception as e:
                print(f"   ⚠️  Ошибка удаления: {e}")
            break
        elif response in ['n', 'no', 'н', 'нет']:
            print(f"   ✅ Папка сохранена: {temp_dir.absolute()}")
            break
        else:
            print("   ⚠️  Введите 'y' (да) или 'n' (нет)")


# ============================================================================
# ПОИСК ИЗОБРАЖЕНИЙ
# ============================================================================

def find_image(clip_id):
    """
    Ищет изображение для клипа по ID.
    Порядок поиска:
      vid_img/{id:03d}.png|jpg|jpeg|webp
      vid_img/{id}.png|jpg|jpeg|webp
      generated/{id:03d}.png|jpg|jpeg|webp
      {id:03d}.png|jpg|jpeg|webp
      {id}.png|jpg|jpeg|webp
    """
    exts = ['png', 'jpg', 'jpeg', 'webp']
    base = Path('.')

    # vid_img/ — с паддингом и без
    for fmt in [f'{clip_id:03d}', f'{clip_id}']:
        for ext in exts:
            p = base / 'vid_img' / f'{fmt}.{ext}'
            if p.exists():
                return p

    # FastGen output: generated/001.png
    for ext in exts:
        p = base / 'generated' / f'{clip_id:03d}.{ext}'
        if p.exists():
            return p

    # С паддингом в текущей папке
    for ext in exts:
        p = base / f'{clip_id:03d}.{ext}'
        if p.exists():
            return p

    # Без паддинга
    for ext in exts:
        p = base / f'{clip_id}.{ext}'
        if p.exists():
            return p

    return None


# ============================================================================
# КЕН БЁРНС: ОДИН КЛИП ИЗ ФОТО
# ============================================================================

def build_ken_burns_clip(image_path, output_path, duration, clip_id,
                         out_w, out_h, fps, encoder_type, codec, bitrate):
    """
    Создаёт видеоклип из изображения с эффектом Ken Burns.

    Нечётный clip_id (1,3,5...) → отдаление:
        начинаем с зума ×1.43 (видно 70% картинки), плавно уходим на ×1.0 (100%)

    Чётный clip_id (2,4,6...) → приближение:
        начинаем с ×1.0 (100%), плавно уходим на зум ×1.43 (70%)

    Масштаб входа: scale до KB_MAX_ZOOM × выходного разрешения, чтобы
    при минимальном зуме (1.0) изображение полностью покрывало кадр.
    """
    # Не используем zoompan — у него баг FFmpeg #4298: целочисленная арифметика
    # x/y вызывает дрожание при медленном зуме. Вместо этого scale+crop.
    # Ресемплер — bilinear: до 30.08 здесь стоял lanczos, и он работал против
    # нас. Резкий фильтр честно прорисовывает каждый скачок размера, а скачки
    # тут были вдвое крупнее обычных (см. ниже про чётность) — самая резкая
    # картинка на самом грубом шаге. Отсюда и замер: 110% дрожания против 102%
    # у video_concat.py, где стоял bilinear.

    # Входной размер: масштабируем картинку до KB_MAX_ZOOM × выходного разрешения
    base_w = int(out_w * KB_MAX_ZOOM) + 2
    base_h = int(out_h * KB_MAX_ZOOM) + 2
    base_w += base_w % 2  # выравнивание до чётного
    base_h += base_h % 2

    # Выбор направления по чётности ID
    if clip_id % 2 == 1:
        # Нечётный → отдаление: 1.43 → 1.0
        z_start = KB_MAX_ZOOM
        z_end   = KB_MIN_ZOOM
    else:
        # Чётный → приближение: 1.0 → 1.43
        z_start = KB_MIN_ZOOM
        z_end   = KB_MAX_ZOOM

    # scale+crop: zoom(t) плавно меняет масштаб через переменную t (секунды).
    # Lanczos даёт чёткое масштабирование без дрожания.
    z_range = z_end - z_start
    dur = max(duration, 0.001)

    # Раньше здесь стояло `trunc(.../2)*2` — округление размера до ЧЁТНЫХ, то
    # есть шаг зума в ДВА пикселя вместо одного. При медленном наезде картинка
    # больше половины кадров стояла на месте и потом прыгала — это и читалось
    # как дрожание (замер: 110% джиттера, 94 неподвижных кадра из 176; в
    # video_concat.py без чётности — 102% и 63). Чётность тут не нужна вовсе:
    # этот кадр не кодируется, из него дальше вырезают out_w×out_h.
    zoom_expr = f"({z_start:.6f}+{z_range:.6f}*t/{dur:.6f})/{KB_MAX_ZOOM:.6f}"
    supersample = _zoom_supersample()
    work_w, work_h = base_w * supersample, base_h * supersample
    crop_w, crop_h = out_w * supersample, out_h * supersample
    # max(...) — страховка от кадра, который ffmpeg отрисовывает чуть за
    # пределом длительности: на отдалении масштаб там уходит ниже кропа, и
    # ffmpeg падает с access violation. Запас в базовом размере всего +2 px,
    # такой кадр его съедает (ловилось в video_concat.py 30.08).
    scale_w_expr = f"max({crop_w}, {work_w}*({zoom_expr}))"
    scale_h_expr = f"max({crop_h}, {work_h}*({zoom_expr}))"

    vf = (
        f'scale={base_w}:{base_h}:force_original_aspect_ratio=increase,'
        f'crop={base_w}:{base_h},'
        f"scale='{scale_w_expr}':'{scale_h_expr}':flags=bilinear:eval=frame,"
        f'crop={crop_w}:{crop_h}:(iw-{crop_w})/2:(ih-{crop_h})/2,'
    )
    if supersample > 1:
        # Ужимаем в самом конце: шаг в пиксель промежуточного кадра становится
        # долей пикселя финального, и ход делается субпиксельным.
        vf += f'scale={out_w}:{out_h}:flags=bicubic,'
    vf += 'format=yuv420p'

    encoder_params = get_encoder_params(encoder_type, codec, bitrate)

    cmd = [
        'ffmpeg', '-y', '-nostdin',
        '-loop', '1',
        '-framerate', str(fps),
        '-i', str(image_path),
        '-vf', vf,
        '-t', f'{duration:.6f}',
        '-r', str(fps),
    ] + encoder_params + ['-an', str(output_path)]

    direction = 'отдаление' if clip_id % 2 == 1 else 'приближение'
    logger.debug(
        f"KB clip {clip_id}: {image_path.name} → {output_path.name} "
        f"({duration:.2f}s, {direction}, zoom {z_start:.2f}→{z_end:.2f})"
    )

    try:
        subprocess.run(cmd, check=True, capture_output=True, **SUBPROCESS_FLAGS)
    except subprocess.CalledProcessError as e:
        logger.error(f"Ошибка FFmpeg для клипа {clip_id}: {e.stderr.decode('utf-8', errors='replace')[-500:]}")
        raise


# ============================================================================
# XFADE СКЛЕЙКА
# ============================================================================

def build_xfade_filtergraph(clip_paths, durations, transitions, t_dur):
    """
    Строит FFmpeg filter_complex для xfade склейки N клипов.

    Возвращает (filtergraph_str, final_output_label).
    Если N=1 — возвращает (None, '[0:v]').

    offset для каждого последующего xfade — накопленное время
    в выходном потоке до начала перехода.
    """
    n = len(clip_paths)
    if n == 1:
        return None, '[0:v]'

    parts = []
    prev_label = '[0:v]'
    offset = 0.0

    for i in range(1, n):
        offset += durations[i - 1] - t_dur
        transition = transitions[(i - 1) % len(transitions)]
        out_label = f'[v{i}]' if i < n - 1 else '[vout]'
        parts.append(
            f"{prev_label}[{i}:v]xfade=transition={transition}:"
            f"duration={t_dur:.3f}:offset={offset:.6f}{out_label}"
        )
        prev_label = out_label

    return ';'.join(parts), '[vout]'


def concat_with_xfade(clip_files, durations, t_dur, output_file,
                      encoder_type, codec, bitrate, display_duration=None):
    """
    Склеивает клипы с xfade переходами.

    Для проектов > CHUNK_SIZE клипов: чанки по CHUNK_SIZE, без xfade на границах.
    Для ≤ CHUNK_SIZE: один запрос FFmpeg со всеми входами.
    """
    n = len(clip_files)
    if n == 0:
        raise ValueError("Нет файлов для склейки")

    if n == 1:
        shutil.copy2(clip_files[0], str(output_file))
        return

    # Защита: t_dur не больше 40% от самого короткого клипа
    min_dur = min(durations)
    t_dur = min(t_dur, min_dur * 0.4)
    t_dur = max(t_dur, 0.1)
    logger.info(f"Длительность перехода: {t_dur:.3f}с")

    CHUNK_SIZE = 80  # клипов за один вызов FFmpeg

    if n <= CHUNK_SIZE:
        _xfade_single_pass(clip_files, durations, t_dur, output_file,
                           encoder_type, codec, bitrate, display_duration)
    else:
        _xfade_chunked(clip_files, durations, t_dur, output_file,
                       encoder_type, codec, bitrate, CHUNK_SIZE)


def _xfade_single_pass(clip_files, durations, t_dur, output_file,
                       encoder_type, codec, bitrate, display_duration):
    """Один FFmpeg вызов для всех клипов"""
    n = len(clip_files)
    filtergraph, final_label = build_xfade_filtergraph(
        clip_files, durations, get_xfade_transitions(), t_dur
    )

    inputs = []
    for f in clip_files:
        inputs += ['-i', str(f)]

    # xfade — фильтр на CPU; кодирование результата через GPU (h264_amf/nvenc) поддерживается
    xfade_encoder_params = get_encoder_params(encoder_type, codec, bitrate)
    out_dur = sum(durations) - (n - 1) * t_dur if display_duration is None else display_duration

    if filtergraph:
        cmd = ['ffmpeg', '-y'] + inputs + [
            '-filter_complex', filtergraph,
            '-map', final_label,
            '-r', '30',
        ] + xfade_encoder_params + ['-an', str(output_file)]
    else:
        cmd = ['ffmpeg', '-y', '-i', str(clip_files[0]),
               '-c', 'copy', str(output_file)]

    run_ffmpeg_with_progress(cmd, out_dur, f"xfade ({n} клипов)")


def _xfade_chunked(clip_files, durations, t_dur, output_file,
                   encoder_type, codec, bitrate, chunk_size):
    """Обработка большого проекта чанками; без xfade на границах чанков"""
    temp_dir = Path(output_file).parent
    # Уникальный префикс для чанков — исключает race condition при параллельных запусках
    run_id = uuid.uuid4().hex[:8]
    chunks = []
    idx = 0

    while idx < len(clip_files):
        end = min(idx + chunk_size, len(clip_files))
        chunk_clips = clip_files[idx:end]
        chunk_durs  = durations[idx:end]
        chunk_num   = idx // chunk_size + 1
        chunk_out   = temp_dir / f'xfade_chunk_{run_id}_{chunk_num:02d}.mp4'

        print(f"   Чанк {chunk_num}: клипы {idx + 1}–{end}...")
        _xfade_single_pass(chunk_clips, chunk_durs, t_dur, chunk_out,
                           encoder_type, codec, bitrate, None)
        chunks.append(chunk_out)
        idx = end

    # Финальная склейка чанков (stream copy)
    # Используем относительные имена файлов + cwd=temp_dir — кириллица в путях не ломает concat
    print(f"   Финальная склейка {len(chunks)} чанков...")
    concat_list = temp_dir / f'xfade_list_{run_id}.txt'
    with open(concat_list, 'w', encoding='utf-8') as f:
        for c in chunks:
            f.write(f"file '{c.name}'\n")

    result = subprocess.run(
        ['ffmpeg', '-y', '-f', 'concat', '-safe', '0',
         '-i', concat_list.name, '-c', 'copy', str(Path(output_file).absolute())],
        cwd=str(temp_dir), capture_output=True, **SUBPROCESS_FLAGS
    )
    if result.returncode != 0:
        stderr_text = result.stderr.decode('utf-8', errors='replace')
        logger.error(f"FFmpeg concat error: {stderr_text[-1000:]}")
        raise subprocess.CalledProcessError(result.returncode, 'ffmpeg concat')

    concat_list.unlink()
    for c in chunks:
        c.unlink(missing_ok=True)


# ============================================================================
# MAIN
# ============================================================================

def main():
    global logger

    parser = argparse.ArgumentParser(
        description='Фото-слайдшоу: Ken Burns + xfade переходы'
    )
    parser.add_argument('plan',
                        help='Путь к montage_plan.json')
    parser.add_argument('-o', '--output',
                        default='photo_result.mp4',
                        help='Выходной файл (по умолчанию: photo_result.mp4)')
    parser.add_argument('-a', '--audio',
                        default=None,
                        help='Аудио-озвучка (wav/mp3/m4a...). '
                             'По умолчанию ищется любой .wav/.mp3 в папке.')
    parser.add_argument('-b', '--bitrate',
                        default='10M',
                        help='Битрейт видео (по умолчанию: 10M)')
    parser.add_argument('--fps',
                        type=int, default=30,
                        help='FPS выходного видео (по умолчанию: 30)')
    parser.add_argument('--resolution',
                        default='1920x1080',
                        help='Разрешение WxH (по умолчанию: 1920x1080)')
    parser.add_argument('--transition-duration',
                        type=float, default=0.7,
                        help='Длительность перехода в секундах (по умолчанию: 0.7)')
    parser.add_argument('--no-gpu',
                        action='store_true',
                        help='Использовать CPU вместо GPU')
    parser.add_argument('--force-amd',
                        action='store_true',
                        help='Принудительно AMD GPU')
    parser.add_argument('--force-reprocess',
                        action='store_true',
                        help='Переобработать Ken Burns клипы заново')
    args = parser.parse_args()

    logger, log_file = setup_logging()

    # Разрешение
    try:
        out_w, out_h = map(int, args.resolution.lower().split('x'))
    except Exception:
        print(f"❌ Неверный формат разрешения: {args.resolution}  (пример: 1920x1080)")
        sys.exit(1)

    print("=" * 80)
    print("🖼️  ФОТО-СЛАЙДШОУ  —  Ken Burns + xfade переходы")
    print("=" * 80)
    print(f"\n📝 Лог-файл: {log_file}")

    # Энкодер
    encoder_type, codec = (
        ('cpu', 'libx264') if args.no_gpu
        else detect_gpu_encoder(args.force_amd)
    )
    if encoder_type == 'nvidia':
        print("\n✅ NVIDIA GPU - h264_nvenc")
    elif encoder_type == 'amd':
        print("\n✅ AMD GPU - h264_amf")
    else:
        print("\nℹ️  CPU - libx264")

    print(f"📊 Разрешение: {out_w}×{out_h}  FPS: {args.fps}  Битрейт: {args.bitrate}")
    print(f"🔀 Переходы: {' → '.join(get_xfade_transitions())} (по кругу, {args.transition_duration:.1f}с)")

    # -----------------------------------------------------------------------
    # Загрузка плана
    # -----------------------------------------------------------------------
    try:
        with open(args.plan, 'r', encoding='utf-8') as f:
            plan = json.load(f)
        logger.info(f"План загружен: {args.plan}")
    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(f"❌ Ошибка загрузки плана: {e}")
        sys.exit(1)

    clips = plan.get('clips', [])
    if not clips:
        print("❌ В montage_plan.json нет поля 'clips'!")
        sys.exit(1)

    # Сортировка по startTime (защита от неправильного порядка в JSON)
    clips = sorted(clips, key=lambda c: c['startTime'])
    logger.info(f"Клипов в плане: {len(clips)}")

    # -----------------------------------------------------------------------
    # Поиск аудио
    # -----------------------------------------------------------------------
    audio_file = args.audio
    if audio_file is None:
        for ext in ['*.wav', '*.mp3', '*.flac', '*.m4a', '*.aac']:
            found = list(Path('.').glob(ext))
            if found:
                audio_file = str(found[0])
                break

    if not audio_file or not os.path.exists(str(audio_file)):
        print("❌ Аудио файл не найден!")
        print("   Положите .wav/.mp3 в папку проекта или укажите: -a файл.wav")
        sys.exit(1)

    audio_duration = get_audio_duration(audio_file)
    print(f"\n🎵 Аудио: {audio_file} ({audio_duration:.2f} сек)")
    print(f"📋 Клипов в плане: {len(clips)}")

    try:
        # ===================================================================
        # ЭТАП 1: ПОИСК ИЗОБРАЖЕНИЙ
        # ===================================================================
        print("\n" + "=" * 80)
        print("🔍 ЭТАП 1: ПОИСК ИЗОБРАЖЕНИЙ")
        print("=" * 80)

        image_map = {}  # clip_id → Path
        missing_ids = []

        for clip in clips:
            cid = clip['id']
            img = find_image(cid)
            if img:
                image_map[cid] = img
            else:
                missing_ids.append(cid)

        print(f"\n✅ Найдено: {len(image_map)} / {len(clips)}")

        if missing_ids:
            shown = missing_ids[:15]
            tail = f'...  (всего {len(missing_ids)})' if len(missing_ids) > 15 else ''
            print(f"⚠️  Не найдено для клипов: {shown}{tail}")
            print("   Картинки ищутся в generated/{id:03d}.png|jpg или {id}.png|jpg")
            if not image_map:
                print("❌ Ни одного изображения не найдено!")
                sys.exit(1)

        # Оставляем только клипы с найденными изображениями
        valid_clips = [c for c in clips if c['id'] in image_map]
        logger.info(f"Валидных клипов: {len(valid_clips)}")

        # ===================================================================
        # ЭТАП 2: KEN BURNS КЛИПЫ
        # ===================================================================
        print("\n" + "=" * 80)
        print("🎬 ЭТАП 2: KEN BURNS КЛИПЫ")
        print("=" * 80)

        temp_dir = Path('temp_photo')
        temp_dir.mkdir(exist_ok=True)

        # Предвычисляем длительности KB-клипов:
        # каждый клип кроме последнего удлиняем на t_dur —
        # xfade-переход поглощает это время, итоговая длина видео = длина аудио.
        t_dur = args.transition_duration
        n_valid = len(valid_clips)
        kb_durations = {}  # cid → фактическая длительность KB-клипа
        for i, clip in enumerate(valid_clips):
            base = clip['endTime'] - clip['startTime']
            is_last = (i == n_valid - 1)
            kb_durations[clip['id']] = base if is_last else base + t_dur

        # Структура: clip_id → (path, duration)  уже готовые
        kb_ready = {}
        to_process = []  # список клипов, которые нужно обработать

        for clip in valid_clips:
            cid = clip['id']
            duration = kb_durations[cid]
            out_path = temp_dir / f'kb_{cid:04d}.mp4'

            if not args.force_reprocess and out_path.exists():
                if out_path.stat().st_size > 10_000:
                    actual = get_video_duration(out_path)
                    if abs(actual - duration) < 0.5:
                        logger.debug(f"Clip {cid}: уже готов")
                        kb_ready[cid] = (out_path, duration)
                        continue

            to_process.append(clip)

        print(f"\n   ✅ Готовых: {len(kb_ready)}")
        print(f"   🔄 Требуют обработки: {len(to_process)}")

        if to_process:
            print()
            with tqdm(total=len(to_process), desc="Ken Burns", unit="клип") as pbar:
                for clip in to_process:
                    cid = clip['id']
                    duration = kb_durations[cid]
                    out_path = temp_dir / f'kb_{cid:04d}.mp4'
                    img_path = image_map[cid]

                    build_ken_burns_clip(
                        image_path=img_path,
                        output_path=out_path,
                        duration=duration,
                        clip_id=cid,
                        out_w=out_w, out_h=out_h,
                        fps=args.fps,
                        encoder_type=encoder_type,
                        codec=codec,
                        bitrate=args.bitrate,
                    )
                    kb_ready[cid] = (out_path, duration)
                    pbar.update(1)

        # Собираем упорядоченный список
        ordered_files    = []
        ordered_durations = []
        for clip in valid_clips:
            cid = clip['id']
            path, dur = kb_ready[cid]
            ordered_files.append(str(path))
            ordered_durations.append(dur)

        print(f"\n✅ Ken Burns клипов готово: {len(ordered_files)}")

        # ===================================================================
        # ЭТАП 3: XFADE СКЛЕЙКА
        # ===================================================================
        print("\n" + "=" * 80)
        print("🔗 ЭТАП 3: XFADE СКЛЕЙКА")
        print("=" * 80)
        print()

        concat_video = temp_dir / 'concat_video.mp4'

        concat_with_xfade(
            clip_files=ordered_files,
            durations=ordered_durations,
            t_dur=args.transition_duration,
            output_file=concat_video,
            encoder_type=encoder_type,
            codec=codec,
            bitrate=args.bitrate,
            display_duration=audio_duration,
        )

        # ===================================================================
        # ЭТАП 4: ЗАМЕНА АУДИО
        # ===================================================================
        print("\n" + "=" * 80)
        print("🎵 ЭТАП 4: ЗАМЕНА АУДИО")
        print("=" * 80)

        pre_encoded_audio = temp_dir / 'narration_aac.m4a'

        print("   Шаг 1/2: WAV → AAC...")
        cmd_aac = [
            'ffmpeg', '-y', '-i', str(audio_file),
            '-c:a', 'aac', '-b:a', '192k', str(pre_encoded_audio)
        ]
        run_ffmpeg_with_progress(cmd_aac, audio_duration, "AAC кодирование")
        logger.info("Аудио закодировано")

        print("   Шаг 2/2: Сборка видео + аудио...")
        cmd_mux = [
            'ffmpeg', '-y',
            '-i', str(concat_video),
            '-i', str(pre_encoded_audio),
            '-map', '0:v', '-map', '1:a',
            '-c:v', 'copy', '-c:a', 'copy',
            '-shortest',
            args.output
        ]
        run_ffmpeg_with_progress(cmd_mux, audio_duration, "Сборка")
        logger.info(f"Готово: {args.output}")

        try:
            pre_encoded_audio.unlink()
        except Exception:
            pass

        # ===================================================================
        # ЭТАП 5: ОЧИСТКА
        # ===================================================================
        ask_delete_temp_folder(temp_dir)

        # ФИНАЛ
        final_size = get_file_size_mb(args.output)
        print("\n" + "=" * 80)
        print("✅ ГОТОВО!")
        print("=" * 80)
        print(f"\n📹 Видео: {args.output}")
        print(f"   • Разрешение: {out_w}×{out_h}")
        print(f"   • FPS: {args.fps}")
        print(f"   • Битрейт: {args.bitrate}")
        print(f"   • Кодек: {codec} ({encoder_type.upper()})")
        print(f"   • Размер: {final_size:.0f} MB")
        print(f"\n🎵 Озвучка: {audio_file}")
        print(f"📝 Лог-файл: {log_file}")
        print("=" * 80)

        logger.info("="*80)
        logger.info("СКРИПТ ЗАВЕРШЁН УСПЕШНО")
        logger.info("="*80)

    except Exception as e:
        logger.critical("КРИТИЧЕСКАЯ ОШИБКА!")
        logger.critical(f"{e}")
        logger.critical(traceback.format_exc())
        print(f"\n❌ КРИТИЧЕСКАЯ ОШИБКА: {e}")
        print(f"📝 Подробности в лог-файле: {log_file}")
        sys.exit(1)


if __name__ == '__main__':
    main()
