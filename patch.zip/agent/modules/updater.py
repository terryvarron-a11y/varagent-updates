"""
updater.py — Проверка и установка обновлений VARAGENT с GitHub
Версия: 2026.03.24-fix
"""
import hashlib
import json
import ssl
import sys
import urllib.request
import urllib.error
import zipfile
import io
from pathlib import Path
from typing import Optional

GITHUB_REPO      = 'terryvarron-a11y/varagent-updates'
VERSION_JSON_URL = f'https://raw.githubusercontent.com/{GITHUB_REPO}/main/version.json'
VERSION_API      = f'https://api.github.com/repos/{GITHUB_REPO}/contents/version.json'
PATCH_URL        = f'https://raw.githubusercontent.com/{GITHUB_REPO}/main/patch.zip'

SKIP_ON_INSTALL = {'projects/', '.env', 'agent/.env', 'publisher.py'}

# Keys that must exist in agent/.env — added with defaults if missing.
# Order matters: each entry is (KEY, default_value, optional_comment_above).
_ENV_REQUIRED = [
    ('VEONONSTOP_API_KEY_3',  '',     '# VeoNonStop Key3 (optional)'),
    ('VEONONSTOP_KEY3_NAME',  'Key3', None),
    ('VEONONSTOP_API_KEY_4',  '',     '# VeoNonStop Key4 (optional)'),
    ('VEONONSTOP_KEY4_NAME',  'Key4', None),
    ('VEONONSTOP_API_BASE',   'https://veononstop.org/api/v1', '# VeoNonStop base URL per key (empty = use VEONONSTOP_API_BASE)'),
    ('VEONONSTOP_API_BASE_2', '', None),
    ('VEONONSTOP_API_BASE_3', '', None),
    ('VEONONSTOP_API_BASE_4', '', None),
    ('VEONONSTOP_MAX_DOWNLOADS', '12', '# Concurrent finished-video downloads (relay bandwidth cap)'),
    ('VEONONSTOP_USAGE_TIMEOUT', '30', '# /account/usage read timeout (s)'),
    ('VEONONSTOP_USAGE_RETRIES', '1', '# /account/usage transient retries'),
    ('VEONONSTOP_USAGE_RETRY_DELAY', '1.5', '# /account/usage retry backoff (s)'),
    ('VEONONSTOP_USAGE_FAIL_SOFT_ERRORS', '1', '# Usage poll errors before fail-soft'),
    ('SYNTHID_CLEAN_ENABLED', 'false',    '# SynthID image watermark removal (inflight, per-image)'),
    ('SYNTHID_STRENGTH',      'moderate', None),
    ('SYNTHID_VERSION',       'v1',       None),
    ('SYNTHID_SAVE_ORIG',          'false',  None),
    ('VEONONSTOP_RECAPTCHA_DELAY', '8.0',   '# reCAPTCHA retry base delay (s). Chrome: 3.0 | Dolphin+free proxy: 8.0 | Residential: 3.0'),
    ('VEONONSTOP_RECAPTCHA_JITTER','3.0',   None),
    ('VEONONSTOP_MAX_TIMEOUT_RETRIES', '5', '# Max server-timeout retries per clip before counting as failed attempt'),
    ('AUDIO_CLEAN_ENABLED',   'false',    '# Audio AI fingerprint removal (disabled)'),
    ('AUDIO_CLEAN_LEVEL',     'moderate', None),
    ('ASSEMBLYAI_SPEECH_MODELS', 'universal-3-pro,universal-2', '# AssemblyAI speech models (fallback chain)'),
    ('TTS_API_KEY_VOICEGEN', '', '# Voicegen TTS key (api.qw1voicegencore.pro)'),
    ('TTS_VOICEGEN_BASE_URL', 'https://api.qw1voicegencore.pro/api/v1', None),
    ('TTS_VOICEGEN_ENGINE', 'elevenLabsV3', '# Voicegen engine'),
    ('TTS_VOICEGEN_STABILITY', '0.5', None),
    ('TTS_VOICEGEN_CHUNK_SIZE', '1200', None),
    ('TTS_VOICEGEN_DELAY_BETWEEN_CHUNKS', '0.5', None),
    ('TTS_VOICEGEN_THREAD_COUNT', '10', None),
    ('KIE_AI_API_KEY', '', '# Kie.ai API key (image remix)'),
    ('FASTGEN_API_KEY_BACKUP', '', '# FastGen backup API key'),
    ('FASTGEN_API_KEY_3', '', '# FastGen Key3 (optional)'),
    ('FASTGEN_API_KEY_4', '', '# FastGen Key4 (optional)'),
    ('FASTGEN_MAX_PARALLEL_2', '10', '# FastGen Key2 max workers'),
    ('FASTGEN_MAX_PARALLEL_3', '10', '# FastGen Key3 max workers'),
    ('FASTGEN_MAX_PARALLEL_4', '10', '# FastGen Key4 max workers'),
    ('FASTGEN_QUOTA_FALLBACK_VEONONSTOP', 'on',
     '# FastGen ImageGen: hourly quota gone on all keys -> remap the rest to VeoNonStop Banana Pro (on|off). No live VeoNonStop image quota -> wait for FastGen hourly reset'),
    ('VEONONSTOP_QUOTA_FALLBACK_FASTGEN', 'on',
     '# VeoNonStop ImageGen: daily image quota gone -> switch to a spare VeoNonStop key with real quota, otherwise hand the rest to FastGen (on|off)'),
    ('VEONONSTOP_BANANA_MODEL_CHAIN', 'GEM_PIX_2,NARWHAL,HARBOR_SEAL',
     '# Per-clip model retry order on ALL_COOKIES_EXHAUSTED_FOR_MODEL (service-side cookie pool per model, not our key quota)'),
    ('DIRECTOR_BACKEND', 'gpt', '# Director backend (gemini or gpt)'),
    ('GPT_MODEL', 'gpt-5.4', None),
    ('GPT_PROVIDER', 'openai', '# GPT provider: openai (Codex auth) | deepseek | openrouter | codex_reseller | gpt_nexus | meta_muse (direct chat API)'),
    ('DEEPSEEK_API_KEY', '', '# DeepSeek API key — needed when GPT_PROVIDER=deepseek'),
    ('DEEPSEEK_MODEL', 'deepseek-v4-flash', '# DeepSeek model: deepseek-v4-flash | deepseek-v4-pro'),
    ('OPENROUTER_API_KEY', '', '# OpenRouter API key — needed when GPT_PROVIDER=openrouter'),
    ('OPENROUTER_MODEL', 'openrouter/free', '# OpenRouter model: openrouter/free (auto), qwen/qwen3-coder:free, etc'),
    ('OPENROUTER_WEB_SEARCH', 'disabled', '# OpenRouter web search: enabled (:online) | disabled'),
    ('CODEX_RESELLER_URL', 'https://ai.ailink1.com/v1/chat/completions', '# Codex/GPT reseller OpenAI-compatible endpoint'),
    ('CODEX_RESELLER_API_KEY', '', '# Codex/GPT reseller API key'),
    ('CODEX_RESELLER_MODEL', 'gpt-5.6-terra', '# Codex/GPT reseller model'),
    ('GPT_NEXUS_URL', 'https://ccmaxshop.de5.net/v1/chat/completions', '# GPT Nexus OpenAI-compatible endpoint'),
    ('GPT_NEXUS_API_KEY', '', '# GPT Nexus API key'),
    ('GPT_NEXUS_EXTRA_API_KEYS', '', '# Optional additional GPT Nexus keys'),
    ('GPT_NEXUS_MODEL', 'gpt-5.5', '# GPT Nexus model'),
    ('GPT_NEXUS_USER_AGENT', 'codex_cli_rs/latest', '# Nexus gateway client identity'),
    ('META_MUSE_URL', 'https://api.meta.ai/v1/chat/completions', '# Meta Muse Spark OpenAI-compatible text endpoint'),
    ('META_MUSE_API_KEY', '', '# Meta Muse API key'),
    ('META_MUSE_MODEL', 'muse-spark-1.2-contributor', '# Approved Meta Muse Contributor model'),
    ('META_MUSE_MAX_TOKENS', '96000', '# Meta Muse reserve: reasoning and visible completion share this output budget'),
    ('CLIPROXY_BASE_URL', 'http://localhost:8317/v1/chat/completions', '# CLIProxyAPI local proxy → Gemini Pro (Antigravity OAuth). Director: GPT_PROVIDER=cliproxy'),
    ('CLIPROXY_API_KEY', 'varagent-cliproxy-local', '# Local proxy auth key (matches api-keys in ~/.cli-proxy-api/config.yaml). NOT an external secret'),
    ('CLIPROXY_MODEL', 'gemini-3.1-pro-low', '# CLIProxyAPI model (Gemini 3.1 Pro via Antigravity)'),
    ('CHAT_REASONING_LEVEL', 'medium', '# Reasoning for direct chat director: off|low|medium|high|max'),
    ('CHAT_MAX_TOKENS', '64000', '# Max output tokens per chat request (Pass2 chunk). DeepSeek max=64K'),
    ('PASS2_EXTERNALIZE_NEGATIVE', '1', '# Pass2: externalize NEGATIVE block from model output (append by script). 1=on 0=off'),
    ('PASS2_EXTERNALIZE_REFMATCH', '1', '# Pass2: externalize ref hard-match signature (append by script to first token). 1=on 0=off'),
    ('PASS2_EXTERNALIZE_STYLE', '1', '# Pass2: externalize STYLE block from model output (append by script). 1=on 0=off'),
    ('STYLE_EXTRACT_MODE', 'neuro', '# How to find style/negative blocks: neuro (LLM, any SG) | regex (anchors) | off'),
    ('STYLE_EXTRACT_BACKEND', '', '# Neuro-extract backend: gpt_nexus|codex_reseller|deepseek|openrouter|meta_muse|gemini|claude_api (empty=auto-pick)'),
    ('STYLE_EXTRACT_MODEL', '', '# Model slug for neuro-extract (empty=provider default)'),
    ('GPT_PASS2_CHUNK_SIZE', '150', None),
    ('GPT_PASS2_PARALLEL', '6', None),
    ('GPT_REWRITE_TIMEOUT', '90', '# Codex rewrite per-call timeout (s) — prevents pipeline stall on hung rewrite'),
    ('YT_PACK_GPT_TIMEOUT', '600', '# YT Packer Codex timeout (s) — big multi-language prompts need 10 min'),
    ('GPT_HIGH_DEMAND_COOLDOWN', '90', '# Cooldown (s) before retry when OpenAI returns "high demand" / Reconnecting...'),
    ('REWRITE_MODEL', 'gemini:gemini-2.5-flash-lite', '# Rewrite model (provider:model) — flash-lite has 1000 RPD free-tier vs 20 on flash'),
    ('REMIX_ENGINE', 'grok', '# Remix engine (grok, kieai, flower, openai or off)'),
    ('VEONONSTOP_REF_MODE', 'name_match', '# Ref mode: name_match (by prompt names) or use_all (all refs on every prompt)'),
    ('VEONONSTOP_FAST_CENSOR', 'off', '# Fast censor bypass: off | after_rewrites | ultrafast'),
    ('VEONONSTOP_IMAGE_UPSCALE', 'off', '# VeoNonStop image upscale: off | 2K | 4K'),
    ('VEONONSTOP_VIDEO_UPSCALE', 'false', '# VeoNonStop video upscale: true|false'),
    ('VEONONSTOP_MAX_RETRIES', '5', '# VeoNonStop max retries per task'),
    ('VEONONSTOP_MAX_SILENT_CYCLES', '5', '# VeoNonStop max silent poll cycles before giving up'),
    ('PIPELINE_VISLIDE_INTERVAL', '3', '# Vislide mode: seconds per slide'),
    ('YT_PACK_COVER_PROVIDER', 'fastgen', '# YT pack cover provider: fastgen | veononstop'),
    ('VIDEO_FPS', '25', '# Concat output FPS'),
    ('CONCAT_BITRATE', '10M', '# Concat output video bitrate'),
    ('PIPELINE_TRANSITIONS', 'false', '# Переходы между клипами (dip-to-X): true|false (опция, дефолт выкл)'),
    ('PIPELINE_TRANSITION_DURATION', '0.5', '# Длительность перехода в секундах'),
    ('PIPELINE_TRANSITION_STYLES', 'fade', '# Стиль(и) перехода через запятую (fade,wipeleft,dissolve,...)'),
    ('PIPELINE_ZOOM_STYLES', 'in-center', '# Ken Burns zoom-стиль(и): in-center (как было)|out-left|... через запятую'),
    ('VISION_CHECK_MODEL', 'gemini-2.5-flash-lite', '# Gemini model for vision_checks (image safety scans) — flash-lite: 1000 RPD free-tier'),
    ('VISION_API_KEY', '', '# Free-tier Gemini key for vision_checks + rewrite (paid quota NOT touched)'),
    ('GEMINI_API_KEY_FREE', '', '# Free-tier fallback for VISION_API_KEY (paid GEMINI_API_KEY intentionally not used)'),
    ('STORY_MODE', 'off', '# Chain mode: off (independent) | batch (morph imggen pairs) | morph (one chain) | chain (LLM-decided chains)'),
    ('CHAIN_IMGGEN_HEADS_ONLY', '1', '# Gen images only for chain heads (skip extends) — saves ~85% imggen'),
    ('VIDEO_EXTEND_FRAME_OFFSET', '0.5', '# Seconds from end to extract last frame (ffmpeg -sseof offset)'),
    ('VIDEO_EXTEND_TRIM_FRAMES', '1', '# video_concat.py: skip N first frames of extend clips (fps-independent via select filter)'),
    ('VIDEO_EXTEND_MUTE_AUDIO', '1', '# Mute audio for extend clips (VEO sound artifacts on each extend start)'),
    ('VIDEO_EXTEND_MAX_CHAIN', '10', '# Soft safety net: max clips in one chain before forced break (0=unlimited)'),
    ('CHAIN_CASCADE_RECOVERY', '1', '# Cascade recovery: regen prev clip on fail instead of immediate force break'),
    ('CHAIN_MAX_SAME_CLIP_FAILS', '3', '# Max fails of same clip before forced sub-chain head (prevents infinite loop)'),
    ('USATAYAI_GENERATOR_BRIDGE_MANIFEST', '', '# Generator bridge: delegate imggen/video to external app (e.g. Usataya). Empty=native VARAGENT.'),
    ('USATAYAI_BRIDGE_MANIFEST', '', '# Final bridge: post-concat processing (subtitles ASS, watermarks, logo). Empty=plain audio mux.'),
    # Real Photo Stage (archival photo/video insertion between Director and ImgGen)
    ('REAL_PHOTO_ENABLED',      'false', '# Real Photo stage: replace part of AI clips with archival photos/videos (off by default)'),
    ('REAL_PHOTO_RATIO_TARGET', '0.40',  '# Target % of clips to replace (0.0..1.0)'),
    ('REAL_PHOTO_RATIO_MIN',    '0.30',  '# Hard floor for replacement %'),
    ('REAL_PHOTO_RATIO_MAX',    '0.55',  '# Hard ceiling for replacement %'),
    ('REAL_PHOTO_EPF_BRIDGE',   '0',     '# Automatically run Extreme Picture Finder for selected Real Photo queries'),
    ('REAL_PHOTO_EPF_EXE',      '',      '# Optional EPF.exe override. Empty = auto-detect'),
    ('REAL_PHOTO_EPF_DATA_DIR', '',      '# Optional EPF data folder override. Empty = auto-detect'),
    ('REAL_PHOTO_EPF_ENGINES',  'google,bing', '# Comma-separated EPF image-search engines'),
    ('REAL_PHOTO_EPF_CANDIDATES', '12',  '# Candidate downloads per Real Photo clip'),
    ('REAL_PHOTO_EPF_SEARCH_TIMEOUT', '180', '# Max seconds to wait for each EPF search'),
    ('REAL_PHOTO_EPF_DOWNLOAD_URL', 'https://drive.google.com/file/d/1xDYIqq6SKQDBEKJKaa9U_mB10I8nfZsy/view?usp=sharing', '# Google Drive URL for the verified VarAgent EPF portable bundle'),
    ('REAL_PHOTO_EPF_DOWNLOAD_SHA256', 'C3AE2A7F574511F915E66C6C717372BE3AE58B01331D4EA3C3836F4843489A5F', '# Required EPF bundle SHA-256'),
    ('REAL_PHOTO_VISION_PROVIDER', 'gemini', '# Vision selector: gemini|gpt_nexus|cliproxy|deepseek|openrouter|claude_api|codex_reseller'),
    ('REAL_PHOTO_VISION_MODEL', 'gemini-2.5-flash', '# Vision model used to choose one EPF candidate per clip'),
    ('REAL_PHOTO_START_SEC',    '15',    '# Archival photos legit only from this second onward (intro hook not marked). 0 = off. Added once, your value is kept on updates'),
    ('REAL_PHOTO_SEARCH_DEPTH', '6',     '# How many records/articles to probe per archival source before next source in cascade (Wikipedia = N articles, pageimage each). Yandex exempt.'),
    ('CLIPROXY_REQUIRE_PROXY',  'true',  '# Require proxy when adding a CLIProxyAPI Gemini account. false = allow no-proxy (own VPN)'),
    ('CODEX_PROXY',             '',      '# Optional HTTP(S) proxy for codex.exe traffic (geo-block workaround). Format: http://user:pass@host:port. Empty = direct'),
    ('CLAUDE_PROXY',            '',      '# Optional HTTP(S) proxy for Claude Code CLI traffic. Empty = direct'),
    ('PASS1_CHUNK_ENABLED',     'false', '# Chunked Pass 1 for chat directors (DeepSeek/OpenRouter/CLIProxy): long audio is split into windows, plans stitched'),
    ('PASS1_CHUNK_MINUTES',     '20',    '# Pass 1 chunk window size, minutes'),
    ('PASS1_PARALLEL',          '1',     '# Parallel Pass 1 chunk requests (1 = sequential)'),
    ('SUBTITLE_PHRASE_LEN',     '50',    '# Subtitle phrase split length (see SUBTITLE_PHRASE_UNIT)'),
    ('SUBTITLE_PHRASE_UNIT',    'chars', '# Subtitle phrase unit: chars | words'),
    ('REAL_PHOTO_SOURCES',      'wikimedia,yandex,nasa,loc,met,getty,europeana,smithsonian,archive',
        '# Archive sources, comma-separated. Wiki(article-pageimage)/Yandex(web, no key)/NASA/LoC/Met/Getty/Archive = no key. Europeana/Smithsonian = optional free keys.'),
    ('REAL_PHOTO_YANDEX_EXCLUDE', '-нейросеть -нейро -ии -ai -midjourney -render -3d -рендер',
        '# Yandex minus-flags: exclude AI/3D-generated from results (engravings/maps/schematics kept)'),
    ('REAL_PHOTO_CODEX_MODEL',  'gpt-5.5', '# Codex model for clip selection / keyframe pick'),
    ('REAL_PHOTO_PROMPT_PROVIDER', 'codex',
        '# Real Photo query prompter (independent of director): codex|gpt_nexus|codex_reseller|cliproxy|deepseek|openrouter|meta_muse. chat-providers are more reliable than Codex CLI'),
    ('REAL_PHOTO_PROMPT_MODEL', '',
        '# Prompter model. Empty = provider default (CLIPROXY_MODEL / DEEPSEEK_MODEL / ...)'),
    ('ENTITY_OVERLAY_MODEL', '',
        '# Entity-card detection model. Empty = provider default'),
    ('YT_PACK_BACKEND', 'gemini',
        '# YT Packer operator: gemini|codex|gpt_nexus|codex_reseller|cliproxy|deepseek|openrouter|meta_muse|claude_api (empty = by model name)'),
    ('EUROPEANA_API_KEY',       '', '# Optional: free key from https://pro.europeana.eu/page/get-api'),
    ('SMITHSONIAN_API_KEY',     '', '# Optional: free key from https://api.data.gov/signup/'),
    ('RIJKSMUSEUM_API_KEY',     '', '# Optional: free key from https://data.rijksmuseum.nl'),
    # Smooth zoom для статичных кадров (Ken Burns в video_concat.py через scale eval=frame + crop)
    ('ZOOM_AMOUNT', '0.10', '# Smooth zoom amplitude per clip: 0.05 / 0.10 / 0.15 / 0.20'),
    ('ZOOM_CURVE',  'linear', '# Zoom curve: linear / constant_speed / ease_out'),
    # FastGen v5 endpoint (named refs binding по [name_ref] токенам в промпте).
    # 1 = использовать /v5/generations для flow/openai/grok/flower image + flow-ultra video + preflight.
    # 0 = legacy v4 (default — пока v5 в обкатке).
    ('REAL_PHOTO_PROMPT_FALLBACK', '1', '# Pass2 пишет промпты и для real_photo (страховка): провал/таймаут загрузки -> догенерация. 1=on'),
    ('REAL_PHOTO_WAIT_TIMEOUT', '1800', '# Макс время фоновой загрузки real_photo (s); дедлайн=MIN(конец генерации, это)'),
    # --- INFOGRAPHIC (separate AI still route) ---
    ('INFOGRAPHIC_ENABLED', 'false', '# Enable director-selected infographic stills'),
    ('INFOGRAPHIC_RATIO_TARGET', '0.15', '# Target share of clips for infographics (0.0..1.0)'),
    ('INFOGRAPHIC_RATIO_MAX', '0.25', '# Hard ceiling for infographic share (0.0..1.0)'),
    ('INFOGRAPHIC_IMG_PROVIDER', 'fastgen', '# Dedicated infographic image provider: fastgen | veononstop'),
    ('INFOGRAPHIC_FASTGEN_MODEL', 'GEM_PIX', '# FastGen model for infographic clips'),
    ('INFOGRAPHIC_VEONONSTOP_MODE', 'imagen', '# VeoNonStop image mode for infographic clips'),
    ('INFOGRAPHIC_VEONONSTOP_BANANA_MODEL', 'GEM_PIX_2', '# Banana model for infographic clips'),
    ('INFOGRAPHIC_STATIC_CONCAT', 'true', '# Do not animate infographic stills in concat'),
    # --- MUSIC (Pass 3 — Suno) ---
    # --- STOCK (Pexels / Pixabay / own folder) ---
    ('STOCK_ENABLED', 'false', '# Stock footage/photos instead of AI generation: true|false'),
    ('STOCK_SOURCES', 'local,pexels,pixabay', '# Stock sources: local (own folder) | pexels | pixabay. Clips split evenly'),
    ('STOCK_LIBRARY_DIR', '', '# Own footage folder (scanned with subfolders). Empty = source off'),
    ('STOCK_RATIO_TARGET', '0.30', '# Share of ALL clips marked for stock by the director'),
    ('STOCK_VIDEO_SHARE', '0.70', '# Of stock clips: share of video, rest = photo'),
    ('STOCK_MUTE_AUDIO', 'true', '# Strip footage audio. Keep ON: audio is the main Content ID claim channel'),
    ('STOCK_EXCLUDE_AI', 'true', '# Drop AI-generated stock (Pixabay reports it; Pexels has no such flag)'),
    ('STOCK_CLIP_START_SEC', '0', '# Cut footage from this second. 0 = from the start'),
    ('STOCK_CLIP_START_JITTER', 'false', '# Randomize start point (similar footage → different first frames)'),
    ('STOCK_CLIP_START_JITTER_SEC', '2', '# Jitter range in seconds (+/-)'),
    ('STOCK_PROMPT_FALLBACK', 'true', '# Nothing found -> clip goes to normal AI generation'),
    ('STOCK_WAIT_TIMEOUT', '1800', '# Max background download time (s). Deadline = MIN(this, pipeline ready); concat never waits'),
    ('STOCK_PROMPT_PROVIDER', '', '# Stock prompter (queries + own-library match): empty=auto | gpt_nexus|codex_reseller|cliproxy|deepseek|openrouter|meta_muse|claude_api|gpt|claude_code'),
    ('STOCK_PROMPT_MODEL', '', '# Stock prompter model. Empty = provider default'),
    ('STOCK_PROXY_URL', '', '# Optional proxy for stock APIs'),
    ('PEXELS_API_KEY', '', '# Free key: https://www.pexels.com/api/ (25000/month)'),
    ('PEXELS_API_KEY_2', '', '# Optional key pool for rotation'),
    ('PIXABAY_API_KEY', '', '# Free key: log in, then open https://pixabay.com/api/docs/ (key is shown there)'),
    ('PIXABAY_API_KEY_2', '', '# Optional key pool for rotation'),
    ('VARAGENT_MUSIC_ENABLED', '0', '# Pipeline tab: background music stage (1/0)'),
    ('VARAGENT_MUSIC_REVIEW_GUI', '0', '# Pipeline tab: review generated music in the GUI before concat (1/0)'),
    ('MUSIC_TRACK_RETRIES', '1', '# Repeat a failed Suno track generation N times before giving up'),
    ('MUSIC_CAPTCHA_COOLDOWN', '600', '# Wait, seconds, after Cloudflare captcha before retrying music generation'),
    ('MUSIC_CAPTCHA_RETRIES', '2', '# How many times to wait out the captcha and retry'),
    ('MUSIC_PROVIDER', 'suno', '# Music source: suno (generate) | local_library (your own folder). Old: safe_stock/pixabay/pexels = local_library'),
    ('MUSIC_LIBRARY_DIR', '', '# Local Sound Library folder (own music, scanned with subfolders). Empty = look only in project music_stock/'),
    ('MUSIC_DIRECTOR_BACKEND', '', '# Music director backend: empty=inherit, gpt(Codex)|gpt_nexus|codex_reseller|deepseek|openrouter|meta_muse|cliproxy|claude_code|claude_api'),
    ('MUSIC_CHAT_MODEL', '', '# Music model slug for a direct chat backend (empty=provider default)'),
    ('SUNO_COOKIE_BROWSER', 'firefox', '# Browser for Suno cookies: firefox|edge|chrome|opera|brave (Chrome v127+ ABE not readable)'),
    ('SUNO_MODEL', 'chirp-fenix', '# Suno model: chirp-fenix (v5.5) | chirp-v4 | chirp-v3-5'),
    ('SUNO_PARALLEL', '1', '# Suno orchestrator parallel threads (1=sequential, max 2-3 vs rate-limit)'),
    ('SUNO_INTER_TRACK_SLEEP', '30', '# Sleep (s) between sequential Suno generations (anti 422 rate-limit)'),
    ('MUSIC_DEFAULT_VOLUME_DB', '-21', '# Music loudness in final mix (positive 16 = -16 dB)'),
    ('MUSIC_DUCKING_DB', '-5', '# Sidechain ducking: how many dB music is dipped under the voice'),
    ('MUSIC_CROSSFADE_MS', '2000', '# Crossfade between adjacent tracks (ms)'),
    ('MUSIC_MIN_TRACK_DURATION', '120', '# Min music track duration (s)'),
    ('MUSIC_MAX_TRACK_DURATION', '240', '# Max music track duration (s, Suno ~3.5 min)'),
    ('MUSIC_MAX_TRACKS', '10', '# Max music tracks in plan'),
    ('MUSIC_FALLBACK_ON_SUNO_FAIL', 'false', '# Do not replace failed Suno music with synthetic noise'),
    ('MUSIC_FALLBACK_MODE', 'off', '# off | ffmpeg_ambient (explicit technical noise-bed opt-in only)'),
    # --- CLAUDE director/music backend (Claude CLI + Claude Nexus API) ---
    ('CLAUDE_MODEL', 'sonnet', '# Claude Code model alias: sonnet | opus | or full model name'),
    ('CLAUDE_CODE_USE_SUBSCRIPTION', 'true', '# true=use logged-in Claude Pro/Max CLI (drop ANTHROPIC_API_KEY from child)'),
    ('CLAUDE_RESELLER_ANTHROPIC_URL', 'https://ccmaxshop.de5.net/v1/messages', '# Claude Nexus native Anthropic Messages endpoint'),
    ('CLAUDE_RESELLER_ANTHROPIC_API_KEY', '', '# Claude Nexus API key'),
    ('CLAUDE_RESELLER_ANTHROPIC_EXTRA_API_KEYS', '', '# Optional additional Claude Nexus keys'),
    ('CLAUDE_RESELLER_ANTHROPIC_MODEL', 'claude-sonnet-4-6', '# Default Claude Nexus model'),
    ('CLAUDE_API_MODEL', '', '# Claude Nexus model override; old claude_api name kept for preset compatibility'),
    # --- ENTITY OVERLAY (Wikipedia person/place cards over video) ---
    ('ENTITY_OVERLAY_ENABLED', 'false', '# Entity cards over video (Wikipedia persons/places): true|false'),
    ('ENTITY_OVERLAY_BACKEND', 'auto', '# Entity detector: auto | gpt_nexus | codex_reseller | direct chat providers | gpt | regex'),
    ('ENTITY_OVERLAY_MAX', '20', '# Max entity cards (0=unlimited)'),
    ('ENTITY_OVERLAY_PARALLEL', '4', '# How many cards to download at once (1 = one by one, old behavior)'),
    ('ENTITY_OVERLAY_WAIT_TIMEOUT', '1800', '# Max background card prep time (s). Deadline = MIN(this, generation done); concat never waits'),
    ('ENTITY_OVERLAY_CONCAT_DOWNLOAD', '', '# 1 = let concat download cards itself (only for manual concat runs without the pipeline)'),
    ('ENTITY_OVERLAY_HOLD_SEC', '4.2', '# Entity card display duration (s)'),
    ('ENTITY_OVERLAY_MIN_GAP_SEC', '24', '# Min gap between entity cards (s)'),
    ('ENTITY_OVERLAY_PROVIDERS', 'wikipedia,yandex', '# Image providers for entity cards'),
    ('ENTITY_OVERLAY_WIKI_LANGS', 'ru,en', '# Wikipedia languages for entity lookup'),
    # --- CONCAT QUEUE (background sequential tail: music + concat) ---
    ('CONCAT_QUEUE_ENABLED', 'true', '# Pipeline tail (music+concat) goes to background queue; generation takes next file immediately. false = old inline behavior'),
]

# Ключи, которые нужно обновить если значение устарело: (key, old_value, new_value)
_ENV_UPGRADES = [
    ('ASSEMBLYAI_SPEECH_MODELS', 'universal-3-pro', 'universal-3-pro,universal-2'),
    # Rewrite: flash (20 RPD free-tier) → flash-lite (1000 RPD). Users on gpt:gpt-5.4-mini keep their gpt rewriter (NOT forced back).
    ('REWRITE_MODEL', 'gemini:gemini-2.5-flash', 'gemini:gemini-2.5-flash-lite'),
    # Theme swap: zombovar.json merged into default.json (ClaudeVAR is now default)
    ('VARAGENT_THEME', 'zombovar', 'default'),
]

# Принудительная перезапись ключей (key, new_value) — ПУСТО ПО ПОЛИТИКЕ:
# если юзер задал значение в .env (свой ключ, свою модель) — апдейт его НЕ ТРОГАЕТ.
# Дефолты для свежеустановленных юзеров приходят через _ENV_REQUIRED.
# Ротация конкретных значений (например, dev-ключ забанили) — через _ENV_UPGRADES
# с парой (key, old_known_value, new_value): сработает только при точном совпадении строки.
_ENV_FORCE = []

_ENV_SECRET_KEY_MARKERS = ('API_KEY', 'TOKEN', 'SECRET', 'PASSWORD')

def _is_secret_env_key(key: str) -> bool:
    return any(marker in key.upper() for marker in _ENV_SECRET_KEY_MARKERS)

_ENV_FASTGEN_KEY_FIELDS = {'FASTGEN_API_KEY_BACKUP', 'FASTGEN_API_KEY_3', 'FASTGEN_API_KEY_4'}
_ENV_FASTGEN_PARALLEL_FIELDS = {'FASTGEN_MAX_PARALLEL_2', 'FASTGEN_MAX_PARALLEL_3', 'FASTGEN_MAX_PARALLEL_4'}

def _insert_env_lines_after_key(text: str, anchor_keys: set[str], new_lines: list[str]) -> str:
    if not new_lines:
        return text
    lines = text.splitlines()
    insert_at = None
    for i, line in enumerate(lines):
        raw = line.strip()
        if raw and not raw.startswith('#') and '=' in raw:
            key, _, _ = raw.partition('=')
            if key.strip() in anchor_keys:
                insert_at = i + 1
    if insert_at is None:
        insert_at = len(lines)
    lines[insert_at:insert_at] = new_lines
    return '\n'.join(lines) + '\n'

# Regex-миграция значений в .env: (pattern, replacement, human_note)
# Применяется к ВСЕМУ содержимому .env через re.sub. Нужно для коррекции
# значений, которые юзеры могли ввести до фикса (например, localhost → 127.0.0.1
# — чтобы обойти IPv6-перехват Dolphin Anty или похожих локальных серверов).
# Схема тоже форсится в http (у локального desk нет TLS — https ломает запросы).
_ENV_REGEX_MIGRATE = [
    (r'https?://localhost:(3001|3002|3003)/', r'http://127.0.0.1:\1/',
     'localhost->127.0.0.1 + force http for local desk ports (IPv6 bypass, no TLS on desk)'),
    (r'https://127\.0\.0\.1:(3001|3002|3003)/', r'http://127.0.0.1:\1/',
     'force http on 127.0.0.1 local desk ports (no TLS on desk)'),
]

# Загружаем токен из .env если есть (для обхода rate limit)
def _load_github_token(root: Path) -> 'Optional[str]':
    env_file = root / 'agent' / '.env'
    if env_file.exists():
        for line in env_file.read_text(encoding='utf-8').splitlines():
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                k, _, v = line.partition('=')
                if k.strip() == 'GITHUB_TOKEN':
                    return v.strip()
    return None


def _md5(path: Path) -> str:
    h = hashlib.md5()
    h.update(path.read_bytes())
    return h.hexdigest()


def _get_ssl_context():
    """Создает SSL context, совместимый с Mac/Windows/Linux."""
    try:
        # Метод 1: certifi (если доступен) — для Mac с Homebrew Python
        import certifi
        ctx = ssl.create_default_context(cafile=certifi.where())
        return ctx
    except ImportError:
        pass

    try:
        # Метод 2: create_default_context с отключенной проверкой
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    except Exception:
        pass

    # Метод 3: unverified context (последний fallback)
    return ssl._create_unverified_context()


def _fetch(url: str, token: str = None, timeout: int = 15) -> bytes:
    headers = {'User-Agent': 'varagent-updater'}
    if token:
        headers['Authorization'] = f'token {token}'
    req = urllib.request.Request(url, headers=headers)
    ctx = _get_ssl_context()
    return urllib.request.urlopen(req, timeout=timeout, context=ctx).read()


def _fetch_version_json(token: str = None) -> dict:
    """Получает version.json через GitHub API (с токеном для обхода rate limit)."""
    import base64
    headers = {
        'User-Agent': 'varagent-updater',
        'Accept': 'application/vnd.github.v3+json',
    }
    if token:
        headers['Authorization'] = f'token {token}'
    req = urllib.request.Request(VERSION_API, headers=headers)
    ctx = _get_ssl_context()
    d = json.loads(urllib.request.urlopen(req, timeout=15, context=ctx).read())
    return json.loads(base64.b64decode(d['content']))


def check_updates(root: Path) -> dict:
    """
    Проверяет наличие обновлений.

    Returns:
        {
          'available': bool,
          'version': str,
          'changelog': [...],
          'changed_files': [...],   # файлы которые реально изменились у юзера
          'error': str or None,
        }
    """
    token = _load_github_token(root)
    try:
        data = _fetch_version_json(token)
    except Exception:
        # Фоллбэк на raw URL — работает даже если GitHub API недоступен
        # или если старый updater.py сломан (NameError VERSION_API и т.п.)
        try:
            raw = _fetch(VERSION_JSON_URL, token)
            data = json.loads(raw)
        except Exception as e:
            return {'available': False, 'error': str(e)}

    remote_files = data.get('files', {})
    changed = []
    for rel, remote_md5 in remote_files.items():
        local_path = root / rel
        if not local_path.exists():
            changed.append(rel)
        elif _md5(local_path) != remote_md5:
            changed.append(rel)

    return {
        'available': len(changed) > 0,
        'version':   data.get('version', '?'),
        'changelog': data.get('changelog', []),
        'changed_files': changed,
        'requires_restart': data.get('requires_restart', False),
        'error': None,
    }


def install_update(root: Path, progress_cb=None) -> dict:
    """
    Скачивает и устанавливает patch.zip.

    progress_cb(msg: str) — опциональный колбэк для прогресса

    Returns: {'ok': bool, 'installed': [...], 'error': str or None}
    """
    def log(msg):
        if progress_cb:
            progress_cb(msg)

    token = _load_github_token(root)
    requires_restart = False
    version_tag = 'latest'
    expected_patch_sha256 = ''

    try:
        # Сначала загружаем version.json для requires_restart
        log('Загрузка version.json...')
        try:
            data = _fetch_version_json(token)
            requires_restart = data.get('requires_restart', False)
            version_tag = str(data.get('version') or 'latest')
            expected_patch_sha256 = str(data.get('patch_sha256') or '').strip().lower()
        except Exception as ve:
            log(f'Предупреждение: не удалось загрузить version.json ({ve})')

        log('Скачивание патча...')
        # Version query prevents GitHub Raw/CDN from returning the previous patch.zip
        # immediately after a publish that reused the same file name.
        patch_bytes = _fetch(f'{PATCH_URL}?v={version_tag}', token, timeout=60)
        if expected_patch_sha256:
            actual_patch_sha256 = hashlib.sha256(patch_bytes).hexdigest()
            if actual_patch_sha256 != expected_patch_sha256:
                raise RuntimeError(
                    'Контрольная сумма patch.zip не совпала с version.json: '
                    f'{actual_patch_sha256} != {expected_patch_sha256}'
                )

        log('Установка файлов...')
        installed = []
        with zipfile.ZipFile(io.BytesIO(patch_bytes)) as zf:
            for name in zf.namelist():
                # Пропускаем защищённые пути
                if any(name.startswith(s) for s in SKIP_ON_INSTALL):
                    continue
                dest = root / Path(name)  # Path() handles / correctly on all platforms
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(zf.read(name))
                installed.append(name)
                log(f'  {name}')

        log(f'Готово. Установлено файлов: {len(installed)}')
        # Очистка __pycache__ — иначе Python может импортировать старый .pyc
        import shutil
        for cache_dir in root.rglob('__pycache__'):
            try:
                shutil.rmtree(cache_dir)
            except Exception:
                pass
        log('Очистка __pycache__ — OK')
        # patch_env из нового updater.py (файл уже перезаписан из zip,
        # но в памяти ещё старый модуль с устаревшим _ENV_REQUIRED)
        _new_updater = root / 'agent' / 'modules' / 'updater.py'
        if _new_updater.exists():
            _ns = {}
            exec(compile(_new_updater.read_text(encoding='utf-8'), str(_new_updater), 'exec'), _ns)
            _added = _ns['patch_env'](root)
            if _added:
                log(f'Обновлён .env: {", ".join(_added)}')
        else:
            patch_env(root)
        _install_fonts(root, log)
        # Доустановка зависимостей из requirements.txt: раньше updater только копировал
        # файлы, а pip не трогал — новые зависимости (напр. rookiepy/browser-cookie3 для
        # Suno cookie-auth) не появлялись у обновляющихся юзеров, и модуль музыки падал.
        # Теперь после копирования прогоняем pip install -r requirements.txt (быстро, если
        # всё уже стоит; ставит только недостающее/обновлённое). Не валит апдейт при сбое.
        _install_requirements(root, log)
        return {'ok': True, 'installed': installed, 'error': None,
                'requires_restart': requires_restart}

    except Exception as e:
        return {'ok': False, 'installed': [], 'error': str(e)}


def _install_requirements(root: Path, log=None) -> None:
    """pip install -r agent/requirements.txt после обновления файлов.

    Тихо и НЕ фатально: если pip недоступен / нет сети / сбой — логируем и идём
    дальше (обновление файлов уже применено, ломать его из-за pip нельзя)."""
    def _log(m):
        if log:
            log(m)
    req = root / 'agent' / 'requirements.txt'
    if not req.exists():
        return
    try:
        import subprocess as _sp
        _log('Проверка зависимостей (pip install -r requirements.txt)...')
        _cmd = [sys.executable, '-m', 'pip', 'install', '-r', str(req),
                '--disable-pip-version-check', '--prefer-binary',
                '--default-timeout=120', '--retries', '3',
                '--trusted-host', 'pypi.org', '--trusted-host', 'files.pythonhosted.org']
        _p = _sp.run(_cmd, capture_output=True, text=True, encoding='utf-8',
                     errors='replace', timeout=900)
        if _p.returncode == 0:
            _log('Зависимости актуальны.')
        else:
            _tail = (_p.stderr or _p.stdout or '')[-300:]
            _log(f'[WARN] pip install вернул код {_p.returncode} — часть зависимостей могла '
                 f'не установиться. Если модуль музыки/куки не работает, запустите '
                 f'install.bat (Win) или install.command (Mac). {_tail}')
    except Exception as _e:
        _log(f'[WARN] Не удалось запустить pip install ({_e}). При проблемах с зависимостями '
             f'запустите install.bat / install.command.')


def patch_env(root: Path) -> list:
    """
    Добавляет в agent/.env строки для ключей из _ENV_REQUIRED, если они отсутствуют.
    Существующие значения НЕ трогает.

    Returns: список добавленных ключей (пустой если всё уже было).
    """
    env_path = root / 'agent' / '.env'
    if not env_path.exists():
        return []

    try:
        text = env_path.read_text(encoding='utf-8')
    except Exception:
        return []

    # Собираем ключи и их значения
    existing_keys = {}  # key → value
    for line in text.splitlines():
        line = line.strip()
        if line and not line.startswith('#') and '=' in line:
            k, _, v = line.partition('=')
            existing_keys[k.strip()] = v.strip()

    added = []
    extra_lines = []
    fastgen_key_lines = []
    fastgen_parallel_lines = []
    for key, default, comment in _ENV_REQUIRED:
        if key not in existing_keys:
            # Ключа нет — добавляем
            target = extra_lines
            if key in _ENV_FASTGEN_KEY_FIELDS:
                target = fastgen_key_lines
            elif key in _ENV_FASTGEN_PARALLEL_FIELDS:
                target = fastgen_parallel_lines
            if comment:
                target.append(comment)
            target.append(f'{key}={default}')
            added.append(key)
        elif not existing_keys[key] and default and not _is_secret_env_key(key):
            # Ключ есть но пустой, а дефолт непустой — прописываем значение
            import re as _re
            text = _re.sub(
                rf'^({_re.escape(key)}\s*=)\s*$',
                rf'\g<1>{default}',
                text, count=1, flags=_re.MULTILINE
            )
            added.append(f'{key} (filled empty)')

    # Принудительная перезапись ключей
    for key, new_val in _ENV_FORCE:
        if _is_secret_env_key(key):
            continue
        if key in existing_keys and existing_keys[key] != new_val:
            import re as _re
            pattern = _re.compile(rf'^({_re.escape(key)}\s*=).*$', _re.MULTILINE)
            if pattern.search(text):
                text = pattern.sub(rf'\g<1>{new_val}', text)
                added.append(f'{key} (force-updated)')

    # Regex-миграции значений (например, localhost → 127.0.0.1)
    import re as _re
    for _pat, _repl, _note in _ENV_REGEX_MIGRATE:
        _new_text, _n = _re.subn(_pat, _repl, text)
        if _n > 0:
            text = _new_text
            added.append(f'regex-migrate x{_n}: {_note}')

    # Обновляем устаревшие значения
    for key, old_val, new_val in _ENV_UPGRADES:
        if key in existing_keys and existing_keys[key] == old_val:
            import re as _re
            pattern = _re.compile(rf'^({_re.escape(key)}\s*=\s*){_re.escape(old_val)}\s*$', _re.MULTILINE)
            if pattern.search(text):
                text = pattern.sub(rf'\g<1>{new_val}', text)
                added.append(f'{key} (upgraded)')

    if not added:
        return []

    text = _insert_env_lines_after_key(
        text,
        {'FASTGEN_API_KEY', 'FASTGEN_API_KEY_BACKUP', 'FASTGEN_API_KEY_2', 'FASTGEN_API_KEY_3', 'FASTGEN_API_KEY_4'},
        fastgen_key_lines,
    )
    text = _insert_env_lines_after_key(
        text,
        {'FASTGEN_MAX_PARALLEL', 'FASTGEN_MAX_PARALLEL_2', 'FASTGEN_MAX_PARALLEL_3', 'FASTGEN_MAX_PARALLEL_4'},
        fastgen_parallel_lines,
    )

    # Добавляем остальные новые ключи в конец файла
    if extra_lines:
        if not text.endswith('\n'):
            extra_lines.insert(0, '')
        text = text + '\n'.join(extra_lines) + '\n'

    env_path.write_text(text, encoding='utf-8')
    return added


def _install_fonts(root: Path, log=None):
    """Копирует шрифты из agent/fonts/ в системную папку шрифтов (если ещё не установлены)."""
    import platform
    import shutil

    fonts_dir = root / 'agent' / 'fonts'
    if not fonts_dir.exists():
        return

    system = platform.system()
    if system == 'Windows':
        # Per-user fonts — не требует прав администратора
        dest_dir = Path.home() / 'AppData' / 'Local' / 'Microsoft' / 'Windows' / 'Fonts'
    elif system == 'Darwin':
        dest_dir = Path.home() / 'Library' / 'Fonts'
    else:
        dest_dir = Path.home() / '.local' / 'share' / 'fonts'

    dest_dir.mkdir(parents=True, exist_ok=True)

    for font_file in fonts_dir.glob('*.ttf'):
        dest = dest_dir / font_file.name
        if dest.exists():
            continue
        try:
            shutil.copy2(str(font_file), str(dest))
            if log:
                log(f'  Шрифт установлен: {font_file.name}')
        except Exception as e:
            if log:
                log(f'  Шрифт {font_file.name}: не удалось ({e})')
