"""Quick check: VeoNonStop account slots for key1 and key2 (if set)."""
import os
import sys
import requests
from pathlib import Path
from dotenv import load_dotenv

env_path = Path(__file__).resolve().parent / '.env'
load_dotenv(env_path)


def query_key(api_key: str, label: str):
    try:
        resp = requests.get(
            'https://veononstop.com/api/v1/account/info',
            headers={'X-API-Key': api_key},
            timeout=10,
        )
        if resp.status_code == 200:
            data = resp.json().get('data', resp.json())
            ct   = int(data.get('concurrent_tasks', data.get('max_cookies', 0)))
            plan = data.get('plan', '?')
            return ct, plan
        else:
            return 0, f'http_{resp.status_code}'
    except Exception as e:
        return 0, f'err'


key1 = os.getenv('VEONONSTOP_API_KEY', '')
key2 = os.getenv('VEONONSTOP_API_KEY_2', '')

if not key1:
    print('  [!] VEONONSTOP_API_KEY not set')
    print('total=0')
    sys.exit(0)

ct1, plan1 = query_key(key1, 'Key1')
total = ct1

print(f'  Key1: {ct1} concurrent tasks  ({plan1})')

if key2:
    ct2, plan2 = query_key(key2, 'Key2')
    total += ct2
    print(f'  Key2: {ct2} concurrent tasks  ({plan2})')
    print(f'  ------------------------------------')
    print(f'  Total: {total} concurrent tasks')
else:
    print(f'  (Key2 not configured)')

# Machine-readable lines for bat parsing
print(f'key1={ct1}')
if key2:
    print(f'key2={ct2}')
else:
    print(f'key2=0')
print(f'total={total}')
