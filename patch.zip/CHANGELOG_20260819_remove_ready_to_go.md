# Change log: remove legacy ready_to_go flow

Date: 2026-08-19

## Why

The active GUI pipeline already uses `pipeline_queue/` and passes an explicit
file list. The old `ready_to_go/` scanner and its TTS fallback were obsolete
and could select unrelated scenario files.

## Changes

- Removed the TTS runner fallback that scanned a queue directory.
- TTS runner now requires `--file-list` and processes only the files supplied
  by the GUI.
- Standalone Script -> Audio now copies the selected script to
  `pipeline_queue/` and passes both `--queue-dir` and `--file-list`.
- Removed `ready_to_go/` fallbacks from the GUI source-file picker and
  pipeline start validation.
- Changed the CLI process default queue to `pipeline_queue/`.
- Changed project initialization and the legacy queue module's self-test to
  use `pipeline_queue/`.
- Removed old `ready_to_go/` wording and paths from launchers, documentation,
  publisher exclusions, and the Korshun bridge fallback.
- Kept the scenario parser contract explicit: the whole scenario file is
  spoken; voice/template comes from GUI/preset `TTS_VOICE_ID`.

## Rollback

Restore the files from the matching pre-change snapshot, then sync the source
files from `VARAGENT_API/` to `VARAGENT_API_PORTABLE/`.

The physical `ready_to_go/` directory and its user files were not deleted.
Only active code, launchers, and documentation references were changed.

## Verification

- Compile `varagent.py`, `agent/agent.py`, `agent/modules/queue.py`,
  `agent/modules/tts.py`, and `agent/tools/tts_runner.py`.
- Run the focused GUI save-defaults test.
- Search active source for `ready_to_go` and confirm zero matches.
- Active source files are UTF-8 without BOM. The `Р...С...` text seen in
  PowerShell output was console decoding, not bytes stored in active source.
- Invalid UTF-8 hits found during the audit belong to macOS `._*` metadata,
  caches, or old user project artifacts and are outside active source.

## Follow-up: YouTube Footage source semantics

- Removed the incorrect mixed candidate pool that combined YouTube results
  with files from the local Stock Footage folder.
- Added an explicit source choice: `YouTube через yt-dlp` or
  `Своя папка Stock Footage`.
- YouTube mode performs search, candidate ranking, download, usage spacing,
  and provenance only for YouTube candidates.
- Local mode scans only the configured local folder and never invokes yt-dlp.
- Added `YOUTUBE_SOURCE=youtube` to the configuration defaults.

## Follow-up: Auto Visual Story parallax

- When `Parallax` is enabled in Auto Visual Story, the pipeline waits for
  EPF/stock materialization, collects ready `real_photo` and `stock_photo`
  images, and sends every Nth eligible image to the normal Veo I2V pipeline.
- The VEO route uses the selected editable parallax template and the existing
  retry, fallback, quota, and Skiper behavior.
- YouTube and all video footage remain untouched. All EPF/stock images not
  selected for parallax continue to the normal FFmpeg zoom concat path.
- The Auto Visual Story parallax stage finishes before `PROJECT_DONE`, so the
  GUI cannot start concat before the selected VEO clips are resolved.

## Follow-up: Auto Visual Story scene duration

- Auto Visual Story still locks the clip type to `slideshow`, but no longer
  disables the minimum and maximum scene-duration controls.
- GUI `--clip-min` and `--clip-max` values remain the runtime override after
  slideshow defaults are applied.

## Follow-up: Auto Visual Story live-test hardening

- Director-profile JSON now accepts list fields serialized as JSON strings,
  which Meta Muse returned for `scenes` and `plans`.
- Visual-query prompts now state the mandatory top-level
  `{"plans":[...]}` shape and exact plan count. If a provider returns an
  incomplete batch, the same batch receives one explicit corrective retry;
  a second invalid reply remains a clear error instead of being silently
  assigned to the wrong scenes.
- Source ratios now apply only when their source is enabled. Disabled Stock
  and YouTube cannot steal EPF scenes through stale percentage settings.
- String-form `fallback_queries` and `negative_constraints` are normalized as
  one item, rather than being split into individual characters.
- EPF vision now writes `vision_response.txt` for every clip and
  `vision_error.json` on failure. The selector accepts JSON fenced or wrapped
  in brief prose, but still rejects an unknown candidate filename.
- Live Auto Visual Story verification used Meta Muse
  `muse-spark-1.2-contributor` for scene/narrative/query stages and
  Codex Reseller `gpt-5.6-terra` to choose EPF images. The persisted test
  project reached `final_asset_gate.ok=true` after importing all three images.

## Verification

- Focused mock suites: 29 Auto Visual Story/EPF/parallax tests and 10 YouTube
  routing/source tests passed.
- Live Veo parallax previously generated a real VEO clip through the normal
  I2V route.
- Live YouTube search returned candidates, but media download is still blocked
  upstream by YouTube HTTP 403 / playback-token requirements; that is not
  marked as a passing download test.

## YouTube module replacement: 2026-08-20

- Wrote the full implementation contract to
  `YOUTUBE_MODULE_IMPLEMENTATION_PLAN.md`.
- Replaced the active `youtube_stage.py` runtime with one canonical pipeline:
  planner queries -> licensed discovery -> temporal locator -> fixed candidate
  parts -> preview contact sheet -> Vision ranking by candidate ID -> exact
  range download -> multi-part composition -> provenance/fallback.
- Removed the YouTube-stage local-folder source option. Local footage belongs
  to Stock Footage; the YouTube stage now searches YouTube only.
- Added multi-query discovery with video-ID deduplication.
- Creative Commons policy is applied server-side through
  `videoLicense=creativeCommon`; `any` is explicit and persisted through the
  GUI.
- Added chapters/description/sparse-scan temporal windows and immutable
  candidate parts. Vision cannot invent a timestamp, URL, video ID, or
  duration; it returns a complete candidate-ID permutation.
- Added one contact sheet per scene with start/middle/end frames for each
  candidate, exact-range preview downloads, retries, source-interval
  reservations, multi-part FFmpeg composition, `selection.json`, and
  `provenance.json`.
- Archived the replaced active implementation at:
  `VARAGENT_API/_backup_youtube_license_gui_20260820_054307/agent/modules/`
- Focused verification after replacement: 44 YouTube/routing/GUI tests passed
  and all touched Python modules compiled successfully.
- Live Data API + Vision + range-download + composition smoke test passed.
  Inspectable artifacts remain under:
  `VARAGENT_API/_live_checks/youtube_final_smoke_20260820_062221/` and
  `VARAGENT_API/_live_checks/youtube_final_full_20260820_062356/`.
- The full root production test collection was also audited: 245 tests passed;
  five unrelated legacy CinAI/music/preset assertions and one fixture error
  remain outside this YouTube change and were not altered.

## GUI cleanup: YouTube settings and Voice/TTS service state — 2026-08-20

- YouTube Data API key is no longer edited in the YouTube stage card; it is
  managed by the central Settings `.env` editor like the other API keys.
- Removed the misleading unused YouTube smart-selector checkbox. Vision is the
  planned candidate-review stage; its operator and model are readonly dropdowns.
- Replaced the free-form selector model field with a provider-driven model
  dropdown and added clearer tooltips for Vision, pool, fragment length,
  source-gap, timeout, license, and rights policy.
- Lumean now has a working template catalog path. The dev `.env` contains the
  supplied Lumean key; secrets are not copied into PORTABLE.
- Voicegen and Lumean keep separate selected IDs/catalogs. Switching services
  restores the correct selection instead of reusing the other catalog.
- Lumean changes the label to `Шаблон:`, shows `Шаблоны`, hides Voicegen-only
  Engine/Stability/Chunk/Pause/Threads and hides Voicegen preview.
- Added GUI state tests and verified a real Lumean template request returned
  42 templates. GUI boot smoke also passed without AttributeError.
- Translated the remaining YouTube labels/dropdown values/tooltips to Russian.
  Renamed the source reuse setting to `Разнос частей одного видео` and
  documented that it is a timeline distance inside the same source video,
  not a delay between scenes or a network wait.

## GUI cleanup: Real Photos compact layout — 2026-08-20

- Kept the `Real Photos` card width unchanged.
- Moved `Non-AI sources only` to its own row.
- Split source percentages into two compact rows: `RP + IG` and
  `Stock + YT`.

## GUI cleanup: Image Generation fallback layout — 2026-08-20

- Put the FastGen, VeoNonStop, and T2V quota fallback checkboxes on separate
  rows so every checkbox remains visible in the narrow settings tab.
- Shortened the visible labels without changing the fallback behavior.
- Removed the misleading `FastGen` reference from the VeoNonStop-to-T2V label;
  the detailed wait/fallback behavior remains in its tooltip.

## GUI cleanup: compact Parallax controls — 2026-08-20

- Reduced the Parallax method combobox from a wide named selector to a compact
  `1 / 2 / 3` selector; mode descriptions remain available in its tooltip.
- Moved `Mix with per-clip` and `Every N` to a separate row so the Parallax
  controls cannot widen the settings tab.

## GUI cleanup: compact YouTube settings — 2026-08-20

- Replaced the unclear `Разнос частей одного видео` label with
  `Отступ между фрагментами`.
- Renamed `макс. часть` to `Макс. фрагмент` and standardized the surrounding
  tooltip text on the term `фрагмент`.
- Replaced the misleading `ждать до запасного источника` label with
  `Ожидание YouTube`; its tooltip now explains that this is the total time
  allowed for search, Vision review, and downloading before unresolved scenes
  enter the configured fallback.
- Put fragment length, source gap, YouTube wait, search backend, license, and
  Vision model on separate compact rows. The widest resulting YouTube row
  requests 284 px.

## GUI freeze: legacy watermark removers — 2026-08-20

- Hid `Audio WM Cleaner` and `SynthID Remover` from the Pipeline Launcher.
- Hid their standalone and Finalize controls from the Control Panel.
- Hid their installer controls and reference cards from Settings.
- Kept the legacy variables and runtime implementation unchanged for now.
- GUI inspection found zero exposed legacy watermark controls; GUI boot and
  the focused GUI test suite passed.
