"""
Suno HTTP-клиент с cookie-авторизацией через Clerk.

Юзер один раз логинится на https://suno.com через Chrome (или Edge/Firefox).
Мы достаём cookie '__client' (long-lived JWT, ~30 дней),
обмениваем его на короткоживущий access JWT через Clerk,
ходим в studio-api.suno.ai под подпиской юзера.

Все треки — инструментал (make_instrumental=True по дефолту, hard-coded в generate()).
"""
from __future__ import annotations

import base64
import json
import logging
import threading
import time
import uuid
from pathlib import Path
from typing import Optional, List, Dict, Any
from urllib.parse import urlparse

import requests


# =============================================================================
# Endpoints / constants
# =============================================================================

# Suno мигрировал с Clerk на собственный auth (auth.suno.com).
# Endpoints структура осталась clerk-совместимой (/v1/client/sessions/{sid}/tokens).
AUTH_BASE = "https://auth.suno.com"
STUDIO_BASE = "https://studio-api-prod.suno.com"  # дефис, не точка — иначе DNS NXDOMAIN

# clerk-js version в URL endpoint'а refresh — обязателен, иначе 400.
DEFAULT_CLERK_JS_VERSION = "5.36.0"

# JWT template, который webapp использует через getToken({ template: 'suno-api' }).
# Без него backend на /api/* отдаст 422 token_validation_failed (audience mismatch).
SUNO_JWT_TEMPLATE = "suno-api"

DEFAULT_MODEL = "chirp-fenix"  # v5.5 — текущая дефолтная модель Suno (с апреля 2026)
DEFAULT_TIMEOUT = 30

# Generation type: "TEXT" — обычная генерация по промпту/тегам (не remix/extend)
DEFAULT_GENERATION_TYPE = "TEXT"
DEFAULT_POLL_EVERY = 10
DEFAULT_GEN_TIMEOUT = 300  # 5 мин на одну генерацию (2 клипа по ~2 мин)

JWT_REFRESH_LEAD_S = 10  # рефрешим access JWT за 10с до истечения

# Domains в cookie jar для Suno
SUNO_COOKIE_DOMAIN = "suno.com"

MODEL_ALIASES = {
    "v5": "chirp-fenix",
    "v5.5": "chirp-fenix",
    "chirp-v5": "chirp-fenix",
    "chirp-v5-5": "chirp-fenix",
    "chirp-fenix-v5": "chirp-fenix",
}


# =============================================================================
# Exceptions
# =============================================================================

class SunoAuthError(RuntimeError):
    """Cookie не найден / Clerk вернул 401 / сессия протухла."""


class SunoQuotaError(RuntimeError):
    """Кончились кредиты подписки."""


class SunoAPIError(RuntimeError):
    """Прочие ошибки studio-api / Clerk."""


# =============================================================================
# Helpers
# =============================================================================

def _decode_jwt_payload(jwt_token: str) -> dict:
    """Декодирует payload JWT (без проверки подписи — нам нужны только claims)."""
    try:
        parts = jwt_token.split('.')
        if len(parts) < 2:
            return {}
        payload_b64 = parts[1]
        # JWT base64 без padding
        padding = 4 - len(payload_b64) % 4
        if padding < 4:
            payload_b64 += '=' * padding
        decoded = base64.urlsafe_b64decode(payload_b64.encode('ascii'))
        return json.loads(decoded)
    except Exception as e:
        logging.warning(f"Suno: не удалось декодировать JWT payload: {e}")
        return {}


def _clean_response_text(text: str, limit: int = 400) -> str:
    """Обрезает HTML/JSON ошибки для лога."""
    if '<html' in text.lower() or '<!doctype' in text.lower():
        return f"[HTML response, likely 5xx/Cloudflare] {text[:200].replace(chr(10), ' ')}"
    return text[:limit]


def _jwt_has_audience(payload: dict, audience: str) -> bool:
    aud = payload.get('aud')
    if isinstance(aud, list):
        return audience in aud
    return aud == audience


def normalize_suno_model(model: Optional[str]) -> str:
    """Normalize UI/legacy model aliases to the current Suno API model id."""
    raw = (model or DEFAULT_MODEL).strip()
    normalized = MODEL_ALIASES.get(raw.lower(), raw)
    if normalized != raw:
        logging.info(f"Suno: model alias {raw!r} normalized to {normalized!r}")
    return normalized


# =============================================================================
# SunoClient
# =============================================================================

class SunoClient:
    """
    Cookie-based клиент к Suno под подпиской пользователя.

    Использование:
        client = SunoClient(browser='chrome')
        client.check_auth()                           # raises SunoAuthError если не залогинен
        info = client.get_credits()
        clip_ids = client.generate(
            prompt="cinematic dark ambient with slow strings, building tension",
            tags="cinematic, dark, ambient, instrumental",
            title="Track 1",
        )
        for cid in clip_ids:
            clip = client.wait_for_clip(cid)
            client.download_audio(cid, Path('music/1.mp3'))
    """

    def __init__(
        self,
        browser: str = 'chrome',
        clerk_js_version: Optional[str] = None,
        timeout: int = DEFAULT_TIMEOUT,
    ):
        self.browser = (browser or 'chrome').lower()
        self.clerk_js_version = clerk_js_version or DEFAULT_CLERK_JS_VERSION
        self.timeout = timeout

        # Auth state
        self._cookie_jar = None
        self._client_cookie: Optional[str] = None  # long-lived __client JWT
        self._session_id: Optional[str] = None
        self._session_cookie_jwt: Optional[str] = None
        self._access_jwt: Optional[str] = None
        self._access_exp: float = 0.0
        self._refresh_lock = threading.Lock()
        self._user_tier: Optional[str] = None  # plan id из JWT, для metadata.user_tier
        # Уникальный токен на жизненный цикл клиента (как webapp на одну Create-сессию)
        self._create_session_token: str = str(uuid.uuid4())

        # Две HTTP-сессии:
        #   _http        — общая (имеет cookies для auth-refresh, не используется для studio-api)
        #   _http_studio — БЕЗ cookies, только Authorization+headers — для studio-api-prod.suno.com
        # Webapp шлёт на studio-api без cookies (credentials:'omit'), иначе 431 Headers Too Large.
        _ua = (
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) '
            'Gecko/20100101 Firefox/150.0'
        )
        self._http = requests.Session()
        self._http.headers.update({
            'User-Agent': _ua,
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Origin': 'https://suno.com',
            'Referer': 'https://suno.com/',
        })
        self._http_studio = requests.Session()
        self._http_studio.headers.update({
            'User-Agent': _ua,
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Origin': 'https://suno.com',
            'Referer': 'https://suno.com/',
        })

        self._load_cookies()
        self._ensure_jwt()

    # =========================================================================
    # Auth: cookie loading + Clerk exchange
    # =========================================================================

    def _load_cookies(self) -> None:
        """
        Достаёт __client cookie из браузера.

        Сначала rookiepy (умеет Chrome v127+ App-Bound Encryption на Windows),
        с fallback на browser_cookie3 (для Firefox / старых Chrome).
        """
        cookies_list = self._load_cookies_rookiepy()
        if cookies_list is None:
            cookies_list = self._load_cookies_bc3()

        if cookies_list is None:
            raise SunoAuthError(
                "Не установлен ни rookiepy, ни browser-cookie3. Запустите:\n"
                "    pip install rookiepy browser-cookie3\n"
                "(или из agent/requirements.txt)"
            )

        # Suno использует две cookie:
        #   __session  на suno.com         — короткоживущий JWT (~60 мин), уже Bearer-token
        #   __client   на auth.suno.com    — long-lived refresh-cookie
        session_cookie = None
        client_cookie = None
        for c in cookies_list:
            name = c.get('name') if isinstance(c, dict) else getattr(c, 'name', None)
            domain = c.get('domain') if isinstance(c, dict) else getattr(c, 'domain', '')
            value = c.get('value') if isinstance(c, dict) else getattr(c, 'value', None)
            domain = domain or ''
            # __session (без суффиксов): на suno.com — это наш access JWT
            if name == '__session' and 'suno.com' in domain:
                if not session_cookie:
                    session_cookie = value
            # __client (без суффиксов): на auth.suno.com — refresh-cookie
            if name == '__client' and 'suno.com' in domain:
                if not client_cookie:
                    client_cookie = value

        if not session_cookie:
            raise SunoAuthError(
                f"Cookie '__session' не найден для suno.com в {self.browser}.\n"
                f"Залогиньтесь на https://suno.com в {self.browser} и повторите."
            )

        self._cookie_jar = cookies_list
        self._client_cookie = client_cookie  # может быть None — рефреш недоступен

        # Прокинем cookies в HTTP-сессию (нужны для refresh + studio-api)
        self._http.cookies.clear()
        self._inject_cookies_into_session(self._cookie_jar)

        # __session — session token (aud=suno-frontend), не годится для studio-api.
        # Берём из payload только sid; access JWT для api берём через refresh endpoint
        # с JWT template 'suno-api' — он выдаёт токен с aud=suno-api.
        payload = _decode_jwt_payload(session_cookie)
        self._session_id = payload.get('sid') or payload.get('session_id')
        if not self._session_id:
            raise SunoAuthError(
                "Не удалось получить sid из cookie '__session'.\n"
                "Перелогиньтесь на suno.com и попробуйте снова."
            )

        # Достанем suno_device_id для Device-Id header (требуется на studio-api)
        self._device_id = None
        for c in cookies_list:
            name = c.get('name') if isinstance(c, dict) else getattr(c, 'name', None)
            value = c.get('value') if isinstance(c, dict) else getattr(c, 'value', None)
            if name == 'suno_device_id' and value:
                self._device_id = value
                break

        # Browser webapp uses __session directly as Bearer for studio-api when it
        # already has aud=suno-api. Prefer that exact browser token for Create;
        # fall back to token refresh only when the cookie is expired/missing.
        self._session_cookie_jwt = session_cookie
        if _jwt_has_audience(payload, 'suno-api'):
            self._access_jwt = session_cookie
            self._access_exp = float(payload.get('exp') or 0.0)
            plan = payload.get('plan') or ''
            if plan and ':' in plan:
                self._user_tier = plan.split(':', 1)[0] or None
        else:
            self._access_jwt = None
            self._access_exp = 0.0

        logging.info(
            f"Suno: cookies loaded from {self.browser}, sid={self._session_id[:24]}, "
            f"device_id={(self._device_id or 'none')[:8]}"
        )

    def _reload_auth_from_browser(self) -> None:
        """Re-read browser cookies and force a fresh API JWT without user action."""
        self._access_jwt = None
        self._access_exp = 0.0
        self._session_cookie_jwt = None
        self._load_cookies()
        self._ensure_jwt(force_refresh=True)

    def _load_cookies_rookiepy(self):
        """Возвращает list of dicts с cookies или None если rookiepy недоступен."""
        try:
            import rookiepy
        except ImportError:
            return None

        loader_map = {
            'chrome':  getattr(rookiepy, 'chrome', None),
            'edge':    getattr(rookiepy, 'edge', None),
            'firefox': getattr(rookiepy, 'firefox', None),
            'opera':   getattr(rookiepy, 'opera', None),
            'brave':   getattr(rookiepy, 'brave', None),
        }
        loader = loader_map.get(self.browser)
        if loader is None:
            return None

        try:
            cookies = loader([
                'suno.com',
                '.suno.com',
                'auth.suno.com',
                'studio-api.suno.ai',
                'studio-api-prod.suno.com',
                'clerk.suno.com',
            ])
            return list(cookies) if cookies else []
        except Exception as e:
            logging.warning(f"Suno: rookiepy failed for {self.browser}: {e}")
            return None  # упадём на browser_cookie3

    def _load_cookies_bc3(self):
        """Fallback: browser_cookie3. Возвращает список Cookie-объектов или None."""
        try:
            import browser_cookie3
        except ImportError:
            return None

        loader = {
            'chrome':  browser_cookie3.chrome,
            'edge':    browser_cookie3.edge,
            'firefox': browser_cookie3.firefox,
            'opera':   browser_cookie3.opera,
            'brave':   browser_cookie3.brave,
        }.get(self.browser)
        if loader is None:
            raise SunoAuthError(
                f"Неизвестный браузер: '{self.browser}'. "
                f"Доступны: chrome, edge, firefox, opera, brave"
            )

        try:
            jar = loader(domain_name=SUNO_COOKIE_DOMAIN)
        except Exception as e:
            raise SunoAuthError(
                f"Не удалось прочитать cookies из {self.browser}: {e}\n"
                f"Возможные причины:\n"
                f"  - Chrome 127+ использует App-Bound Encryption — нужен rookiepy:\n"
                f"      pip install rookiepy\n"
                f"  - Браузер не установлен или не залогинен на suno.com\n"
                f"  - Закройте {self.browser} перед запуском\n"
                f"  - macOS: Terminal Full Disk Access"
            )
        return list(jar) if jar else []

    def _inject_cookies_into_session(self, cookies_list) -> None:
        """Унифицирует rookiepy dicts и browser_cookie3 CookieJar в requests.Session."""
        for c in cookies_list:
            if isinstance(c, dict):
                # rookiepy формат
                try:
                    self._http.cookies.set(
                        name=c.get('name'),
                        value=c.get('value'),
                        domain=c.get('domain'),
                        path=c.get('path', '/'),
                    )
                except Exception as e:
                    logging.debug(f"Suno: пропуск cookie {c.get('name')}: {e}")
            else:
                # browser_cookie3: CookieJar item
                try:
                    self._http.cookies.set_cookie(c)
                except Exception:
                    try:
                        self._http.cookies.set(
                            name=c.name, value=c.value,
                            domain=c.domain, path=getattr(c, 'path', '/'),
                        )
                    except Exception:
                        pass

    def _refresh_access_jwt(self, force: bool = False) -> str:
        """
        Получает свежий access JWT через auth.suno.com/v1/client/sessions/{sid}/tokens.
        Если __session cookie из браузера ещё свежий — возвращает его без сетевого запроса
        (если не force=True).
        """
        with self._refresh_lock:
            # Кто-то другой уже обновил пока ждали лок
            if not force and self._access_jwt and time.time() < self._access_exp - JWT_REFRESH_LEAD_S:
                return self._access_jwt

            if not self._session_id:
                raise SunoAuthError("Нет session_id — сначала _load_cookies()")

            # POST /tokens без template — Suno auth выдаёт сразу токен с aud=suno-api
            # (template "suno-api" не существует как path, dev: 404).
            url = f"{AUTH_BASE}/v1/client/sessions/{self._session_id}/tokens"
            params = {'_clerk_js_version': self.clerk_js_version}

            # Минимальный cookie-набор для auth.suno.com — только __client*.
            # Если слать полные ~40 cookies от .suno.com, попадаем в 431 Headers Too Large.
            min_cookies = {}
            for c in self._cookie_jar:
                name = c.get('name') if isinstance(c, dict) else getattr(c, 'name', None)
                value = c.get('value') if isinstance(c, dict) else getattr(c, 'value', None)
                domain = c.get('domain') if isinstance(c, dict) else getattr(c, 'domain', '')
                if name and value and (name.startswith('__client') or name.startswith('__session')):
                    if 'suno.com' in (domain or ''):
                        min_cookies[name] = value

            try:
                r = requests.post(
                    url, params=params, cookies=min_cookies,
                    headers={
                        'Origin': 'https://suno.com',
                        'Referer': 'https://suno.com/',
                        'User-Agent': self._http.headers.get('User-Agent'),
                    },
                    timeout=self.timeout,
                )
            except requests.RequestException as e:
                raise SunoAuthError(f"auth.suno.com недоступен: {e}")

            if r.status_code in (401, 403):
                raise SunoAuthError(
                    f"auth.suno.com вернул {r.status_code} — cookie протух. "
                    f"Перелогиньтесь на suno.com в {self.browser}."
                )
            if r.status_code != 200:
                raise SunoAuthError(
                    f"auth.suno.com token refresh {r.status_code}: "
                    f"{_clean_response_text(r.text)}"
                )

            try:
                data = r.json()
            except ValueError:
                raise SunoAuthError(f"auth.suno.com вернул не-JSON: {r.text[:200]}")

            jwt_token = data.get('jwt')
            if not jwt_token:
                raise SunoAuthError(f"auth.suno.com не вернул jwt: {data}")

            payload = _decode_jwt_payload(jwt_token)
            exp = payload.get('exp') or (time.time() + 50)

            # Извлекаем user_tier из claim 'plan' = "<uuid>:<period>:" → берём <uuid>
            plan = payload.get('plan') or ''
            if plan and ':' in plan:
                self._user_tier = plan.split(':', 1)[0] or None

            self._access_jwt = jwt_token
            self._access_exp = float(exp)
            logging.debug(f"Suno: access JWT refreshed, ttl={int(exp - time.time())}s, tier={self._user_tier}")
            return jwt_token

    def _ensure_jwt(self, force_refresh: bool = False) -> str:
        """
        Гарантирует свежий access JWT перед запросом к studio-api.

        Suno's /generate/v2 проверяет token строже чем /billing/info — браузерный
        __session не проходит, нужен JWT, полученный через POST на refresh-endpoint.
        Поэтому force_refresh=True для каждой генерации.
        """
        if force_refresh:
            return self._refresh_access_jwt(force=True)
        if not self._access_jwt or time.time() >= self._access_exp - JWT_REFRESH_LEAD_S:
            return self._refresh_access_jwt()
        return self._access_jwt

    def _prepare_generate_jwt(self) -> str:
        """Prepare a JWT accepted by /generate/v2-web without forcing page refresh."""
        session_payload = _decode_jwt_payload(self._session_cookie_jwt or '')
        session_exp = float(session_payload.get('exp') or 0.0)
        if (
            self._session_cookie_jwt
            and _jwt_has_audience(session_payload, 'suno-api')
            and time.time() < session_exp - JWT_REFRESH_LEAD_S
        ):
            self._access_jwt = self._session_cookie_jwt
            self._access_exp = session_exp
            return self._access_jwt

        errors: List[str] = []
        for attempt in range(2):
            try:
                if attempt == 1:
                    self._reload_auth_from_browser()
                jwt_token = self._refresh_access_jwt(force=True)
                payload = _decode_jwt_payload(jwt_token)
                if not _jwt_has_audience(payload, 'suno-api'):
                    raise SunoAuthError(
                        f"auth.suno.com returned JWT with aud={payload.get('aud')!r}, expected suno-api"
                    )
                return jwt_token
            except Exception as exc:
                errors.append(str(exc))
                logging.warning(f"Suno: generate JWT refresh attempt {attempt + 1} failed: {exc}")

        raise SunoAuthError(
            f"Suno auth failed for {self.browser}. "
            f"Tried browser cookie + auth refresh. Last error: {errors[-1] if errors else 'unknown'}"
        )

    def _auth_headers(self, force_refresh: bool = False) -> dict:
        """Полный набор headers как у webapp — иначе backend режет 422."""
        # Browser-Token: webapp шлёт {"token": base64(JSON{"timestamp": ms_now})}
        ts_payload = json.dumps(
            {"timestamp": int(time.time() * 1000)},
            separators=(',', ':'),
        ).encode('utf-8')
        b64 = base64.urlsafe_b64encode(ts_payload).rstrip(b'=').decode('ascii')
        browser_token = json.dumps({"token": b64}, separators=(',', ':'))

        h = {
            'Authorization': f'Bearer {self._ensure_jwt(force_refresh=force_refresh)}',
            'Browser-Token': browser_token,
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Origin': 'https://suno.com',
            'Referer': 'https://suno.com/',
            'Connection': 'keep-alive',
            'Priority': 'u=4',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-site',
            'TE': 'trailers',
        }
        if self._device_id:
            h['Device-Id'] = self._device_id
        return h

    # =========================================================================
    # Public: auth check + account info
    # =========================================================================

    def check_auth(self) -> bool:
        """Возвращает True если cookie валиден и Clerk даёт JWT."""
        try:
            self._refresh_access_jwt()
            self.get_credits()
            return True
        except SunoAuthError:
            raise
        except Exception as e:
            logging.warning(f"Suno: check_auth неуспешен: {e}")
            return False

    def get_credits(self) -> Dict[str, Any]:
        """Возвращает информацию о кредитах подписки. Endpoint: /api/billing/info"""
        url = f"{STUDIO_BASE}/api/billing/info"
        r = self._http_studio.get(url, headers=self._auth_headers(), timeout=self.timeout)
        if r.status_code == 401:
            raise SunoAuthError("studio-api 401 — JWT невалиден")
        if r.status_code != 200:
            raise SunoAPIError(f"billing/info {r.status_code}: {_clean_response_text(r.text)}")
        return r.json()

    # =========================================================================
    # Generation
    # =========================================================================

    def generate(
        self,
        prompt: str,
        tags: str,
        title: Optional[str] = None,
        instrumental: bool = True,         # дефолт TRUE — стори-телл бэкграунд
        model: str = DEFAULT_MODEL,
        continue_clip_id: Optional[str] = None,
        continue_at: Optional[float] = None,
    ) -> List[str]:
        """
        Запускает генерацию музыки. Возвращает 2 clip_id (Suno всегда даёт 2 варианта).

        Args:
            prompt: описание музыки (style/mood — НЕ текст песни в инструментал-режиме)
            tags: теги жанра/настроения через запятую
            title: имя трека
            instrumental: ВСЕГДА True для нашего пайплайна (бэкграунд под диктора)
            model: chirp-fenix / chirp-v3-5 / chirp-v4
            continue_clip_id: id предыдущего клипа для продолжения
            continue_at: с какой секунды продолжать предыдущий клип
        """
        # Hard constraint: для VARAGENT всегда инструментал.
        # Параметр оставлен на случай будущего расширения, но в нашем пайплайне всегда True.
        if not instrumental:
            logging.warning("Suno: instrumental=False — для VARAGENT не рекомендуется (нужен бэкграунд)")
        model = normalize_suno_model(model)
        api_prompt = prompt
        api_tags = tags or ""
        api_make_instrumental = bool(instrumental)

        if model == "chirp-fenix":
            # Current Suno v5.5 webapp sends description-mode generations as:
            # prompt="<style description>", tags="", make_instrumental=false.
            # Instrumental intent is expressed in the prompt itself.
            prompt_parts = [p.strip() for p in (prompt, tags) if p and p.strip()]
            api_prompt = ", ".join(prompt_parts)
            lower_prompt = api_prompt.lower()
            if instrumental and "instrumental" not in lower_prompt:
                api_prompt = f"{api_prompt}, instrumental, no vocals, no lyrics"
            elif instrumental and "no vocals" not in lower_prompt:
                api_prompt = f"{api_prompt}, no vocals, no lyrics"
            api_tags = ""
            api_make_instrumental = False

        # Negative tags — Suno's official mechanism to suppress unwanted elements.
        # Even with make_instrumental=True or "no vocals" in prompt, Suno v5.5/chirp-fenix
        # sometimes leaks vocals (humming, choirs, ahh-vocals, lyrics). negative_tags
        # is enforced server-side at generation, more reliable than prompt hints.
        api_negative_tags = ""
        if instrumental and model != "chirp-fenix":
            api_negative_tags = "vocals, lyrics, singing, voice, sung, choir, chant, humming, vocal, words, spoken, narration, rap"

        # Suno мигрировал на /generate/v2-web/ в апреле 2026 (v5.5 / chirp-fenix).
        # Body schema полностью изменилась — есть metadata, transaction_uuid, generation_type.
        url = f"{STUDIO_BASE}/api/generate/v2-web/"

        # Create is stricter than billing. Prefer a fresh browser __session
        # token when it is already scoped for suno-api, otherwise try the auth
        # refresh endpoint and one silent cookie reload before asking the user.
        self._prepare_generate_jwt()

        # Per-call session token + transaction UUID. Webapp генерирует новый
        # create_session_token на каждый клик Create — без этого Suno режет 422
        # после ~6 запросов (rate limit per session_token).
        per_call_session_token = str(uuid.uuid4())
        per_call_transaction_uuid = str(uuid.uuid4())

        body = {
            "token": None,                          # turnstile token (опционально для Pro)
            "generation_type": DEFAULT_GENERATION_TYPE,
            "title": title or "",
            "tags": api_tags,
            "negative_tags": api_negative_tags,
            "mv": model,                            # chirp-fenix (v5.5) / chirp-v3-5 / chirp-v4
            "prompt": api_prompt,                   # описание стиля (или текст в lyrics-режиме)
            "make_instrumental": api_make_instrumental,
            "user_uploaded_images_b64": None,
            "metadata": {
                "web_client_pathname": "/create",
                "is_max_mode": False,
                "is_mumble": False,
                "create_mode": "custom",
                "user_tier": self._user_tier,       # plan UUID, может быть None для free
                "create_session_token": per_call_session_token,
                "disable_volume_normalization": False,
            },
            "override_fields": [],
            "cover_clip_id": None,
            "cover_start_s": None,
            "cover_end_s": None,
            "persona_id": None,
            "artist_clip_id": None,
            "artist_start_s": None,
            "artist_end_s": None,
            "continue_clip_id": continue_clip_id,
            "continued_aligned_prompt": None,
            "continue_at": continue_at,
            "transaction_uuid": per_call_transaction_uuid,
        }

        # Retry on 422 (Suno rate-limits бывают временные) — 1 попытка ретрая после 90с
        _attempts = 0
        _max_attempts = 3
        while True:
            _attempts += 1
            r = self._http_studio.post(
                url,
                headers=self._auth_headers(),
                data=json.dumps(body, separators=(',', ':')),
                timeout=self.timeout,
            )
            if r.status_code == 422 and _attempts < _max_attempts:
                retryable = True
                error_type = ''
                try:
                    err_data = r.json()
                    retryable = bool(err_data.get('retryable', True))
                    error_type = str(err_data.get('error_type') or '')
                except ValueError:
                    pass
                if error_type == 'token_validation_failed':
                    logging.warning(
                        f"Suno: /generate token_validation_failed on attempt {_attempts} - reloading cookies/JWT"
                    )
                    self._reload_auth_from_browser()
                    body['transaction_uuid'] = str(uuid.uuid4())
                    body['metadata']['create_session_token'] = str(uuid.uuid4())
                    continue
                if not retryable:
                    logging.warning(
                        f"Suno: /generate 422 non-retryable ({error_type or 'unknown'}) — без sleep/retry"
                    )
                    break
                logging.warning(
                    f"Suno: /generate 422 на попытке {_attempts} — sleep 90s и retry"
                )
                time.sleep(90)
                # Свежий transaction_uuid + session_token + JWT для retry
                body['transaction_uuid'] = str(uuid.uuid4())
                body['metadata']['create_session_token'] = str(uuid.uuid4())
                self._ensure_jwt(force_refresh=False)
                continue
            break

        if r.status_code == 401 and _attempts < _max_attempts:
            logging.warning("Suno: /generate 401 - reloading cookies/JWT and retrying once")
            self._reload_auth_from_browser()
            body['transaction_uuid'] = str(uuid.uuid4())
            body['metadata']['create_session_token'] = str(uuid.uuid4())
            r = self._http_studio.post(
                url,
                headers=self._auth_headers(),
                data=json.dumps(body, separators=(',', ':')),
                timeout=self.timeout,
            )

        if r.status_code == 401:
            raise SunoAuthError("studio-api 401 на /generate/v2 — JWT невалиден")
        if r.status_code == 402 or r.status_code == 429:
            raise SunoQuotaError(
                f"Suno вернул {r.status_code}: кончились кредиты или rate limit. "
                f"{_clean_response_text(r.text)}"
            )
        if r.status_code != 200:
            raise SunoAPIError(
                f"/generate/v2 {r.status_code}: {_clean_response_text(r.text)}"
            )

        try:
            data = r.json()
        except ValueError:
            raise SunoAPIError(
                f"/generate/v2 {r.status_code} returned non-JSON: "
                f"{_clean_response_text(r.text or repr(r.content[:200]))}"
            )
        clips = data.get('clips') or []
        clip_ids = [c.get('id') for c in clips if c.get('id')]
        if not clip_ids:
            raise SunoAPIError(f"/generate/v2 не вернул clips: {data}")

        logging.info(f"Suno: запущено {len(clip_ids)} клипов: {clip_ids}")
        return clip_ids

    # =========================================================================
    # Polling + download
    # =========================================================================

    def get_clips(self, clip_ids: List[str]) -> List[Dict[str, Any]]:
        """POST /api/feed/v3 со списком clipIds — статусы N клипов одним запросом."""
        if not clip_ids:
            return []
        url = f"{STUDIO_BASE}/api/feed/v3"
        body = {
            "filters": {
                "ids": {"presence": "True", "clipIds": list(clip_ids)},
            },
            "limit": len(clip_ids),
        }
        r = self._http_studio.post(
            url,
            headers=self._auth_headers(),
            data=json.dumps(body, separators=(',', ':')),
            timeout=self.timeout,
        )
        if r.status_code == 401:
            raise SunoAuthError("studio-api 401 на /feed/v3 — JWT невалиден")
        if r.status_code != 200:
            raise SunoAPIError(f"/feed/v3 {r.status_code}: {_clean_response_text(r.text)}")
        # /feed/v3 возвращает либо массив clips, либо {"clips": [...]} — нормализуем
        data = r.json()
        if isinstance(data, list):
            return data
        return data.get('clips') or data.get('items') or data.get('feed') or []

    def get_clip(self, clip_id: str) -> Dict[str, Any]:
        clips = self.get_clips([clip_id])
        if not clips:
            raise SunoAPIError(f"Клип {clip_id} не найден в /feed")
        return clips[0]

    def wait_for_clip(
        self,
        clip_id: str,
        timeout: int = DEFAULT_GEN_TIMEOUT,
        poll_every: int = DEFAULT_POLL_EVERY,
        on_progress=None,
    ) -> Dict[str, Any]:
        """Ждёт пока clip.status станет 'complete' или 'error'."""
        t0 = time.time()
        last_status = None
        while True:
            elapsed = time.time() - t0
            if elapsed > timeout:
                raise SunoAPIError(f"Suno timeout {timeout}s для клипа {clip_id}")

            try:
                clip = self.get_clip(clip_id)
            except (SunoAuthError, SunoQuotaError):
                raise
            except Exception as e:
                logging.warning(f"Suno: poll {clip_id} ошибка: {e}, retry через {poll_every}s")
                time.sleep(poll_every)
                continue

            status = clip.get('status', 'unknown')
            if status != last_status:
                logging.info(f"Suno {clip_id[:8]}: {last_status} → {status} (t={elapsed:.0f}s)")
                last_status = status
            if on_progress:
                try:
                    on_progress(clip_id, status, elapsed, clip)
                except Exception:
                    pass

            if status == 'complete':
                return clip
            if status == 'error':
                raise SunoAPIError(
                    f"Suno вернул error для {clip_id}: "
                    f"{clip.get('metadata', {}).get('error_message', '?')}"
                )

            time.sleep(poll_every)

    def download_audio(self, clip_id_or_clip, dest: Path, chunk_size: int = 65536) -> Path:
        """Скачивает MP3 клипа в dest. Принимает либо clip_id, либо dict из /feed."""
        if isinstance(clip_id_or_clip, str):
            clip = self.get_clip(clip_id_or_clip)
        else:
            clip = clip_id_or_clip

        audio_url = clip.get('audio_url')
        if not audio_url:
            raise SunoAPIError(f"Нет audio_url у клипа {clip.get('id')}: status={clip.get('status')}")

        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)

        with self._http_studio.get(audio_url, stream=True, timeout=120) as r:
            if r.status_code != 200:
                raise SunoAPIError(f"Download {audio_url} → {r.status_code}")
            with open(dest, 'wb') as f:
                for chunk in r.iter_content(chunk_size=chunk_size):
                    if chunk:
                        f.write(chunk)

        logging.info(f"Suno: скачан {clip.get('id', '?')[:8]} → {dest} ({dest.stat().st_size} bytes)")
        return dest

    # =========================================================================
    # Convenience
    # =========================================================================

    def generate_and_wait(
        self,
        prompt: str,
        tags: str,
        title: Optional[str] = None,
        instrumental: bool = True,
        model: str = DEFAULT_MODEL,
        timeout: int = DEFAULT_GEN_TIMEOUT,
        on_progress=None,
    ) -> List[Dict[str, Any]]:
        """generate() + wait_for_clip() для всех вариантов. Возвращает list of clip dicts."""
        clip_ids = self.generate(
            prompt=prompt, tags=tags, title=title,
            instrumental=instrumental, model=model,
        )
        results = []
        for cid in clip_ids:
            results.append(self.wait_for_clip(cid, timeout=timeout, on_progress=on_progress))
        return results
