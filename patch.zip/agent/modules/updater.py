"""
updater.py — Проверка и установка обновлений VARAGENT с GitHub
Версия: 2026.03.24-fix
"""
import hashlib
import json
import ssl
import urllib.request
import urllib.error
import zipfile
import io
from pathlib import Path
from typing import Optional

GITHUB_REPO      = 'terryvarron-a11y/varagent-updates'
VERSION_JSON_URL = f'https://raw.githubusercontent.com/{GITHUB_REPO}/main/version.json'
VERSION_API      = f'https://api.github.com/repos/{GITHUB_REPO}/contents/version.json'
PATCH_URL        = f'https://raw.githubusercontent.com/{GITHUB_REPO}/main/patch.zip'

SKIP_ON_INSTALL = {'projects/', '.env', 'agent/.env', 'publisher.py'}

# Keys that must exist in agent/.env — added with defaults if missing.
# Order matters: each entry is (KEY, default_value, optional_comment_above).
_ENV_REQUIRED = [
    ('VEONONSTOP_API_KEY_3',  '',     '# VeoNonStop Key3 (optional)'),
    ('VEONONSTOP_KEY3_NAME',  'Key3', None),
    ('VEONONSTOP_API_KEY_4',  '',     '# VeoNonStop Key4 (optional)'),
    ('VEONONSTOP_KEY4_NAME',  'Key4', None),
    ('VEONONSTOP_API_BASE',   'https://veononstop.org/api/v1', '# VeoNonStop base URL per key (empty = use VEONONSTOP_API_BASE)'),
    ('VEONONSTOP_API_BASE_2', '', None),
    ('VEONONSTOP_API_BASE_3', '', None),
    ('VEONONSTOP_API_BASE_4', '', None),
    ('SYNTHID_CLEAN_ENABLED', 'false',    '# SynthID image watermark removal (inflight, per-image)'),
    ('SYNTHID_STRENGTH',      'moderate', None),
    ('SYNTHID_VERSION',       'v1',       None),
    ('SYNTHID_SAVE_ORIG',          'false',  None),
    ('VEONONSTOP_RECAPTCHA_DELAY', '8.0',   '# reCAPTCHA retry base delay (s). Chrome: 3.0 | Dolphin+free proxy: 8.0 | Residential: 3.0'),
    ('VEONONSTOP_RECAPTCHA_JITTER','3.0',   None),
    ('VEONONSTOP_MAX_TIMEOUT_RETRIES', '5', '# Max server-timeout retries per clip before counting as failed attempt'),
    ('AUDIO_CLEAN_ENABLED',   'false',    '# Audio AI fingerprint removal (disabled)'),
    ('AUDIO_CLEAN_LEVEL',     'moderate', None),
    ('ASSEMBLYAI_SPEECH_MODELS', 'universal-3-pro,universal-2', '# AssemblyAI speech models (fallback chain)'),
    ('KIE_AI_API_KEY', '', '# Kie.ai API key (image remix)'),
    ('FASTGEN_API_KEY_BACKUP', '', '# FastGen backup API key'),
    ('FASTGEN_API_KEY_3', '', '# FastGen Key3 (optional)'),
    ('FASTGEN_API_KEY_4', '', '# FastGen Key4 (optional)'),
    ('FASTGEN_MAX_PARALLEL_2', '10', '# FastGen Key2 max workers'),
    ('FASTGEN_MAX_PARALLEL_3', '10', '# FastGen Key3 max workers'),
    ('FASTGEN_MAX_PARALLEL_4', '10', '# FastGen Key4 max workers'),
    ('DIRECTOR_BACKEND', 'gpt', '# Director backend (gemini or gpt)'),
    ('GPT_MODEL', 'gpt-5.4', None),
    ('GPT_PASS2_CHUNK_SIZE', '150', None),
    ('GPT_PASS2_PARALLEL', '6', None),
    ('GPT_REWRITE_TIMEOUT', '90', '# Codex rewrite per-call timeout (s) — prevents pipeline stall on hung rewrite'),
    ('YT_PACK_GPT_TIMEOUT', '600', '# YT Packer Codex timeout (s) — big multi-language prompts need 10 min'),
    ('GPT_HIGH_DEMAND_COOLDOWN', '90', '# Cooldown (s) before retry when OpenAI returns "high demand" / Reconnecting...'),
    ('REWRITE_MODEL', 'gemini:gemini-2.5-flash-lite', '# Rewrite model (provider:model) — flash-lite has 1000 RPD free-tier vs 20 on flash'),
    ('REMIX_ENGINE', 'grok', '# Remix engine (grok or kieai)'),
    ('VEONONSTOP_REF_MODE', 'name_match', '# Ref mode: name_match (by prompt names) or use_all (all refs on every prompt)'),
    ('VISION_CHECK_MODEL', 'gemini-2.5-flash-lite', '# Gemini model for vision_checks (image safety scans) — flash-lite: 1000 RPD free-tier'),
    ('VISION_API_KEY', '', '# Free-tier Gemini key for vision_checks + rewrite (paid quota NOT touched)'),
    ('GEMINI_API_KEY_FREE', '', '# Free-tier fallback for VISION_API_KEY (paid GEMINI_API_KEY intentionally not used)'),
    ('STORY_MODE', 'off', '# Chain mode: off (independent) | batch (morph imggen pairs) | morph (one chain) | chain (LLM-decided chains)'),
    ('CHAIN_IMGGEN_HEADS_ONLY', '1', '# Gen images only for chain heads (skip extends) — saves ~85% imggen'),
    ('VIDEO_EXTEND_FRAME_OFFSET', '0.5', '# Seconds from end to extract last frame (ffmpeg -sseof offset)'),
    ('VIDEO_EXTEND_TRIM_FRAMES', '1', '# video_concat.py: skip N first frames of extend clips (fps-independent via select filter)'),
    ('VIDEO_EXTEND_MUTE_AUDIO', '1', '# Mute audio for extend clips (VEO sound artifacts on each extend start)'),
    ('VIDEO_EXTEND_MAX_CHAIN', '10', '# Soft safety net: max clips in one chain before forced break (0=unlimited)'),
    ('CHAIN_CASCADE_RECOVERY', '1', '# Cascade recovery: regen prev clip on fail instead of immediate force break'),
    ('CHAIN_MAX_SAME_CLIP_FAILS', '3', '# Max fails of same clip before forced sub-chain head (prevents infinite loop)'),
    ('USATAYAI_GENERATOR_BRIDGE_MANIFEST', '', '# Generator bridge: delegate imggen/video to external app (e.g. Usataya). Empty=native VARAGENT.'),
    ('USATAYAI_BRIDGE_MANIFEST', '', '# Final bridge: post-concat processing (subtitles ASS, watermarks, logo). Empty=plain audio mux.'),
    # Real Photo Stage (archival photo/video insertion between Director and ImgGen)
    ('REAL_PHOTO_ENABLED',      'false', '# Real Photo stage: replace part of AI clips with archival photos/videos (off by default)'),
    ('REAL_PHOTO_RATIO_TARGET', '0.40',  '# Target % of clips to replace (0.0..1.0)'),
    ('REAL_PHOTO_RATIO_MIN',    '0.30',  '# Hard floor for replacement %'),
    ('REAL_PHOTO_RATIO_MAX',    '0.55',  '# Hard ceiling for replacement %'),
    ('REAL_PHOTO_SOURCES',      'wikimedia,nasa,loc,met,getty,europeana,smithsonian,archive',
        '# Archive sources, comma-separated. Wiki/NASA/LoC/Met/Getty/Archive = no key. Europeana/Smithsonian = optional free keys. Rijks frozen (rewrite needed).'),
    ('REAL_PHOTO_CODEX_MODEL',  'gpt-5.5', '# Codex model for clip selection / keyframe pick'),
    ('EUROPEANA_API_KEY',       '', '# Optional: free key from https://pro.europeana.eu/page/get-api'),
    ('SMITHSONIAN_API_KEY',     '', '# Optional: free key from https://api.data.gov/signup/'),
    ('RIJKSMUSEUM_API_KEY',     '', '# Optional: free key from https://data.rijksmuseum.nl'),
    # Smooth zoom для статичных кадров (Ken Burns в video_concat.py через scale eval=frame + crop)
    ('ZOOM_AMOUNT', '0.10', '# Smooth zoom amplitude per clip: 0.05 / 0.10 / 0.15 / 0.20'),
    ('ZOOM_CURVE',  'linear', '# Zoom curve: linear / constant_speed / ease_out'),
    # FastGen v5 endpoint (named refs binding по [name_ref] токенам в промпте).
    # 1 = использовать /v5/generations для flow/openai/grok/flower image + flow-ultra video + preflight.
    # 0 = legacy v4 (default — пока v5 в обкатке).
    ('FASTGEN_USE_V5', '1', '# FastGen v5 named-refs endpoint (1=on / 0=v4 legacy)'),
]

# Ключи, которые нужно обновить если значение устарело: (key, old_value, new_value)
_ENV_UPGRADES = [
    ('ASSEMBLYAI_SPEECH_MODELS', 'universal-3-pro', 'universal-3-pro,universal-2'),
    # Rewrite: flash (20 RPD free-tier) → flash-lite (1000 RPD). Users on gpt:gpt-5.4-mini keep their gpt rewriter (NOT forced back).
    ('REWRITE_MODEL', 'gemini:gemini-2.5-flash', 'gemini:gemini-2.5-flash-lite'),
    # Theme swap: zombovar.json merged into default.json (ClaudeVAR is now default)
    ('VARAGENT_THEME', 'zombovar', 'default'),
]

# Принудительная перезапись ключей (key, new_value) — ПУСТО ПО ПОЛИТИКЕ:
# если юзер задал значение в .env (свой ключ, свою модель) — апдейт его НЕ ТРОГАЕТ.
# Дефолты для свежеустановленных юзеров приходят через _ENV_REQUIRED.
# Ротация конкретных значений (например, dev-ключ забанили) — через _ENV_UPGRADES
# с парой (key, old_known_value, new_value): сработает только при точном совпадении строки.
_ENV_FORCE = []

_ENV_SECRET_KEY_MARKERS = ('API_KEY', 'TOKEN', 'SECRET', 'PASSWORD')

def _is_secret_env_key(key: str) -> bool:
    return any(marker in key.upper() for marker in _ENV_SECRET_KEY_MARKERS)

_ENV_FASTGEN_KEY_FIELDS = {'FASTGEN_API_KEY_BACKUP', 'FASTGEN_API_KEY_3', 'FASTGEN_API_KEY_4'}
_ENV_FASTGEN_PARALLEL_FIELDS = {'FASTGEN_MAX_PARALLEL_2', 'FASTGEN_MAX_PARALLEL_3', 'FASTGEN_MAX_PARALLEL_4'}

def _insert_env_lines_after_key(text: str, anchor_keys: set[str], new_lines: list[str]) -> str:
    if not new_lines:
        return text
    lines = text.splitlines()
    insert_at = None
    for i, line in enumerate(lines):
        raw = line.strip()
        if raw and not raw.startswith('#') and '=' in raw:
            key, _, _ = raw.partition('=')
            if key.strip() in anchor_keys:
                insert_at = i + 1
    if insert_at is None:
        insert_at = len(lines)
    lines[insert_at:insert_at] = new_lines
    return '\n'.join(lines) + '\n'

# Regex-миграция значений в .env: (pattern, replacement, human_note)
# Применяется к ВСЕМУ содержимому .env через re.sub. Нужно для коррекции
# значений, которые юзеры могли ввести до фикса (например, localhost → 127.0.0.1
# — чтобы обойти IPv6-перехват Dolphin Anty или похожих локальных серверов).
# Схема тоже форсится в http (у локального desk нет TLS — https ломает запросы).
_ENV_REGEX_MIGRATE = [
    (r'https?://localhost:(3001|3002|3003)/', r'http://127.0.0.1:\1/',
     'localhost->127.0.0.1 + force http for local desk ports (IPv6 bypass, no TLS on desk)'),
    (r'https://127\.0\.0\.1:(3001|3002|3003)/', r'http://127.0.0.1:\1/',
     'force http on 127.0.0.1 local desk ports (no TLS on desk)'),
]

# Загружаем токен из .env если есть (для обхода rate limit)
def _load_github_token(root: Path) -> 'Optional[str]':
    env_file = root / 'agent' / '.env'
    if env_file.exists():
        for line in env_file.read_text(encoding='utf-8').splitlines():
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                k, _, v = line.partition('=')
                if k.strip() == 'GITHUB_TOKEN':
                    return v.strip()
    return None


def _md5(path: Path) -> str:
    h = hashlib.md5()
    h.update(path.read_bytes())
    return h.hexdigest()


def _get_ssl_context():
    """Создает SSL context, совместимый с Mac/Windows/Linux."""
    try:
        # Метод 1: certifi (если доступен) — для Mac с Homebrew Python
        import certifi
        ctx = ssl.create_default_context(cafile=certifi.where())
        return ctx
    except ImportError:
        pass

    try:
        # Метод 2: create_default_context с отключенной проверкой
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    except Exception:
        pass

    # Метод 3: unverified context (последний fallback)
    return ssl._create_unverified_context()


def _fetch(url: str, token: str = None, timeout: int = 15) -> bytes:
    headers = {'User-Agent': 'varagent-updater'}
    if token:
        headers['Authorization'] = f'token {token}'
    req = urllib.request.Request(url, headers=headers)
    ctx = _get_ssl_context()
    return urllib.request.urlopen(req, timeout=timeout, context=ctx).read()


def _fetch_version_json(token: str = None) -> dict:
    """Получает version.json через GitHub API (с токеном для обхода rate limit)."""
    import base64
    headers = {
        'User-Agent': 'varagent-updater',
        'Accept': 'application/vnd.github.v3+json',
    }
    if token:
        headers['Authorization'] = f'token {token}'
    req = urllib.request.Request(VERSION_API, headers=headers)
    ctx = _get_ssl_context()
    d = json.loads(urllib.request.urlopen(req, timeout=15, context=ctx).read())
    return json.loads(base64.b64decode(d['content']))


def check_updates(root: Path) -> dict:
    """
    Проверяет наличие обновлений.

    Returns:
        {
          'available': bool,
          'version': str,
          'changelog': [...],
          'changed_files': [...],   # файлы которые реально изменились у юзера
          'error': str or None,
        }
    """
    token = _load_github_token(root)
    try:
        data = _fetch_version_json(token)
    except Exception:
        # Фоллбэк на raw URL — работает даже если GitHub API недоступен
        # или если старый updater.py сломан (NameError VERSION_API и т.п.)
        try:
            raw = _fetch(VERSION_JSON_URL, token)
            data = json.loads(raw)
        except Exception as e:
            return {'available': False, 'error': str(e)}

    remote_files = data.get('files', {})
    changed = []
    for rel, remote_md5 in remote_files.items():
        local_path = root / rel
        if not local_path.exists():
            changed.append(rel)
        elif _md5(local_path) != remote_md5:
            changed.append(rel)

    return {
        'available': len(changed) > 0,
        'version':   data.get('version', '?'),
        'changelog': data.get('changelog', []),
        'changed_files': changed,
        'requires_restart': data.get('requires_restart', False),
        'error': None,
    }


def install_update(root: Path, progress_cb=None) -> dict:
    """
    Скачивает и устанавливает patch.zip.

    progress_cb(msg: str) — опциональный колбэк для прогресса

    Returns: {'ok': bool, 'installed': [...], 'error': str or None}
    """
    def log(msg):
        if progress_cb:
            progress_cb(msg)

    token = _load_github_token(root)
    requires_restart = False

    try:
        # Сначала загружаем version.json для requires_restart
        log('Загрузка version.json...')
        try:
            data = _fetch_version_json(token)
            requires_restart = data.get('requires_restart', False)
        except Exception as ve:
            log(f'Предупреждение: не удалось загрузить version.json ({ve})')

        log('Скачивание патча...')
        patch_bytes = _fetch(PATCH_URL, token, timeout=60)

        log('Установка файлов...')
        installed = []
        with zipfile.ZipFile(io.BytesIO(patch_bytes)) as zf:
            for name in zf.namelist():
                # Пропускаем защищённые пути
                if any(name.startswith(s) for s in SKIP_ON_INSTALL):
                    continue
                dest = root / Path(name)  # Path() handles / correctly on all platforms
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(zf.read(name))
                installed.append(name)
                log(f'  {name}')

        log(f'Готово. Установлено файлов: {len(installed)}')
        # Очистка __pycache__ — иначе Python может импортировать старый .pyc
        import shutil
        for cache_dir in root.rglob('__pycache__'):
            try:
                shutil.rmtree(cache_dir)
            except Exception:
                pass
        log('Очистка __pycache__ — OK')
        # patch_env из нового updater.py (файл уже перезаписан из zip,
        # но в памяти ещё старый модуль с устаревшим _ENV_REQUIRED)
        _new_updater = root / 'agent' / 'modules' / 'updater.py'
        if _new_updater.exists():
            _ns = {}
            exec(compile(_new_updater.read_text(encoding='utf-8'), str(_new_updater), 'exec'), _ns)
            _added = _ns['patch_env'](root)
            if _added:
                log(f'Обновлён .env: {", ".join(_added)}')
        else:
            patch_env(root)
        _install_fonts(root, log)
        return {'ok': True, 'installed': installed, 'error': None,
                'requires_restart': requires_restart}

    except Exception as e:
        return {'ok': False, 'installed': [], 'error': str(e)}


def patch_env(root: Path) -> list:
    """
    Добавляет в agent/.env строки для ключей из _ENV_REQUIRED, если они отсутствуют.
    Существующие значения НЕ трогает.

    Returns: список добавленных ключей (пустой если всё уже было).
    """
    env_path = root / 'agent' / '.env'
    if not env_path.exists():
        return []

    try:
        text = env_path.read_text(encoding='utf-8')
    except Exception:
        return []

    # Собираем ключи и их значения
    existing_keys = {}  # key → value
    for line in text.splitlines():
        line = line.strip()
        if line and not line.startswith('#') and '=' in line:
            k, _, v = line.partition('=')
            existing_keys[k.strip()] = v.strip()

    added = []
    extra_lines = []
    fastgen_key_lines = []
    fastgen_parallel_lines = []
    for key, default, comment in _ENV_REQUIRED:
        if key not in existing_keys:
            # Ключа нет — добавляем
            target = extra_lines
            if key in _ENV_FASTGEN_KEY_FIELDS:
                target = fastgen_key_lines
            elif key in _ENV_FASTGEN_PARALLEL_FIELDS:
                target = fastgen_parallel_lines
            if comment:
                target.append(comment)
            target.append(f'{key}={default}')
            added.append(key)
        elif not existing_keys[key] and default and not _is_secret_env_key(key):
            # Ключ есть но пустой, а дефолт непустой — прописываем значение
            import re as _re
            text = _re.sub(
                rf'^({_re.escape(key)}\s*=)\s*$',
                rf'\g<1>{default}',
                text, count=1, flags=_re.MULTILINE
            )
            added.append(f'{key} (filled empty)')

    # Принудительная перезапись ключей
    for key, new_val in _ENV_FORCE:
        if _is_secret_env_key(key):
            continue
        if key in existing_keys and existing_keys[key] != new_val:
            import re as _re
            pattern = _re.compile(rf'^({_re.escape(key)}\s*=).*$', _re.MULTILINE)
            if pattern.search(text):
                text = pattern.sub(rf'\g<1>{new_val}', text)
                added.append(f'{key} (force-updated)')

    # Regex-миграции значений (например, localhost → 127.0.0.1)
    import re as _re
    for _pat, _repl, _note in _ENV_REGEX_MIGRATE:
        _new_text, _n = _re.subn(_pat, _repl, text)
        if _n > 0:
            text = _new_text
            added.append(f'regex-migrate x{_n}: {_note}')

    # Обновляем устаревшие значения
    for key, old_val, new_val in _ENV_UPGRADES:
        if key in existing_keys and existing_keys[key] == old_val:
            import re as _re
            pattern = _re.compile(rf'^({_re.escape(key)}\s*=\s*){_re.escape(old_val)}\s*$', _re.MULTILINE)
            if pattern.search(text):
                text = pattern.sub(rf'\g<1>{new_val}', text)
                added.append(f'{key} (upgraded)')

    if not added:
        return []

    text = _insert_env_lines_after_key(
        text,
        {'FASTGEN_API_KEY', 'FASTGEN_API_KEY_BACKUP', 'FASTGEN_API_KEY_2', 'FASTGEN_API_KEY_3', 'FASTGEN_API_KEY_4'},
        fastgen_key_lines,
    )
    text = _insert_env_lines_after_key(
        text,
        {'FASTGEN_MAX_PARALLEL', 'FASTGEN_MAX_PARALLEL_2', 'FASTGEN_MAX_PARALLEL_3', 'FASTGEN_MAX_PARALLEL_4'},
        fastgen_parallel_lines,
    )

    # Добавляем остальные новые ключи в конец файла
    if extra_lines:
        if not text.endswith('\n'):
            extra_lines.insert(0, '')
        text = text + '\n'.join(extra_lines) + '\n'

    env_path.write_text(text, encoding='utf-8')
    return added


def _install_fonts(root: Path, log=None):
    """Копирует шрифты из agent/fonts/ в системную папку шрифтов (если ещё не установлены)."""
    import platform
    import shutil

    fonts_dir = root / 'agent' / 'fonts'
    if not fonts_dir.exists():
        return

    system = platform.system()
    if system == 'Windows':
        # Per-user fonts — не требует прав администратора
        dest_dir = Path.home() / 'AppData' / 'Local' / 'Microsoft' / 'Windows' / 'Fonts'
    elif system == 'Darwin':
        dest_dir = Path.home() / 'Library' / 'Fonts'
    else:
        dest_dir = Path.home() / '.local' / 'share' / 'fonts'

    dest_dir.mkdir(parents=True, exist_ok=True)

    for font_file in fonts_dir.glob('*.ttf'):
        dest = dest_dir / font_file.name
        if dest.exists():
            continue
        try:
            shutil.copy2(str(font_file), str(dest))
            if log:
                log(f'  Шрифт установлен: {font_file.name}')
        except Exception as e:
            if log:
                log(f'  Шрифт {font_file.name}: не удалось ({e})')
