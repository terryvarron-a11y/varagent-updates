#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
chmod +x "$SCRIPT_DIR"/*.command 2>/dev/null

# Открываем в новом окне терминала если запущено двойным кликом
if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e 'tell app "Terminal" to do script "cd '\'''"$SCRIPT_DIR"'\'' && bash '\'''"$SCRIPT_DIR/varagent.command"'\'' ; exit"'
    exit 0
fi

cd "$SCRIPT_DIR"

# Activate Homebrew (needed on macOS to find brew-installed Python 3.10+)
if [ -f /opt/homebrew/bin/brew ]; then
    eval "$(/opt/homebrew/bin/brew shellenv)"
elif [ -f /usr/local/bin/brew ]; then
    eval "$(/usr/local/bin/brew shellenv)"
fi

# Always launch through the virtual environment created by install.command.
PY="$SCRIPT_DIR/.venv/bin/python3"
if [ ! -x "$PY" ]; then
    echo ""
    echo "[ERROR] VARAGENT virtual environment was not found."
    echo "Run install.command first."
    echo ""
    read -p "Press Enter to exit..."
    exit 1
fi

# Проверяем tkinter
$PY -c "import tkinter" 2>/dev/null
if [ $? -ne 0 ]; then
    echo ""
    echo "[ERROR] tkinter not found."
    _pyver=$($PY -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>/dev/null)
    echo "Install: brew install python-tk@${_pyver}"
    echo ""
    read -p "Press Enter to exit..."
    exit 1
fi

# Авто-установка недостающих пакетов
$PY -c "import requests" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "[INFO] Installing missing packages..."
    $PY -m pip install requests python-dotenv tqdm colorama 2>/dev/null || $PY -m pip install --break-system-packages requests python-dotenv tqdm colorama
fi

$PY "$SCRIPT_DIR/varagent.py" "$@"

if [ $? -ne 0 ]; then
    echo ""
    echo "[ERROR] VarAgent exited with error."
    read -p "Press Enter to exit..."
fi
