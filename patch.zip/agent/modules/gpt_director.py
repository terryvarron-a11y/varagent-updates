"""
GPT Director через Codex CLI.
Drop-in замена GeminiDirector — тот же интерфейс analyze().
"""
from __future__ import annotations

import json
import logging
import subprocess
import sys
import time
import threading
from pathlib import Path
from typing import Optional, Dict, Any
from datetime import datetime

import config
from modules.validator import validate_montage_plan_json, check_clip_id_sequence


class GptDirector:
    """Режиссёрский анализ через GPT (Codex CLI)"""

    def __init__(self, model_name: Optional[str] = None):
        self.model_name = model_name or config.GPT_MODEL
        self.codex_exe = Path(config.CODEX_EXE_PATH)
        self.schemas_dir = Path(__file__).parent.parent / 'schemas'
        self.prompts_dir = Path(__file__).parent.parent / 'prompts'
        self.timeout = config.GPT_DIRECTOR_TIMEOUT

        if not config.CODEX_EXE_PATH or not self.codex_exe.is_file():
            raise FileNotFoundError(f"Codex CLI не найден: {self.codex_exe}")

    # =========================================================================
    # ГЛАВНЫЙ МЕТОД — тот же интерфейс что у GeminiDirector
    # =========================================================================

    def analyze(
        self,
        transcription_path: str,
        style_guide_path: str,
        output_dir: str,
        project_name: str = "Untitled",
        two_pass: bool = False,
        prompts_only: bool = False,
        resume_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        output_dir = Path(output_dir)
        transcription_path = Path(transcription_path)
        style_guide_path = Path(style_guide_path)

        # Загрузить транскрипцию
        transcription = json.loads(transcription_path.read_text(encoding='utf-8'))
        audio_duration = transcription.get('audioDuration', 0)
        style_guide = style_guide_path.read_text(encoding='utf-8')

        results = {}

        if prompts_only:
            mp_path = output_dir / 'montage_plan.json'
            if not mp_path.exists():
                raise FileNotFoundError(f"montage_plan.json не найден: {mp_path}")
            montage_plan = json.loads(mp_path.read_text(encoding='utf-8'))
        else:
            # === PASS 1 — montage_plan.json ===
            montage_plan, mp_path = self._run_pass1(
                transcription_path, style_guide_path,
                output_dir, project_name, audio_duration, transcription
            )

        results['montage_plan'] = str(mp_path)
        results['num_clips'] = len(montage_plan.get('clips', []))

        # === PASS 2 — prompts ===
        # GPT через Codex всегда работает в two-pass режиме (два отдельных exec вызова)
        prompts_path, num_prompts = self._run_pass2(
            mp_path, transcription_path, style_guide_path,
            output_dir, project_name, montage_plan,
            resume_path=resume_path
        )
        results['prompts'] = str(prompts_path) if prompts_path else None
        results['num_prompts'] = num_prompts
        results['cost'] = {
            'total_cost': 0,
            'input_tokens': 0,
            'output_tokens': 0,
            'note': 'GPT via ChatGPT subscription'
        }
        return results

    # =========================================================================
    # CODEX SUBPROCESS WRAPPER
    # =========================================================================

    def _run_codex(
        self,
        task_prompt: str,
        schema_file: str,
        result_file: Path,
        working_dir: Path,
    ) -> dict:
        """
        Запуск codex exec и чтение control JSON.
        Возвращает распарсенный control dict.
        """
        schema_path = self.schemas_dir / schema_file

        if not schema_path.exists():
            raise FileNotFoundError(f"Schema не найдена: {schema_path}")

        # Удалить предыдущий result если есть
        if result_file.exists():
            result_file.unlink()

        cmd = [
            str(self.codex_exe), 'exec',
            task_prompt,
            '--output-schema', str(schema_path),
            '--output-last-message', str(result_file),
            '--dangerously-bypass-approvals-and-sandbox',
            '--skip-git-repo-check',
            '-m', self.model_name,
            '-C', str(working_dir),
        ]

        logging.info(f"Codex exec: model={self.model_name} schema={schema_file} cwd={working_dir}")
        t0 = time.time()

        # Run with real-time output streaming
        _stdout_lines = []
        _stderr_lines = []
        _returncode = [None]
        _done = threading.Event()
        _last_activity = [t0]

        def _exec():
            try:
                p = subprocess.Popen(
                    cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    text=True, encoding='utf-8', errors='replace',
                )
                # Read stdout in background thread
                def _read_stderr():
                    for line in p.stderr:
                        _stderr_lines.append(line.rstrip())
                        _last_activity[0] = time.time()
                serr_t = threading.Thread(target=_read_stderr, daemon=True)
                serr_t.start()

                for line in p.stdout:
                    line = line.rstrip()
                    if line:
                        _stdout_lines.append(line)
                        _last_activity[0] = time.time()
                        # Show Codex tool calls / file writes in real-time
                        ll = line.lower()
                        if any(k in ll for k in ('write', 'read', 'wrote', 'append', 'file', 'prompt')):
                            sys.stdout.write(f'\r   📝 {line[:100]:<100}\n')
                            sys.stdout.flush()

                p.wait(timeout=self.timeout)
                serr_t.join(timeout=5)
                _returncode[0] = p.returncode
            except subprocess.TimeoutExpired:
                p.kill()
                _returncode[0] = -1
            except Exception as e:
                _stderr_lines.append(str(e))
                _returncode[0] = -1
            finally:
                _done.set()

        thread = threading.Thread(target=_exec, daemon=True)
        thread.start()

        # Progress monitor (prints full lines for GUI compatibility)
        _last_size = 0
        _last_prompts = 0
        _last_print = 0
        _PRINT_INTERVAL = 15  # print progress every N seconds
        # Find prompts file to monitor
        _monitor_file = None

        while not _done.is_set():
            elapsed = time.time() - t0
            mins = int(elapsed) // 60
            secs = int(elapsed) % 60
            time_str = f"{mins}м {secs:02d}с" if mins > 0 else f"{secs}с"

            # Re-scan for prompts file periodically
            if not _monitor_file:
                _mf = list(working_dir.glob('*_prompts_*.txt'))
                if _mf:
                    _monitor_file = max(_mf, key=lambda f: f.stat().st_mtime)

            # Check prompts file growth
            _cur_prompts = _last_prompts
            _cur_size = _last_size
            if _monitor_file and _monitor_file.exists():
                try:
                    sz = _monitor_file.stat().st_size
                    if sz != _last_size:
                        _last_size = sz
                        _cur_size = sz
                        txt = _monitor_file.read_text(encoding='utf-8', errors='replace')
                        n = len([p for p in txt.strip().split('\n\n') if p.strip()])
                        if n != _last_prompts:
                            _last_prompts = n
                            _cur_prompts = n
                            # Print immediately when prompts count changes
                            print(f"   ⏳ GPT: {time_str} | {n} prompts written ({sz:,} bytes)")
                            _last_print = time.time()
                except Exception:
                    pass

            # Periodic progress print (even if nothing changed — shows it's alive)
            if time.time() - _last_print >= _PRINT_INTERVAL:
                extra = f" | {_cur_prompts} prompts, {_cur_size:,}b" if _cur_size > 0 else ""
                idle = time.time() - _last_activity[0]
                idle_warn = f" (idle {int(idle)}s)" if idle > 60 else ""
                print(f"   ⏳ GPT: {time_str}{extra}{idle_warn}")
                _last_print = time.time()

            _done.wait(2)

            # Hard timeout
            if elapsed > self.timeout:
                print(f"   ⏰ GPT timeout ({self.timeout}s)")
                logging.error(f"Codex timeout after {self.timeout}s")
                raise RuntimeError(f"Codex timeout after {self.timeout}s")

        elapsed = time.time() - t0
        mins = int(elapsed) // 60
        secs = int(elapsed) % 60
        time_str = f"{mins}м {secs:02d}с" if mins > 0 else f"{secs}с"

        if _returncode[0] == -1 and not _stdout_lines:
            sys.stdout.write(f'\r   ⏰ GPT timeout ({self.timeout}s)              \n')
            sys.stdout.flush()
            logging.error(f"Codex timeout after {self.timeout}s")
            raise RuntimeError(f"Codex timeout after {self.timeout}s")

        sys.stdout.write(f'\r   ✅ GPT — готово за {time_str}              \n')
        sys.stdout.flush()

        proc_stdout = '\n'.join(_stdout_lines)
        proc_stderr = '\n'.join(_stderr_lines)

        logging.info(f"Codex finished in {elapsed:.1f}s, exit_code={_returncode[0]}")

        # Извлечь tokens used из stderr/stdout
        for line in (proc_stderr).split('\n') + (proc_stdout).split('\n'):
            if 'tokens used' in line.lower():
                logging.info(f"Codex tokens: {line.strip()}")
                print(f"   📊 {line.strip()}")

        if _returncode[0] != 0:
            logging.error(f"Codex stderr (last 2000): {proc_stderr[-2000:]}")

        if not result_file.exists():
            raise RuntimeError(
                f"Codex не создал {result_file.name} "
                f"(exit {_returncode[0]}): {proc_stderr[:500]}"
            )

        raw = result_file.read_text(encoding='utf-8').strip()
        try:
            control = json.loads(raw)
        except json.JSONDecodeError as e:
            logging.error(f"Invalid JSON in {result_file}: {raw[:500]}")
            raise RuntimeError(f"Codex вернул невалидный JSON: {e}")

        logging.info(f"Codex control: {json.dumps(control, ensure_ascii=False)}")
        print(f"   ⏱  Codex: {elapsed:.0f}s, model={self.model_name}")
        return control

    # =========================================================================
    # PASS 2 — CODEX WITHOUT CONTROL JSON
    # =========================================================================

    def _run_codex_pass2(
        self,
        task_prompt: str,
        prompts_path: Path,
        n_clips: int,
        working_dir: Path,
    ) -> int:
        """
        Запуск codex для Pass 2 без --output-schema / --output-last-message.
        Мониторим файл промптов напрямую:
          - как только n_clips промптов написано и файл стабилен 15с — убиваем процесс
          - процесс завершился сам — читаем файл
          - hard timeout (self.timeout) с частичным восстановлением
        Возвращает суммарное количество промптов в файле (включая предыдущие чанки).
        """
        cmd = [
            str(self.codex_exe), 'exec',
            task_prompt,
            '--dangerously-bypass-approvals-and-sandbox',
            '--skip-git-repo-check',
            '-m', self.model_name,
            '-C', str(working_dir),
        ]

        logging.info(f"Codex Pass2: model={self.model_name}, expect={n_clips} prompts, cwd={working_dir}")
        t0 = time.time()

        _stderr_lines = []

        p = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True, encoding='utf-8', errors='replace',
        )

        def _drain_stderr():
            for line in p.stderr:
                _stderr_lines.append(line.rstrip())
        threading.Thread(target=_drain_stderr, daemon=True).start()

        _last_size = -1
        _last_prompts = 0
        _last_print = 0
        _file_stable_since = None
        _STABLE_SECS = 15
        _PRINT_INTERVAL = 15
        _early_exit = False

        while True:
            elapsed = time.time() - t0
            mins, secs = int(elapsed) // 60, int(elapsed) % 60
            time_str = f"{mins}м {secs:02d}с" if mins else f"{secs}с"

            # --- мониторинг файла промптов ---
            if prompts_path.exists():
                try:
                    sz = prompts_path.stat().st_size
                    if sz != _last_size:
                        _last_size = sz
                        _file_stable_since = None
                        txt = prompts_path.read_text(encoding='utf-8', errors='replace')
                        n = len([x for x in txt.strip().split('\n\n') if x.strip()])
                        if n != _last_prompts:
                            _last_prompts = n
                            print(f"   ⏳ GPT Pass2: {time_str} | {n}/{n_clips} промптов ({sz:,} bytes)")
                            _last_print = time.time()
                    else:
                        # размер не изменился
                        if _last_prompts >= n_clips:
                            if _file_stable_since is None:
                                _file_stable_since = time.time()
                            elif time.time() - _file_stable_since >= _STABLE_SECS:
                                print(f"   ✅ Все {n_clips} промптов написаны, файл стабилен {_STABLE_SECS}с — завершаем Codex")
                                logging.info(f"Pass2 early exit: {_last_prompts}/{n_clips} prompts, file stable")
                                p.kill()
                                _early_exit = True
                                break
                except Exception:
                    pass

            # --- процесс завершился сам ---
            if p.poll() is not None:
                break

            # --- hard timeout ---
            if elapsed > self.timeout:
                p.kill()
                if _last_prompts > 0:
                    logging.warning(f"Pass2 timeout ({self.timeout}s) but {_last_prompts} prompts found — recovering")
                    print(f"   ⏰ Таймаут {self.timeout}s, {_last_prompts}/{n_clips} промптов в файле — берём")
                    break
                proc_stderr = '\n'.join(_stderr_lines[-20:])
                raise RuntimeError(
                    f"Codex Pass2 timeout ({self.timeout}s): файл промптов не создан.\n{proc_stderr[:500]}"
                )

            # --- периодический прогресс ---
            if time.time() - _last_print >= _PRINT_INTERVAL:
                extra = f" | {_last_prompts}/{n_clips} промптов" if _last_size >= 0 else ""
                print(f"   ⏳ GPT Pass2: {time_str}{extra}")
                _last_print = time.time()

            time.sleep(2)

        elapsed = time.time() - t0
        mins, secs = int(elapsed) // 60, int(elapsed) % 60
        print(f"   ⏱  Codex Pass2: {mins}м {secs:02d}с")

        if not prompts_path.exists():
            proc_stderr = '\n'.join(_stderr_lines[-20:])
            raise RuntimeError(f"Codex Pass2: файл промптов не создан.\n{proc_stderr[:500]}")

        txt = prompts_path.read_text(encoding='utf-8', errors='replace')
        count = len([x for x in txt.strip().split('\n\n') if x.strip()])
        logging.info(f"Codex Pass2 done: {count} prompts in file, elapsed={elapsed:.1f}s")
        return count

    # =========================================================================
    # PASS 1 — MONTAGE PLAN
    # =========================================================================

    def _run_pass1(
        self,
        transcription_path: Path,
        style_guide_path: Path,
        output_dir: Path,
        project_name: str,
        audio_duration: float,
        transcription: dict,
    ) -> tuple:
        """
        Pass 1: транскрипция + стайлгайд → montage_plan.json.
        Один exec вызов.
        """
        mp_path = output_dir / 'montage_plan.json'
        result_file = output_dir / '_codex_pass1_control.json'

        # Загрузить системную инструкцию
        sys_instr_path = self.prompts_dir / 'director_instruction_pass1.txt'
        pause_guide_path = self.prompts_dir / 'director_pause_guide.txt'

        task_prompt = self._build_pass1_prompt(
            transcription_path, style_guide_path, sys_instr_path,
            pause_guide_path, mp_path, project_name, audio_duration
        )

        print(f"\n🎬 GPT Pass 1: создание монтажного плана...")
        print(f"   Модель: {self.model_name}")
        print(f"   Аудио: {audio_duration:.0f}с ({audio_duration/60:.1f} мин)")

        control = self._run_codex(task_prompt, 'pass1_control.json', result_file, output_dir)

        if control.get('status') != 'ok':
            raise RuntimeError(f"GPT Pass 1 failed: {control.get('error_message', 'unknown')}")

        # Прочитать и провалидировать montage_plan.json
        actual_mp_path = Path(control.get('montage_plan_path', str(mp_path)))
        if not actual_mp_path.exists():
            actual_mp_path = mp_path

        if not actual_mp_path.exists():
            raise RuntimeError(f"montage_plan.json не создан: {actual_mp_path}")

        montage_plan = json.loads(actual_mp_path.read_text(encoding='utf-8'))

        # Нормализация обёртки
        if 'montage_plan' in montage_plan and 'clips' in montage_plan['montage_plan']:
            montage_plan = montage_plan['montage_plan']

        # Валидация через существующий валидатор
        is_valid, errors = validate_montage_plan_json(montage_plan, audio_duration)
        if not is_valid:
            logging.warning(f"GPT montage plan validation: {errors}")
            print(f"   ⚠️  Валидация: {len(errors)} замечаний (авто-коррекция)")
        else:
            print(f"   ✅ Валидация монтажного плана — OK")

        # Проверка ID последовательности
        id_problems = check_clip_id_sequence(montage_plan.get('clips', []))
        if id_problems:
            logging.warning(f"GPT montage plan ID issues: {id_problems}")
            print(f"   ⚠️  ID последовательность: {len(id_problems)} проблем (авто-коррекция)")
            # Авто-коррекция: перенумерация 1..N
            for i, clip in enumerate(montage_plan.get('clips', [])):
                clip['id'] = i + 1
                clip['file'] = f"{i + 1}.mp4"

        # Перезаписать нормализованный план
        mp_path.write_text(
            json.dumps(montage_plan, indent=2, ensure_ascii=False),
            encoding='utf-8'
        )

        clips = montage_plan.get('clips', [])
        _mp_chars = len(mp_path.read_text(encoding='utf-8'))
        print(f"   ✅ Монтажный план: {len(clips)} клипов, {audio_duration:.0f}с")
        print(f"   📊 Plan output: {_mp_chars:,} chars ≈ {_mp_chars // 3:,} tokens")
        return montage_plan, mp_path

    def _build_pass1_prompt(
        self,
        transcription_path: Path,
        style_guide_path: Path,
        sys_instr_path: Path,
        pause_guide_path: Path,
        mp_path: Path,
        project_name: str,
        audio_duration: float,
    ) -> str:
        """Сборка промпта для Pass 1."""
        t_path = transcription_path.as_posix()
        sg_path = style_guide_path.as_posix()
        si_path = sys_instr_path.as_posix()
        pg_path = pause_guide_path.as_posix()
        out_path = mp_path.as_posix()

        clip_min = config.ACTIVE_CLIP_MIN_DURATION
        clip_max = config.ACTIVE_CLIP_MAX_DURATION
        intro_min = config.get_intro_clip_min()
        intro_max = config.get_intro_clip_max()
        intro_block = config.INTRO_BLOCK_DURATION

        return f"""You are a film director creating a montage plan for a documentary.

## SYSTEM INSTRUCTION
Read the director instruction file: {si_path}
Also read the pause guide: {pg_path}

When reading the instruction, apply these substitutions:
- {{clip_min_dur}} = {clip_min}
- {{clip_max_dur}} = {clip_max}
- {{clip_intro_min_dur}} = {intro_min}
- {{clip_intro_max_dur}} = {intro_max}
- {{intro_block_dur}} = {intro_block}

## STYLE GUIDE
Read the style guide file: {sg_path}

## TRANSCRIPTION
Read the transcription file: {t_path}

## PROJECT
Name: {project_name}
Audio duration: {audio_duration:.2f} seconds

## TASK
1. Read ALL files listed above
2. Generate a montage plan following the director instruction rules
3. Write the result as JSON to: {out_path}

The JSON must have this structure:
{{
  "montage_plan": {{
    "audioDuration": {audio_duration:.2f},
    "clips": [
      {{"id": 1, "file": "1.mp4", "startTime": 0.0, "endTime": 7.8}},
      {{"id": 2, "file": "2.mp4", "startTime": 7.8, "endTime": 14.2}},
      ...
    ]
  }}
}}

Rules:
- Each clip duration: {clip_min}–{clip_max} seconds
- Clips must be continuous (no gaps): clip N endTime = clip N+1 startTime
- First clip startTime = 0.0
- Last clip endTime must equal audioDuration ({audio_duration:.2f})
- IDs sequential: 1, 2, 3, ...
- File format: "{{id}}.mp4"

Write the JSON file and then report your status in your final response."""

    # =========================================================================
    # PASS 2 — PROMPTS
    # =========================================================================

    def _run_pass2(
        self,
        mp_path: Path,
        transcription_path: Path,
        style_guide_path: Path,
        output_dir: Path,
        project_name: str,
        montage_plan: dict,
        resume_path: Optional[str] = None,
    ) -> tuple:
        """
        Pass 2: montage_plan + стайлгайд → промпты per clip.
        Возвращает (prompts_path, num_prompts).
        """
        clips = montage_plan.get('clips', [])
        total_clips = len(clips)
        if total_clips == 0:
            print("   ❌ Монтажный план пуст — нечего промптировать")
            return None, 0

        chunk_size = config.GPT_PASS2_CHUNK_SIZE or total_clips

        timestamp = datetime.now().strftime('%Y%m%d_%H%M')
        prompts_path = output_dir / f'{project_name}_prompts_{timestamp}.txt'
        total_prompts = 0
        cursor = 0
        chunk_idx = 0

        # Load transcription fragments for clip cards
        transcription = json.loads(transcription_path.read_text(encoding='utf-8'))
        fragments = transcription.get('transcription', [])

        # Resume: подсчитать существующие промпты
        if resume_path:
            rp = Path(resume_path)
            if rp.exists():
                prompts_path = rp
                existing = rp.read_text(encoding='utf-8').strip().split('\n\n')
                total_prompts = len([p for p in existing if p.strip()])
                cursor = total_prompts
                print(f"   ↩️  Resume: {total_prompts} промптов уже есть, продолжаем с клипа {cursor + 1}")

        while cursor < total_clips:
            chunk_end = min(cursor + chunk_size, total_clips)
            chunk_clips = clips[cursor:chunk_end]
            from_id = chunk_clips[0]['id']
            to_id = chunk_clips[-1]['id']
            n_clips = len(chunk_clips)

            # Build clip cards with voiceover text (like Gemini)
            clip_cards = []
            for clip in chunk_clips:
                cs = clip.get('startTime', 0)
                ce = clip.get('endTime', 0)
                texts = [f['text'] for f in fragments
                         if f.get('start', 0) < ce and f.get('end', 0) > cs]
                text = ' '.join(texts).strip() or '(pause)'
                clip_cards.append(
                    f"[CLIP {clip['id']}] {cs:.1f}–{ce:.1f}s\n"
                    f"VOICEOVER: {text}"
                )
            clip_block = '\n\n'.join(clip_cards)

            # Previous plot context (last 5 clips before this chunk)
            prev_plot = ""
            if cursor > 0:
                prev_start = max(0, cursor - 5)
                plot_lines = []
                for c in clips[prev_start:cursor]:
                    cs, ce = c.get('startTime', 0), c.get('endTime', 0)
                    texts = [f['text'] for f in fragments
                             if f.get('start', 0) < ce and f.get('end', 0) > cs]
                    plot_lines.append(f"Clip {c['id']} ({cs:.1f}-{ce:.1f}s): {' '.join(texts).strip()}")
                prev_plot = '\n'.join(plot_lines)

            # Контекст предыдущих промптов
            prev_sample = ""
            if prompts_path.exists() and total_prompts > 0:
                existing = prompts_path.read_text(encoding='utf-8').strip().split('\n\n')
                prev_sample = '\n\n'.join(existing[-5:])

            task_prompt = self._build_pass2_prompt(
                style_guide_path, prompts_path,
                clip_block, from_id, to_id, n_clips, total_clips,
                prev_sample, prev_plot, total_prompts > 0
            )

            chunk_label = f" (клипы {from_id}–{to_id})" if total_clips > chunk_size else ""
            print(f"\n✍️  GPT Pass 2: генерация промптов{chunk_label}...")

            file_total = self._run_codex_pass2(task_prompt, prompts_path, n_clips, output_dir)

            written = file_total - total_prompts  # добавлено в этом чанке
            chunk_idx += 1

            # Output stats
            if prompts_path.exists():
                _fsize = prompts_path.stat().st_size
                _chars = len(prompts_path.read_text(encoding='utf-8'))
                _est_tokens = _chars // 3
                print(f"   → Записано: {written}, всего: {file_total}/{total_clips}")
                print(f"   📊 Output: {_chars:,} chars ≈ {_est_tokens:,} tokens ({_fsize:,} bytes)")
            else:
                print(f"   → Записано: {written}, всего: {file_total}/{total_clips}")

            total_prompts = file_total

            if written < n_clips:
                # частичная запись — берём что есть и останавливаемся
                logging.warning(f"Pass2 partial chunk: {written}/{n_clips}, stopping")
                break

            cursor = chunk_end

            if chunk_end >= total_clips:
                break

        # Финальная валидация
        if prompts_path.exists():
            actual = prompts_path.read_text(encoding='utf-8').strip().split('\n\n')
            actual_count = len([p for p in actual if p.strip()])
            if actual_count != total_prompts:
                logging.warning(f"Prompts count mismatch: control={total_prompts}, file={actual_count}")
                total_prompts = actual_count

            # Trim если больше чем клипов
            if total_prompts > total_clips:
                logging.warning(f"Overprompt: {total_prompts}>{total_clips}, trimming")
                all_p = [p for p in actual if p.strip()]
                prompts_path.write_text(
                    '\n\n'.join(all_p[:total_clips]),
                    encoding='utf-8'
                )
                total_prompts = total_clips

        print(f"\n✅ GPT Pass 2 завершён: {total_prompts}/{total_clips} промптов")
        return prompts_path if total_prompts > 0 else None, total_prompts

    def _build_pass2_prompt(
        self,
        style_guide_path: Path,
        prompts_path: Path,
        clip_block: str,
        from_id: int,
        to_id: int,
        n_clips: int,
        total_clips: int,
        prev_sample: str,
        prev_plot: str,
        append_mode: bool,
    ) -> str:
        """Сборка промпта для Pass 2 с clip cards (как Gemini)."""
        prev_section = ""
        if prev_sample:
            prev_section = f"""
## PREVIOUS PROMPTS (for style consistency — continue in the same format)
{prev_sample}
"""
        plot_section = ""
        if prev_plot:
            plot_section = f"""
## PREVIOUS SCENE CONTEXT (what was just visualized)
{prev_plot}
"""

        write_mode = "Append to the existing file (do NOT overwrite previous content)." if append_mode else "Create a new file."

        return f"""You are a film director writing visual prompts for image generation.

## STYLE GUIDE
Read the style guide file: {style_guide_path.as_posix()}
{plot_section}{prev_section}
## CLIPS TO PROCESS ({n_clips} clips, {from_id}–{to_id} out of {total_clips} total)

{clip_block}

## TASK
Write one visual prompt per clip above. For each clip:
1. Use the VOICEOVER text provided — write a prompt that visualizes ONLY that voiceover
2. Apply the style guide: camera angles, lighting, atmosphere, negative prompt
3. Prompt for clip N describes ONLY what is heard in clip N — do NOT look ahead

STRICT OUTPUT RULES:
- Each prompt = ONE continuous line, no line breaks inside the prompt
- Prompts separated by ONE blank line between them
- Exactly {n_clips} prompts, one per clip
- NO numbering, NO clip IDs, NO headers in the output
- Alternate camera angles: wide → medium → close-up → wide
- Each prompt must end with: "single full-frame continuous camera view edge-to-edge"

Write all {n_clips} prompts to: {prompts_path.as_posix()}
{write_mode}

Report your status in your final response."""


# =========================================================================
# Wrapper function — аналог direct_project() для GptDirector
# =========================================================================

def gpt_direct_project(
    transcription_path: str,
    style_guide_path: str,
    output_dir: str,
    project_name: str = "Untitled",
    model_name: Optional[str] = None,
    two_pass: bool = False,
    prompts_only: bool = False,
    resume_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Wrapper: создаёт GptDirector и запускает analyze()."""
    director = GptDirector(model_name=model_name)
    return director.analyze(
        transcription_path, style_guide_path, output_dir, project_name,
        two_pass=two_pass, prompts_only=prompts_only, resume_path=resume_path,
    )
