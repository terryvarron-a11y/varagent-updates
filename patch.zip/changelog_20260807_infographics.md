# Infographics Changelog

## Step 1 - Foundation and director prompts

- Created a pre-change backup in `_codex_backups/20260807_infographics`.
- Added the `infographic` clip source and shared helpers for static media.
- Added infographic settings to config, `.env.example`, and updater requirements.
- Added `agent/prompts/infographic_default_style.txt` as the editable fallback style.
- Wired the Pass 1 directors to allocate eligible clips to infographic output.
- Wired Pass 2 prompt construction to preserve the source marker and apply either
  the style-guide infographic section or the editable default style.

Status: image-generator routing, video exclusion, concat behavior, GUI controls,
tests, and portable sync are still in progress.

## Step 2 - Dedicated media route and GUI

- Normal FastGen and VeoNonStop image runs now exclude infographic clips.
- Added a dedicated infographic image route in `agent.py`, with its own provider
  and model settings. It runs before every VideoGen action and stages stills in
  both `generated/` and `vid_img/`.
- Added a dedicated retry for missing infographic media before concat. The retry
  preserves `source: infographic` instead of silently converting it to a normal
  scene.
- Updated Veo, Flow Ultra, and both inflight watchers to skip all static sources,
  including infographics.
- Added the Pipeline GUI Infographics card: enable switch, target/max share,
  separate provider and model controls.
- Added the Concat GUI option to keep infographic clips static. When enabled,
  concat uses a fixed frame with no Ken Burns movement.
- Added the editable fallback style to the Prompts tab.

Status: validation, focused tests, portable sync, and checksum verification remain.

## Step 3 - Validation and Tk portable sync

- Recompiled all touched API modules, `varagent.py`, and `video_concat.py`.
- Added and ran `agent/test_infographics.py`: 2 tests passed.
- Confirmed `video_concat.py --help` exposes both infographic concat flags.
- Backed up the pre-sync portable files in
  `VARAGENT_API_PORTABLE/_codex_backups/20260807_infographics_before_sync`.
- Synced 20 runtime files from `VARAGENT_API` to `VARAGENT_API_PORTABLE`.
- Verified all 20 synced files with MD5 checksums and compiled the portable copy.

Status: complete. No publish or repository operation was performed.

## Step 4 - Tk portable release preflight

- Verified the Tk runtime files already match between `VARAGENT_API` and
  `VARAGENT_API_PORTABLE` with MD5 checksums.
- Added the missing infographic defaults to the portable `.env`; all values
  are safe defaults and contain no user credentials.
- Hardened `publisher.py` so `_codex_backups` is excluded from `patch.zip`.
- Created preflight backups before these changes in each Tk pair member.

Status: ready for final checksum verification and publish.

## Step 5 - Verification

- Confirmed the publisher collects 240 distribution files and zero files from
  `_codex_backups`.
- Re-ran the secret scan for published updater settings and portable `.env`:
  no Google, OpenAI, or Anthropic keys were found.
- Compiled the affected API and portable runtime modules, including the Tk GUI
  and concat script.
- Ran the focused suite: infographic, Veo censorship fallback, and remix chain
  tests; 6 tests passed.

Status: verified and ready for Tk portable publication.

## Step 6 - Tk pair sync

- Synced the release changelog into `VARAGENT_API_PORTABLE`.
- Verified the deployable Tk product surface with MD5: 0 differences between
  API and portable, excluding intentional user-local configuration.
- Confirmed the portable infographic defaults are present and the publisher has
  both required GitHub configuration values.

Status: Tk portable is synchronized and ready for the publisher release.
