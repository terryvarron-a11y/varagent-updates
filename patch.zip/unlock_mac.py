#!/usr/bin/env python3
# UNLOCK_MAC.PY - First-run unlocker for macOS
# Run: python3 unlock_mac.py
# (Python scripts don't need execute bit - works on first run)

import os
import subprocess
import glob

script_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(script_dir)

print()
print("=" * 72)
print(" SCENAGENT RTG - macOS Unlocker")
print("=" * 72)
print()

# 1. chmod +x all .command and .sh files
count = 0
for pattern in ("*.command", "*.sh"):
    for f in sorted(glob.glob(pattern)):
        os.chmod(f, 0o755)
        print(f"  chmod +x {f}")
        count += 1

if count == 0:
    print("  [WARN] No .command or .sh files found in this folder")
    print(f"  Make sure you run this from the Var_Agent folder: {script_dir}")
else:
    print(f"  [OK] {count} files made executable")

print()

# 2. Remove quarantine (xattr -cr .)
result = subprocess.run(
    ["xattr", "-cr", "."],
    capture_output=True
)
if result.returncode == 0:
    print("  [OK] Quarantine attribute removed (xattr -cr .)")
else:
    stderr = result.stderr.decode("utf-8", errors="replace").strip()
    if stderr:
        print(f"  [WARN] xattr: {stderr}")
    else:
        print("  [OK] xattr done (no quarantine attributes found)")

print()
print("=" * 72)
print(" DONE! Now double-click: install.command")
print("=" * 72)
print()
input("Press Enter to exit...")
