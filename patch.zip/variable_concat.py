#!/usr/bin/env python3
"""
VARIABLE CONCAT - v1
Сборка ролика из смеси фото и видео по montage_plan.json.

• Фото (.png/.jpg/.jpeg/.webp) → Ken Burns эффект (чередование зум/отдаление)
• Видео (.mp4/.mov) → перекодировка к целевому resolution+fps с обрезкой по таймингу
• Прямой cut-монтаж (без xfade-переходов)
• Источник длительностей клипов — montage_plan.json (startTime/endTime)
• GPU ускорение (NVENC / AMF / libx264 fallback)
"""

import subprocess
import json
import sys
import os
import argparse
from pathlib import Path
from tqdm import tqdm
import platform
import time
import shutil
import logging
from datetime import datetime
import traceback

if platform.system() == 'Windows':
    SUBPROCESS_FLAGS = {'creationflags': 0x08000000}
else:
    SUBPROCESS_FLAGS = {}

logger = None

# Границы Ken Burns
KB_MIN_ZOOM = 1.0
KB_MAX_ZOOM = 1.43

# ============================================================================
# ЛОГГИРОВАНИЕ
# ============================================================================

def setup_logging():
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = f'variable_concat_{timestamp}.log'

    _logger = logging.getLogger('VariableConcat')
    _logger.setLevel(logging.DEBUG)

    formatter = logging.Formatter(
        '%(asctime)s | %(levelname)-8s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    fh = logging.FileHandler(log_file, encoding='utf-8')
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(formatter)
    _logger.addHandler(fh)

    ch = logging.StreamHandler()
    ch.setLevel(logging.WARNING)
    ch.setFormatter(formatter)
    _logger.addHandler(ch)

    _logger.info("=" * 80)
    _logger.info("НАЧАЛО РАБОТЫ VARIABLE CONCAT")
    _logger.info("=" * 80)

    return _logger, log_file


# ============================================================================
# ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
# ============================================================================

def get_audio_duration(audio_path):
    try:
        result = subprocess.run(
            ['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
             '-of', 'default=noprint_wrappers=1:nokey=1', str(audio_path)],
            capture_output=True, text=True, check=True, **SUBPROCESS_FLAGS
        )
        duration = float(result.stdout.strip())
        logger.info(f"Длительность аудио: {duration:.2f} сек")
        return duration
    except Exception as e:
        logger.error(f"Ошибка получения длительности аудио: {e}")
        print(f"❌ Ошибка получения длительности аудио: {e}")
        sys.exit(1)


def get_video_duration(video_path):
    try:
        result = subprocess.run(
            ['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
             '-of', 'default=noprint_wrappers=1:nokey=1', str(video_path)],
            capture_output=True, text=True, check=True, **SUBPROCESS_FLAGS
        )
        return float(result.stdout.strip())
    except Exception:
        return 0.0


def get_file_size_mb(file_path):
    try:
        return os.path.getsize(str(file_path)) / (1024 * 1024)
    except Exception:
        return 0.0


def _test_encoder(codec):
    try:
        cmd = [
            'ffmpeg', '-hide_banner', '-loglevel', 'error',
            '-f', 'lavfi', '-i', 'nullsrc=s=64x64:d=0.1',
            '-c:v', codec, '-frames:v', '1', '-f', 'null', '-'
        ]
        r = subprocess.run(cmd, capture_output=True, timeout=10, **SUBPROCESS_FLAGS)
        return r.returncode == 0
    except Exception:
        return False


def detect_gpu_encoder(force_amd=False):
    logger.debug("Определение GPU энкодера")
    try:
        result = subprocess.run(
            ['ffmpeg', '-hide_banner', '-encoders'],
            capture_output=True, text=True, **SUBPROCESS_FLAGS
        )
        if 'h264_amf' in result.stdout and _test_encoder('h264_amf'):
            logger.info("AMD GPU (h264_amf)")
            return 'amd', 'h264_amf'
        if 'h264_nvenc' in result.stdout and not force_amd and _test_encoder('h264_nvenc'):
            logger.info("NVIDIA GPU (h264_nvenc)")
            return 'nvidia', 'h264_nvenc'
        logger.info("CPU (libx264)")
        return 'cpu', 'libx264'
    except Exception as e:
        logger.warning(f"Ошибка определения GPU: {e}")
        return 'cpu', 'libx264'


def get_encoder_params(encoder_type, codec, bitrate='10M'):
    bval = int(bitrate.rstrip('M')) if bitrate.endswith('M') else 10
    buf = f'{bval * 2}M'
    if encoder_type == 'nvidia':
        return ['-c:v', codec, '-preset', 'p4', '-tune', 'hq',
                '-b:v', bitrate, '-maxrate', bitrate, '-bufsize', buf,
                '-profile:v', 'high', '-pix_fmt', 'yuv420p']
    elif encoder_type == 'amd':
        return ['-c:v', codec, '-quality', 'speed',
                '-b:v', bitrate, '-maxrate', bitrate, '-bufsize', buf,
                '-profile:v', 'high', '-pix_fmt', 'yuv420p']
    else:
        return ['-c:v', codec, '-preset', 'medium',
                '-b:v', bitrate, '-maxrate', bitrate, '-bufsize', buf,
                '-profile:v', 'high', '-pix_fmt', 'yuv420p']


def run_ffmpeg_with_progress(cmd, total_duration, description="Processing"):
    logger.debug(f"FFmpeg: {description}")
    cmd_with_progress = cmd + ['-progress', 'pipe:1']
    process = subprocess.Popen(
        cmd_with_progress, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        universal_newlines=True, **SUBPROCESS_FLAGS
    )
    start_time = time.time()
    last_refresh = start_time

    if total_duration is None or total_duration <= 0:
        bar_fmt = '{l_bar}{bar}| {n:.1f}s [{elapsed}]'
        tqdm_total = None
    else:
        bar_fmt = '{l_bar}{bar}| {n:.1f}/{total:.1f}s [{elapsed}]'
        tqdm_total = total_duration

    with tqdm(total=tqdm_total, desc=description, unit="s", bar_format=bar_fmt) as pbar:
        last_t = 0
        for line in process.stdout:
            line = line.strip()
            if line.startswith('out_time_us=') or line.startswith('out_time_ms='):
                try:
                    val = line.split('=')[1]
                    if val and val != 'N/A':
                        time_s = int(val) / 1_000_000.0
                        delta = time_s - last_t
                        if delta > 0:
                            pbar.update(delta)
                            last_t = time_s
                except (ValueError, IndexError):
                    pass
            now = time.time()
            if now - last_refresh >= 1.0:
                pbar.refresh()
                last_refresh = now

    process.wait()
    elapsed = time.time() - start_time
    logger.info(f"{description} завершено за {elapsed:.1f}с")

    if process.returncode != 0:
        logger.error(f"FFmpeg ошибка returncode={process.returncode}")
        raise subprocess.CalledProcessError(process.returncode, cmd)


def ask_delete_temp_folder(temp_dir):
    temp_dir = Path(temp_dir)
    if not temp_dir.exists():
        return
    try:
        size_mb = sum(
            f.stat().st_size for f in temp_dir.rglob('*') if f.is_file()
        ) / (1024 * 1024)
    except Exception:
        size_mb = 0
    print(f"\n🧹 Временная папка: {temp_dir}")
    print(f"   💾 Размер: {size_mb:.0f} MB")
    print()
    while True:
        response = input("Удалить временную папку? (y/n): ").strip().lower()
        if response in ['y', 'yes', 'д', 'да']:
            try:
                shutil.rmtree(temp_dir)
                print("   ✅ Папка удалена")
                logger.info("Временная папка удалена")
            except Exception as e:
                print(f"   ⚠️  Ошибка удаления: {e}")
            break
        elif response in ['n', 'no', 'н', 'нет']:
            print(f"   ✅ Папка сохранена: {temp_dir.absolute()}")
            break
        else:
            print("   ⚠️  Введите 'y' (да) или 'n' (нет)")


# ============================================================================
# АВТОСИНХРОНИЗАЦИЯ ВИДЕО/АУДИО
# ============================================================================

def fix_video_audio_sync(video_path, audio_path, temp_dir, encoder_type, codec, bitrate):
    """Автоисправление рассинхронизации финального видео и аудио.

    Стратегии (по возрастанию разницы):
      ≤ 0.5с — ничего не делать (допустимо)
      ≤ 5с   — обрезка / freeze frame (без перекодирования)
      > 5с   — изменение скорости (с перекодированием)
    """
    logger.info("ЭТАП 3.5: ПРОВЕРКА СИНХРОНИЗАЦИИ ВИДЕО/АУДИО")
    print("\n" + "=" * 80)
    print("🔧 ЭТАП 3.5: ПРОВЕРКА СИНХРОНИЗАЦИИ")
    print("=" * 80)

    video_duration = get_video_duration(video_path)
    audio_dur = get_audio_duration(audio_path)
    diff = video_duration - audio_dur
    diff_str = f"+{diff:.2f}с" if diff >= 0 else f"{diff:.2f}с"
    print(f"\n📊 Видео: {video_duration:.2f}с  |  Аудио: {audio_dur:.2f}с  |  Разница: {diff_str}")
    logger.info(f"Видео: {video_duration:.2f}с, аудио: {audio_dur:.2f}с, разница: {diff:.2f}с")

    if abs(diff) <= 0.5:
        mark = "✅ Идеально" if abs(diff) <= 0.1 else "✅ Допустимо"
        print(f"{mark} (разница {abs(diff):.2f}с)")
        print("=" * 80)
        return video_path

    fixed_video = Path(temp_dir) / 'concat_synced.mp4'

    if abs(diff) <= 5.0:
        if diff > 0:
            # Видео длиннее — обрезаем без перекодирования
            print(f"🔧 Видео длиннее на {diff:.2f}с — обрезаем (без перекодирования)...")
            logger.info(f"Обрезка видео на {diff:.2f}с")
            subprocess.run([
                'ffmpeg', '-y',
                '-i', str(video_path),
                '-t', str(audio_dur),
                '-c', 'copy',
                str(fixed_video)
            ], check=True, capture_output=True, **SUBPROCESS_FLAGS)
        else:
            # Видео короче — freeze frame в конец
            freeze_duration = abs(diff)
            print(f"🔧 Видео короче на {freeze_duration:.2f}с — добавляем freeze frame...")
            logger.info(f"Freeze frame: {freeze_duration:.2f}с")

            temp_frame = Path(temp_dir) / 'last_frame_sync.png'
            subprocess.run([
                'ffmpeg', '-y', '-sseof', '-1',
                '-i', str(video_path),
                '-update', '1', '-q:v', '1', str(temp_frame)
            ], check=True, capture_output=True, **SUBPROCESS_FLAGS)

            freeze_clip = Path(temp_dir) / 'freeze_end.mp4'
            encoder_params = get_encoder_params(encoder_type, codec, bitrate)
            subprocess.run([
                'ffmpeg', '-y', '-loop', '1',
                '-i', str(temp_frame),
                '-t', str(freeze_duration), '-r', '60'
            ] + encoder_params + ['-an', str(freeze_clip)],
                check=True, capture_output=True, **SUBPROCESS_FLAGS)
            temp_frame.unlink()

            concat_sync_list = Path(temp_dir) / 'concat_sync.txt'
            with open(concat_sync_list, 'w', encoding='utf-8') as f:
                f.write(f"file '{Path(video_path).absolute()}'\n")
                f.write(f"file '{freeze_clip.absolute()}'\n")
            subprocess.run([
                'ffmpeg', '-y', '-f', 'concat', '-safe', '0',
                '-i', str(concat_sync_list),
                '-c', 'copy', str(fixed_video)
            ], check=True, capture_output=True, **SUBPROCESS_FLAGS)

        result_dur = get_video_duration(fixed_video)
        print(f"✅ Готово: {result_dur:.2f}с (разница {abs(result_dur - audio_dur):.2f}с)")
        logger.info(f"Синхронизация исправлена: {result_dur:.2f}с")
        print("=" * 80)
        return fixed_video

    # > 5 сек — изменяем скорость (перекодирование)
    speed_factor = video_duration / audio_dur
    action = "ускоряем" if diff > 0 else "замедляем"
    print(f"🔧 Большая разница {abs(diff):.2f}с — {action} видео: {speed_factor:.4f}× (перекодирование)...")
    logger.warning(f"Изменение скорости: {speed_factor:.4f}×")

    encoder_params = get_encoder_params(encoder_type, codec, bitrate)
    subprocess.run([
        'ffmpeg', '-y', '-i', str(video_path),
        '-filter:v', f'setpts={1/speed_factor}*PTS',
        '-r', '60'
    ] + encoder_params + [str(fixed_video)],
        check=True, capture_output=True, **SUBPROCESS_FLAGS)

    result_dur = get_video_duration(fixed_video)
    print(f"✅ Готово: {result_dur:.2f}с (разница {abs(result_dur - audio_dur):.2f}с)")
    logger.info(f"Скорость изменена: {result_dur:.2f}с")
    print("=" * 80)
    return fixed_video


# ============================================================================
# ПОИСК ФАЙЛОВ (видео или фото) ПО CLIP ID
# ============================================================================

VIDEO_EXTS = ['mp4', 'mov']
IMAGE_EXTS = ['png', 'jpg', 'jpeg', 'webp']


def find_file(clip_id):
    """
    Ищет файл для клипа по ID.

    Порядок поиска:
      1. Видео: {id}.mp4|mov, {id:03d}.mp4|mov
      2. Фото:  vid_img/{id:03d}.png|jpg|jpeg|webp
                {id:03d}.png|jpg|jpeg|webp
                {id}.png|jpg|jpeg|webp

    Возвращает (Path, 'video'|'image') или (None, None).
    """
    base = Path('.')

    # 1. Видео (из vid_img/)
    for fmt in [f'{clip_id}', f'{clip_id:03d}']:
        for ext in VIDEO_EXTS:
            p = base / 'vid_img' / f'{fmt}.{ext}'
            if p.exists():
                return p, 'video'

    # 2. Фото — vid_img/
    for fmt in [f'{clip_id:03d}', f'{clip_id}']:
        for ext in IMAGE_EXTS:
            p = base / 'vid_img' / f'{fmt}.{ext}'
            if p.exists():
                return p, 'image'

    # 3. Фото — с паддингом
    for ext in IMAGE_EXTS:
        p = base / f'{clip_id:03d}.{ext}'
        if p.exists():
            return p, 'image'

    # 4. Фото — без паддинга
    for ext in IMAGE_EXTS:
        p = base / f'{clip_id}.{ext}'
        if p.exists():
            return p, 'image'

    return None, None


# ============================================================================
# KEN BURNS: ОДИН КЛИП ИЗ ФОТО
# ============================================================================

def build_ken_burns_clip(image_path, output_path, duration, clip_id,
                         out_w, out_h, fps, encoder_type, codec, bitrate):
    """
    Создаёт видеоклип из изображения с эффектом Ken Burns.

    Нечётный clip_id → отдаление: ×1.43 → ×1.0
    Чётный  clip_id → приближение: ×1.0 → ×1.43
    """
    base_w = int(out_w * KB_MAX_ZOOM) + 2
    base_h = int(out_h * KB_MAX_ZOOM) + 2
    base_w += base_w % 2
    base_h += base_h % 2

    if clip_id % 2 == 1:
        z_start = KB_MAX_ZOOM
        z_end   = KB_MIN_ZOOM
    else:
        z_start = KB_MIN_ZOOM
        z_end   = KB_MAX_ZOOM

    z_range = z_end - z_start
    dur = max(duration, 0.001)

    scale_w_expr = f"trunc(({base_w}*({z_start:.6f}+{z_range:.6f}*t/{dur:.6f})/{KB_MAX_ZOOM:.6f})/2)*2"
    scale_h_expr = f"trunc(({base_h}*({z_start:.6f}+{z_range:.6f}*t/{dur:.6f})/{KB_MAX_ZOOM:.6f})/2)*2"

    vf = (
        f'scale={base_w}:{base_h}:force_original_aspect_ratio=increase,'
        f'crop={base_w}:{base_h},'
        f"scale='{scale_w_expr}':'{scale_h_expr}':flags=lanczos:eval=frame,"
        f'crop={out_w}:{out_h}:(iw-{out_w})/2:(ih-{out_h})/2,'
        f'format=yuv420p'
    )

    encoder_params = get_encoder_params(encoder_type, codec, bitrate)

    n_frames = max(1, round(duration * fps))

    cmd = [
        'ffmpeg', '-y', '-nostdin',
        '-loop', '1',
        '-framerate', str(fps),
        '-i', str(image_path),
        '-vf', vf,
        '-frames:v', str(n_frames),
        '-r', str(fps),
    ] + encoder_params + ['-an', str(output_path)]

    direction = 'отдаление' if clip_id % 2 == 1 else 'приближение'
    logger.debug(
        f"KB clip {clip_id}: {image_path.name} → {output_path.name} "
        f"({duration:.2f}s, {direction})"
    )

    try:
        subprocess.run(cmd, check=True, capture_output=True, **SUBPROCESS_FLAGS)
    except subprocess.CalledProcessError as e:
        stderr = e.stderr.decode('utf-8', errors='replace')
        if 'moov atom not found' in stderr:
            reason = 'файл повреждён (moov atom not found) — скорее всего прерванная загрузка'
        elif 'Invalid data found' in stderr or 'Invalid data' in stderr:
            reason = 'файл повреждён (невалидные данные)'
        elif 'No such file' in stderr:
            reason = 'файл не найден'
        elif 'Permission denied' in stderr:
            reason = 'нет доступа к файлу'
        else:
            reason = f'FFmpeg вернул код {e.returncode}'
        logger.error(f"Ошибка клипа {clip_id}: {reason}")
        raise RuntimeError(
            f"Клип {clip_id} не обработан: {reason}. "
            f"Замените файл и запустите снова."
        ) from None


# ============================================================================
# ВИДЕОКЛИП: ПЕРЕКОДИРОВКА К ЦЕЛЕВОМУ RESOLUTION+FPS
# ============================================================================

def build_video_clip(source_path, output_path, duration, out_w, out_h,
                     fps, encoder_type, codec, bitrate):
    """
    Перекодирует видеоклип к целевому разрешению и FPS,
    обрезая до указанной длительности.
    """
    vf = (
        f'scale={out_w}:{out_h}:force_original_aspect_ratio=decrease,'
        f'pad={out_w}:{out_h}:(ow-iw)/2:(oh-ih)/2,'
        f'setsar=1,'
        f'format=yuv420p'
    )

    encoder_params = get_encoder_params(encoder_type, codec, bitrate)

    n_frames = max(1, round(duration * fps))

    cmd = [
        'ffmpeg', '-y', '-nostdin',
        '-i', str(source_path),
        '-vf', vf,
        '-frames:v', str(n_frames),
        '-r', str(fps),
    ] + encoder_params + ['-an', str(output_path)]

    logger.debug(
        f"Video clip {source_path.name} → {output_path.name} "
        f"({duration:.2f}s, {out_w}x{out_h}@{fps})"
    )

    try:
        subprocess.run(cmd, check=True, capture_output=True, **SUBPROCESS_FLAGS)
    except subprocess.CalledProcessError as e:
        stderr = e.stderr.decode('utf-8', errors='replace')
        # Определяем понятную причину по тексту ошибки FFmpeg
        if 'moov atom not found' in stderr:
            reason = 'файл повреждён (moov atom not found) — скорее всего прерванная загрузка'
        elif 'Invalid data found' in stderr or 'Invalid data' in stderr:
            reason = 'файл повреждён (невалидные данные)'
        elif 'No such file' in stderr:
            reason = 'файл не найден'
        elif 'Permission denied' in stderr:
            reason = 'нет доступа к файлу'
        else:
            reason = f'FFmpeg вернул код {e.returncode}'
        logger.error(f"Ошибка клипа {source_path.name}: {reason}")
        raise RuntimeError(
            f"Клип {source_path.name} не обработан: {reason}. "
            f"Замените файл и запустите снова."
        ) from None


# ============================================================================
# MAIN
# ============================================================================

def main():
    global logger

    parser = argparse.ArgumentParser(
        description='Variable Concat: смешанный монтаж фото + видео'
    )
    parser.add_argument('plan',
                        help='Путь к montage_plan.json')
    parser.add_argument('-o', '--output',
                        default='result.mp4',
                        help='Выходной файл (по умолчанию: result.mp4)')
    parser.add_argument('-a', '--audio',
                        default=None,
                        help='Аудио-озвучка (wav/mp3/m4a...). '
                             'По умолчанию ищется любой .wav/.mp3 в папке.')
    parser.add_argument('-b', '--bitrate',
                        default='10M',
                        help='Битрейт видео (по умолчанию: 10M)')
    parser.add_argument('--fps',
                        type=int, default=None,
                        choices=[25, 30, 60],
                        help='FPS выходного видео (25/30/60, по умолчанию: интерактивный выбор)')
    parser.add_argument('--resolution',
                        default='1920x1080',
                        help='Разрешение WxH (по умолчанию: 1920x1080)')
    parser.add_argument('--no-gpu',
                        action='store_true',
                        help='Использовать CPU вместо GPU')
    parser.add_argument('--force-amd',
                        action='store_true',
                        help='Принудительно AMD GPU')
    parser.add_argument('--force-reprocess',
                        action='store_true',
                        help='Переобработать все клипы заново')
    args = parser.parse_args()

    logger, log_file = setup_logging()

    # Разрешение
    try:
        out_w, out_h = map(int, args.resolution.lower().split('x'))
    except Exception:
        print(f"❌ Неверный формат разрешения: {args.resolution}  (пример: 1920x1080)")
        sys.exit(1)

    # Интерактивный выбор FPS
    if args.fps is None:
        print("\n🎞️  Выберите FPS:")
        print("   1) 25 fps")
        print("   2) 30 fps")
        print("   3) 60 fps (рекомендуется)")
        try:
            fps_choice = input("   Выбор [1/2/3, по умолчанию 3]: ").strip()
        except EOFError:
            fps_choice = '3'
        fps_map = {'1': 25, '2': 30, '3': 60, '': 60}
        args.fps = fps_map.get(fps_choice, 60)

    print("=" * 80)
    print("🎬 VARIABLE CONCAT  —  Фото + Видео")
    print("=" * 80)
    print(f"\n📝 Лог-файл: {log_file}")

    # Энкодер
    encoder_type, codec = (
        ('cpu', 'libx264') if args.no_gpu
        else detect_gpu_encoder(args.force_amd)
    )
    if encoder_type == 'nvidia':
        print("\n✅ NVIDIA GPU - h264_nvenc")
    elif encoder_type == 'amd':
        print("\n✅ AMD GPU - h264_amf")
    else:
        print("\nℹ️  CPU - libx264")

    print(f"📊 Разрешение: {out_w}×{out_h}  FPS: {args.fps}  Битрейт: {args.bitrate}")

    # -----------------------------------------------------------------------
    # Загрузка плана
    # -----------------------------------------------------------------------
    try:
        with open(args.plan, 'r', encoding='utf-8') as f:
            plan = json.load(f)
        logger.info(f"План загружен: {args.plan}")
    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(f"❌ Ошибка загрузки плана: {e}")
        sys.exit(1)

    clips = plan.get('clips', [])
    if not clips:
        print("❌ В montage_plan.json нет поля 'clips'!")
        sys.exit(1)

    clips = sorted(clips, key=lambda c: c['startTime'])
    logger.info(f"Клипов в плане: {len(clips)}")

    # -----------------------------------------------------------------------
    # Поиск аудио
    # -----------------------------------------------------------------------
    audio_file = args.audio
    if audio_file is None:
        for ext in ['*.wav', '*.mp3', '*.flac', '*.m4a', '*.aac']:
            found = list(Path('.').glob(ext))
            if found:
                audio_file = str(found[0])
                break

    if not audio_file or not os.path.exists(str(audio_file)):
        print("❌ Аудио файл не найден!")
        print("   Положите .wav/.mp3 в папку проекта или укажите: -a файл.wav")
        sys.exit(1)

    audio_duration = get_audio_duration(audio_file)
    print(f"\n🎵 Аудио: {audio_file} ({audio_duration:.2f} сек)")
    print(f"📋 Клипов в плане: {len(clips)}")

    try:
        # ===================================================================
        # ЭТАП 1: ПОИСК ФАЙЛОВ
        # ===================================================================
        print("\n" + "=" * 80)
        print("🔍 ЭТАП 1: ПОИСК ФАЙЛОВ")
        print("=" * 80)

        file_map = {}   # clip_id → (Path, 'video'|'image')
        missing_ids = []
        video_count = 0
        image_count = 0

        for clip in clips:
            cid = clip['id']
            path, ftype = find_file(cid)
            if path:
                file_map[cid] = (path, ftype)
                if ftype == 'video':
                    video_count += 1
                else:
                    image_count += 1
            else:
                missing_ids.append(cid)

        print(f"\n✅ Найдено: {len(file_map)} / {len(clips)}")
        print(f"   🎬 Видео: {video_count}")
        print(f"   🖼️  Фото:  {image_count}")

        if missing_ids:
            shown = ', '.join(str(i) for i in missing_ids[:20])
            tail = f' ...ещё {len(missing_ids) - 20}' if len(missing_ids) > 20 else ''
            print(f"\n❌ Файлы отсутствуют для клипов: {shown}{tail}")
            print(f"   Ищу в vid_img/ форматы: .mp4 .mov .png .jpg .jpeg .webp")
            print(f"   Сгенерируйте или скачайте недостающие клипы и запустите снова.")
            sys.exit(1)

        valid_clips = [c for c in clips if c['id'] in file_map]
        logger.info(f"Валидных клипов: {len(valid_clips)} (видео: {video_count}, фото: {image_count})")

        # ===================================================================
        # ЭТАП 2: ОБРАБОТКА КЛИПОВ
        # ===================================================================
        print("\n" + "=" * 80)
        print("🎬 ЭТАП 2: ОБРАБОТКА КЛИПОВ")
        print("=" * 80)

        temp_dir = Path('temp_var')
        temp_dir.mkdir(exist_ok=True)

        # Определяем какие клипы уже готовы
        ready = {}      # cid → Path
        to_process = []

        for clip in valid_clips:
            cid = clip['id']
            duration = clip['endTime'] - clip['startTime']
            out_path = temp_dir / f'kv_{cid:04d}.mp4'

            if not args.force_reprocess and out_path.exists():
                if out_path.stat().st_size > 10_000:
                    actual = get_video_duration(out_path)
                    if abs(actual - duration) < 0.08:
                        logger.debug(f"Clip {cid}: уже готов")
                        ready[cid] = out_path
                        continue

            to_process.append(clip)

        print(f"\n   ✅ Готовых: {len(ready)}")
        print(f"   🔄 Требуют обработки: {len(to_process)}")

        if to_process:
            print()
            with tqdm(total=len(to_process), desc="Обработка клипов", unit="клип") as pbar:
                for clip in to_process:
                    cid = clip['id']
                    duration = clip['endTime'] - clip['startTime']
                    out_path = temp_dir / f'kv_{cid:04d}.mp4'
                    source, ftype = file_map[cid]

                    if ftype == 'image':
                        build_ken_burns_clip(
                            image_path=source,
                            output_path=out_path,
                            duration=duration,
                            clip_id=cid,
                            out_w=out_w, out_h=out_h,
                            fps=args.fps,
                            encoder_type=encoder_type,
                            codec=codec,
                            bitrate=args.bitrate,
                        )
                    else:
                        build_video_clip(
                            source_path=source,
                            output_path=out_path,
                            duration=duration,
                            out_w=out_w, out_h=out_h,
                            fps=args.fps,
                            encoder_type=encoder_type,
                            codec=codec,
                            bitrate=args.bitrate,
                        )

                    ready[cid] = out_path
                    pbar.update(1)

        # Упорядоченный список клипов
        ordered_files = []
        for clip in valid_clips:
            ordered_files.append(str(ready[clip['id']]))

        print(f"\n✅ Клипов готово: {len(ordered_files)}")

        # Проверка суммы длительностей vs аудио
        total_clips_dur = sum(c['endTime'] - c['startTime'] for c in valid_clips)
        diff = total_clips_dur - audio_duration
        sync_ok = abs(diff) < 1.0
        diff_str = f"+{diff:.2f}с" if diff >= 0 else f"{diff:.2f}с"
        sync_mark = "✅" if sync_ok else "⚠️ "
        print(f"{sync_mark} Длительность клипов: {total_clips_dur:.2f}с  |  Аудио: {audio_duration:.2f}с  |  Разница: {diff_str}")
        if not sync_ok:
            print(f"   ⚠️  Разница > 1с — возможен десинхрон! Проверьте montage_plan.json.")
        logger.info(f"Сумма клипов: {total_clips_dur:.2f}с, аудио: {audio_duration:.2f}с, разница: {diff:.2f}с")

        # ===================================================================
        # ЭТАП 3: CONCAT (прямой cut)
        # ===================================================================
        print("\n" + "=" * 80)
        print("🔗 ЭТАП 3: СБОРКА ВИДЕО")
        print("=" * 80)
        print()

        concat_list = temp_dir / 'concat_list.txt'
        with open(concat_list, 'w', encoding='utf-8') as f:
            for fpath in ordered_files:
                f.write(f"file '{Path(fpath).absolute()}'\n")

        concat_video = temp_dir / 'concat_raw.mp4'
        total_video_dur = sum(
            c['endTime'] - c['startTime'] for c in valid_clips
        )

        cmd_concat = [
            'ffmpeg', '-y', '-f', 'concat', '-safe', '0',
            '-i', str(concat_list),
            '-c', 'copy',
            str(concat_video)
        ]
        run_ffmpeg_with_progress(cmd_concat, total_video_dur, "Сборка клипов")
        logger.info("Concat завершён")

        # ЭТАП 3.5: СИНХРОНИЗАЦИЯ
        concat_video = fix_video_audio_sync(
            str(concat_video), audio_file, temp_dir, encoder_type, codec, args.bitrate
        )

        # ===================================================================
        # ЭТАП 4: ЗАМЕНА АУДИО
        # ===================================================================
        print("\n" + "=" * 80)
        print("🎵 ЭТАП 4: ЗАМЕНА АУДИО")
        print("=" * 80)

        pre_encoded_audio = temp_dir / 'narration_aac.m4a'

        print("   Шаг 1/2: WAV → AAC...")
        cmd_aac = [
            'ffmpeg', '-y', '-i', str(audio_file),
            '-c:a', 'aac', '-b:a', '192k', str(pre_encoded_audio)
        ]
        run_ffmpeg_with_progress(cmd_aac, audio_duration, "AAC кодирование")
        logger.info("Аудио закодировано")

        print("   Шаг 2/2: Сборка видео + аудио...")
        cmd_mux = [
            'ffmpeg', '-y',
            '-i', str(concat_video),
            '-i', str(pre_encoded_audio),
            '-map', '0:v', '-map', '1:a',
            '-c:v', 'copy', '-c:a', 'copy',
            '-shortest',
            args.output
        ]
        run_ffmpeg_with_progress(cmd_mux, audio_duration, "Сборка")
        logger.info(f"Готово: {args.output}")

        try:
            pre_encoded_audio.unlink()
        except Exception:
            pass

        # ===================================================================
        # ЭТАП 5: ОЧИСТКА
        # ===================================================================
        ask_delete_temp_folder(temp_dir)

        # ФИНАЛ
        final_size = get_file_size_mb(args.output)
        print("\n" + "=" * 80)
        print("✅ ГОТОВО!")
        print("=" * 80)
        print(f"\n📹 Видео: {args.output}")
        print(f"   • Разрешение: {out_w}×{out_h}")
        print(f"   • FPS: {args.fps}")
        print(f"   • Битрейт: {args.bitrate}")
        print(f"   • Кодек: {codec} ({encoder_type.upper()})")
        print(f"   • Размер: {final_size:.0f} MB")
        print(f"   • Видеоклипов: {video_count}  Фотоклипов: {image_count}")
        print(f"\n🎵 Озвучка: {audio_file}")
        print(f"📝 Лог-файл: {log_file}")
        print("=" * 80)

        logger.info("=" * 80)
        logger.info("СКРИПТ ЗАВЕРШЁН УСПЕШНО")
        logger.info("=" * 80)

    except RuntimeError as e:
        # Чистые ошибки от нас (битый файл, etc.) — без traceback
        logger.error(str(e))
        print(f"\n❌ ОШИБКА: {e}")
        print(f"📝 Подробности в лог-файле: {log_file}")
        sys.exit(1)
    except Exception as e:
        logger.critical("КРИТИЧЕСКАЯ ОШИБКА!")
        logger.critical(traceback.format_exc())
        print(f"\n❌ КРИТИЧЕСКАЯ ОШИБКА: {e}")
        print(f"📝 Подробности в лог-файле: {log_file}")
        sys.exit(1)


if __name__ == '__main__':
    main()
