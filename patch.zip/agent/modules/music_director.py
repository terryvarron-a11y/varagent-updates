"""
Music Director — Pass 3.

Тот же подход что у gpt_director.py: запускает Codex CLI с
schemas/music_plan_control.json + prompts/music_director_pass.txt,
получает music_plan.json — список инструментальных треков для Suno
расставленных по смыслу транскрипции и montage_plan.
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Optional, Dict, Any

import config
from modules.music_plan_utils import normalize_music_plan


class MusicDirector:
    """Codex-based music supervisor — генерирует music_plan.json"""

    def __init__(self, model_name: Optional[str] = None):
        self.model_name = model_name or config.GPT_MODEL
        self.codex_exe = Path(config.CODEX_EXE_PATH)
        self.schemas_dir = Path(__file__).parent.parent / 'schemas'
        self.prompts_dir = Path(__file__).parent.parent / 'prompts'
        self.timeout = config.GPT_DIRECTOR_TIMEOUT

        if not config.CODEX_EXE_PATH or not self.codex_exe.is_file():
            raise FileNotFoundError(f"Codex CLI не найден: {self.codex_exe}")

    def plan(
        self,
        transcription_path: str,
        montage_plan_path: str,
        style_guide_path: str,
        output_dir: str,
        project_name: str = "Untitled",
    ) -> Dict[str, Any]:
        """
        Создаёт music_plan.json в output_dir.

        Returns dict с:
          music_plan_path: str
          tracks_count:    int
          audio_duration:  float
        """
        output_dir = Path(output_dir)
        transcription_path = Path(transcription_path)
        montage_plan_path = Path(montage_plan_path)
        style_guide_path = Path(style_guide_path)

        if not transcription_path.exists():
            raise FileNotFoundError(f"Транскрипция не найдена: {transcription_path}")
        if not montage_plan_path.exists():
            raise FileNotFoundError(f"Монтажный план не найден: {montage_plan_path}")

        # Audio duration из транскрипции
        transcription = json.loads(transcription_path.read_text(encoding='utf-8-sig'))
        audio_duration = float(transcription.get('audioDuration', 0))

        mp_path = output_dir / 'music_plan.json'
        result_file = output_dir / '_codex_music_pass_control.json'

        sys_instr_path = self.prompts_dir / 'music_director_pass.txt'

        task_prompt = self._build_prompt(
            sys_instr_path=sys_instr_path,
            transcription_path=transcription_path,
            montage_plan_path=montage_plan_path,
            style_guide_path=style_guide_path,
            output_path=mp_path,
            project_name=project_name,
            audio_duration=audio_duration,
        )

        print(f"\n🎵 Music Director: создание музыкального плана...")
        print(f"   Модель: {self.model_name}")
        print(f"   Аудио:  {audio_duration:.0f}с ({audio_duration/60:.1f} мин)")

        control = self._run_codex(
            task_prompt, 'music_plan_control.json',
            result_file, output_dir,
        )

        if control.get('status') != 'ok':
            raise RuntimeError(
                f"Music Director вернул error: {control.get('error_message', 'unknown')}"
            )

        actual_path = Path(control.get('music_plan_path', str(mp_path)))
        if not actual_path.exists():
            actual_path = mp_path
        if not actual_path.exists():
            raise RuntimeError(f"music_plan.json не создан: {actual_path}")

        # Валидация и нормализация плана
        plan = json.loads(actual_path.read_text(encoding='utf-8-sig'))
        if 'music_plan' in plan and 'tracks' in plan['music_plan']:
            plan = plan['music_plan']
        tracks = plan.get('tracks', [])

        # Hard-fix: instrumental=True всегда
        for t in tracks:
            t['instrumental'] = True

        before_count = len(tracks)
        plan = normalize_music_plan(
            plan,
            audio_duration,
            min_track_duration=getattr(config, 'MUSIC_MIN_TRACK_DURATION', 120),
            max_track_duration=getattr(config, 'MUSIC_MAX_TRACK_DURATION', 240),
            max_tracks=getattr(config, 'MUSIC_MAX_TRACKS', 10),
        )
        target_volume_db = float(getattr(config, 'MUSIC_DEFAULT_VOLUME_DB', -21))
        target_ducking_db = float(getattr(config, 'MUSIC_DUCKING_DB', -5))
        plan['global_volume_db'] = target_volume_db
        plan['global_ducking_db'] = target_ducking_db
        for t in plan.get('tracks', []) or []:
            if isinstance(t, dict):
                t['volume_db'] = target_volume_db
        tracks = plan.get('tracks', [])
        if len(tracks) != before_count:
            print(
                f"   Music plan simplified: {before_count} -> {len(tracks)} tracks "
                f"(min {getattr(config, 'MUSIC_MIN_TRACK_DURATION', 120)}s, "
                f"max {getattr(config, 'MUSIC_MAX_TRACKS', 10)} total)"
            )

        # Перезапись нормализованного плана
        mp_path.write_text(
            json.dumps({'music_plan': plan} if 'tracks' in plan else plan,
                       indent=2, ensure_ascii=False),
            encoding='utf-8',
        )

        # Проверка покрытия аудио
        if tracks:
            first_start = float(tracks[0].get('startTime', 0))
            last_end = float(tracks[-1].get('endTime', 0))
            if first_start > 0.5:
                logging.warning(f"music_plan: первый трек начинается с {first_start:.1f}с, не с 0")
            if abs(last_end - audio_duration) > 1.0:
                logging.warning(
                    f"music_plan: последний трек заканчивается на {last_end:.1f}с, "
                    f"аудио {audio_duration:.1f}с"
                )

        print(f"   ✅ {len(tracks)} треков, покрытие {audio_duration:.0f}с")
        return {
            'music_plan_path': str(mp_path),
            'tracks_count': len(tracks),
            'audio_duration': audio_duration,
        }

    # =========================================================================
    # Codex subprocess wrapper (упрощённая версия из gpt_director.py)
    # =========================================================================

    def _run_codex(
        self,
        task_prompt: str,
        schema_file: str,
        result_file: Path,
        working_dir: Path,
    ) -> dict:
        schema_path = self.schemas_dir / schema_file
        if not schema_path.exists():
            raise FileNotFoundError(f"Schema не найдена: {schema_path}")

        if result_file.exists():
            result_file.unlink()

        task_file = working_dir / f'_codex_music_task.md'
        task_file.write_text(task_prompt, encoding='utf-8')
        short_prompt = f"Read and follow ALL instructions from this file: {task_file.as_posix()}"

        cmd = [
            str(self.codex_exe), 'exec',
            short_prompt,
            '--output-schema', str(schema_path),
            '--output-last-message', str(result_file),
            '--dangerously-bypass-approvals-and-sandbox',
            '--skip-git-repo-check',
            '-m', self.model_name,
            '-C', str(working_dir),
        ]

        logging.info(f"Codex Music: model={self.model_name} cwd={working_dir}")
        t0 = time.time()
        _stdout: list = []
        _stderr: list = []
        _rc: list = [None]
        _done = threading.Event()

        def _exec():
            try:
                # stdin=DEVNULL обязателен для Codex CLI v0.128.0+ — иначе
                # "Reading additional input from stdin..." → exit 1.
                p = subprocess.Popen(
                    cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    stdin=subprocess.DEVNULL,
                    text=True, encoding='utf-8', errors='replace',
                )
                _draino_t = threading.Thread(
                    target=lambda: [_stderr.append(l.rstrip()) for l in p.stderr],
                    daemon=True,
                )
                _draino_t.start()
                for line in p.stdout:
                    _stdout.append(line.rstrip())
                p.wait(timeout=self.timeout)
                _draino_t.join(timeout=5)
                _rc[0] = p.returncode
            except subprocess.TimeoutExpired:
                p.kill()
                _rc[0] = -1
            except Exception as e:
                _stderr.append(str(e))
                _rc[0] = -1
            finally:
                _done.set()

        threading.Thread(target=_exec, daemon=True).start()

        _spinner_chars = '⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
        _i = 0
        while not _done.is_set():
            elapsed = time.time() - t0
            mins, secs = int(elapsed) // 60, int(elapsed) % 60
            t_str = f"{mins}м {secs:02d}с" if mins > 0 else f"{secs}с"
            spin = _spinner_chars[_i % len(_spinner_chars)]
            _i += 1
            sys.stdout.write(f'\r{spin} Music Director: {t_str}   \n')
            sys.stdout.flush()
            _done.wait(1)
            if elapsed > self.timeout:
                raise RuntimeError(f"Codex timeout {self.timeout}s")

        elapsed = time.time() - t0
        if _rc[0] != 0:
            logging.error(f"Codex stderr: {chr(10).join(_stderr[-30:])}")

        if not result_file.exists():
            raise RuntimeError(
                f"Codex не создал {result_file.name} (exit {_rc[0]})\n"
                f"stderr: {chr(10).join(_stderr[-10:])}"
            )

        raw = result_file.read_text(encoding='utf-8-sig').strip()
        try:
            control = json.loads(raw)
        except json.JSONDecodeError as e:
            raise RuntimeError(f"Codex вернул невалидный JSON: {e}\n{raw[:500]}")

        print(f"   ⏱  Music Director: {elapsed:.0f}с, model={self.model_name}")
        return control

    # =========================================================================
    # Prompt builder
    # =========================================================================

    def _build_prompt(
        self,
        sys_instr_path: Path,
        transcription_path: Path,
        montage_plan_path: Path,
        style_guide_path: Path,
        output_path: Path,
        project_name: str,
        audio_duration: float,
    ) -> str:
        si = sys_instr_path.as_posix()
        tr = transcription_path.as_posix()
        mp = montage_plan_path.as_posix()
        sg = style_guide_path.as_posix()
        out = output_path.as_posix()
        target_volume_db = float(getattr(config, 'MUSIC_DEFAULT_VOLUME_DB', -21))

        return f"""You are a music director / sound supervisor for a storytelling video.

## SYSTEM INSTRUCTION
Read the music director instruction file: {si}
Follow ALL its rules — especially:
- The score must SOUND CLEARLY ON-MEANING: derive each track's genre, instruments,
  tempo and harmony from the actual content, emotion and SPEECH INTONATION of the
  transcript segment it covers (mood -> harmony/timbre, speech pace/intensity ->
  musical tempo/density). Do NOT use generic templates detached from the words.
- Place every music change exactly on a TONAL SHIFT in the narration (anxiety->relief,
  past->present, setup->climax), not on a timer. Track boundaries must land on story turns.
- For EVERY track write a `text_anchor` (in Russian): which words/emotion/intonation
  of that segment drove its sound. This field is mandatory; it justifies the binding
  and is shown to the user.
- ALL tracks must be `instrumental: true` (no vocals, no lyrics, no singing)
- Background music for narration (must not overpower the voice)
- Keep the bed even and restrained: no sharp spikes, bright solos, or drums
  that break through the voice. Use {target_volume_db:g} dB as the loudness target.
  This task value overrides any generic volume example in the instruction file.
- prefer long 120-240 second tracks, max 10 tracks total
- Track 1 is the intro bed: it must start dynamically and immediately,
  matching the transcript meaning but avoiding a calm/slow opening
- The intro bed must be audible in the first second: first beat/impact at 0:00,
  no generated silence before the music, no slow fade-in
- The first 8-12 seconds should feel like a breathtaking hook, then the same
  bed may settle to a calmer narration underscore
- prompt and tags in English; mood/title can be in Russian

## INPUTS
1. Transcription (voiceover with timestamps): {tr}
2. Montage plan (visual clips structure): {mp}
3. Style guide (project tone): {sg}

## PROJECT
Name: {project_name}
Audio duration: {audio_duration:.2f} seconds

## TASK
1. Read all three input files above — read the transcript BY ITS WORDS.
2. Analyze the narrative arc — where does mood/energy/intonation shift?
3. Plan music tracks whose boundaries land on those tonal shifts (NOT mechanical equal slicing).
4. For each track, derive the sound from the meaning + intonation of that segment, then
   write Suno-ready `prompt` and `tags`, plus a Russian `text_anchor` explaining the binding.
5. Write the result as JSON to: {out}

## OUTPUT JSON STRUCTURE
{{
  "music_plan": {{
    "audioDuration": {audio_duration:.2f},
    "global_volume_db": {target_volume_db:g},
    "tracks": [
      {{
        "id": 1,
        "startTime": 0.0,
        "endTime": 95.4,
        "mood": "напряжённое начало",
        "text_anchor": "Завязка про надвигающуюся угрозу, низкая веская интонация диктора -> тёмный пульсирующий бэд, медленный веский темп под речь",
        "genre": "cinematic dark ambient",
        "energy": "high",
        "energy_arc": "high->mid",
        "prompt": "dynamic cinematic intro, starts immediately with pulsing percussion, impact hit on the first beat, audible in the first second, urgent rhythmic momentum, tense orchestral stabs, driving low strings, breathtaking hook for the first 8-12 seconds then settles under narration, documentary tension, no silence before the music, no slow fade-in, no quiet opening",
        "tags": "dynamic intro, cinematic, tense, urgent, pulsing percussion, instrumental",
        "title": "Opening - Tension",
        "volume_db": {target_volume_db:g},
        "hook_seconds": 12,
        "fade_in_ms": 0,
        "fade_out_ms": 2500,
        "instrumental": true
      }}
    ]
  }}
}}

## RULES
- All `instrumental: true` (no vocals, no lyrics, no singing) — hard rule for every track
- Every track must include a non-empty Russian `text_anchor` justifying its sound
- Sound is derived from meaning + intonation of the covered text, not generic templates
- First track startTime = 0.0
- First non-silence track must be a dynamic intro: `energy` high or mid-high,
  `energy_arc` high->mid or high, `fade_in_ms` = 0, and prompt must include
  immediate rhythmic/percussive momentum. The track must be audible in the first
  second with a first-beat impact at 0:00; do not begin the intro with silence,
  calm pads, sparse piano, slow drones, or a long fade-in. After the first
  8-12 seconds, it may settle under narration.
- Last track endTime ≈ {audio_duration:.2f}
- Adjacent tracks: track[N].endTime == track[N+1].startTime (continuous)
- IDs sequential 1, 2, 3, ...
- 120 ≤ (endTime - startTime) ≤ 240 seconds when the video length allows it
- Total tracks: 2-10

After writing the JSON, return your status. Set `music_plan_path` to: {out}
"""


def music_direct_project(
    transcription_path: str,
    montage_plan_path: str,
    style_guide_path: str,
    output_dir: str,
    project_name: str = "Untitled",
    model_name: Optional[str] = None,
) -> Dict[str, Any]:
    """Wrapper: создаёт MusicDirector backend и запускает plan()."""
    backend = (getattr(config, 'MUSIC_DIRECTOR_BACKEND', '') or getattr(config, 'DIRECTOR_BACKEND', 'gpt')).lower()
    _gpt_provider = getattr(config, 'GPT_PROVIDER', '').lower()
    if backend in ('deepseek', 'openrouter') or (
        backend in ('gpt', 'openai') and _gpt_provider in ('deepseek', 'openrouter')
    ):
        # Прямой chat API (DeepSeek/OpenRouter) — без Codex/Moon Bridge
        from modules.chat_music_director import ChatMusicDirector
        director = ChatMusicDirector(model_name=model_name)
    elif backend in ('claude', 'claude_code'):
        from modules.claude_code_music_director import ClaudeCodeMusicDirector
        director = ClaudeCodeMusicDirector(model_name=model_name)
    elif backend in ('claude_api', 'anthropic'):
        from modules.claude_api_music_director import ClaudeApiMusicDirector
        director = ClaudeApiMusicDirector(model_name=model_name)
    else:
        director = MusicDirector(model_name=model_name)
    return director.plan(
        transcription_path, montage_plan_path, style_guide_path,
        output_dir, project_name,
    )
