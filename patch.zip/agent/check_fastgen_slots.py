"""Quick check: FastGen quota for key1 and key2 (if set)."""
import os
import sys
from pathlib import Path
from dotenv import load_dotenv

env_path = Path(__file__).resolve().parent / '.env'
load_dotenv(env_path)

# Import after env load
sys.path.insert(0, str(Path(__file__).resolve().parent))
import config
from modules.fastgen import FastGenClient, parse_usage_remaining, parse_usage_threads


def query_key(api_key: str, label: str):
    try:
        c = FastGenClient(api_key=api_key)
        usage = c.get_usage()
        remaining = parse_usage_remaining(usage)
        threads = parse_usage_threads(usage)
        return remaining, threads
    except Exception as e:
        return None, None


key1 = config.FASTGEN_API_KEY
key2 = config.FASTGEN_API_KEY_2

if not key1:
    print('  [!] FASTGEN_API_KEY not set')
    print('key1=0')
    print('key2=0')
    sys.exit(0)

r1, t1 = query_key(key1, 'Key1')
t1 = t1 or 0
print(f'  Key1: {r1 if r1 is not None else "?"} gen/h remaining | {t1} threads')

if key2:
    r2, t2 = query_key(key2, 'Key2')
    t2 = t2 or 0
    print(f'  Key2: {r2 if r2 is not None else "?"} gen/h remaining | {t2} threads')
    print(f'  ------------------------------------')
    print(f'  Total threads: {t1 + t2}')
    print(f'key1={t1}')
    print(f'key2={t2}')
    print(f'total={t1 + t2}')
else:
    print(f'  (Key2 not configured)')
    print(f'key1={t1}')
    print(f'key2=0')
    print(f'total={t1}')
