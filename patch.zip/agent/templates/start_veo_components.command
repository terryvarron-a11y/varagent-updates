#!/bin/bash
# START_VEO_COMPONENTS.COMMAND - VeoNonStop Multi-Image-to-Video (components)
# Run: double-click this file in Finder

PROJECT_NAME="{project_name}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
AGENT_DIR="$(cd "$SCRIPT_DIR/../../agent" && pwd)"

chmod +x *.command *.sh 2>/dev/null

if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e "tell app \"Terminal\" to do script \"cd '$SCRIPT_DIR' && exec '$0'\""
    exit 0
fi

echo ""
echo "========================================================================"
echo "  VeoNonStop COMPONENTS (multi-image-to-video)"
echo "  Project: $PROJECT_NAME"
echo "========================================================================"
echo ""

# Check ref/
if [ ! -d "$SCRIPT_DIR/ref" ]; then
    echo "  [WARN] ref/ folder not found!"
    echo "    Put character/location images in: $SCRIPT_DIR/ref/"
    echo ""
    read -p "  Custom ref path (or Enter to cancel): " REF_INPUT
    if [ -z "$REF_INPUT" ]; then
        echo "  Cancelled."
        exit 0
    fi
    REF_ARG="--ref-dir \"$REF_INPUT\""
else
    echo "  ref/ folder found - using as reference"
    echo ""
    REF_ARG=""
fi

# Aspect ratio
echo "  Select aspect ratio:"
echo "    [1] 16:9   landscape, default"
echo "    [2] 9:16   portrait"
echo "    [3] 1:1    square"
echo ""
read -p "  Aspect [1/2/3] (Enter = 1): " RATIO_CHOICE
RATIO="16:9"
case "$RATIO_CHOICE" in
    2) RATIO="9:16" ;;
    3) RATIO="1:1" ;;
esac
echo "    Selected: $RATIO"
echo ""

# Parallel
read -p "  Parallel [1-24] (Enter = 12): " PARALLEL
PARALLEL="${PARALLEL:-12}"
echo "    Selected: $PARALLEL"
echo ""

# Clip IDs
read -p "  Clip IDs (e.g. 1,2,3 or Enter for all): " IDS_INPUT
IDS_ARG=""
if [ -n "$IDS_INPUT" ]; then
    IDS_ARG="--ids $IDS_INPUT"
    echo "    Clips: $IDS_INPUT"
else
    echo "    Clips: ALL"
fi
echo ""

# Single prompt
read -p "  Single prompt for all clips (Enter = per-clip): " PROMPT_INPUT
PROMPT_ARG=""
if [ -n "$PROMPT_INPUT" ]; then
    PROMPT_ARG="--prompt \"$PROMPT_INPUT\""
    echo "    Prompt: single"
else
    echo "    Prompt: per-clip"
fi
echo ""

# Confirm
echo "========================================================================"
echo "  SUMMARY:"
echo "    Project:  $PROJECT_NAME"
echo "    Mode:     components (multi-image-to-video)"
echo "    Ratio:    $RATIO"
echo "    Parallel: $PARALLEL"
echo "========================================================================"
echo ""
read -p "  Start? (y/n): " CONFIRM
if [ "$CONFIRM" != "y" ] && [ "$CONFIRM" != "Y" ]; then
    echo "  Cancelled."
    exit 0
fi

echo ""
echo "  Starting components generation..."
echo ""

cd "$AGENT_DIR"

eval python agent.py img2video \
    --project "$PROJECT_NAME" \
    --mode "components" \
    --ratio "$RATIO" \
    --parallel "$PARALLEL" $IDS_ARG $PROMPT_ARG $REF_ARG

EXIT_CODE=$?
echo ""
if [ $EXIT_CODE -ne 0 ]; then
    echo "[ERROR] Components generation failed. See log above."
else
    echo "========================================================================"
    echo "  DONE. Output: $SCRIPT_DIR/vid_img/"
    echo "========================================================================"
fi
echo ""
read -p "Press Enter to close..."
