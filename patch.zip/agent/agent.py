#!/usr/bin/env python3
"""
Video Production Agent - Главный скрипт
Автоматизация создания видео через AI
"""
import argparse
import subprocess
import sys
import os
from pathlib import Path
from datetime import datetime
import json
import logging
import traceback
from datetime import datetime as dt
from typing import Optional
from tqdm import tqdm


class _TeeStream:
    """Дублирует stdout в файл."""
    def __init__(self, original, file_handle):
        self._orig = original
        self._file = file_handle
    def write(self, data):
        self._orig.write(data)
        try:
            self._file.write(data)
            self._file.flush()
        except Exception:
            pass
    def flush(self):
        self._orig.flush()
        try:
            self._file.flush()
        except Exception:
            pass
    def __getattr__(self, name):
        return getattr(self._orig, name)

# Установка UTF-8 кодировки для Windows (консоль + вывод)
if sys.platform == 'win32':
    os.system('chcp 65001 >nul')
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')

# Добавляем путь к модулям
sys.path.insert(0, str(Path(__file__).parent))

import config
from modules.transcriber import AssemblyAITranscriber, transcribe_audio
from modules.director import GeminiDirector, direct_project
from modules.script_director import GeminiScriptDirector, script_direct_project
from modules.validator import (
    validate_transcription_json,
    validate_montage_plan_json,
    validate_json_file,
    validate_file_exists
)
from modules.queue import (
    get_ready_files,
    get_sg_all_file,
    get_all_style_guides_for_audio,
    setup_project,
    create_process_batch_files,
    create_fragment_checker
)
from modules.fastgen import generate_all_images
from modules.yt_packer import run_yt_packer
from modules.veo_video import generate_all_videos as veo_generate_all_videos
from modules.imggen import generate_all_images as veo_generate_all_images
from modules.ref_compress import compress_refs


# ============================================================================
# YT PACKER: ИНТЕРАКТИВНЫЙ ЗАПУСК ПОСЛЕ ПРОМПТОВ
# ============================================================================

def _ask_yt_packer(project_dir: str, source_lang: str = None) -> bool:
    """
    Спрашивает юзера запустить ли YT Packer после создания промптов.
    source_lang — язык транскрипции (из AssemblyAI), автоматически ставится первым в YT_PACK_LANGUAGES.
    Возвращает True если запущен и успешен.
    """
    # Подставляем язык транскрипции как исходный язык YT Packer
    if source_lang:
        other_langs = [l for l in config.YT_PACK_LANGUAGES if l != source_lang]
        config.YT_PACK_LANGUAGES = [source_lang] + other_langs

    print()
    print("=" * 60)
    print("  YT PACKER — YouTube packaging")
    print("=" * 60)
    print()
    choice = input("  Run YT Packer? (y/n, Enter=n): ").strip().lower()
    if choice != 'y':
        print("  [SKIP] YT Packer skipped.")
        return False

    print()
    print("  Mode:")
    print("    [1] Silent      (use .env defaults, show & confirm)")
    print("    [2] Interactive (ask each parameter)")
    print()
    mode = input("  Choose [1/2] (Enter=1): ").strip()

    if mode == '2':
        _yt_packer_interactive()
    else:
        _yt_packer_silent()

    # Запуск
    try:
        run_yt_packer(project_dir)
        return True
    except Exception as e:
        print(f"\n  [ERROR] YT Packer failed: {e}")
        logging.debug(traceback.format_exc())
        return False


def _yt_packer_silent():
    """Показывает текущие настройки YT Packer из .env, спрашивает подтверждение."""
    print()
    print("  " + "-" * 50)
    print("  YT PACKER SETTINGS (from .env)")
    print("  " + "-" * 50)
    print(f"  Languages:    {', '.join(config.YT_PACK_LANGUAGES)}")
    print(f"  Model:        {config.YT_PACK_MODEL}")
    print(f"  Subtitles:    {'ON' if config.YT_PACK_SUBTITLES else 'OFF'}")
    print(f"  Description:  {'ON' if config.YT_PACK_DESCRIPTION else 'OFF'}")
    print(f"  Covers:       {'ON' if config.YT_PACK_COVERS else 'OFF'}")
    if config.YT_PACK_COVERS:
        print(f"  Cover model:  {config.YT_PACK_COVER_MODEL}")
        print(f"  Cover count:  {config.YT_PACK_COVER_COUNT}")
    print("  " + "-" * 50)
    print()

    confirm = input("  All correct? (y/n, Enter=y): ").strip().lower()
    if confirm == 'n':
        print("  Switching to interactive mode...")
        _yt_packer_interactive()


def _yt_packer_interactive():
    """Спрашивает каждый параметр YT Packer у пользователя."""
    print()
    print("  " + "-" * 50)
    print("  YT PACKER INTERACTIVE SETUP")
    print("  " + "-" * 50)

    # Languages
    print()
    current_langs = ','.join(config.YT_PACK_LANGUAGES)
    langs_input = input(f"  Languages (comma-separated) [{current_langs}]: ").strip()
    if langs_input:
        config.YT_PACK_LANGUAGES = [l.strip() for l in langs_input.split(',') if l.strip()]

    # Models
    models = {'1': 'gemini-2.5-flash', '2': 'gemini-2.5-pro', '3': 'gemini-2.0-flash'}
    print()
    print("  Model for subtitle TRANSLATION (cheap/fast):")
    print("    [1] gemini-2.5-flash       (fast, default)")
    print("    [2] gemini-2.5-pro         (quality)")
    print("    [3] gemini-2.0-flash       (ultra-fast)")
    print()
    m = input(f"  Translation model [1/2/3] (Enter={config.YT_PACK_TRANSLATE_MODEL}): ").strip()
    if m in models:
        config.YT_PACK_TRANSLATE_MODEL = models[m]

    print()
    print("  Model for CONTENT (titles/description/tags/covers):")
    print("    [1] gemini-2.5-flash       (fast, default)")
    print("    [2] gemini-2.5-pro         (quality)")
    print("    [3] gemini-2.0-flash       (ultra-fast)")
    print()
    m = input(f"  Content model [1/2/3] (Enter={config.YT_PACK_CONTENT_MODEL}): ").strip()
    if m in models:
        config.YT_PACK_CONTENT_MODEL = models[m]

    # Subtitles
    print()
    sub = input(f"  Generate subtitles? (y/n) [{'y' if config.YT_PACK_SUBTITLES else 'n'}]: ").strip().lower()
    if sub in ('y', 'n'):
        config.YT_PACK_SUBTITLES = (sub == 'y')

    # Description
    desc = input(f"  Generate description/titles/tags? (y/n) [{'y' if config.YT_PACK_DESCRIPTION else 'n'}]: ").strip().lower()
    if desc in ('y', 'n'):
        config.YT_PACK_DESCRIPTION = (desc == 'y')

    # Covers
    cov = input(f"  Generate covers? (y/n) [{'y' if config.YT_PACK_COVERS else 'n'}]: ").strip().lower()
    if cov in ('y', 'n'):
        config.YT_PACK_COVERS = (cov == 'y')

    if config.YT_PACK_COVERS:
        count = input(f"  Cover count [1-8] ({config.YT_PACK_COVER_COUNT}): ").strip()
        if count.isdigit() and 1 <= int(count) <= 8:
            config.YT_PACK_COVER_COUNT = int(count)

    print()
    print(f"  Settings applied: langs={','.join(config.YT_PACK_LANGUAGES)}, "
          f"translate_model={config.YT_PACK_TRANSLATE_MODEL}, "
          f"content_model={config.YT_PACK_CONTENT_MODEL}, "
          f"subs={'ON' if config.YT_PACK_SUBTITLES else 'OFF'}, "
          f"desc={'ON' if config.YT_PACK_DESCRIPTION else 'OFF'}, "
          f"covers={'ON' if config.YT_PACK_COVERS else 'OFF'}")


# ============================================================================
# НАСТРОЙКА ЛОГГИРОВАНИЯ
# ============================================================================

def setup_logging(log_dir: Path) -> Path:
    """Настройка логгирования"""
    log_dir.mkdir(exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = log_dir / f'agent_{timestamp}.log'

    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(getattr(logging, config.LOG_LEVEL))
    file_handler.setFormatter(logging.Formatter(config.LOG_FORMAT))

    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.WARNING)
    stream_handler.setFormatter(logging.Formatter(config.LOG_FORMAT))

    root = logging.getLogger()
    root.setLevel(getattr(logging, config.LOG_LEVEL))
    root.handlers.clear()
    root.addHandler(file_handler)
    root.addHandler(stream_handler)
    
    # Скрыть DEBUG логи от httpcore и других библиотек
    logging.getLogger('httpcore').setLevel(logging.WARNING)
    logging.getLogger('httpx').setLevel(logging.WARNING)
    logging.getLogger('google').setLevel(logging.WARNING)

    return log_file


# ============================================================================
# КОМАНДЫ АГЕНТА
# ============================================================================

def cmd_transcribe(args):
    """Команда: транскрипция аудио"""
    print("\n" + "="*60)
    print("🎙️  ТРАНСКРИПЦИЯ АУДИО (AssemblyAI)")
    print("="*60)

    # Проверка API ключа
    if not config.ASSEMBLYAI_API_KEY:
        print("\n❌ Ошибка: ASSEMBLYAI_API_KEY не указан в .env")
        sys.exit(1)

    # Проверка файла
    audio_path = Path(args.audio)
    if not audio_path.exists():
        print(f"\n❌ Аудиофайл не найден: {audio_path}")
        sys.exit(1)

    # Определение выходного пути
    output_path = args.output or audio_path.parent / 'transcription.json'
    
    # Язык
    language_code = args.language or config.ASSEMBLYAI_LANGUAGE_CODE
    print(f"\n📊 Язык транскрипции: {language_code}")

    try:
        # Транскрипция
        result = transcribe_audio(str(audio_path), str(output_path), language_code=language_code)

        print(f"\n✅ ТРАНСКРИПЦИЯ ЗАВЕРШЕНА!")
        print(f"   Фрагментов: {len(result['transcription'])}")
        print(f"   Длительность: {result['audioDuration']:.2f} сек")
        print(f"   Файл: {output_path}")

    except Exception as e:
        print(f"\n❌ Ошибка транскрипции: {e}")
        logging.debug(traceback.format_exc())
        sys.exit(1)


def cmd_direct(args):
    """Команда: режиссерский анализ"""
    log_dir = Path(__file__).parent / 'logs'
    log_file = setup_logging(log_dir)

    print("\n" + "="*60)
    print("🎬 РЕЖИССЕРСКИЙ АНАЛИЗ (Gemini)")
    print("="*60)
    print(f"📝 Лог-файл: {log_file}")

    # Проверка API ключа
    if not config.GEMINI_API_KEY:
        print("\n❌ Ошибка: GEMINI_API_KEY не указан в .env")
        sys.exit(1)

    # Проверка файлов
    transcription_path = Path(args.transcription)
    style_guide_path = Path(args.style)

    if not transcription_path.exists():
        print(f"\n❌ Транскрипция не найдена: {transcription_path}")
        sys.exit(1)

    if not style_guide_path.exists():
        print(f"\n❌ Style guide не найден: {style_guide_path}")
        sys.exit(1)

    # Валидация транскрипции
    is_valid, data, msg = validate_json_file(str(transcription_path))
    if not is_valid:
        print(f"\n❌ Ошибка транскрипции: {data}")
        sys.exit(1)

    is_valid, errors = validate_transcription_json(data)
    if not is_valid:
        print(f"\n⚠️  Предупреждения транскрипции:")
        for error in errors:
            print(f"   • {error}")
        if not args.force:
            print("\nИспользуйте --force для пропуска валидации")
            sys.exit(1)

    # Определение выходной директории
    output_dir = args.output or transcription_path.parent

    # Выбор модели
    model_name = args.model or config.GEMINI_MODEL
    print(f"\n📊 Модель: {model_name}")
    
    # director_analysis.md
    generate_director = args.director_analysis if args.director_analysis is not None else config.GENERATE_DIRECTOR_ANALYSIS
    print(f"📊 director_analysis.md: {'✓ ВКЛЮЧЕН' if generate_director else '✗ ОТКЛЮЧЕН'}")

    two_pass = getattr(args, 'two_pass', False)
    prompts_only = getattr(args, 'prompts_only', False)
    if prompts_only:
        print(f"📊 Режим: только промпты (--prompts-only, проход 2)")
    elif two_pass:
        print(f"📊 Режим: 2-проходный (--two-pass)")
    else:
        print(f"📊 Режим: 1-проходный")

    # Resume: ищем существующий файл промптов
    resume_path = None
    if getattr(args, 'resume', False) and prompts_only:
        _od = Path(output_dir)
        _candidates = sorted(_od.glob(f"{args.project}_prompts_*.txt"))
        _non_over = [f for f in _candidates if 'OVERPROMPT' not in f.name]
        _best = _non_over[-1] if _non_over else (_candidates[-1] if _candidates else None)
        if _best:
            resume_path = str(_best)
            print(f"\n🔄 Продолжение с файла: {_best.name}")
        else:
            print("\n⚠️  Существующий файл промптов не найден, начинаем заново")

    try:
        # Режиссерский анализ
        results = direct_project(
            str(transcription_path),
            str(style_guide_path),
            str(output_dir),
            args.project,
            model_name=model_name,
            two_pass=two_pass,
            prompts_only=prompts_only,
            resume_path=resume_path,
        )

        print(f"\n✅ РЕЖИССЕРСКИЙ АНАЛИЗ ЗАВЕРШЕН!")
        for name, path in results.items():
            print(f"   • {name}: {path}")

    except Exception as e:
        print(f"\n❌ Ошибка режиссерского анализа: {e}")
        logging.debug(traceback.format_exc())
        sys.exit(1)


def cmd_script_direct(args):
    """Команда: режиссура из текстового сценария (без аудио/транскрипции)."""
    print("\n" + "="*60)
    print("🎬 SCRIPT DIRECTOR MODE")
    print("="*60)

    script_path = Path(args.script)
    style_path  = Path(args.style)

    if not script_path.exists():
        print(f"\n❌ Сценарий не найден: {script_path}")
        sys.exit(1)
    if not style_path.exists():
        print(f"\n❌ Style guide не найден: {style_path}")
        sys.exit(1)

    # Папка вывода: рядом со сценарием или явно заданная
    if args.output:
        output_dir = Path(args.output)
    else:
        output_dir = script_path.parent / f"SCRIPT_{script_path.stem}"
    output_dir.mkdir(parents=True, exist_ok=True)

    project_name = args.project or script_path.stem
    script_type  = args.script_type
    two_pass     = args.two_pass

    log_dir = Path(__file__).parent / 'logs'
    setup_logging(log_dir)
    logging.info(f"Script director: script={script_path.name} type={script_type} two_pass={two_pass}")

    # Применяем настройки длительности клипов из CLI
    if getattr(args, 'clip_mode', None) == 'slideshow':
        config.ACTIVE_CLIP_MIN_DURATION = config.SLIDESHOW_CLIP_MIN_DURATION
        config.ACTIVE_CLIP_MAX_DURATION = config.SLIDESHOW_CLIP_MAX_DURATION
    if getattr(args, 'clip_min', None):
        config.ACTIVE_CLIP_MIN_DURATION = args.clip_min
    if getattr(args, 'clip_max', None):
        config.ACTIVE_CLIP_MAX_DURATION = args.clip_max

    print(f"   Сценарий:   {script_path.name}")
    print(f"   Тип:        {script_type}")
    print(f"   Style:      {style_path.name}")
    print(f"   Проект:     {project_name}")
    print(f"   Режим:      {'2-pass' if two_pass else '1-pass'}")
    print(f"   Клипы:      {config.ACTIVE_CLIP_MIN_DURATION}-{config.ACTIVE_CLIP_MAX_DURATION}с")
    print(f"   Вывод:      {output_dir}")

    try:
        result = script_direct_project(
            script_path=str(script_path),
            style_guide_path=str(style_path),
            output_dir=str(output_dir),
            project_name=project_name,
            script_type=script_type,
            two_pass=two_pass,
        )
        print(f"\n✅ Script Director завершён!")
        for k, v in result.items():
            if k not in ('cost', 'num_prompts', 'num_clips'):
                print(f"   • {k}: {v}")

        # Пост-пайплайн генерация
        post_action = getattr(args, 'post_action', None)
        yt_pack = getattr(args, 'yt_pack', False)
        if post_action and post_action != 'skip':
            _run_post_pipeline_silent(str(output_dir), post_action, run_yt_pack=yt_pack)
        elif yt_pack:
            _run_post_pipeline_silent(str(output_dir), 'skip', run_yt_pack=True)

    except Exception as e:
        print(f"\n❌ Ошибка: {e}")
        logging.debug(traceback.format_exc())
        sys.exit(1)


def cmd_validate(args):
    """Команда: валидация файлов"""
    print("\n" + "="*60)
    print("🔍 ВАЛИДАЦИЯ ФАЙЛОВ")
    print("="*60)
    
    files_validated = 0
    errors_found = 0
    
    # Валидация transcription.json
    if args.transcription:
        print(f"\n📄 Валидация: {args.transcription}")
        is_valid, data, msg = validate_json_file(args.transcription)
        
        if is_valid:
            is_valid, errors = validate_transcription_json(data)
            if is_valid:
                print("   ✅ transcription.json валиден")
                files_validated += 1
            else:
                print("   ❌ Ошибки transcription.json:")
                for error in errors:
                    print(f"      • {error}")
                errors_found += len(errors)
        else:
            print(f"   ❌ {data}")
            errors_found += 1
    
    # Валидация montage_plan.json
    if args.montage_plan:
        print(f"\n📄 Валидация: {args.montage_plan}")
        is_valid, data, msg = validate_json_file(args.montage_plan)
        
        if is_valid:
            audio_duration = data.get('audioDuration', 0)
            is_valid, errors = validate_montage_plan_json(data, audio_duration)
            if is_valid:
                print("   ✅ montage_plan.json валиден")
                files_validated += 1
            else:
                print("   ❌ Ошибки montage_plan.json:")
                for error in errors:
                    print(f"      • {error}")
                errors_found += len(errors)
        else:
            print(f"   ❌ {data}")
            errors_found += 1
    
    # Валидация всех файлов в директории
    if args.all or args.dir:
        dir_path = Path(args.dir) if args.dir else Path('.')
        print(f"\n📄 Сканирование директории: {dir_path}")
        
        for json_file in dir_path.glob('*.json'):
            if json_file.name in ['transcription.json', 'montage_plan.json']:
                if json_file.name == 'transcription.json':
                    args.transcription = str(json_file)
                    cmd_validate(args)
                elif json_file.name == 'montage_plan.json':
                    args.montage_plan = str(json_file)
                    cmd_validate(args)
    
    # Итог
    print("\n" + "="*60)
    if errors_found == 0:
        print(f"✅ ВАЛИДАЦИЯ ЗАВЕРШЕНА: {files_validated} файлов без ошибок")
    else:
        print(f"❌ ВАЛИДАЦИЯ ЗАВЕРШЕНА: найдено {errors_found} ошибок")
        sys.exit(1)


def cmd_run(args):
    """Команда: полный пайплайн (этапы 1-2)"""
    print("\n" + "="*60)
    print("🚀 ПОЛНЫЙ ПЛАЙПЛАЙН (Этапы 1-2: Агент)")
    print("="*60)

    # Проверка API ключей
    errors = config.check_api_keys()
    if errors:
        print("\n❌ Ошибки конфигурации:")
        for error in errors:
            print(f"   • {error}")
        sys.exit(1)

    # Проверка аудиофайла
    audio_path = Path(args.audio)
    if not audio_path.exists():
        print(f"\n❌ Аудиофайл не найден: {audio_path}")
        sys.exit(1)

    # Проверка style guide
    style_guide_path = Path(args.style)
    if not style_guide_path.exists():
        print(f"\n❌ Style guide не найден: {style_guide_path}")
        sys.exit(1)

    # Настройка логгирования
    log_dir = Path('logs')
    log_file = setup_logging(log_dir)
    logging.info(f"Запуск пайплайна: {args.audio}")
    
    # Язык транскрипции
    language_code = args.language or config.ASSEMBLYAI_LANGUAGE_CODE
    print(f"\n📊 Язык транскрипции: {language_code}")
    
    # Выбор модели
    model_name = args.model or config.GEMINI_MODEL
    print(f"📊 Модель Gemini: {model_name}")
    
    # director_analysis.md
    generate_director = args.director_analysis if args.director_analysis is not None else config.GENERATE_DIRECTOR_ANALYSIS
    print(f"📊 director_analysis.md: {'✓ ВКЛЮЧЕН' if generate_director else '✗ ОТКЛЮЧЕН'}")

    # ЭТАП 1: ТРАНСКРИПЦИЯ
    print("\n" + "="*60)
    print("ЭТАП 1/2: ТРАНСКРИПЦИЯ")
    print("="*60)

    transcription_output = audio_path.parent / 'transcription.json'

    try:
        transcription_result = transcribe_audio(str(audio_path), str(transcription_output), language_code=language_code)
        logging.info(f"Транскрипция завершена: {transcription_output}")
    except Exception as e:
        print(f"\n❌ Ошибка транскрипции: {e}")
        logging.debug(traceback.format_exc())
        sys.exit(1)

    # Проверка качества транскрипции перед режиссёром
    if transcription_result.get('_quality_critical', False):
        print("\n⛔ Транскрипция аномальная! Режиссёр НЕ запущен.")
        print("   Проверьте transcription.json и перезапустите транскрипцию.")
        print("   Используйте --force для принудительного запуска.")
        if not getattr(args, 'force', False):
            sys.exit(1)

    # ЭТАП 2: РЕЖИССЕРСКИЙ АНАЛИЗ
    print("\n" + "="*60)
    print("ЭТАП 2/2: РЕЖИССЕРСКИЙ АНАЛИЗ")
    print("="*60)

    output_dir = audio_path.parent

    try:
        result = direct_project(
            str(transcription_output),
            str(style_guide_path),
            str(output_dir),
            args.project,
            model_name=model_name
        )
        logging.info(f"Режиссерский анализ завершен: {output_dir}")
        
        # Вывод стоимости сразу после завершения
        if 'cost' in result:
            print(f"\n💰 СТОИМОСТЬ:")
            print(f"   Input:  {result['cost']['input_tokens']:,} токенов = ${result['cost']['input_cost']:.4f}")
            print(f"   Output: {result['cost']['output_tokens']:,} токенов = ${result['cost']['output_cost']:.4f}")
            print(f"   ИТОГО:  ${result['cost']['total_cost']:.4f}")
    except Exception as e:
        print(f"\n❌ Ошибка режиссерского анализа: {e}")
        logging.debug(traceback.format_exc())
        sys.exit(1)

    # ЭТАП 3: ГЕНЕРАЦИЯ ИЗОБРАЖЕНИЙ (опционально)
    if getattr(args, 'with_images', False):
        if not config.FASTGEN_API_KEY:
            print("\n[WARN] FASTGEN_API_KEY not set, skipping image generation")
        else:
            print("\n" + "="*60)
            print("STAGE 3/3: IMAGE GENERATION (FastGen)")
            print("="*60)

            try:
                gen_result = generate_all_images(
                    project_dir=str(output_dir),
                )
                ok = gen_result.get('generated', 0)
                total = gen_result.get('total_clips', 0)
                logging.info(f"Image generation: {ok}/{total}")
            except Exception as e:
                print(f"\n[ERROR] Image generation failed: {e}")
                logging.debug(traceback.format_exc())
                # Don't exit — stages 1-2 already completed

    # ФИНАЛ — отчет
    print("\n" + "="*60)
    print("STAGES 1-2 COMPLETE!")
    print("="*60)

    # Чтение лога проекта для вывода стоимости
    project_log = output_dir / f'{args.project}_log.txt'
    if project_log.exists():
        with open(project_log, 'r', encoding='utf-8') as f:
            content = f.read()
            if "СТОИМОСТЬ:" in content:
                cost_section = content.split("СТОИМОСТЬ:")[1].split("===")[0]
                print(f"\n  Cost: {cost_section.strip()}")

    print(f"\n  Output: {output_dir}")
    print(f"  Prompts: {args.project}_prompts_*.txt")
    print(f"  Log: {log_file}")

    # Интерактивное меню: только в терминале (не в GUI/pipeline)
    if sys.stdin.isatty():
        _ask_post_pipeline_action(str(output_dir))
        _ask_yt_packer(str(output_dir), source_lang=language_code)


def cmd_status(args):
    """Команда: статус проекта"""
    print("\n" + "="*60)
    print("📊 СТАТУС ПРОЕКТА")
    print("="*60)

    project_dir = Path(args.dir) if args.dir else Path('.')

    # Проверка файлов
    files = {
        'narration.wav': 'Аудио озвучка',
        'transcription.json': 'Транскрипция',
        'montage_plan.json': 'Монтажный план',
    }

    print(f"\n📂 Директория: {project_dir.absolute()}\n")

    for filename, description in files.items():
        file_path = project_dir / filename
        if file_path.exists():
            size = file_path.stat().st_size
            if size > 1024*1024:
                size_str = f"{size / (1024*1024):.1f} MB"
            elif size > 1024:
                size_str = f"{size / 1024:.1f} KB"
            else:
                size_str = f"{size} B"
            print(f"   ✅ {filename:<25} {size_str:>10}  {description}")
        else:
            print(f"   ❌ {filename:<25} {'не найден':>10}  {description}")

    # Проверка style guide файла (ищем по маске *_style_*.txt)
    style_files = list(project_dir.glob('*_style_*.txt'))
    if style_files:
        for sf in style_files:
            size = sf.stat().st_size
            size_str = f"{size / 1024:.1f} KB" if size > 1024 else f"{size} B"
            print(f"   ✅ {sf.name:<25} {size_str:>10}  Style Guide")
    else:
        print(f"   ❌ {'*_style_*.txt':<25} {'не найден':>10}  Style Guide")

    # Проверка prompts файла (ищем по маске *_prompts_*.txt)
    prompts_files = list(project_dir.glob('*_prompts_*.txt'))
    if prompts_files:
        for pf in prompts_files:
            size = pf.stat().st_size
            size_str = f"{size / 1024:.1f} KB" if size > 1024 else f"{size} B"
            print(f"   ✅ {pf.name:<25} {size_str:>10}  Промпты для Veo3")
    else:
        print(f"   ❌ {'*_prompts_*.txt':<25} {'не найден':>10}  Промпты для Veo3")

    # Проверка видеофайлов
    print("\n🎬 Видеофрагменты:")
    video_files = list(project_dir.glob('*.mp4')) + list(project_dir.glob('*.mov'))

    if video_files:
        # Проверка переименованных файлов
        numbered_files = [f for f in video_files if f.name[0].isdigit()]
        veo_files = [f for f in video_files if 'veo' in f.name.lower()]

        if numbered_files:
            print(f"   ✅ Переименованные: {len(numbered_files)} файлов")
            max_num = max(int(f.name.split('.')[0]) for f in numbered_files if f.name[0].isdigit())
            min_num = min(int(f.name.split('.')[0]) for f in numbered_files if f.name[0].isdigit())
            print(f"      Диапазон: {min_num} - {max_num}")

        if veo_files:
            print(f"   ⏳ Veo3 (требуют переименования): {len(veo_files)} файлов")
    else:
        print("   ⏳ Видеофрагменты не найдены (ожидают генерации в Veo3)")

    # Итог
    print("\n" + "="*60)

    # Определение стадии проекта
    if not (project_dir / 'transcription.json').exists():
        print("📍 СТАДИЯ: Ожидает транскрипции")
        print("   Запусти: agent run --audio narration.wav")
    elif not (project_dir / 'montage_plan.json').exists():
        print("📍 СТАДИЯ: Ожидает режиссерского анализа")
        print("   Запусти: agent direct --transcription transcription.json --style style_guide.txt")
    elif not video_files:
        print("📍 СТАДИЯ: Ожидает генерации видео в Veo3")
        print("   1. Открой prompts.txt")
        print("   2. Сгенерируй видео в Veo3")
        print("   3. Скачай в папку проекта")
    elif not numbered_files and veo_files:
        print("📍 СТАДИЯ: Ожидает переименования видео")
        print("   Запусти: process.bat")
    else:
        print("📍 СТАДИЯ: Готов к склейке")
        print("   Запусти: process.bat")


def cmd_cost_estimate(args):
    """Команда: оценка стоимости для озвучки"""
    print("\n" + "="*60)
    print("ОЦЕНКА СТОИМОСТИ GEMINI API")
    print("="*60)
    
    audio_duration_min = args.duration  # минуты
    language = args.language  # язык для учёта токенизации
    
    # Эмпирическая оценка
    # Русский язык: ~120-140 слов в минуту (медленнее английского)
    # Но токенизация БОЛЬШЕ: русское слово = 1.5-2.0 токена (vs 1.3 для английского)
    # Потому что:
    #   - Кириллица = больше байт на символ
    #   - Сложные окончания = больше суб-слов
    
    # Коэффициенты по языкам
    language_coeffs = {
        'en': {'wpm': 150, 'tokens_per_word': 1.3},   # английский
        'ru': {'wpm': 130, 'tokens_per_word': 1.8},   # русский (больше токенов!)
        'es': {'wpm': 140, 'tokens_per_word': 1.4},   # испанский
        'fr': {'wpm': 140, 'tokens_per_word': 1.4},   # французский
        'de': {'wpm': 130, 'tokens_per_word': 1.5},   # немецкий
        'it': {'wpm': 140, 'tokens_per_word': 1.4},   # итальянский
        'pt': {'wpm': 140, 'tokens_per_word': 1.4},   # португальский
        'zh': {'wpm': 180, 'tokens_per_word': 1.0},   # китайский (иероглифы)
        'ja': {'wpm': 180, 'tokens_per_word': 1.2},   # японский
        'ko': {'wpm': 170, 'tokens_per_word': 1.3},   # корейский
    }
    
    lang_config = language_coeffs.get(language, language_coeffs['ru'])
    words_per_minute = lang_config['wpm']
    tokens_per_word = lang_config['tokens_per_word']
    
    # Расчёт количества слов и токенов транскрипции
    total_words = audio_duration_min * words_per_minute
    transcription_tokens = int(total_words * tokens_per_word)
    
    # ========================================================================
    # ВХОДНЫЕ ТОКЕНЫ (INPUT)
    # ========================================================================
    # 1. Системный промпт (инструкция режиссёра с правилами пауз и т.д.)
    system_prompt_tokens = 5130
    
    # 2. Style guide (визуальный стиль проекта)
    style_guide_tokens = 700
    
    # 3. Транскрипция (рассчитана выше)
    # transcription_tokens
    
    # 4. Дополнительные данные (название, длительность, форматирование)
    extra_tokens = 210
    
    input_tokens = system_prompt_tokens + style_guide_tokens + transcription_tokens + extra_tokens
    
    # ========================================================================
    # ВЫХОДНЫЕ ТОКЕНЫ (OUTPUT)
    # ========================================================================
    # Оценка количества сцен: 1 сцена на ~5 секунд аудио
    num_scenes = int((audio_duration_min * 60) / 5)
    
    # 1. montage_plan.json (~25 токенов на клип)
    montage_plan_tokens = num_scenes * 25
    
    # 2. prompts.txt (style guide + visual description на каждую сцену)
    # ~200 токенов на сцену
    prompts_tokens = num_scenes * 200
    
    # 3. 4list_prompts.txt — ЗАМОРОЖЕНО (экономия ~280 токенов на сцену)
    # list_prompts_tokens = num_scenes * 280
    list_prompts_tokens = 0  # ИСКЛЮЧЁН ИЗ ПАЙПЛАЙНА
    
    # 4. director_analysis.md (таблица с обоснованиями) — УПРАВЛЯЕМОЕ
    # director_analysis_tokens = 5000  # Если включено
    director_analysis_tokens = 5000 if config.GENERATE_DIRECTOR_ANALYSIS else 0
    
    output_tokens = montage_plan_tokens + prompts_tokens + list_prompts_tokens + director_analysis_tokens
    
    # ========================================================================
    # ВЫВОД ИНФОРМАЦИИ
    # ========================================================================
    
    print(f"\nВходные данные:")
    print(f"   Длительность аудио: {audio_duration_min} мин")
    print(f"   Язык: {language}")
    print(f"   Примерное количество слов: {total_words:,}")
    print(f"   Токенизация: {tokens_per_word} токена/слово ({language})")
    print(f"   Токены транскрипции: ~{transcription_tokens:,}")
    
    print(f"\nВХОДНЫЕ ТОКЕНЫ (INPUT):")
    print(f"   Системный промпт:     ~{system_prompt_tokens:,}")
    print(f"   Style guide:          ~{style_guide_tokens:,}")
    print(f"   Транскрипция:         ~{transcription_tokens:,}")
    print(f"   Доп. данные:          ~{extra_tokens:,}")
    print(f"   {'-'*33}")
    print(f"   ВСЕГО INPUT:          ~{input_tokens:,}")
    
    print(f"\nВЫХОДНЫЕ ТОКЕНЫ (OUTPUT):")
    print(f"   montage_plan.json:    ~{montage_plan_tokens:,} ({num_scenes} сцен x 25)")
    print(f"   prompts.txt:          ~{prompts_tokens:,} ({num_scenes} сцен x 200)")
    print(f"   4list_prompts.txt:    ИСКЛЮЧЁН (экономия ~{num_scenes * 280:,} токенов)")
    if config.GENERATE_DIRECTOR_ANALYSIS:
        print(f"   director_analysis.md: ~{director_analysis_tokens:,} (ВКЛЮЧЕНО)")
    else:
        print(f"   director_analysis.md: ИСКЛЮЧЁН (экономия ~5,000 токенов)")
    print(f"   {'-'*33}")
    print(f"   ВСЕГО OUTPUT:         ~{output_tokens:,}")
    
    print("\n" + "="*60)
    print("СТОИМОСТЬ ПО МОДЕЛЯМ:")
    print("="*60)
    
    models = [
        ('gemini-2.5-flash', 'Flash (быстро/дешево)'),
        ('gemini-2.5-pro', 'Pro (качество)'),
        ('gemini-2.0-flash-exp', '2.0 Flash Exp (бесплатно beta)'),
    ]
    
    print(f"\n{'Модель':<25} {'Input':<12} {'Output':<12} {'Стоимость':<10}")
    print("-" * 60)
    
    for model_id, model_name in models:
        cost = config.estimate_cost(input_tokens, output_tokens, model_id)
        print(f"{model_name:<25} ${cost['input_cost']:<11.4f} ${cost['output_cost']:<11.4f} ${cost['total_cost']:.4f}")
    
    print("\n" + "="*60)
    print("Примечание:")
    assembly_cost = audio_duration_min * 0.15 / 60
    print(f"   * AssemblyAI: ~$0.15/час = ${assembly_cost:.2f} за {audio_duration_min} мин")
    print("   * Цены актуальны на 2026-02-21")
    print("   * gemini-2.0-flash-exp бесплатен в период beta")
    print(f"   * 4list_prompts.txt ИСКЛЮЧЁН — экономия ~{num_scenes * 280:,} токенов output")
    print(f"   * director_analysis.md: {'ВКЛЮЧЁНО' if config.GENERATE_DIRECTOR_ANALYSIS else 'ОТКЛЮЧЕНО'} (экономия ~5,000 токенов = $0.05/проект на Pro)")
    print(f"   * Управление: GENERATE_DIRECTOR_ANALYSIS в .env или --director-analysis в CLI")
    print("="*60)


def _save_failed_prompts(project_dir: str, stage: str, failed_count: int) -> None:
    """Сохраняет информацию о несгенерированных клипах в failed_prompts.txt.

    stage: 'imggen', 'i2v', 't2v', 'components'
    """
    p = Path(project_dir)
    failed_file = p / 'failed_prompts.txt'

    # Читаем промпты
    try:
        from modules.extract_prompt import extract_all_prompts, find_prompts_file
        prompts_file = find_prompts_file(str(p))
        all_prompts = extract_all_prompts(prompts_file) if prompts_file else {}
    except Exception:
        all_prompts = {}

    # Читаем montage_plan для списка clip IDs
    try:
        import json as _json
        mp_path = p / 'montage_plan.json'
        if mp_path.exists():
            mp_data = _json.loads(mp_path.read_text(encoding='utf-8'))
            mp = mp_data.get('montage_plan', mp_data)
            all_clip_ids = [c['id'] for c in mp.get('clips', [])]
        else:
            all_clip_ids = sorted(all_prompts.keys())
    except Exception:
        all_clip_ids = sorted(all_prompts.keys())

    missing = []

    if stage == 'imggen':
        gen_dir = p / 'generated'
        for cid in all_clip_ids:
            found = any((gen_dir / f"{cid:03d}{ext}").exists()
                        for ext in ('.png', '.jpg', '.jpeg', '.webp'))
            if not found:
                prompt = all_prompts.get(cid, f'(prompt #{cid} not found)')
                missing.append((cid, prompt))

    elif stage in ('i2v', 't2v', 'components'):
        vid_dir = p / 'vid_img'
        for cid in all_clip_ids:
            if not (vid_dir / f"{cid:03d}.mp4").exists():
                prompt = all_prompts.get(cid, f'(prompt #{cid} not found)')
                if stage == 'i2v':
                    # Показываем какой файл-картинку нужно было оживить
                    img_name = f"generated/{cid:03d}.png"
                    missing.append((cid, f"[image: {img_name}] {prompt[:150]}"))
                else:
                    missing.append((cid, prompt))

    if not missing:
        return

    lines = [f"=== FAILED {stage.upper()} ({len(missing)} clips) ===\n"]
    for cid, prompt in missing:
        lines.append(f"#{cid:03d}: {prompt[:200]}\n")

    # Append (не перезаписываем — могут быть failed от обоих стадий)
    with open(failed_file, 'a', encoding='utf-8') as f:
        f.writelines(lines)
        f.write("\n")

    print(f"  Failed {stage} prompts saved to: {failed_file.name} ({len(missing)} clips)")
    logging.info(f"Saved {len(missing)} failed {stage} prompts to {failed_file}")


def _start_inflight_watcher(p_dir: str, video_key_slot: str, video_parallel: int,
                            ar: str, prompt_mode: str):
    """Launch watch_i2v.py as background subprocess for inflight i2v mode.
    Returns Popen handle or None if watch_i2v.py not found / launch failed."""
    import subprocess as _sp
    watch_script = Path(__file__).parent / 'watch_i2v.py'
    if not watch_script.exists():
        print("  [WARN] watch_i2v.py not found — inflight mode disabled")
        return None
    cmd = [sys.executable, str(watch_script),
           '--project', p_dir,
           '--parallel', str(video_parallel),
           '--key-slot', video_key_slot,
           '--aspect', ar]
    if prompt_mode == 'single':
        cmd.append('--single-prompt')
    print(f"  [INFLIGHT] Starting watch_i2v.py (key={video_key_slot}, parallel={video_parallel})...")
    try:
        import os as _os
        _env = dict(_os.environ)
        _env['PYTHONUTF8'] = '1'
        proc = _sp.Popen(cmd, cwd=str(Path(__file__).parent), env=_env)
        return proc
    except Exception as e:
        print(f"  [WARN] Inflight mode failed to start: {e}")
        return None


def _run_post_pipeline_silent(project_dir: str, action: str, prompt_mode: str = 'single', run_yt_pack: bool = False) -> None:
    """Запуск пост-пайплайн генерации в silent-режиме (без интерактивных вопросов).

    Args:
        project_dir: Путь к проекту
        action: 'fastgen', 'fastgen_i2v', 'veo_i2v', 't2v', 'i2v', 'components'
        prompt_mode: 'single' (один промпт на все) или 'perclip' (оригинальные промпты)
    """
    if action == 'skip' or not action:
        return

    p_dir = str(project_dir)
    ar = config.VEONONSTOP_ASPECT_RATIO

    # GUI may override key slot and parallel via env vars
    imggen_key_slot  = os.environ.get('VARAGENT_IMGGEN_KEY_SLOT', '1')
    video_key_slot   = os.environ.get('VARAGENT_VIDEO_KEY_SLOT',  '1')
    imggen_parallel  = int(os.environ.get('VARAGENT_IMGGEN_PARALLEL',
                                          os.environ.get('VEONONSTOP_MAX_PARALLEL',
                                                         config.VEONONSTOP_MAX_PARALLEL)))
    video_parallel   = int(os.environ.get('VARAGENT_VIDEO_PARALLEL',
                                          os.environ.get('VEONONSTOP_MAX_PARALLEL',
                                                         config.VEONONSTOP_MAX_PARALLEL)))
    inflight_mode    = os.environ.get('VARAGENT_INFLIGHT_MODE', '0') == '1'
    fg_dual_key      = os.environ.get('FASTGEN_DUAL_KEY', '0') == '1'

    # Legacy: VEONONSTOP_MAX_PARALLEL still applies when not overridden
    parallel = video_parallel

    def _resolve_veo_key(slot: str) -> list:
        """Returns list of 1-based key indices for the given slot."""
        ALL_KEYS = [
            config.VEONONSTOP_API_KEY,
            config.VEONONSTOP_API_KEY_2,
            config.VEONONSTOP_API_KEY_3,
            config.VEONONSTOP_API_KEY_4,
        ]
        if slot in ('both', 'all'):
            active = [i + 1 for i, k in enumerate(ALL_KEYS) if k]
            return active if active else [1]
        try:
            idx = int(slot)
        except (ValueError, TypeError):
            idx = 1
        if 1 <= idx <= 4 and ALL_KEYS[idx - 1]:
            return [idx]
        return [1]

    # ── REF SIZE PREFLIGHT ────────────────────────────────────────────────────
    # Compress any refs that exceed 1.5 MB before any API calls touch them.
    # (Primary compression runs in a background thread during transcription;
    #  this call is a safety net for direct invocations and any leftovers.)
    _ref_dir_pf = Path(project_dir) / 'ref'
    if _ref_dir_pf.exists():
        compress_refs(str(_ref_dir_pf), max_mb=1.5)
    # ─────────────────────────────────────────────────────────────────────────

    print(f"\n  [Silent] Post-pipeline: {action.upper()}")
    print(f"  Ratio: {ar}  |  ImgKey: {imggen_key_slot}  ImgWorkers: {imggen_parallel}"
          f"  |  VidKey: {video_key_slot}  VidWorkers: {video_parallel}"
          + ("  | INFLIGHT" if inflight_mode else ""))

    try:
        if action == 'fastgen':
            if not config.FASTGEN_API_KEY:
                print("  [SKIP] FASTGEN_API_KEY not set")
                return
            print("  Starting FastGen image generation...")
            result = generate_all_images(project_dir=p_dir, dual_key=fg_dual_key)
            print(f"  FastGen done: {result.get('generated', 0)} images -> generated/")

        elif action == 'fastgen_i2v':
            if not config.FASTGEN_API_KEY:
                print("  [SKIP] FASTGEN_API_KEY not set")
                return
            if not config.VEONONSTOP_API_KEY:
                print("  [SKIP] VEONONSTOP_API_KEY not set")
                return

            # Inflight: start watch_i2v.py BEFORE imggen so it animates images as they appear
            _watch_proc = None
            if inflight_mode:
                _watch_proc = _start_inflight_watcher(p_dir, video_key_slot, video_parallel, ar, prompt_mode)

            print("  Starting FastGen image generation...")
            result = generate_all_images(project_dir=p_dir, dual_key=fg_dual_key)
            ok = result.get('generated', 0)
            img_failed = result.get('failed', 0)
            print(f"  FastGen done: {ok} images -> generated/")

            if img_failed > 0:
                _save_failed_prompts(p_dir, 'imggen', img_failed)

            if ok > 0:
                if inflight_mode and _watch_proc is not None:
                    print("  [INFLIGHT] Waiting for watch_i2v.py to finish...")
                    _watch_proc.wait()
                    print("  [INFLIGHT] watch_i2v done -> vid_img/")
                    vid_failed = 0  # watch_i2v manages its own retries
                else:
                    vid_keys = _resolve_veo_key(video_key_slot)
                    print("  Starting VeoNonStop i2v...")
                    single_prompt = None
                    if prompt_mode == 'single':
                        sp_path = Path(p_dir) / 'single_prompt.txt'
                        if sp_path.exists():
                            single_prompt = sp_path.read_text(encoding='utf-8').strip()
                            print(f"  Using single_prompt.txt: {single_prompt[:50]}...")
                        else:
                            single_prompt = 'default'
                    vid_result = veo_generate_all_videos(
                        project_dir=p_dir, mode='i2v',
                        max_parallel=video_parallel, aspect_ratio=ar,
                        single_prompt=single_prompt,
                        active_keys=vid_keys,
                        silent=True,
                    )
                    vid_failed = vid_result.get('failed', 0)
                    print("  i2v done -> vid_img/")
                    if vid_failed > 0:
                        _save_failed_prompts(p_dir, 'i2v', vid_failed)

                total_failed = img_failed + vid_failed
                if total_failed > 0:
                    marker = Path(p_dir) / 'has_failed_clips.flag'
                    marker.write_text(f"img_failed={img_failed}\nvid_failed={vid_failed}\n", encoding='utf-8')
                    print(f"  [WARNING] {total_failed} clips failed (img={img_failed}, vid={vid_failed})")
                    print(f"  Failed info saved to: failed_prompts.txt + has_failed_clips.flag")
            elif inflight_mode and _watch_proc is not None:
                _watch_proc.terminate()

        elif action == 'veo_i2v':
            if not config.VEONONSTOP_API_KEY:
                print("  [SKIP] VEONONSTOP_API_KEY not set")
                return

            # Inflight: start watch_i2v.py BEFORE imggen
            _watch_proc = None
            if inflight_mode:
                _watch_proc = _start_inflight_watcher(p_dir, video_key_slot, video_parallel, ar, prompt_mode)

            imggen_keys = _resolve_veo_key(imggen_key_slot)
            imggen_mode = config.VEONONSTOP_IMGGEN_MODE
            print(f"  Starting VeoNonStop image generation (mode={imggen_mode}, key={imggen_key_slot})...")
            result = veo_generate_all_images(
                project_dir=p_dir,
                mode=imggen_mode,
                max_parallel=imggen_parallel,
                aspect_ratio=ar,
                active_keys=imggen_keys,
                silent=True,
            )
            ok = result.get('generated', 0)
            img_failed = result.get('failed', 0)
            print(f"  VeoNonStop images done: {ok} images -> generated/")

            if img_failed > 0:
                _save_failed_prompts(p_dir, 'imggen', img_failed)

            if ok > 0:
                if inflight_mode and _watch_proc is not None:
                    print("  [INFLIGHT] Waiting for watch_i2v.py to finish...")
                    _watch_proc.wait()
                    print("  [INFLIGHT] watch_i2v done -> vid_img/")
                    vid_failed = 0
                else:
                    vid_keys = _resolve_veo_key(video_key_slot)
                    print("  Starting VeoNonStop i2v...")
                    single_prompt = None
                    if prompt_mode == 'single':
                        sp_path = Path(p_dir) / 'single_prompt.txt'
                        if sp_path.exists():
                            single_prompt = sp_path.read_text(encoding='utf-8').strip()
                            print(f"  Using single_prompt.txt: {single_prompt[:50]}...")
                        else:
                            single_prompt = 'default'
                    vid_result = veo_generate_all_videos(
                        project_dir=p_dir, mode='i2v',
                        max_parallel=video_parallel, aspect_ratio=ar,
                        single_prompt=single_prompt,
                        active_keys=vid_keys,
                        silent=True,
                    )
                    vid_failed = vid_result.get('failed', 0)
                    print("  i2v done -> vid_img/")
                    if vid_failed > 0:
                        _save_failed_prompts(p_dir, 'i2v', vid_failed)

                total_failed = img_failed + vid_failed
                if total_failed > 0:
                    marker = Path(p_dir) / 'has_failed_clips.flag'
                    marker.write_text(f"img_failed={img_failed}\nvid_failed={vid_failed}\n", encoding='utf-8')
                    print(f"  [WARNING] {total_failed} clips failed (img={img_failed}, vid={vid_failed})")
                    print(f"  Failed info saved to: failed_prompts.txt + has_failed_clips.flag")
            elif inflight_mode and _watch_proc is not None:
                _watch_proc.terminate()

        elif action in ('t2v', 'i2v', 'components'):
            if not config.VEONONSTOP_API_KEY:
                print("  [SKIP] VEONONSTOP_API_KEY not set")
                return
            if action == 'i2v':
                from pathlib import Path as _Path
                gen_dir = _Path(project_dir) / 'generated'
                if not gen_dir.exists() or not list(gen_dir.glob('*.png')):
                    print("  [SKIP] i2v requires images in generated/ — run FastGen first")
                    return
            ref_dir = None
            if action == 'components':
                from pathlib import Path as _Path
                ref_dir = str(_Path(project_dir) / 'ref')
            vid_keys = _resolve_veo_key(video_key_slot)
            print(f"  Starting VeoNonStop {action} (key={video_key_slot})...")
            vid_result = veo_generate_all_videos(
                project_dir=p_dir, mode=action,
                max_parallel=video_parallel, aspect_ratio=ar,
                ref_dir=ref_dir,
                active_keys=vid_keys,
                silent=True,
            )
            vid_failed = vid_result.get('failed', 0)
            print(f"  {action} done -> vid_img/")

            if vid_failed > 0:
                _save_failed_prompts(p_dir, action, vid_failed)
                marker = Path(p_dir) / 'has_failed_clips.flag'
                marker.write_text(f"vid_failed={vid_failed}\nmode={action}\n", encoding='utf-8')
                print(f"  [WARNING] {vid_failed} clips failed in {action}")
                print(f"  Failed info saved to: failed_prompts.txt + has_failed_clips.flag")

    except Exception as e:
        print(f"  [ERROR] Post-pipeline {action} failed: {e}")
        logging.debug(traceback.format_exc())

    # YT Packer (optional, runs after all other stages)
    if run_yt_pack:
        try:
            from modules.yt_packer import run_yt_packer
            print(f"\n  [YT Pack] Starting YouTube packer for {Path(project_dir).name}...")
            run_yt_packer(project_dir)
            print(f"  [YT Pack] Done → yt_pack/")
        except Exception as e:
            print(f"  [ERROR] YT Pack failed: {e}")
            logging.debug(traceback.format_exc())


def _ask_post_pipeline_action(project_dir: str, clip_ids=None, aspect_ratio: str = None) -> None:
    """Interactive menu after direction completes: what to do next with prompts."""
    if not config.VEONONSTOP_API_KEY:
        # No VeoNonStop key — skip the menu, show old message
        return

    print("\n" + "=" * 60)
    print("  WHAT TO DO NEXT?")
    print("=" * 60)
    print()
    print("  [1] FastGen images + VeoNonStop animate (i2v)")
    print("  [2] VeoNonStop images (Imagen/Banana) + VeoNonStop animate (i2v)")
    print("  [3] Prompts -> VeoNonStop text-to-video (t2v)")
    print("  [4] Prompts + refs -> VeoNonStop components (multi-image-to-video)")
    print("  [5] FastGen images only (no video)")
    print("  [6] VeoNonStop images only (no video)")
    print("  [7] Skip — manual workflow")
    print()

    while True:
        choice = input("  Select [1-7, Enter=7]: ").strip() or '7'
        if choice in ('1', '2', '3', '4', '5', '6', '7'):
            break
        print("  Enter 1-7")

    if choice == '7':
        print("  Skipped. Use run_generate / run_img2video bat files manually.")
        return

    p_dir = str(project_dir)

    # --- Aspect ratio ---
    ar = aspect_ratio or config.VEONONSTOP_ASPECT_RATIO
    print(f"\n  Aspect ratio (current: {ar}):")
    print("    [1] 16:9  [2] 9:16  [3] 1:1")
    ar_sel = input(f"    Select [1/2/3, Enter={ar}]: ").strip()
    if ar_sel == '1': ar = '16:9'
    elif ar_sel == '2': ar = '9:16'
    elif ar_sel == '3': ar = '1:1'

    # --- Parallel workers ---
    par = config.VEONONSTOP_MAX_PARALLEL
    par_input = input(f"\n  Parallel workers [1-24, Enter={par}]: ").strip()
    if par_input.isdigit() and 1 <= int(par_input) <= 24:
        par = int(par_input)

    # --- Choices 1, 2: images then i2v ---
    if choice in ('1', '2'):
        # Step A: generate images
        if choice == '1':
            # FastGen
            if not config.FASTGEN_API_KEY:
                print("\n  [ERROR] FASTGEN_API_KEY not set in .env")
                return
            print("\n  Starting FastGen image generation...")
            try:
                result = generate_all_images(
                    project_dir=p_dir,
                    clip_ids=clip_ids,
                )
                ok = result.get('generated', 0)
                print(f"  FastGen done: {ok} images generated")
            except Exception as e:
                print(f"  [ERROR] FastGen failed: {e}")
                return
        else:
            # VeoNonStop images — ask which sub-mode
            print("\n  VeoNonStop image generator:")
            print("    [1] Imagen 3.5")
            print("    [2] Banana Pro")
            print("    [3] Banana Pro + style-reference (iz ref/)")
            print()
            while True:
                img_choice = input("    Select [1/2/3, Enter=1]: ").strip() or '1'
                if img_choice in ('1', '2', '3'):
                    break
                print("    Enter 1, 2, or 3")
            img_mode = {'1': 'imagen', '2': 'banana', '3': 'banana_ref'}[img_choice]
            print(f"\n  Starting VeoNonStop image generation ({img_mode})...")
            try:
                result = veo_generate_all_images(
                    project_dir=p_dir,
                    mode=img_mode,
                    max_parallel=par,
                    clip_ids=clip_ids,
                    aspect_ratio=ar,
                )
                ok = result.get('generated', 0)
                print(f"  VeoNonStop images done: {ok} images generated")
            except Exception as e:
                print(f"  [ERROR] VeoNonStop image generation failed: {e}")
                return

        # Step B: ask prompt source for i2v
        print("\n  Prompt source for video animation:")
        print("    [1] Director prompts (per-clip from *_prompts_*.txt)")
        print("    [2] Single prompt for all clips")
        print()
        single_prompt = None
        while True:
            ps = input("    Select [1/2, Enter=1]: ").strip() or '1'
            if ps in ('1', '2'):
                break
            print("    Enter 1 or 2")
        if ps == '2':
            single_prompt = input("    Enter prompt: ").strip()
            if not single_prompt:
                print("    Empty prompt — using per-clip prompts")
                single_prompt = None

        print("\n  Starting VeoNonStop image-to-video...")
        try:
            result = veo_generate_all_videos(
                project_dir=p_dir,
                mode='i2v',
                max_parallel=par,
                clip_ids=clip_ids,
                single_prompt=single_prompt,
                aspect_ratio=ar,
            )
            ok = result.get('generated', 0)
            print(f"\n  img2video done: {ok} videos generated -> vid_img/")
        except Exception as e:
            print(f"  [ERROR] img2video failed: {e}")
        return

    # --- Choice 3: t2v ---
    if choice == '3':
        print("\n  Prompt source for text-to-video:")
        print("    [1] Director prompts (per-clip from *_prompts_*.txt)")
        print("    [2] Single prompt for all clips")
        print()
        single_prompt = None
        while True:
            ps = input("    Select [1/2, Enter=1]: ").strip() or '1'
            if ps in ('1', '2'):
                break
            print("    Enter 1 or 2")
        if ps == '2':
            single_prompt = input("    Enter prompt: ").strip()
            if not single_prompt:
                print("    Empty prompt — using per-clip prompts")
                single_prompt = None

        print("\n  Starting VeoNonStop text-to-video...")
        try:
            result = veo_generate_all_videos(
                project_dir=p_dir,
                mode='t2v',
                max_parallel=par,
                clip_ids=clip_ids,
                single_prompt=single_prompt,
                aspect_ratio=ar,
            )
            ok = result.get('generated', 0)
            print(f"\n  t2v done: {ok} videos generated -> vid_img/")
        except Exception as e:
            print(f"  [ERROR] t2v failed: {e}")
        return

    # --- Choice 4: components (multi-image-to-video) ---
    if choice == '4':
        ref_dir = str(Path(project_dir) / 'ref')
        if not Path(ref_dir).exists():
            print(f"\n  [WARN] ref/ folder not found: {ref_dir}")
            custom = input("  Custom ref path (or Enter to cancel): ").strip()
            if not custom:
                print("  Cancelled.")
                return
            ref_dir = custom

        print("\n  Starting VeoNonStop components (multi-image-to-video)...")
        try:
            result = veo_generate_all_videos(
                project_dir=p_dir,
                mode='components',
                max_parallel=par,
                clip_ids=clip_ids,
                aspect_ratio=ar,
                ref_dir=ref_dir,
            )
            ok = result.get('generated', 0)
            print(f"\n  components done: {ok} videos generated -> vid_img/")
        except Exception as e:
            print(f"  [ERROR] components failed: {e}")
        return

    # --- Choice 5: FastGen images only ---
    if choice == '5':
        if not config.FASTGEN_API_KEY:
            print("\n  [ERROR] FASTGEN_API_KEY not set in .env")
            return
        print("\n  Starting FastGen image generation...")
        try:
            result = generate_all_images(
                project_dir=p_dir,
                clip_ids=clip_ids,
            )
            ok = result.get('generated', 0)
            print(f"\n  FastGen done: {ok} images generated -> generated/")
        except Exception as e:
            print(f"  [ERROR] FastGen failed: {e}")
        return

    # --- Choice 6: VeoNonStop images only ---
    if choice == '6':
        print("\n  VeoNonStop image generator:")
        print("    [1] Imagen 3.5")
        print("    [2] Banana Pro")
        print("    [3] Banana Pro + style-reference (iz ref/)")
        print()
        while True:
            img_choice = input("    Select [1/2/3, Enter=1]: ").strip() or '1'
            if img_choice in ('1', '2', '3'):
                break
            print("    Enter 1, 2, or 3")
        img_mode = {'1': 'imagen', '2': 'banana', '3': 'banana_ref'}[img_choice]
        print(f"\n  Starting VeoNonStop image generation ({img_mode})...")
        try:
            result = veo_generate_all_images(
                project_dir=p_dir,
                mode=img_mode,
                max_parallel=par,
                clip_ids=clip_ids,
                aspect_ratio=ar,
            )
            ok = result.get('generated', 0)
            print(f"\n  VeoNonStop images done: {ok} images generated -> generated/")
        except Exception as e:
            print(f"  [ERROR] VeoNonStop image generation failed: {e}")
        return


def _ask_image_generator() -> str:
    """Интерактивный выбор генератора изображений."""
    print("\n  Image generator:")
    print("    [1] FastGen (Replicate)")
    print("    [2] VeoNonStop Imagen 3.5")
    print("    [3] VeoNonStop Banana Pro       (GEM_PIX_2)")
    print("    [4] VeoNonStop Banana Pro + ref (GEM_PIX_2)")
    print("    [5] VeoNonStop Banana 2         (NARWHAL)")
    print("    [6] VeoNonStop Banana 2  + ref  (NARWHAL)")
    print()
    while True:
        choice = input("  Select [1-6, Enter=1]: ").strip() or '1'
        if choice in ('1', '2', '3', '4', '5', '6'):
            return {'1': 'fastgen', '2': 'imagen', '3': 'banana', '4': 'banana_ref',
                    '5': 'banana2', '6': 'banana2_ref'}[choice]
        print("  Enter 1 to 6")


def _ask_post_generate_action() -> Optional[str]:
    """Интерактивный вопрос после генерации картинок: конвертировать в видео?"""
    print("\n  Convert images to video?")
    print("    [1] Yes, image-to-video (ozhivit kartinki)")
    print("    [2] Yes, text-to-video (bez kartinok, zanovo)")
    print("    [3] Yes, components (t2v + referensy iz ref/)")
    print("    [4] No, tolko izobrazheniya")
    print()
    while True:
        choice = input("  Select [1/2/3/4, Enter=4]: ").strip() or '4'
        if choice == '1':
            return 'i2v'
        elif choice == '2':
            return 't2v'
        elif choice == '3':
            return 'components'
        elif choice == '4':
            return None
        print("  Enter 1, 2, 3 or 4")


def _resolve_veo_key(slot: str) -> list:
    """Returns list of 1-based key indices for the given slot."""
    ALL_KEYS = [
        config.VEONONSTOP_API_KEY,
        config.VEONONSTOP_API_KEY_2,
        config.VEONONSTOP_API_KEY_3,
        config.VEONONSTOP_API_KEY_4,
    ]
    if slot in ('both', 'all'):
        active = [i + 1 for i, k in enumerate(ALL_KEYS) if k]
        return active if active else [1]
    try:
        idx = int(slot)
    except (ValueError, TypeError):
        idx = 1
    if 1 <= idx <= 4 and ALL_KEYS[idx - 1]:
        return [idx]
    return [1]


def cmd_generate(args):
    """Команда: генерация изображений (этап 3) — FastGen или VeoNonStop"""
    log_dir = Path(__file__).parent / 'logs'
    log_file = setup_logging(log_dir)

    print("\n" + "="*60)
    print("STAGE 3: IMAGE GENERATION")
    print("="*60)
    print(f"Log: {log_file}")

    # Определение папки проекта
    base_dir = Path(__file__).parent.parent
    project_dir = base_dir / 'projects' / args.project

    if not project_dir.exists():
        print(f"\n[ERROR] Project not found: {project_dir}")
        sys.exit(1)

    # Парсинг ID клипов
    clip_ids = None
    if args.ids:
        try:
            clip_ids = [int(x.strip()) for x in args.ids.split(',')]
            print(f"\n  Selected clips: {clip_ids}")
        except ValueError:
            print(f"\n[ERROR] Invalid --ids format: {args.ids} (expected: 1,2,3)")
            sys.exit(1)

    # Выбор генератора: CLI-аргумент или интерактивно
    image_gen = getattr(args, 'image_gen', None) or _ask_image_generator()

    try:
        if image_gen == 'fastgen':
            # --- FastGen ---
            key_slot = getattr(args, 'key_slot', '1')
            dual_key_flag = False

            if key_slot == '2':
                if not config.FASTGEN_API_KEY_2:
                    print("\n[ERROR] FASTGEN_API_KEY_2 not set in .env")
                    sys.exit(1)
                api_key = config.FASTGEN_API_KEY_2
                print("\n  [INFO] FastGen: using Key2 (FASTGEN_API_KEY_2)")
            elif key_slot == 'both':
                api_key = config.FASTGEN_API_KEY
                dual_key_flag = True
                print("\n  [INFO] FastGen: dual-key mode (Key1 + Key2)")
            else:
                # key_slot == '1' or legacy --backup-key
                api_key = config.FASTGEN_API_KEY
                if getattr(args, 'backup_key', False):
                    if not config.FASTGEN_API_KEY_BACKUP:
                        print("\n[ERROR] FASTGEN_API_KEY_BACKUP not set in .env")
                        sys.exit(1)
                    api_key = config.FASTGEN_API_KEY_BACKUP
                    print("\n  [INFO] FastGen: using BACKUP key")

            if not api_key:
                print("\n[ERROR] FASTGEN_API_KEY not set in .env")
                sys.exit(1)

            print(f"\n  Generator: FastGen ({args.model or config.FASTGEN_MODEL})")

            result = generate_all_images(
                project_dir=str(project_dir),
                max_parallel=args.parallel or config.FASTGEN_MAX_PARALLEL,
                clip_ids=clip_ids,
                mode=args.mode,
                model=args.model,
                aspect_ratio=args.aspect,
                api_key=api_key,
                preflight=not getattr(args, 'no_preflight', False),
                dual_key=dual_key_flag,
            )

        else:
            # --- VeoNonStop (imagen / banana / banana_ref) ---
            if not config.VEONONSTOP_API_KEY:
                print("\n[ERROR] VEONONSTOP_API_KEY not set in .env")
                sys.exit(1)

            key_slot = getattr(args, 'key_slot', '1')
            veo_keys = _resolve_veo_key(key_slot)
            print(f"\n  VeoNonStop keys: {veo_keys}")
            print(f"\n  Generator: VeoNonStop ({image_gen.upper()})")

            result = veo_generate_all_images(
                project_dir=str(project_dir),
                mode=image_gen,
                max_parallel=args.parallel or config.VEONONSTOP_MAX_PARALLEL,
                clip_ids=clip_ids,
                aspect_ratio=args.aspect,
                active_keys=veo_keys,
                preflight=not getattr(args, 'no_preflight', False),
                silent=not sys.stdin.isatty(),
            )

        ok = result.get('generated', 0)
        failed = result.get('failed', 0)

        print(f"\n{'='*60}")
        print(f"IMAGE GENERATION COMPLETE!")
        print(f"{'='*60}")
        print(f"  OK: {ok}")
        if failed:
            print(f"  Failed: {failed}")
        print(f"  Output: {project_dir / 'generated'}")

        # Предложение конвертировать в видео (если VeoNonStop ключ есть)
        if ok > 0 and config.VEONONSTOP_API_KEY and sys.stdin.isatty():
            video_mode = _ask_post_generate_action()
            if video_mode:
                # Спросить источник промптов (per-clip или один на всё)
                single_prompt = None
                print("\n  Prompt source for video generation:")
                print("    [1] Director prompts (per-clip from *_prompts_*.txt)")
                print("    [2] Single prompt for all clips")
                print()
                while True:
                    ps = input("    Select [1/2, Enter=1]: ").strip() or '1'
                    if ps in ('1', '2'):
                        break
                    print("    Enter 1 or 2")
                if ps == '2':
                    single_prompt = input("    Enter prompt: ").strip() or None

                print(f"\n  Starting img2video ({video_mode})...")
                veo_generate_all_videos(
                    project_dir=str(project_dir),
                    mode=video_mode,
                    max_parallel=config.VEONONSTOP_MAX_PARALLEL,
                    clip_ids=clip_ids,
                    aspect_ratio=args.aspect,
                    single_prompt=single_prompt,
                )

    except Exception as e:
        print(f"\n[ERROR] Generation failed: {e}")
        logging.debug(traceback.format_exc())
        sys.exit(1)


def cmd_img2video(args):
    """Команда: генерация видеоклипов через VeoNonStop API (этап 3.5)"""
    log_dir = Path(__file__).parent / 'logs'
    log_file = setup_logging(log_dir)

    print("\n" + "="*60)
    print("STAGE 3.5: VIDEO GENERATION (VeoNonStop)")
    print("="*60)
    print(f"Log: {log_file}")

    if not config.VEONONSTOP_API_KEY:
        print("\n[ERROR] VEONONSTOP_API_KEY not set in .env")
        sys.exit(1)

    # Определение папки проекта
    base_dir = Path(__file__).parent.parent
    project_dir = base_dir / 'projects' / args.project

    if not project_dir.exists():
        print(f"\n[ERROR] Project not found: {project_dir}")
        sys.exit(1)

    # Парсинг ID клипов
    clip_ids = None
    if args.ids:
        try:
            clip_ids = [int(x.strip()) for x in args.ids.split(',')]
            print(f"\n  Selected clips: {clip_ids}")
        except ValueError:
            print(f"\n[ERROR] Invalid --ids format: {args.ids}")
            sys.exit(1)

    # Prompt: --prompt-file overrides --prompt (fixes Cyrillic encoding via CMD)
    single_prompt = args.prompt
    if getattr(args, 'prompt_file', None):
        pf = Path(args.prompt_file)
        if not pf.exists():
            print(f"\n[ERROR] --prompt-file not found: {pf}")
            sys.exit(1)
        single_prompt = pf.read_text(encoding='utf-8').strip()
        if not single_prompt:
            print(f"\n[ERROR] --prompt-file is empty: {pf}")
            sys.exit(1)
        print(f"\n  Prompt loaded from file: \"{single_prompt[:80]}{'...' if len(single_prompt) > 80 else ''}\"")

    # Key slot
    key_slot = getattr(args, 'key_slot', '1')
    veo_keys = _resolve_veo_key(key_slot)
    print(f"\n  Video keys: {veo_keys}")

    # Режим — интерактивный выбор если не указан
    mode = args.mode
    if not mode:
        print("\n  Video generation mode:")
        print("    [1] i2v        — image-to-video (ozhivlenie kartinok iz generated/)")
        print("    [2] t2v        — text-to-video (video iz promptov, bez kartinok)")
        print("    [3] components — text-to-video + referensy iz ref/")
        print()
        while True:
            choice = input("  Select [1/2/3]: ").strip()
            if choice == '1':
                mode = 'i2v'
                break
            elif choice == '2':
                mode = 't2v'
                break
            elif choice == '3':
                mode = 'components'
                break
            print("  Enter 1, 2, or 3")

    try:
        result = veo_generate_all_videos(
            project_dir=str(project_dir),
            mode=mode,
            max_parallel=args.parallel or config.VEONONSTOP_MAX_PARALLEL,
            clip_ids=clip_ids,
            single_prompt=single_prompt,
            aspect_ratio=args.ratio,
            ref_dir=args.ref_dir,
            active_keys=veo_keys,
            no_cancel=getattr(args, 'no_cancel', False),
        )

        ok = result.get('generated', 0)
        failed = result.get('failed', 0)
        skipped = result.get('skipped', 0)

        print(f"\n{'='*60}")
        print(f"IMG2VIDEO COMPLETE!")
        print(f"{'='*60}")
        print(f"  OK: {ok}")
        print(f"  Skipped: {skipped}")
        if failed:
            print(f"  Failed: {failed}")
        print(f"  Output: {project_dir / 'vid_img'}")

    except Exception as e:
        print(f"\n[ERROR] img2video failed: {e}")
        logging.debug(traceback.format_exc())
        sys.exit(1)


def cmd_yt_pack(args):
    """Команда: YT Packer — YouTube-упаковщик"""
    project_name = args.project
    source_lang = getattr(args, 'source_lang', None)
    projects_dir = Path(__file__).parent.parent / 'projects'
    project_dir = projects_dir / project_name

    if not project_dir.exists():
        print(f"\n[ERROR] Проект не найден: {project_dir}")
        sys.exit(1)

    # Показать настройки / интерактивный выбор
    if getattr(args, 'interactive', False):
        _yt_packer_interactive()
    else:
        print()
        print("  " + "-" * 50)
        print(f"  Project:      {project_name}")
        print(f"  Languages:    {', '.join(config.YT_PACK_LANGUAGES)}")
        print(f"  Model:        {config.YT_PACK_MODEL}")
        print(f"  Subtitles:    {'ON' if config.YT_PACK_SUBTITLES else 'OFF'}")
        print(f"  Description:  {'ON' if config.YT_PACK_DESCRIPTION else 'OFF'}")
        print(f"  Covers:       {'ON' if config.YT_PACK_COVERS else 'OFF'}")
        if config.YT_PACK_COVERS:
            print(f"  Cover count:  {config.YT_PACK_COVER_COUNT}")
        print("  " + "-" * 50)
        print()
        choice = input("  Start? (1=yes / 2=exit, Enter=1): ").strip()
        if choice == '2':
            print("  Cancelled.")
            sys.exit(0)

    # Логгирование
    log_dir = Path(__file__).parent / 'logs'
    log_file = setup_logging(log_dir)

    try:
        results = run_yt_packer(str(project_dir), source_lang=source_lang)
        if not results:
            print("\n[WARN] YT Packer завершился без результатов")
    except Exception as e:
        print(f"\n[ERROR] YT Packer failed: {e}")
        logging.debug(traceback.format_exc())
        sys.exit(1)


def cmd_process_queue(args):
    """Команда: обработка очереди из ready_to_go"""
    run_pipeline = getattr(args, 'run', False)
    language_code = getattr(args, 'language', None) or config.ASSEMBLYAI_LANGUAGE_CODE

    # Логгирование — сразу при старте, всегда
    log_dir = Path(__file__).parent / 'logs'
    log_file = setup_logging(log_dir)

    print("\n" + "="*60)
    print("ОБРАБОТКА ОЧЕРЕДИ (ready_to_go)")
    if run_pipeline:
        print("+ АВТОЗАПУСК ПАЙПЛАЙНА (транскрипция + режиссура)")
    print("="*60)
    print(f"📝 Лог-файл: {log_file}")

    # Выбор режима: видео или слайдшоу
    clip_mode = getattr(args, 'clip_mode', None)
    print()
    if clip_mode == 'slideshow':
        config.ACTIVE_CLIP_MIN_DURATION = config.SLIDESHOW_CLIP_MIN_DURATION
        config.ACTIVE_CLIP_MAX_DURATION = config.SLIDESHOW_CLIP_MAX_DURATION
        print(f"  → Слайдшоурежим: клипы {config.ACTIVE_CLIP_MIN_DURATION}-{config.ACTIVE_CLIP_MAX_DURATION}с")
    elif clip_mode == 'video':
        config.ACTIVE_CLIP_MIN_DURATION = config.VIDEO_CLIP_MIN_DURATION
        config.ACTIVE_CLIP_MAX_DURATION = config.VIDEO_CLIP_MAX_DURATION
        print(f"  → Видеорежим: клипы {config.ACTIVE_CLIP_MIN_DURATION}-{config.ACTIVE_CLIP_MAX_DURATION}с")
    else:
        print("Что создаём?")
        print(f"  [1] Видео      (Veo3-фрагменты)   клипы {config.VIDEO_CLIP_MIN_DURATION}-{config.VIDEO_CLIP_MAX_DURATION}с  (Enter = по умолчанию)")
        print(f"  [2] Слайдшоу   (картинки)          клипы {config.SLIDESHOW_CLIP_MIN_DURATION}-{config.SLIDESHOW_CLIP_MAX_DURATION}с")
        print()
        while True:
            mode_choice = input("Ваш выбор [1/2]: ").strip()
            if mode_choice in ('', '1'):
                config.ACTIVE_CLIP_MIN_DURATION = config.VIDEO_CLIP_MIN_DURATION
                config.ACTIVE_CLIP_MAX_DURATION = config.VIDEO_CLIP_MAX_DURATION
                print(f"  → Видеорежим: клипы {config.ACTIVE_CLIP_MIN_DURATION}-{config.ACTIVE_CLIP_MAX_DURATION}с")
                break
            elif mode_choice == '2':
                config.ACTIVE_CLIP_MIN_DURATION = config.SLIDESHOW_CLIP_MIN_DURATION
                config.ACTIVE_CLIP_MAX_DURATION = config.SLIDESHOW_CLIP_MAX_DURATION
                print(f"  → Слайдшоурежим: клипы {config.ACTIVE_CLIP_MIN_DURATION}-{config.ACTIVE_CLIP_MAX_DURATION}с")
                break
            else:
                print("  Введите 1 или 2 (Enter = видео)")

    # Переопределение длительности клипов из CLI (--clip-min / --clip-max)
    clip_min_arg = getattr(args, 'clip_min', None)
    clip_max_arg = getattr(args, 'clip_max', None)
    if clip_min_arg is not None:
        config.ACTIVE_CLIP_MIN_DURATION = clip_min_arg
    if clip_max_arg is not None:
        config.ACTIVE_CLIP_MAX_DURATION = clip_max_arg
    if clip_min_arg is not None or clip_max_arg is not None:
        print(f"  → Длительность переопределена: {config.ACTIVE_CLIP_MIN_DURATION}-{config.ACTIVE_CLIP_MAX_DURATION}с")

    # Параметры вступительного блока
    intro_min = config.get_intro_clip_min()
    intro_max = config.get_intro_clip_max()
    print(f"  → Вступительный блок: первые {config.INTRO_BLOCK_DURATION}с → клипы {intro_min}-{intro_max}с")

    # Пути к папкам
    base_dir = Path(__file__).parent.parent
    _queue_dir_arg = getattr(args, 'queue_dir', None)
    if _queue_dir_arg and Path(_queue_dir_arg).is_dir():
        ready_dir = Path(_queue_dir_arg)
        print(f"\n[GUI] Queue dir: {ready_dir.name}/")
    else:
        ready_dir = base_dir / 'ready_to_go'
    projects_dir = base_dir / 'projects'
    concat_script = base_dir / 'video_concat.py'

    # Проверка папок
    if not ready_dir.exists():
        ready_dir.mkdir(parents=True, exist_ok=True)
        print(f"\n✅ Папка {ready_dir.name} создана: {ready_dir}")

    if not projects_dir.exists():
        projects_dir.mkdir(parents=True, exist_ok=True)
        print(f"✅ Папка projects создана: {projects_dir}")

    # Получение списка файлов
    audio_files = get_ready_files(ready_dir)

    # --file-list из GUI: сохраняем порядок загрузки (обходит алфавитную сортировку)
    _file_list_raw = getattr(args, 'file_list', None)
    if _file_list_raw:
        try:
            import json as _json_fl
            _fl = [Path(p) for p in _json_fl.loads(_file_list_raw) if Path(p).exists()]
            if _fl:
                audio_files = _fl
                print(f"\n[GUI] File list: {len(audio_files)} file(s) in GUI load order")
        except Exception as _fle:
            print(f"\n[WARN] --file-list parse error: {_fle}. Using ready_to_go scan order.")

    if not audio_files:
        print(f"\n[WARN] Нет файлов в ready_to_go")
        print(f"   Папка: {ready_dir}")
        print(f"   Положите туда .wav, .mp3, .flac, .m4a или .aac файлы")
        sys.exit(0)

    print(f"\nНайдено файлов: {len(audio_files)}")
    for f in audio_files:
        print(f"   - {f.name}")

    # Парсим --ref-map (индивидуальные рефы из GUI: {"audio.wav": "/path/.pending_refs/stem/"})
    import json as _json
    _ref_map_raw = getattr(args, 'ref_map', None)
    if _ref_map_raw:
        os.environ['VARAGENT_REF_MAP'] = _ref_map_raw
        print(f"\n[GUI] Ref map: индивидуальные рефы для {len(_json.loads(_ref_map_raw))} файлов")

    # Парсим --style-map (индивидуальные стили из GUI: {"audio.mp3": "/path/sg.txt"})
    _style_map_raw = getattr(args, 'style_map', None)
    style_map = {}
    if _style_map_raw:
        try:
            style_map = _json.loads(_style_map_raw)
            print(f"\n[GUI] Style map: {len(style_map)} audio->SG mapping(s) — пропускаем сканирование ready_to_go")
            for _a, _s in style_map.items():
                print(f"   {_a} -> {Path(_s).name}")
        except Exception as e:
            print(f"\n[WARN] Не удалось разобрать --style-map: {e}. Используем автопоиск.")
            style_map = {}

    # ПРОВЕРКА НА КОНФЛИКТ SG_ALL + ИНДИВИДУАЛЬНЫЕ
    # Пропускаем если стили переданы явно через GUI (--style или --style-map)
    sg_all_file = None
    use_sg_all = False
    if style_map or getattr(args, 'style', None):
        # Стили переданы явно из GUI — не лезем в ready_to_go
        pass
    else:
        print("\n" + "="*60)
        print("ПРОВЕРКА STYLE GUIDES")
        print("="*60)

        sg_all_file = get_sg_all_file(ready_dir)

        if sg_all_file:
            print(f"\n✅ SG_ALL найден: {sg_all_file.name}")

            # Проверяем есть ли индивидуальные
            individual_guides = []
            for audio_file in audio_files:
                guides = get_all_style_guides_for_audio(audio_file, ready_dir)
                individual_guides.extend(guides)

            if individual_guides:
                print(f"\n⚠️  НАЙДЕНЫ ИНДИВИДУАЛЬНЫЕ STYLE GUIDES!")
                print(f"   Количество: {len(individual_guides)}")
                for g in individual_guides:
                    print(f"   • {g.name}")

                print("\n" + "="*60)
                print("ВЫБЕРИТЕ ДЕЙСТВИЕ:")
                print("="*60)
                print("  1. Использовать SG_ALL для ВСЕХ аудио")
                print("  2. Использовать индивидуальные для каждого аудио")
                print("  3. Временно заморозить SG_ALL (переименовать в .bak)")
                print()

                try:
                    choice = input("Введите номер (1/2/3): ").strip()
                except EOFError:
                    choice = '2'
                    print(f"[non-interactive] auto-selected: 2 (individual style guides)")

                if choice == '1':
                    print(f"\n✅ Будет использован SG_ALL: {sg_all_file.name}")
                    use_sg_all = True
                elif choice == '2':
                    print(f"\n✅ Будут использованы индивидуальные style guides")
                    use_sg_all = False
                elif choice == '3':
                    # Переименовываем SG_ALL
                    bak_name = sg_all_file.name + '.bak'
                    sg_all_file.rename(sg_all_file.parent / bak_name)
                    print(f"\n✅ SG_ALL заморожен: {bak_name}")
                    use_sg_all = False
                else:
                    print(f"\n⚠️  Неверный выбор, используем SG_ALL по умолчанию")
                    use_sg_all = True
            else:
                print(f"\n✅ Индивидуальные style guides не найдены")
                use_sg_all = True
        else:
            print(f"\nℹ️  SG_ALL не найден, будут использованы индивидуальные style guides")
            use_sg_all = False

    # Обработка каждого файла
    print("\n" + "="*60)
    print("ОБРАБОТКА ПРОЕКТОВ")
    print("="*60)

    # Инициализация списка ошибок
    errors = []
    success_count = 0

    # Определяем нужно ли копировать аудио (если несколько style guides)
    copy_audio = False
    if not use_sg_all:
        # Проверяем есть ли несколько style guides для одного аудио
        for audio_file in audio_files:
            guides = get_all_style_guides_for_audio(audio_file, ready_dir)
            if len(guides) > 1:
                copy_audio = True
                break

    # Прогресс-бар для очереди
    for audio_file in tqdm(audio_files, desc="Обработка проектов", unit="проект"):
        try:
            # Определяем какой style guide использовать
            if style_map and audio_file.name in style_map:
                style_guide = Path(style_map[audio_file.name])  # индивидуальный из GUI
            elif getattr(args, 'style', None):
                style_guide = Path(args.style)  # один для всех из GUI
            elif use_sg_all and sg_all_file:
                style_guide = sg_all_file
            else:
                style_guide = None  # Будет найден автоматически по имени в ready_to_go
            
            # Настройка проекта
            project_info = setup_project(audio_file, ready_dir, projects_dir, concat_script, style_guide, copy_audio)

            # Удаление оригинала аудио из ready_to_go (только если проект создан успешно)
            if not copy_audio and audio_file.exists():
                try:
                    audio_file.unlink()
                    print(f"   [OK] Аудиофайл перемещён: {audio_file.name}")
                except Exception as e:
                    print(f"   [WARN] Не удалось удалить оригинал: {e}")

            print(f"\n[OK] Проект создан: {project_info['name']}")
            print(f"   Папка: {project_info['project_dir']}")

            # Запуск полного пайплайна сразу после создания проекта
            pipeline_ok = True
            if run_pipeline:
                audio_path = Path(project_info['audio_file'])
                style_path = Path(project_info['style_guide']) if project_info.get('style_guide') else None
                project_name = project_info['name']
                project_dir = Path(project_info['project_dir'])
                transcription_path = Path(project_info['transcription'])

                print(f"\n{'='*60}")
                print(f"ПАЙПЛАЙН: {project_name}")
                print(f"{'='*60}")

                if not style_path or not style_path.exists():
                    print(f"   [WARN] Style guide не найден, пайплайн пропущен")
                else:
                    _full_log_path = project_dir / f'{project_name}_full.log'
                    _full_log_fh = open(_full_log_path, 'w', encoding='utf-8', errors='replace')
                    _orig_stdout = sys.stdout
                    sys.stdout = _TeeStream(_orig_stdout, _full_log_fh)
                    try:
                        from_script = getattr(args, 'from_script', None)
                        script_type = getattr(args, 'script_type', 'prose')

                        if from_script:
                            # === Script mode: пропускаем TTS + транскрипцию ===
                            script_path = Path(from_script)
                            if not script_path.exists():
                                print(f"\n❌ Сценарий не найден: {script_path}")
                                pipeline_ok = False
                                continue
                            logging.info(f"Script mode: {script_path.name}, type={script_type}")
                            script_direct_project(
                                str(script_path),
                                str(style_path),
                                str(project_dir),
                                project_name,
                                script_type=script_type,
                                two_pass=getattr(args, 'two_pass', False),
                            )
                            logging.info(f"Script director завершен: {project_dir}")
                        else:
                            # === Обычный режим: транскрипция + режиссёр ===
                            logging.info(f"Запуск пайплайна: {audio_path.name}, язык: {language_code}")

                            # -- REF PREFLIGHT: compress refs in background while transcription runs --
                            import threading as _threading
                            _ref_dir_bg = project_dir / 'ref'
                            _ref_thread = None
                            if _ref_dir_bg.exists():
                                _ref_thread = _threading.Thread(
                                    target=compress_refs,
                                    args=(str(_ref_dir_bg),),
                                    kwargs={'max_mb': 1.5},
                                    daemon=True,
                                    name='ref-compress',
                                )
                                _ref_thread.start()
                                logging.info(f"ref_compress: background thread started for {_ref_dir_bg}")

                            transcription_result = transcribe_audio(str(audio_path), str(transcription_path), language_code=language_code)
                            logging.info(f"Транскрипция завершена: {transcription_path}")

                            if transcription_result.get('_quality_critical', False):
                                print(f"\n⛔ Транскрипция '{project_name}' аномальная!")
                                print("   Режиссёр НЕ запущен. Проверьте transcription.json.")
                                pipeline_ok = False
                                continue

                            direct_project(
                                str(transcription_path),
                                str(style_path),
                                str(project_dir),
                                project_name,
                                two_pass=getattr(args, 'two_pass', False)
                            )
                            logging.info(f"Режиссерский анализ завершен: {project_dir}")
                        print(f"\n[OK] Пайплайн завершён: {project_name}")

                        # Join ref-compress background thread before generation uses the refs
                        if '_ref_thread' in dir() and _ref_thread and _ref_thread.is_alive():
                            logging.info("ref_compress: waiting for background thread...")
                            _ref_thread.join(timeout=120)

                        # Пост-пайплайн генерация: silent если передан --post-action, иначе интерактивно
                        post_action = getattr(args, 'post_action', None)
                        prompt_mode = getattr(args, 'prompt_mode', 'single')
                        yt_pack = getattr(args, 'yt_pack', False)
                        if post_action:
                            _run_post_pipeline_silent(str(project_dir), post_action, prompt_mode, run_yt_pack=yt_pack)
                        else:
                            if sys.stdin.isatty():
                                _ask_post_pipeline_action(str(project_dir))
                            if yt_pack:
                                _run_post_pipeline_silent(str(project_dir), 'skip', run_yt_pack=True)

                        # Сигнал для GUI: все этапы завершены, можно запускать конкат
                        print(f"PROJECT_DONE: {project_dir}", flush=True)

                        # Предложить запуск YT Packer (только в терминале, только если не было --post-action и не было --yt-pack)
                        if not post_action and not yt_pack and sys.stdin.isatty():
                            _ask_yt_packer(str(project_dir), source_lang=language_code)
                    except Exception as pipeline_err:
                        print(f"\n[ERROR] Ошибка пайплайна для {project_name}: {pipeline_err}")
                        logging.debug(traceback.format_exc())
                        pipeline_ok = False
                        errors.append({
                            'file': project_name,
                            'error': str(pipeline_err),
                            'traceback': traceback.format_exc()
                        })
                    finally:
                        sys.stdout = _orig_stdout
                        _full_log_fh.close()

            if pipeline_ok:
                success_count += 1

        except Exception as e:
            error_msg = f"Ошибка при создании проекта {audio_file.name}: {e}"
            print(f"\n[ERROR] {error_msg}")
            logging.debug(traceback.format_exc())

            # Сохраняем ошибку в список
            errors.append({
                'file': audio_file.name,
                'error': str(e),
                'traceback': traceback.format_exc()
            })
            continue

    # Сохранение отчёта об ошибках
    if errors:
        error_report_path = base_dir / 'errors.json'
        with open(error_report_path, 'w', encoding='utf-8', errors='replace') as f:
            json.dump({
                'timestamp': datetime.now().isoformat(),
                'total_projects': len(audio_files),
                'successful': success_count,
                'failed': len(errors),
                'error_rate': len(errors) / len(audio_files),
                'errors': errors
            }, f, indent=2, ensure_ascii=False)
        
        print(f"\n⚠️  Отчёт об ошибках сохранён: {error_report_path}")

    # Итог
    print("\n" + "="*60)
    print("[OK] ОБРАБОТКА ОЧЕРЕДИ ЗАВЕРШЕНА!")
    print("="*60)

    if run_pipeline:
        print(f"""
Обработано проектов: {success_count} из {len(audio_files)}
Успешно: {success_count}
Ошибки: {len(errors)}

Папка проектов: {projects_dir}
""")
        if success_count > 0:
            print("СЛЕДУЮЩИЙ ШАГ:")
            print("   Открой prompts_*.txt в папке проекта и генерируй видео в Veo3.")
            print("   Затем положи видеофрагменты в папку проекта и запусти process_fast.bat")
        if errors:
            print("\nОШИБКИ (проекты, требующие повторного запуска):")
            for err in errors:
                proj = err.get('project', '?')
                msg  = err.get('error', '?')
                print(f"   [{proj}] {msg}")
            print()
            print("КАК ПОВТОРИТЬ режиссуру без повторной транскрипции:")
            print("   python agent/agent.py direct \\")
            print("     --transcription projects/<PROJECT>/transcription.json \\")
            print("     --style ready_to_go/<STYLE>.txt \\")
            print("     --project <PROJECT>")
        print()
    else:
        print(f"""
Создано проектов: {success_count} из {len(audio_files)}
Успешно: {success_count}
Ошибки: {len(errors)}

Папка проектов: {projects_dir}

СЛЕДУЮЩИЕ ШАГИ:
   Запустите полный пайплайн:
      python agent.py process --run
   Или для отдельного проекта:
      python agent.py run --audio projects/PROJECT_NAME/audio.mp3 --style style_guide.txt --project PROJECT_NAME
""")


# ============================================================================
# DRY-RUN
# ============================================================================

def cmd_dry_run(args):
    """Тестовый прогон: проверка компонентов + mock-симуляция пайплайна без API вызовов."""
    import shutil
    import importlib
    import time
    import random

    GREEN   = '\033[92m'
    RED     = '\033[91m'
    YELLOW  = '\033[93m'
    CYAN    = '\033[96m'
    MAGENTA = '\033[95m'
    DIM     = '\033[2m'
    RESET   = '\033[0m'
    BOLD    = '\033[1m'

    OK   = f"{GREEN}[OK]{RESET}"
    FAIL = f"{RED}[FAIL]{RESET}"
    WARN = f"{YELLOW}[WARN]{RESET}"
    MOCK = f"{MAGENTA}[MOCK]{RESET}"

    agent_dir = Path(__file__).parent
    root_dir  = agent_dir.parent
    rtg_dir   = root_dir / 'ready_to_go'

    def sep(title=''):
        if title:
            print(f"\n{BOLD}── {title} {'─'*(50-len(title))}{RESET}")
        else:
            print(f"{DIM}{'─'*60}{RESET}")

    def step(msg, sym=None):
        s = sym or MOCK
        print(f"  {s}  {msg}")

    # ═══════════════════════════════════════════════
    # БЛОК 1: ПРОВЕРКА КОМПОНЕНТОВ
    # ═══════════════════════════════════════════════
    print()
    print(f"{BOLD}{'='*60}{RESET}")
    print(f"{BOLD}  DRY-RUN  (0 API calls){RESET}")
    print(f"{BOLD}{'='*60}{RESET}")

    sep("COMPONENTS CHECK")
    results = []

    def check(label, passed, detail=''):
        sym = OK if passed else FAIL
        line = f"  {sym}  {label}"
        if detail:
            line += f"  {DIM}{detail}{RESET}"
        print(line)
        results.append(passed)
        return passed

    # Модули
    for mod_name, label in [
        ('modules.transcriber',   'transcriber'),
        ('modules.director',      'director'),
        ('modules.fastgen',       'fastgen'),
        ('modules.imggen',        'imggen'),
        ('modules.veo_video',     'veo_video'),
        ('modules.yt_packer',     'yt_packer'),
    ]:
        try:
            importlib.import_module(mod_name)
            check(label, True)
        except Exception as e:
            check(label, False, str(e))

    # API ключи
    ffmpeg_path = shutil.which('ffmpeg')
    check('ffmpeg',            bool(ffmpeg_path),              ffmpeg_path or 'NOT IN PATH')
    check('ASSEMBLYAI_API_KEY', bool(config.ASSEMBLYAI_API_KEY), 'SET' if config.ASSEMBLYAI_API_KEY else 'MISSING')
    check('GEMINI_API_KEY',     bool(config.GEMINI_API_KEY),     'SET' if config.GEMINI_API_KEY     else 'MISSING')
    check('FASTGEN_API_KEY',    bool(config.FASTGEN_API_KEY),    'SET' if config.FASTGEN_API_KEY    else 'MISSING')
    check('VEONONSTOP_API_KEY', bool(config.VEONONSTOP_API_KEY), 'SET' if config.VEONONSTOP_API_KEY else 'MISSING')

    all_ok = all(results)
    print()
    if not all_ok:
        print(f"  {FAIL}  Component check failed — fix before pipeline run.")
        print()
        return

    print(f"  {OK}  All components ready.")

    if not getattr(args, 'mock', False):
        # Без --mock: только проверка компонентов
        sep("PIPELINE CHAIN")
        stages = [
            ('TTS (optional)',           True),
            ('Stage 1  Transcription',   bool(config.ASSEMBLYAI_API_KEY)),
            ('Stage 2  Direction',       bool(config.GEMINI_API_KEY)),
            ('Stage 3  Image gen',       bool(config.FASTGEN_API_KEY) or bool(config.VEONONSTOP_API_KEY)),
            ('Stage 3.5  Video gen',     bool(config.VEONONSTOP_API_KEY)),
            ('Stage 4  Concat (ffmpeg)', bool(ffmpeg_path)),
            ('Stage 5  YT Pack',         True),
        ]
        for i, (label, ready) in enumerate(stages):
            arrow = ' →' if i < len(stages) - 1 else ''
            print(f"  {OK if ready else WARN}  {label}{arrow}")
        print()
        print(f"{BOLD}{'='*60}{RESET}")
        print(f"  {GREEN}{BOLD}Pipeline ready.{RESET}  Run with --mock for full simulation.")
        print(f"{BOLD}{'='*60}{RESET}")
        print()
        return

    # ═══════════════════════════════════════════════
    # БЛОК 2: MOCK PIPELINE SIMULATION
    # ═══════════════════════════════════════════════
    sep("MOCK PIPELINE SIMULATION")
    print(f"  {DIM}No API calls. Simulating pipeline flow with fake data.{RESET}")

    # Найти аудио в ready_to_go
    audio_files = list(rtg_dir.glob('*.mp3')) + list(rtg_dir.glob('*.wav'))
    style_files = list(rtg_dir.glob('*.txt'))

    if audio_files:
        audio = audio_files[0]
        size_mb = audio.stat().st_size / 1_048_576
        est_min = max(1, round(size_mb / 1.5))
        audio_name = audio.stem
    else:
        audio_name = 'sample_audio'
        est_min = 5

    clip_avg = (config.VIDEO_CLIP_MIN_DURATION + config.VIDEO_CLIP_MAX_DURATION) / 2
    est_clips = max(5, round(est_min * 60 / clip_avg))
    project_name = f"FLOW_{audio_name}_{datetime.now().strftime('%d%m%y_%H%M')}"

    # CONFIG SUMMARY
    two_pass = config.GEMINI_TWO_PASS
    veo_par  = config.VEONONSTOP_MAX_PARALLEL
    fg_par   = config.FASTGEN_MAX_PARALLEL
    ratio    = config.VEONONSTOP_ASPECT_RATIO

    print()
    print(f"  {DIM}Config:  lang={config.ASSEMBLYAI_LANGUAGE_CODE}  model={config.GEMINI_MODEL}")
    print(f"           two-pass={two_pass}  clips={config.VIDEO_CLIP_MIN_DURATION}-{config.VIDEO_CLIP_MAX_DURATION}s  ratio={ratio}")
    print(f"           fastgen.parallel={fg_par}  veo.parallel={veo_par}{RESET}")

    # ── STAGE 0: TTS (skip) ──
    sep("Stage 0  TTS")
    step(f"audio found in ready_to_go/: {audio.name if audio_files else '[none]'}")
    if audio_files:
        step(f"TTS skipped — audio already present", OK)
    else:
        step(f"Would run TTS: script.txt → audio.mp3", MOCK)

    # ── STAGE 1: QUEUE + TRANSCRIPTION ──
    sep("Stage 1  Queue + Transcription (AssemblyAI)")
    step(f"Queue: ready_to_go/{audio_name}.*  →  projects/{project_name}/")
    step(f"Transcription: {audio_name}  (~{est_min} min audio)")
    step(f"  ← {est_min*8} segments, lang={config.ASSEMBLYAI_LANGUAGE_CODE}  [mock]")
    step(f"  → transcription.json", OK)

    # ── STAGE 2: DIRECTION ──
    sep("Stage 2  Direction (Gemini)")
    step(f"Model: {config.GEMINI_MODEL}  two-pass={two_pass}")
    if two_pass:
        step(f"Pass 1: JSON plan  →  {est_clips} clips planned")
        step(f"Pass 2: prompts    →  {est_clips} prompts generated (chunked)")
    else:
        step(f"Single pass: plan + prompts  →  {est_clips} clips")
    step(f"  → montage_plan.json  +  *_prompts_*.txt", OK)

    # ── STAGE 3: IMAGE GEN ──
    sep("Stage 3  Image generation (FastGen)")
    step(f"FastGen {config.FASTGEN_MODEL}  parallel={fg_par}  aspect={config.FASTGEN_ASPECT_RATIO}")
    step(f"  {est_clips} images  ({est_clips} prompts from prompts.txt)")
    step(f"  batches: {(est_clips + fg_par - 1) // fg_par} × {fg_par} workers")
    step(f"  est. time: ~{round(est_clips / fg_par * 8)}s  (mock: skipped)", MOCK)
    step(f"  → generated/{'{001..%03d}' % est_clips}.png", OK)

    # ── STAGE 3.5: VIDEO GEN ──
    sep("Stage 3.5  Video generation (VeoNonStop i2v)")
    submit_slots = max(1, veo_par // 3)
    step(f"i2v  ratio={ratio}  parallel={veo_par}  submit_semaphore={submit_slots}")
    step(f"  {est_clips} clips  (images from generated/)")
    step(f"  est. time: ~{round(est_clips / veo_par * 75 / 60)}m  @75s/clip  (mock: skipped)", MOCK)
    step(f"  → vid_img/{'{001..%03d}' % est_clips}.mp4", OK)

    # ── STAGE 4: CONCAT ──
    sep("Stage 4  Concat (video_concat.py + FFmpeg)")
    total_s = round(est_clips * clip_avg)
    step(f"Input: {est_clips} fragments  +  montage_plan.json")
    step(f"Retiming → concat → final trim  (~{total_s}s = {total_s//60}:{total_s%60:02d} min)")
    step(f"  → projects/{project_name}/{project_name}.mp4", OK)

    # ── STAGE 5: YT PACK ──
    sep("Stage 5  YT Pack")
    langs = getattr(config, 'YT_PACK_LANGUAGES', [config.ASSEMBLYAI_LANGUAGE_CODE])
    step(f"Languages: {' + '.join(str(l) for l in langs[:3])}")
    step(f"  → subtitles (.srt)  description  tags  cover prompts", OK)

    # ── SUMMARY ──
    sep("SUMMARY")
    cost_ai   = round(est_min * 0.007, 2)
    cost_gem  = round(est_clips * 0.002, 2)
    cost_fg   = round(est_clips * 0.015, 2)
    cost_veo  = round(est_clips * 0.05,  2)
    cost_tot  = round(cost_ai + cost_gem + cost_fg + cost_veo, 2)
    time_img  = round(est_clips / fg_par * 8)
    time_vid  = round(est_clips / veo_par * 75)

    print(f"\n  Project:   {project_name}")
    print(f"  Audio:     {audio_name}  (~{est_min} min)")
    print(f"  Clips:     {est_clips}")
    print(f"  Est. time: ~{time_img}s image gen  +  ~{time_vid//60}m video gen  +  ~3m concat")
    print(f"  Est. cost: AssemblyAI ~${cost_ai}  Gemini ~${cost_gem}  FastGen ~${cost_fg}  VeoNon ~${cost_veo}")
    print(f"             Total ~${cost_tot}")
    print()
    print(f"{BOLD}{'='*60}{RESET}")
    print(f"  {GREEN}{BOLD}Mock run complete. 0 API calls made.{RESET}")
    print(f"{BOLD}{'='*60}{RESET}")
    print()


# ============================================================================
# CLI ИНТЕРФЕЙС
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description='Video Production Agent - Автоматизация создания видео',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Примеры использования:
  agent run --audio narration.wav --style style_guide.txt --project "My Video"
  agent transcribe --audio narration.wav
  agent direct --transcription transcription.json --style style_guide.txt
  agent validate --all
  agent status
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Команды')
    
    # Команда: run (полный пайплайн)
    parser_run = subparsers.add_parser('run', help='Полный пайплайн (этапы 1-2)')
    parser_run.add_argument('--audio', required=True, help='Путь к аудиофайлу')
    parser_run.add_argument('--style', required=True, help='Путь к style_guide.txt')
    parser_run.add_argument('--project', default='Untitled', help='Название проекта')
    parser_run.add_argument('--language', choices=config.ASSEMBLYAI_SUPPORTED_LANGUAGES,
                           default=None, help='Язык аудио (по умолчанию из .env)')
    parser_run.add_argument('--model', type=str, default=None, help='Модель Gemini (например gemini-3.0-pro)')
    parser_run.add_argument('--director-analysis', action='store_true', default=None,
                           help='Генерировать director_analysis.md (переопределяет .env)')
    parser_run.add_argument('--force', action='store_true', help='Запустить режиссёра даже при аномальной транскрипции')
    parser_run.add_argument('--with-images', action='store_true', default=False,
                           help='Run FastGen image generation (stage 3) after director')
    parser_run.set_defaults(func=cmd_run)

    # Команда: transcribe
    parser_transcribe = subparsers.add_parser('transcribe', help='Транскрипция аудио')
    parser_transcribe.add_argument('--audio', required=True, help='Путь к аудиофайлу')
    parser_transcribe.add_argument('--output', help='Путь для transcription.json')
    parser_transcribe.add_argument('--language', choices=config.ASSEMBLYAI_SUPPORTED_LANGUAGES,
                                  default=None, help='Язык аудио (по умолчанию из .env)')
    parser_transcribe.set_defaults(func=cmd_transcribe)

    # Команда: direct
    parser_direct = subparsers.add_parser('direct', help='Режиссерский анализ')
    parser_direct.add_argument('--transcription', required=True, help='Путь к transcription.json')
    parser_direct.add_argument('--style', required=True, help='Путь к style_guide.txt')
    parser_direct.add_argument('--output', help='Директория для результатов')
    parser_direct.add_argument('--project', default='Untitled', help='Название проекта')
    parser_direct.add_argument('--force', action='store_true', help='Пропустить валидацию')
    parser_direct.add_argument('--model', type=str, default=None, help='Модель Gemini (например gemini-3.0-pro)')
    parser_direct.add_argument('--director-analysis', action='store_true', default=None,
                              help='Генерировать director_analysis.md (переопределяет .env)')
    parser_direct.add_argument('--two-pass', action='store_true', default=False,
                              help='Двухпроходный режим: проход 1 = JSON план, проход 2 = промпты (для проектов > 15 мин)')
    parser_direct.add_argument('--prompts-only', action='store_true', default=False,
                              help='Только проход 2: читает готовый montage_plan.json и генерирует промпты')
    parser_direct.add_argument('--resume', action='store_true', default=False,
                              help='Продолжить запись промптов с места остановки (только с --prompts-only)')
    parser_direct.set_defaults(func=cmd_direct)
    
    # Команда: validate
    parser_validate = subparsers.add_parser('validate', help='Валидация файлов')
    parser_validate.add_argument('--transcription', help='Путь к transcription.json')
    parser_validate.add_argument('--montage-plan', help='Путь к montage_plan.json')
    parser_validate.add_argument('--all', action='store_true', help='Валидировать все JSON')
    parser_validate.add_argument('--dir', help='Директория для сканирования')
    parser_validate.set_defaults(func=cmd_validate)
    
    # Команда: status
    parser_status = subparsers.add_parser('status', help='Статус проекта')
    parser_status.add_argument('--dir', default='.', help='Директория проекта')
    parser_status.set_defaults(func=cmd_status)
    
    # Команда: cost-estimate
    parser_cost = subparsers.add_parser('cost-estimate', help='Оценка стоимости API')
    parser_cost.add_argument('--duration', type=int, default=30, help='Длительность аудио в минутах (по умолчанию 30)')
    parser_cost.add_argument('--language', choices=config.ASSEMBLYAI_SUPPORTED_LANGUAGES,
                            default='ru', help='Язык аудио (влияет на токенизацию, по умолчанию ru)')
    parser_cost.set_defaults(func=cmd_cost_estimate)
    
    # Команда: generate (генерация изображений — FastGen или VeoNonStop)
    parser_generate = subparsers.add_parser('generate', help='Image generation (stage 3) — FastGen / VeoNonStop')
    parser_generate.add_argument('--project', required=True, help='Project folder name (in projects/)')
    parser_generate.add_argument('--ids', type=str, default=None,
                                 help='Comma-separated clip IDs (e.g., 1,2,3). Default: all')
    parser_generate.add_argument('--parallel', type=int, default=None,
                                 help=f'Max parallel generations (default: {config.FASTGEN_MAX_PARALLEL})')
    parser_generate.add_argument('--mode', choices=['flow', 'whisk'], default=None,
                                 help='Reference mode: flow (flat refs) or whisk (categorized). Auto-detected if not set')
    parser_generate.add_argument('--model', type=str, default=None,
                                 help=f'FastGen model (default: {config.FASTGEN_MODEL})')
    parser_generate.add_argument('--aspect', type=str, default=None,
                                 help=f'Aspect ratio (default: {config.FASTGEN_ASPECT_RATIO})')
    parser_generate.add_argument('--backup-key', action='store_true', default=False,
                                 help='Use FASTGEN_API_KEY_BACKUP instead of main key')
    parser_generate.add_argument('--image-gen', choices=['fastgen', 'imagen', 'banana', 'banana_ref', 'banana2', 'banana2_ref'],
                                 default=None,
                                 help='Image generator: fastgen (default), imagen, banana, banana_ref')
    parser_generate.add_argument('--no-preflight', action='store_true', default=False,
                                 help='Skip preflight ref test (banana_ref mode only)')
    parser_generate.add_argument('--key-slot', choices=['1', '2', '3', '4', 'both', 'all'], default='1',
                                 help='Key slot: 1-4=specific key, both/all=all configured keys in parallel')
    parser_generate.set_defaults(func=cmd_generate)

    # Команда: img2video (генерация видео через VeoNonStop)
    parser_i2v = subparsers.add_parser('img2video', help='Video generation via VeoNonStop API (stage 3.5)')
    parser_i2v.add_argument('--project', required=True, help='Project folder name (in projects/)')
    parser_i2v.add_argument('--mode', choices=['i2v', 't2v', 'components'], default=None,
                            help='Mode: i2v (image-to-video), t2v (text-to-video), components (t2v + refs)')
    parser_i2v.add_argument('--ids', type=str, default=None,
                            help='Comma-separated clip IDs (e.g., 1,2,3). Default: all')
    parser_i2v.add_argument('--parallel', type=int, default=None,
                            help=f'Max parallel tasks (default: {config.VEONONSTOP_MAX_PARALLEL})')
    parser_i2v.add_argument('--ratio', type=str, default=None,
                            help=f'Aspect ratio: 16:9, 9:16, 1:1 (default: {config.VEONONSTOP_ASPECT_RATIO})')
    parser_i2v.add_argument('--prompt', type=str, default=None,
                            help='Single prompt for all clips (overrides per-clip prompts)')
    parser_i2v.add_argument('--prompt-file', type=str, default=None,
                            help='Path to file with single prompt (UTF-8). Overrides --prompt.')
    parser_i2v.add_argument('--key-slot', choices=['1', '2', '3', '4', 'both', 'all'], default='1',
                            help='Key slot: 1-4=specific key, both/all=all configured keys in parallel')
    parser_i2v.add_argument('--ref-dir', type=str, default=None,
                            help='Reference images directory (for components mode, default: PROJECT/ref/)')
    parser_i2v.add_argument('--no-cancel', action='store_true', default=False,
                            help='Skip cancel-all-tasks on startup (use when another generation runs in parallel)')
    parser_i2v.set_defaults(func=cmd_img2video)

    # Команда: yt-pack (YouTube-упаковщик)
    parser_ytpack = subparsers.add_parser('yt-pack', help='YT Packer — субтитры, описание, обложки (stage 5)')
    parser_ytpack.add_argument('--project', required=True, help='Название папки проекта (в projects/)')
    parser_ytpack.add_argument('--source-lang', default=None,
                                help='Язык транскрипции (ru, en, ...). Если не указан — читается из transcription.json')
    parser_ytpack.add_argument('--interactive', action='store_true', default=False,
                                help='Спросить каждый параметр интерактивно перед запуском')
    parser_ytpack.set_defaults(func=cmd_yt_pack)

    # Команда: process (обработка очереди)
    parser_process = subparsers.add_parser('process', help='Обработка очереди из ready_to_go')
    parser_process.add_argument('--style', default=None, metavar='FILE',
                                help='Явный style guide для всех аудио (передаётся из GUI, обходит автопоиск из ready_to_go)')
    parser_process.add_argument('--style-map', default=None, metavar='JSON',
                                help='JSON-маппинг {"audio.mp3": "/path/sg.txt"} для индивидуальных style guides (из GUI)')
    parser_process.add_argument('--file-list', default=None, metavar='JSON',
                                help='JSON-массив путей к аудиофайлам (из GUI, сохраняет порядок загрузки)')
    parser_process.add_argument('--queue-dir', default=None, metavar='DIR',
                                help='Папка очереди (из GUI: pipeline_queue/ вместо ready_to_go/)')
    parser_process.add_argument('--ref-map', default=None, metavar='JSON',
                                help='JSON-маппинг {"audio.wav": "/path/staging/"} индивидуальных рефов (из GUI)')
    parser_process.add_argument('--run', action='store_true',
                                help='Запустить полный пайплайн (транскрипция + режиссура) сразу после настройки каждого проекта')
    parser_process.add_argument('--two-pass', action='store_true', default=False,
                                help='Двухпроходный режим для режиссуры (для проектов > 15 мин)')
    parser_process.add_argument('--language', choices=config.ASSEMBLYAI_SUPPORTED_LANGUAGES,
                                default=None, help='Язык озвучки (default: из .env ASSEMBLYAI_LANGUAGE_CODE)')
    parser_process.add_argument('--clip-mode', choices=['video', 'slideshow'], default=None,
                                help='Тип клипов: video (Veo3, 4-8с) или slideshow (картинки, 2-7с). Если не указан — спрашивает интерактивно.')
    parser_process.add_argument('--clip-min', type=int, default=None,
                                help='Минимальная длительность клипа (сек, переопределяет .env)')
    parser_process.add_argument('--clip-max', type=int, default=None,
                                help='Максимальная длительность клипа (сек, переопределяет .env)')
    parser_process.add_argument('--post-action',
                                choices=['skip', 'fastgen', 'fastgen_i2v', 'veo_i2v', 't2v', 'i2v', 'components'],
                                default=None,
                                help='Post-pipeline generation (silent mode): skip/fastgen/fastgen_i2v/veo_i2v/t2v/i2v/components')
    parser_process.add_argument('--prompt-mode',
                                choices=['single', 'perclip'],
                                default='single',
                                help='Prompt mode for i2v: single (one prompt for all) or perclip (original prompts from prompts.txt)')
    parser_process.add_argument('--from-script', metavar='FILE', default=None,
                                help='Script file (.txt) — skip TTS+transcription, use GeminiScriptDirector instead')
    parser_process.add_argument('--script-type', choices=['prose', 'screenplay'], default='prose',
                                help='Script type: prose (default) or screenplay')
    parser_process.add_argument('--yt-pack', action='store_true', default=False,
                                help='Run YT Packer (subtitles, description, covers) after all stages')
    parser_process.set_defaults(func=cmd_process_queue)

    # Команда: script (режиссура из текстового сценария)
    parser_script = subparsers.add_parser('script', help='Script Director — режиссура из текстового сценария (без аудио)')
    parser_script.add_argument('--script', required=True, metavar='FILE', help='Путь к текстовому сценарию (.txt)')
    parser_script.add_argument('--style',  required=True, metavar='FILE', help='Путь к style_guide.txt')
    parser_script.add_argument('--project', default=None, help='Название проекта (по умолчанию — имя файла сценария)')
    parser_script.add_argument('--output', default=None, help='Папка вывода (по умолчанию: рядом со сценарием)')
    parser_script.add_argument('--script-type', choices=['prose', 'screenplay'], default='prose',
                                help='Тип сценария: prose (проза, по умолчанию) или screenplay')
    parser_script.add_argument('--two-pass', action='store_true', default=False,
                                help='Двухпроходный режим (Pass 1 = JSON план, Pass 2 = промпты)')
    parser_script.add_argument('--clip-mode', choices=['video', 'slideshow'], default=None)
    parser_script.add_argument('--clip-min', type=int, default=None)
    parser_script.add_argument('--clip-max', type=int, default=None)
    parser_script.add_argument('--post-action',
                                choices=['skip', 'fastgen', 'fastgen_i2v', 'veo_i2v', 't2v', 'i2v', 'components'],
                                default=None)
    parser_script.add_argument('--yt-pack', action='store_true', default=False,
                                help='Run YT Packer after all stages')
    parser_script.set_defaults(func=cmd_script_direct)

    parser_dryrun = subparsers.add_parser('dry-run', help='Тестовый прогон — проверка компонентов + mock-симуляция пайплайна')
    parser_dryrun.add_argument('--mock', action='store_true', default=False,
                               help='Симулировать полный пайплайн с фейковыми данными (0 API вызовов)')
    parser_dryrun.set_defaults(func=cmd_dry_run)

    args = parser.parse_args()
    
    if args.command is None:
        parser.print_help()
        sys.exit(0)
    
    args.func(args)


if __name__ == '__main__':
    main()
