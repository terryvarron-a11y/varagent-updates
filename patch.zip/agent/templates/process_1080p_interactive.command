#!/bin/bash
# PROCESS_1080P_INTERACTIVE.COMMAND - Video concat 1080p interactive (macOS - double click)
# Run: double-click this file in Finder

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Auto-set execute permissions
chmod +x *.command *.sh 2>/dev/null
[ -f "$SCRIPT_DIR/.venv/bin/activate" ] && source "$SCRIPT_DIR/.venv/bin/activate"

# Open Terminal.app for interactive mode
if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e "tell app \"Terminal\" to do script \"cd '$SCRIPT_DIR' && exec '$0'\""
    exit 0
fi

clear

echo ""
echo "================================================================================"
echo "CONCAT 1080p (with re-encoding) - INTERACTIVE"
echo "================================================================================"
echo ""

# Check montage_plan.json
if [ ! -f "montage_plan.json" ]; then
    echo "[ERROR] montage_plan.json not found!"
    echo "Press Enter to exit..."
    read
    exit 1
fi

# Find audio file
AUDIO_FILE=""
for EXT in wav mp3 flac m4a aac; do
    for F in *.$EXT; do
        [ -f "$F" ] && AUDIO_FILE="$F" && break 2
    done
done

if [ -z "$AUDIO_FILE" ]; then
    echo "[ERROR] Audio file not found!"
    echo "   Put .wav, .mp3, .flac, .m4a or .aac in the project folder"
    echo "Press Enter to exit..."
    read
    exit 1
fi
echo "   Audio found: $AUDIO_FILE"

# ============================================================================
# STEP 1: RENAME VIDEO FRAGMENTS
# ============================================================================

echo ""
echo "[1/4] Renaming video fragments..."
echo ""

if [ -f "rename_videos.py" ]; then
    python3 rename_videos.py --dir vid_img
    if [ $? -ne 0 ]; then
        echo "[ERROR] Rename failed!"
        echo "Press Enter to exit..."
        read
        exit 1
    fi
else
    echo "   [WARN] rename_videos.py not found, skipping..."
fi

# ============================================================================
# STEP 2: CHECK FRAGMENTS
# ============================================================================

echo ""
echo "[2/4] Checking fragments..."
echo ""

if [ -f "check_fragments.command" ]; then
    bash check_fragments.command
    if [ $? -ne 0 ]; then
        MISSING=""
        [ -f "missing_fragments.txt" ] && MISSING=$(cat missing_fragments.txt)
        echo "   Missing fragments: $MISSING"
        echo ""
        echo "================================================================================"
        echo "  What to do with missing fragments?"
        echo "    [1] Show prompts (generate in Veo3)"
        echo "    [2] Copy images from generated/ to vid_img/ (still-frame substitute)"
        echo "================================================================================"
        echo ""
        printf "  Your choice [1/2] (Enter = 1): "
        read FRAG_CHOICE
        FRAG_CHOICE="${FRAG_CHOICE:-1}"
        echo ""

        if [ "$FRAG_CHOICE" = "2" ]; then
            echo "  Copying images from generated/ to vid_img/..."
            echo ""
            python3 copy_images_to_vid.py
            if [ $? -ne 0 ]; then
                echo ""
                echo "[WARN] Some images not found in generated/. See output above."
                echo "Press Enter to exit..."
                read
                exit 1
            fi
            echo ""
            echo "  Re-checking fragments..."
            if [ -f "check_fragments.command" ]; then
                bash check_fragments.command
                if [ $? -ne 0 ]; then
                    echo ""
                    echo "[WARN] Still missing fragments after copy. See output above."
                    echo "Press Enter to exit..."
                    read
                    exit 1
                fi
            fi
            echo "  All fragments in place. Continuing..."
        else
            echo ""
            echo "================================================================================"
            echo "PROMPTS FOR MISSING FRAGMENTS"
            echo "================================================================================"
            echo ""
            echo "  Copy these prompts to Veo3 to generate missing fragments"
            echo ""

            if [ -n "$MISSING" ] && [ -f "extract_prompt.py" ]; then
                for ID in $MISSING; do
                    echo "================================================================================"
                    echo "FRAGMENT #$ID (MISSING)"
                    echo "================================================================================"
                    echo ""
                    python3 extract_prompt.py "$ID"
                    echo ""
                done
            else
                echo "[WARN] extract_prompt.py not found, open *_prompts_*.txt manually"
            fi

            echo ""
            echo "NEXT STEPS:"
            echo "   1. Copy prompts above"
            echo "   2. Generate missing fragments in Veo3"
            echo "   3. Download files to vid_img/"
            echo "   4. Run process_1080p_interactive.command again"
            echo ""
            echo "Press Enter to exit..."
            read
            exit 1
        fi
    fi
else
    echo "   [WARN] check_fragments.command not found, skipping check..."
fi

# ============================================================================
# STEP 2.5: FFPROBE INTEGRITY CHECK (parallel background jobs)
# ============================================================================

echo ""
echo "[2.5/4] Validating fragment integrity (ffprobe)..."
echo ""

TMPD=$(mktemp -d)
PIDS=()
MAX_JOBS=8

for F in vid_img/*.mp4; do
    [ -f "$F" ] || continue
    STEM=$(basename "$F" .mp4)
    (
        if ffprobe -v error "$F" 2>"$TMPD/$STEM.err"; then
            echo ok > "$TMPD/$STEM.status"
        else
            echo broken > "$TMPD/$STEM.status"
        fi
    ) &
    PIDS+=($!)
    if [ ${#PIDS[@]} -ge $MAX_JOBS ]; then
        wait "${PIDS[@]}"
        PIDS=()
    fi
done
[ ${#PIDS[@]} -gt 0 ] && wait "${PIDS[@]}"

BROKEN_IDS=""
BROKEN_COUNT=0
TOTAL=0
for STATF in "$TMPD"/*.status; do
    [ -f "$STATF" ] || continue
    TOTAL=$((TOTAL + 1))
    if [ "$(cat "$STATF")" = "broken" ]; then
        STEM=$(basename "$STATF" .status)
        ID=$(echo "$STEM" | sed 's/^0*//' | tr -d '[:space:]')
        [ -z "$ID" ] && ID=0
        ERR=$(head -1 "$TMPD/$STEM.err" 2>/dev/null)
        echo "   [BROKEN] #$ID — $ERR"
        BROKEN_IDS="$BROKEN_IDS $ID"
        BROKEN_COUNT=$((BROKEN_COUNT + 1))
    fi
done
rm -rf "$TMPD"

if [ $BROKEN_COUNT -gt 0 ]; then
    echo ""
    echo "========================================================================"
    echo "[ERROR] Broken fragments ($BROKEN_COUNT):$BROKEN_IDS"
    echo "========================================================================"
    echo ""
    echo "  What to do with broken fragments?"
    echo "    [1] Show prompts (regenerate in Veo3)"
    echo "    [2] Copy images from generated/ as still-frame (fast fallback)"
    echo ""
    printf "  Your choice [1/2] (Enter = 1): "
    read BRK_CHOICE
    BRK_CHOICE="${BRK_CHOICE:-1}"
    echo ""

    if [ "$BRK_CHOICE" = "2" ]; then
        echo "  Deleting broken mp4s and copying images..."
        echo ""
        for ID in $BROKEN_IDS; do
            PADDED=$(printf "%04d" $ID)
            [ -f "vid_img/$PADDED.mp4" ] && rm "vid_img/$PADDED.mp4" && echo "  del $PADDED.mp4"
        done
        echo "${BROKEN_IDS## }" > missing_fragments.txt
        if [ -f "copy_images_to_vid.py" ]; then
            python3 copy_images_to_vid.py
            if [ $? -ne 0 ]; then
                echo ""
                echo "[WARN] Some images not found in generated/. See output above."
                echo "Press Enter to exit..."
                read
                exit 1
            fi
        else
            echo "[WARN] copy_images_to_vid.py not found."
            echo "Press Enter to exit..."
            read
            exit 1
        fi
        rm -f missing_fragments.txt
        echo ""
        echo "  All copied. Continuing assembly..."
    else
        if [ -f "extract_prompt.py" ]; then
            for ID in $BROKEN_IDS; do
                echo "=== FRAGMENT #$ID ==="
                python3 extract_prompt.py "$ID"
                echo ""
            done
        fi
        echo "Press Enter to exit..."
        read
        exit 1
    fi
fi
echo "   [OK] All $TOTAL fragments valid"

# ============================================================================
# STEP 3: CONCAT 1080p
# ============================================================================

echo ""
echo "[3/4] Concat video (1080p, 20Mbps, re-encoding)..."
echo ""

SUB_TEMPLATE=""
SCRIPT_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
_FOUND=$(find "$SCRIPT_ROOT/agent/templates" -maxdepth 1 -name "*1080p*.ass" 2>/dev/null | sort | head -1)

if [ -n "$_FOUND" ] && [ -f "$_FOUND" ]; then
    SUB_TEMPLATE_NAME=$(basename "$_FOUND")
    echo ""
    echo "[SUBTITLES] Template found: $SUB_TEMPLATE_NAME"
    printf "Burn subtitles? (1) Yes  (2) No: "
    read _APPLY_SUB
    if [ "$_APPLY_SUB" = "1" ]; then
        SUB_TEMPLATE="$_FOUND"
        echo "[INFO] Subtitles enabled: $SUB_TEMPLATE_NAME"
    fi
else
    echo "[INFO] No .ass template found in agent/templates/ - subtitles skipped"
fi

# Logo check
LOGO_ARG=""
LOGO_SKIP=0
if [ -f "logo.png" ]; then
    echo ""
    echo "[LOGO] logo.png found!"
    printf "Burn logo? (1) Yes  (2) No (Enter = 2): "
    read _LOGO_CHOICE
    if [ "$_LOGO_CHOICE" = "1" ]; then
        LOGO_ARG="--logo logo.png"
        echo "[INFO] Logo enabled"
    else
        mv logo.png logo.png.skip
        LOGO_SKIP=1
        echo "[INFO] Logo skipped"
    fi
fi

if [ -n "$SUB_TEMPLATE" ]; then
    python3 video_concat.py montage_plan.json -o "{project_name}.mp4" -b 20M -r 1080 --veo-audio-inline --subtitles "$SUB_TEMPLATE" $LOGO_ARG
else
    python3 video_concat.py montage_plan.json -o "{project_name}.mp4" -b 20M -r 1080 --veo-audio-inline $LOGO_ARG
fi
if [ $? -ne 0 ]; then
    [ $LOGO_SKIP -eq 1 ] && mv logo.png.skip logo.png 2>/dev/null
    echo "[ERROR] Concat failed!"
    echo "Press Enter to exit..."
    read
    exit 1
fi
[ $LOGO_SKIP -eq 1 ] && mv logo.png.skip logo.png 2>/dev/null

# ============================================================================
# STEP 4: CLEANUP
# ============================================================================

echo ""
echo "[4/4] Renaming original audio..."
echo ""

if [ -f "result_original_audio.wav" ]; then
    mv "result_original_audio.wav" "VEO_AUDIO.wav"
    echo "   [OK] VEO_AUDIO.wav created"
fi

echo ""
echo "[4/4] Cleanup..."
echo ""

# Interactive: ask about deleting temp_processed
if [ -d "temp_processed" ]; then
    echo ""
    echo "   Found temp_processed folder with processed fragments."
    echo "   Delete it to save space?"
    echo ""
    echo "   [1] Yes, delete (recommended)"
    echo "   [2] No, keep (for debugging)"
    echo ""
    echo -n "   Your choice [1-2] (Enter = 1): "
    read CHOICE
    case "$CHOICE" in
        1|"")
            rm -rf "temp_processed"
            echo "   [OK] temp_processed removed"
            ;;
        2)
            echo "   [OK] temp_processed kept"
            ;;
        *)
            echo "   [WARN] Invalid choice, keeping temp_processed"
            ;;
    esac
fi

mkdir -p "FLOW_veo3_fragments"
for F in *.mp4; do
    [ -f "$F" ] || continue
    if [ "$F" != "{project_name}.mp4" ]; then
        mv "$F" "FLOW_veo3_fragments/"
    fi
done

echo ""
echo "================================================================================"
echo "[OK] DONE!"
echo "================================================================================"
echo ""
echo "   Result:    {project_name}.mp4"
echo "   Audio:     VEO_AUDIO.wav"
echo "   Fragments: FLOW_veo3_fragments/"
echo ""
echo "Press Enter to exit..."
read
