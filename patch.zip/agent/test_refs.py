"""
test_refs.py — проверяет каждый ref-файл по отдельности через Banana API.
Запуск: python test_refs.py <project_name>
"""
import sys
import os
import base64
import requests
import mimetypes
from pathlib import Path

API_KEY = "veo_8cd5c80d536d4f783f2f057ceea30a2ca015746644534584"
BASE_URL = "https://veononstop.org/api/v1"
HEADERS = {"X-API-Key": API_KEY, "Content-Type": "application/json"}
TEST_PROMPT_NEUTRAL = "A person stands in a room, photorealistic."
TEST_PROMPT_TESLA = "The gaunt, peaceful face of elderly Nikola Tesla lying motionless in bed + thin institutional linen + prestige historical docu-thriller cinematography, HBO/Netflix level"
TEST_PROMPT_EDISON = "Thomas Edison holding a glowing lightbulb in his laboratory + Edison's workshop + prestige historical docu-thriller cinematography, HBO/Netflix level"

def load_ref(path: Path):
    mime = mimetypes.guess_type(str(path))[0] or "image/jpeg"
    data = path.read_bytes()
    b64 = base64.b64encode(data).decode()
    return {"image_base64": b64, "mime_type": mime}

def test_ref(ref_path: Path):
    ref = load_ref(ref_path)
    body = {
        "prompt": TEST_PROMPT_NEUTRAL,
        "num_images": 1,
        "aspect_ratio": "16:9",
        "model_key": "GEM_PIX_2",
        "reference_images": [ref],
    }
    url = f"{BASE_URL}/image/banana/generate"
    try:
        resp = requests.post(url, headers=HEADERS, json=body, timeout=120)
        status = resp.status_code
        try:
            js = resp.json()
        except Exception:
            js = {"raw": resp.text[:200]}
        return status, js
    except Exception as e:
        return 0, {"exception": str(e)}

def fmt_result(status, js):
    if status == 200 and js.get("success"):
        return "OK"
    elif status == 500:
        return f"500: {js.get('error', str(js))[:60]}"
    elif status == 0:
        return f"EXCEPTION: {js.get('exception', '')[:60]}"
    else:
        return f"HTTP {status}: {str(js)[:60]}"

def main():
    project = sys.argv[1] if len(sys.argv) > 1 else "тесла_мастерстиль"
    ref_dir = Path(__file__).parent.parent / "projects" / project / "ref"
    if not ref_dir.exists():
        print(f"[ERROR] ref/ not found: {ref_dir}")
        sys.exit(1)

    imgs = sorted([f for f in ref_dir.iterdir()
                   if f.suffix.lower() in ('.png', '.jpg', '.jpeg', '.webp')])
    if not imgs:
        print("[ERROR] No images in ref/")
        sys.exit(1)

    # Шаг 1: все рефы с нейтральным промптом
    print(f"\n=== STEP 1: Each ref + NEUTRAL prompt ===")
    print(f"{'File':<30} {'Size':>8}  {'HTTP':>4}  Result")
    print("-" * 80)
    ok_refs = []
    for img in imgs:
        size_kb = img.stat().st_size // 1024
        status, js = test_ref(img)  # uses TEST_PROMPT_NEUTRAL
        result = fmt_result(status, js)
        ok = "OK" if (status == 200 and js.get("success")) else "XX"
        print(f"  {ok} {img.name:<28} {size_kb:>6}KB  {status:>4}  {result}")
        if status == 200 and js.get("success"):
            ok_refs.append(img)

    # Шаг 2: прошедшие рефы с промптом "Nikola Tesla"
    if ok_refs:
        print(f"\n=== STEP 2: OK refs + TESLA prompt (mentions 'Nikola Tesla') ===")
        print(f"{'File':<30}  {'HTTP':>4}  Result")
        print("-" * 80)
        for img in ok_refs:
            body = {
                "prompt": TEST_PROMPT_TESLA,
                "num_images": 1,
                "aspect_ratio": "16:9",
                "model_key": "GEM_PIX_2",
                "reference_images": [load_ref(img)],
            }
            url = f"{BASE_URL}/image/banana/generate"
            try:
                resp = requests.post(url, headers=HEADERS, json=body, timeout=120)
                try:
                    js = resp.json()
                except Exception:
                    js = {"raw": resp.text[:200]}
                result = fmt_result(resp.status_code, js)
                ok = "OK" if (resp.status_code == 200 and js.get("success")) else "XX"
                print(f"  {ok} {img.name:<28}  {resp.status_code:>4}  {result}")
            except Exception as e:
                print(f"  ✗ {img.name:<28}  EXCEPTION: {e}")

    print("\nDone.")

if __name__ == "__main__":
    main()
