# Veo censorship fallback - 2026-08-06

- Treat two consecutive terminal Veo censor-like responses as a confirmed censorship chain.
- Keep ordinary network/client timeouts outside this classification.
- For I2V, stop video generation and copy the source image into `vid_img/{clip_id}`.
- For T2V, generate a static fallback with VeoNonStop Banana 2 Lite (`HARBOR_SEAL`) and save it into `vid_img/{clip_id}.jpg`.
- Added regression tests in `agent/test_veo_censor_fallback.py`.
- No API keys were rotated.
