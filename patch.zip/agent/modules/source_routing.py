"""Deterministic post-Pass-1 routing for optional external sources."""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any

import config


_PROTECTED = {
    "real_photo_pending",
    "real_photo",
    "real_video",
    "stock_pending",
    "stock_photo",
    "stock_video",
    "infographic",
    "youtube",
    "youtube_video",
}

_MOTION_WORDS = {
    "action", "moving", "movement", "walk", "walking", "run", "running",
    "drive", "driving", "traffic", "street", "crowd", "crowds", "work",
    "working", "machine", "machinery", "waves", "rain", "fire", "flight",
    "строит", "идет", "идут", "движ", "машин", "улиц", "толп", "работ",
    "огон", "дожд", "волн",
}


def _enabled(value: Any) -> bool:
    return str(value).strip().lower() in ("1", "true", "yes", "on")


def _non_ai_enabled() -> bool:
    value = (
        __import__("os").environ.get(
            "NON_AI_IMAGE_MODE",
            "1" if getattr(config, "NON_AI_IMAGE_MODE", False) else "0",
        )
    )
    return _enabled(value)


def _clip_text(clip: dict[str, Any]) -> str:
    return " ".join(
        str(clip.get(key) or "")
        for key in ("description", "voiceover", "text", "narration", "prompt")
    ).strip().lower()


def _score(clip: dict[str, Any]) -> tuple[int, int]:
    text = _clip_text(clip)
    motion = sum(1 for word in _MOTION_WORDS if word in text)
    try:
        clip_id = int(clip.get("id", 0))
    except (TypeError, ValueError):
        clip_id = 0
    return motion, -clip_id


def apply_youtube_ratio_policy(montage_path: str | Path) -> dict[str, Any]:
    """Apply the standard-director YouTube target without touching other sources.

    Non-AI allocation remains authoritative in ``non_ai_image_policy.py``.
    Existing Stock/EPF markers are preserved. The policy only fills or trims
    YouTube assignments.
    """
    path = Path(montage_path)
    raw = json.loads(path.read_text(encoding="utf-8-sig"))
    plan = raw.get("montage_plan", raw) if isinstance(raw, dict) else raw
    clips = list(plan.get("clips") or [])

    if not getattr(config, "YOUTUBE_FOOTAGE_ENABLED", False) or _non_ai_enabled():
        if not getattr(config, "YOUTUBE_FOOTAGE_ENABLED", False):
            for clip in clips:
                if clip.get("source") == "youtube_pending":
                    clip.pop("source", None)
        return {"enabled": False, "assigned": 0, "total": len(clips)}

    ratio = max(0.0, min(1.0, float(getattr(config, "YOUTUBE_RATIO_TARGET", 0.0) or 0.0)))
    ratio_max = max(ratio, min(1.0, float(getattr(config, "YOUTUBE_RATIO_MAX", 1.0) or 1.0)))
    target = min(len(clips), int(round(len(clips) * ratio)))
    maximum = (
        0
        if ratio <= 0
        else min(len(clips), int(math.ceil(len(clips) * ratio_max)))
    )

    marked = [
        clip for clip in clips
        if clip.get("source") in {"youtube_pending", "youtube", "youtube_video"}
    ]
    if len(marked) > maximum:
        for clip in sorted(marked, key=lambda item: int(item.get("id", 0)), reverse=True)[maximum:]:
            if clip.get("source") == "youtube_pending":
                clip.pop("source", None)
        marked = marked[:maximum]

    available = [
        clip for clip in clips
        if not clip.get("source") and clip.get("source") not in _PROTECTED
    ]
    for clip in sorted(available, key=_score, reverse=True):
        if len(marked) >= target:
            break
        clip["source"] = "youtube_pending"
        marked.append(clip)

    audit = {
        "enabled": True,
        "target_ratio": ratio,
        "max_ratio": ratio_max,
        "target_count": target,
        "assigned": len(marked),
        "clip_ids": [int(clip.get("id")) for clip in marked if clip.get("id") is not None],
    }
    plan["youtube_routing"] = audit
    path.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
    return audit
