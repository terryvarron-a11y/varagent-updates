# Tk Pair Fixes

## 2026-08-07 - Disable ref hard-match for ref-free generation

- Found `PASS2_EXTERNALIZE_REFMATCH=1` was enabled unconditionally in both
  `gpt_director.py` and `chat_director.py`.
- The Pass 2 prompt then instructed the LLM to emit `[name_ref.jpg]` tokens,
  and `apply_ref_hardmatch()` expanded them into the long `MATCH...` text.
- Hard-match is now enabled only when the current project contains actual
  image files in `project/ref/`.
- Non-image files in `project/ref/` do not enable it; any actual image file does.
- Existing ref-based generation keeps the previous hard-match behavior.
