"""
Local Sound Library — фоновая музыка из личной папки пользователя.

Никакой генерации здесь нет. Берём готовые треки, которые пользователь сам
отобрал, и раскладываем их по слотам music_plan.json. Финальный микшер сам
зацикливает короткие треки и обрезает длинные под тайминг плана.

Откуда берутся треки (в порядке приоритета):
  1. config.MUSIC_LIBRARY_DIR — общая папка пользователя (задаётся в GUI,
     живёт вне проекта — копировать музыку в каждый проект не нужно);
  2. project/music_stock/ и project/stock_music/ — старое поведение,
     оставлено для совместимости с уже собранными проектами.

JSON-паспорт (evidence) рядом с треком НЕ обязателен: файлы в личной папке
пользователь отобрал сам. Если паспорт есть — из него берутся название,
лицензия и ссылка для music_attribution.txt (полезно для треков, скачанных
со стоков). Нет паспорта — трек всё равно используется.
"""
from __future__ import annotations

import json
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

import config
from modules.music_plan_utils import normalize_music_plan


POLICY = (
    "local sound library; tracks are pre-selected by the user; "
    "no local fallback generation"
)
# Оставлено для обратной совместимости (старые манифесты/импорты ссылались на имя).
STRICT_POLICY = POLICY
AUDIO_EXTS = {".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg"}
SAFE_CONTENT_ID_VALUES = {
    "no_content_id",
    "verified_no_content_id",
    "none",
    "not_registered",
    "content_id_free",
}


def generate_safe_music_for_project(
    project_dir: str | Path,
    *,
    plan_path: str | Path | None = None,
    provider: str | None = None,
    force: bool = False,
) -> Dict[str, Any]:
    project_dir = Path(project_dir).resolve()
    plan_path = Path(plan_path) if plan_path else project_dir / "music_plan.json"
    provider = _normalize_provider(provider or getattr(config, "MUSIC_PROVIDER", "local_library"))

    plan = _load_plan(plan_path)
    plan = normalize_music_plan(
        plan,
        float(plan.get("audioDuration", 0) or 0),
        min_track_duration=getattr(config, "MUSIC_MIN_TRACK_DURATION", 120),
        max_track_duration=getattr(config, "MUSIC_MAX_TRACK_DURATION", 240),
        max_tracks=getattr(config, "MUSIC_MAX_TRACKS", 10),
    )

    manifest: Dict[str, Any] = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "policy": POLICY,
        "provider_requested": provider,
        "provider_used": "local_library",
        "items": [],
        "rejections": [],
        "notes": [],
    }

    if provider in {"procedural", "local", "ffmpeg"}:
        manifest["provider_used"] = "none"
        manifest["rejections"].append({
            "provider": provider,
            "reason": "Local/procedural background music is disabled for this workflow.",
        })
        _mark_no_music(plan)
        _save_plan(plan_path, plan)
        _write_evidence(project_dir, manifest)
        return _summary(0, 0, len(_active_tracks(plan)), "none")

    roots = _library_roots(project_dir)
    candidates = _collect_library_tracks(roots, project_dir, manifest)
    if not candidates:
        manifest["provider_used"] = "none"
        searched = ", ".join(str(r) for r in roots) or "(no folders configured)"
        manifest["notes"].append(
            f"No audio files found. Searched: {searched}. "
            "Set the Local Sound Library folder in the GUI (Music block) or drop "
            "tracks into project/music_stock/."
        )
        _mark_no_music(plan)
        _save_plan(plan_path, plan)
        _write_evidence(project_dir, manifest)
        print("   [local_library] No audio files found - continuing without background music")
        print(f"   [local_library] Searched: {searched}")
        return _summary(0, 0, len(_active_tracks(plan)), "none")

    print(f"   [local_library] {len(candidates)} track(s) available")
    selected = _assign_stock_tracks(project_dir, plan, candidates, manifest, force=force)
    _save_plan(plan_path, plan)
    _write_evidence(project_dir, manifest)
    print(f"   [local_library] Selected {selected} track slot(s)")
    return _summary(selected, 0, len(_active_tracks(plan)), "local_library")


def _library_roots(project_dir: Path) -> List[Path]:
    """Папки, где ищем треки: личная библиотека пользователя + папки проекта."""
    roots: List[Path] = []
    lib = str(getattr(config, "MUSIC_LIBRARY_DIR", "") or "").strip().strip('"')
    if lib:
        roots.append(Path(lib).expanduser())
    roots.append(project_dir / "music_stock")
    roots.append(project_dir / "stock_music")
    # Убираем дубли, сохраняя порядок приоритета.
    seen: set[str] = set()
    unique: List[Path] = []
    for root in roots:
        key = str(root).rstrip("\\/").lower()
        if key not in seen:
            seen.add(key)
            unique.append(root)
    return unique


def _collect_library_tracks(
    roots: List[Path], project_dir: Path, manifest: Dict[str, Any]
) -> List[Dict[str, Any]]:
    """Все аудиофайлы из папок библиотеки. JSON-паспорт опционален."""
    candidates: List[Dict[str, Any]] = []
    seen_files: set[str] = set()
    for root in roots:
        try:
            if not root.exists():
                continue
        except OSError as exc:                      # недоступный сетевой путь и т.п.
            manifest["rejections"].append({"folder": str(root), "reason": f"not accessible: {exc}"})
            continue
        shared_manifest = _load_shared_manifest(root)
        try:
            audio_files = sorted(p for p in root.rglob("*") if p.suffix.lower() in AUDIO_EXTS)
        except OSError as exc:
            manifest["rejections"].append({"folder": str(root), "reason": f"scan failed: {exc}"})
            continue
        for audio_path in audio_files:
            key = str(audio_path.resolve()).lower()
            if key in seen_files:                   # один и тот же файл из пересекающихся папок
                continue
            seen_files.add(key)
            # Паспорт не обязателен — пользователь отобрал треки сам.
            evidence = _load_track_evidence(audio_path, shared_manifest) or {}
            candidates.append({
                "path": audio_path,
                "evidence": evidence,
                "keywords": _candidate_keywords(audio_path, evidence),
            })
    return candidates


def _assign_stock_tracks(
    project_dir: Path,
    plan: Dict[str, Any],
    candidates: List[Dict[str, Any]],
    manifest: Dict[str, Any],
    *,
    force: bool,
) -> int:
    music_dir = project_dir / "music"
    music_dir.mkdir(parents=True, exist_ok=True)
    tracks = _active_tracks(plan)
    selected = 0
    used: set[str] = set()          # чтобы один трек не встал во все слоты подряд
    for track in tracks:
        tid = int(track.get("id") or 0)
        if tid <= 0:
            continue
        best = _best_candidate_for_track(track, candidates, used)
        src = best["path"]
        used.add(str(src).lower())
        evidence = best.get("evidence") or {}
        suffix = src.suffix.lower()
        target = music_dir / f"{tid}{suffix}"
        if force or not target.exists():
            shutil.copy2(src, target)
        track["file"] = target.name
        track["source"] = str(evidence.get("source") or evidence.get("provider") or "local_library").lower()
        track["license"] = evidence.get("license") or evidence.get("license_name") or "user-provided"
        track["license_url"] = evidence.get("license_url") or evidence.get("page_url")
        track["page_url"] = evidence.get("page_url") or evidence.get("url")
        track["content_id_status"] = _content_id_status(evidence)
        track["attribution_required"] = bool(evidence.get("attribution_required", False))
        track["stock_music_file"] = _rel(src, project_dir)
        track.pop("suno_clip_ids", None)
        track.pop("suno_durations", None)
        manifest["items"].append({
            "track_id": tid,
            "file": f"music/{target.name}",
            "source_file": _rel(src, project_dir),
            "source": track["source"],
            "license": track["license"],
            "license_url": track.get("license_url"),
            "page_url": track.get("page_url"),
            "content_id_status": track["content_id_status"],
            "fit": "ffmpeg mixer loops short files and trims long files to the planned slot",
        })
        selected += 1
    return selected


def _content_id_status(evidence: Dict[str, Any]) -> str:
    """Статус Content ID из паспорта. Нет паспорта — считаем непроверенным."""
    status = str(evidence.get("content_id_status") or evidence.get("content_id") or "").strip().lower()
    if status in SAFE_CONTENT_ID_VALUES:
        return "verified_no_content_id"
    return status or "unverified"


def _rel(path: Path, project_dir: Path) -> str:
    """Путь относительно проекта; для файлов вне проекта — абсолютный."""
    try:
        return str(path.relative_to(project_dir))
    except ValueError:
        return str(path)


def _mark_no_music(plan: Dict[str, Any]) -> None:
    for track in _active_tracks(plan):
        track["file"] = "__no_verified_stock__.mp3"
        track["source"] = "none"
        track["content_id_status"] = "no_track_found"
        track["attribution_required"] = False
        track.pop("suno_clip_ids", None)
        track.pop("suno_durations", None)


# Старое имя — на случай внешних импортов.
_mark_no_verified_music = _mark_no_music


def _best_candidate_for_track(
    track: Dict[str, Any], candidates: List[Dict[str, Any]], used: set[str] | None = None
) -> Dict[str, Any]:
    """Лучший трек под слот: совпадение слов плана с именем файла/паспортом.

    При прочих равных предпочитаем ещё не использованный трек — иначе один и тот
    же файл встаёт во все слоты подряд.
    """
    used = used or set()
    track_words = _words(" ".join(
        str(track.get(k) or "") for k in ("title", "genre", "mood", "energy", "tags", "prompt")
    ))
    scored = []
    for idx, cand in enumerate(candidates):
        score = len(track_words & cand["keywords"]) if track_words else 0
        fresh = 0 if str(cand["path"]).lower() in used else 1
        scored.append((score, fresh, -idx, cand))
    # Сначала по совпадению слов, затем неиспользованные, затем порядок папки.
    scored.sort(reverse=True, key=lambda item: (item[0], item[1], item[2]))
    return scored[0][3]


def _candidate_keywords(audio_path: Path, evidence: Dict[str, Any]) -> set[str]:
    fields = [
        audio_path.stem,
        audio_path.parent.name,          # музыка часто разложена по папкам-настроениям
        evidence.get("title", ""),
        evidence.get("mood", ""),
        evidence.get("genre", ""),
        evidence.get("tags", ""),
        evidence.get("description", ""),
    ]
    return _words(" ".join(str(x) for x in fields))


def _words(text: str) -> set[str]:
    return {w for w in re.findall(r"[a-zа-я0-9]{3,}", text.lower())}


def _load_shared_manifest(root: Path) -> Dict[str, Any]:
    for name in ("music_stock_manifest.json", "manifest.json"):
        path = root / name
        if path.exists():
            try:
                raw = json.loads(path.read_text(encoding="utf-8-sig"))
                return raw if isinstance(raw, dict) else {}
            except Exception:
                return {}
    return {}


def _load_track_evidence(audio_path: Path, shared_manifest: Dict[str, Any]) -> Dict[str, Any] | None:
    for sidecar in (audio_path.with_suffix(audio_path.suffix + ".json"), audio_path.with_suffix(".json")):
        if sidecar.exists():
            try:
                raw = json.loads(sidecar.read_text(encoding="utf-8-sig"))
                return raw if isinstance(raw, dict) else None
            except Exception:
                return None
    entries = shared_manifest.get("tracks") or shared_manifest.get("items") or []
    for entry in entries if isinstance(entries, list) else []:
        if not isinstance(entry, dict):
            continue
        names = {
            str(entry.get("file") or ""),
            str(entry.get("filename") or ""),
            str(entry.get("path") or ""),
        }
        if audio_path.name in names:
            return entry
    return None


def _write_evidence(project_dir: Path, manifest: Dict[str, Any]) -> None:
    music_dir = project_dir / "music"
    music_dir.mkdir(parents=True, exist_ok=True)
    (music_dir / "music_safe_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    lines: List[str] = [
        "Background music sources",
        f"Policy: {manifest['policy']}",
        f"Provider used: {manifest.get('provider_used') or 'none'}",
        "",
    ]
    if manifest.get("items"):
        lines.append("Tracks:")
        for item in manifest["items"]:
            lines.append(
                f"- {item['file']}: {item['source']}; {item['license']}; "
                f"Content ID: {item['content_id_status']}; {item.get('page_url') or ''}"
            )
    if manifest.get("rejections"):
        lines.extend(["", "Skipped sources:"])
        for rej in manifest["rejections"]:
            src = rej.get("file") or rej.get("folder") or rej.get("provider") or "source"
            lines.append(f"- {src}: {rej['reason']}")
    if manifest.get("notes"):
        lines.extend(["", "Notes:"])
        lines.extend(f"- {n}" for n in manifest["notes"])
    lines.extend([
        "",
        "If no tracks are listed above, the final render continues without background music.",
        "Short tracks are looped; long tracks are trimmed by the final ffmpeg mixer.",
    ])
    (music_dir / "music_attribution.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def _load_plan(plan_path: Path) -> Dict[str, Any]:
    if not plan_path.exists():
        raise FileNotFoundError(f"music_plan.json not found: {plan_path}")
    raw = json.loads(plan_path.read_text(encoding="utf-8-sig"))
    if isinstance(raw, dict) and isinstance(raw.get("music_plan"), dict):
        return raw["music_plan"]
    if isinstance(raw, dict):
        return raw
    raise ValueError(f"Invalid music_plan.json: {plan_path}")


def _save_plan(plan_path: Path, plan: Dict[str, Any]) -> None:
    plan_path.write_text(
        json.dumps({"music_plan": plan}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def _active_tracks(plan: Dict[str, Any]) -> List[Dict[str, Any]]:
    return [
        t for t in plan.get("tracks", []) or []
        if isinstance(t, dict) and (t.get("genre") or "").lower() != "silence"
    ]


def _summary(ok: int, skipped: int, total: int, provider: str) -> Dict[str, Any]:
    return {
        "ok": ok,
        "skipped": skipped,
        "failed": 0,
        "fallback": 0,
        "total": total,
        "provider": provider,
    }


def _normalize_provider(provider: str) -> str:
    provider = (provider or "local_library").strip().lower().replace("-", "_")
    aliases = {
        "safe": "local_library",
        "safe_stock": "local_library",
        "stock_safe": "local_library",
        "stock": "local_library",
        "local_sound_library": "local_library",
        # pixabay/pexels музыкой по API не отдаются — историческое значение из .env
        # молча уезжало сюда же; сохраняем поведение для старых конфигов.
        "pixabay": "local_library",
        "pexels": "local_library",
    }
    return aliases.get(provider, provider)
