@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
title VarAgent GUI
cd /d "%~dp0"

REM ============================================================================
REM Search Python in same paths where install.bat puts it
REM ============================================================================
set "PYTHON_CMD="
set "PYTHON_ARGS="
set "PYVER="

REM First use the same command-based detection as install.bat. On Python 3.14+
REM Windows may install into %LOCALAPPDATA%\Python\pythoncore-3.14-64 instead of
REM the older %LOCALAPPDATA%\Programs\Python\Python314 folder.
python --version 2>&1 | findstr /R /C:"^Python [0-9]" >nul
if not errorlevel 1 (
    for /f "tokens=2" %%v in ('python --version 2^>^&1') do set "PYVER=%%v"
    set "PYTHON_CMD=python"
    set "PYTHON_ARGS="
    call :check_python_version
)

if not defined PYTHON_CMD (
    py --version 2>&1 | findstr /R /C:"^Python [0-9]" >nul
    if not errorlevel 1 (
        for /f "tokens=2" %%v in ('py --version 2^>^&1') do set "PYVER=%%v"
        set "PYTHON_CMD=py"
        set "PYTHON_ARGS="
        call :check_python_version
    )
)

if not defined PYTHON_CMD (
    for %%P in (3.14 3.13 3.12 3.11 3.10) do (
        if not defined PYTHON_CMD (
            py -%%P --version 2>&1 | findstr /R /C:"^Python [0-9]" >nul
            if not errorlevel 1 (
                set "PYTHON_CMD=py"
                set "PYTHON_ARGS=-%%P"
            )
        )
    )
)

if not defined PYTHON_CMD (
    for %%P in (3.14 3.13 3.12 3.11 3.10) do (
        for %%A in (64 32) do (
            if not defined PYTHON_CMD if exist "%LOCALAPPDATA%\Python\pythoncore-%%P-%%A\python.exe" (
                set "PYTHON_CMD=%LOCALAPPDATA%\Python\pythoncore-%%P-%%A\python.exe"
                set "PYTHON_ARGS="
            )
        )
    )
)

if not defined PYTHON_CMD (
    for %%P in (Python314 Python313 Python312 Python311 Python310) do (
        if not defined PYTHON_CMD if exist "%LOCALAPPDATA%\Programs\Python\%%P\python.exe" (
            set "PYTHON_CMD=%LOCALAPPDATA%\Programs\Python\%%P\python.exe"
            set "PYTHON_ARGS="
        )
        if not defined PYTHON_CMD if exist "C:\%%P\python.exe" (
            set "PYTHON_CMD=C:\%%P\python.exe"
            set "PYTHON_ARGS="
        )
        if not defined PYTHON_CMD if exist "C:\Program Files\%%P\python.exe" (
            set "PYTHON_CMD=C:\Program Files\%%P\python.exe"
            set "PYTHON_ARGS="
        )
    )
)

if not defined PYTHON_CMD (
    echo.
    echo [ERROR] Python 3.10+ ne nayden v standartnykh putyakh.
    echo Zapustite install.bat dlya ustanovki Python.
    echo.
    pause
    exit /b 1
)

"!PYTHON_CMD!" !PYTHON_ARGS! varagent.py %*
if errorlevel 1 pause
exit /b %errorlevel%

:check_python_version
for /f "tokens=1,2 delims=." %%a in ("!PYVER!") do (
    set "PY_MAJOR=%%a"
    set "PY_MINOR=%%b"
)
if !PY_MAJOR! LSS 3 (
    set "PYTHON_CMD="
    set "PYTHON_ARGS="
)
if !PY_MAJOR! EQU 3 if !PY_MINOR! LSS 10 (
    set "PYTHON_CMD="
    set "PYTHON_ARGS="
)
exit /b 0
