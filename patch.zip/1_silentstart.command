#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
chmod +x "$SCRIPT_DIR"/*.command 2>/dev/null

if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e 'tell app "Terminal" to do script "cd '\''$SCRIPT_DIR'\'' && exec '\''$0'\''"'
    exit 0
fi

clear

get_env() {
    local val
    val=$(grep -E "^$1=" "$SCRIPT_DIR/agent/.env" 2>/dev/null | tail -1 | cut -d'=' -f2-)
    echo "${val:-$2}"
}

ASSEMBLYAI_LANGUAGE_CODE=$(get_env ASSEMBLYAI_LANGUAGE_CODE ru)
ASSEMBLYAI_SEGMENTATION_MODE=$(get_env ASSEMBLYAI_SEGMENTATION_MODE words)
GEMINI_MODEL=$(get_env GEMINI_MODEL gemini-3.1-pro-preview)
VIDEO_CLIP_MIN_DURATION=$(get_env VIDEO_CLIP_MIN_DURATION 4)
VIDEO_CLIP_MAX_DURATION=$(get_env VIDEO_CLIP_MAX_DURATION 8)
INTRO_BLOCK_DURATION=$(get_env INTRO_BLOCK_DURATION 30)
INTRO_CLIP_MIN_DURATION=$(get_env INTRO_CLIP_MIN_DURATION 0)
INTRO_CLIP_MAX_DURATION=$(get_env INTRO_CLIP_MAX_DURATION 0)

echo ""
echo "================================================================================"
echo " 1_SILENTSTART  [Transcription + Direction]  SILENT MODE"
echo "================================================================================"
echo ""
echo " CURRENT SETTINGS (.env):"
echo " -------------------------------------------------------"
echo " Transcription lang:   $ASSEMBLYAI_LANGUAGE_CODE"
echo " Segmentation mode:    $ASSEMBLYAI_SEGMENTATION_MODE"
echo " Gemini model:         $GEMINI_MODEL"
echo " Two-pass mode:        always ON"
echo " Clip duration:        ${VIDEO_CLIP_MIN_DURATION}-${VIDEO_CLIP_MAX_DURATION}s"
echo " Intro block:          first ${INTRO_BLOCK_DURATION}s  /  clips: ${INTRO_CLIP_MIN_DURATION}s-${INTRO_CLIP_MAX_DURATION}s"
echo " -------------------------------------------------------"
echo ""
echo -n " All correct? Start pipeline? (y=start / n=switch to interactive): "
read CONFIRM
echo ""

if [ "$CONFIRM" = "n" ] || [ "$CONFIRM" = "N" ]; then
    echo " Switching to interactive mode..."
    exec "$SCRIPT_DIR/1_interactivestart.command"
fi

if [ "$CONFIRM" != "y" ] && [ "$CONFIRM" != "Y" ]; then
    echo " Cancelled."
    echo "Press Enter to exit..." && read
    exit 1
fi

echo " Starting pipeline..."
echo ""
cd "$SCRIPT_DIR/agent"
python3 agent.py process --run --language "$ASSEMBLYAI_LANGUAGE_CODE" --two-pass --clip-mode video
RESULT=$?

echo ""
if [ $RESULT -ne 0 ]; then
    echo "================================================================================"
    echo " [ERROR] Pipeline failed!"
    echo "================================================================================"
else
    echo "================================================================================"
    echo " [OK] 1_SILENTSTART complete! Check projects/ folder."
    echo "================================================================================"
    echo " NEXT: Open *_prompts_*.txt and generate video in Veo3"
fi
echo "Press Enter to exit..." && read
exit $RESULT
