"""
refresh_desk_session.py — Force-refresh cookie pool on VeoNonStop desktop instance(s).

Signs a JWT with desk backend's JWT_SECRET (same secret used by api.aivideoz.top),
then calls on each desk:
  POST /api/veo3/session/release   — clears current session
  POST /api/veo3/session/init      — reacquires all cookies from pool

The JWT must carry a REAL user_id with an active subscription, else cookie pool
at api.aivideoz.top rejects /session/init with 500.

Usage:
  # default: use hardcoded user_id
  python refresh_desk_session.py --port 3001 --port 3003

  # override user_id
  python refresh_desk_session.py --port 3001 --user-id 1481951789

  # or via env
  VARAGENT_DESK_USER_ID=1481951789 python refresh_desk_session.py --port 3001
"""
import argparse
import os
import sys
import time
from pathlib import Path

import jwt
import requests

_BACKEND_ENV_DEFAULT = Path(
    r"C:/Users/VARGART/AppData/Local/Programs/veo-subscriber/resources/backend/.env"
)
# Real VeoNonStop account user_id (see memory/reference_veononstop_user_id.md)
_DEFAULT_USER_ID = 1481951789


def _load_jwt_secret(env_path: Path) -> str:
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line.startswith("JWT_SECRET="):
            return line.split("=", 1)[1].strip().strip('"').strip("'")
    raise RuntimeError(f"JWT_SECRET not found in {env_path}")


def _mint_token(secret: str, user_id: int) -> str:
    payload = {
        "user_id": user_id,
        "username": f"user-{user_id}",
        "iat": int(time.time()),
        "exp": int(time.time()) + 300,  # 5 min
    }
    return jwt.encode(payload, secret, algorithm="HS256")


def refresh(port: int, token: str) -> bool:
    base = f"http://127.0.0.1:{port}/api/veo3"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    print(f"\n=== :{port} ===")
    try:
        r = requests.post(f"{base}/session/release", headers=headers, json={}, timeout=10)
        print(f"  release -> {r.status_code} {r.text[:200]}")
    except Exception as e:
        print(f"  release FAILED: {e}")
        return False

    time.sleep(1.5)

    try:
        r = requests.post(f"{base}/session/init", headers=headers, json={}, timeout=60)
        print(f"  init    -> {r.status_code} {r.text[:300]}")
        return r.status_code == 200
    except Exception as e:
        print(f"  init FAILED: {e}")
        return False


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", action="append", type=int, required=True,
                    help="Desk backend port (can be repeated)")
    ap.add_argument("--user-id", type=int,
                    default=int(os.environ.get("VARAGENT_DESK_USER_ID", _DEFAULT_USER_ID)),
                    help=f"Real user_id (default {_DEFAULT_USER_ID})")
    ap.add_argument("--env", default=str(_BACKEND_ENV_DEFAULT),
                    help="Path to desk backend .env (for JWT_SECRET)")
    args = ap.parse_args()

    env_path = Path(args.env)
    if not env_path.exists():
        print(f"ERROR: backend .env not found at {env_path}")
        return 2

    secret = _load_jwt_secret(env_path)
    token = _mint_token(secret, args.user_id)
    print(f"[JWT] signed for user_id={args.user_id} (exp in 5 min, secret from {env_path.name})")

    ok_count = 0
    for port in args.port:
        if refresh(port, token):
            ok_count += 1

    print(f"\n=== Summary: {ok_count}/{len(args.port)} desks refreshed ===")
    return 0 if ok_count == len(args.port) else 1


if __name__ == "__main__":
    sys.exit(main())
