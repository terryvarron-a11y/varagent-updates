#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_SCRIPT="$SCRIPT_DIR/../Resources/install_runtime.sh"

osascript - "$INSTALL_SCRIPT" <<'APPLESCRIPT'
on run argv
    tell application "Terminal"
        activate
        do script "/bin/bash " & quoted form of item 1 of argv
    end tell
end run
APPLESCRIPT
