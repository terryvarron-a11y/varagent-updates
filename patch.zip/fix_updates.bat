@echo off
chcp 65001 >nul
setlocal
title VarAgent - Fix Updates
cd /d "%~dp0"

REM ============================================================================
REM Clears GITHUB_TOKEN in agent\.env
REM The distributed token expired; GitHub answers 404 to requests carrying it,
REM so the Update button fails. The repo is public - no token is needed at all.
REM ============================================================================

echo.
echo   VarAgent - repairing the update check
echo   =====================================
echo.

REM Folder name does not matter (VARAGENT_API_PORTABLE, VarAgent, anything):
REM we look next to this file first, then one level up, then inside every
REM subfolder that holds varagent.py - so dropping the file NEXT TO the program
REM folder works too.
set "ENVFILE="
if exist "agent\.env" set "ENVFILE=agent\.env"

if not defined ENVFILE if exist "..\agent\.env" set "ENVFILE=..\agent\.env"

if not defined ENVFILE (
    for /d %%D in ("*") do (
        if not defined ENVFILE if exist "%%~fD\agent\.env" if exist "%%~fD\varagent.py" set "ENVFILE=%%~fD\agent\.env"
    )
)

if not defined ENVFILE (
    echo   [ERROR] agent\.env not found.
    echo.
    echo   Put fix_updates.bat INTO the VarAgent folder - the one that holds
    echo   varagent.bat - and run it again. The folder name does not matter.
    echo.
    pause
    exit /b 1
)

echo   Found: %ENVFILE%
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$p = (Resolve-Path -LiteralPath $env:ENVFILE).Path;" ^
  "$bytes = [IO.File]::ReadAllBytes($p);" ^
  "$bom = ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF);" ^
  "$text = [Text.Encoding]::UTF8.GetString($bytes);" ^
  "if ($bom) { $text = $text.Substring(1) }" ^
  "if ($text -notmatch '(?m)^GITHUB_TOKEN=') { Write-Host '  Line GITHUB_TOKEN not found - nothing to clear.'; exit 2 }" ^
  "if ($text -match '(?m)^GITHUB_TOKEN=\s*$') { Write-Host '  Token is already empty - nothing to do.'; exit 3 }" ^
  "Copy-Item $p ($p + '.bak_token') -Force;" ^
  "$text = [Regex]::Replace($text, '(?m)^GITHUB_TOKEN=[^\r\n]*', 'GITHUB_TOKEN=');" ^
  "[IO.File]::WriteAllText($p, $text, (New-Object Text.UTF8Encoding($bom)));" ^
  "Write-Host ('  Token cleared. Backup: ' + $p + '.bak_token')"

set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (
    echo   Done. Start VarAgent and press "Check" on the Donate tab.
) else if "%RC%"=="3" (
    echo   Nothing to fix - updates should already work.
) else if "%RC%"=="2" (
    echo   Could not find the GITHUB_TOKEN line. Send this window to the author.
) else (
    echo   Something went wrong. Send this window to the author.
)
echo.
pause
