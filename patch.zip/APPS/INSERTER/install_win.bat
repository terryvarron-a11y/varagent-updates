@echo off
setlocal
title Audio Inserter - Windows setup
cd /d "%~dp0"

echo ============================================================
echo   Audio Inserter - Windows setup
echo ============================================================
echo.

call :find_python
if not defined PYTHON_CMD (
    echo [1/3] Python 3.10+ was not found.
    echo.
    echo Install Python 3.10+ from:
    echo   https://www.python.org/downloads/
    echo.
    echo During setup enable:
    echo   Add Python to PATH
    echo   py launcher
    echo.
    echo If Python is already installed, disable Windows App Execution Alias
    echo for python.exe and python3.exe, then run this file again.
    echo.
    pause
    exit /b 1
)
echo [1/3] Python found: %PYTHON_LABEL%

echo.
echo [2/3] Installing Python packages from requirements.txt...
%PYTHON_CMD% -m ensurepip --upgrade >nul 2>&1
%PYTHON_CMD% -m pip --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo pip was not found in this Python installation.
    echo Reinstall Python with pip enabled, then run install_win.bat again.
    echo.
    pause
    exit /b 1
)
%PYTHON_CMD% -m pip install --user -r "%~dp0requirements.txt"
if errorlevel 1 (
    echo.
    echo Could not install Python packages.
    echo Try manually:
    echo   %PYTHON_CMD% -m pip install --user Pillow ttkbootstrap
    echo.
    pause
    exit /b 1
)

echo.
where ffmpeg >nul 2>&1
if errorlevel 1 (
    echo [3/3] ffmpeg was not found in PATH.
    where winget >nul 2>&1
    if errorlevel 1 (
        echo.
        echo Install ffmpeg manually:
        echo   1. Download: https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip
        echo   2. Extract to C:\ffmpeg
        echo   3. Add C:\ffmpeg\bin to PATH
        echo   4. Restart this setup file
    ) else (
        echo Trying to install ffmpeg with winget...
        winget install --id Gyan.FFmpeg -e --silent --accept-source-agreements --accept-package-agreements
        echo.
        echo Close this window and open it again after ffmpeg installation.
    )
) else (
    for /f "delims=" %%V in ('ffmpeg -version 2^>^&1 ^| findstr /B "ffmpeg version"') do echo [3/3] ffmpeg found: %%V
)

echo.
echo ============================================================
echo   Done. Start AudioInserter.bat by double click.
echo ============================================================
echo.

echo Install check:
%PYTHON_CMD% --version 2>nul
%PYTHON_CMD% -c "import PIL; print('  Pillow      :', PIL.__version__)" 2>nul
%PYTHON_CMD% -c "import ttkbootstrap; print('  ttkbootstrap: OK')" 2>nul
ffmpeg -version 2>nul | findstr /B "ffmpeg version"
echo.

pause
exit /b 0

:find_python
for %%C in ("py -3.14" "py -3.13" "py -3.12" "py -3.11" "py -3.10" "py -3" "python" "python3") do (
    call :try_python %%~C
    if defined PYTHON_CMD exit /b 0
)
exit /b 1

:try_python
set "CANDIDATE=%*"
%CANDIDATE% -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>&1
if errorlevel 1 exit /b 1
for /f "delims=" %%V in ('%CANDIDATE% -c "import sys; print(sys.executable)" 2^>^&1') do set "PYTHON_EXE=%%V"
for /f "delims=" %%V in ('%CANDIDATE% -c "import sys; print(sys.version.split()[0])" 2^>^&1') do set "PYTHON_VER=%%V"
set "PYTHON_LABEL=%PYTHON_EXE% - Python %PYTHON_VER%"
set "PYTHON_CMD=%CANDIDATE%"
exit /b 0
