# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

VARAGENT_API is an AI video production agent. Full pipeline: audio → AssemblyAI transcription → AI direction (GPT/Gemini: montage plan + prompts) → image generation (FastGen/VeoNonStop) → video generation (VeoNonStop i2v/t2v OR FastGen Flow Ultra) → FFmpeg concat.

VARAGENT_API is the **development branch**. VARAGENT_API_PORTABLE is the user-facing portable distribution — always sync changes to both simultaneously.

## Entry Points

```bash
# Primary: process queue + run full pipeline
python agent/agent.py process --run

# pipeline.bat — interactive guided launcher (TTS + all stages)
pipeline.bat

# Stage runners
run_stage1_simple.bat    # process + run (no TTS)
0_interactivestart.bat   # TTS interactive → pipeline
0_silentstart.bat        # TTS silent → pipeline

# Stage 2: concat (run inside project folder)
process_fast.bat         # fast concat
process_1080p.bat        # 1080p reencoded
```

## CLI Commands (agent/agent.py)

```bash
# Core
python agent.py process [--run] [--language ru] [--two-pass] [--clip-mode video|slideshow]
                        [--clip-min N] [--clip-max N]
                        [--post-action skip|fastgen|fastgen_i2v|t2v|i2v|components|veo_i2v
                                       |fastgen_ultra_t2v|fastgen_ultra_ingredients|fastgen_ultra_i2v]
python agent.py run     --audio FILE --style FILE
python agent.py transcribe --audio FILE
python agent.py direct  --transcription FILE --style FILE
python agent.py validate --all
python agent.py status
python agent.py cost-estimate --duration 30 --language ru
```

`--post-action` triggers silent generation after direction completes. Without it, interactive menu appears.

## Architecture

```
ready_to_go/           ← input: audio (.mp3/.wav) + style guides (.txt)
    ├── audio.mp3
    ├── audio_стиль.txt        ← per-file style guide
    └── SG_ALL_пометка.txt     ← global style guide

projects/FLOW_name_date/      ← one folder per audio file
    ├── transcription.json     ← AssemblyAI output
    ├── montage_plan.json      ← Gemini pass 1: clip list + timing
    ├── *_prompts_*.txt        ← Gemini pass 2: one prompt per line
    ├── generated/             ← FastGen/VeoNonStop images
    ├── vid_img/               ← VeoNonStop video fragments
    └── *.mp4                  ← final concat
```

## Modules (agent/modules/)

| Module | Purpose |
|--------|---------|
| `transcriber.py` | AssemblyAI API — audio → segments with timestamps |
| `director.py` | Gemini backend — segments → montage_plan.json + prompts. Two-pass: pass1=JSON plan, pass2=text prompts |
| `gpt_director.py` | GPT backend (Codex CLI) — drop-in replacement for director.py. Activated via `DIRECTOR_BACKEND=gpt` |
| `queue.py` | Scans ready_to_go/, creates project folders, generates BAT files from templates |
| `fastgen.py` | FastGen API — bulk image generation with polling |
| `imggen.py` | VeoNonStop image generation (Imagen/Banana models) |
| `img2video.py` | VeoNonStop video generation — i2v (animate images), t2v (text-to-video), components (multi-image) |
| `flowultra.py` | FastGen Flow Ultra video orchestrator — generate_all_videos_flow_ultra(mode=t2v/ingredients/keyframes). Альтернатива VeoNonStop для VideoGen stage. Keyframes=i2v (start image), ingredients=components (1-3 ref images), t2v=pure text. Flow Ultra использует отдельную подписку FastGen (`/api/v2/usage` → `flow_ultra_threads_allowed`) |
| `codex_adapt.py` | VEO prompt adapter via Codex CLI — converts image-prompts to i2v prompts per style guide |
| `sg_adapter.py` | Adapts master style guide to a specific plot via GPT (Codex CLI). Reads script from `SRT/{project}_скрипт.txt` |
| `gemini_rewrite.py` | Shared censorship-bypass rewriter — template-driven, supports both Gemini and GPT backends |
| `veononstop.py` | VeoNonStop HTTP client — task submit + status polling + video download |
| `remix.py` | i2v/ref remixing chains |
| `ref_compress.py` | Downscale reference images before API calls |
| `tts.py` | TTS via mat3u (ElevenLabs) or csv666 |
| `updater.py` | Auto-update from GitHub (repo: `terryvarron-a11y/varagent-updates`). Manages version.json and .env key migrations |
| `validator.py` | Validates JSON structure of transcription/montage_plan |
| `rewrite_names.py` | Renames generated video files to sequential numbers |
| `yt_packer.py` | YouTube packaging: subtitles, description, tags, cover prompts |

Schemas in `agent/schemas/`: `pass1_control.json`, `pass2_control.json`, `veo_adapt_control.json` — control output structure for GPT director and VEO adapter.

Prompt templates in `agent/prompts/`: `director_instruction_pass1.txt`, `veo_adapt_prompt.txt`, `sg_adapt_prompt.txt`, `rewrite_prompt.txt`, `i2v_remix_prompt.txt`, `ref_remix_prompt.txt`.

## Key Configuration (agent/.env)

Required API keys:
```env
ASSEMBLYAI_API_KEY=
GEMINI_API_KEY=
FASTGEN_API_KEY=
VEONONSTOP_API_KEY=      # https://veononstop.org
TTS_API_KEY_MAT3U=
```

Key settings:
```env
GEMINI_MODEL=gemini-3.1-pro
GEMINI_TWO_PASS=false          # true for 200+ clip projects
GEMINI_THINKING_BUDGET=0       # 0=auto; int for Gemini 2.x budget control
ASSEMBLYAI_LANGUAGE_CODE=ru
VIDEO_CLIP_MIN_DURATION=4
VIDEO_CLIP_MAX_DURATION=8
FASTGEN_MODEL=GEMINI           # GEMINI|GEM_PIX_2|GEM_PIX|GROK|NARWHAL|IMAGEN_3_5
FASTGEN_ASPECT_RATIO=landscape
FASTGEN_API_KEY_BACKUP=        # fallback key if primary fails
VEONONSTOP_MAX_PARALLEL=12     # Basic=4, Standard=12, VIP=24
VEONONSTOP_ASPECT_RATIO=16:9
VEONONSTOP_API_KEY_2=          # optional round-robin keys (_2, _3, _4)
VEONONSTOP_FAST_CENSOR=off     # off|after_rewrites|ultrafast
VEONONSTOP_IMAGE_UPSCALE=off   # off|2K|4K
VEONONSTOP_VIDEO_UPSCALE=false

# KIE.AI remix
KIE_AI_API_KEY=
REMIX_ENGINE=grok              # grok|kieai
REMIX_AVAILABLE=false

# FastGen multi-key
FASTGEN_API_KEY_2=
FASTGEN_MAX_PARALLEL_2=4

# Continuation/rollback
CONT_ROLLBACK_SIZE=20

# GPT Director (Codex CLI) settings
DIRECTOR_BACKEND=gpt           # gpt|gemini — switches between gpt_director.py and director.py
GPT_MODEL=gpt-5.4
GPT_DIRECTOR_TIMEOUT=1200
REWRITE_MODEL=gemini:gemini-2.5-flash  # backend for gemini_rewrite.py censorship bypass

# Long audio chunking (Pass 1 only)
DIRECTOR_PASS1_CHUNK_THRESHOLD=2400   # seconds; projects longer than this get chunked
DIRECTOR_PASS1_CHUNK_DURATION=1200    # chunk size in seconds
```

Config is loaded from `agent/.env`. BAT/pipeline.bat sets OS env vars that take precedence over .env (python-dotenv does NOT override existing env vars).

## BAT Templates

`agent/templates/` contains `.txt` (Windows) and `.command` (macOS) templates. Generated by `queue.py` into each project folder. Any fix to a `.txt` template MUST also be applied to the `.command` counterpart.

Template families (always fix all):
- `process_fast.txt/.command`, `process_1080p.txt/.command`
- `run_veo_i2v.txt/.command`, `run_fastgen_veo_i2v.txt/.command`
- `run_veo_t2v.txt/.command`, `run_veo_components.txt/.command`
- `run_veo_imggen.txt/.command`, `run_img2video.txt/.command`

## Critical Rules

**VARAGENT_API ↔ VARAGENT_API_PORTABLE sync**: ANY change to `agent/` must be applied to both. Never patch only one side.

**BAT files — CRLF required**: Write tool saves LF. Always convert after writing:
```python
data = open(path, 'rb').read()
open(path, 'wb').write(data.replace(b'\r\n', b'\n').replace(b'\n', b'\r\n'))
```

**BAT nested quotes bug**: Never `set "VAR=--flag "!VALUE!""` — CMD truncates at inner `"`. Use a flag variable (`FLAG_ON=yes`) and emit `--flag "!VALUE!"` directly in the python call.

**No Cyrillic in echo/REM**: CMD breaks with LF endings + Cyrillic. Keep echo/REM in ASCII transliteration.

**Validate after every edit**: Re-read changed lines or grep for new code. Never assume an edit landed correctly.

**Backup before editing large files**: Always backup files >500 lines before editing them.

**Propose before editing**: Suggest the change and wait for approval before touching code. Never self-initiate edits.

**Verify line count after edit**: After editing a large file, confirm the line count didn't drop significantly (would indicate accidental deletion).

## video_concat.py

Assembles final video from `montage_plan.json` + fragments in `vid_img/`. Called from project BATs or from `pipeline.bat` auto-concat loop.

```bash
python video_concat.py montage_plan.json -o project.mp4 -b 10M --force-amd
```

After editing root `video_concat.py`, bulk-copy to all project folders:
```bash
for proj in projects/*/; do cp video_concat.py "${proj}video_concat.py"; done
```

## Running Tests

Tests must be run from `agent/` directory (sys.path requires it):
```bash
cd agent
python -m pytest test_*.py
# or individual:
python test_kieai.py
```

## Verifying varagent.py Edits

After every edit to `varagent.py`, always verify it imports cleanly:
```bash
python -c "import varagent; print('OK')"
```
Never report a varagent.py change as done without running this check.

## Custom Claude Commands

`.claude/commands/` contains project-specific slash commands, e.g. `disaster-veo.md` for converting documentary scripts to VEO prompts (uses Sonnet 4.6).

## updater.py — Skip-on-Install Files

These files are never overwritten by the auto-updater:
`projects/`, `.env`, `agent/.env`, `publisher.py`

## Director Two-Pass Mode

Pass 1 (JSON plan): Gemini generates `montage_plan.json` with clip list and timing.
Pass 2 (prompts): Gemini generates one visual prompt per clip, chunked if >PROMPT_CHUNK_SIZE clips.
`GEMINI_TWO_PASS=true` is recommended for projects > 15 min (200+ clips).
`max_output_tokens=65536` — required; 8192 causes truncation on large projects.
