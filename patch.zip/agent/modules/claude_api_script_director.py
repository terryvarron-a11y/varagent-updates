"""Claude API backend for Script Director."""
from __future__ import annotations

from typing import Any, Optional, Tuple

import config
from modules.claude_api_runner import ClaudeApiRunner, ClaudeApiTextResponse
from modules.script_director import GeminiScriptDirector


class ClaudeApiScriptDirector(GeminiScriptDirector):
    def __init__(self, model_name: Optional[str] = None):
        self.api_key = config.CLAUDE_API_KEY or config.ANTHROPIC_API_KEY
        self.model_name = model_name or config.CLAUDE_API_MODEL
        self.input_tokens = 0
        self.output_tokens = 0
        self.runner = ClaudeApiRunner(self.model_name, config.CLAUDE_DIRECTOR_TIMEOUT)

    def _make_api_call(
        self,
        prompt: str,
        pass2_mode: bool = False,
        spinner_msg: str = "Claude API думает",
        system_instruction: str = '',
    ) -> Tuple[Any, Optional[dict]]:
        text, cost_info, _elapsed = self.runner.complete(
            prompt,
            system_instruction=system_instruction,
            label=spinner_msg,
            temperature=0.45 if pass2_mode else 0.3,
        )
        self.input_tokens += cost_info.get('input_tokens', 0)
        self.output_tokens += cost_info.get('output_tokens', 0)
        return ClaudeApiTextResponse(text), cost_info
