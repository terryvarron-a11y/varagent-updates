"""
Claude Code music director backend.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Optional

import config
from modules.claude_code_runner import (
    ClaudeCodeRunner,
    extract_json_object,
    extract_result_text,
    load_json_file,
)
from modules.music_director import MusicDirector


class ClaudeCodeMusicDirector(MusicDirector):
    """MusicDirector implementation that runs through Claude Code CLI."""

    def __init__(self, model_name: Optional[str] = None):
        self.model_name = model_name or config.CLAUDE_MODEL
        self.schemas_dir = Path(__file__).parent.parent / 'schemas'
        self.prompts_dir = Path(__file__).parent.parent / 'prompts'
        self.timeout = config.CLAUDE_DIRECTOR_TIMEOUT
        self.claude = ClaudeCodeRunner(self.model_name, self.timeout)

    def _run_codex(
        self,
        task_prompt: str,
        schema_file: str,
        result_file: Path,
        working_dir: Path,
    ) -> dict:
        schema_path = self.schemas_dir / schema_file
        if not schema_path.exists():
            raise FileNotFoundError(f"Schema не найдена: {schema_path}")

        if result_file.exists():
            result_file.unlink()

        task_file = working_dir / '_claude_music_task.md'
        task_file.write_text(task_prompt, encoding='utf-8')

        extra = f"""
Expected control schema: {schema_path.as_posix()}
After writing music_plan.json, write a valid control JSON object to:
{result_file.as_posix()}
The control JSON must match the schema. Do not wrap it in Markdown.
Your final response must also be the same control JSON object only.
"""
        rc, _stdout, stderr, elapsed = self.claude.run_task_file(
            task_file=task_file,
            working_dir=working_dir,
            label='Music',
            extra_instruction=extra,
        )

        if not result_file.exists():
            try:
                stdout_control = extract_json_object(extract_result_text(_stdout))
                if stdout_control:
                    result_file.write_text(
                        json.dumps(stdout_control, ensure_ascii=False, indent=2),
                        encoding='utf-8',
                    )
            except Exception:
                pass

        if not result_file.exists():
            mp_path = working_dir / 'music_plan.json'
            if mp_path.exists():
                try:
                    plan = json.loads(mp_path.read_text(encoding='utf-8-sig'))
                    tracks = plan.get('tracks') or plan.get('music_plan', {}).get('tracks', [])
                    audio_duration = plan.get('audioDuration') or plan.get('music_plan', {}).get('audioDuration', 0)
                    result_file.write_text(json.dumps({
                        'music_plan_path': str(mp_path),
                        'status': 'ok',
                        'tracks_count': len(tracks),
                        'audio_duration': audio_duration,
                        'error_message': '',
                    }, ensure_ascii=False, indent=2), encoding='utf-8')
                except Exception as e:
                    logging.warning("Could not synthesize Claude music control: %s", e)

        if not result_file.exists():
            result_text = extract_result_text(_stdout)
            raise RuntimeError(
                f"Claude Code не создал {result_file.name} (exit {rc})\n"
                f"stdout: {result_text[-1200:]}\n"
                f"stderr: {stderr[-1200:]}"
            )

        control = load_json_file(result_file)
        logging.info("Claude Music control: %s", json.dumps(control, ensure_ascii=False))
        print(f"   ⏱  Music Director (Claude): {elapsed:.0f}с, model={self.model_name}")
        return control
