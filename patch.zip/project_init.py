#!/usr/bin/env python3
"""
Project Init — Инициализация проекта VARAGENT_API

Проверка API ключей, создание директорий, валидация окружения.
"""
import os
import sys
from pathlib import Path
from dotenv import load_dotenv

# Цвета для вывода
class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

def print_header(text: str):
    print(f"\n{Colors.BOLD}{Colors.BLUE}{'=' * 60}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.BLUE}{text:^60}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.BLUE}{'=' * 60}{Colors.RESET}\n")

def print_ok(text: str):
    print(f"{Colors.GREEN}✓{Colors.RESET} {text}")

def print_error(text: str):
    print(f"{Colors.RED}✗{Colors.RESET} {text}")

def print_warn(text: str):
    print(f"{Colors.YELLOW}⚠{Colors.RESET} {text}")

def print_info(text: str):
    print(f"{Colors.BLUE}ℹ{Colors.RESET} {text}")

def check_env_file(env_path: Path) -> bool:
    """Проверяет существование .env файла"""
    if env_path.exists():
        print_ok(f".env файл найден: {env_path}")
        return True
    else:
        print_error(f".env файл не найден: {env_path}")
        print_info("Создайте .env копию из .env.example")
        return False

def load_env(agent_dir: Path) -> bool:
    """Загружает .env из agent директории"""
    env_path = agent_dir / '.env'
    if env_path.exists():
        load_dotenv(env_path)
        print_ok(f".env загружен из: {env_path}")
        return True
    
    # Пробуем корневой .env
    root_env = agent_dir.parent / '.env'
    if root_env.exists():
        load_dotenv(root_env)
        print_ok(f".env загружен из: {root_env}")
        return True
    
    print_error(".env не найден ни в agent/, ни в корне/")
    return False

def check_api_keys() -> dict:
    """Проверяет наличие и валидность API ключей"""
    keys = {
        'ASSEMBLYAI_API_KEY': {
            'value': os.getenv('ASSEMBLYAI_API_KEY', ''),
            'desc': 'AssemblyAI (транскрипция)',
            'required': True
        },
        'GEMINI_API_KEY': {
            'value': os.getenv('GEMINI_API_KEY', ''),
            'desc': 'Gemini (режиссура)',
            'required': True
        },
        'FASTGEN_API_KEY': {
            'value': os.getenv('FASTGEN_API_KEY', ''),
            'desc': 'FastGen (изображения)',
            'required': False
        },
        'VEONONSTOP_API_KEY': {
            'value': os.getenv('VEONONSTOP_API_KEY', ''),
            'desc': 'VeoNonStop (видео)',
            'required': False
        },
        'TTS_API_KEY_MAT3U': {
            'value': os.getenv('TTS_API_KEY_MAT3U', ''),
            'desc': 'TTS Mat3u (озвучка)',
            'required': False
        },
        'TTS_API_KEY_CSV666': {
            'value': os.getenv('TTS_API_KEY_CSV666', ''),
            'desc': 'TTS CSV666 (озвучка)',
            'required': False
        },
    }
    
    results = {'ok': [], 'missing': [], 'empty': []}
    
    for key, info in keys.items():
        if not info['value']:
            if info['required']:
                results['missing'].append(key)
                print_error(f"{info['desc']}: {key} — НЕ ЗАДАН (обязательный)")
            else:
                results['empty'].append(key)
                print_warn(f"{info['desc']}: {key} — не задан (опциональный)")
        else:
            # Маскируем ключ для вывода
            masked = f"{info['value'][:6]}...{info['value'][-6:]}" if len(info['value']) > 12 else info['value'][:4] + '***'
            results['ok'].append(key)
            print_ok(f"{info['desc']}: {key} = {masked}")
    
    return results

def check_veo_key_status():
    """Проверяет статус VeoNonStop API ключа через /account/info"""
    api_key = os.getenv('VEONONSTOP_API_KEY', '')
    if not api_key:
        return
    
    print_info("Проверка статуса VeoNonStop ключа...")
    
    try:
        import requests
        base_url = "https://veononstop.com/api/v1"
        headers = {"X-API-Key": api_key}
        
        response = requests.get(f"{base_url}/account/info", headers=headers, timeout=10)
        
        if response.status_code == 200:
            data = response.json().get('data', {})
            username = data.get('username', '???')
            plan = data.get('plan', '???')
            expires = data.get('expires_at', '???')
            max_cookies = data.get('max_cookies', '???')
            
            print_ok(f"VeoNonStop: user={username}, plan={plan}, slots={max_cookies}")
            print_info(f"  Срок действия: {expires}")
        elif response.status_code == 401:
            error_data = response.json()
            error_msg = error_data.get('error', 'Unknown error')
            print_error(f"VeoNonStop: {error_msg}")
        else:
            print_warn(f"VeoNonStop: статус {response.status_code}")
            
    except ImportError:
        print_warn("requests не установлен — пропущена проверка VeoNonStop")
    except Exception as e:
        print_warn(f"VeoNonStop: ошибка проверки — {e}")

def create_directories(base_dir: Path):
    """Создаёт необходимые директории"""
    dirs_to_create = [
        base_dir / 'projects',
        base_dir / 'ready_to_go',
        base_dir / 'agent' / 'temp',
        base_dir / 'agent' / 'logs',
    ]
    
    for dir_path in dirs_to_create:
        if not dir_path.exists():
            dir_path.mkdir(parents=True, exist_ok=True)
            print_ok(f"Создана директория: {dir_path}")
        else:
            print_info(f"Директория существует: {dir_path}")

def check_python_version():
    """Проверяет версию Python"""
    version = sys.version_info
    if version.major >= 3 and version.minor >= 8:
        print_ok(f"Python {version.major}.{version.minor}.{version.micro}")
        return True
    else:
        print_error(f"Python {version.major}.{version.minor} — требуется 3.8+")
        return False

def check_dependencies():
    """Проверяет установленные зависимости"""
    required = ['requests', 'python-dotenv']
    missing = []
    
    for pkg in required:
        try:
            __import__(pkg.replace('-', '_'))
            print_ok(f"{pkg} установлен")
        except ImportError:
            missing.append(pkg)
            print_error(f"{pkg} — НЕ установлен")
    
    # Проверяем requirements.txt
    req_file = Path(__file__).parent / 'agent' / 'requirements.txt'
    if req_file.exists():
        print_info(f"requirements.txt найден: {req_file}")
    
    return len(missing) == 0

def check_gemini_key_format():
    """Проверяет формат Gemini API ключа"""
    key = os.getenv('GEMINI_API_KEY', '')
    if key:
        if key.startswith('AIza'):
            print_ok("Gemini ключ: формат корректный (AIza...)")
            return True
        else:
            print_warn(f"Gemini ключ: неожиданный формат ({key[:4]}...)")
            return False
    return False

def check_assemblyai_key_format():
    """Проверяет формат AssemblyAI API ключа"""
    key = os.getenv('ASSEMBLYAI_API_KEY', '')
    if key:
        if len(key) == 32 and all(c in '0123456789abcdef' for c in key.lower()):
            print_ok("AssemblyAI ключ: формат корректный (32 hex)")
            return True
        else:
            print_warn(f"AssemblyAI ключ: неожиданный формат ({len(key)} символов)")
            return False
    return False

def main():
    print_header("VARAGENT_API — ИНИЦИАЛИЗАЦИЯ ПРОЕКТА")
    
    base_dir = Path(__file__).parent
    agent_dir = base_dir / 'agent'
    
    all_ok = True
    
    # 1. Версия Python
    print_info("1. Проверка Python...")
    if not check_python_version():
        all_ok = False
    
    # 2. Зависимости
    print_info("\n2. Проверка зависимостей...")
    if not check_dependencies():
        print_warn("Установите зависимости: pip install -r agent/requirements.txt")
    
    # 3. .env файл
    print_info("\n3. Проверка .env...")
    if not load_env(agent_dir):
        all_ok = False
    
    # 4. API ключи
    print_info("\n4. Проверка API ключей...")
    key_results = check_api_keys()
    
    if key_results['missing']:
        print_error(f"\nОтсутствуют обязательные ключи: {', '.join(key_results['missing'])}")
        all_ok = False
    
    # 5. Формат ключей
    print_info("\n5. Проверка формата ключей...")
    check_gemini_key_format()
    check_assemblyai_key_format()
    
    # 6. Статус VeoNonStop
    print_info("\n6. Проверка VeoNonStop...")
    check_veo_key_status()
    
    # 7. Директории
    print_info("\n7. Создание директорий...")
    create_directories(base_dir)
    
    # Итог
    print_header("ИТОГИ")
    
    if all_ok and not key_results['missing']:
        print_ok("Инициализация завершена успешно!")
        print_info("Запустите: pipeline.bat или 0_interactivestart.bat")
        return 0
    else:
        print_error("Инициализация завершена с ошибками")
        print_info("Исправьте ошибки выше и запустите повторно")
        return 1

if __name__ == '__main__':
    sys.exit(main())
