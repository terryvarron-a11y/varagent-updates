# macOS Quick Start

## First Time Setup

### 0. Unlock Scripts (required on first run!)

macOS blocks scripts from other computers. Run this in Terminal **before** anything else:

```bash
cd /path/to/Var_Agent
python3 unlock_mac.py
```

Or manually:
```bash
chmod +x *.command && xattr -cr .
```

### 1. Install Dependencies
Double-click **`install.command`** in Finder

Or via Terminal:
```bash
./install.command
```

### 2. Check Installation
Double-click **`check_install.command`**

### 3. Set API Keys
Open `agent/.env` and fill in:
```
ASSEMBLYAI_API_KEY=your_key  (https://www.assemblyai.com/app/)
GEMINI_API_KEY=your_key      (https://aistudio.google.com/app/apikey)
FASTGEN_API_KEY=your_key     (https://fast-gen.ai)
```

### 4. Run Stage 1
Double-click **`run_stage1_simple.command`**

---

## Main Commands (Var_Agent folder)

| File | Description |
|------|-------------|
| `install.command` | Install all dependencies (Python, packages, FFmpeg) |
| `check_install.command` | Check installed components |
| `check_and_fix.command` | Check + auto-fix problems |
| `run_stage1_simple.command` | **Run Stage 1** (transcription + prompts) |
| `run_stage2_auto.command` | Auto video concat for all projects |
| `run_stage2_interactive.command` | Interactive video concat |

---

## Project-Level Commands (inside each project folder)

After Stage 1 completes, each project in `projects/PROJECT_NAME/` will have these `.command` files:

### Video Concat (Stage 2)
| File | Description |
|------|-------------|
| `process_fast.command` | Fast concat (no re-encoding) |
| `process_1080p.command` | Concat with 1080p re-encoding |
| `process_fast_interactive.command` | Fast concat + ask about cleanup |
| `process_1080p_interactive.command` | 1080p concat + ask about cleanup |

**Usage:** After generating video fragments in Veo3 and downloading them to the project folder, double-click any of the above `.command` files.

### Image Generation (Stage 3)
| File | Description |
|------|-------------|
| `run_generate.command` | Generate images via FastGen API |
| `run_dogenerator.command` | Re-generate missing clips |

### Director (Emergency)
| File | Description |
|------|-------------|
| `run_director.command` | Run director without transcription (use if Stage 1 broke after transcription) |

---

## Troubleshooting

### macOS says "file is damaged" or offers to move to Trash
**Cause:** macOS Gatekeeper quarantine attribute on files received from another computer.

**Fix** (run in Terminal from Var_Agent folder):
```bash
python3 unlock_mac.py
```

Or manually:
```bash
xattr -cr .
chmod +x *.command
```

Or: right-click the file → **Open** → click **Open** again in the dialog.

### "Permission denied" error
```bash
chmod +x *.command
```

### "Python3 not found" error
Install Python:
```bash
xcode-select --install
# or via Homebrew
brew install python@3.11
```

### Script closes immediately
Run via Terminal to see errors:
```bash
bash run_stage1_simple.command
```

### Homebrew not found
Install Homebrew:
```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

After install:
```bash
eval "$(/opt/homebrew/bin/brew shellenv)"  # Apple Silicon
eval "$(/usr/local/bin/brew shellenv)"     # Intel
```
