"""
cliproxy_mgr.py — управление локальным CLIProxyAPI для варагента.

CLIProxyAPI даёт Gemini 3.1 Pro через Antigravity OAuth (обход выжженной API-квоты).
Этот модуль инкапсулирует всё, что раньше делалось вручную (winget, config.yaml,
запуск сервера, login, health) — чтобы GUI мог авторизовать в один клик, как Codex/Claude.

Ключевые нюансы (проверены эмпирически):
- Сервер слушает :8317, OpenAI-совместимый /v1/chat/completions.
- Логин с конфигом БЕЗ proxy-url → callback-listener :51121, браузер завершает сам.
  С proxy-url логин уходит в ручной paste-режим — поэтому для логина отдельный конфиг.
- Все Gemini-запросы (API) идут через сервер С proxy-url (гео-прокси, если задан).
- Новый Google-аккаунт может требовать одноразовой верификации (ссылка от Google).
"""
from __future__ import annotations

import json
import os
import sys
import shutil
import socket
import subprocess
import time
from pathlib import Path
from typing import Optional

PROXY_PORT = 8317
CALLBACK_PORT = 51121
LOCAL_KEY = "varagent-cliproxy-local"
ACCOUNTS_BASE_PORT = 8318  # 8317 — легаси одиночный сервер; аккаунты Plan Б с 8318+

# creationflags: скрыть консольное окно на Windows
_NOWIN = {"creationflags": 0x08000000} if sys.platform == "win32" else {}


def _home() -> Path:
    return Path(os.path.expanduser("~"))


def config_dir() -> Path:
    d = _home() / ".cli-proxy-api"
    d.mkdir(parents=True, exist_ok=True)
    return d


def config_path() -> Path:
    return config_dir() / "config.yaml"


def login_config_path() -> Path:
    """Отдельный конфиг для логина — БЕЗ proxy-url (иначе paste-режим)."""
    return config_dir() / "config_login.yaml"


def auth_files() -> list[Path]:
    """JSON-файлы авторизации (antigravity-<email>.json и т.п.), кроме служебных."""
    d = config_dir()
    return [f for f in d.glob("*.json")
            if not f.name.startswith("_") and not f.name.startswith("config")]


# ─────────────────────────────────────────────────────────────────────────────
# Поиск / установка бинарника
# ─────────────────────────────────────────────────────────────────────────────

def find_exe() -> Optional[Path]:
    """cli-proxy-api.exe: PATH → winget packages → bundled в дистрибутиве."""
    # 1) PATH (winget добавляет алиас cli-proxy-api)
    w = shutil.which("cli-proxy-api")
    if w:
        return Path(w)
    # 2) winget packages
    if sys.platform == "win32":
        base = _home() / "AppData" / "Local" / "Microsoft" / "WinGet" / "Packages"
        if base.exists():
            hits = list(base.glob("LuisPater.CLIProxyAPI_*/cli-proxy-api.exe"))
            if hits:
                return hits[0]
    # 3) bundled рядом с варагентом (portable)
    here = Path(__file__).resolve().parent.parent.parent  # VARAGENT_API/
    for cand in (here / "CLIProxyAPI" / "cli-proxy-api.exe",
                 here / "cli-proxy-api.exe",
                 here / "cli-proxy-api"):
        if cand.exists():
            return cand
    return None


def install_via_winget(log=print) -> bool:
    """winget install LuisPater.CLIProxyAPI. Возвращает True при успехе."""
    if sys.platform != "win32":
        log("Автоустановка через winget только на Windows — поставьте cli-proxy-api вручную.")
        return False
    if not shutil.which("winget"):
        log("winget не найден — поставьте cli-proxy-api вручную или обновите Windows.")
        return False
    log("Устанавливаю CLIProxyAPI через winget...")
    try:
        subprocess.run(
            ["winget", "install", "--id", "LuisPater.CLIProxyAPI", "--source", "winget",
             "--accept-source-agreements", "--accept-package-agreements", "--disable-interactivity"],
            timeout=300, **_NOWIN,
        )
    except Exception as e:
        log(f"winget install error: {e}")
    return find_exe() is not None


# ─────────────────────────────────────────────────────────────────────────────
# Конфиги
# ─────────────────────────────────────────────────────────────────────────────

def write_config(proxy_url: str = "") -> Path:
    """Основной конфиг сервера (порт 8317, локальный ключ, опц. гео-прокси)."""
    lines = [
        "# CLIProxyAPI config для VARAGENT (авто-сгенерён GUI). Gemini 3.1 Pro via Antigravity.",
        'host: "127.0.0.1"',
        f"port: {PROXY_PORT}",
        'auth-dir: "~/.cli-proxy-api"',
        "api-keys:",
        f'  - "{LOCAL_KEY}"',
        "remote-management:",
        "  allow-remote: false",
        '  secret-key: ""',
        "debug: false",
        "request-retry: 3",
    ]
    pu = proxy_to_url((proxy_url or "").strip())  # голый формат → URL со схемой
    if pu:
        lines.append(f'# Гео-прокси: все запросы к Google/Antigravity идут через этот IP')
        lines.append(f'proxy-url: "{pu}"')
    cfg = config_path()
    cfg.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return cfg


def read_proxy_url() -> str:
    """Текущий proxy-url из config.yaml (для показа в GUI). '' если нет."""
    cfg = config_path()
    if not cfg.exists():
        return ""
    try:
        for line in cfg.read_text(encoding="utf-8").splitlines():
            s = line.strip()
            if s.startswith("proxy-url:"):
                val = s.split(":", 1)[1].strip().strip('"').strip("'")
                return val
    except Exception:
        pass
    return ""


def write_login_config() -> Path:
    """Конфиг для ЛОГИНА — БЕЗ proxy-url (браузерный callback-listener, без paste)."""
    lines = [
        'host: "127.0.0.1"',
        f"port: {PROXY_PORT + 1}",  # 8318, чтобы не конфликтовать с сервером
        'auth-dir: "~/.cli-proxy-api"',
        "api-keys:",
        f'  - "{LOCAL_KEY}"',
        "debug: false",
    ]
    cfg = login_config_path()
    cfg.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return cfg


# ─────────────────────────────────────────────────────────────────────────────
# Сервер
# ─────────────────────────────────────────────────────────────────────────────

def is_server_running() -> bool:
    """True если что-то слушает :8317."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1.0)
        return s.connect_ex(("127.0.0.1", PROXY_PORT)) == 0


def start_server(proxy_url: str = "", log=print) -> bool:
    """Запустить сервер (если не запущен). Возвращает True если слушает :8317."""
    if is_server_running():
        return True
    exe = find_exe()
    if not exe:
        log("cli-proxy-api не найден — нажмите Antigravity Login (поставится автоматически).")
        return False
    write_config(proxy_url)
    try:
        subprocess.Popen(
            [str(exe), "-config", str(config_path())],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,
            **_NOWIN,
        )
    except Exception as e:
        log(f"Не удалось запустить cli-proxy-api: {e}")
        return False
    for _ in range(15):
        if is_server_running():
            log(f"CLIProxyAPI сервер запущен на :{PROXY_PORT}")
            return True
        time.sleep(0.5)
    log("CLIProxyAPI сервер не поднялся за 7с.")
    return False


def restart_server(proxy_url: str = "", log=print) -> bool:
    """Перезапуск (подхватить новый proxy-url / свежий токен)."""
    stop_server()
    time.sleep(1.0)
    return start_server(proxy_url, log=log)


def stop_server():
    """Убить процессы cli-proxy-api (сервер + login)."""
    if sys.platform == "win32":
        try:
            subprocess.run(["taskkill", "/F", "/IM", "cli-proxy-api.exe"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **_NOWIN)
        except Exception:
            pass
    else:
        try:
            subprocess.run(["pkill", "-f", "cli-proxy-api"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────────────────────
# Авторизация / статус
# ─────────────────────────────────────────────────────────────────────────────

def is_authorized() -> bool:
    """Есть ли валидный токен (файл auth + сервер отдаёт непустой список моделей)."""
    if not auth_files():
        return False
    try:
        import requests
        r = requests.get(f"http://127.0.0.1:{PROXY_PORT}/v1/models",
                         headers={"Authorization": f"Bearer {LOCAL_KEY}"}, timeout=6)
        if r.status_code == 200:
            data = r.json().get("data") or []
            return len(data) > 0
    except Exception:
        pass
    return False


# Провайдеры OAuth-логина: флаг cli-proxy-api + префикс имени auth-файла.
# Проверено по исходникам CLIProxyAPI 7.2.77:
#   antigravity → antigravity-<email>.json (callback :51121)
#   claude      → claude-<email>.json      (callback :54545, OAuth через claude.ai, подписка Pro/Max)
#   xai         → xai-<email>.json         (callback :56121, device-code, на будущее)
_LOGIN_PROVIDERS = {
    "antigravity": {"flag": "-antigravity-login", "prefixes": ("antigravity-", "gemini-", "aistudio-")},
    "claude":      {"flag": "-claude-login",      "prefixes": ("claude-", "anthropic-")},
    "xai":         {"flag": "-xai-login",         "prefixes": ("xai-", "grok-")},
}


def authorized_email(provider: Optional[str] = None) -> Optional[str]:
    """Email из имени auth-файла. provider=None → любой известный провайдер;
    provider='claude'/'antigravity'/'xai' → только его auth-файл."""
    if provider:
        prefixes = _LOGIN_PROVIDERS.get(provider, {}).get("prefixes", ())
    else:
        prefixes = tuple(p for v in _LOGIN_PROVIDERS.values() for p in v["prefixes"])
    for f in auth_files():
        name = f.stem
        for pref in prefixes:
            if name.startswith(pref):
                return name[len(pref):]
    return None


def has_auth(provider: str) -> bool:
    """Есть ли auth-файл конкретного провайдера (claude/antigravity/xai)."""
    return authorized_email(provider) is not None


def login_command(provider: str = "antigravity") -> Optional[list[str]]:
    """Аргументы запуска логина (в терминале). Конфиг БЕЗ прокси → браузерный callback.
    provider: antigravity (Gemini) | claude (подписка Pro/Max) | xai (Grok)."""
    exe = find_exe()
    if not exe:
        return None
    flag = _LOGIN_PROVIDERS.get(provider, _LOGIN_PROVIDERS["antigravity"])["flag"]
    write_login_config()
    return [str(exe), flag, "-config", str(login_config_path())]


def normalize_proxy(raw: str) -> str:
    """Приводит прокси к форме с кредами БЕЗ схемы: user:pass@host:port (или host:port).
    Принимает и URL (со схемой — схему сохраняет), и формат антика host:port:user:pass."""
    s = (raw or "").strip()
    if not s:
        return ""
    if "://" in s:
        return s  # уже URL со схемой
    parts = s.split(":")
    if len(parts) == 4:  # host:port:user:pass (формат антика/Proxifier)
        host, port, user, pw = parts
        return f"{user}:{pw}@{host}:{port}"
    if len(parts) == 2:  # host:port (без авторизации)
        return f"{parts[0]}:{parts[1]}"
    return s  # что-то нестандартное — отдаём как есть


def _curl_ip(proxy_arg: str, timeout: int) -> tuple[bool, str]:
    """Один прогон curl через заданный --proxy. (ok, текст об IP или ошибке)."""
    curl = shutil.which("curl") or "curl"
    try:
        r = subprocess.run(
            [curl, "-s", "--max-time", str(timeout), "--proxy", proxy_arg, "https://ifconfig.co/json"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", **_NOWIN,
        )
        out = (r.stdout or "").strip()
        if out and ("ip" in out.lower()):
            import json as _json
            try:
                j = _json.loads(out)
                return True, f"IP {j.get('ip','?')} | {j.get('country','?')} ({j.get('city','')})"
            except Exception:
                return True, out[:200]
        return False, (r.stderr or out or "нет данных")[:200]
    except Exception as e:
        return False, str(e)


def proxy_to_url(raw: str, default_scheme: str = "socks5") -> str:
    """МГНОВЕННО (без сети) → URL со схемой. Со схемой — как есть. Формат антика
    host:port:user:pass → default_scheme://user:pass@host:port. Для сохранения/использования."""
    s = (raw or "").strip()
    if not s:
        return ""
    if "://" in s:
        return s
    return f"{default_scheme}://{normalize_proxy(s)}"


def apply_proxy_scheme(raw: str, scheme: str) -> str:
    """ПРИНУДИТЕЛЬНО навесить выбранную юзером схему (http/socks5). Единая точка сборки:
    снимает существующую схему, ставит выбранную. Тип прокси из host:port:user:pass не определить
    — поэтому юзер выбирает сам, а мы просто собираем. Мгновенно, без сети."""
    s = (raw or "").strip()
    if not s:
        return ""
    scheme = (scheme or "http").strip() or "http"
    creds = s.split("://", 1)[1] if "://" in s else normalize_proxy(s)
    return f"{scheme}://{creds}" if creds else ""


def probe_proxy(raw: str, timeout: int = 25) -> tuple[bool, str, str]:
    """СЕТЕВОЙ пробник (для кнопки «Проверить»): (ok, текст об IP/ошибке, рабочий_URL_со_схемой).
    Принимает URL и формат антика host:port:user:pass; без схемы пробует socks5, затем http."""
    pu = (raw or "").strip()
    if not pu:
        return True, "Прокси не задан — прямое соединение.", ""
    if "://" in pu:
        arg = pu.replace("socks5://", "socks5h://", 1) if pu.startswith("socks5://") else pu
        ok, msg = _curl_ip(arg, timeout)
        return (ok, msg if ok else f"Прокси не ответил: {msg}", pu)
    creds = normalize_proxy(pu)
    for scheme, label in (("socks5h", "socks5"), ("http", "http")):
        ok, msg = _curl_ip(f"{scheme}://{creds}", timeout)
        if ok:
            return True, f"[{label}] {msg}", f"{label}://{creds}"
    return (False, "Прокси не ответил ни по socks5, ни по http (проверь host:port:user:pass)",
            f"socks5://{creds}")


def test_proxy(proxy_url: str, timeout: int = 25) -> tuple[bool, str]:
    """Обёртка (ok, msg) над probe_proxy — для существующих вызовов."""
    ok, msg, _ = probe_proxy(proxy_url, timeout)
    return ok, msg


# ═════════════════════════════════════════════════════════════════════════════
# МУЛЬТИАККАУНТ (Plan Б): свой инстанс + свой прокси на каждый Gemini-аккаунт.
#
# Зачем: per-account поле proxy_url в auth-JSON в текущем exe (7.2.75) НЕ поддержано
# (issue #1508 открыт). Поэтому изоляцию «аккаунт ↔ прокси» — и в рантайме, и при
# refresh токена — даём отдельным процессом cli-proxy-api на каждый аккаунт: свой порт,
# свой auth-dir (одна json), свой ГЛОБАЛЬНЫЙ proxy-url (который точно работает).
#
# Реестр varagent_accounts.json: [{email, proxy, port, pid}]. Аддитивно к легаси
# одиночному серверу на :8317 — пустой реестр = старое поведение (обратная совместимость).
# ═════════════════════════════════════════════════════════════════════════════

def accounts_registry_path() -> Path:
    return config_dir() / "varagent_accounts.json"


def load_accounts() -> list[dict]:
    """Список аккаунтов из реестра: [{email, proxy, port, pid}]. [] если нет/битый."""
    p = accounts_registry_path()
    if not p.exists():
        return []
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def save_accounts(accounts: list[dict]) -> None:
    accounts_registry_path().write_text(
        json.dumps(accounts, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def _safe_email(email: str) -> str:
    """Email → безопасное имя папки/файла (без спецсимволов)."""
    return "".join(c if (c.isalnum() or c in "-_.") else "_" for c in (email or "acct"))


def account_dir(email: str) -> Path:
    """Изолированный auth-dir аккаунта (там ровно одна antigravity-<email>.json)."""
    d = config_dir() / ("acct_" + _safe_email(email))
    d.mkdir(parents=True, exist_ok=True)
    return d


def account_config_path(email: str) -> Path:
    return config_dir() / ("config_acct_" + _safe_email(email) + ".yaml")


def account_auth_file(email: str) -> Optional[Path]:
    """Auth-json аккаунта в его папке (antigravity-/gemini-/aistudio-)."""
    for f in account_dir(email).glob("*.json"):
        if f.name.startswith(("antigravity-", "gemini-", "aistudio-")):
            return f
    return None


def next_free_account_port(accounts: Optional[list[dict]] = None) -> int:
    """Следующий свободный порт для нового инстанса (8318+, минуя занятые в реестре)."""
    accounts = accounts if accounts is not None else load_accounts()
    used = {int(a["port"]) for a in accounts if a.get("port")}
    p = ACCOUNTS_BASE_PORT
    while p in used:
        p += 1
    return p


def write_account_config(email: str, proxy_url: str, port: int) -> Path:
    """Per-account серверный конфиг: свой порт, свой auth-dir, свой прокси."""
    lines = [
        f"# CLIProxyAPI per-account config (VARAGENT Plan Б) — {email}",
        'host: "127.0.0.1"',
        f"port: {int(port)}",
        f'auth-dir: "{account_dir(email).as_posix()}"',
        "api-keys:",
        f'  - "{LOCAL_KEY}"',
        "debug: false",
        "request-retry: 3",
    ]
    pu = proxy_to_url((proxy_url or "").strip())  # host:port:user:pass → socks5://... (exe не ест голый)
    if pu:
        lines.append("# Прокси аккаунта: ВСЕ запросы этого инстанса (генерация + refresh) через него")
        lines.append(f'proxy-url: "{pu}"')
    cfg = account_config_path(email)
    cfg.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return cfg


def is_port_running(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1.0)
        return s.connect_ex(("127.0.0.1", int(port))) == 0


def authorized_on_port(port: int) -> bool:
    """Инстанс на порту отдаёт непустой список моделей = авторизация рабочая."""
    try:
        import requests
        r = requests.get(f"http://127.0.0.1:{int(port)}/v1/models",
                         headers={"Authorization": f"Bearer {LOCAL_KEY}"}, timeout=6)
        if r.status_code == 200:
            return len(r.json().get("data") or []) > 0
    except Exception:
        pass
    return False


def _kill_pid(pid: int) -> None:
    if not pid:
        return
    try:
        if sys.platform == "win32":
            subprocess.run(["taskkill", "/F", "/PID", str(pid)],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **_NOWIN)
        else:
            os.kill(int(pid), 9)
    except Exception:
        pass


def start_account_instance(email: str, proxy_url: str, port: int, log=print) -> Optional[int]:
    """Поднять инстанс аккаунта на его порту. Возвращает pid (или None). Идемпотентно:
    если порт уже слушает — считаем запущенным (pid из реестра, если был)."""
    if is_port_running(port):
        for a in load_accounts():
            if a.get("email") == email:
                return a.get("pid")
        return None
    exe = find_exe()
    if not exe:
        log("cli-proxy-api не найден — сначала установите/залогиньте аккаунт.")
        return None
    if account_auth_file(email) is None:
        log(f"У аккаунта {email} нет auth-файла в {account_dir(email).name} — сначала логин.")
        return None
    write_account_config(email, proxy_url, port)
    try:
        proc = subprocess.Popen(
            [str(exe), "-config", str(account_config_path(email))],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,
            **_NOWIN,
        )
    except Exception as e:
        log(f"Не удалось запустить инстанс {email}: {e}")
        return None
    for _ in range(16):
        if is_port_running(port):
            log(f"Инстанс {email} поднят на :{port} (pid {proc.pid})")
            return proc.pid
        time.sleep(0.5)
    log(f"Инстанс {email} не поднялся за 8с.")
    return proc.pid


def _pid_on_port(port: int) -> Optional[int]:
    """PID, слушающий :port (Windows netstat / *nix lsof). None если свободен."""
    try:
        if sys.platform == "win32":
            out = subprocess.run(["netstat", "-ano"], capture_output=True, text=True,
                                 errors="replace", **_NOWIN).stdout or ""
            for line in out.splitlines():
                if f":{port} " in line and "LISTENING" in line:
                    pid = line.split()[-1]
                    if pid.isdigit():
                        return int(pid)
        else:
            out = subprocess.run(["lsof", "-ti", f"tcp:{port}"],
                                 capture_output=True, text=True).stdout or ""
            for pid in out.split():
                if pid.isdigit():
                    return int(pid)
    except Exception:
        pass
    return None


def stop_account_instance(email: str, log=print, wait_free: bool = True) -> None:
    """Убить инстанс аккаунта: pid из реестра + добить того, кто реально держит порт.
    wait_free=True → ждём фактического освобождения порта (иначе start увидит занятый порт
    и НЕ перезапишет конфиг = старый прокси останется)."""
    port = None
    for a in load_accounts():
        if a.get("email") == email:
            _kill_pid(a.get("pid"))
            port = int(a.get("port") or 0)
            break
    if not port:
        return
    # добить того, кто ещё держит порт (pid из реестра мог протухнуть)
    for _ in range(12):  # до ~6с
        if not is_port_running(port):
            return
        _pid = _pid_on_port(port)
        if _pid:
            _kill_pid(_pid)
        if not wait_free:
            return
        time.sleep(0.5)


def restart_account_instance(email: str, proxy_url: str, port: int, log=print) -> Optional[int]:
    """ЧЕСТНЫЙ перезапуск инстанса с НОВЫМ прокси: стоп → дождаться порта → конфиг → старт.
    Без этого смена прокси не применяется (start идемпотентен, видит занятый порт и выходит)."""
    stop_account_instance(email, log=log, wait_free=True)
    return start_account_instance(email, proxy_url, port, log=log)


def start_all_accounts(log=print) -> list[dict]:
    """Поднять инстансы всех аккаунтов реестра, обновить pid. Возвращает обновлённый реестр."""
    accounts = load_accounts()
    changed = False
    for a in accounts:
        pid = start_account_instance(a["email"], a.get("proxy", ""), int(a["port"]), log=log)
        if pid and a.get("pid") != pid:
            a["pid"] = pid
            changed = True
    if changed:
        save_accounts(accounts)
    return accounts


def stop_all_accounts() -> None:
    for a in load_accounts():
        _kill_pid(a.get("pid"))


def running_account_ports() -> list[int]:
    """Порты авторизованных живых инстансов — для round-robin в chat_client."""
    ports = []
    for a in load_accounts():
        port = int(a.get("port") or 0)
        if port and is_port_running(port) and authorized_on_port(port):
            ports.append(port)
    return ports


def account_status(email: str, port: int) -> tuple[str, bool]:
    """(текст статуса по-человечески, работает_ли) для строки аккаунта в GUI."""
    if not is_port_running(port):
        if account_auth_file(email):
            return ("остановлен", False)
        return ("нет входа", False)
    if authorized_on_port(port):
        return ("работает", True)
    return ("запускается…", False)  # прогрев через прокси — GUI перепроверит


def remove_account(email: str, wipe_auth: bool = True, log=print) -> None:
    """Убрать аккаунт: стоп инстанса, удалить из реестра, (опц.) стереть auth-папку и конфиг."""
    stop_account_instance(email, log=log)
    accounts = [a for a in load_accounts() if a.get("email") != email]
    save_accounts(accounts)
    try:
        cfg = account_config_path(email)
        if cfg.exists():
            cfg.unlink()
    except Exception:
        pass
    if wipe_auth:
        try:
            import shutil as _sh
            d = account_dir(email)
            if d.exists():
                _sh.rmtree(d, ignore_errors=True)
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────────────────────
# Ручной логин аккаунта (--no-browser): URL в GUI → юзер открывает в Dolphin-профиле →
# приём кода ДВОЙНОЙ (авто-callback ИЛИ ручной GET по вставленному redirect-URL).
# Обмен код→токен exe делает через proxy-url login-конфига = прокси аккаунта.
#
# Проверено живьём (7.2.75): --no-browser печатает URL с redirect_uri=localhost:51121,
# затем ждёт callback на :51121 (paste-режима нет). Токен пишется в auth-dir login-конфига.
# ─────────────────────────────────────────────────────────────────────────────

LOGIN_PROBE_PORT = 8399  # порт HTTP-сервера login-процесса (не сервер и не аккаунты)

import re as _re
_AUTH_URL_RE = _re.compile(r"https://accounts\.google\.com/o/oauth2/\S+")


def login_staging_dir() -> Path:
    """Пустая папка для нового логина: любая *.json тут = свежий аккаунт."""
    d = config_dir() / "_login_staging"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _clear_login_staging() -> None:
    for f in login_staging_dir().glob("*.json"):
        try:
            f.unlink()
        except Exception:
            pass


def write_manual_login_config(proxy_url: str) -> Path:
    """Login-конфиг для --no-browser: staging auth-dir + прокси аккаунта (для обмена токена)."""
    lines = [
        'host: "127.0.0.1"',
        f"port: {LOGIN_PROBE_PORT}",
        f'auth-dir: "{login_staging_dir().as_posix()}"',
        "api-keys:",
        f'  - "{LOCAL_KEY}"',
        "debug: false",
    ]
    pu = proxy_to_url((proxy_url or "").strip())  # голый host:port:user:pass → socks5://...
    if pu:
        lines.append(f'proxy-url: "{pu}"')
    cfg = config_dir() / "config_manual_login.yaml"
    cfg.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return cfg


def free_login_port(log=print) -> None:
    """Освободить callback-порт :51121 от залипших login-процессов cli-proxy-api.
    Без этого новый --no-browser падает: 'bind :51121: Only one usage of each socket'."""
    if not is_port_running(CALLBACK_PORT):
        return
    # найти pid, слушающий :51121, и убить именно его (а не все cli-proxy-api подряд)
    killed = False
    if sys.platform == "win32":
        try:
            out = subprocess.run(["netstat", "-ano"], capture_output=True, text=True,
                                 errors="replace", **_NOWIN).stdout or ""
            for line in out.splitlines():
                if f":{CALLBACK_PORT} " in line and "LISTENING" in line:
                    pid = line.split()[-1]
                    if pid.isdigit():
                        _kill_pid(int(pid))
                        killed = True
        except Exception:
            pass
    else:
        try:
            out = subprocess.run(["lsof", "-ti", f"tcp:{CALLBACK_PORT}"],
                                 capture_output=True, text=True).stdout or ""
            for pid in out.split():
                if pid.isdigit():
                    _kill_pid(int(pid))
                    killed = True
        except Exception:
            pass
    if killed:
        log("Освобождён порт логина :51121 (был занят залипшим процессом).")
        for _ in range(6):
            if not is_port_running(CALLBACK_PORT):
                break
            time.sleep(0.5)


def start_manual_login(proxy_url: str, on_line=None):
    """Запустить --no-browser логин. Возвращает Popen (или None). Стрим stdout → on_line(line).
    GUI ищет в строках auth-URL (extract_auth_url). Staging очищается перед стартом.

    ВАЖНО: перед стартом освобождаем :51121 — иначе залипший прошлый login-процесс держит
    порт, новый падает мгновенно (bind error), слушателя нет → приём кода бьёт в 10061."""
    exe = find_exe()
    if not exe:
        return None
    free_login_port()  # ← корневой фикс «10061 / connection refused»
    _clear_login_staging()
    cfg = write_manual_login_config(proxy_url)
    try:
        proc = subprocess.Popen(
            [str(exe), "-antigravity-login", "--no-browser", "-config", str(cfg)],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL, text=True, encoding="utf-8", errors="replace",
            **_NOWIN,
        )
    except Exception:
        return None
    if on_line is not None:
        import threading
        def _rd():
            try:
                for ln in proc.stdout:
                    on_line(ln.rstrip("\n"))
            except Exception:
                pass
        threading.Thread(target=_rd, daemon=True).start()
    return proc


def extract_auth_url(line: str) -> Optional[str]:
    """Достаёт Google OAuth URL из строки stdout логина (или None)."""
    m = _AUTH_URL_RE.search(line or "")
    return m.group(0) if m else None


def find_browser() -> Optional[Path]:
    """Универсально ищем Chrome/Edge/Chromium: реестр App Paths → станд. папки → PATH.
    Не хардкодим путь — у разных юзеров браузер лежит по-разному."""
    # 1) Windows реестр App Paths (и HKLM, и HKCU)
    if sys.platform == "win32":
        try:
            import winreg
            for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
                for exe_name in ("chrome.exe", "msedge.exe"):
                    try:
                        with winreg.OpenKey(
                            hive,
                            rf"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\{exe_name}"
                        ) as k:
                            val, _ = winreg.QueryValueEx(k, None)
                            if val and Path(val).exists():
                                return Path(val)
                    except OSError:
                        continue
        except Exception:
            pass
    # 2) стандартные папки (env-переменные, не хардкод буквы диска)
    _pf = os.environ.get("PROGRAMFILES", r"C:\Program Files")
    _pf86 = os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")
    _lad = os.environ.get("LOCALAPPDATA", str(_home() / "AppData" / "Local"))
    rels = [
        r"Google\Chrome\Application\chrome.exe",
        r"Chromium\Application\chrome.exe",
        r"Microsoft\Edge\Application\msedge.exe",
        r"BraveSoftware\Brave-Browser\Application\brave.exe",
    ]
    bases = [_pf, _pf86, _lad]
    for b in bases:
        for r in rels:
            p = Path(b) / r
            if p.exists():
                return p
    # macOS / Linux станд. места
    for p in ("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
              "/Applications/Chromium.app/Contents/MacOS/Chromium",
              "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"):
        if Path(p).exists():
            return Path(p)
    # 3) PATH
    for name in ("chrome", "google-chrome", "chromium", "chromium-browser", "msedge", "brave"):
        w = shutil.which(name)
        if w:
            return Path(w)
    return None


def open_url_in_proxy_browser(url: str, proxy_url: str, log=print) -> bool:
    """Открыть URL в Chrome/Edge через HTTP-прокси аккаунта (чистый временный профиль).
    Консент идёт через прокси; callback на localhost:51121 браузер отдаёт локально (loopback).

    NB: только HTTP(S)-прокси — Chrome не держит SOCKS5-авторизацию. Для socks5-с-паролем
    используй «в антике» (Dolphin). Возвращает True если браузер запущен."""
    br = find_browser()
    if not br:
        log("Chrome/Edge/Chromium не найден — открой ссылку вручную в браузере с прокси.")
        return False
    prof = config_dir() / "_login_browser_profile"
    prof.mkdir(parents=True, exist_ok=True)
    args = [
        str(br),
        f"--proxy-server={proxy_url}",
        # localhost мимо прокси, чтобы callback :51121 дошёл до слушателя exe
        "--proxy-bypass-list=127.0.0.1;localhost;<-loopback>",
        f"--user-data-dir={prof}",
        "--no-first-run", "--no-default-browser-check", "--new-window",
        url,
    ]
    try:
        subprocess.Popen(args, **_NOWIN)
        return True
    except Exception as e:
        log(f"Не удалось запустить браузер: {e}")
        return False


def submit_redirect_url(redirect_url: str) -> tuple[bool, str]:
    """FALLBACK: отдать код слушателю exe локально (loopback — наружу не идёт, IP не палит).

    Юзер вставляет полный redirect-URL (localhost:51121/oauth-callback?code=...&state=...);
    мы локально GET'им его на 127.0.0.1:51121. Принимаем и полный URL, и просто query.
    """
    u = (redirect_url or "").strip()
    if not u:
        return False, "Пустой URL"
    # вычленяем query-часть
    if "oauth-callback" in u:
        query = u.split("oauth-callback", 1)[1].lstrip("?")
    elif u.startswith("?"):
        query = u[1:]
    elif "code=" in u and "://" not in u:
        query = u  # похоже, вставили только query
    else:
        # полный URL с другим путём — берём то, что после '?'
        query = u.split("?", 1)[1] if "?" in u else u
    if "code=" not in query:
        return False, "В URL нет code= — вставьте полный адрес редиректа с ?code=...&state=..."
    local = f"http://127.0.0.1:{CALLBACK_PORT}/oauth-callback?{query}"
    try:
        import requests
        r = requests.get(local, timeout=15)
        if r.status_code < 400:
            return True, "Код передан слушателю — идёт обмен на токен…"
        return False, f"Слушатель ответил {r.status_code} (возможно, callback уже принят)"
    except Exception as e:
        return False, f"Не удалось достучаться до слушателя :{CALLBACK_PORT}: {e}"


def finalize_manual_login(proxy_url: str, timeout_s: int = 20, log=print) -> Optional[str]:
    """Дождаться появления json в staging → перенести в папку аккаунта, зарегистрировать,
    поднять инстанс. Возвращает email (или None если токен не появился)."""
    proxy_url = proxy_to_url((proxy_url or "").strip())  # реестр хранит URL со схемой
    staged = None
    for _ in range(int(timeout_s) * 2):
        cands = [f for f in login_staging_dir().glob("*.json")
                 if f.name.startswith(("antigravity-", "gemini-", "aistudio-"))]
        if cands:
            staged = cands[0]
            break
        time.sleep(0.5)
    if not staged:
        return None
    # email из имени файла (antigravity-<email>.json)
    stem = staged.stem
    email = stem
    for pref in ("antigravity-", "gemini-", "aistudio-"):
        if stem.startswith(pref):
            email = stem[len(pref):]
            break
    # перенести json в изолированную папку аккаунта
    dst = account_dir(email) / staged.name
    try:
        if dst.exists():
            dst.unlink()
        staged.replace(dst)
    except Exception:
        import shutil as _sh
        _sh.copy2(str(staged), str(dst))
        try:
            staged.unlink()
        except Exception:
            pass
    # реестр: добавить/обновить (порт держим стабильным, если акк уже был)
    accounts = load_accounts()
    existing = next((a for a in accounts if a.get("email") == email), None)
    if existing:
        existing["proxy"] = proxy_url
        port = int(existing["port"])
    else:
        port = next_free_account_port(accounts)
        accounts.append({"email": email, "proxy": proxy_url, "port": port, "pid": None})
    save_accounts(accounts)
    # поднять инстанс аккаунта с его прокси
    pid = start_account_instance(email, proxy_url, port, log=log)
    if pid:
        for a in accounts:
            if a.get("email") == email:
                a["pid"] = pid
        save_accounts(accounts)
    return email
