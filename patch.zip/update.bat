@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo ================================================================
echo  VARAGENT - Update
echo  Rabotaet dazhe esli varagent.py ne zapuskaetsya.
echo ================================================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python ne nayden. Zapustite install.bat.
    pause
    exit /b 1
)

set "TMP_PY=%TEMP%\varagent_update_%RANDOM%.py"

echo import sys, pathlib > "!TMP_PY!"
echo p = pathlib.Path('.') >> "!TMP_PY!"
echo sys.path.insert(0, str(p / 'agent')) >> "!TMP_PY!"
echo from modules import updater as u >> "!TMP_PY!"
echo i = u.check_updates(p) >> "!TMP_PY!"
echo if i.get('error'): print('[ERROR]', i['error']); sys.exit(1) >> "!TMP_PY!"
echo if not i['available']: print('[OK] Uzhe aktualnaya versiya: v' + i['version']); sys.exit(0) >> "!TMP_PY!"
echo print('Dostupno: v' + i['version']) >> "!TMP_PY!"
echo for line in i.get('changelog', []): print(' *', line) >> "!TMP_PY!"
echo print() >> "!TMP_PY!"
echo res = u.install_update(p, lambda m: print(' ', m)) >> "!TMP_PY!"
echo if not res['ok']: print('[ERROR]', res['error']); sys.exit(1) >> "!TMP_PY!"
echo print('[OK] Obnovleno. Zapustite varagent.bat.') >> "!TMP_PY!"

echo  Proverka obnovleniy...
echo.
python "!TMP_PY!"
set "EXIT_CODE=!errorlevel!"
del "!TMP_PY!" >nul 2>&1

if "!EXIT_CODE!"=="1" (
    echo.
    echo  [ERROR] Obnovlenie ne udalos. Smotri oshibku vyshe.
    pause
    exit /b 1
)

echo.
echo  Zapustite varagent.bat
echo.
pause
