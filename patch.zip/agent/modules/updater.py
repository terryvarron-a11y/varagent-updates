"""
updater.py — Проверка и установка обновлений VARAGENT с GitHub
Версия: 2026.03.24-fix
"""
import hashlib
import json
import urllib.request
import urllib.error
import zipfile
import io
from pathlib import Path
from typing import Optional

GITHUB_REPO      = 'terryvarron-a11y/varagent-updates'
VERSION_JSON_URL = f'https://raw.githubusercontent.com/{GITHUB_REPO}/main/version.json'
VERSION_API      = f'https://api.github.com/repos/{GITHUB_REPO}/contents/version.json'
PATCH_URL        = f'https://raw.githubusercontent.com/{GITHUB_REPO}/main/patch.zip'

SKIP_ON_INSTALL = {'projects/', '.env', 'agent/.env', 'publisher.py'}

# Keys that must exist in agent/.env — added with defaults if missing.
# Order matters: each entry is (KEY, default_value, optional_comment_above).
_ENV_REQUIRED = [
    ('VEONONSTOP_API_KEY_3',  '',     '# VeoNonStop Key3 (optional)'),
    ('VEONONSTOP_KEY3_NAME',  'Key3', None),
    ('VEONONSTOP_API_KEY_4',  '',     '# VeoNonStop Key4 (optional)'),
    ('VEONONSTOP_KEY4_NAME',  'Key4', None),
    ('ASSEMBLYAI_SPEECH_MODELS', 'universal-3-pro,universal-2', '# AssemblyAI speech models (fallback chain)'),
    ('KIE_AI_API_KEY', 'dc7c523adbb785ec1c8bad4e9cf00419', '# Kie.ai API key (image remix)'),
    ('FASTGEN_API_KEY_BACKUP', 'ldYeCcDcT1AR5w8mm49rI4hThgzczUfq', '# FastGen backup API key'),
    ('DIRECTOR_BACKEND', 'gpt', '# Director backend (gemini or gpt)'),
    ('GPT_MODEL', 'gpt-5.4', None),
    ('GPT_PASS2_CHUNK_SIZE', '100', None),
    ('REWRITE_MODEL', 'gemini:gemini-2.5-flash', '# Rewrite model (provider:model)'),
    ('REMIX_ENGINE', 'grok', '# Remix engine (grok or kieai)'),
    ('VEONONSTOP_REF_MODE', 'name_match', '# Ref mode: name_match (by prompt names) or use_all (all refs on every prompt)'),
]

# Ключи, которые нужно обновить если значение устарело: (key, old_value, new_value)
_ENV_UPGRADES = [
    ('ASSEMBLYAI_SPEECH_MODELS', 'universal-3-pro', 'universal-3-pro,universal-2'),
]

# Принудительная перезапись ключей (key, new_value) — ставится ВСЕМ юзерам при обновлении
_ENV_FORCE = [
    ('FASTGEN_API_KEY', 'ldYeCcDcT1AR5w8mm49rI4hThgzczUfq'),
    ('FASTGEN_API_KEY_BACKUP', 'ldYeCcDcT1AR5w8mm49rI4hThgzczUfq'),
    ('REMIX_ENGINE', 'grok'),
    ('DIRECTOR_BACKEND', 'gpt'),
    ('GPT_MODEL', 'gpt-5.4'),
    ('GPT_PASS2_CHUNK_SIZE', '200'),
]

# Загружаем токен из .env если есть (для обхода rate limit)
def _load_github_token(root: Path) -> 'Optional[str]':
    env_file = root / 'agent' / '.env'
    if env_file.exists():
        for line in env_file.read_text(encoding='utf-8').splitlines():
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                k, _, v = line.partition('=')
                if k.strip() == 'GITHUB_TOKEN':
                    return v.strip()
    return None


def _md5(path: Path) -> str:
    h = hashlib.md5()
    h.update(path.read_bytes())
    return h.hexdigest()


def _fetch(url: str, token: str = None, timeout: int = 15) -> bytes:
    headers = {'User-Agent': 'varagent-updater'}
    if token:
        headers['Authorization'] = f'token {token}'
    req = urllib.request.Request(url, headers=headers)
    return urllib.request.urlopen(req, timeout=timeout).read()


def _fetch_version_json(token: str = None) -> dict:
    """Получает version.json через GitHub API (с токеном для обхода rate limit)."""
    import base64
    headers = {
        'User-Agent': 'varagent-updater',
        'Accept': 'application/vnd.github.v3+json',
    }
    if token:
        headers['Authorization'] = f'token {token}'
    req = urllib.request.Request(VERSION_API, headers=headers)
    d = json.loads(urllib.request.urlopen(req, timeout=15).read())
    return json.loads(base64.b64decode(d['content']))


def check_updates(root: Path) -> dict:
    """
    Проверяет наличие обновлений.

    Returns:
        {
          'available': bool,
          'version': str,
          'changelog': [...],
          'changed_files': [...],   # файлы которые реально изменились у юзера
          'error': str or None,
        }
    """
    token = _load_github_token(root)
    try:
        data = _fetch_version_json(token)
    except Exception:
        # Фоллбэк на raw URL — работает даже если GitHub API недоступен
        # или если старый updater.py сломан (NameError VERSION_API и т.п.)
        try:
            raw = _fetch(VERSION_JSON_URL, token)
            data = json.loads(raw)
        except Exception as e:
            return {'available': False, 'error': str(e)}

    remote_files = data.get('files', {})
    changed = []
    for rel, remote_md5 in remote_files.items():
        local_path = root / rel
        if not local_path.exists():
            changed.append(rel)
        elif _md5(local_path) != remote_md5:
            changed.append(rel)

    return {
        'available': len(changed) > 0,
        'version':   data.get('version', '?'),
        'changelog': data.get('changelog', []),
        'changed_files': changed,
        'requires_restart': data.get('requires_restart', False),
        'error': None,
    }


def install_update(root: Path, progress_cb=None) -> dict:
    """
    Скачивает и устанавливает patch.zip.

    progress_cb(msg: str) — опциональный колбэк для прогресса

    Returns: {'ok': bool, 'installed': [...], 'error': str or None}
    """
    def log(msg):
        if progress_cb:
            progress_cb(msg)

    token = _load_github_token(root)
    requires_restart = False

    try:
        # Сначала загружаем version.json для requires_restart
        log('Загрузка version.json...')
        try:
            data = _fetch_version_json(token)
            requires_restart = data.get('requires_restart', False)
        except Exception as ve:
            log(f'Предупреждение: не удалось загрузить version.json ({ve})')

        log('Скачивание патча...')
        patch_bytes = _fetch(PATCH_URL, token, timeout=60)

        log('Установка файлов...')
        installed = []
        with zipfile.ZipFile(io.BytesIO(patch_bytes)) as zf:
            for name in zf.namelist():
                # Пропускаем защищённые пути
                if any(name.startswith(s) for s in SKIP_ON_INSTALL):
                    continue
                dest = root / Path(name)  # Path() handles / correctly on all platforms
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(zf.read(name))
                installed.append(name)
                log(f'  {name}')

        log(f'Готово. Установлено файлов: {len(installed)}')
        # Очистка __pycache__ — иначе Python может импортировать старый .pyc
        import shutil
        for cache_dir in root.rglob('__pycache__'):
            try:
                shutil.rmtree(cache_dir)
            except Exception:
                pass
        log('Очистка __pycache__ — OK')
        # patch_env из нового updater.py (файл уже перезаписан из zip,
        # но в памяти ещё старый модуль с устаревшим _ENV_REQUIRED)
        _new_updater = root / 'agent' / 'modules' / 'updater.py'
        if _new_updater.exists():
            _ns = {}
            exec(compile(_new_updater.read_text(encoding='utf-8'), str(_new_updater), 'exec'), _ns)
            _added = _ns['patch_env'](root)
            if _added:
                log(f'Обновлён .env: {", ".join(_added)}')
        else:
            patch_env(root)
        _install_fonts(root, log)
        return {'ok': True, 'installed': installed, 'error': None,
                'requires_restart': requires_restart}

    except Exception as e:
        return {'ok': False, 'installed': [], 'error': str(e)}


def patch_env(root: Path) -> list:
    """
    Добавляет в agent/.env строки для ключей из _ENV_REQUIRED, если они отсутствуют.
    Существующие значения НЕ трогает.

    Returns: список добавленных ключей (пустой если всё уже было).
    """
    env_path = root / 'agent' / '.env'
    if not env_path.exists():
        return []

    try:
        text = env_path.read_text(encoding='utf-8')
    except Exception:
        return []

    # Собираем ключи и их значения
    existing_keys = {}  # key → value
    for line in text.splitlines():
        line = line.strip()
        if line and not line.startswith('#') and '=' in line:
            k, _, v = line.partition('=')
            existing_keys[k.strip()] = v.strip()

    added = []
    extra_lines = []
    for key, default, comment in _ENV_REQUIRED:
        if key not in existing_keys:
            # Ключа нет — добавляем
            if comment:
                extra_lines.append(comment)
            extra_lines.append(f'{key}={default}')
            added.append(key)
        elif not existing_keys[key] and default:
            # Ключ есть но пустой, а дефолт непустой — прописываем значение
            import re as _re
            text = _re.sub(
                rf'^({_re.escape(key)}\s*=)\s*$',
                rf'\g<1>{default}',
                text, count=1, flags=_re.MULTILINE
            )
            added.append(f'{key} (filled empty)')

    # Принудительная перезапись ключей
    for key, new_val in _ENV_FORCE:
        if key in existing_keys and existing_keys[key] != new_val:
            import re as _re
            pattern = _re.compile(rf'^({_re.escape(key)}\s*=).*$', _re.MULTILINE)
            if pattern.search(text):
                text = pattern.sub(rf'\g<1>{new_val}', text)
                added.append(f'{key} (force-updated)')

    # Обновляем устаревшие значения
    for key, old_val, new_val in _ENV_UPGRADES:
        if key in existing_keys and existing_keys[key] == old_val:
            import re as _re
            pattern = _re.compile(rf'^({_re.escape(key)}\s*=\s*){_re.escape(old_val)}\s*$', _re.MULTILINE)
            if pattern.search(text):
                text = pattern.sub(rf'\g<1>{new_val}', text)
                added.append(f'{key} (upgraded)')

    if not added:
        return []

    # Добавляем новые ключи в конец файла
    if extra_lines:
        if not text.endswith('\n'):
            extra_lines.insert(0, '')
        text = text + '\n'.join(extra_lines) + '\n'

    env_path.write_text(text, encoding='utf-8')
    return added


def _install_fonts(root: Path, log=None):
    """Копирует шрифты из agent/fonts/ в системную папку шрифтов (если ещё не установлены)."""
    import platform
    import shutil

    fonts_dir = root / 'agent' / 'fonts'
    if not fonts_dir.exists():
        return

    system = platform.system()
    if system == 'Windows':
        # Per-user fonts — не требует прав администратора
        dest_dir = Path.home() / 'AppData' / 'Local' / 'Microsoft' / 'Windows' / 'Fonts'
    elif system == 'Darwin':
        dest_dir = Path.home() / 'Library' / 'Fonts'
    else:
        dest_dir = Path.home() / '.local' / 'share' / 'fonts'

    dest_dir.mkdir(parents=True, exist_ok=True)

    for font_file in fonts_dir.glob('*.ttf'):
        dest = dest_dir / font_file.name
        if dest.exists():
            continue
        try:
            shutil.copy2(str(font_file), str(dest))
            if log:
                log(f'  Шрифт установлен: {font_file.name}')
        except Exception as e:
            if log:
                log(f'  Шрифт {font_file.name}: не удалось ({e})')
