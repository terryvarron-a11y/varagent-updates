"""
tts_runner.py — запускатель TTS + продолжение пайплайна.

Вызывается из батников:
    python tts_runner.py --mode silent
    python tts_runner.py --mode interactive

Режимы:
    silent      — показывает настройки из .env, подтверждение уже получено батником.
                  После TTS автоматически запускает agent.py process --run.
    interactive — спрашивает каждый параметр. После TTS: pause (послушать),
                  подтверждение, выбор режима следующих этапов.
"""
import sys
import os
import json
import subprocess
from pathlib import Path

# Добавляем agent/ в путь
_agent_dir = Path(__file__).parent.parent
sys.path.insert(0, str(_agent_dir))

import config
from modules.tts import run_tts, parse_script_file


# ============================================================================
# ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
# ============================================================================

def _ask(prompt: str, default: str = '') -> str:
    val = input(f"{prompt} [{default}]: ").strip()
    return val if val else default


def _print_settings_table():
    """Выводит текущие настройки TTS из .env."""
    svc = config.TTS_SERVICE
    print()
    print("=" * 60)
    print("  TTS SETTINGS (from .env)")
    print("=" * 60)
    print(f"  Service:          {svc}")

    if svc == 'csv666':
        key_set = bool(config.TTS_API_KEY_CSV666)
        print(f"  API Key csv666:   {'[SET]' if key_set else '[NOT SET!]'}")
        print(f"  Chunk size:       {config.TTS_CSV666_CHUNK_SIZE}")
        print(f"  Output format:    {config.TTS_CSV666_OUTPUT_FORMAT}")
    elif svc == 'voicegen':
        key_set = bool(config.TTS_API_KEY_VOICEGEN)
        print(f"  API Key Voicegen: {'[SET]' if key_set else '[NOT SET!]'}")
        print(f"  Engine:           {config.TTS_VOICEGEN_ENGINE}")
        print(f"  Chunk size:       {config.TTS_VOICEGEN_CHUNK_SIZE}")
        print(f"  Threads:          {config.TTS_VOICEGEN_THREAD_COUNT}")
    elif svc == 'lumean':
        key_set = bool(config.TTS_API_KEY_LUMEAN)
        print(f"  API Key Lumean:   {'[SET]' if key_set else '[NOT SET!]'}")
        print(f"  Base URL:         {config.TTS_LUMEAN_BASE_URL}")
        print(f"  Template:         {'[SET]' if config.TTS_VOICE_ID else '[NOT SET!]'}")
    else:
        key_set = bool(config.TTS_API_KEY_MAT3U)
        print(f"  API Key mat3u:    {'[SET]' if key_set else '[NOT SET!]'}")
        print(f"  Model ID:         {config.TTS_MAT3U_MODEL_ID}")
        print(f"  Split type:       {config.TTS_MAT3U_SPLIT_TYPE}")
        print(f"  Max chunk len:    {config.TTS_MAT3U_MAX_CHUNK_LENGTH}")
        print(f"  Split output:     {config.TTS_MAT3U_SPLIT_OUTPUT}")
        print(f"  Auto pause:       {config.TTS_MAT3U_AUTO_PAUSE_ENABLED}")
        if config.TTS_MAT3U_AUTO_PAUSE_ENABLED:
            print(f"  Pause duration:   {config.TTS_MAT3U_AUTO_PAUSE_DURATION}s")
            print(f"  Pause frequency:  every {config.TTS_MAT3U_AUTO_PAUSE_FREQUENCY} chunks")

    print(f"  Transcription:    {config.ASSEMBLYAI_LANGUAGE_CODE}")
    print(f"  Gemini model:     {config.GEMINI_MODEL}")
    print(f"  Clip mode:        video {config.VIDEO_CLIP_MIN_DURATION}-{config.VIDEO_CLIP_MAX_DURATION}s")
    print("=" * 60)


def _interactive_tts_settings() -> dict:
    """Спрашивает настройки TTS у пользователя. Возвращает dict с перегрузками."""
    overrides = {}

    print()
    print("=" * 60)
    print("  TTS INTERACTIVE SETUP")
    print("=" * 60)

    # Сервис
    print()
    print("  TTS service:")
    print("    [1] mat3u  (voicer.mat3u.com) — ElevenLabs")
    print("    [2] csv666 (voiceapi.csv666.ru)")
    print("    [3] Voicegen (api.qw1voicegencore.pro)")
    print("    [4] Lumean (api.lumean.app)")
    print()
    svc_choice = _ask("  Choose [1-4]", "1")
    overrides['service'] = {
        '1': 'mat3u', '2': 'csv666', '3': 'voicegen', '4': 'lumean'
    }.get(svc_choice, 'mat3u')
    svc = overrides['service']

    if svc == 'mat3u':
        print()
        print("  mat3u model (ElevenLabs):")
        print("    [1] eleven_multilingual_v2  (recommended, quality)")
        print("    [2] eleven_v3               (newest generation)")
        print("    [3] eleven_turbo_v2_5       (fast + quality)")
        print("    [4] eleven_turbo_v2         (fast)")
        print("    [5] eleven_flash_v2_5       (ultra-fast)")
        print("    [6] eleven_flash_v2         (max speed)")
        m = _ask("  Model [1-6]", "1")
        models = {
            '1': 'eleven_multilingual_v2',
            '2': 'eleven_v3',
            '3': 'eleven_turbo_v2_5',
            '4': 'eleven_turbo_v2',
            '5': 'eleven_flash_v2_5',
            '6': 'eleven_flash_v2',
        }
        overrides['model_id'] = models.get(m, 'eleven_multilingual_v2')

        print()
        print("  Split type (how to split text into chunks):")
        print("    [1] smart       (AI-based, recommended)")
        print("    [2] sentences   (by sentences)")
        print("    [3] paragraphs  (by paragraphs)")
        print("    [4] max_length  (by character count)")
        st = _ask("  Split [1/2/3/4]", "1")
        splits = {'1': 'smart', '2': 'sentences', '3': 'paragraphs', '4': 'max_length'}
        overrides['split_type'] = splits.get(st, 'smart')

        overrides['max_chunk_length'] = int(_ask("  Max chunk length (100-1000)", str(config.TTS_MAT3U_MAX_CHUNK_LENGTH)))

        ap = _ask("  Auto pause? (y/n)", "n")
        overrides['auto_pause_enabled'] = ap.lower() == 'y'
        if overrides['auto_pause_enabled']:
            overrides['auto_pause_duration'] = float(_ask("  Pause duration (0.1-30.0 sec)", "0.5"))
            overrides['auto_pause_frequency'] = int(_ask("  Pause every N chunks", "1"))
    elif svc == 'csv666':
        # csv666: модель и voice заданы внутри шаблона (template_uuid)
        # Шаблон создаётся в Telegram-боте csv666
        print()
        print("  csv666: model + voice are inside the template (template_uuid)")
        print("          Create/edit templates via csv666 Telegram bot")
        overrides['chunk_size'] = int(_ask("  Chunk size (500-2000)", str(config.TTS_CSV666_CHUNK_SIZE)))
    elif svc == 'lumean':
        print()
        print("  Lumean: voice + model are inside the template (template UUID)")
        print("          Select the template in the GUI or set TTS_VOICE_ID")
    else:
        print()
        print("  Voicegen: voice is taken from the first line of the script")

    return overrides


def _apply_overrides(overrides: dict):
    """Применяет перегрузки настроек в config (in-place, для текущей сессии)."""
    if 'service' in overrides:
        config.TTS_SERVICE = overrides['service']
    if 'model_id' in overrides:
        config.TTS_MAT3U_MODEL_ID = overrides['model_id']
    if 'split_type' in overrides:
        config.TTS_MAT3U_SPLIT_TYPE = overrides['split_type']
    if 'max_chunk_length' in overrides:
        config.TTS_MAT3U_MAX_CHUNK_LENGTH = overrides['max_chunk_length']
    if 'auto_pause_enabled' in overrides:
        config.TTS_MAT3U_AUTO_PAUSE_ENABLED = overrides['auto_pause_enabled']
    if 'auto_pause_duration' in overrides:
        config.TTS_MAT3U_AUTO_PAUSE_DURATION = overrides['auto_pause_duration']
    if 'auto_pause_frequency' in overrides:
        config.TTS_MAT3U_AUTO_PAUSE_FREQUENCY = overrides['auto_pause_frequency']
    if 'chunk_size' in overrides:
        config.TTS_CSV666_CHUNK_SIZE = overrides['chunk_size']


def _run_pipeline(language: str = None, two_pass: bool = True, clip_mode: str = 'video', post_action: str = None):
    """Запускает agent.py process --run."""
    lang = language or config.ASSEMBLYAI_LANGUAGE_CODE
    cmd = [sys.executable, str(_agent_dir / 'agent.py'), 'process', '--run', '--language', lang]
    if two_pass:
        cmd.append('--two-pass')
    cmd += ['--clip-mode', clip_mode]
    if post_action:
        cmd += ['--post-action', post_action]
    print()
    print("=" * 60)
    print("  LAUNCHING PIPELINE: transcription + direction")
    print(f"  Command: {' '.join(cmd)}")
    print("=" * 60)
    result = subprocess.run(cmd, cwd=str(_agent_dir))
    return result.returncode


# ============================================================================
# MAIN
# ============================================================================

def main():
    mode = 'interactive'
    post_action = None
    clip_mode = None  # None = use default 'video' or interactive choice
    two_pass_override = None  # None = use config.GEMINI_TWO_PASS
    tts_only = False          # только озвучка: пайплайн запускает вызывающая сторона
    file_list_raw = None      # JSON-массив путей — очередь из GUI
    queue_dir_arg = None      # папка очереди
    argv = sys.argv[1:]
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == '--mode' and i + 1 < len(argv):
            mode = argv[i + 1]
            i += 2
        elif arg in ('silent', 'interactive'):
            mode = arg
            i += 1
        elif arg == '--post-action' and i + 1 < len(argv):
            post_action = argv[i + 1]
            i += 2
        elif arg == '--clip-mode' and i + 1 < len(argv):
            clip_mode = argv[i + 1]
            i += 2
        elif arg == '--two-pass':
            two_pass_override = True
            i += 1
        elif arg == '--no-two-pass':
            two_pass_override = False
            i += 1
        elif arg == '--tts-only':
            # Флаг передавался из GUI и раньше молча игнорировался: разбора не
            # было, и silent-режим внизу сам стартовал agent.py process --run со
            # своими дефолтами — лишний оплаченный прогон мимо настроек GUI.
            tts_only = True
            i += 1
        elif arg == '--file-list' and i + 1 < len(argv):
            file_list_raw = argv[i + 1]
            i += 2
        elif arg == '--queue-dir' and i + 1 < len(argv):
            queue_dir_arg = argv[i + 1]
            i += 2
        else:
            i += 1

    base_dir = _agent_dir.parent
    queue_dir = Path(queue_dir_arg) if queue_dir_arg else base_dir / 'pipeline_queue'
    if not queue_dir.is_dir():
        print(f"[ERROR] Queue folder not found: {queue_dir}")
        sys.exit(1)

    if not file_list_raw:
        print("\n[ERROR] TTS runner requires --file-list from the GUI.")
        print("   Select script files in the Pipeline Launcher first.")
        sys.exit(1)
    try:
        script_files = [Path(p) for p in json.loads(file_list_raw)]
    except Exception as _fle:
        print(f"\n[ERROR] --file-list не разобран: {_fle}")
        sys.exit(1)
    _missing = [p for p in script_files if not p.is_file()]
    for _mp in _missing:
        print(f"[ERROR] Файл очереди не найден: {_mp}")
    script_files = [p for p in script_files if p.is_file()]
    if not script_files:
        print("\n[ERROR] Ни один файл из --file-list не существует. Запуск прерван.")
        sys.exit(1)
    print(f"[GUI] File list: {len(script_files)} файл(ов) в порядке очереди")

    print(f"\n  Found {len(script_files)} script file(s):")
    for sf in script_files:
        try:
            vid, txt = parse_script_file(sf)
            print(f"    {sf.name}  [voice: {vid[:20]}...]  [{len(txt)} chars]")
        except Exception as e:
            print(f"    {sf.name}  [ERROR: {e}]")

    # Настройки
    overrides = {}
    if mode == 'interactive':
        overrides = _interactive_tts_settings()
        _apply_overrides(overrides)
    else:
        _print_settings_table()

    print()

    # Обрабатываем каждый скрипт
    generated_audio = []
    tts_failures = []

    # ПАКЕТНЫЙ ПУТЬ: у Voicegen своя очередь, он принимает все задачи разом.
    # Раньше файлы шли строго по одному — следующий ждал, пока доиграет
    # предыдущий, хотя сервис в это время простаивал. На десятке сценариев
    # это десятки лишних минут. В интерактивном режиме не применяем: там
    # человек слушает и правит каждый файл по очереди, пачка ему не нужна.
    _batch_done = set()
    if (config.TTS_SERVICE or '').lower() == 'voicegen' and mode != 'interactive':
        _todo = []
        for _sp in script_files:
            _stem = _sp.stem
            # Аудио кладём РЯДОМ с исходным сценарием: файл очереди лежит в
            # pipeline_queue/, и следующая фаза ищет mp3 ровно по этому пути.
            _out_dir = _sp.parent
            _ready = None
            for _ext in ('.mp3', '.wav', '.m4a'):
                _c = _out_dir / f'{_stem}{_ext}'
                if _c.is_file() and _c.stat().st_size > 1024:
                    _ready = _c
                    break
            if _ready is not None and os.environ.get('TTS_FORCE_REGENERATE', '').lower() not in ('1', 'true', 'yes'):
                continue          # уже озвучено
            _todo.append((_sp, _out_dir / _stem))

        if len(_todo) > 1:
            # ПЕРВЫЙ — сейчас и в одиночку: монтаж ждёт именно его, и пока
            # он озвучивается, все воркеры сервиса заняты только им.
            # ОСТАЛЬНЫЕ — отдельным фоновым процессом: он переживёт выход
            # отсюда, и их озвучка пойдёт ПАРАЛЛЕЛЬНО видеогенерации первого,
            # а не задержит её старт. Раньше пайплайн ждал, пока доиграет вся
            # пачка, хотя первый сценарий был готов через минуту.
            try:
                from modules.tts import run_tts_batch

                print(f"\n  Batch TTS: первый сценарий сейчас, "
                      f"остальные ({len(_todo)-1}) — фоном")
                _res = run_tts_batch(_todo[:1], service=config.TTS_SERVICE)
                for _src, _audio in _res.items():
                    generated_audio.append(_audio)
                    _batch_done.add(Path(_src))

                if len(_todo) > 1 and os.environ.get('TTS_NO_BACKGROUND', '').lower() not in ('1', 'true', 'yes'):
                    _rest = [str(sp) for sp, _o in _todo[1:]]
                    _bg = [sys.executable, str(Path(__file__).resolve()),
                           '--mode', 'silent', '--tts-only',
                           '--file-list', json.dumps(_rest, ensure_ascii=False),
                           '--queue-dir', str(queue_dir)]
                    _env = os.environ.copy()
                    _env['TTS_NO_BACKGROUND'] = '1'      # внук уже не форкает
                    _env['PYTHONIOENCODING'] = 'utf-8'
                    subprocess.Popen(_bg, cwd=str(_agent_dir), env=_env,
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    for _sp, _o in _todo[1:]:
                        _batch_done.add(_sp)
                    print(f"  Batch TTS: {len(_rest)} сценари(ев) ушли в фон — пайплайн стартует сейчас")
            except Exception as _e:
                print(f"  [WARN] Batch TTS failed ({_e}) — иду по одному")

    for script_path in script_files:
        if script_path in _batch_done:
            continue          # уже озвучен пакетом
        stem = script_path.stem
        # Рядом со сценарием в pipeline_queue/. Расширение добавит tts.py.
        output_path = script_path.parent / stem

        # Уже озвученное не переозвучиваем. Повтор задания очереди, продолжение
        # после сбоя или второй запуск пачки раньше отправляли текст в сервис
        # заново: это платит за ту же озвучку дважды и стоит минуты ожидания.
        _existing = None
        for _ext in ('.mp3', '.wav', '.m4a'):
            _candidate = script_path.parent / f'{stem}{_ext}'
            if _candidate.is_file() and _candidate.stat().st_size > 1024:
                _existing = _candidate
                break
        if _existing is not None and os.environ.get('TTS_FORCE_REGENERATE', '').lower() not in ('1', 'true', 'yes'):
            size_kb = _existing.stat().st_size // 1024
            print(f"\n[{script_path.name}] Audio already exists: {_existing.name} ({size_kb} KB) — skip TTS")
            print("  (TTS_FORCE_REGENERATE=1 to voice it again)")
            generated_audio.append(_existing)
            continue

        print(f"\n[{script_path.name}] Starting TTS...")
        try:
            audio_path = run_tts(script_path, output_path, service=config.TTS_SERVICE)
            generated_audio.append(audio_path)
            print(f"  OK: {audio_path}")
        except Exception as e:
            print(f"  [ERROR] TTS failed for {script_path.name}: {e}")
            tts_failures.append((script_path.name, str(e)))
            continue

        if mode == 'interactive':
            print()
            print(f"  Audio ready: {audio_path}")
            print("  Listen to the audio, edit the script if needed, then press Enter.")
            input("  Press Enter to continue... ")

            cont = input("  Continue to next stages? (y/n): ").strip().lower()
            if cont != 'y':
                print("  Skipping pipeline for this file.")
                continue

            print()
            print("  Next stages mode:")
            print("    [1] silent      (use .env defaults, no prompts)")
            print("    [2] interactive (ask each step)")
            next_mode = input("  Choose [1/2] (default=1): ").strip()

            if next_mode == '2':
                # interactive: ask each param
                tp_ans = input("  Two-pass direction? (y/n, default=y): ").strip().lower()
                two_pass = tp_ans != 'n'
                cm_ans = input("  Clip mode? (1=video / 2=slideshow, default=1): ").strip()
                cm = 'slideshow' if cm_ans == '2' else 'video'
            else:
                # silent: use config defaults
                two_pass = config.GEMINI_TWO_PASS
                cm = clip_mode or 'video'

            rc = _run_pipeline(two_pass=two_pass, clip_mode=cm, post_action=post_action)
            if rc != 0:
                print(f"\n  [ERROR] Pipeline failed (exit code {rc})")
        else:
            # silent — сразу продолжаем после всех скриптов
            pass

    if tts_failures:
        print(
            f"\n[ERROR] TTS завершён с ошибками: {len(tts_failures)} "
            f"файл(ов) не озвучено. Следующая фаза pipeline заблокирована."
        )
        for failed_name, reason in tts_failures:
            print(f"  - {failed_name}: {reason}")
        sys.exit(1)

    # В silent режиме запускаем pipeline один раз после всех TTS.
    # При --tts-only пайплайн запускает вызывающая сторона (GUI второй фазой,
    # со своими настройками и слепком файла) — здесь только озвучка.
    if mode == 'silent' and generated_audio and not tts_only:
        two_pass = two_pass_override if two_pass_override is not None else config.GEMINI_TWO_PASS
        rc = _run_pipeline(two_pass=two_pass, clip_mode=clip_mode or 'video', post_action=post_action)
        if rc != 0:
            print(f"\n[ERROR] Pipeline failed (exit code {rc})")
            sys.exit(rc)

    print("\n[OK] TTS Runner complete.")


if __name__ == '__main__':
    main()
