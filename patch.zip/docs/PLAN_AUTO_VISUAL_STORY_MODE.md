# План внедрения режима Auto Visual Story в VARAGENT API

Дата: 2026-08-18  
Статус: планирование, код не изменяется  
Источник идеи: `C:\Users\VARGART\Downloads\auto_visual_story_builder_spec.md`

## 1. Решение

Не создавать отдельный Auto Visual Story Builder. Реализовать его как новый режим
работы существующего пайплайна VARAGENT:

```text
Auto Visual Story
  audio
    -> transcription с word timestamps
    -> semantic scene plan
    -> deterministic context packets
    -> visual decision/query creator
    -> EPF / Real Photo candidate pipeline
    -> vision selection
    -> still-image motion / Ken Burns
    -> existing Concat
    -> final.mp4
```

Режим должен быть отдельной веткой поведения. Обычные `video`, `vislide`,
AI ImageGen, VideoGen, Real Photo и Stock не должны менять контракт без явного
выбора нового режима.

Предлагаемые внутренние идентификаторы:

```text
story_mode=auto_visual_story
clip_mode=vislide
visual_strategy=new_search|reuse_previous
```

`clip_mode=vislide` используется как существующий renderer-путь для статических
изображений. Новый режим отвечает за смысловую разметку и выбор визуалов, а не
за второй renderer.

## 2. Что уже есть и что переиспользуем

### Вход и транскрипция

- `agent/modules/transcriber.py`
  - AssemblyAI;
  - `ASSEMBLYAI_SEGMENTATION_MODE=words` уже умеет получать слово как элемент
    с `start`/`end`;
  - существующие `transcription.json`, SRT и проверки таймингов.
- `agent/modules/validator.py`
  - проверки длительности, порядка, перекрытий и покрытия аудио.

Для нового режима нужен нормализованный word-level слой, но не отдельный STT
провайдер. Текущие sentence/paragraph сегменты можно сохранить для обычных
режимов и дополнить `words` либо отдельным `transcription_words.json`.

### Director

- `agent/modules/director.py`
  - существующий Pass 1, Pass 2, chunking, continuation, retry и JSON-парсинг;
  - существующие backend/fallback-механизмы.
- `agent/modules/chat_director.py`,
  `agent/modules/gpt_director.py`,
  `agent/modules/claude_*_director.py`,
  `agent/modules/script_director.py`
  - готовые провайдерные пути, которые нужно использовать через общий адаптер.
- `agent/prompts/director_instruction*.txt`
  - текущие контракты обычного montage plan.

Для Auto Visual Story нужен отдельный structured-output контракт. Не следует
перегружать текущий обычный Pass 1 полями контекста до тех пор, пока новый
режим не пройдет тесты.

### Архивные изображения и EPF

- `agent/modules/real_photo.py`
  - выбор клипов;
  - генерация запросов;
  - EPF automatic bridge;
  - импорт кандидата;
  - fallback на архивные источники;
  - `real_photo_pending`, `real_photo`, credits и query log.
- `agent/modules/real_photo_markup.py`
  - директива разметки Real Photo-клипов.
- `agent/modules/clip_sources.py`
  - единый реестр source-маркеров и фильтрация ImageGen/VideoGen.
- `agent/tools/extreme_picture_finder_bridge.py`
  - фактический EPF job/ingest contract; перед внедрением проверить реальный
    API этого моста, не выводить его из названий файлов.

EPF должен остаться сборщиком кандидатов. Context Packet не передается внутрь
EPF целиком: EPF получает короткий поисковый запрос и `clip_id`, а расширенный
контекст сохраняется в артефактах VARAGENT для vision selector и отладки.

### Render и concat

- `video_concat.py`
  - изображение уже превращается в клип заданной длительности;
  - Ken Burns, pan/zoom, blur-fill для архивных кадров;
  - статические источники и fallback на `generated/`;
  - transitions, fps, resolution и metadata.
- `varagent.py`
  - ConcatQueue и readiness guard;
  - существующий `vislide`;
  - финальные стадии и прогресс GUI.

Новый режим не должен добавлять отдельный FFmpeg renderer в MVP.

## 3. Целевой pipeline-режим

### 3.1 Вход

Минимальный вход:

```text
audio file
optional style guide
language
director provider/model
EPF enabled
vision provider/model
render settings
```

Style guide остается необязательным для visual story. Если он задан, он
влияет на визуальную эстетику, но не должен заменять narrative context.

### 3.2 Стадии

```text
Queue
  -> Transcribe Words
  -> Narrative/Scene Plan
  -> Context Packets
  -> Visual Plans
  -> EPF/Real Photo
  -> Candidate/Vision Selection
  -> Materialize generated/
  -> Vislide/Concat
```

`Music` остается независимой фоновой задачей после получения director plan и
ожидается только на границе concat, как в текущей архитектуре.

### 3.3 Режимы запуска

Нужны три служебных режима для безопасной разработки и resume:

1. **Analyze Only**
   - транскрипция, scene plan, context packets и visual plans;
   - EPF и render не запускаются.
2. **Search Existing Plan**
   - берет существующий `visual_plan.json`;
   - запускает EPF/candidate/vision selection.
3. **Render Existing Selection**
   - берет уже выбранные изображения и manifests;
   - запускает только materialize/vislide/concat.

Полный запуск объединяет все три шага.

## 4. Данные и контракты

### 4.1 Нормализованные слова

Вариант предпочтительный:

```json
{
  "index": 0,
  "text": "слово",
  "start": 0.12,
  "end": 0.39
}
```

Хранение:

```text
transcription.json -> existing segments + words[]
```

или, если обратная совместимость проще:

```text
transcription_words.json
```

Все scene boundaries должны ссылаться на индексы слов, а фактические секунды
вычисляются кодом. LLM не должна придумывать `startTime`/`endTime`.

### 4.2 Scene plan

Расширение `montage_plan.json` допустимо, но для MVP лучше писать отдельный
`visual_story_plan.json`, а после успешной валидации материализовать совместимый
`montage_plan.json`.

Минимальный объект сцены:

```json
{
  "id": 1,
  "word_start_index": 0,
  "word_end_index": 42,
  "startTime": 0.0,
  "endTime": 5.6,
  "text": "текст сцены",
  "chain_id": 1,
  "scene_role": "event|portrait|location|object|abstract|transition",
  "entities": ["subject_id"],
  "reveal_state": "known|hidden|revealed",
  "description": "завершенная визуальная мысль"
}
```

Правила:

- clip IDs последовательные;
- первый clip начинается с 0;
- последний покрывает `audioDuration`;
- нет overlap;
- короткие сцены объединяются deterministic merge pass;
- сцена определяется сменой визуальной мысли, а не фиксированными 5 секундами;
- `chain_id` сохраняется, пока субъект/локация/визуальная ситуация не меняется.

### 4.3 Context Packet

Для каждой сцены создается отдельный JSON:

```json
{
  "scene_id": 1,
  "word_start_index": 0,
  "word_end_index": 42,
  "source_text": "текущая сцена",
  "context_before": ["предыдущие фрагменты"],
  "context_after": ["следующие фрагменты"],
  "chapter_summary": "краткое running summary",
  "entities": {
    "active": ["subject_id"],
    "resolved": {"она": "subject_id"},
    "hidden": [],
    "revealed": []
  },
  "previous_visual": null,
  "visual_history": []
}
```

ContextWindowBuilder должен быть deterministic и тестируемым без LLM. LLM
получает уже собранный packet, а не весь транскрипт и не голую текущую фразу.

### 4.4 Visual Plan

```json
{
  "scene_id": 1,
  "visual_strategy": "new_search",
  "visual_intent": "конкретное описание того, что должно быть на экране",
  "search_query": "short specific English query",
  "fallback_queries": [
    "alternative query"
  ],
  "preferred_source": "epf|archive|stock|reuse",
  "negative_constraints": [
    "не современный коллаж"
  ],
  "confidence": 0.86,
  "reason": "почему меняется или сохраняется визуал"
}
```

Обязательное правило: сначала `visual_intent`, потом query. Query Creator
может вернуть `reuse_previous`; в этом случае EPF не запускается, а сцена
ссылается на выбранный asset предыдущей сцены/цепочки.

### 4.5 Selection manifest

Для каждого клипа сохранять:

```json
{
  "scene_id": 1,
  "visual_strategy": "new_search",
  "query": "specific query",
  "candidates": [
    {
      "path": "real_photo_candidates/001/02.jpg",
      "source": "extreme_picture_finder",
      "license": "unknown",
      "page_url": ""
    }
  ],
  "selected": {
    "path": "generated/001.jpg",
    "candidate_index": 1,
    "vision_reason": "..."
  }
}
```

Агрегированные файлы проекта:

```text
transcription_words.json
visual_story_plan.json
narrative_map.json
context_packets/001.json
visual_plans.jsonl
visual_history.json
epf_jobs/
real_photo_query_log.json
visual_selections.json
visual_story_state.json
```

Секреты, cookies и signed URLs в эти manifests не записывать.

## 5. Архитектура модулей

Новые модули:

```text
agent/modules/visual_story.py
agent/modules/visual_story_context.py
agent/modules/visual_story_director.py
agent/modules/visual_story_query.py
agent/modules/visual_story_validator.py
agent/prompts/visual_story_scene_plan.txt
agent/prompts/visual_story_query_creator.txt
```

Ответственность:

- `visual_story_context.py`
  - word index -> time mapping;
  - context before/after;
  - running summary;
  - entity/reveal state;
  - visual history;
  - deterministic merge/normalization.
- `visual_story_director.py`
  - вызывает существующий director backend;
  - получает scene plan в strict JSON;
  - выполняет retry/fallback через существующие provider helpers;
  - не пишет обычные image prompts.
- `visual_story_query.py`
  - принимает Context Packet;
  - выдает Visual Plan;
  - валидирует strategy/query;
  - умеет батчировать 3-5 сцен, сохраняя отдельный результат на сцену.
- `visual_story_validator.py`
  - проверяет words, scenes, visual plans, chain IDs, coverage и referential integrity.
- `visual_story.py`
  - оркестратор resume;
  - вызывает EPF/RealPhoto;
  - materialize/reuse;
  - запускает существующий vislide/concat flow;
  - пишет state и progress.

Существующие файлы, которые потребуют точечного расширения:

```text
agent/config.py
agent/agent.py
agent/modules/transcriber.py
agent/modules/validator.py
agent/modules/real_photo.py
agent/modules/clip_sources.py
varagent.py
video_concat.py (только если выявится отсутствие нужного render-параметра)
```

## 6. Интеграция с Real Photo и EPF

### 6.1 Маркировка

Auto Visual Story не должен использовать старое процентное автоназначение
Real Photo как главный режиссерский механизм. Режиссёр сначала выдает
`visual_strategy` и `preferred_source`, после чего оркестратор переводит сцены
в source-маркеры:

```text
new_search + epf      -> real_photo_pending
new_search + archive  -> real_photo_pending
reuse_previous        -> reuse_previous / asset_ref
```

Existing `real_photo.py` должен быть вызван с явным `clip_ids`, а не с повторным
выбором процентов. Это сохраняет авторское решение Director и не позволяет
Real Photo stage переопределить его.

### 6.2 EPF

Порядок для каждого `new_search`:

1. создать EPF job по `clip_id` и `search_query`;
2. скачать кандидатов;
3. сразу после готовности кандидатов запустить vision selection;
4. записать selected manifest;
5. импортировать выбранный файл в `generated/{id:03d}.ext`;
6. обновить `visual_story_state.json`;
7. только после результата дать клип дальнейшему renderer.

Поиск и vision не должны работать как «сначала скачать всё, потом выбрать всё».
Нужен потоковый per-clip pipeline: EPF для следующего клипа идет параллельно с
vision для уже готового клипа.

### 6.3 Fallback

- EPF timeout/error -> fallback query или обычные archive sources;
- vision error -> deterministic candidate policy, например largest valid
  candidate, с явной пометкой `selection_method=deterministic_fallback`;
- no candidate -> `visual_status=unresolved`, не подменять exact-event photo
  случайной картинкой молча;
- `reuse_previous` без предыдущего asset -> превратить в `new_search` только с
  записью причины;
- полный отказ внешних источников -> остановить режим с понятным отчетом либо
  использовать явно включенный AI fallback, но не скрытно.

## 7. GUI

В существующем Pipeline Launcher добавить режим в карточку
`Transcription + Direction` или отдельную компактную секцию
`Visual Story`.

Минимальные элементы:

```text
Mode:
  Ordinary Pipeline
  Auto Visual Story

Scene boundaries:
  Min duration
  Target duration
  Soft max duration
  Merge short scenes

Context:
  Before fragments
  After fragments
  Dynamic window ON
  Recent visual history length

Visual source:
  EPF / Real Photo
  Archive fallback
  Require real image
  Allow AI fallback

Run:
  Full
  Analyze Only
  Search Existing Plan
  Render Existing Selection
```

При выборе Auto Visual Story:

- video-specific controls не должны создавать обычные AI-клипы;
- `vislide` выбирается автоматически и остается видимым как итоговый render path;
- EPF/vision settings показываются рядом и берутся из существующей Real Photo
  секции;
- обычные percentage controls Real Photo скрываются или блокируются, потому что
  распределение делает visual plan;
- музыка, subtitles, transitions, zoom, fps и concat settings остаются общими.

## 8. CLI и конфигурация

Добавить без поломки старых команд:

```text
agent.py process --run --story-mode auto_visual_story
agent.py run --audio FILE --style FILE --story-mode auto_visual_story
agent.py visual-story --project PROJECT --step analyze
agent.py visual-story --project PROJECT --step search
agent.py visual-story --project PROJECT --step render
```

Первая реализация может использовать существующие `process --run` и
`--post-action`, если новый `visual-story` subcommand даст лишнюю поверхность.
Но state-файлы и resume должны быть доступны без GUI.

Новые config/env ключи:

```text
VISUAL_STORY_MODE
VISUAL_STORY_MIN_SCENE_DURATION
VISUAL_STORY_TARGET_SCENE_DURATION
VISUAL_STORY_MAX_SCENE_DURATION
VISUAL_STORY_CONTEXT_BEFORE
VISUAL_STORY_CONTEXT_AFTER
VISUAL_STORY_VISUAL_HISTORY
VISUAL_STORY_QUERY_BATCH_SIZE
VISUAL_STORY_ALLOW_REUSE
VISUAL_STORY_ALLOW_AI_FALLBACK
VISUAL_STORY_REQUIRE_WORD_TIMESTAMPS
VISUAL_STORY_EPf_TIMEOUT
```

Название ключа для EPF привести к единому upper-case стилю проекта, например
`VISUAL_STORY_EPF_TIMEOUT`; опечатку `EPf` выше не реализовывать.

## 9. Фазы реализации

### Phase 0 — аудит и контракт

- подтвердить реальные функции EPF bridge и vision selector;
- подтвердить текущий формат AssemblyAI words;
- проверить, что `vislide` покрывает все нужные still-image cases;
- определить, где живет runtime state и как его resume-ить;
- зафиксировать JSON schemas и версии контрактов.

Результат: только audit note и schemas, без изменения pipeline behavior.

### Phase 1 — deterministic context layer

- добавить нормализованные words;
- реализовать `ContextPacket`;
- реализовать `NarrativeState` и visual history;
- добавить unit tests для pronoun, reveal, contrast, metaphor и new entity;
- добавить `context_packets/` и debug output.

На этой фазе не запускать EPF и не менять GUI full run.

### Phase 2 — semantic scene planner

- добавить отдельный Auto Visual Story Pass 1;
- strict JSON parser;
- mapping word indices -> start/end;
- merge short scenes;
- timeline validation;
- сохранить `visual_story_plan.json`;
- добавить Analyze Only в CLI.

Обычный Director Pass 1 не менять по умолчанию.

### Phase 3 — Query Creator

- добавить `visual_story_query_creator.txt`;
- реализовать `new_search`/`reuse_previous`;
- добавить `visual_intent`, fallback queries и negative constraints;
- validation без EPF;
- cache по hash Context Packet + provider/model/prompt version.

### Phase 4 — EPF/vision streaming

- адаптировать существующий Real Photo/EPF путь к явному списку clip IDs;
- запускать per-clip candidate download -> vision -> import;
- сохранять candidates/selection/provenance;
- добавить Search Existing Plan;
- покрыть timeout, retry, no-match и deterministic fallback.

### Phase 5 — renderer integration

- materialize selected images в `generated/`;
- переиспользовать `vislide` и `video_concat.py`;
- добавить `Render Existing Selection`;
- проверить Ken Burns, portrait images, transitions и exact audio coverage;
- не добавлять новый FFmpeg pipeline без доказанной необходимости.

### Phase 6 — GUI и полный режим

- добавить выбор Auto Visual Story;
- подключить snapshot настроек;
- прогресс по новым подстадиям;
- полный запуск и resume;
- блокировка несовместимых AI video controls;
- human-readable summary и ссылки на debug artifacts.

### Phase 7 — hardening и portable

- regression suite обычного pipeline;
- e2e на коротком audio;
- тест на длинном audio/chunking;
- проверка отмены, повторного запуска и частично готового EPF;
- backup перед изменениями;
- синхронизация API -> PORTABLE;
- MD5/compile/help checks.

## 10. Тестовый план

### Unit

- word index mapping;
- context before/after;
- running summary state;
- entity resolution;
- reveal state;
- visual history;
- `reuse_previous`;
- merge short scenes;
- gap/overlap/coverage;
- strict Visual Plan validation.

### Integration без сети

- synthetic transcription -> scene plan;
- scene plan -> Context Packets;
- Context Packets -> mocked Query Creator;
- mocked visual plans -> fake EPF manifests;
- selected images -> existing concat fixture.

### Live/optional

- один короткий voiceover;
- 3-5 смысловых сцен;
- EPF candidates;
- vision selection;
- render and audio duration check.

Тесты с живыми API не должны быть обязательными для обычного CI.

## 11. Критерии готовности MVP

MVP считается готовым, если:

1. пользователь выбирает Auto Visual Story в существующем GUI;
2. один audio запускает полный pipeline без ручного промежуточного скрипта;
3. сцены создаются по смыслу, а не по фиксированному интервалу;
4. каждая сцена имеет word indices и корректное время;
5. Query Creator получает Context Packet с before/after, summary, entities и
   visual history;
6. Query Creator умеет `new_search` и `reuse_previous`;
7. EPF получает только короткий query и clip ID;
8. vision получает candidates и visual_intent;
9. selected image сохраняется с provenance;
10. отсутствие кандидата не ломает весь проект и не маскируется;
11. selected stills рендерятся существующим vislide/concat;
12. итоговый MP4 покрывает исходную audio duration;
13. Analyze Only, Search Existing Plan и Render Existing Selection работают;
14. обычные режимы VARAGENT проходят regression tests без изменения поведения.

## 12. Не делать в MVP

- отдельный desktop GUI;
- отдельную базу знаний или vector database;
- сложный autonomous entity graph;
- автоматический subject asset pool;
- полноценный human review editor;
- новую систему лицензирования вместо существующих credits/manifests;
- обязательный новый video generator;
- передавать весь транскрипт Query Creator на каждый запрос;
- молча подменять exact-event photo generic-картинкой;
- переписывать EPF Bridge.

## 13. Основные риски

### Недостаток word timestamps

Режим должен запросить AssemblyAI words и проверить их наличие. Не делать
немой fallback на придуманные LLM секунды.

### Конфликт с текущей разметкой source

Auto Visual Story должен использовать явные clip IDs и не смешивать
процентную Real Photo/Stock политику с собственной visual strategy.

### Повторная генерация

Перед запуском каждого этапа читать state и manifests. `clip_id` должен быть
стабильным от scene plan до selected image и concat.

### EPF медленный или зависший

Per-clip streaming, timeout, bounded retry и resume важнее максимального
параллелизма. Конец одного клипа не должен ждать весь EPF batch.

### Лицензии

EPF и архивные источники уже имеют разную provenance-модель. Не писать в
картинку неподтвержденную лицензию; хранить source/page URL и статус проверки в
manifest/credits.

## 14. Рекомендуемый порядок коммитов

```text
1. docs + JSON schemas + audit
2. word-level normalization + validators
3. deterministic ContextWindowBuilder + tests
4. Auto Visual Story scene planner + prompt
5. Query Creator + visual plan validator/cache
6. EPF/vision explicit clip-id adapter
7. streaming selection + resume state
8. vislide/concat integration
9. GUI/CLI
10. regression + portable sync
```

Каждый коммит должен сохранять обычный pipeline рабочим. Перед каждой фазой,
которая меняет runtime-код, сделать backup затрагиваемых файлов.

## 15. Итоговая рекомендация

Начинать не с GUI и не с EPF. Первый кодовый вертикальный срез:

```text
synthetic words
  -> ContextWindowBuilder
  -> mocked Visual Plan
  -> fake selected image
  -> existing vislide/concat
```

После этого подключать настоящий Director backend и только потом EPF/vision.
Так проверяется главный продуктовый инвариант: изображение меняется, когда
меняется визуальная мысль, а не потому что прошли N секунд.
