#!/bin/bash
# STAGE 1: QUEUE + PIPELINE (macOS - double click)
# Run: double-click this file in Finder

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR/agent"

# Auto-set execute permissions
chmod +x "$SCRIPT_DIR"/*.command 2>/dev/null

# Check agent.py exists
if [ ! -f "agent.py" ]; then
    echo "ERROR: agent.py not found in $SCRIPT_DIR/agent"
    echo "Press Enter to exit..."
    read
    exit 1
fi

# Open Terminal.app for interactive mode
if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e "tell app \"Terminal\" to do script \"cd '$SCRIPT_DIR' && exec '$0'\""
    exit 0
fi

clear

echo ""
echo "================================================================================"
echo " STAGE 1: QUEUE + PIPELINE"
echo " Source: ready_to_go/   New files only!"
echo "================================================================================"
echo ""

echo " Dubbing language:"
echo ""
echo "   [1] ru  - Russian    (default)"
echo "   [2] en  - English"
echo "   [3] es  - Spanish"
echo "   [4] de  - German"
echo "   [5] fr  - French"
echo "   [6] it  - Italian"
echo "   [7] pt  - Portuguese"
echo "   [8] zh  - Chinese"
echo "   [9] Other (enter code manually)"
echo ""

LANG="ru"
echo -n "  Language [1-9] (Enter = ru): "
read LANG_CHOICE

case "$LANG_CHOICE" in
    1|"") LANG="ru" ;;
    2) LANG="en" ;;
    3) LANG="es" ;;
    4) LANG="de" ;;
    5) LANG="fr" ;;
    6) LANG="it" ;;
    7) LANG="pt" ;;
    8) LANG="zh" ;;
    9) echo -n "  Enter language code: " && read LANG ;;
esac

echo ""
echo " [OK] Language: $LANG"
echo ""

echo " Select direction mode:"
echo ""
echo "   [1]  1-pass  (faster, up to ~15 min / ~200 clips)"
echo "   [2]  2-pass  (long projects, 242+ clips)"
echo ""

TWO_PASS_FLAG=""
echo -n "Enter 1 or 2 and press Enter: "
read CHOICE

case "$CHOICE" in
    1|"")
        TWO_PASS_FLAG=""
        echo ""
        echo " [OK] Mode: 1-pass"
        ;;
    2)
        TWO_PASS_FLAG="--two-pass"
        echo ""
        echo " [OK] Mode: 2-pass"
        ;;
    *)
        echo ""
        echo " [ERROR] Invalid choice. Cancelled."
        echo ""
        echo "Press Enter to exit..."
        read
        exit 1
        ;;
esac

echo ""
echo "================================================================================"
echo ""

echo " Running: python3 agent.py process --run --language $LANG $TWO_PASS_FLAG"
echo ""

python3 agent.py process --run --language "$LANG" $TWO_PASS_FLAG
RESULT=$?

echo ""
echo "================================================================================"
echo " DONE. Check folders in projects/"
echo "================================================================================"
echo ""
echo "NEXT STEP: Open prompts_*.txt and generate video in Veo3"
echo ""
echo "Press Enter to exit..."
read

exit $RESULT
