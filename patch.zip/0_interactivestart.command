#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
chmod +x "$SCRIPT_DIR"/*.command 2>/dev/null
[ -f "$SCRIPT_DIR/.venv/bin/activate" ] && source "$SCRIPT_DIR/.venv/bin/activate"

if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e 'tell app "Terminal" to do script "cd '\''$SCRIPT_DIR'\'' && exec '\''$0'\''"'
    exit 0
fi

clear

echo ""
echo "================================================================================"
echo " 0_INTERACTIVESTART  [TTS + Pipeline]  INTERACTIVE MODE"
echo "================================================================================"
echo ""
echo " Script files from ready_to_go/ will be processed."
echo " You will be asked about each TTS parameter."
echo " After audio is generated, you can listen before continuing."
echo ""

python3 "$SCRIPT_DIR/agent/tools/tts_runner.py" --mode interactive
RESULT=$?

if [ $RESULT -ne 0 ]; then
    echo ""
    echo "[ERROR] TTS Runner failed!"
fi

echo ""
echo "================================================================================"
echo " [OK] 0_INTERACTIVESTART complete!"
echo "================================================================================"
echo "Press Enter to exit..." && read
exit $RESULT
