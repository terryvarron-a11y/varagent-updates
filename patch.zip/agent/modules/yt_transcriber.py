"""
yt_transcriber.py — Транскрибирует видео YouTube канала через AssemblyAI.

Использование из кода:
    from modules.yt_transcriber import run_channel_transcription
    run_channel_transcription(
        channel_url="https://www.youtube.com/@SomeChannel/videos",
        out_dir=Path("projects/channel_subs"),
        max_videos=10,
        sort_mode="latest",   # latest | popular | oldest | random
        ytdlp_path=None,      # auto-detect
        progress_cb=None,     # callback(msg: str, level: str)
        stop_event=None,      # threading.Event для отмены
    )
"""

import os
import sys
import json
import re
import logging
import time
import random
import shutil
import sqlite3
import tempfile
import threading
import subprocess
import requests
from pathlib import Path
from typing import Dict, List, Optional, Callable, Tuple

import config


def _utf8_env() -> dict:
    """Return env dict that forces UTF-8 output from subprocesses (yt-dlp)."""
    env = dict(os.environ)
    env['PYTHONUTF8'] = '1'
    env['PYTHONIOENCODING'] = 'utf-8'
    return env


# Имена куков авторизации Google/YouTube. ЗНАЧЕНИЯ нам не нужны и не читаются —
# только имена, а они в базе браузера лежат открыто (шифруется лишь value).
_YT_AUTH_COOKIE_NAMES = {
    'SID', 'HSID', 'SSID', 'APISID', 'SAPISID',
    '__Secure-1PSID', '__Secure-3PSID', 'LOGIN_INFO',
}

# Кэш автоподбора на процесс: проба стоит секунды, а ответ на прогон один.
_BROWSER_CHOICE: Dict[str, str] = {}

# Признаки того, что куки физически НЕ достались: база занята запущенным
# браузером, DPAPI не расшифровал, профиля нет. Замер 29.08 на живом yt-dlp
# 2026.08.19 (Windows): Chrome — «Could not copy Chrome cookie database»
# (запущенный браузер держит базу), Edge — «Failed to decrypt with DPAPI»,
# Opera отдала 1094 куки, Firefox — 137. Ошибки уходят в stderr, успех и сами
# куки — в stdout.
COOKIE_READ_ERROR_RE = re.compile(
    r"could not copy .{0,30}cookie database|failed to decrypt|"
    r"could not find .{0,30}cookies database|unable to (?:read|open) .{0,30}cookie|"
    r"permission denied .{0,30}cookie|unsupported .{0,20}keyring", re.I)


def _browser_candidates() -> List[Tuple[str, str]]:
    """(имя для yt-dlp, путь профиля) — ВСЕ поддерживаемые браузеры платформы.

    Порядок здесь — только порядок перебора «на равных»; реальный приоритет
    считает `_detect_browser` по наличию логина YouTube в куках."""
    if sys.platform == 'win32':
        return [
            ('firefox', os.path.expandvars(r'%APPDATA%\Mozilla\Firefox\Profiles')),
            ('chrome',  os.path.expandvars(r'%LOCALAPPDATA%\Google\Chrome\User Data')),
            ('edge',    os.path.expandvars(r'%LOCALAPPDATA%\Microsoft\Edge\User Data')),
            ('brave',   os.path.expandvars(r'%LOCALAPPDATA%\BraveSoftware\Brave-Browser\User Data')),
            ('opera',   os.path.expandvars(r'%APPDATA%\Opera Software\Opera Stable')),
            ('vivaldi', os.path.expandvars(r'%LOCALAPPDATA%\Vivaldi\User Data')),
            ('chromium', os.path.expandvars(r'%LOCALAPPDATA%\Chromium\User Data')),
        ]
    if sys.platform == 'darwin':
        home = Path.home()
        return [
            ('firefox', str(home / 'Library/Application Support/Firefox/Profiles')),
            ('chrome',  str(home / 'Library/Application Support/Google/Chrome')),
            ('edge',    str(home / 'Library/Application Support/Microsoft Edge')),
            ('brave',   str(home / 'Library/Application Support/BraveSoftware/Brave-Browser')),
            ('opera',   str(home / 'Library/Application Support/com.operasoftware.Opera')),
            ('safari',  str(home / 'Library/Safari')),
            ('vivaldi', str(home / 'Library/Application Support/Vivaldi')),
        ]
    home = Path.home()
    return [
        ('firefox',  str(home / '.mozilla/firefox')),
        ('chrome',   str(home / '.config/google-chrome')),
        ('chromium', str(home / '.config/chromium')),
        ('brave',    str(home / '.config/BraveSoftware/Brave-Browser')),
        ('opera',    str(home / '.config/opera')),
        ('vivaldi',  str(home / '.config/vivaldi')),
    ]


def _cookie_db_paths(name: str, profile_dir: str) -> List[Path]:
    """Файлы кук-баз браузера (Firefox — cookies.sqlite, Chromium — Network/Cookies)."""
    root = Path(profile_dir)
    if not root.is_dir():
        return []
    if name in ('firefox', 'librewolf'):
        return sorted(root.glob('*/cookies.sqlite'))
    if name == 'safari':
        return []                       # Safari хранит куки в бинарном .binarycookies
    found: List[Path] = []
    for profile in ('Default', 'Profile 1', 'Profile 2', '.'):
        for tail in ('Network/Cookies', 'Cookies'):
            candidate = root / profile / tail
            if candidate.is_file():
                found.append(candidate)
    return found


def _has_youtube_login(name: str, profile_dir: str) -> Optional[bool]:
    """Есть ли в куках браузера ЛОГИН YouTube.

    True — есть, False — нет, None — выяснить не удалось (браузер держит базу
    открытой / формат не читается). Читаем только ИМЕНА куков: значения
    зашифрованы и нам не нужны — расшифровка не делается вообще.

    Зачем: бот-проверку «Sign in to confirm you're not a bot» снимают куки
    ЗАЛОГИНЕННОГО профиля, поэтому такой браузер идёт первым в очереди
    (`browsers_ranked`).

    Искать надо на `.google.com`, а НЕ на youtube.com. До 30.08 здесь стоял
    запрос `host LIKE '%youtube.com'` — и он всегда возвращал «не вошёл», даже
    когда человек залогинен: сессионные куки Google (SID, HSID, SSID, APISID,
    SAPISID, `__Secure-*PSID`) лежат на домене google.com, на youtube.com их
    нет ни одного. Замер на живом Firefox: yt-dlp выгружает 137 куков, среди
    них все семь авторизационных — и все на `.google.com`.

    Из-за этой ошибки приоритет браузеров вырождался: все получали ранг
    «не вошёл», и залогиненный профиль ничем не выделялся."""
    for db in _cookie_db_paths(name, profile_dir):
        tmp_path = None
        try:
            with tempfile.NamedTemporaryFile(prefix='varagent_cookies_', suffix='.sqlite',
                                             delete=False) as tmp:
                tmp_path = Path(tmp.name)
            shutil.copyfile(db, tmp_path)          # база может быть занята браузером
            con = sqlite3.connect(str(tmp_path))
            try:
                tables = {row[0] for row in con.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'")}
                if 'moz_cookies' in tables:
                    query = ("SELECT name FROM moz_cookies "
                             "WHERE host LIKE '%google.com' OR host LIKE '%youtube.com'")
                elif 'cookies' in tables:
                    query = ("SELECT name FROM cookies "
                             "WHERE host_key LIKE '%google.com' OR host_key LIKE '%youtube.com'")
                else:
                    continue
                names = {str(row[0]) for row in con.execute(query)}
            finally:
                con.close()
            if names & _YT_AUTH_COOKIE_NAMES:
                return True
            return False
        except Exception as exc:                   # занята/битая/зашифрована иначе
            logging.debug(f"_has_youtube_login: {name} — не прочитал {db.name}: {exc}")
        finally:
            if tmp_path is not None:
                try:
                    tmp_path.unlink(missing_ok=True)
                except OSError:
                    pass
    return None


def _resolve_ytdlp_for_probe(ytdlp_path: Optional[str] = None) -> str:
    """Тот же поиск, что у ютуб-стадии: имя файла зависит от системы."""
    if ytdlp_path:
        return ytdlp_path
    try:
        from modules.youtube_stage import _yt_dlp_path

        return _yt_dlp_path()
    except Exception:                                # noqa: BLE001
        pass
    root = Path(__file__).parent.parent.parent
    for name in ('yt-dlp.exe', 'yt-dlp_macos', 'yt-dlp_linux', 'yt-dlp'):
        candidate = root / name
        if candidate.is_file():
            return str(candidate)
    return shutil.which('yt-dlp') or 'yt-dlp'


def _cookies_readable(ytdlp: str, name: str) -> bool:
    """Достаёт ли yt-dlp куки этого браузера НА САМОМ ДЕЛЕ.

    Раньше здесь стоял `--cookies-from-browser NAME --version`. Проверено
    29.08: такая проба не открывает базу куков вовсе и возвращает 0 даже для
    браузера, который не установлен, — список «рабочих» браузеров был просто
    списком установленных. У пользователя в логе значилось «доступны браузеры
    chrome, edge», хотя ни один из них куков не отдавал.

    Предсказать это по имени браузера нельзя — тем же замером Opera отдала
    1094 куки, а Chrome и Edge не отдали ничего, причём по разным причинам
    (занятая база против DPAPI). Поэтому спрашиваем сам yt-dlp.

    Проба ниже заставляет yt-dlp реально вскрыть базу — экспортом куков, без
    единого сетевого запроса (URL не передаём, yt-dlp ругнётся на его
    отсутствие уже ПОСЛЕ извлечения). Сами куки уходят в stdout, и мы его
    сознательно выбрасываем в DEVNULL: это секреты, их незачем ни читать, ни
    держать в памяти. Судим по stderr — там и только там появляются ошибки
    извлечения.
    """
    try:
        probe = subprocess.run(
            [ytdlp, '--ignore-config', '--cookies-from-browser', name,
             '--cookies', '-', '--simulate', '--skip-download'],
            stdout=subprocess.DEVNULL,        # там сами куки — не читаем
            stderr=subprocess.PIPE,
            timeout=60, env=_utf8_env(),
        )
    except Exception as exc:                     # noqa: BLE001
        logging.debug(f"_cookies_readable: {name} — проба не выполнилась: {exc}")
        return False
    stderr = probe.stderr
    if isinstance(stderr, bytes):
        stderr = stderr.decode('utf-8', errors='replace')
    problem = COOKIE_READ_ERROR_RE.search(stderr or '')
    if problem:
        logging.debug(f"_cookies_readable: {name} — куки не достались: {problem.group(0)}")
        return False
    return True


def browsers_ranked(ytdlp_path: Optional[str] = None) -> List[str]:
    """ВСЕ браузеры, чьи куки yt-dlp реально может прочитать, по приоритету.

    Приоритет — профили С логином YouTube, затем неизвестные, затем без логина.
    До 29.08 порядок был обратный: залогиненные куки уводят невстраиваемые
    ролики в UNPLAYABLE (улов 25.08), и от них берегли весь прогон. Цена
    оказалась несопоставимой: UNPLAYABLE не встретился НИ РАЗУ ни в одном
    пользовательском логе, а «Sign in to confirm you're not a bot» — то, что
    лечится ровно логином, — положил 112 клипов из 132 за один прогон. Теперь
    бережём от массового отказа, а UNPLAYABLE ловим точечно, на конкретном
    ролике (см. `youtube_stage.UNPLAYABLE_RE`).

    Firefox по-прежнему выше хромиумов, и это сильнее логина: он отдаёт куки
    надёжнее всех, тогда как у хромиумов база то занята запущенным браузером,
    то не расшифровывается. Но список фильтрует не имя браузера, а проба
    `_cookies_readable` — она и решает, кто реально годится.

    Настройка `YTDLP_COOKIES_BROWSER` перекрывает автоподбор; «none/off/нет» →
    пустой список (работаем без куков).
    """
    override = str(getattr(config, 'YTDLP_COOKIES_BROWSER', '') or '').strip().lower()
    if override in ('none', 'off', 'no', 'нет', 'без', 'без куков'):
        return []
    if override:
        return [override]

    installed = [(name, path) for name, path in _browser_candidates() if os.path.isdir(path)]
    ranked: List[Tuple[int, str]] = []
    for name, path in installed:
        logged_in = _has_youtube_login(name, path)
        # Залогиненный профиль вперёд: бот-проверку снимают именно его куки.
        rank = 0 if logged_in is True else (1 if logged_in is None else 2)
        # Firefox выше любого хромиума — см. докстринг.
        if name.lower() != "firefox":
            rank += 10
        ranked.append((rank, name))
    ranked.sort(key=lambda item: item[0])

    ytdlp = _resolve_ytdlp_for_probe(ytdlp_path)
    working: List[str] = []
    for rank, name in ranked:
        if _cookies_readable(ytdlp, name):
            working.append(name)
    if working:
        logging.info("yt-dlp cookies: доступны браузеры %s", ", ".join(working))
    else:
        # Раньше здесь оказывался список установленных браузеров, куки которых
        # на деле не читались, и стадия молча билась в закрытую дверь.
        logging.warning(
            "yt-dlp cookies: куки не читаются ни из одного браузера "
            "(установлены: %s) — работаем без куков. Если ютуб начнёт "
            "требовать «подтвердите, что вы не робот», помогут куки браузера: "
            "надёжнее всего Firefox с входом в аккаунт; хромиумы часто не "
            "отдают базу — закрытый браузер иногда помогает",
            ", ".join(name for _rank, name in ranked) or "ни одного")
    return working


def _detect_browser(ytdlp_path: Optional[str] = None) -> str:
    """Подобрать браузер для yt-dlp --cookies-from-browser.

    Перебираем ВСЕ установленные браузеры (не зашитый порядок), приоритет —
    как в `browsers_ranked`: Firefox выше хромиумов, а внутри — профиль С
    логином YouTube вперёд (29.08 порядок по логину перевернули, обоснование
    там же). Каждый кандидат проверяется реальным вскрытием базы куков
    (`_cookies_readable`), первый рабочий побеждает.

    Настройка `YTDLP_COOKIES_BROWSER` (GUI «Браузер для куков yt-dlp»)
    перекрывает автоподбор; значения `none`/`off`/`нет` → работать без куков
    (возвращается пустая строка — вызывающий код тогда не подставляет флаг)."""
    override = str(getattr(config, 'YTDLP_COOKIES_BROWSER', '') or '').strip().lower()
    if override in ('none', 'off', 'no', 'нет', 'без', 'без куков'):
        return ''
    if override:
        return override
    if 'auto' in _BROWSER_CHOICE:
        return _BROWSER_CHOICE['auto']

    installed = [(name, path) for name, path in _browser_candidates() if os.path.isdir(path)]
    ranked: List[Tuple[int, str, str]] = []
    for name, path in installed:
        logged_in = _has_youtube_login(name, path)
        rank = 0 if logged_in is True else (1 if logged_in is None else 2)
        if name.lower() != 'firefox':
            rank += 10
        ranked.append((rank, name, path))
    ranked.sort(key=lambda item: item[0])

    ytdlp = _resolve_ytdlp_for_probe(ytdlp_path)
    for rank, name, _path in ranked:
        if _cookies_readable(ytdlp, name):
            # rank % 10 — бонус Firefox прибавлен десятками, метка о логине
            # живёт в младшем разряде.
            label = {0: 'с логином YouTube', 1: 'логин неизвестен',
                     2: 'без логина YouTube'}[rank % 10]
            logging.info(f"yt-dlp cookies: выбран {name} ({label})")
            _BROWSER_CHOICE['auto'] = name
            return name
    logging.info("yt-dlp cookies: рабочий браузер не найден — работаем без куков")
    _BROWSER_CHOICE['auto'] = ''
    return ''


def _ensure_node() -> bool:
    """Check if node is available, attempt auto-install if not. Returns True if available."""
    if shutil.which('node'):
        return True
    logging.info("Node.js not found, attempting auto-install...")
    try:
        if sys.platform == 'win32':
            # Try winget first
            if shutil.which('winget'):
                subprocess.run(['winget', 'install', 'OpenJS.NodeJS.LTS',
                               '--accept-source-agreements', '--accept-package-agreements'],
                              capture_output=True, timeout=300)
                if shutil.which('node'):
                    logging.info("Node.js installed via winget")
                    return True
            # Try npm/fnm/nvm — skip, winget is cleanest
            logging.warning("Node.js auto-install failed (no winget?). Brainstorm will work without JS runtimes.")
        elif sys.platform == 'darwin':
            if shutil.which('brew'):
                subprocess.run(['brew', 'install', 'node'], capture_output=True, timeout=300)
                if shutil.which('node'):
                    logging.info("Node.js installed via brew")
                    return True
            logging.warning("Node.js auto-install failed (no brew?)")
        else:
            logging.info("Node.js auto-install not supported on this platform")
    except Exception as e:
        logging.warning(f"Node.js auto-install error: {e}")
    return False


def _run_ytdlp(cmd: list, **kwargs) -> subprocess.CompletedProcess:
    """Run yt-dlp subprocess with correct encoding handling.
    On Windows yt-dlp outputs cp1251, not UTF-8.
    Injects --js-runtimes nodejs if node is available."""
    # Inject common flags after the exe path (cmd[0])
    inject = []
    # Личный конфиг юзера (%APPDATA%\yt-dlp\config.txt) навязывает свой -f и роняет
    # наши вызовы на роликах без такого формата — пайплайн должен быть от него независим.
    if '--ignore-config' not in cmd and '--no-config' not in cmd:
        inject += ['--ignore-config']
    if '--js-runtimes' not in cmd:
        # Как в youtube_stage: ищем ещё и deno, включая свой в agent/tools/,
        # который кладёт кнопка «Установить YouTube-модуль». Без рантайма
        # yt-dlp теряет часть форматов и ловит 403 (разбор 29.08).
        try:
            from tools.youtube_setup import js_runtime_args

            inject += js_runtime_args()
        except Exception:                        # noqa: BLE001
            if shutil.which('node'):             # запасной путь как раньше
                inject += ['--js-runtimes', 'node']
    if '--cookies-from-browser' not in cmd:
        _browser = _detect_browser()
        if _browser:                      # пусто = сознательно работаем без куков
            inject += ['--cookies-from-browser', _browser]
    if inject:
        cmd = [cmd[0]] + inject + cmd[1:]
    kwargs.setdefault('capture_output', True)
    kwargs.setdefault('env', _utf8_env())
    # Read as bytes, decode manually
    kwargs.pop('text', None)
    kwargs.pop('encoding', None)
    kwargs.pop('errors', None)
    result = subprocess.run(cmd, **kwargs)
    # Try UTF-8 first, fallback to cp1251 (Windows Russian locale)
    for enc in ('utf-8', 'cp1251', 'latin-1'):
        try:
            result.stdout = result.stdout.decode(enc)
            break
        except (UnicodeDecodeError, AttributeError):
            continue
    if isinstance(result.stdout, bytes):
        result.stdout = result.stdout.decode('utf-8', errors='replace')
    if isinstance(result.stderr, bytes):
        result.stderr = result.stderr.decode('utf-8', errors='replace')
    return result


# ── AssemblyAI helpers ───────────────────────────────────────────────────────

_POLL_INTERVAL = 10
_MAX_WAIT = 900  # 15 min max per video


def _ms_to_srt(ms: int) -> str:
    h  = ms // 3_600_000; ms -= h * 3_600_000
    m  = ms // 60_000;    ms -= m * 60_000
    s  = ms // 1_000;     ms -= s * 1_000
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def _words_to_srt(words: list, max_chars: int = 60, max_gap_ms: int = 1000) -> str:
    if not words:
        return ""
    groups, group = [], []
    for w in words:
        if group:
            gap = w["start"] - group[-1]["end"]
            text_so_far = " ".join(x["text"] for x in group)
            if gap > max_gap_ms or len(text_so_far) + len(w["text"]) + 1 > max_chars:
                groups.append(group)
                group = []
        group.append(w)
    if group:
        groups.append(group)

    parts = []
    for i, grp in enumerate(groups, 1):
        start = _ms_to_srt(grp[0]["start"])
        end   = _ms_to_srt(grp[-1]["end"])
        text  = " ".join(w["text"] for w in grp)
        parts.append(f"{i}\n{start} --> {end}\n{text}\n")
    return "\n".join(parts)


def _get_segments(transcript_id: str, api_key: str, mode: str = "sentences") -> list:
    """Get sentences or paragraphs from AssemblyAI for a completed transcript."""
    endpoint = "sentences" if mode == "sentences" else "paragraphs"
    url = f"https://api.assemblyai.com/v2/transcript/{transcript_id}/{endpoint}"
    resp = requests.get(url, headers={"authorization": api_key}, timeout=60)
    resp.raise_for_status()
    return resp.json().get(endpoint, [])


def _segments_to_srt(segments: list) -> str:
    """Convert AssemblyAI sentences/paragraphs to SRT format."""
    if not segments:
        return ""
    blocks = []
    for i, seg in enumerate(segments, 1):
        start_ms = seg.get("start", 0)
        end_ms = seg.get("end", 0)
        text = seg.get("text", "").strip()
        if not text:
            continue
        blocks.append(f"{i}\n{_ms_to_srt(start_ms)} --> {_ms_to_srt(end_ms)}\n{text}\n")
    return "\n".join(blocks)


def _srt_to_plain(srt_text: str) -> str:
    """Убирает временные метки и номера блоков — чистый текст."""
    lines, out = srt_text.splitlines(), []
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        # пропускаем номер блока (только цифры)
        if line.isdigit():
            i += 1
            continue
        # пропускаем строку с временем (содержит "-->")
        if "-->" in line:
            i += 1
            continue
        if line:
            out.append(line)
        i += 1
    return " ".join(out)


def _upload_audio(file_path: Path, api_key: str) -> str:
    """Загружает аудиофайл в AssemblyAI, возвращает upload_url."""
    with open(file_path, "rb") as f:
        resp = requests.post(
            "https://api.assemblyai.com/v2/upload",
            headers={"authorization": api_key},
            data=f,
            timeout=300,
        )
    resp.raise_for_status()
    return resp.json()["upload_url"]


def _try_download_subs(vid_id: str, ytdlp: str, lang: str, out_srt: Path, out_txt: Path,
                        log: Callable) -> bool:
    """Try to download auto-subs or manual subs via yt-dlp. Returns True if successful.
    lang='auto' → sub-langs='*' (any available language) + fallback 'en'.
    lang='zh' → also probes zh-Hans/zh-Hant (YouTube использует разные коды для китайского).
    Otherwise: lang + 'en' fallback."""
    tmp_dir = out_srt.parent / "_tmp_subs"
    tmp_dir.mkdir(exist_ok=True)
    tmp_base = str(tmp_dir / vid_id)

    # Build --sub-langs и список кандидатов для поиска .srt файла
    if lang == 'auto':
        _sub_langs_arg = "*"
        _candidates = []  # неизвестны заранее — пройдём все .srt в tmp_dir
    elif lang == 'zh':
        # Generic 'zh' — YouTube часто отдаёт zh-Hans или zh-Hant; пробуем все сразу
        _sub_langs_arg = "zh,zh-Hans,zh-Hant,zh-CN,zh-TW,en"
        _candidates = ['zh', 'zh-Hans', 'zh-Hant', 'zh-CN', 'zh-TW', 'en']
    else:
        _sub_langs_arg = f"{lang},en"
        _candidates = [lang, 'en']

    # Try auto-generated subs first, then manual subs
    for sub_flag in ["--write-auto-subs", "--write-subs"]:
        cmd = [
            ytdlp, "--skip-download",
            sub_flag,
            "--sub-langs", _sub_langs_arg,
            "--sub-format", "srt",
            "--convert-subs", "srt",
            "-o", tmp_base + ".%(ext)s",
            f"https://www.youtube.com/watch?v={vid_id}",
        ]
        try:
            r = _run_ytdlp(cmd, timeout=60)
        except Exception:
            continue

        # Find downloaded .srt file
        if _candidates:
            _scan_langs = _candidates
        else:
            # auto mode — scan whatever was downloaded (vid_id.<lang>.srt)
            _scan_langs = []
            for _f in tmp_dir.glob(f"{vid_id}.*.srt"):
                _parts = _f.name.split('.')
                if len(_parts) >= 3:
                    _scan_langs.append(_parts[-2])
        for try_lang in _scan_langs:
            srt_file = tmp_dir / f"{vid_id}.{try_lang}.srt"
            if srt_file.exists() and srt_file.stat().st_size > 100:
                import shutil
                shutil.copy(str(srt_file), str(out_srt))
                # Convert SRT to plain text
                text_lines = []
                for line in srt_file.read_text(encoding='utf-8', errors='replace').splitlines():
                    line = line.strip()
                    if not line or line.isdigit() or '-->' in line:
                        continue
                    text_lines.append(line)
                out_txt.write_text('\n'.join(text_lines), encoding='utf-8')
                label = "auto-subs" if sub_flag == "--write-auto-subs" else "manual subs"
                log(f"   Субтитры скачаны ({label}, {try_lang}): {out_srt.name}")
                # Cleanup
                try:
                    import shutil as _sh
                    _sh.rmtree(str(tmp_dir), ignore_errors=True)
                except Exception:
                    pass
                return True
    # Cleanup
    try:
        import shutil as _sh
        _sh.rmtree(str(tmp_dir), ignore_errors=True)
    except Exception:
        pass
    return False


def _submit_transcription_once(audio_url: str, api_key: str, speech_models: list) -> str:
    """Отправляет задание на транскрипцию, возвращает transcript_id."""
    resp = requests.post(
        "https://api.assemblyai.com/v2/transcript",
        headers={"authorization": api_key, "content-type": "application/json"},
        json={
            "audio_url": audio_url,
            "language_detection": True,
            "speech_models": speech_models,
        },
        timeout=60,
    )
    resp.raise_for_status()
    return resp.json()["id"]


def _submit_transcription(audio_url: str, api_key: str) -> str:
    models = config.ASSEMBLYAI_SPEECH_MODELS or ["universal-3-pro", "universal-2"]
    attempts = [models]
    attempted = set()
    last_error = None

    while attempts:
        speech_models = attempts.pop(0)
        model_key = tuple(speech_models)
        if model_key in attempted:
            continue
        attempted.add(model_key)

        try:
            return _submit_transcription_once(audio_url, api_key, speech_models)
        except requests.HTTPError as error:
            last_error = error
            response = error.response
            error_text = (
                response.text.lower()
                if response is not None and response.text
                else str(error).lower()
            )
            rejected = []
            for model in models:
                name = re.escape(str(model).lower())
                if re.search(
                    rf"(?:{name}.{{0,100}}(?:deprecated|unsupported|invalid|not available|not enabled)"
                    rf"|(?:deprecated|unsupported|invalid|not available|not enabled).{{0,100}}{name})",
                    error_text,
                ):
                    rejected.append(model)
            suggested = list(dict.fromkeys(re.findall(
                r"\b(?:universal|best)[-.][a-z0-9.-]+",
                error_text,
            )))
            candidates = [
                model for model in models
                if model not in rejected and (model,) not in attempted
            ]
            candidates.extend(
                model for model in suggested
                if (model,) not in attempted and model not in candidates
            )
            if not candidates:
                break
            print(
                f"[WARN] AssemblyAI rejected: {', '.join(rejected) or 'requested models'}; "
                f"trying individually: {', '.join(candidates)}"
            )
            attempts.extend([[model] for model in candidates])

    if last_error is not None:
        raise last_error
    raise RuntimeError("AssemblyAI: failed to create transcription task")


def _wait_result(transcript_id: str, api_key: str,
                 stop_event: Optional[threading.Event] = None,
                 progress_cb=None) -> dict:
    url = f"https://api.assemblyai.com/v2/transcript/{transcript_id}"
    headers = {"authorization": api_key}
    elapsed = 0
    while elapsed < _MAX_WAIT:
        if stop_event and stop_event.is_set():
            raise InterruptedError("Cancelled")
        resp = requests.get(url, headers=headers, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        status = data["status"]
        if status == "completed":
            return data
        if status == "error":
            raise RuntimeError(f"AssemblyAI error: {data.get('error')}")
        time.sleep(_poll_interval := _POLL_INTERVAL)
        elapsed += _poll_interval
        if progress_cb:
            progress_cb(f"   [{elapsed}s] {status}...", "INFO")
    raise TimeoutError(f"Timeout after {_MAX_WAIT}s")


# ── yt-dlp helpers ───────────────────────────────────────────────────────────

def _find_ytdlp(ytdlp_path: Optional[str] = None) -> str:
    if ytdlp_path and Path(ytdlp_path).exists():
        return ytdlp_path
    # рядом со скриптом varagent.py
    candidates = [
        Path(__file__).parent.parent.parent / "yt-dlp.exe",
        Path(__file__).parent.parent.parent / "yt-dlp",
    ]
    for c in candidates:
        if c.exists():
            return str(c)
    # в PATH
    return "yt-dlp"


def _get_channel_name(channel_url: str, ytdlp: str) -> str:
    """Возвращает реальное имя канала через yt-dlp.
    --flat-playlist не отдаёт channel metadata, поэтому используем
    --skip-download --playlist-items 1 для получения полной метадаты одного видео."""
    _bad = {"NA", "na", "N/A", "n/a", "None", ""}
    for field in ("%(channel)s", "%(uploader)s"):
        cmd = [ytdlp, "--playlist-items", "1", "--skip-download",
               "--print", field,
               channel_url]
        result = _run_ytdlp(cmd)
        for line in result.stdout.splitlines():
            val = line.strip()
            if val and val not in _bad:
                return val
    # Fallback: parse @handle from URL
    url_clean = channel_url.rstrip("/")
    if "/@" in url_clean:
        return url_clean.split("/@")[-1].split("/")[0]
    if "/c/" in url_clean or "/channel/" in url_clean:
        return url_clean.split("/")[-1]
    return ""


def _get_video_list(channel_url: str, ytdlp: str,
                    sort_mode: str = "latest",
                    max_videos: int = 0,
                    progress_cb=None) -> list:
    """Возвращает список видео [{id, title, date, view_count, duration}].
    sort_mode: latest | popular | oldest | random
    max_videos: 0 = все
    Автоматически фильтрует YouTube Shorts (duration <= 60s).
    """
    cmd = [ytdlp, "--flat-playlist", "--print", "%(id)s\t%(title)s\t%(upload_date)s\t%(view_count)s\t%(duration)s\t%(webpage_url)s",
           channel_url]
    if progress_cb:
        progress_cb("Получаем список видео...", "INFO")
    result = _run_ytdlp(cmd)
    if result.returncode != 0 and result.stderr:
        # Log yt-dlp errors so they're visible (cookie lock, auth issues, etc.)
        for err_line in result.stderr.strip().splitlines()[:5]:
            if progress_cb:
                progress_cb(f"  yt-dlp: {err_line.strip()}", "WARNING")
            logging.warning(f"yt-dlp list: {err_line.strip()}")
    videos = []
    shorts_filtered = 0
    for line in result.stdout.splitlines():
        parts = line.strip().split("\t")
        if len(parts) >= 2 and parts[0].strip():
            vid_id = parts[0].strip()
            title  = parts[1].strip() if len(parts) > 1 else vid_id
            date   = parts[2].strip() if len(parts) > 2 else "00000000"
            views  = int(parts[3].strip()) if len(parts) > 3 and parts[3].strip().isdigit() else 0
            duration_str = parts[4].strip() if len(parts) > 4 else "0"
            webpage_url = parts[5].strip() if len(parts) > 5 else ""

            try:
                duration = int(float(duration_str)) if duration_str and duration_str != "NA" else 0
            except ValueError:
                duration = 0

            # Skip YouTube Shorts - check URL first (100% reliable)
            if "/shorts/" in webpage_url:
                shorts_filtered += 1
                continue

            # Fallback: skip by duration if known (<=180s / 3 min)
            if 0 < duration <= 180:
                shorts_filtered += 1
                continue

            videos.append({"id": vid_id, "title": title, "date": date, "views": views, "duration": duration})

    if sort_mode == "latest":
        videos.sort(key=lambda v: v["date"], reverse=True)
    elif sort_mode == "oldest":
        videos.sort(key=lambda v: v["date"])
    elif sort_mode == "popular":
        videos.sort(key=lambda v: v["views"], reverse=True)
    elif sort_mode == "random":
        random.shuffle(videos)

    if max_videos and max_videos > 0:
        videos = videos[:max_videos]

    if progress_cb:
        msg = f"Найдено видео: {len(videos)}"
        if shorts_filtered > 0:
            msg += f" (пропущено Shorts: {shorts_filtered})"
        progress_cb(msg, "INFO")
    return videos


def _download_audio(vid_id: str, ytdlp: str, tmp_dir: Path,
                    progress_cb=None) -> Path:
    """Скачивает аудио видео в tmp_dir, возвращает путь к файлу."""
    yt_url = f"https://www.youtube.com/watch?v={vid_id}"
    out_tmpl = str(tmp_dir / f"{vid_id}.%(ext)s")
    cmd = [ytdlp,
           "--extract-audio", "--audio-format", "mp3", "--audio-quality", "5",
           "--no-playlist",
           "-o", out_tmpl,
           yt_url]
    result = _run_ytdlp(cmd)
    # Debug: log what yt-dlp said
    logging.info(f"yt-dlp audio stdout: {(result.stdout or '')[-500:]}")
    logging.info(f"yt-dlp audio stderr: {(result.stderr or '')[-500:]}")
    logging.info(f"yt-dlp audio returncode: {result.returncode}")
    logging.info(f"yt-dlp looking for audio in: {tmp_dir}")
    # List what's actually in tmp_dir
    if tmp_dir.exists():
        found = list(tmp_dir.iterdir())
        logging.info(f"yt-dlp tmp_dir contents: {[f.name for f in found]}")
    for ext in ("mp3", "m4a", "opus", "webm", "ogg", "wav"):
        p = tmp_dir / f"{vid_id}.{ext}"
        if p.exists():
            return p
    # Fallback: any audio file in tmp_dir with vid_id in name
    for f in tmp_dir.iterdir():
        if vid_id in f.name and f.suffix in ('.mp3', '.m4a', '.opus', '.webm', '.ogg', '.wav'):
            logging.info(f"yt-dlp fallback match: {f.name}")
            return f
    raise RuntimeError("Audio file not found after yt-dlp download")


# ── Main public function ─────────────────────────────────────────────────────

def run_channel_transcription(
    channel_url: str,
    out_dir: Path,
    max_videos: int = 0,
    sort_mode: str = "latest",
    ytdlp_path: Optional[str] = None,
    progress_cb: Optional[Callable] = None,
    stop_event: Optional[threading.Event] = None,
    try_subs_first: bool = False,
    subs_lang: str = "ru",
    seg_mode: str = "sentences",
) -> dict:
    """
    Транскрибирует видео YouTube-канала через AssemblyAI.

    Сохраняет в out_dir:
      - {date}_{title}_{id}.srt         — субтитры с метками времени
      - {date}_{title}_{id}.txt         — чистый текст (скрипт)
      - 0_split_{channel_slug}.txt  — все скрипты в одном файле

    Возвращает: {"done": N, "total": M, "srt_dir": str(out_dir)}
    """

    def log(msg, level="INFO"):
        if progress_cb:
            progress_cb(msg, level)

    # Ensure Node.js is available for yt-dlp JS runtimes
    if not shutil.which('node'):
        log("Node.js не найден, пробуем установить...", "WARNING")
        if _ensure_node():
            log("Node.js установлен", "SUCCESS")
        else:
            log("Node.js не установлен — продолжаем без JS runtimes", "WARNING")

    # Detect browser for cookies
    detected_browser = _detect_browser()
    log(f"Cookies browser: {detected_browser or 'без куков'}")

    api_key = getattr(config, "ASSEMBLYAI_API_KEY", "") or os.getenv("ASSEMBLYAI_API_KEY", "")
    if not api_key:
        raise RuntimeError("ASSEMBLYAI_API_KEY не задан в config/.env")

    ytdlp = _find_ytdlp(ytdlp_path)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Получаем реальное имя канала и список видео
    channel_name = _get_channel_name(channel_url, ytdlp)
    videos = _get_video_list(channel_url, ytdlp, sort_mode, max_videos, log)
    if not videos:
        log("Нет видео на канале или yt-dlp не смог получить список", "ERROR")
        return {"done": 0, "total": 0, "srt_dir": str(out_dir)}

    # Имя папки канала
    if channel_name:
        channel_slug = "".join(c if c.isalnum() or c in " _-" else "_" for c in channel_name)[:60].strip()
    else:
        # Fallback: из URL
        channel_slug = channel_url.rstrip("/").split("/")[-1].lstrip("@")[:40]
        channel_slug = "".join(c if c.isalnum() or c in "-_" else "_" for c in channel_slug)
    log(f"Канал: {channel_name or channel_slug}", "INFO")

    # Подпапка для каждого канала
    out_dir = out_dir / channel_slug
    out_dir.mkdir(parents=True, exist_ok=True)
    tmp_dir = out_dir / "_tmp_audio"
    tmp_dir.mkdir(exist_ok=True)

    split_path = out_dir / f"0_split_{channel_slug}.txt"

    log(f"Транскрибируем {len(videos)} видео → {out_dir}", "INFO")
    done = 0

    for i, v in enumerate(videos, 1):
        if stop_event and stop_event.is_set():
            log("Остановлено пользователем", "WARNING")
            break

        vid_id = v["id"]
        title  = v["title"]
        date   = v["date"]
        safe   = "".join(c if c.isalnum() or c in " _-" else "_" for c in title)[:80].strip()

        srt_path = out_dir / f"{date}_{safe}_{vid_id}.srt"
        txt_path = out_dir / f"{date}_{safe}_{vid_id}.txt"

        if srt_path.exists() and txt_path.exists():
            log(f"[{i}/{len(videos)}] SKIP (уже есть): {srt_path.name}", "INFO")
            # Append skipped to splitscript too
            if txt_path.exists():
                plain = txt_path.read_text(encoding='utf-8', errors='replace').strip()
                if plain:
                    with open(split_path, "a", encoding="utf-8") as sf:
                        sf.write(f"\n\n{'='*60}\n")
                        sf.write(f"## {title}\n")
                        sf.write(f"{'='*60}\n\n")
                        sf.write(plain)
                        sf.write("\n")
            done += 1
            continue

        log(f"[{i}/{len(videos)}] {title[:70]}", "INFO")

        # Try downloading existing subtitles first
        if try_subs_first:
            if _try_download_subs(vid_id, ytdlp, subs_lang, srt_path, txt_path, log):
                # Append to splitscript
                if txt_path.exists():
                    plain = txt_path.read_text(encoding='utf-8', errors='replace')
                    with open(split_path, "a", encoding="utf-8") as sf:
                        sf.write(f"\n\n{'='*60}\n")
                        sf.write(f"# {title}\n")
                        sf.write(f"# {date} | subs\n")
                        sf.write(f"{'='*60}\n\n")
                        sf.write(plain)
                done += 1
                continue
            log(f"   Субтитры не найдены, транскрибируем через AssemblyAI...", "INFO")

        audio_file = None
        try:
            # 1. Скачиваем аудио
            log(f"   Скачиваем аудио...", "INFO")
            audio_file = _download_audio(vid_id, ytdlp, tmp_dir, log)
            sz = audio_file.stat().st_size // 1024
            log(f"   Скачано: {audio_file.name} ({sz} KB)", "INFO")

            # 2. Загружаем в AssemblyAI
            log(f"   Загружаем в AssemblyAI...", "INFO")
            upload_url = _upload_audio(audio_file, api_key)
            log(f"   Загружено OK", "INFO")

            # 3. Транскрибируем
            tid = _submit_transcription(upload_url, api_key)
            log(f"   Транскрибируем ({tid[:8]}...)...", "INFO")
            data = _wait_result(tid, api_key, stop_event, log)
            log("", "INFO")  # clear progress line

            lang     = data.get("language_code", "?")
            duration = data.get("audio_duration", 0)
            words    = data.get("words") or []

            if seg_mode in ("sentences", "paragraphs"):
                try:
                    segments = _get_segments(tid, api_key, seg_mode)
                    srt_text = _segments_to_srt(segments)
                except Exception as _seg_e:
                    log(f"   {seg_mode} failed ({_seg_e}), fallback to words", "WARNING")
                    srt_text = _words_to_srt(words) if words else ""
            elif words:
                srt_text = _words_to_srt(words)
            else:
                text    = data.get("text") or ""
                dur_ms  = int((duration or 0) * 1000)
                srt_text = f"1\n00:00:00,000 --> {_ms_to_srt(dur_ms)}\n{text}\n" if text else ""

            if srt_text:
                srt_path.write_text(srt_text, encoding="utf-8")
                plain = _srt_to_plain(srt_text)
                txt_path.write_text(plain, encoding="utf-8")

                # Дописываем в splitscript
                with open(split_path, "a", encoding="utf-8") as sf:
                    sf.write(f"\n\n{'='*60}\n")
                    sf.write(f"# {title}\n")
                    sf.write(f"# {date} | {lang} | {int(duration or 0)}s\n")
                    sf.write(f"{'='*60}\n\n")
                    sf.write(plain)

                log(f"   OK [{lang}] {len(words)} words → {srt_path.name}", "SUCCESS")
                done += 1
            else:
                log(f"   EMPTY — текст не получен", "WARNING")

        except InterruptedError:
            break
        except Exception as e:
            log(f"   ERROR: {e}", "ERROR")
        finally:
            if audio_file and audio_file.exists():
                try:
                    audio_file.unlink()
                except Exception:
                    pass

        time.sleep(2)

    # Удаляем tmp папку если пустая
    try:
        if tmp_dir.exists() and not any(tmp_dir.iterdir()):
            tmp_dir.rmdir()
    except Exception:
        pass

    log(f"Готово: {done}/{len(videos)} субтитров в {out_dir}", "SUCCESS")
    return {"done": done, "total": len(videos), "srt_dir": str(out_dir)}
