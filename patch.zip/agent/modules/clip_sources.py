"""
clip_sources.py — единый реестр маркеров `source` в montage_plan.json.

Клип с любым из этих маркеров обслуживает ВНЕШНЯЯ стадия (архив или сток), а не
нейрогенерация. ImgGen / FastGen / Veo / FlowUltra обязаны такие клипы пропускать:
иначе картинка сгенерится поверх скачанной — конфликт файлов и сожжённая квота,
причём молча.

Зачем модуль: литерал ('real_photo', 'real_photo_pending', 'real_video') был
скопирован в 7 файлов. Добавление нового источника требовало не забыть ни один —
забыл хоть один, получил двойную генерацию без единой ошибки в логе. Теперь точка
правды одна.

Значения маркеров
-----------------
Real Photo stage (архивные материалы: Wikipedia/NASA/LoC/Archive/Yandex/...):
  real_photo_pending — режиссёр пометил клип, стадия ещё не отработала
  real_photo         — архивное ФОТО скачано (лежит в generated/{id:03d}.{ext})
  real_video         — архивное ВИДЕО готово (лежит в vid_img/{id:03d}.mp4)
                       (видео-путь сейчас отключён, маркер зарезервирован)

Stock stage (Pexels / Pixabay / Coverr — современный постановочный футаж):
  stock_pending      — режиссёр пометил клип, стадия ещё не отработала
  stock_photo        — сток-ФОТО скачано (generated/{id:03d}.{ext}; concat сам
                       сделает Ken Burns)
  stock_video        — сток-ВИДЕО готово (vid_img/{id:03d}.mp4; уже обрезано под
                       длину клипа, zoom не нужен)

Сток и архив намеренно РАЗНЫЕ маркеры: у них разные источники, лицензии и смысл
(архив — исторический материал, сток — современная съёмка), и разные стадии.
"""
from __future__ import annotations

# Архивная стадия (real_photo.py)
REAL_PHOTO_SOURCES = frozenset({
    'real_photo',
    'real_photo_pending',
    'real_video',
})

# Стоковая стадия (Pexels/Pixabay/Coverr)
STOCK_SOURCES = frozenset({
    'stock_pending',
    'stock_photo',
    'stock_video',
})

# Всё, что НЕ должно попасть в нейрогенерацию.
# Именно этот набор проверяют ImgGen/FastGen/Veo/FlowUltra/watch_i2v.
EXTERNAL_SOURCES = REAL_PHOTO_SOURCES | STOCK_SOURCES

# Клипы, чей материал кладётся в vid_img/ готовым видео (concat берёт как фрагмент,
# Ken Burns не применяется).
VIDEO_SOURCES = frozenset({'real_video', 'stock_video'})

# Клипы, чей материал кладётся картинкой в generated/ (concat делает Ken Burns).
PHOTO_SOURCES = frozenset({'real_photo', 'stock_photo'})


def is_external(source: str | None) -> bool:
    """True, если клип обслуживает внешняя стадия и генератор должен его пропустить."""
    return bool(source) and source in EXTERNAL_SOURCES
