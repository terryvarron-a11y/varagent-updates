"""
filesta_envato.py — сток Envato Elements: ПОИСК по публичной выдаче,
ПЛАТНАЯ загрузка мастер-файла через панель Filesta.

Почему два разных канала (метод разведан 28.08, см. docs/ENVATO_FILESTA_METHOD.md):

  • выдача Envato публична — обычный GET отдаёт готовый HTML со всеми карточками,
    браузер и логин для поиска НЕ нужны;
  • сам файл отдаёт только Filesta, где куплена лицензия (300 загрузок в сутки).
    Её защита (proof-of-work, Cloudflare Turnstile, подпись запроса от отпечатка
    устройства) проходится ТОЛЬКО из настоящего Chrome, поэтому загрузка идёт
    через CDP-подключение к пользовательскому браузеру.

Отбор целиком бесплатный: вижн смотрит превью (постер карточки или превью-mp4),
и лишь ПОБЕДИТЕЛЬ стоит одной загрузки из суточной квоты.

Разметка карточки — проверена на сохранённых страницах 31.08, у видео и фото она
РАЗНАЯ (см. `parse_cards`).
"""
from __future__ import annotations

import html as _html
import json
import logging
import os
import queue
import re
import subprocess
import threading
import time
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional

import config

from modules.stock_search import StockResult, _words

logger = logging.getLogger(__name__)

SOURCE = 'filesta_envato'
_BASE = 'https://elements.envato.com'

# Ссылка на ассет: /<slug строчными>-<КОД>, КОД — ровно 7 символов [A-Z0-9] в
# ВЕРХНЕМ регистре. Цифра в коде НЕ обязательна (проверено: 11 карточек из 70
# без единой цифры — REJYWRH, BVRZLYU, RXKAVSM). Регистр отсекает мусор лучше:
# /sound-effects не проходит, потому что effects строчными.
_ASSET_PATH_RE = re.compile(r'^/[a-z0-9][a-z0-9-]*-([A-Z0-9]{7})/?$')
# Якорь карточки. Он один и тот же на обеих страницах: 70/70 у видео, 60/60 у
# фото. Искать карточки по классам нельзя — они генерируются сборкой.
_ITEM_LINK_RE = re.compile(r'<a\b[^>]*data-testid="item-link"[^>]*>')
_ATTR_RE = {
    'href': re.compile(r'\bhref="([^"]*)"'),
    'title': re.compile(r'\btitle="([^"]*)"'),
    'aria': re.compile(r'\baria-label="([^"]*)"'),
}
_VIDEO_TAG_RE = re.compile(r'<video\b[^>]*>')
_IMG_TAG_RE = re.compile(r'<img\b[^>]*>')
_IAR_RE = re.compile(r'--iar:\s*([0-9.]+)')
_SRCSET_ITEM_RE = re.compile(r'(https?://[^\s,"]+)\s+(\d+)w')

# Какой ширины постер брать из srcSet. В нём лежат УЖЕ ПОДПИСАННЫЕ адреса на
# 200-800 px, поэтому крупный кадр достаётся бесплатно и без подделки подписи
# (`w` входит в подпись `s=`, вручную её не сменить — отсюда прежний потолок 500
# в заметке разведки). Панель контактного листа вижна — до 900 px, так что 800
# закрывает её целиком.
_POSTER_WIDTH = 800

_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
       '(KHTML, like Gecko) Chrome/122.0 Safari/537.36')


# ── настройки ───────────────────────────────────────────────────────────────

def _home() -> Path:
    """Папка провайдера: отпечаток и профиль Chrome лежат рядом с агентом."""
    raw = str(getattr(config, 'FILESTA_HOME', '') or '').strip()
    if raw:
        return Path(raw).expanduser()
    return Path(__file__).resolve().parents[1] / '.filesta'


def fingerprint_path() -> Path:
    raw = str(getattr(config, 'FILESTA_FINGERPRINT', '') or '').strip()
    return Path(raw).expanduser() if raw else _home() / 'fp_real.json'


def profile_path() -> Path:
    raw = str(getattr(config, 'FILESTA_PROFILE', '') or '').strip()
    return Path(raw).expanduser() if raw else _home() / 'chrome_profile'


def _cdp_url() -> str:
    return str(getattr(config, 'FILESTA_CDP_URL', '') or 'http://127.0.0.1:9222').strip()


def _max_master_mb() -> int:
    try:
        return max(1, int(getattr(config, 'FILESTA_MAX_MASTER_MB', 300) or 300))
    except (TypeError, ValueError):
        return 300


def configured() -> bool:
    """Источник настроен? Без отпечатка загрузка невозможна в принципе."""
    return fingerprint_path().is_file()


# ── поиск: адрес выдачи ─────────────────────────────────────────────────────

def search_url(query: str, media_type: str = 'video',
               target_w: int = 1920, target_h: int = 1080) -> str:
    """Адрес публичной выдачи Envato.

    Фильтры задаются ПУТЁМ, не параметрами: `?orientation=landscape` сервер сам
    перекидывает на путь, а `?orientation=horizontal` игнорирует — полагаться на
    параметры нельзя.

    Слова ориентации у фото и видео РАЗНЫЕ: landscape/portrait/square против
    horizontal/vertical/square. Разрешение видео — только 720p и 1080p: мастер
    приходит в исходном качестве, и у 4K-ассета он бывает на гигабайты
    (замер: 4,3 ГБ против 86 МБ у 1080p).
    """
    slug = urllib.parse.quote(' '.join(str(query or '').split()), safe='')
    if target_h > target_w:
        photo_orient, video_orient = 'portrait', 'vertical'
    elif target_h == target_w:
        photo_orient, video_orient = 'square', 'square'
    else:
        photo_orient, video_orient = 'landscape', 'horizontal'

    if media_type == 'photo':
        return f'{_BASE}/photos/{slug}/orientation-{photo_orient}'
    # `stock-footage` отсекает моушн-графику и оставляет живые съёмки.
    return (f'{_BASE}/stock-video/stock-footage/{slug}'
            f'/orientation-{video_orient}'
            f'/resolution-720p-(hd)+1080p-(full-hd)')


# ── поиск: разбор карточек ──────────────────────────────────────────────────

def _unescape(url: str) -> str:
    """`&amp;` → `&`. Без этого подпись `s=` не сходится и CDN отвечает 403 —
    это не защита, а наша же ошибка разбора."""
    return _html.unescape(str(url or '')).strip()


def _pick_srcset(tag: str, want_width: int = _POSTER_WIDTH) -> str:
    """Самый подходящий адрес из srcSet: ближайший снизу к нужной ширине.

    В srcSet лежат подписанные варианты 200..800 px — берём готовый, а не
    правим `w` в адресе (ширина входит в подпись, подмена даёт 403).
    """
    srcset = re.search(r'\bsrcSet="([^"]*)"', tag, re.I)
    if not srcset:
        return ''
    best_url, best_width = '', -1
    for url, width in _SRCSET_ITEM_RE.findall(_unescape(srcset.group(1))):
        width = int(width)
        if width <= want_width and width > best_width:
            best_url, best_width = url, width
    if best_url:
        return best_url
    # Все варианты крупнее нужного — берём самый мелкий из них.
    items = [(int(w), u) for u, w in _SRCSET_ITEM_RE.findall(_unescape(srcset.group(1)))]
    return min(items)[1] if items else ''


def _attr(tag: str, name: str) -> str:
    match = re.search(rf'\b{name}="([^"]*)"', tag, re.I)
    return _unescape(match.group(1)) if match else ''


def parse_cards(html_text: str, media_type: str = 'video') -> List[Dict[str, Any]]:
    """Карточки выдачи → список словарей. Чистая функция: сети здесь нет,
    поэтому её гоняет офлайн-тест на сохранённых страницах.

    Разметка у видео и фото РАЗНАЯ (проверено на снимках 31.08):

      видео: <video src=ПРЕВЬЮ.mp4 poster=ПОСТЕР> … <img alt> … затем
             <a data-testid="item-link" aria-label="ЗАГОЛОВОК" href="/slug-КОД">
             — медиа стоит ПЕРЕД ссылкой, заголовок в `aria-label`;

      фото:  <a title="ЗАГОЛОВОК" data-testid="item-link" href="/slug-КОД">
                 <img srcSet=… src=…>
             </a>
             — медиа ВНУТРИ ссылки, заголовок в `title`.

    Заголовок берём у самой ссылки, а НЕ из `img[alt]`: первые `alt` на странице
    принадлежат шапке сайта («Envato», «PremiumBeat Content Feature»), и разбор
    по ним даёт мусор вместо названия ассета.
    """
    cards: List[Dict[str, Any]] = []
    seen: set = set()
    for match in _ITEM_LINK_RE.finditer(html_text):
        tag = match.group(0)
        href = _attr(tag, 'href')
        path = urllib.parse.urlparse(href).path or href
        code_match = _ASSET_PATH_RE.match(path)
        if not code_match:
            continue
        code = code_match.group(1)
        if code in seen:
            continue
        seen.add(code)

        title = _attr(tag, 'aria-label') or _attr(tag, 'title')
        # У фото заголовок иногда идёт с приставкой «Preview: ».
        title = re.sub(r'^preview:\s*', '', title, flags=re.I).strip()

        preview_url = poster_url = ''
        aspect = 0.0
        if media_type == 'video':
            # ПОСЛЕДНИЙ <video> перед ссылкой — он и принадлежит этой карточке.
            # «Первый <video> после ссылки» даёт превью СОСЕДНЕГО ролика: вижн
            # смотрел бы одно, а покупали бы другое (грабли разведки 28.08).
            head = html_text[:match.start()]
            video_tags = _VIDEO_TAG_RE.findall(head[-6000:])
            if video_tags:
                video_tag = video_tags[-1]
                preview_url = _unescape(_attr(video_tag, 'src'))
                poster_url = _unescape(_attr(video_tag, 'poster'))
            img_tags = _IMG_TAG_RE.findall(head[-6000:])
            if img_tags and not poster_url:
                poster_url = _pick_srcset(img_tags[-1]) or _attr(img_tags[-1], 'src')
            elif img_tags:
                # Из srcSet берём кадр покрупнее постера плеера (тот всегда w=500).
                bigger = _pick_srcset(img_tags[-1])
                if bigger:
                    poster_url = bigger
            iar = _IAR_RE.findall(head[-6000:])
            if iar:
                try:
                    aspect = float(iar[-1])
                except ValueError:
                    aspect = 0.0
        else:
            # У фото картинка лежит ВНУТРИ ссылки — смотрим вперёд, до её конца.
            tail = html_text[match.end():match.end() + 8000]
            close = tail.find('</a>')
            if close > 0:
                tail = tail[:close]
            img_match = _IMG_TAG_RE.search(tail)
            if img_match:
                img_tag = img_match.group(0)
                poster_url = _pick_srcset(img_tag) or _unescape(_attr(img_tag, 'src'))

        cards.append({
            'code': code,
            'page_url': _BASE + path.rstrip('/'),
            'title': title,
            'preview_url': preview_url,
            'poster_url': poster_url,
            'aspect': aspect,
        })
    return cards


def _http_get(url: str, timeout: int = 30) -> str:
    proxy = (getattr(config, 'STOCK_PROXY_URL', '') or '').strip()
    opener = urllib.request.build_opener(
        urllib.request.ProxyHandler({'http': proxy, 'https': proxy}) if proxy
        else urllib.request.ProxyHandler({})
    )
    request = urllib.request.Request(url, headers={
        'User-Agent': _UA,
        'Accept': 'text/html,application/xhtml+xml',
        'Accept-Language': 'en-US,en;q=0.9',
    })
    with opener.open(request, timeout=timeout) as response:
        return response.read().decode('utf-8', 'replace')


def search_filesta_envato(query: str, media_type: str = 'video', limit: int = 20,
                          target_w: int = 1920, target_h: int = 1080) -> List[StockResult]:
    """Та же сигнатура, что у остальных источников стока.

    `limit` — сколько карточек взять СО СТРАНИЦЫ: выдача отдаёт 60-70 разом,
    пагинацию не трогаем, этого хватает с запасом.
    """
    if not str(query or '').strip():
        return []
    url = search_url(query, media_type, target_w, target_h)
    try:
        html_text = _http_get(url)
    except Exception as exc:                                # noqa: BLE001
        logger.warning("%s: выдача не открылась (%s): %s", SOURCE, type(exc).__name__, exc)
        return []

    cards = parse_cards(html_text, media_type)
    if not cards:
        logger.info("%s: по «%s» карточек не нашлось", SOURCE, str(query)[:50])
        return []

    results: List[StockResult] = []
    for card in cards[:max(1, int(limit))]:
        title = card['title'] or card['code']
        results.append(StockResult(
            source=SOURCE,
            media_type=media_type,
            # `url` — ключ дедупа `used_urls` и адрес для платной загрузки.
            # Конечного файла здесь НЕТ: он появится только после покупки, о чём
            # и говорит `preview_only`.
            url=card['page_url'],
            page_url=card['page_url'],
            title=title,
            keywords=_words(title),
            license_name='Envato Elements subscription',
            preview_url=card['preview_url'],
            poster_url=card['poster_url'],
            preview_only=True,
            asset_id=card['code'],
        ))
    logger.info("%s: «%s» → %d карточек (%s)", SOURCE, str(query)[:40],
                len(results), media_type)
    return results


# ── платная загрузка: один браузер, очередь, пачки ──────────────────────────

# Подпись запроса и решение time-lock живут В СТРАНИЦЕ: нужен доступ к
# localStorage (sessionId, accessToken, csrf) и crypto.subtle. Скрипт — перенос
# отлаженного docs/envato_filesta_download.py, с одной правкой: он принимает
# СПИСОК ссылок и отдаёт список ответов, чтобы пачка уходила одним заходом.
_REQUEST_JS = """
async (args) => {
  const {items, fp} = args;
  const clean = (v) => (v || '').replace(/^"|"$/g, '');
  const hex = (b) => Array.from(new Uint8Array(b))
      .map(x => x.toString(16).padStart(2, '0')).join('');
  const sha256 = async (s) => hex(await crypto.subtle.digest(
      'SHA-256', new TextEncoder().encode(s)));
  const hmac = async (msg, key) => {
    const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(key),
        {name: 'HMAC', hash: 'SHA-256'}, false, ['sign']);
    return hex(await crypto.subtle.sign('HMAC', k, new TextEncoder().encode(msg)));
  };
  const nonce = () => {
    const a = new Uint8Array(16); crypto.getRandomValues(a);
    return Array.from(a).map(b => b.toString(16).padStart(2, '0')).join('');
  };
  // time-lock: k возведений в квадрат по модулю, ускорить нельзя (в этом смысл)
  const solve = (x, k, n) => {
    const a = BigInt('0x' + n); let v = BigInt('0x' + x) % a;
    for (let i = 0; i < k; i++) v = (v * v) % a;
    return v.toString(16);
  };

  const sessionId = clean(localStorage.getItem('sessionId'));
  const secret = (await sha256('filesta:download:' + sessionId)).substring(0, 32);
  const parts = [`sr:${fp.screenResolution}`, `cd:${fp.colorDepth}`,
                 `tz:${fp.timezone}`, `lang:${fp.language}`, `plat:${fp.platform}`];
  if (fp.canvas) parts.push(`cv:${fp.canvas}`);
  if (fp.cpuCores) parts.push(`cpu:${fp.cpuCores}`);
  if (fp.deviceMemory) parts.push(`mem:${fp.deviceMemory}`);
  if (fp.touchSupport !== undefined) parts.push(`touch:${fp.touchSupport}`);
  if (fp.webgl) parts.push(`wgl:${fp.webgl}`);
  if (fp.audio) parts.push(`aud:${fp.audio}`);
  if (fp.fonts) parts.push(`fonts:${fp.fonts}`);
  const fpHash = await sha256(parts.sort().join('|'));

  const send = async (itemUrl, extra) => {
    fp.collectedAt = Date.now();       // ОБЯЗАТЕЛЬНО: сервер проверяет свежесть
    const ts = Date.now().toString(), nc = nonce();
    const sig = await hmac(`${ts}:${nc}:${fpHash}:POST:/downloads`,
                           `${secret}:${sessionId}`);
    const csrf = clean(localStorage.getItem('x-csrf-token'));
    const gesture = window.__lastGesture ? Date.now() - window.__lastGesture : 900;
    const len = itemUrl.length;
    const r = await fetch('/api/downloads', {
      method: 'POST', credentials: 'include',
      headers: Object.assign({
        'Accept': 'application/json, text/plain, */*',
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + clean(localStorage.getItem('accessToken')),
        'X-Device-Fingerprint': btoa(JSON.stringify(fp)),
        'X-Request-Signature': sig,
        'X-Request-Timestamp': ts,
        'X-Request-Nonce': nc,
        'X-Session-Id': sessionId,
        'X-UI-Gesture': String(gesture),
        'X-UI-Path': 'm=1;k=mouse;t=-1;d=-1;v=-1',
        'X-UI-Trap': '0',
        'X-UI-Field': `e=${len};u=0;o=0;p=0;d=0;b=1;c=${len};f=5200;s=${gesture};n=2;t=0`,
        'X-CSRF-Token': csrf,
        'X-XSRF-TOKEN': csrf,
      }, extra || {}),
      body: JSON.stringify({platform: 'envato', itemUrl, itemType: 'standard'}),
    });
    return {status: r.status, body: (await r.text()).slice(0, 4000)};
  };

  const out = [];
  for (const itemUrl of items) {
    let res = await send(itemUrl);
    for (let i = 0; i < 4; i++) {
      let p = {};
      try { p = JSON.parse(res.body); } catch (e) { break; }
      const fresh = p?.error?.newToken || p?.newToken;
      if (fresh) {                                  // CSRF ротируется
        localStorage.setItem('x-csrf-token', fresh);
        res = await send(itemUrl);
        continue;
      }
      if (p?.code === 'TIMELOCK_REQUIRED' && p.puzzle) {
        const answer = solve(p.puzzle.x, p.puzzle.k, p.puzzle.n);
        res = await send(itemUrl, {'X-Timelock-Id': p.puzzle.id,
                                   'X-Timelock-Answer': answer});
        continue;
      }
      break;
    }
    out.push({itemUrl, status: res.status, body: res.body});
  }
  return out;
}
"""

_GESTURE_JS = """
() => {
  window.__lastGesture = window.__lastGesture || 0;
  if (window.__gestureHooked) return;
  window.__gestureHooked = true;
  for (const e of ['pointerdown', 'mousedown', 'keydown'])
    document.addEventListener(e, ev => {
      if (ev.isTrusted) window.__lastGesture = Date.now();
    }, {capture: true, passive: true});
}
"""

_LICENSES_JS = """
async () => {
  const clean = (v) => (v || '').replace(/^"|"$/g, '');
  const r = await fetch('/api/users/licenses', {
    credentials: 'include',
    headers: {'Authorization': 'Bearer ' + clean(localStorage.getItem('accessToken')),
              'Accept': 'application/json'},
  });
  return {status: r.status, body: (await r.text()).slice(0, 8000)};
}
"""

_XHR_SPY_JS = """
() => {
  if (window.__fpSpy !== undefined) return;
  window.__fpSpy = null;
  const open = XMLHttpRequest.prototype.open;
  const set = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.open = function (m, u, ...rest) {
    this.__u = u; return open.call(this, m, u, ...rest);
  };
  XMLHttpRequest.prototype.setRequestHeader = function (k, v) {
    if (this.__u && this.__u.includes('/downloads') &&
        k.toLowerCase() === 'x-device-fingerprint') window.__fpSpy = v;
    return set.call(this, k, v);
  };
}
"""


class _Job:
    """Одно задание загрузчику: ссылка → файл. Клип ждёт свой `done`."""

    __slots__ = ('kind', 'asset_url', 'destination', 'done', 'ok', 'error', 'payload')

    def __init__(self, kind: str, asset_url: str = '', destination: Optional[Path] = None):
        self.kind = kind                     # 'download' | 'quota'
        self.asset_url = asset_url
        self.destination = destination
        self.done = threading.Event()
        self.ok = False
        self.error = ''
        self.payload: Any = None


class _Downloader:
    """Один Chrome, одна вкладка, ОДИН рабочий поток — и очередь заданий.

    Почему так: Playwright sync-API привязан к своему потоку, а Chrome по CDP у
    нас один. При этом стадия идёт в 12 потоков — значит нужен не замок вокруг
    чужого вызова, а исполнитель-потребитель.

    Ожидания «пока наберётся пачка» здесь НЕТ: первое задание берётся
    блокирующе и уходит в работу сразу. Пачка складывается сама — из того, что
    успело накопиться, пока качалось предыдущее (`get_nowait` до опустошения).
    """

    _MAX_BATCH = 8

    def __init__(self) -> None:
        self._queue: "queue.Queue[_Job]" = queue.Queue()
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self._playwright = None
        self._browser = None
        self._page = None
        self._fingerprint: Optional[dict] = None
        self._fatal = ''                     # источник выключен на прогон

    # — публичное —

    def submit(self, job: _Job, timeout: float = 900.0) -> _Job:
        if self._fatal:
            job.error = self._fatal
            job.done.set()
            return job
        self._ensure_thread()
        self._queue.put(job)
        if not job.done.wait(timeout=timeout):
            job.error = f'загрузчик не ответил за {int(timeout)}с'
        return job

    def fatal(self) -> str:
        return self._fatal

    # — поток-исполнитель —

    def _ensure_thread(self) -> None:
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return
            self._thread = threading.Thread(target=self._loop, daemon=True,
                                            name='filesta-downloader')
            self._thread.start()

    def _loop(self) -> None:
        while True:
            job = self._queue.get()
            batch = [job]
            # Всё, что уже лежит в очереди, забираем этим же заходом.
            while len(batch) < self._MAX_BATCH:
                try:
                    batch.append(self._queue.get_nowait())
                except queue.Empty:
                    break
            try:
                self._handle_batch(batch)
            except Exception as exc:                        # noqa: BLE001
                for item in batch:
                    if not item.done.is_set():
                        item.error = f'{type(exc).__name__}: {exc}'
                        item.done.set()
                logger.warning("%s: загрузчик упал на пачке из %d: %s",
                               SOURCE, len(batch), exc)
            finally:
                for item in batch:
                    item.done.set()

    def _handle_batch(self, batch: List[_Job]) -> None:
        quota_jobs = [item for item in batch if item.kind == 'quota']
        download_jobs = [item for item in batch if item.kind == 'download']
        page = self._page_or_start()

        for item in quota_jobs:
            try:
                item.payload = self._read_quota(page)
                item.ok = item.payload is not None
            except Exception as exc:                        # noqa: BLE001
                item.error = str(exc)
            item.done.set()

        if not download_jobs:
            return

        if len(download_jobs) > 1:
            logger.info("%s: пачка загрузок — %d шт.", SOURCE, len(download_jobs))
        # Доверенный жест: его требует заголовок X-UI-Gesture.
        page.evaluate(_GESTURE_JS)
        page.mouse.move(620, 390)
        page.mouse.click(620, 390)
        page.wait_for_timeout(250)

        answers = page.evaluate(_REQUEST_JS, {
            'items': [item.asset_url for item in download_jobs],
            'fp': self._load_fingerprint(),
        })
        by_url = {str(answer.get('itemUrl') or ''): answer for answer in (answers or [])}

        for item in download_jobs:
            answer = by_url.get(item.asset_url) or {}
            status = int(answer.get('status') or 0)
            body = str(answer.get('body') or '')
            if status != 202:
                item.error = f'Filesta отказала ({status}): {body[:200]}'
                # Смена схемы подписи — единственная причина выключить источник
                # целиком: дальше все запросы будут падать так же.
                if 'SECURITY_CHECK_FAILED' in body:
                    self._note_security_failure()
                item.done.set()
                continue
            try:
                result = json.loads(body)['data']['result']
            except Exception as exc:                        # noqa: BLE001
                item.error = f'ответ не разобран: {exc}'
                item.done.set()
                continue
            try:
                item.ok = self._fetch_file(str(result.get('downloadUrl') or ''),
                                           item.destination)
                if not item.ok and not item.error:
                    item.error = 'файл не скачался'
            except Exception as exc:                        # noqa: BLE001
                item.error = f'{type(exc).__name__}: {exc}'
            item.done.set()

    # — браузер —

    def _page_or_start(self):
        if self._page is not None:
            try:
                if not self._page.is_closed():
                    return self._page
            except Exception:                               # noqa: BLE001
                pass
        from playwright.sync_api import sync_playwright

        if self._playwright is None:
            self._playwright = sync_playwright().start()
        try:
            self._browser = self._playwright.chromium.connect_over_cdp(_cdp_url())
        except Exception:                                   # noqa: BLE001
            _launch_chrome()
            self._browser = self._playwright.chromium.connect_over_cdp(_cdp_url())
        context = self._browser.contexts[0] if self._browser.contexts else self._browser.new_context()
        page = next((p for p in context.pages if 'filesta.com' in (p.url or '')), None)
        if page is None:
            page = context.new_page()
            page.goto('https://filesta.com/services/envato/content',
                      wait_until='domcontentloaded', timeout=60_000)
            page.wait_for_timeout(6000)
        self._page = page
        return page

    def _load_fingerprint(self) -> dict:
        if self._fingerprint is None:
            path = fingerprint_path()
            if not path.is_file():
                raise RuntimeError(
                    f'отпечаток не снят: {path}. Settings → Filesta → «Снять отпечаток»')
            self._fingerprint = json.loads(path.read_text(encoding='utf-8'))
        return dict(self._fingerprint)

    def _note_security_failure(self) -> None:
        """Два SECURITY_CHECK_FAILED подряд = схема подписи сменилась."""
        count = getattr(self, '_security_fails', 0) + 1
        setattr(self, '_security_fails', count)
        if count >= 2:
            self._fatal = ('Filesta сменила схему подписи (SECURITY_CHECK_FAILED). '
                           'Источник выключен на прогон; снимите отпечаток заново.')
            logger.error("[stock] ⛔ %s", self._fatal)

    def _read_quota(self, page) -> Optional[int]:
        """Остаток суточных загрузок: сумма по валидным лицензиям Envato.

        Ключ лицензии (`key`) — секрет, наружу он не идёт: берём только числа.
        """
        answer = page.evaluate(_LICENSES_JS)
        if int(answer.get('status') or 0) != 200:
            return None
        payload = json.loads(answer.get('body') or '{}')
        items = payload.get('data') if isinstance(payload, dict) else payload
        if isinstance(items, dict):
            items = items.get('licenses') or items.get('items') or []
        total = 0
        found = False
        for license_item in items or []:
            if not isinstance(license_item, dict):
                continue
            if str(license_item.get('service') or '').lower() != 'envato':
                continue
            if license_item.get('isValid') is False:
                continue
            remaining = license_item.get('remainingDailyLimit')
            if remaining is None:
                continue
            try:
                total += int(remaining)
                found = True
            except (TypeError, ValueError):
                continue
        return total if found else None

    def _fetch_file(self, download_url: str, destination: Path) -> bool:
        """Забрать мастер ПОТОКОМ. Читать целиком в память нельзя: замер
        разведки — 4,3 ГБ у 4K-ассета, машина вставала."""
        if not download_url or destination is None:
            return False
        destination.parent.mkdir(parents=True, exist_ok=True)
        limit = _max_master_mb() * 1024 * 1024
        request = urllib.request.Request(download_url, headers={'User-Agent': _UA})
        temporary = destination.with_suffix(destination.suffix + '.part')
        with urllib.request.urlopen(request, timeout=300) as response:
            declared = int(response.headers.get('Content-Length') or 0)
            if declared and declared > limit:
                # Квота УЖЕ списана (она уходит в момент запроса), поэтому такой
                # случай пишем отдельной строкой: если порог начнёт срабатывать
                # часто, это видно сразу.
                logger.warning("[stock] %s: мастер %.0f МБ больше потолка %d МБ — "
                               "не качаю (загрузка уже списана)",
                               SOURCE, declared / 1024 / 1024, _max_master_mb())
                return False
            got = 0
            with temporary.open('wb') as handle:
                while True:
                    chunk = response.read(512 * 1024)
                    if not chunk:
                        break
                    got += len(chunk)
                    if got > limit:
                        handle.close()
                        temporary.unlink(missing_ok=True)
                        logger.warning("[stock] %s: мастер перевалил потолок %d МБ — обрываю",
                                       SOURCE, _max_master_mb())
                        return False
                    handle.write(chunk)
        if temporary.stat().st_size < 1024:
            temporary.unlink(missing_ok=True)
            return False
        destination.unlink(missing_ok=True)
        temporary.replace(destination)
        return True


_downloader = _Downloader()


def _launch_chrome() -> None:
    """Поднять Chrome с отладочным портом и нашим профилем.

    Профиль — отдельный (`agent/.filesta/chrome_profile`), чтобы не трогать
    рабочий браузер пользователя; вход в Filesta он делает один раз в нём же.
    """
    executable = str(getattr(config, 'FILESTA_CHROME_EXE', '') or '').strip()
    if not executable:
        for candidate in (
            r'C:\Program Files\Google\Chrome\Application\chrome.exe',
            r'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe',
            '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
        ):
            if Path(candidate).is_file():
                executable = candidate
                break
    if not executable:
        raise RuntimeError('Chrome не найден — задайте FILESTA_CHROME_EXE')
    port = urllib.parse.urlparse(_cdp_url()).port or 9222
    profile = profile_path()
    profile.mkdir(parents=True, exist_ok=True)
    flags = {}
    if os.name == 'nt':
        flags['creationflags'] = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    subprocess.Popen([
        executable,
        f'--remote-debugging-port={port}',
        f'--user-data-dir={profile}',
        'https://filesta.com/services/envato/content',
    ], **flags)
    logger.info("%s: поднял Chrome (порт %s, профиль %s)", SOURCE, port, profile)
    time.sleep(6)


# ── публичные функции провайдера ────────────────────────────────────────────

def download_master(asset_url: str, destination: str | Path) -> bool:
    """Купить и скачать мастер-файл. Одна загрузка = одна единица квоты."""
    job = _downloader.submit(_Job('download', str(asset_url), Path(destination)))
    if not job.ok and job.error:
        logger.warning("[stock] %s: %s — %s", SOURCE, str(asset_url)[-40:], job.error)
    return bool(job.ok)


def quota_left() -> Optional[int]:
    """Остаток суточных загрузок (сумма по лицензиям Envato) или None."""
    job = _downloader.submit(_Job('quota'), timeout=120)
    return job.payload if job.ok else None


def source_down() -> str:
    """Непустая строка — источник выключен на прогон (и почему)."""
    return _downloader.fatal()


def capture_fingerprint(timeout_sec: int = 300) -> dict:
    """Разово снять НАСТОЯЩИЙ отпечаток устройства.

    Собрать его руками нельзя: canvas/webgl/audio/fonts — вычисляемые хеши.
    Вешаем перехват на XHR (через window.fetch НЕ работает — панель ходит по
    XHR), пользователь один раз качает что-нибудь кнопкой, мы забираем заголовок.
    """
    import base64
    from playwright.sync_api import sync_playwright

    with sync_playwright() as pw:
        try:
            browser = pw.chromium.connect_over_cdp(_cdp_url())
        except Exception:                                   # noqa: BLE001
            _launch_chrome()
            browser = pw.chromium.connect_over_cdp(_cdp_url())
        context = browser.contexts[0] if browser.contexts else browser.new_context()
        page = next((p for p in context.pages if 'filesta.com' in (p.url or '')), None)
        if page is None:
            page = context.new_page()
            page.goto('https://filesta.com/services/envato/content',
                      wait_until='domcontentloaded', timeout=60_000)
            page.wait_for_timeout(6000)
        page.evaluate(_XHR_SPY_JS)
        deadline = time.time() + timeout_sec
        while time.time() < deadline:
            page.wait_for_timeout(2000)
            raw = page.evaluate('() => window.__fpSpy')
            if raw:
                data = json.loads(base64.b64decode(raw + '=' * (-len(raw) % 4)))
                target = fingerprint_path()
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
                logger.info("%s: отпечаток сохранён → %s", SOURCE, target)
                return data
    raise RuntimeError('отпечаток не пойман: скачайте что-нибудь кнопкой в панели Filesta')
