"""
stock_stage.py — стадия подстановки сток-материала в клипы монтажного плана.

Сидит между Director (montage_plan.json) и генераторами изображений.
Клипы, помеченные режиссёром как `source: stock_pending`, получают реальный
материал вместо нейрогенерации:
  видео → vid_img/{id:03d}.mp4 (уже обрезан под клип) → source: stock_video
  фото  → generated/{id:03d}.jpg (concat сам сделает Ken Burns) → source: stock_photo

Генераторы (ImgGen/FastGen/Veo/FlowUltra) пропускают такие клипы —
см. modules/clip_sources.py (EXTERNAL_SOURCES).

Каскад при нулевой выдаче (решение юзера):
    назначенный источник → СОСЕДНИЕ источники (тот же запрос) →
    альтернативный запрос (LLM) по всем источникам → обычная нейрогенерация

Почему сначала сосед, а не альт-запрос: другой сток — бесплатный HTTP-вызов,
а альт-запрос — вызов LLM (деньги/время/квота). Индексы у стоков разные:
чего нет в Pexels, часто есть в Pixabay. Перепромпчивать имеет смысл, только
когда запрос не нашёлся НИГДЕ — тогда проблема в самом запросе.
"""
from __future__ import annotations

import json
import logging
import re
import shutil
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional

import config
from modules.clip_sources import STOCK_SOURCES
from modules.footage_cut import cut_footage, probe_video
from modules.stock_search import (StockResult, rank_stock, search_source, _words,
                                  VIDEO_EXTS, PHOTO_EXTS)

logger = logging.getLogger(__name__)

_PHOTO_EXT_RE = re.compile(r'\.(jpg|jpeg|png|webp)(\?|$)', re.I)

# Человеческие причины фолбека — юзер должен понимать, почему сток «не сработал»,
# а не гадать. Молчаливая деградация недопустима.
_REASON_TEXT = {
    'no_query': 'промптер не дал запрос (LLM недоступна и озвучки нет)',
    'no_match': 'ничего подходящего не нашлось ни в библиотеке, ни на стоках',
    'download_failed': 'кандидаты найдены, но файл не скачался/не обрезался',
    'interrupted': 'остановлено пользователем',
}


def _match_local_by_words(queries: List[Any], items: List[StockResult], root: Path) -> Dict[int, str]:
    """Фолбек подбора библиотеки без LLM: слова запроса против имени файла и папки.

    Работает только когда промптер лёг. Тупее LLM, поэтому с двумя предохранителями:
      • match_count — учитывает словоформы (storm ⊂ thunderstorms), иначе половина
        файлов не найдётся из-за одной буквы;
      • порог 50% слов запроса — иначе одно случайное общее слово («night») подсунет
        грозовой футаж в клип про городской трафик. Пустой ответ лучше мусорного:
        клип уйдёт на сток.
    """
    from modules.stock_search import match_count, _words

    out: Dict[int, str] = {}
    used: set = set()
    for q in queries:
        qwords = _words(getattr(q, 'query', '') or '')
        if not qwords:
            continue
        want_video = getattr(q, 'media', 'video') == 'video'
        best = None
        best_score = 0.0
        for it in items:
            if (it.media_type == 'video') != want_video:
                continue
            if it.local_path in used:
                continue
            hits = match_count(qwords, it.keywords)
            score = hits / len(qwords)
            if score >= 0.5 and score > best_score:      # порог: половина слов запроса
                best, best_score = it, score
        if best is not None:
            used.add(best.local_path)
            out[q.clip_id] = best.local_path
    return out


def _write_stock_report(project_dir: Path, ok_count: int, fallback_ids: List[int],
                        reasons: Dict[int, str], sources: List[str]) -> None:
    """Отчёт стадии в папку проекта — чтобы причины фолбека остались в проекте,
    а не только в консоли, которую юзер мог не смотреть."""
    try:
        payload = {
            'sources': sources,
            'taken_from_stock': ok_count,
            'fell_back_to_generation': len(fallback_ids),
            'fallback_clips': [
                {'clip_id': cid, 'reason': reasons.get(cid, 'неизвестно')}
                for cid in sorted(fallback_ids)
            ],
        }
        (project_dir / 'stock_report.json').write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    except Exception as exc:
        logger.warning("[stock] не смог записать stock_report.json: %s", exc)


def _enabled_sources() -> List[str]:
    """Включённые источники в порядке из настроек. local — только если задана папка."""
    raw = getattr(config, 'STOCK_SOURCES', ['local', 'pexels', 'pixabay'])
    if isinstance(raw, str):
        raw = [s.strip().lower() for s in raw.split(',') if s.strip()]
    out = []
    for s in raw:
        if s == 'local' and not (getattr(config, 'STOCK_LIBRARY_DIR', '') or '').strip():
            continue                     # папка не задана — источника нет
        if s == 'pexels' and not (getattr(config, 'PEXELS_API_KEY', '') or '').strip():
            continue
        if s == 'pixabay' and not (getattr(config, 'PIXABAY_API_KEY', '') or '').strip():
            continue
        out.append(s)
    return out


def _http_download(url: str, dst: Path, *, stop_event: Optional[threading.Event] = None,
                   timeout: int = 120, max_mb: int = 400) -> bool:
    """Скачать файл. Прерываемо (стоп-кнопка) и с потолком размера."""
    proxy = (getattr(config, 'STOCK_PROXY_URL', '') or '').strip()
    opener = urllib.request.build_opener(
        urllib.request.ProxyHandler({'http': proxy, 'https': proxy}) if proxy
        else urllib.request.ProxyHandler({})
    )
    req = urllib.request.Request(url, headers={'User-Agent': 'varagent-stock/1.0'})
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_suffix(dst.suffix + '.part')
    limit = max_mb * 1024 * 1024
    try:
        with opener.open(req, timeout=timeout) as r, open(tmp, 'wb') as f:
            got = 0
            while True:
                if stop_event is not None and stop_event.is_set():
                    raise InterruptedError('stopped')
                chunk = r.read(256 * 1024)
                if not chunk:
                    break
                got += len(chunk)
                if got > limit:
                    raise IOError(f'файл больше {max_mb} МБ — пропускаю')
                f.write(chunk)
        if tmp.stat().st_size < 1024:
            raise IOError('слишком маленький файл')
        if dst.exists():
            dst.unlink()
        tmp.replace(dst)
        return True
    except Exception as exc:
        if not isinstance(exc, InterruptedError):
            logger.info("  скачивание не удалось (%s): %s", type(exc).__name__, exc)
        if tmp.exists():
            tmp.unlink(missing_ok=True)
        return False


def _search_cascade(
    query: str,
    media_type: str,
    *,
    primary: str,
    sources: List[str],
    clip_duration: float,
    target_w: int,
    target_h: int,
    used_urls: set,
    limit: int = 20,
) -> List[StockResult]:
    """Назначенный источник, затем соседние — ТОТ ЖЕ запрос. Возвращает ранжированное."""
    order = [primary] + [s for s in sources if s != primary]
    for src in order:
        raw = search_source(src, query, media_type, limit, target_w, target_h)
        ranked = rank_stock(raw, query, clip_duration=clip_duration,
                            target_w=target_w, target_h=target_h, used_urls=used_urls)
        if ranked:
            if src != primary:
                logger.info("    '%s' не нашёлся в %s → взял в %s", query[:40], primary, src)
            return ranked
    return []


class StockProcessor:
    def __init__(
        self,
        project_dir: str | Path,
        *,
        target_w: int = 1920,
        target_h: int = 1080,
        fps: Optional[int] = None,
        alt_query_fn=None,
    ):
        self.project_dir = Path(project_dir).resolve()
        self.montage_path = self.project_dir / 'montage_plan.json'
        self.generated_dir = self.project_dir / 'generated'
        self.vid_img_dir = self.project_dir / 'vid_img'
        self.cache_dir = self.project_dir / '.stock_cache'
        self.target_w = target_w
        self.target_h = target_h
        self.fps = int(fps if fps is not None else getattr(config, 'VIDEO_FPS', 60))
        self.used_urls: set = set()
        self.credits: List[Dict[str, Any]] = []
        # {clip_id: StockQuery} — заполняет build_queries (промптер стока)
        self.queries: Dict[int, Any] = {}
        # Функция альт-запросов (LLM). Не задана — каскад просто закончится фолбеком.
        self.alt_query_fn = alt_query_fn

    # ── план ────────────────────────────────────────────────────────────────
    def _load_plan(self) -> Dict[str, Any]:
        raw = json.loads(self.montage_path.read_text(encoding='utf-8-sig'))
        return raw.get('montage_plan', raw) if isinstance(raw, dict) else {}

    def _save_plan(self, plan: Dict[str, Any]) -> None:
        raw = json.loads(self.montage_path.read_text(encoding='utf-8-sig'))
        if isinstance(raw, dict) and 'montage_plan' in raw:
            raw['montage_plan'] = plan
        else:
            raw = plan
        self.montage_path.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding='utf-8')

    def _commit_pending_delta(self, pending: List[Dict[str, Any]]) -> None:
        """Записать ТОЛЬКО свои клипы (по их итоговому source + материализованные поля)
        в montage_plan под locked-ретраем. Real_photo идёт параллельно и правит свои клипы —
        общий файл пишется атомарно по дельте, без гонки (см. apply_clip_source_delta).

        Материализованный клип несёт не только source, но и file/stock_source/stock_page
        (см. _materialize) — их тоже кладём в дельту, иначе они потеряются при записи."""
        from modules.clip_sources import apply_clip_source_delta
        delta = {}
        for clip in pending:
            cid = clip.get('id')
            try:
                cid = int(cid)
            except (TypeError, ValueError):
                continue
            # source после обработки: 'stock_video'/'stock_photo' (ok) или отсутствует (снят → None)
            patch = {'source': clip.get('source')}
            for k in ('file', 'stock_source', 'stock_page'):
                if k in clip:
                    patch[k] = clip[k]
            delta[cid] = patch
        apply_clip_source_delta(self.montage_path, delta,
                                log=lambda m: logger.info("[stock] " + m))

    def pending_clips(self, plan: Dict[str, Any]) -> List[Dict[str, Any]]:
        return [c for c in (plan.get('clips') or []) if c.get('source') == 'stock_pending']

    @staticmethod
    def _clip_voiceover(clip: Dict[str, Any]) -> str:
        """Текст озвучки клипа — контекст для промптера.

        Директор кладёт реплики по-разному в зависимости от бэкенда, поэтому
        собираем из всех известных полей, а не гадаем по одному.
        """
        for key in ('voiceover', 'text', 'narration', 'transcript'):
            v = clip.get(key)
            if isinstance(v, str) and v.strip():
                return v.strip()
        segs = clip.get('segments') or clip.get('lines')
        if isinstance(segs, list):
            parts = [s.get('text', '') if isinstance(s, dict) else str(s) for s in segs]
            joined = ' '.join(p for p in parts if p).strip()
            if joined:
                return joined
        # последний шанс — визуальный промпт режиссёра (художественный, но лучше пустоты)
        return (clip.get('prompt') or '').strip()

    def build_queries(self, clips: List[Dict[str, Any]]) -> Dict[int, Any]:
        """Промптер стока: запросы + тип медиа + сопоставление своей библиотеки.

        Вызов 1 — озвучка → query + media (с пропорцией video/photo).
        Вызов 2 — те же query + список файлов → local_file | null (если папка включена).
        Промптер свой, от режиссёра не зависит: Pass 1 только ставит маркер.
        """
        from modules import stock_prompter

        # Тема ролика (якорь) — Pass 1 кладёт в montage_plan.theme. Опционально.
        try:
            _raw = json.loads(self.montage_path.read_text(encoding='utf-8-sig'))
            _theme = (_raw.get('theme') or _raw.get('montage_plan', {}).get('theme', '') or '').strip()
        except Exception:
            _theme = ''
        payload = [{'id': int(c['id']), 'voiceover': self._clip_voiceover(c)} for c in clips]
        queries = stock_prompter.generate_queries(payload, theme=_theme)
        if not queries:
            return {}

        # Локальная библиотека — вторым вызовом, только если она реально включена
        lib_root = (getattr(config, 'STOCK_LIBRARY_DIR', '') or '').strip().strip('"')
        sources = _enabled_sources()
        if lib_root and 'local' in sources:
            from modules.stock_search import _scan_local_library
            root = Path(lib_root).expanduser()
            items = _scan_local_library(root)
            rel = []
            by_rel = {}
            for it in items:
                try:
                    r = str(Path(it.local_path).relative_to(root)).replace('\\', '/')
                except ValueError:
                    r = Path(it.local_path).name
                rel.append(r)
                by_rel[r] = it.local_path
            if rel:
                matched = stock_prompter.match_local(queries, rel)
                if matched is None:
                    # LLM легла → подбор по словам, иначе библиотека умрёт вместе с ней.
                    # (Пустой {} от LLM — это НЕ сюда: она честно сказала «не подходит».)
                    matched = _match_local_by_words(queries, items, root)
                    if matched:
                        print(f"   [stock] промптер недоступен → подбор по словам: "
                              f"{len(matched)} клип(ов) из своей библиотеки")
                for q in queries:
                    f = matched.get(q.clip_id)
                    if f:
                        q.local_file = by_rel.get(f, f)
                if matched:
                    print(f"   [stock] своя библиотека закрыла {len(matched)} из {len(queries)} клип(ов)")
        return {q.clip_id: q for q in queries}

    # ── обработка клипа ─────────────────────────────────────────────────────
    def process_clip(
        self,
        clip: Dict[str, Any],
        primary_source: str,
        sources: List[str],
        *,
        stop_event: Optional[threading.Event] = None,
    ) -> Dict[str, Any]:
        cid = int(clip.get('id') or 0)
        sq = (self.queries or {}).get(cid)
        if sq is None or not (sq.query or '').strip():
            return {'id': cid, 'status': 'no_query'}
        query = sq.query
        media_type = sq.media
        duration = float(clip.get('endTime', 0)) - float(clip.get('startTime', 0))

        # Промптер выбрал файл из своей библиотеки → он и идёт в дело, сток не трогаем.
        # Тип берём по расширению файла, а не по ответу модели: .mp4 — это видео,
        # что бы она ни написала.
        if sq.local_file:
            p = Path(sq.local_file)
            is_video = p.suffix.lower() in VIDEO_EXTS
            cand = StockResult(
                source='local', media_type='video' if is_video else 'photo',
                url=str(p), local_path=str(p), title=p.stem,
                license_name='own material',
            )
            res = self._materialize(clip, cand, duration, stop_event=stop_event)
            if res.get('ok'):
                self.used_urls.add(cand.url)
                self._add_credit(cid, cand)
                return {'id': cid, 'status': 'ok', 'source': 'local',
                        'media': cand.media_type, 'query': query,
                        'url': cand.url, 'page_url': cand.page_url}
            # Свой файл битый/не режется → не теряем клип, идём на сток с тем же запросом
            logger.info("    клип %s: свой файл не подошёл (%s) → сток", cid, p.name)

        ranked = _search_cascade(
            query, media_type, primary=primary_source, sources=sources,
            clip_duration=duration if media_type == 'video' else 0.0,
            target_w=self.target_w, target_h=self.target_h, used_urls=self.used_urls,
        )
        # Нигде не нашлось → альтернативный запрос (LLM), затем снова по всем источникам
        if not ranked and self.alt_query_fn:
            for alt in (self.alt_query_fn(clip, query) or [])[:2]:
                if not alt or alt.strip().lower() == query.strip().lower():
                    continue
                logger.info("    альт-запрос: '%s'", alt[:50])
                ranked = _search_cascade(
                    alt, media_type, primary=primary_source, sources=sources,
                    clip_duration=duration if media_type == 'video' else 0.0,
                    target_w=self.target_w, target_h=self.target_h, used_urls=self.used_urls,
                )
                if ranked:
                    break
        if not ranked:
            return {'id': cid, 'status': 'no_match', 'query': query}

        for cand in ranked[:4]:
            if stop_event is not None and stop_event.is_set():
                return {'id': cid, 'status': 'interrupted'}
            res = self._materialize(clip, cand, duration, stop_event=stop_event)
            if res.get('ok'):
                self.used_urls.add(cand.url)
                self._add_credit(cid, cand)
                return {'id': cid, 'status': 'ok', 'source': cand.source,
                        'media': cand.media_type, 'query': query,
                        'url': cand.url, 'page_url': cand.page_url}
        return {'id': cid, 'status': 'download_failed', 'query': query}

    def _materialize(self, clip: Dict[str, Any], cand: StockResult, duration: float,
                     *, stop_event: Optional[threading.Event] = None) -> Dict[str, Any]:
        cid = int(clip.get('id') or 0)
        if cand.media_type == 'video':
            src = Path(cand.local_path) if cand.source == 'local' else self.cache_dir / f'{cid:03d}_src.mp4'
            if cand.source != 'local':
                if not _http_download(cand.url, src, stop_event=stop_event):
                    return {'ok': False}
            dst = self.vid_img_dir / f'{cid:03d}.mp4'
            cut = cut_footage(
                src, dst, duration,
                target_w=self.target_w, target_h=self.target_h, fps=self.fps,
                start_sec=float(getattr(config, 'STOCK_CLIP_START_SEC', 0) or 0),
                jitter=bool(getattr(config, 'STOCK_CLIP_START_JITTER', False)),
                jitter_sec=float(getattr(config, 'STOCK_CLIP_START_JITTER_SEC', 2) or 2),
                mute=bool(getattr(config, 'STOCK_MUTE_AUDIO', True)),
                stop_event=stop_event, clip_id=cid,
            )
            if cand.source != 'local':
                src.unlink(missing_ok=True)          # исходник больше не нужен
            if not cut.get('ok'):
                return {'ok': False}
            clip['source'] = 'stock_video'
            clip['file'] = dst.name
            clip['stock_source'] = cand.source
            clip['stock_page'] = cand.page_url
            return {'ok': True}

        # фото → generated/, concat сам сделает Ken Burns
        ext = 'jpg'
        m = _PHOTO_EXT_RE.search(cand.url or '')
        if m:
            ext = m.group(1).lower()
            ext = 'jpg' if ext == 'jpeg' else ext
        dst = self.generated_dir / f'{cid:03d}.{ext}'
        if cand.source == 'local':
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(cand.local_path, dst)
        elif not _http_download(cand.url, dst, stop_event=stop_event):
            return {'ok': False}
        clip['source'] = 'stock_photo'
        clip['stock_source'] = cand.source
        clip['stock_page'] = cand.page_url
        return {'ok': True}

    def _add_credit(self, clip_id: int, cand: StockResult) -> None:
        self.credits.append({
            'clip_id': clip_id,
            'source': cand.source,
            'author': cand.author,
            'page_url': cand.page_url,
            'license': cand.license_name,
            'title': cand.title,
        })

    def write_credits(self) -> None:
        if not self.credits:
            return
        path = self.project_dir / 'stock_credits.json'
        path.write_text(json.dumps({'items': self.credits}, ensure_ascii=False, indent=2),
                        encoding='utf-8')

        # Человекочитаемая версия для описания YouTube. Дедуп по page_url.
        # 'local' (свой материал) в атрибуцию не идёт — незачем.
        try:
            _site = {'pexels': 'Pexels', 'pixabay': 'Pixabay', 'coverr': 'Coverr'}
            lines, seen = [], set()
            for it in sorted(self.credits, key=lambda x: x.get('clip_id', 0)):
                if it.get('source') == 'local':
                    continue
                key = it.get('page_url') or (it.get('source'), it.get('title'))
                if key in seen:
                    continue
                seen.add(key)
                site = _site.get(it.get('source'), (it.get('source') or 'Stock').title())
                parts = [f"**{site}**"]
                if (it.get('title') or '').strip():
                    parts.append(f"«{it['title'].strip()}»")
                if (it.get('author') or '').strip():
                    parts.append(it['author'].strip())
                if (it.get('license') or '').strip():
                    parts.append(it['license'].strip())
                row = ' — '.join(parts)
                if (it.get('page_url') or '').strip():
                    row += f" — {it['page_url'].strip()}"
                lines.append(f"- {row}")
            md = (
                "# Источники футажа (сток)\n\n"
                "Стоковые материалы, использованные в видео. Можно вставить в описание ролика.\n\n"
                + ("\n".join(lines) if lines else "_только собственный материал — атрибуция не нужна_")
                + "\n"
            )
            (self.project_dir / 'stock_credits.md').write_text(md, encoding='utf-8')
        except Exception as exc:
            logger.warning("[stock] credits .md write failed (non-fatal): %s", exc)


def run_stock_stage(
    project_dir: str | Path,
    *,
    target_w: int = 1920,
    target_h: int = 1080,
    fps: Optional[int] = None,
    stop_event: Optional[threading.Event] = None,
    deadline_ts: Optional[float] = None,
    alt_query_fn=None,
) -> Dict[str, Any]:
    """Обработать клипы `stock_pending`. Возвращает сводку.

    Клипы, которым материал не нашёлся, теряют маркер → уходят в обычную
    нейрогенерацию (STOCK_PROMPT_FALLBACK). Пайплайн не встаёт.
    """
    proc = StockProcessor(project_dir, target_w=target_w, target_h=target_h,
                          fps=fps, alt_query_fn=alt_query_fn)
    if not proc.montage_path.exists():
        return {'ok': 0, 'failed': 0, 'total': 0, 'error': 'montage_plan.json не найден'}

    plan = proc._load_plan()
    pending = proc.pending_clips(plan)
    if not pending:
        return {'ok': 0, 'failed': 0, 'total': 0}

    sources = _enabled_sources()
    if not sources:
        why = ('нет доступных источников: не задана папка библиотеки и/или '
               'не заполнены ключи PEXELS_API_KEY / PIXABAY_API_KEY')
        print(f"\n[stock] ⚠️  {why}")
        print(f"[stock] ⚠️  все {len(pending)} помеченных клип(ов) уходят в НЕЙРОГЕНЕРАЦИЮ")
        logger.warning("[stock] %s — %d клипов в нейрогенерацию", why, len(pending))
        ids = [int(c.get('id') or 0) for c in pending]
        for c in pending:
            c.pop('source', None)
        proc._commit_pending_delta(pending)
        _write_stock_report(proc.project_dir, 0, ids, {i: why for i in ids}, sources)
        return {'ok': 0, 'failed': len(pending), 'total': len(pending),
                'fallback': len(pending), 'error': 'no sources'}

    print(f"\n[stock] {len(pending)} клип(ов), источники: {', '.join(sources)}")

    # Промптер: запросы + тип медиа (вызов 1) и своя библиотека (вызов 2, если включена).
    # Нет запросов вообще (LLM легла и озвучки нет) → клипы уходят в нейрогенерацию.
    proc.queries = proc.build_queries(pending)
    if not proc.queries:
        why = ('промптер стока не дал ни одного запроса '
               f'(оператор: {getattr(config, "STOCK_PROMPT_PROVIDER", "auto")}) — '
               'проверь доступность LLM')
        print(f"\n[stock] ⚠️  {why}")
        print(f"[stock] ⚠️  все {len(pending)} помеченных клип(ов) уходят в НЕЙРОГЕНЕРАЦИЮ")
        logger.warning("[stock] %s — %d клипов в нейрогенерацию", why, len(pending))
        ids = [int(c.get('id') or 0) for c in pending]
        for c in pending:
            c.pop('source', None)
        proc._commit_pending_delta(pending)
        _write_stock_report(proc.project_dir, 0, ids, {i: why for i in ids}, sources)
        return {'ok': 0, 'failed': len(pending), 'total': len(pending),
                'fallback': len(pending), 'error': 'no queries'}

    # Сетевые стоки — их раздаёт карусель. `local` идёт мимо неё: файл назначает промптер.
    net_sources = [s for s in sources if s != 'local']
    ok = failed = 0
    fallback_ids: List[int] = []

    reasons: Dict[int, str] = {}          # clip_id → почему ушёл в нейрогенерацию
    results_by_id: Dict[int, Dict[str, Any]] = {}   # clip_id → res (для stock_query_log.json)
    for i, clip in enumerate(pending):
        if stop_event is not None and stop_event.is_set():
            logger.info("[stock] остановлено пользователем")
            break
        if deadline_ts and time.time() > deadline_ts:
            logger.info("[stock] дедлайн — оставшиеся клипы уходят в нейрогенерацию")
            break
        # round-robin ПО ПОРЯДКУ КЛИПОВ: иначе соседние клипы ролика окажутся
        # из одного стока и будут визуально слипаться по стилю.
        # `local` в карусели НЕ участвует: свой файл назначает промптер (он один
        # видит и клипы, и папку), а карусель раздаёт только сетевые стоки.
        primary = net_sources[i % len(net_sources)] if net_sources else 'local'
        res = proc.process_clip(clip, primary, net_sources, stop_event=stop_event)
        results_by_id[int(clip.get('id') or 0)] = res
        if res.get('status') == 'ok':
            ok += 1
            print(f"   [{i+1}/{len(pending)}] клип {res['id']}: {res['media']} из {res['source']}")
        elif res.get('status') == 'interrupted':
            break
        else:
            failed += 1
            cid = int(clip.get('id') or 0)
            fallback_ids.append(cid)
            why = _REASON_TEXT.get(res.get('status', ''), res.get('status', 'неизвестно'))
            reasons[cid] = why
            q = (res.get('query') or '')[:40]
            print(f"   [{i+1}/{len(pending)}] клип {cid}: {why}"
                  + (f" (запрос: '{q}')" if q else "") + " → нейрогенерация")

    # Не нашлось / прервано / дедлайн → снять маркер, чтобы генератор подхватил клип
    for clip in pending:
        if clip.get('source') == 'stock_pending':
            clip.pop('source', None)
            cid = int(clip.get('id') or 0)
            if cid not in fallback_ids:
                fallback_ids.append(cid)
                reasons.setdefault(cid, 'не дошла очередь (стоп/дедлайн)')

    # ТОЛЬКО свои клипы по дельте (не весь план) — real_photo пишет параллельно,
    # полный снимок затёр бы его правки (см. apply_clip_source_delta).
    proc._commit_pending_delta(pending)
    proc.write_credits()
    _write_stock_report(proc.project_dir, ok, fallback_ids, reasons, sources)

    # Query-log (отладка качества запросов): вход(id+voiceover), запрос+кем(провайдер/path/
    # fallback-причина), медиа, ссылка на файл + страницу. Логирование не роняет стадию.
    try:
        log_items = []
        for clip in pending:
            cid = int(clip.get('id') or 0)
            sq = (proc.queries or {}).get(cid)
            res = results_by_id.get(cid)
            status = res.get('status') if res else 'skipped'
            log_items.append({
                'clip_id': cid,
                'voiceover': proc._clip_voiceover(clip)[:200],
                'query': getattr(sq, 'query', '') if sq else '',
                'media': getattr(sq, 'media', '') if sq else '',
                'query_by': getattr(sq, 'query_by', '') if sq else '',
                'query_path': getattr(sq, 'query_path', '') if sq else '',
                'fallback_reason': getattr(sq, 'fallback_reason', '') if sq else '',
                'local_file': getattr(sq, 'local_file', '') if sq else '',
                'status': status,
                'status_reason': reasons.get(cid, ''),
                'source': (res.get('source') if res else '') or '',
                'image_url': (res.get('url') if res else '') or '',
                'page_url': (res.get('page_url') if res else '') or '',
            })
        (proc.project_dir / 'stock_query_log.json').write_text(
            json.dumps({'project': proc.project_dir.name, 'items': log_items},
                       ensure_ascii=False, indent=2), encoding='utf-8')
        logger.info("[stock] query-log → stock_query_log.json (%d clips)", len(log_items))
    except Exception as exc:
        logger.warning("[stock] query-log write failed (non-fatal): %s", exc)

    if proc.cache_dir.exists():
        shutil.rmtree(proc.cache_dir, ignore_errors=True)

    # Явный отчёт юзеру: фолбек НЕ должен быть тихим — иначе непонятно,
    # почему сток «не сработал».
    print(f"\n[stock] итог: {ok} из {len(pending)} клип(ов) взяты из стока/библиотеки")
    if fallback_ids:
        by_reason: Dict[str, List[int]] = {}
        for cid in fallback_ids:
            by_reason.setdefault(reasons.get(cid, 'неизвестно'), []).append(cid)
        print(f"[stock] ⚠️  {len(fallback_ids)} клип(ов) ушли в НЕЙРОГЕНЕРАЦИЮ:")
        for why, ids in sorted(by_reason.items(), key=lambda x: -len(x[1])):
            shown = ', '.join(str(i) for i in sorted(ids)[:12])
            more = f" … и ещё {len(ids) - 12}" if len(ids) > 12 else ""
            print(f"[stock]    • {why}: {len(ids)} шт (клипы {shown}{more})")
            logger.warning("[stock] %s: клипы %s", why, sorted(ids))
        print(f"[stock]    подробности: {(proc.project_dir / 'stock_report.json')}")
    return {'ok': ok, 'failed': failed, 'total': len(pending),
            'fallback': len(fallback_ids), 'sources': sources, 'reasons': reasons}
