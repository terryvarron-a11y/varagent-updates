#!/bin/bash
# INSTALL_FFMPEG.COMMAND - Install FFmpeg on macOS via Homebrew

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
chmod +x "$SCRIPT_DIR"/*.command 2>/dev/null
[ -f "$SCRIPT_DIR/.venv/bin/activate" ] && source "$SCRIPT_DIR/.venv/bin/activate"

if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e 'tell app "Terminal" to do script "cd '\''$SCRIPT_DIR'\'' && exec '\''$0'\''"'
    exit 0
fi

clear

echo ""
echo "========================================================"
echo "           FFmpeg Installation (macOS)"
echo "========================================================"
echo ""
echo "Checking for Homebrew..."
if ! command -v brew &>/dev/null; then
    echo ""
    echo "[ERROR] Homebrew not found!"
    echo ""
    echo "Install Homebrew first:"
    echo '  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"'
    echo ""
    echo "Press Enter to exit..." && read
    exit 1
fi

echo "[OK] Homebrew found. Installing FFmpeg..."
echo ""
brew install ffmpeg

echo ""
echo "========================================================"
echo " Installation complete!"
echo "========================================================"
echo ""
echo "Verify: ffmpeg -version"
echo ""
echo "Press Enter to exit..." && read
