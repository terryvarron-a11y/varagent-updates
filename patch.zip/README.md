# 🎬 SCENAGENT_RTG — Video Production Agent

**Версия:** 1.2.1 (тест обновления 25 марта 2026)

---

## 🚀 БЫСТРЫЙ СТАРТ

### 1. Настройка API ключей

```bash
cd agent
copy .env.example .env
# Отредактировать .env:
# - ASSEMBLYAI_API_KEY
# - GEMINI_API_KEY
# - GEMINI_MODEL=gemini-3-pro-preview
```

### 2.

### 3. Подготовка очереди

Положите аудиофайлы в `ready_to_go/`:
```
ready_to_go/
├── horror_story.mp3
├── horror_story_комикс.txt      ← Style guide (новый формат!)
└── SG_ALL_ужасы.txt             ← Общий style guide (опционально)
```

### 4. Запуск пайплайна

```bash
# Этап 1: Обработка очереди + транскрипция + режиссура (ОДНА КОМАНДА)
run_stage1_simple.bat
# Читает только ready_to_go/, создаёт проекты и сразу запускает полный пайплайн

# Этап 2: Генерация видео (вручную)
# - Открыть {project}_prompts_{date}.txt в папке проекта
# - Сгенерировать в Veo3
# - Скачать в папку проекта (имя файлов не важно)

# Этап 3: Склейка
cd projects/PROJECT
process_fast.bat    # Быстрая склейка
# ИЛИ
process_1080p.bat   # 1080p с перекодированием
```

**Автоматическое переименование:** Скрипт `process.bat` автоматически переименует файлы Veo3 (`087-veo-...mp4`, `video_1.mp4`, и т.д.) в `1.mp4`, `2.mp4`, ... согласно номерам в начале имён.

---

## 📁 СТРУКТУРА ПРОЕКТА

```
SCENAGENT_RTG/
├── agent/                      ← Код агента
│   ├── agent.py                ← CLI
│   ├── config.py               ← Конфигурация
│   ├── .env                    ← API ключи
│   ├── modules/                ← Модули
│   ├── prompts/                ← Инструкции
│   ├── templates/              ← Шаблоны BAT
│   ├── rename_videos.py        ← ⭐ Скрипт переименования
│   └── extract_prompt.py       ← Извлечение промптов
│
├── docs/                       ← Документация
│   ├── PROJECT_STATUS.md       ← ⭐ ГЛАВНЫЙ ФАЙЛ
│   ├── README.md               ← Индекс
│   ├── TODAY_CHANGES.md        ← Изменения за сегодня
│   ├── CHANGELOG.md            ← История изменений
│   └── ...
│
├── ready_to_go/                ← Входная очередь
│   ├── *.mp3, *.wav            ← Аудиофайлы
│   ├── {audio}_{пометка}.txt   ← Style guides (новый формат!)
│   └── SG_ALL_{пометка}.txt    ← Общий style guide
│
├── projects/                   ← Проекты
│   └── {project_name}/
│       ├── {audio}.mp3         ← Аудио
│       ├── {project}_style_{date}.txt  ← Style guide
│       ├── transcription.json  ← Транскрипция
│       ├── montage_plan.json   ← Монтажный план
│       ├── {project}_prompts_{date}.txt  ← Промпты
│       ├── {project}.mp4       ← Готовое видео
│       ├── rename_videos.py    ← Скрипт переименования
│       ├── extract_prompt.py   ← Извлечение промптов
│       └── process_fast.bat    ← Склейка
│
├── run_stage1_simple.bat       ← ⭐ Запуск Этапа 1 (очередь + пайплайн)
└── 0_video_concat_groups_v5_FAST_TRIM.py  ← Скрипт склейки
```

---

## 📚 ДОКУМЕНТАЦИЯ

**Главный файл:** [`docs/PROJECT_STATUS.md`](docs/PROJECT_STATUS.md) ⭐

**Другие файлы:**
- [`docs/README.md`](docs/README.md) — Индекс документации
- [`docs/HUMAN_PIPELINE.md`](docs/HUMAN_PIPELINE.md) — Для пользователей
- [`docs/TECHNICAL_PIPELINE.md`](docs/TECHNICAL_PIPELINE.md) — Для разработчиков
- [`docs/LOGGING.md`](docs/LOGGING.md) — Логи и отчёты
- [`docs/CHANGELOG.md`](docs/CHANGELOG.md) — История изменений
- [`docs/TODAY_CHANGES.md`](docs/TODAY_CHANGES.md) — Изменения за сегодня ⭐
- [`docs/RENAME_VIDEOS.md`](docs/RENAME_VIDEOS.md) — Переименование видео

---

## 🎛️ КОМАНДЫ

```bash
# Обработка очереди + полный пайплайн (ОСНОВНАЯ КОМАНДА)
python agent.py process --run

# Только создание проектов (без транскрипции/режиссуры)
python agent.py process

# Полный пайплайн для конкретного проекта
python agent.py run --audio projects/name/name.wav --style style_guide.txt

# Транскрипция
python agent.py transcribe --audio name.wav

# Режиссура
python agent.py direct --transcription transcription.json --style style_guide.txt

# Валидация
python agent.py validate --all

# Статус
python agent.py status

# Оценка стоимости
python agent.py cost-estimate --duration 30 --language ru

# Переименование видео
cd projects/PROJECT
python rename_videos.py

# Извлечение промпта
python extract_prompt.py 5  # Для фрагмента #5
```

---

## ⚙️ НАСТРОЙКИ (agent/.env)

```env
# API ключи
ASSEMBLYAI_API_KEY=...
GEMINI_API_KEY=...

# Модель Gemini
GEMINI_MODEL=gemini-2.0-flash-exp  # flash, pro, gemini3-pro

# Thinking Level (для Gemini 3.x Pro)
GEMINI_THINKING_LEVEL=medium  # low, medium, high

# Язык транскрипции
ASSEMBLYAI_LANGUAGE_CODE=ru

# Генерация director_analysis.md
GENERATE_DIRECTOR_ANALYSIS=false  # true для отладки
```

---

## 💰 ТАРИФЫ API

### AssemblyAI (Транскрипция)
- Free: $50 кредит (~185 часов)
- Paid: $0.15/час → **30 мин = ~$0.075**

### Gemini AI (Режиссура, 30 мин)
- **Flash:** ~$0.03
- **Pro:** ~$0.83
- **2.0 Flash Exp:** $0.00 (beta)

**Итого за 30 минут:** ~$0.07 - $0.95 (в зависимости от модели)

---

## 🐛 ТИПИЧНЫЕ ПРОБЛЕМЫ

### ❌ "Style guide не найден"
**Решение:** Создать `SG_ALL.txt` или `{name}_style.txt` в `ready_to_go/`

### ❌ "Аудиофайл не найден"
**Решение:** Проверить что файл в `projects/{name}/`

### ❌ "Отсутствуют фрагменты: 5 12"
**Решение:** Сгенерировать в Veo3, скачать, запустить снова

---

## 📞 ПОДДЕРЖКА

При проблемах:
1. Проверь [`docs/HUMAN_PIPELINE.md`](docs/HUMAN_PIPELINE.md)
2. Изучи логи в `agent/logs/`
3. Проверь `errors.json` (если есть)

---

**Проект готов к работе!** 🚀
