"""Visual decision and search-query stage for Auto Visual Story."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import config
from modules.director_profiles import coerce_json_list
from modules.visual_story_validator import validate_visual_plans


def _mock_plan(packet: dict[str, Any], previous: dict[str, Any] | None) -> dict[str, Any]:
    scene = packet["current_scene"]
    text = str(scene.get("text") or "").strip()
    intent = str(scene.get("description") or text).strip()
    return {
        "scene_id": int(packet["scene_id"]),
        "visual_strategy": "new_search",
        "reuse_clip_id": None,
        "visual_intent": intent,
        "search_query": " ".join(text.split()[:8]) or f"scene {packet['scene_id']}",
        "search_queries": [
            " ".join(text.split()[:8]) or f"scene {packet['scene_id']}",
        ],
        "fallback_queries": [],
        "preferred_source": "epf",
        "negative_constraints": [
            "logo",
            "watermark",
            "thumbnail",
            "AI-generated illustration",
        ],
        "confidence": 0.5,
        "reason": "deterministic mock plan",
    }


def _string_list(value: Any, *, limit: int) -> list[str]:
    if isinstance(value, str):
        values = [value]
    elif isinstance(value, (list, tuple)):
        values = value
    else:
        values = []
    return [str(item).strip() for item in values if str(item).strip()][:limit]


def _normalize_plan(
    raw: dict[str, Any],
    scene_id: int,
    *,
    allow_reuse: bool,
) -> dict[str, Any]:
    strategy = str(raw.get("visual_strategy") or "new_search").strip().lower()
    if strategy == "reuse_previous" and not allow_reuse:
        strategy = "new_search"
    intent = str(raw.get("visual_intent") or "").strip()
    query = str(raw.get("search_query") or "").strip()
    reuse_id = raw.get("reuse_clip_id")
    if strategy == "reuse_previous":
        reuse_id = int(reuse_id or scene_id - 1)
        query = ""
    else:
        reuse_id = None
    fallbacks = _string_list(raw.get("fallback_queries"), limit=4)
    search_queries = _string_list(raw.get("search_queries"), limit=6)
    if query and query not in search_queries:
        search_queries.insert(0, query)
    for fallback in fallbacks:
        if fallback not in search_queries:
            search_queries.append(fallback)
    negatives = _string_list(raw.get("negative_constraints"), limit=10)
    confidence = raw.get("confidence", 0.5)
    try:
        confidence = max(0.0, min(float(confidence), 1.0))
    except (TypeError, ValueError):
        confidence = 0.5
    return {
        "scene_id": scene_id,
        "visual_strategy": strategy,
        "reuse_clip_id": reuse_id,
        "visual_intent": intent,
        "search_query": query,
        "search_queries": search_queries,
        "media_type": (
            "photo"
            if str(raw.get("media_type") or raw.get("preferred_media") or "").strip().lower()
            == "photo"
            else "video"
        ),
        "fallback_queries": fallbacks,
        "preferred_source": str(raw.get("preferred_source") or "epf").strip().lower(),
        "negative_constraints": negatives,
        "confidence": confidence,
        "reason": str(raw.get("reason") or "").strip(),
    }


def _plans_from_payload(payload: dict[str, Any]) -> list[dict[str, Any]]:
    """Read the plan envelope, accepting a bare object only for one scene."""
    if not isinstance(payload, dict):
        raise ValueError(
            f"Visual query response must be an object, got {type(payload).__name__}"
        )
    if "plans" in payload:
        return coerce_json_list(payload["plans"], "plans")
    if "scene_id" in payload:
        return [payload]
    raise ValueError("Visual query response has neither 'plans' nor 'scene_id'")


def _validate_batch_plan_ids(
    raw_plans: list[dict[str, Any]],
    batch: list[dict[str, Any]],
    batch_index: int,
) -> None:
    expected = [int(packet["scene_id"]) for packet in batch]
    try:
        actual = [int(plan["scene_id"]) for plan in raw_plans]
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(
            f"Visual query batch {batch_index} returned a plan without a valid scene_id"
        ) from exc
    if actual != expected:
        raise ValueError(
            f"Visual query batch {batch_index} returned scene IDs {actual}, "
            f"expected {expected}"
        )


def create_visual_plans(
    *,
    packets: list[dict[str, Any]],
    transport,
    prompt_template: str,
    story_dir: str | Path,
    batch_size: int = 20,
    allow_reuse: bool = True,
    mock: bool = False,
) -> list[dict[str, Any]]:
    story = Path(story_dir)
    plans: list[dict[str, Any]] = []
    batch_size = max(1, int(batch_size))
    for batch_index, offset in enumerate(range(0, len(packets), batch_size), 1):
        batch = packets[offset:offset + batch_size]
        history = [
            {
                "scene_id": item["scene_id"],
                "visual_strategy": item["visual_strategy"],
                "reuse_clip_id": item.get("reuse_clip_id"),
                "visual_intent": item["visual_intent"],
                "search_query": item.get("search_query", ""),
            }
            for item in plans[-6:]
        ]
        if mock:
            raw_plans = [
                _mock_plan(packet, plans[-1] if plans else None)
                for packet in batch
            ]
        else:
            prompt = (
                prompt_template
                .replace("{{PLAN_COUNT}}", str(len(batch)))
                .replace(
                    "{{STOCK_POLICY}}",
                    (
                        f"Stock is enabled. Allocate approximately "
                        f"{float(getattr(config, 'STOCK_RATIO_TARGET', 0.30) or 0.30):.0%} "
                        "of new_search scenes to preferred_source stock."
                        if getattr(config, "STOCK_ENABLED", False)
                        else "Stock is disabled. Use preferred_source epf for all new_search scenes."
                    ),
                )
                .replace(
                    "{{YOUTUBE_POLICY}}",
                    (
                        f"YouTube Footage is enabled. Allocate approximately "
                        f"{float(getattr(config, 'YOUTUBE_RATIO_TARGET', 0.0) or 0.0):.0%} "
                        "of new_search scenes to preferred_source youtube."
                        if getattr(config, "YOUTUBE_FOOTAGE_ENABLED", False)
                        else "YouTube Footage is disabled. Do not use preferred_source youtube."
                    ),
                )
                .replace(
                    "{{CONTEXT_PACKETS_JSON}}",
                    json.dumps(batch, ensure_ascii=False, indent=2),
                )
                .replace(
                    "{{VISUAL_HISTORY_JSON}}",
                    json.dumps(history, ensure_ascii=False, indent=2),
                )
                .replace("{{ALLOW_REUSE}}", "true" if allow_reuse else "false")
            )
            payload = transport.call_json(
                phase=f"visual_queries_{batch_index:03d}",
                prompt=prompt,
                schema_file="visual_story_queries.json",
            )
            raw_plans = _plans_from_payload(payload)
            if len(raw_plans) != len(batch):
                repair_prompt = (
                    prompt
                    + "\n\nYour preceding response was invalid because it returned "
                    f"{len(raw_plans)} plan(s) for {len(batch)} context packets. "
                    "Return the complete batch now. The only valid top-level JSON "
                    'shape is {"plans":[...]} with one plan per packet in order.'
                )
                payload = transport.call_json(
                    phase=f"visual_queries_{batch_index:03d}_repair",
                    prompt=repair_prompt,
                    schema_file="visual_story_queries.json",
                )
                raw_plans = _plans_from_payload(payload)
        if len(raw_plans) != len(batch):
            raise ValueError(
                f"Visual query batch {batch_index} returned "
                f"{len(raw_plans)}/{len(batch)} plans"
            )
        _validate_batch_plan_ids(raw_plans, batch, batch_index)
        for packet, raw in zip(batch, raw_plans):
            plans.append(
                _normalize_plan(
                    raw,
                    int(packet["scene_id"]),
                    allow_reuse=allow_reuse,
                )
            )

    validate_visual_plans(plans, len(packets), allow_reuse=allow_reuse)
    jsonl = story / "visual_plans.jsonl"
    with jsonl.open("w", encoding="utf-8") as stream:
        for plan in plans:
            stream.write(json.dumps(plan, ensure_ascii=False) + "\n")
    (story / "visual_plans.json").write_text(
        json.dumps({"version": 1, "plans": plans}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return plans
