@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

REM ============================================================================
REM 1_SILENTSTART.BAT - Start from transcription stage (Silent Mode)
REM Stage 1: Transcription -> Direction  (audio already in ready_to_go\)
REM ============================================================================

echo.
echo ================================================================================
echo  1_SILENTSTART  [Transcription + Direction]  SILENT MODE
echo ================================================================================

set "ENV_FILE=%~dp0agent\.env"
set "AGENT=%~dp0agent\agent.py"

REM Read settings from .env for display
set "ASSEMBLYAI_LANGUAGE_CODE=ru"
set "GEMINI_MODEL=gemini-3.1-pro-preview"
set "GEMINI_TWO_PASS=true"
set "VIDEO_CLIP_MIN_DURATION=4"
set "VIDEO_CLIP_MAX_DURATION=8"
set "ASSEMBLYAI_SEGMENTATION_MODE=words"
set "INTRO_BLOCK_DURATION=30"
set "INTRO_CLIP_MIN_DURATION=0"
set "INTRO_CLIP_MAX_DURATION=0"
set "VEONONSTOP_ASPECT_RATIO=16:9"
set "VEONONSTOP_MAX_PARALLEL=3"

for /f "usebackq tokens=1,* delims==" %%A in ("%ENV_FILE%") do (
    set "KEY=%%A"
    set "VAL=%%B"
    set "KEY=!KEY: =!"
    if "!KEY!"=="ASSEMBLYAI_LANGUAGE_CODE"     set "ASSEMBLYAI_LANGUAGE_CODE=!VAL!"
    if "!KEY!"=="GEMINI_MODEL"                 set "GEMINI_MODEL=!VAL!"
    if "!KEY!"=="GEMINI_TWO_PASS"              set "GEMINI_TWO_PASS=!VAL!"
    if "!KEY!"=="VIDEO_CLIP_MIN_DURATION"      set "VIDEO_CLIP_MIN_DURATION=!VAL!"
    if "!KEY!"=="VIDEO_CLIP_MAX_DURATION"      set "VIDEO_CLIP_MAX_DURATION=!VAL!"
    if "!KEY!"=="ASSEMBLYAI_SEGMENTATION_MODE" set "ASSEMBLYAI_SEGMENTATION_MODE=!VAL!"
    if "!KEY!"=="INTRO_BLOCK_DURATION"         set "INTRO_BLOCK_DURATION=!VAL!"
    if "!KEY!"=="INTRO_CLIP_MIN_DURATION"      set "INTRO_CLIP_MIN_DURATION=!VAL!"
    if "!KEY!"=="INTRO_CLIP_MAX_DURATION"      set "INTRO_CLIP_MAX_DURATION=!VAL!"
    if "!KEY!"=="VEONONSTOP_ASPECT_RATIO"      set "VEONONSTOP_ASPECT_RATIO=!VAL!"
    if "!KEY!"=="VEONONSTOP_MAX_PARALLEL"      set "VEONONSTOP_MAX_PARALLEL=!VAL!"
)

set "TWO_PASS_FLAG=--two-pass"

echo.
echo  CURRENT SETTINGS (.env):
echo  -------------------------------------------------------
echo  Transcription lang:   !ASSEMBLYAI_LANGUAGE_CODE!
echo  Segmentation mode:    !ASSEMBLYAI_SEGMENTATION_MODE!
echo  Gemini model:         !GEMINI_MODEL!
echo  Two-pass mode:        always ON
echo  Clip duration:        !VIDEO_CLIP_MIN_DURATION!-!VIDEO_CLIP_MAX_DURATION!s
echo  Intro block:          first !INTRO_BLOCK_DURATION!s  /  clips: !INTRO_CLIP_MIN_DURATION!s-!INTRO_CLIP_MAX_DURATION!s
echo  -------------------------------------------------------
echo.

set /p "CONFIRM=All correct? Start pipeline? (y=start / n=switch to interactive): "
echo.

if /i "!CONFIRM!"=="n" (
    echo  Switching to interactive mode...
    echo.
    call "%~dp01_interactivestart.bat"
    exit /b
)

if /i not "!CONFIRM!"=="y" (
    echo  Cancelled.
    pause
    exit /b 1
)

REM ============================================================================
REM  POST-PIPELINE: generation mode (approve once - runs silent, no prompts)
REM ============================================================================

echo  Post-pipeline generation (after transcription + direction):
echo.
echo    [1] Skip - manual via bat files          (default)
echo    [2] FastGen images only
echo    [3] FastGen images + VeoNonStop i2v      (animate)
echo    [4] VeoNonStop text-to-video (t2v)
echo    [5] VeoNonStop components (t2v + ref/)
echo.
echo  Veo settings from .env: ratio=!VEONONSTOP_ASPECT_RATIO!  parallel=!VEONONSTOP_MAX_PARALLEL!
echo  No further questions after start.
echo.

set "POST_ACTION=skip"
set /p POST_CHOICE="  Post-pipeline [1-5] (Enter = 1 skip): "
if "!POST_CHOICE!"=="2" set "POST_ACTION=fastgen"
if "!POST_CHOICE!"=="3" set "POST_ACTION=fastgen_i2v"
if "!POST_CHOICE!"=="4" set "POST_ACTION=t2v"
if "!POST_CHOICE!"=="5" set "POST_ACTION=components"

echo.
echo  Selected: !POST_ACTION!
echo.

echo ================================================================================
echo  Starting pipeline [post-action: !POST_ACTION!]...
echo ================================================================================
echo.

cd /d "%~dp0agent"
python agent.py process --run --language !ASSEMBLYAI_LANGUAGE_CODE! --two-pass --clip-mode video --post-action !POST_ACTION!

if errorlevel 1 (
    echo.
    echo [ERROR] Pipeline failed!
    pause
    exit /b 1
)

echo.
echo ================================================================================
echo  [OK] 1_SILENTSTART complete! Check projects\ folder.
echo ================================================================================
pause
