#!/bin/bash
# START_VEO_T2V.COMMAND - VeoNonStop Text-to-Video (t2v)
# Run: double-click this file in Finder

PROJECT_NAME="{project_name}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
AGENT_DIR="$(cd "$SCRIPT_DIR/../../agent" && pwd)"

chmod +x *.command *.sh 2>/dev/null
[ -f "$SCRIPT_DIR/.venv/bin/activate" ] && source "$SCRIPT_DIR/.venv/bin/activate"

if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e "tell app \"Terminal\" to do script \"cd '$SCRIPT_DIR' && exec '$0'\""
    exit 0
fi

echo ""
echo "========================================================================"
echo "  VeoNonStop TEXT-TO-VIDEO (t2v)"
echo "  Project: $PROJECT_NAME"
echo "========================================================================"
echo ""

# Aspect ratio
echo "  Select aspect ratio:"
echo "    [1] 16:9   landscape, default"
echo "    [2] 9:16   portrait"
echo "    [3] 1:1    square"
echo ""
read -p "  Aspect [1/2/3] (Enter = 1): " RATIO_CHOICE
RATIO="16:9"
case "$RATIO_CHOICE" in
    2) RATIO="9:16" ;;
    3) RATIO="1:1" ;;
esac
echo "    Selected: $RATIO"
echo ""

# Account slots check
echo "  Checking VeoNonStop account slots..."
KEY1_SLOTS=0
KEY2_SLOTS=0
KEY3_SLOTS=0
KEY4_SLOTS=0
TMPSLOTS=$(mktemp /tmp/veo_slots_XXXXXX.txt)
pushd "$AGENT_DIR" > /dev/null
python check_slots.py > "$TMPSLOTS" 2>/dev/null
popd > /dev/null
while IFS='=' read -r k v; do
    case "$k" in
        key1) KEY1_SLOTS="$v" ;;
        key2) KEY2_SLOTS="$v" ;;
        key3) KEY3_SLOTS="$v" ;;
        key4) KEY4_SLOTS="$v" ;;
    esac
done < "$TMPSLOTS"
cat "$TMPSLOTS"
rm -f "$TMPSLOTS"
echo ""

# Key selection
KEY_TOTAL=$((KEY1_SLOTS + KEY2_SLOTS + KEY3_SLOTS + KEY4_SLOTS))
echo "  Select API key:"
echo "    [1] Key1  ($KEY1_SLOTS slots)    (default)"
[ "$KEY2_SLOTS" -gt 0 ] 2>/dev/null && echo "    [2] Key2  ($KEY2_SLOTS slots)"
[ "$KEY3_SLOTS" -gt 0 ] 2>/dev/null && echo "    [3] Key3  ($KEY3_SLOTS slots)"
[ "$KEY4_SLOTS" -gt 0 ] 2>/dev/null && echo "    [4] Key4  ($KEY4_SLOTS slots)"
[ "$KEY_TOTAL" -gt "$KEY1_SLOTS" ] 2>/dev/null && echo "    [A] All   ($KEY_TOTAL slots total)"
echo ""
KEY_SLOT="1"
KEY_LABEL="Key1"
KEY_DEFAULT_PARALLEL="$KEY1_SLOTS"
read -p "  Key [1/2/3/4/A] (Enter = 1): " KEY_CHOICE
case "$KEY_CHOICE" in
    2) KEY_SLOT="2"; KEY_LABEL="Key2"; KEY_DEFAULT_PARALLEL="$KEY2_SLOTS"; echo "    Selected: Key2" ;;
    3) KEY_SLOT="3"; KEY_LABEL="Key3"; KEY_DEFAULT_PARALLEL="$KEY3_SLOTS"; echo "    Selected: Key3" ;;
    4) KEY_SLOT="4"; KEY_LABEL="Key4"; KEY_DEFAULT_PARALLEL="$KEY4_SLOTS"; echo "    Selected: Key4" ;;
    [aA]) KEY_SLOT="all"; KEY_LABEL="All"; KEY_DEFAULT_PARALLEL="$KEY_TOTAL"; echo "    Selected: All" ;;
    *) echo "    Selected: Key1" ;;
esac
echo ""

# Parallel
if [ "$KEY_DEFAULT_PARALLEL" -eq 0 ] 2>/dev/null; then KEY_DEFAULT_PARALLEL=12; fi
read -p "  Parallel workers (Enter = $KEY_DEFAULT_PARALLEL): " PARALLEL
PARALLEL="${PARALLEL:-$KEY_DEFAULT_PARALLEL}"
echo "    Selected: $PARALLEL"
echo ""

# Clip IDs
read -p "  Clip IDs (e.g. 1,2,3 or Enter for all): " IDS_INPUT
IDS_ARG=""
if [ -n "$IDS_INPUT" ]; then
    IDS_ARG="--ids $IDS_INPUT"
    echo "    Clips: $IDS_INPUT"
else
    echo "    Clips: ALL"
fi
echo ""

# Prompt source
echo "  Prompt source:"
echo "    [1] Director prompts (per-clip)"
echo "    [2] Single prompt for all clips"
echo ""
read -p "  Prompt [1/2] (Enter = 1): " PROMPT_CHOICE
PROMPT_ARG=""
if [ "$PROMPT_CHOICE" = "2" ]; then
    read -p "  Enter prompt: " PROMPT_INPUT
    if [ -n "$PROMPT_INPUT" ]; then
        PROMPT_ARG="--prompt \"$PROMPT_INPUT\""
        echo "    Prompt: single"
    else
        echo "    Prompt: per-clip"
    fi
else
    echo "    Prompt: per-clip"
fi
echo ""

# Confirm
echo "========================================================================"
echo "  SUMMARY:"
echo "    Project:  $PROJECT_NAME"
echo "    Mode:     t2v (text-to-video)"
echo "    Key:      $KEY_LABEL"
echo "    Ratio:    $RATIO"
echo "    Parallel: $PARALLEL"
echo "========================================================================"
echo ""
read -p "  Start? (y/n): " CONFIRM
if [ "$CONFIRM" != "y" ] && [ "$CONFIRM" != "Y" ]; then
    echo "  Cancelled."
    exit 0
fi

echo ""
echo "  Starting text-to-video..."
echo ""

cd "$AGENT_DIR"

eval python agent.py img2video \
    --project "$PROJECT_NAME" \
    --mode "t2v" \
    --ratio "$RATIO" \
    --parallel "$PARALLEL" \
    --key-slot "$KEY_SLOT" $IDS_ARG $PROMPT_ARG

EXIT_CODE=$?
echo ""
if [ $EXIT_CODE -ne 0 ]; then
    echo "[ERROR] t2v generation failed. See log above."
else
    echo "========================================================================"
    echo "  DONE. Output: $SCRIPT_DIR/vid_img/"
    echo "========================================================================"
fi
echo ""
read -p "Press Enter to close..."
