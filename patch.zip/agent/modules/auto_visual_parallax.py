"""Auto Visual Story handoff for selective EPF/stock-photo parallax."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable

import config
from modules.clip_sources import AUTO_VISUAL_PARALLAX_PHOTO_SOURCES


IMAGE_EXTENSIONS = (".png", ".jpg", ".jpeg", ".webp")


def ready_auto_visual_photo_ids(project_dir: str | Path,
                                sources=None,
                                include_ai: bool = False) -> list[int]:
    """Return ordered ready photo IDs, excluding all video sources.

    ``sources`` — какие источники брать. По умолчанию набор Auto Visual Story
    (Real Photo + сток), в стандартном режиме сюда приходит выбор пользователя
    галками рядом с параллаксом.
    ``include_ai`` — добавить нейрокадры (галка «AI»). Включается только когда
    видеогенерация выключена: при работающем i2v те же кадры оживляет обычная
    стадия, и второй проход отправил бы их повторно.
    """
    from modules.clip_sources import VIDEO_SKIP_SOURCES

    allowed = set(sources) if sources is not None else set(
        AUTO_VISUAL_PARALLAX_PHOTO_SOURCES)
    # Учитываем и НАМЕРЕНИЕ режиссёра, а не только закрытые клипы: пока стадия
    # качает, у клипа промежуточный маркер (`stock_pending`), а если материал не
    # нашёлся — маркер вовсе снимут. Считая только по готовым, мы бы получали
    # каждый круг новый список, и «каждый N-й» ездил бы по ролику.
    if 'stock_photo' in allowed:
        allowed.add('stock_pending')
    if 'real_photo' in allowed:
        allowed.add('real_photo_pending')
    project = Path(project_dir)
    plan_path = project / "montage_plan.json"
    raw = json.loads(plan_path.read_text(encoding="utf-8-sig"))
    plan = raw.get("montage_plan", raw)
    generated = project / "generated"
    result: list[int] = []
    for clip in plan.get("clips", []):
        source = clip.get("source")
        if include_ai and source not in VIDEO_SKIP_SOURCES:
            # Нейрокадр: внешнего маркера нет, материал — картинка в
            # generated/. Берём его ТОЛЬКО когда видеогенерация выключена: при
            # включённом i2v его оживит обычная стадия, и параллакс-промпт
            # подставит она сама — иначе кадр ушёл бы в работу дважды.
            pass
        elif source not in allowed:
            continue
        try:
            result.append(int(clip["id"]))
        except (KeyError, TypeError, ValueError):
            continue
    return result


def photo_ready_for_parallax(project_dir: str | Path, clip_id: int) -> bool:
    """Готов ли кадр к отправке: картинка на месте, видео ещё нет."""
    project = Path(project_dir)
    if (project / "vid_img" / f"{clip_id:03d}.mp4").is_file():
        return False                       # уже оживлён — второй раз не шлём
    generated = project / "generated"
    return any((generated / f"{clip_id:03d}{ext}").is_file()
               for ext in IMAGE_EXTENSIONS)


def run_auto_visual_parallax(
    project_dir: str | Path,
    generate_videos: Callable[..., dict[str, Any]],
    sources=None,
    include_ai: bool = False,
) -> dict[str, Any]:
    """Run normal Veo I2V for every Nth ready photo of the given sources.

    ``generate_videos`` is the regular ``veo_generate_all_videos`` entrypoint,
    injected here so the selection behavior can be tested without network calls.
    ``sources`` — набор источников; None = набор Auto Visual Story. Прореживание
    (`VEONONSTOP_I2V_PARALLAX_EVERY_N`) здесь ровно то же, что у нейрокадров в
    обычном i2v, — настройка одна на обе ветки.
    """
    project = Path(project_dir)
    eligible_ids = ready_auto_visual_photo_ids(project, sources, include_ai)
    try:
        every_n = max(
            1,
            int(getattr(config, "VEONONSTOP_I2V_PARALLAX_EVERY_N", 2) or 2),
        )
    except (TypeError, ValueError):
        every_n = 2
    # Здесь работает ТОЛЬКО «каждый N-й», без оглядки на «Mix with per-clip».
    # Микс — про выбор между параллакс-промптом и промптом сцены, а в этом
    # проходе второго варианта не существует: фото в i2v не попадают вовсе, а
    # нейрокадры приходят сюда лишь при выключенной видеогенерации, где
    # перклип-оживления нет. Кто не попал — остаётся картинкой и получает зум в
    # склейке. Нужно оживить все — ставится Every N = 1 (замечание юзера 28.08).
    #
    # Каждый N-й считается ПО СПИСКУ подходящих клипов плана, а не по номеру
    # клипа: номера расставлены по всему ролику, и при N=2 источник, легший на
    # нечётные позиции, не получил бы параллакс вовсе. По списку охват ровный —
    # статики под номерами 3, 8, 9, 14, 17, 28 при N=3 дают клипы 9 и 28.
    # Список строится по плану (включая ещё не закрытые клипы), поэтому он не
    # зависит от того, что успело скачаться, и не меняется от круга к кругу.
    chosen = [cid for index, cid in enumerate(eligible_ids, start=1)
              if index % every_n == 0]
    selected_ids = [cid for cid in chosen
                    if photo_ready_for_parallax(project, cid)]
    summary: dict[str, Any] = {
        "eligible_ids": eligible_ids,
        "chosen_ids": chosen,
        "selected_ids": selected_ids,
        "every_n": every_n,
        "result": None,
    }
    if not selected_ids:
        return summary
    summary["result"] = generate_videos(
        project_dir=str(project),
        mode="i2v",
        clip_ids=selected_ids,
        silent=True,
        no_cancel=True,
        allow_external_image_clip_ids=selected_ids,
        parallax_only=True,
    )
    return summary


def watch_parallax(
    project_dir: str | Path,
    generate_videos: Callable[..., dict[str, Any]],
    sources=None,
    include_ai: bool = False,
    *,
    stop_event=None,
    poll_sec: float = 6.0,
    printer=print,
) -> dict[str, Any]:
    """Оживлять кадры параллаксом ПО МЕРЕ ГОТОВНОСТИ, не дожидаясь стадий.

    Список «кого паралаксить» считается ОДИН раз по плану — каждый N-й из
    подходящих клипов, — поэтому он не зависит от того, что успело скачаться.
    Дальше цикл просто ждёт, когда у выбранных появятся картинки: готовые
    уходят в VeoNonStop сразу, остальные ждут следующего круга.

    Останавливается по `stop_event` (его ставит пайплайн, когда стадии-источники
    закончили) — после чего делает последний круг по остаткам.
    """
    project = Path(project_dir)
    eligible_ids = ready_auto_visual_photo_ids(project, sources, include_ai)
    try:
        every_n = max(
            1,
            int(getattr(config, "VEONONSTOP_I2V_PARALLAX_EVERY_N", 2) or 2),
        )
    except (TypeError, ValueError):
        every_n = 2
    chosen = [cid for index, cid in enumerate(eligible_ids, start=1)
              if index % every_n == 0]
    summary: dict[str, Any] = {
        "eligible_ids": eligible_ids,
        "chosen_ids": chosen,
        "done_ids": [],
        "every_n": every_n,
        "rounds": 0,
    }
    if not chosen:
        return summary
    printer(f"  [Параллакс] в очереди {len(chosen)} кадр(ов) из "
            f"{len(eligible_ids)} (каждый {every_n}-й), жду их готовности")

    import time as _time

    done: set = set()
    while True:
        finishing = stop_event is not None and stop_event.is_set()
        ready = [cid for cid in chosen
                 if cid not in done and photo_ready_for_parallax(project, cid)]
        if ready:
            summary["rounds"] += 1
            printer(f"  [Параллакс] отправляю {len(ready)} кадр(ов): "
                    + ", ".join(f"{cid:03d}" for cid in ready))
            try:
                generate_videos(
                    project_dir=str(project),
                    mode="i2v",
                    clip_ids=ready,
                    silent=True,
                    no_cancel=True,
                    allow_external_image_clip_ids=ready,
                    parallax_only=True,
                )
            except Exception as exc:                      # noqa: BLE001
                # Параллакс — украшение: кадр останется картинкой и получит
                # зум в склейке, ронять из-за него прогон нельзя.
                printer(f"  [Параллакс] партия не удалась: {str(exc)[:200]}")
            done.update(ready)
            summary["done_ids"] = sorted(done)
        if finishing or len(done) >= len(chosen):
            break
        _time.sleep(max(1.0, float(poll_sec)))
    waiting = [cid for cid in chosen if cid not in done]
    if waiting:
        printer(f"  [Параллакс] без картинки к концу стадий: "
                + ", ".join(f"{cid:03d}" for cid in waiting)
                + " — останутся статикой с зумом")
    return summary
