"""
Utilities for keeping music_plan.json practical for background music.

The director can still choose semantic cue points, but Suno is much more
reliable when we ask for a small number of long instrumental beds. The final
mix stage already trims/loops each bed to the exact slot.
"""
from __future__ import annotations

import os
from copy import deepcopy
from math import ceil
from typing import Any, Dict, Iterable, List


def _coerce_db(value: Any, default: float = -21.0) -> float:
    try:
        db = float(value)
    except (TypeError, ValueError):
        db = float(default)
    if db > 0:
        db = -db
    return max(-60.0, min(0.0, db))


def _default_volume_db() -> float:
    return _coerce_db(os.getenv("MUSIC_DEFAULT_VOLUME_DB", "-21"), -21.0)


def normalize_music_plan(
    plan: Dict[str, Any],
    audio_duration: float,
    *,
    min_track_duration: int = 120,
    max_track_duration: int = 240,
    max_tracks: int = 10,
) -> Dict[str, Any]:
    """Return a normalized plan with long continuous tracks and <= max_tracks."""
    plan = deepcopy(plan)
    tracks = _valid_tracks(plan.get("tracks", []))
    if not tracks:
        plan["tracks"] = []
        return plan

    audio_duration = float(audio_duration or plan.get("audioDuration") or 0.0)
    if audio_duration <= 0:
        audio_duration = float(tracks[-1].get("endTime", 0.0))

    tracks = _drop_leading_silence(tracks)
    tracks = _make_continuous(tracks, audio_duration)

    effective_min = _effective_min_duration(audio_duration, min_track_duration, max_tracks)
    tracks = _merge_short_tracks(tracks, effective_min)
    tracks = _limit_track_count(tracks, max_tracks)

    if max_track_duration > 0:
        tracks = _split_long_tracks(tracks, max_track_duration, max_tracks)

    tracks = _make_continuous(tracks, audio_duration)
    tracks = _renumber(tracks)
    tracks = _force_dynamic_intro(tracks)

    default_volume_db = _default_volume_db()
    plan["audioDuration"] = audio_duration
    plan["global_volume_db"] = _coerce_db(plan.get("global_volume_db", default_volume_db), default_volume_db)
    for track in tracks:
        track["volume_db"] = _coerce_db(track.get("volume_db", plan["global_volume_db"]), plan["global_volume_db"])
    plan["tracks"] = tracks
    return plan


def _valid_tracks(raw_tracks: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    tracks: List[Dict[str, Any]] = []
    for raw in raw_tracks:
        if not isinstance(raw, dict):
            continue
        t = deepcopy(raw)
        try:
            st = float(t.get("startTime", 0.0))
            en = float(t.get("endTime", st))
        except (TypeError, ValueError):
            continue
        if en <= st:
            continue
        t["startTime"] = st
        t["endTime"] = en
        t["instrumental"] = True
        tracks.append(t)
    tracks.sort(key=lambda item: float(item.get("startTime", 0.0)))
    return tracks


def _effective_min_duration(audio_duration: float, requested_min: int, max_tracks: int) -> float:
    if audio_duration <= 0:
        return float(requested_min)
    if audio_duration <= requested_min:
        return audio_duration
    if max_tracks <= 1:
        return min(float(requested_min), audio_duration)
    if ceil(audio_duration / float(requested_min)) <= max_tracks:
        return float(requested_min)
    return max(1.0, audio_duration / float(max_tracks))


def _make_continuous(tracks: List[Dict[str, Any]], audio_duration: float) -> List[Dict[str, Any]]:
    if not tracks:
        return tracks
    cursor = 0.0
    fixed: List[Dict[str, Any]] = []
    for idx, t in enumerate(tracks):
        item = deepcopy(t)
        item["startTime"] = round(cursor, 2)
        if idx == len(tracks) - 1 and audio_duration > 0:
            end = audio_duration
        else:
            end = max(cursor + 0.1, float(item.get("endTime", cursor + 0.1)))
        item["endTime"] = round(end, 2)
        cursor = end
        fixed.append(item)
    return fixed


def _drop_leading_silence(tracks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Do not allow a silent/calm gap before the first background bed."""
    first_music_idx = None
    for idx, track in enumerate(tracks):
        genre = str(track.get("genre") or "").strip().lower()
        prompt = str(track.get("prompt") or "").strip()
        if genre != "silence" and prompt:
            first_music_idx = idx
            break
    if first_music_idx is None:
        return tracks
    if first_music_idx == 0:
        return tracks
    return [deepcopy(t) for t in tracks[first_music_idx:]]


def _merge_short_tracks(tracks: List[Dict[str, Any]], min_duration: float) -> List[Dict[str, Any]]:
    if len(tracks) <= 1 or min_duration <= 0:
        return tracks

    merged: List[Dict[str, Any]] = []
    bucket: List[Dict[str, Any]] = []

    for track in tracks:
        bucket.append(track)
        bucket_duration = float(bucket[-1]["endTime"]) - float(bucket[0]["startTime"])
        if bucket_duration >= min_duration:
            merged.append(_merge_group(bucket))
            bucket = []

    if bucket:
        tail = _merge_group(bucket)
        if merged:
            prev = merged[-1]
            prev_duration = float(prev["endTime"]) - float(prev["startTime"])
            if prev_duration < min_duration or len(bucket) == 1:
                merged[-1] = _merge_group([prev, tail])
            else:
                merged.append(tail)
        else:
            merged.append(tail)
    return merged


def _limit_track_count(tracks: List[Dict[str, Any]], max_tracks: int) -> List[Dict[str, Any]]:
    if max_tracks <= 0:
        return tracks
    limited = list(tracks)
    while len(limited) > max_tracks:
        best_idx = 0
        best_duration = None
        for idx in range(len(limited) - 1):
            dur = float(limited[idx + 1]["endTime"]) - float(limited[idx]["startTime"])
            if best_duration is None or dur < best_duration:
                best_idx = idx
                best_duration = dur
        limited[best_idx:best_idx + 2] = [_merge_group(limited[best_idx:best_idx + 2])]
    return limited


def _split_long_tracks(
    tracks: List[Dict[str, Any]],
    max_duration: int,
    max_tracks: int,
) -> List[Dict[str, Any]]:
    if max_duration <= 0:
        return tracks

    result: List[Dict[str, Any]] = []
    remaining_slots = max(0, max_tracks - len(tracks))
    for track in tracks:
        duration = float(track["endTime"]) - float(track["startTime"])
        if duration <= max_duration or remaining_slots <= 0:
            result.append(track)
            continue

        pieces = min(int(ceil(duration / float(max_duration))), remaining_slots + 1)
        if pieces <= 1:
            result.append(track)
            continue

        step = duration / pieces
        for idx in range(pieces):
            part = deepcopy(track)
            part["startTime"] = round(float(track["startTime"]) + step * idx, 2)
            part["endTime"] = round(
                float(track["startTime"]) + step * (idx + 1),
                2,
            )
            if pieces > 1:
                base_title = str(part.get("title") or "Music Bed")
                part["title"] = f"{base_title} Part {idx + 1}"
            result.append(part)
        remaining_slots -= pieces - 1
    return result


def _merge_group(group: List[Dict[str, Any]]) -> Dict[str, Any]:
    if len(group) == 1:
        item = deepcopy(group[0])
        item["instrumental"] = True
        return item

    first = group[0]
    last = group[-1]
    merged = deepcopy(first)
    merged["startTime"] = float(first["startTime"])
    merged["endTime"] = float(last["endTime"])
    merged["instrumental"] = True
    merged["source_track_ids"] = [
        item.get("id") for item in group if item.get("id") is not None
    ]

    moods = _unique_text(item.get("mood") for item in group)
    genres = _unique_text(item.get("genre") for item in group)
    titles = _unique_text(item.get("title") for item in group)
    prompts = _unique_text(item.get("prompt") for item in group)
    tags = _unique_tags(item.get("tags") for item in group)
    anchors = _unique_text(item.get("text_anchor") for item in group)

    if moods:
        merged["mood"] = " / ".join(moods[:4])
    if anchors:
        merged["text_anchor"] = " | ".join(anchors[:4])
    if genres:
        merged["genre"] = genres[0]
    if titles:
        merged["title"] = " + ".join(titles[:3])
    if prompts:
        if len(prompts) == 1:
            merged["prompt"] = prompts[0]
        else:
            merged["prompt"] = (
                f"{prompts[0]}, evolving underscore, later shifting toward "
                f"{prompts[-1]}"
            )
    if tags:
        merged["tags"] = ", ".join(tags[:10])

    merged["energy"] = first.get("energy") or last.get("energy") or "mid"
    start_energy = first.get("energy") or "mid"
    end_energy = last.get("energy") or start_energy
    merged["energy_arc"] = start_energy if start_energy == end_energy else f"{start_energy}->{end_energy}"
    merged["fade_in_ms"] = first.get("fade_in_ms", 1500)
    merged["fade_out_ms"] = last.get("fade_out_ms", 2500)
    merged["volume_db"] = first.get("volume_db", _default_volume_db())
    return merged


def _renumber(tracks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    numbered: List[Dict[str, Any]] = []
    for idx, track in enumerate(tracks, 1):
        item = deepcopy(track)
        item["id"] = idx
        if item.get("file"):
            item["file"] = f"{idx}.mp3"
        item["instrumental"] = True
        numbered.append(item)
    return numbered


def _force_dynamic_intro(tracks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Make the first generated bed start with momentum while preserving topic/style."""
    fixed = [deepcopy(t) for t in tracks]
    first_idx = None
    for idx, track in enumerate(fixed):
        genre = str(track.get("genre") or "").strip().lower()
        prompt = str(track.get("prompt") or "").strip()
        if genre != "silence" and prompt:
            first_idx = idx
            break
    if first_idx is None:
        return fixed

    track = fixed[first_idx]
    track["intro_dynamic"] = True
    track["startTime"] = 0.0
    track["energy"] = "high"
    track["energy_arc"] = "high->mid"
    track["hook_seconds"] = int(track.get("hook_seconds") or 12)
    track["fade_in_ms"] = 0
    track["volume_db"] = _coerce_db(track.get("volume_db", _default_volume_db()), _default_volume_db())

    prompt = str(track.get("prompt") or "").strip()
    dynamic_prefix = (
        "dynamic cinematic intro, starts immediately with pulsing percussion, "
        "impact hit on the first beat, audible in the first second, "
        "urgent rhythmic momentum, tense orchestral stabs, driving low strings, "
        "high-impact hook for the first 8-12 seconds then settles under narration"
    )
    dynamic_suffix = (
        "no silence before the music, no slow fade-in, no quiet opening, "
        "no ambient pad-only opening, immediate hook, documentary underscore, "
        "instrumental, no vocals, no lyrics"
    )
    low_prompt = prompt.lower()
    if "dynamic cinematic intro" not in low_prompt:
        prompt = f"{dynamic_prefix}, {prompt}"
    low_prompt = prompt.lower()
    for avoid in ("no slow fade-in", "immediate hook", "audible in the first second"):
        if avoid not in low_prompt:
            prompt = f"{prompt}, {dynamic_suffix}"
            break
    track["prompt"] = prompt.strip(" ,")

    tags = _unique_tags([
        track.get("tags"),
        "dynamic intro, first beat impact, urgent, pulsing percussion, cinematic, tense, instrumental",
    ])
    track["tags"] = ", ".join(tags[:12])

    title = str(track.get("title") or "").strip()
    if title and "intro" not in title.lower():
        track["title"] = f"Dynamic Intro - {title}"
    elif not title:
        track["title"] = "Dynamic Intro"
    return fixed


def _unique_text(values: Iterable[Any]) -> List[str]:
    seen = set()
    out: List[str] = []
    for value in values:
        text = str(value or "").strip()
        if not text or text.lower() in seen:
            continue
        seen.add(text.lower())
        out.append(text)
    return out


def _unique_tags(values: Iterable[Any]) -> List[str]:
    seen = set()
    out: List[str] = []
    for value in values:
        for raw in str(value or "").split(","):
            tag = raw.strip()
            key = tag.lower()
            if not tag or key in seen:
                continue
            seen.add(key)
            out.append(tag)
    if "instrumental" not in seen:
        out.append("instrumental")
    return out
