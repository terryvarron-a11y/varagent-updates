"""
clip_sources.py — единый реестр маркеров `source` в montage_plan.json.

Клип с любым из этих маркеров обслуживает ВНЕШНЯЯ стадия (архив или сток), а не
нейрогенерация. ImgGen / FastGen / Veo / FlowUltra обязаны такие клипы пропускать:
иначе картинка сгенерится поверх скачанной — конфликт файлов и сожжённая квота,
причём молча.

Зачем модуль: литерал ('real_photo', 'real_photo_pending', 'real_video') был
скопирован в 7 файлов. Добавление нового источника требовало не забыть ни один —
забыл хоть один, получил двойную генерацию без единой ошибки в логе. Теперь точка
правды одна.

Значения маркеров
-----------------
Real Photo stage (архивные материалы: Wikipedia/NASA/LoC/Archive/Yandex/...):
  real_photo_pending — режиссёр пометил клип, стадия ещё не отработала
  real_photo         — архивное ФОТО скачано (лежит в generated/{id:03d}.{ext})
  real_video         — архивное ВИДЕО готово (лежит в vid_img/{id:03d}.mp4)
                       (видео-путь сейчас отключён, маркер зарезервирован)

Stock stage (Pexels / Pixabay / Coverr — современный постановочный футаж):
  stock_pending      — режиссёр пометил клип, стадия ещё не отработала
  stock_photo        — сток-ФОТО скачано (generated/{id:03d}.{ext}; concat сам
                       сделает Ken Burns)
  stock_video        — сток-ВИДЕО готово (vid_img/{id:03d}.mp4; уже обрезано под
                       длину клипа, zoom не нужен)

Сток и архив намеренно РАЗНЫЕ маркеры: у них разные источники, лицензии и смысл
(архив — исторический материал, сток — современная съёмка), и разные стадии.
"""
from __future__ import annotations

# Архивная стадия (real_photo.py)
REAL_PHOTO_SOURCES = frozenset({
    'real_photo',
    'real_photo_pending',
    'real_video',
})

# Стоковая стадия (Pexels/Pixabay/Coverr)
STOCK_SOURCES = frozenset({
    'stock_pending',
    'stock_photo',
    'stock_video',
})

# Всё, что НЕ должно попасть в нейрогенерацию.
# Именно этот набор проверяют ImgGen/FastGen/Veo/FlowUltra/watch_i2v.
EXTERNAL_SOURCES = REAL_PHOTO_SOURCES | STOCK_SOURCES

# Клипы, чей материал кладётся в vid_img/ готовым видео (concat берёт как фрагмент,
# Ken Burns не применяется).
VIDEO_SOURCES = frozenset({'real_video', 'stock_video'})

# Клипы, чей материал кладётся картинкой в generated/ (concat делает Ken Burns).
PHOTO_SOURCES = frozenset({'real_photo', 'stock_photo'})


def is_external(source: str | None) -> bool:
    """True, если клип обслуживает внешняя стадия и генератор должен его пропустить."""
    return bool(source) and source in EXTERNAL_SOURCES


def log_source_markup(clips, printer=print) -> None:
    """Сводка разметки Pass 1 в лог юзера: сколько клипов помечено под Real Photo /
    Сток. Печатается только для ВКЛЮЧЁННЫХ стадий — в т.ч. явный ноль («Сток: 0»),
    чтобы не гадать, почему сток-стадия не оставила ни одного файла (она молча
    выходит при нуле помеченных клипов)."""
    import config
    rp_on = bool(getattr(config, 'REAL_PHOTO_ENABLED', False))
    st_on = bool(getattr(config, 'STOCK_ENABLED', False))
    if not (rp_on or st_on):
        return
    clips = clips or []
    n_rp = sum(1 for c in clips if c.get('source') in REAL_PHOTO_SOURCES)
    n_st = sum(1 for c in clips if c.get('source') in STOCK_SOURCES)
    parts = []
    if rp_on:
        parts.append(f"Real Photo: {n_rp}")
    if st_on:
        parts.append(f"Сток: {n_st}")
    printer(f"   📋 Разметка стадий: {' | '.join(parts)}  (из {len(clips)} клипов)")
    if rp_on and n_rp == 0:
        printer("      ⚠️  Real Photo включён, но режиссёр не пометил ни одного клипа — стадия будет пропущена")
    if st_on and n_st == 0:
        printer("      ⚠️  Сток включён, но режиссёр не пометил ни одного клипа — стадия будет пропущена")


def apply_clip_source_delta(montage_path, delta, *, retries: int = 6, delay: float = 5.0,
                            acquire_timeout: float = 4.0, log=None) -> bool:
    """Атомарно применить дельту к СВОИМ клипам montage_plan.json.

    Зачем: real_photo и сток — две ФОНОВЫЕ стадии, финишируют независимо и обе правят
    montage_plan. Если писать весь файл своим снимком — параллельная стадия затрёт чужие
    правки (гонка read-modify-write). Здесь каждая стадия под filelock ПЕРЕЧИТЫВАЕТ свежий
    файл и меняет ТОЛЬКО клипы из своей дельты — чужие клипы физически не переписываются
    устаревшим снимком, поэтому затирания нет.

    Ждать друг друга стадиям нельзя (упавшая/зависшая задержит готовую до таймаута), поэтому
    пишем независимо, а конфликт разруливаем локом.

    delta: {clip_id(int): patch(dict)}. Ключ 'source' со значением None → снять маркер
    (clip.pop('source')); прочие пары → clip[k] = v. Клипы не из delta не трогаются.

    При занятом локе НЕ падаем: ждём `delay` сек и повторяем (до `retries` раз). После
    исчерпания — форс-запись своей дельты (лучше записать, чем потерять результат стадии).
    Возвращает True при успешной записи.
    """
    import json
    import time
    from pathlib import Path

    montage_path = Path(montage_path)
    if not delta:
        return True

    def _do_write():
        raw = json.loads(montage_path.read_text(encoding='utf-8-sig'))
        container = raw['montage_plan'] if (isinstance(raw, dict) and 'montage_plan' in raw) else raw
        clips = (container.get('clips') if isinstance(container, dict) else None) or []
        for clip in clips:
            cid = clip.get('id')
            try:
                cid = int(cid)
            except (TypeError, ValueError):
                continue
            patch = delta.get(cid)
            if not patch:
                continue
            for k, v in patch.items():
                if k == 'source' and v is None:
                    clip.pop('source', None)
                else:
                    clip[k] = v
        montage_path.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding='utf-8')

    try:
        from filelock import FileLock, Timeout
    except Exception:
        # filelock недоступен — пишем без лока (лучше запись со слабым риском гонки, чем потеря)
        try:
            _do_write()
            return True
        except Exception as e:
            if log:
                log(f"montage delta write failed (no filelock): {e}")
            return False

    lock = FileLock(str(montage_path) + '.lock')
    for attempt in range(1, retries + 1):
        try:
            with lock.acquire(timeout=acquire_timeout):
                _do_write()
            return True
        except Timeout:
            if log:
                log(f"montage_plan занят другой стадией — жду {delay:.0f}с "
                    f"(попытка {attempt}/{retries})")
            time.sleep(delay)
        except Exception as e:
            if log:
                log(f"montage delta write error: {e}")
            return False
    # Все ретраи исчерпаны — форсируем свою дельту (ломаем зависший lock)
    if log:
        log("montage_plan lock не отпущен за все ретраи — форс-запись своей дельты")
    try:
        _do_write()
        return True
    except Exception as e:
        if log:
            log(f"montage force-write failed: {e}")
        return False
