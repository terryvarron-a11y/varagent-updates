"""
find_missing_clips.py - finds clip IDs missing from generated/ folder.

Usage:
  python find_missing_clips.py <project_name>

Output (stdout):
  Line 1: total prompts count
  Line 2: missing count
  Line 3: comma-separated missing IDs (or empty if none missing)
  Line 4+: one line per missing clip: "<id>: <prompt>"

Exit codes:
  0 - some clips missing (proceed with generation)
  1 - error (project/prompts not found)
  2 - nothing missing (all clips already generated)
"""
import sys
import os
from pathlib import Path

# Windows: force UTF-8 output
if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

# Add agent dir to path for imports
sys.path.insert(0, str(Path(__file__).parent))

import config
from extract_prompt import extract_all_prompts, find_prompts_file


def main():
    if len(sys.argv) < 2:
        print("Usage: find_missing_clips.py <project_name>", file=sys.stderr)
        sys.exit(1)

    project_name = sys.argv[1]
    base_dir = Path(__file__).parent.parent
    project_dir = base_dir / 'projects' / project_name

    if not project_dir.exists():
        print(f"ERROR: Project not found: {project_dir}", file=sys.stderr)
        sys.exit(1)

    # Load prompts
    prompts_file = find_prompts_file(str(project_dir))
    if not prompts_file:
        print(f"ERROR: No prompts file in {project_dir}", file=sys.stderr)
        sys.exit(1)

    all_prompts = extract_all_prompts(prompts_file)
    if not all_prompts:
        print(f"ERROR: No prompts parsed from {prompts_file}", file=sys.stderr)
        sys.exit(1)

    # Find already generated files
    generated_dir = project_dir / 'generated'
    generated_ids = set()
    if generated_dir.exists():
        for f in generated_dir.iterdir():
            if f.suffix.lower() == '.png' and f.stem.isdigit():
                generated_ids.add(int(f.stem))

    # Find missing
    all_ids = set(all_prompts.keys())
    missing_ids = sorted(all_ids - generated_ids)

    # Output
    print(len(all_prompts))                          # line 1: total
    print(len(missing_ids))                          # line 2: missing count
    print(','.join(str(i) for i in missing_ids))     # line 3: IDs csv

    for cid in missing_ids:
        prompt = all_prompts[cid]
        # truncate long prompts for display
        short = prompt[:120] + '...' if len(prompt) > 120 else prompt
        print(f"{cid}: {short}")                     # line 4+: id: prompt

    if not missing_ids:
        sys.exit(2)
    sys.exit(0)


if __name__ == '__main__':
    main()
