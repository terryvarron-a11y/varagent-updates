"""Cancel all VeoNonStop tasks — cleanup zombie tasks from previous runs."""
import os, requests, logging
from pathlib import Path
from dotenv import load_dotenv

logging.basicConfig(level=logging.WARNING, format='%(message)s')

# Load .env from agent/ dir
env_path = Path(__file__).resolve().parent / '.env'
load_dotenv(env_path)

api_key = os.getenv('VEONONSTOP_API_KEY', '')
if not api_key:
    print("0")
    exit()

try:
    resp = requests.post(
        'https://veononstop.com/api/v1/video/cancel-all',
        headers={'X-API-Key': api_key},
        timeout=15,
    )
    if resp.status_code in (200, 201):
        data = resp.json().get('data', {})
        count = data.get('cancelled_count', 0)
        tasks = data.get('tasks', [])
        if count > 0:
            logging.warning(f"cancel-all: {count} tasks cancelled: {tasks}")
        print(f"{count}")
    else:
        logging.warning(f"cancel-all failed ({resp.status_code}): {resp.text[:100]}")
        print("0")
except Exception as e:
    logging.warning(f"cancel-all error: {e}")
    print("0")
