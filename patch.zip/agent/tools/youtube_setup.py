# -*- coding: utf-8 -*-
"""Установка и обновление YouTube-модуля: yt-dlp + JavaScript-рантайм.

Зачем это отдельной кнопкой
---------------------------
1. `yt-dlp.exe` НЕ едет с обновлениями софта — он исключён из патча как крупный
   бинарник (`publisher.EXCLUDE_NAMES`). У пользователя остаётся файл из
   первоначального дистрибутива, а ютуб ломает совместимость каждые пару
   месяцев: старый yt-dlp отвечает 403 и стадия молча даёт ноль роликов.

2. Свежий yt-dlp требует JavaScript-рантайм. Без него он пишет:
   «No supported JavaScript runtime could be found … YouTube extraction without
   a JS runtime has been deprecated, and some formats may be missing» — часть
   форматов пропадает, ссылки на поток не проходят проверку подписи, и это ещё
   один источник 403. Проверено 29.08: на машине разработчика стоял Node, и
   потому всё работало; у пользователей рантайма нет вовсе.

Что ставим и почему deno, а не Node
-----------------------------------
yt-dlp по умолчанию ищет ТОЛЬКО deno: `JS Challenge Providers: bun
(unavailable), deno (unavailable), node (unavailable)`. Установленный Node он
берёт лишь при явном `--js-runtimes node`. Поэтому:

  • есть deno (системный или наш) → ничего не качаем, yt-dlp найдёт его сам;
  • есть Node → качать не нужно, добавляем флаг `--js-runtimes node:путь`;
  • нет ничего → качаем deno, один файл, кладём в `agent/tools/`.

Так пользователю не нужно ставить Node руками, а системный Node не пропадает
зря.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Callable, Optional

import urllib.request

_YTDLP_RELEASE = "https://github.com/yt-dlp/yt-dlp/releases/latest/download/"
DENO_RELEASE = "https://github.com/denoland/deno/releases/latest/download/"

ROOT = Path(__file__).resolve().parents[2]      # папка софта
TOOLS_DIR = Path(__file__).resolve().parent      # agent/tools
_UA = {"User-Agent": "varagent-youtube-setup/1.0"}
_NO_WINDOW = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}


def ytdlp_name() -> str:
    """Имя файла yt-dlp для этой системы.

    До 29.08 здесь было зашито `yt-dlp.exe` на всех платформах: на macOS
    кнопка скачивала ВИНДОВЫЙ бинарник и клала его в корень софта. Хуже, что
    `youtube_stage._yt_dlp_path()` предпочитает файл рядом с софтом системному
    из PATH — то есть кнопка ломала рабочую установку через brew.
    """
    if os.name == "nt":
        return "yt-dlp.exe"
    if sys.platform == "darwin":
        return "yt-dlp_macos"
    return "yt-dlp_linux"


def ytdlp_url() -> str:
    """Ассет того же релиза, что подходит этой системе."""
    return _YTDLP_RELEASE + ytdlp_name()


def ytdlp_path() -> Path:
    """Куда кладём и откуда берём yt-dlp — корень софта, как и раньше."""
    return ROOT / ytdlp_name()


def deno_asset() -> str:
    """Архив deno под систему и процессор.

    `platform.machine()` на Apple Silicon отвечает 'arm64', на Intel —
    'x86_64'; путать их нельзя, чужой бинарник просто не запустится.
    """
    import platform

    machine = (platform.machine() or "").lower()
    arm = machine in ("arm64", "aarch64")
    if os.name == "nt":
        return ("deno-aarch64-pc-windows-msvc.zip" if arm
                else "deno-x86_64-pc-windows-msvc.zip")
    if sys.platform == "darwin":
        return ("deno-aarch64-apple-darwin.zip" if arm
                else "deno-x86_64-apple-darwin.zip")
    return ("deno-aarch64-unknown-linux-gnu.zip" if arm
            else "deno-x86_64-unknown-linux-gnu.zip")


def bundled_deno() -> Path:
    return TOOLS_DIR / ("deno.exe" if os.name == "nt" else "deno")


def _failure_hint(exc: Exception) -> str:
    """Понятная приписка к ошибке скачивания вместо голого traceback."""
    text = f"{type(exc).__name__}: {exc}"
    if "CERTIFICATE_VERIFY_FAILED" in text or "SSL" in text.upper():
        if sys.platform == "darwin":
            return ("  Похоже на известную беду macOS с сертификатами: "
                    "запустите fix_ssl_mac.command в папке софта и повторите.")
        return "  Не проходит проверка сертификата — мешает антивирус или прокси."
    if "403" in text or "rate limit" in text.lower():
        return "  GitHub временно ограничил запросы с вашего адреса — повторите позже."
    if "Errno 13" in text or "Permission" in text:
        return "  Нет прав на запись в папку софта — закройте VarAgent и повторите."
    return ""


def _make_executable(path: Path) -> None:
    """Бит исполнения — на macOS и Linux без него файл не запустить."""
    if os.name == "nt":
        return
    try:
        path.chmod(path.stat().st_mode | 0o111)
    except OSError:                                            # noqa: BLE001
        pass


def _version_of(executable: str | Path) -> str:
    try:
        done = subprocess.run([str(executable), "--version"], capture_output=True,
                              text=True, timeout=30, **_NO_WINDOW)
        return (done.stdout or "").strip().splitlines()[0].strip()
    except Exception:                                          # noqa: BLE001
        return ""


def find_js_runtime() -> tuple[str, str]:
    """(вид, путь) первого доступного рантайма или ('', '').

    Порядок: наш deno → системный deno → системный Node. Наш первый, потому что
    он заведомо совместим и не зависит от того, что пользователь поставил.
    """
    local = bundled_deno()
    if local.is_file():
        return "deno", str(local)
    for kind in ("deno", "node"):
        found = shutil.which(kind)
        if found:
            return kind, found
    return "", ""


def js_runtime_args() -> list[str]:
    """Аргументы yt-dlp для JS-рантайма. Пусто — если добавлять нечего.

    Для deno флаг не нужен (yt-dlp включает его по умолчанию), но путь всё же
    передаём, когда deno наш: иначе он не в PATH и не будет найден.
    """
    kind, path = find_js_runtime()
    if not kind:
        return []
    if kind == "deno" and path == str(bundled_deno()):
        return ["--js-runtimes", f"deno:{path}"]
    if kind == "deno":
        return []                                  # системный deno найдётся сам
    return ["--js-runtimes", f"node:{path}"]       # Node только явным флагом


def _yt_transcriber():
    """Модуль с разбором браузеров лежит в agent/modules — берём его оттуда."""
    import importlib

    agent_dir = Path(__file__).resolve().parents[1]
    if str(agent_dir) not in sys.path:
        sys.path.insert(0, str(agent_dir))
    return importlib.import_module("modules.yt_transcriber")


def firefox_state() -> dict:
    """Стоит ли Firefox и виден ли в нём вход в аккаунт Google.

    Куки берутся из браузера, и без входа в аккаунт они не спасают от
    «подтвердите, что вы не робот». Поэтому интерфейсу мало знать «Firefox
    установлен» — нужно ещё, вошёл ли человек в аккаунт. Имена куков читаются
    из базы браузера, значения не расшифровываются вовсе.
    """
    state = {"installed": False, "signed_in": None, "profile": ""}
    try:
        module = _yt_transcriber()
        for name, path in module._browser_candidates():
            if name != "firefox":
                continue
            state["profile"] = path
            state["installed"] = os.path.isdir(path)
            if state["installed"]:
                state["signed_in"] = module._has_youtube_login(name, path)
            break
    except Exception:                                    # noqa: BLE001
        # Запасной путь: хотя бы наличие папки профиля, без разбора куков.
        for candidate in (
            os.path.expandvars(r"%APPDATA%\Mozilla\Firefox\Profiles"),
            str(Path.home() / "Library/Application Support/Firefox/Profiles"),
            str(Path.home() / ".mozilla/firefox"),
        ):
            if os.path.isdir(candidate):
                state["installed"] = True
                state["profile"] = candidate
                break
    return state


_STATUS_CACHE: dict = {}


def status(refresh: bool = False) -> dict:
    """Что сейчас установлено — для интерфейса и логов.

    Ответ кэшируется: каждый вызов запускает `yt-dlp --version` и
    `node/deno --version`, а спрашивают состояние сразу несколько мест
    интерфейса (карточка в настройках и блок футажей на вкладке запуска).
    `refresh=True` — пересчитать; так делает `install()` и кнопка «Проверить».
    """
    if _STATUS_CACHE and not refresh:
        return dict(_STATUS_CACHE)
    ytdlp = ytdlp_path()
    kind, path = find_js_runtime()
    firefox = firefox_state()
    fresh = {
        "ytdlp_path": str(ytdlp),
        "ytdlp_exists": ytdlp.is_file(),
        "ytdlp_version": _version_of(ytdlp) if ytdlp.is_file() else "",
        "runtime_kind": kind,
        "runtime_path": path,
        "runtime_version": _version_of(path) if path else "",
        "firefox_installed": firefox["installed"],
        "firefox_signed_in": firefox["signed_in"],
    }
    _STATUS_CACHE.clear()
    _STATUS_CACHE.update(fresh)
    return dict(fresh)


def is_ready(info: Optional[dict] = None) -> bool:
    """Модуль готов к работе: есть и yt-dlp, и JavaScript-рантайм.

    Единый критерий на весь софт — чтобы индикаторы в разных местах не
    расходились в том, что считать готовностью.
    """
    info = status() if info is None else info
    return bool(info.get("ytdlp_exists")) and bool(info.get("runtime_kind"))


def _download(url: str, target: Path, progress: Callable[[str], None],
              label: str) -> None:
    """Скачать во временный файл и заменить одним движением.

    Пишем рядом и переименовываем: оборванная закачка не должна оставить
    покалеченный yt-dlp вместо рабочего.
    """
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(target.suffix + ".part")
    request = urllib.request.Request(url, headers=_UA)
    with urllib.request.urlopen(request, timeout=120) as response:
        total = int(response.headers.get("Content-Length") or 0)
        done = 0
        step = max(1, total // 10) if total else 0
        next_mark = step
        with tmp.open("wb") as handle:
            while True:
                chunk = response.read(512 * 1024)
                if not chunk:
                    break
                handle.write(chunk)
                done += len(chunk)
                if step and done >= next_mark:
                    progress(f"   {label}: {done / 1024 / 1024:.0f} из "
                             f"{total / 1024 / 1024:.0f} МБ")
                    next_mark += step
    if target.exists():
        target.unlink()
    tmp.replace(target)


def install(progress: Optional[Callable[[str], None]] = None) -> dict:
    """Поставить свежий yt-dlp и, если нужно, JS-рантайм.

    Возвращает тот же словарь, что `status()`, — уже после установки.
    """
    say = progress or (lambda _message: None)
    say(f"YouTube-модуль: скачиваю свежий yt-dlp ({ytdlp_name()})…")
    try:
        _download(ytdlp_url(), ytdlp_path(), say, "yt-dlp")
        _make_executable(ytdlp_path())
        say(f"   yt-dlp обновлён: {_version_of(ytdlp_path()) or 'версия не определилась'}")
    except Exception as exc:                                   # noqa: BLE001
        say(f"   yt-dlp скачать не вышло: {type(exc).__name__}: {exc}")
        if _failure_hint(exc):
            say(_failure_hint(exc))

    kind, path = find_js_runtime()
    if kind:
        say(f"   JavaScript-рантайм уже есть: {kind} ({_version_of(path) or path})")
    else:
        wanted = deno_asset()
        say(f"YouTube-модуль: рантайма нет, скачиваю deno ({wanted}, ~40 МБ)…")
        try:
            # Прямая ссылка на ассет последнего релиза, без GitHub API: у API
            # лимит 60 запросов в час НА IP без токена, и упереться в него
            # легко — тогда установка падала бы с 403 на ровном месте
            # (поймано при проверке 29.08). Ссылка проверена для всех шести
            # ассетов: Windows/macOS/Linux × x86_64/aarch64.
            archive = TOOLS_DIR / wanted
            _download(DENO_RELEASE + wanted, archive, say, "deno")
            # В архиве под Windows лежит deno.exe, под macOS и Linux — просто
            # deno: искать только по «.exe» значило не найти ничего.
            inner = bundled_deno().name.lower()
            with zipfile.ZipFile(archive) as zf:
                names = [n for n in zf.namelist()
                         if n.lower().rsplit("/", 1)[-1] == inner]
                if not names:
                    raise RuntimeError(f"в архиве deno нет {inner}")
                with zf.open(names[0]) as src, bundled_deno().open("wb") as dst:
                    shutil.copyfileobj(src, dst)
            archive.unlink(missing_ok=True)
            _make_executable(bundled_deno())
            say(f"   deno установлен: {_version_of(bundled_deno()) or bundled_deno()}")
        except Exception as exc:                               # noqa: BLE001
            say(f"   deno поставить не вышло: {type(exc).__name__}: {exc}")
            if _failure_hint(exc):
                say(_failure_hint(exc))

    final = status(refresh=True)          # после установки кэш заведомо устарел
    if is_ready(final):
        say("YouTube-модуль готов: yt-dlp %s + %s" % (
            final["ytdlp_version"] or "?", final["runtime_kind"]))
    else:
        say("YouTube-модуль установлен НЕ полностью — смотри сообщения выше")
    return final


if __name__ == "__main__":
    install(progress=print)
