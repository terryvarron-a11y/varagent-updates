#!/bin/bash
# PROCESS_1080P.COMMAND - Video concat with 1080p re-encoding (macOS - double click)
# Run: double-click this file in Finder

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Auto-set execute permissions
chmod +x *.command *.sh 2>/dev/null

# Open Terminal.app for interactive mode
if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e "tell app \"Terminal\" to do script \"cd '$SCRIPT_DIR' && exec '$0'\""
    exit 0
fi

clear

echo ""
echo "================================================================================"
echo "CONCAT 1080p (with re-encoding)"
echo "================================================================================"
echo ""

# Check montage_plan.json
if [ ! -f "montage_plan.json" ]; then
    echo "[ERROR] montage_plan.json not found!"
    echo "Press Enter to exit..."
    read
    exit 1
fi

# Find audio file
AUDIO_FILE=""
for EXT in wav mp3 flac m4a aac; do
    for F in *.$EXT; do
        [ -f "$F" ] && AUDIO_FILE="$F" && break 2
    done
done

if [ -z "$AUDIO_FILE" ]; then
    echo "[ERROR] Audio file not found!"
    echo "   Put .wav, .mp3, .flac, .m4a or .aac in the project folder"
    echo "Press Enter to exit..."
    read
    exit 1
fi
echo "   Audio found: $AUDIO_FILE"

# ============================================================================
# STEP 1: RENAME VIDEO FRAGMENTS
# ============================================================================

echo ""
echo "[1/4] Renaming video fragments..."
echo ""

if [ -f "rename_videos.py" ]; then
    python3 rename_videos.py --dir vid_img
    if [ $? -ne 0 ]; then
        echo "[ERROR] Rename failed!"
        echo "Press Enter to exit..."
        read
        exit 1
    fi
else
    echo "   [WARN] rename_videos.py not found, skipping..."
fi

# ============================================================================
# STEP 2: CHECK FRAGMENTS
# ============================================================================

echo ""
echo "[2/4] Checking fragments..."
echo ""

if [ -f "check_fragments.command" ]; then
    bash check_fragments.command
    if [ $? -ne 0 ]; then
        echo ""
        echo "================================================================================"
        echo "PROMPTS FOR MISSING FRAGMENTS"
        echo "================================================================================"
        echo ""
        echo "  Copy these prompts to Veo3 to generate missing fragments"
        echo ""

        if [ -f "missing_fragments.txt" ]; then
            MISSING=$(cat missing_fragments.txt)
            echo "   Missing fragments: $MISSING"
            echo ""
            if [ -f "extract_prompt.py" ]; then
                for ID in $MISSING; do
                    echo "================================================================================"
                    echo "FRAGMENT #$ID (MISSING)"
                    echo "================================================================================"
                    echo ""
                    python3 extract_prompt.py "$ID"
                    echo ""
                done
            else
                echo "[WARN] extract_prompt.py not found, open *_prompts_*.txt manually"
            fi
        fi

        echo ""
        echo "NEXT STEPS:"
        echo "   1. Copy prompts above"
        echo "   2. Generate missing fragments in Veo3"
        echo "   3. Download files to this folder"
        echo "   4. Run process_1080p.command again"
        echo ""
        echo "Press Enter to exit..."
        read
        exit 1
    fi
else
    echo "   [WARN] check_fragments.command not found, skipping check..."
fi

# ============================================================================
# STEP 3: CONCAT 1080p
# ============================================================================

echo ""
echo "[3/4] Concat video (1080p, 10Mbps, re-encoding)..."
echo ""

SUB_ARG=""
SCRIPT_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
SUB_TEMPLATE=$(find "$SCRIPT_ROOT/agent/templates" -maxdepth 1 -name "*1080p*.ass" | sort | head -1)

if [ -n "$SUB_TEMPLATE" ]; then
    SUB_TEMPLATE_NAME=$(basename "$SUB_TEMPLATE")
    echo ""
    echo "[SUBTITLES] Template found: $SUB_TEMPLATE_NAME"
    printf "Burn subtitles? (1) Yes  (2) No: "
    read _APPLY_SUB
    if [ "$_APPLY_SUB" = "1" ]; then
        SUB_ARG="--subtitles \"$SUB_TEMPLATE\""
        echo "[INFO] Subtitles enabled: $SUB_TEMPLATE_NAME"
    fi
else
    echo "[INFO] No .ass template found in agent/templates/ - subtitles skipped"
fi

python3 video_concat.py montage_plan.json -o "{project_name}.mp4" -b 10M -r 1080 --veo-audio-inline $SUB_ARG
if [ $? -ne 0 ]; then
    echo "[ERROR] Concat failed!"
    echo "Press Enter to exit..."
    read
    exit 1
fi

# ============================================================================
# STEP 4: CLEANUP
# ============================================================================

echo ""
echo "[4/4] Renaming original audio..."
echo ""

if [ -f "result_original_audio.wav" ]; then
    mv "result_original_audio.wav" "VEO_AUDIO.wav"
    echo "   [OK] VEO_AUDIO.wav created"
fi

echo ""
echo "[4/4] Cleanup..."
echo ""

mkdir -p "FLOW_veo3_fragments"
for F in *.mp4; do
    [ -f "$F" ] || continue
    if [ "$F" != "{project_name}.mp4" ]; then
        mv "$F" "FLOW_veo3_fragments/"
    fi
done

if [ -d "temp_processed" ]; then
    rm -rf "temp_processed"
    echo "   [OK] temp_processed removed"
fi

echo ""
echo "================================================================================"
echo "[OK] DONE!"
echo "================================================================================"
echo ""
echo "   Result:    {project_name}.mp4"
echo "   Audio:     VEO_AUDIO.wav"
echo "   Fragments: FLOW_veo3_fragments/"
echo ""
echo "Press Enter to exit..."
read
