"""Canonical YouTube footage pipeline for montage scenes.

The stage has one runtime path:

planner queries -> licensed discovery -> temporal locator -> fixed parts ->
preview contact sheet -> Vision ranking by candidate ID -> range downloads ->
multi-part composition -> provenance and terminal fallback.

The director supplies the scene and its duration. The module owns YouTube
video IDs, source timestamps, part durations, downloads, and composition.
"""
from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import re
import shutil
import subprocess
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Optional

import requests
from PIL import Image, ImageDraw

import config
from modules.footage_cut import cut_footage, probe_video

VIDEO_EXTENSIONS = {".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v"}
TOKEN_RE = re.compile(r"[0-9A-Za-zА-Яа-яЁё]{3,}")
YOUTUBE_DATA_API_URL = "https://www.googleapis.com/youtube/v3"
CHAT_PROVIDERS = frozenset({
    "cliproxy",
    "deepseek",
    "openrouter",
    "meta_muse",
    "claude_api",
    "codex_reseller",
    "gpt_nexus",
})
RIGHTS_RESTRICTION_PATTERNS = (
    ("non-commercial", re.compile(r"\bnon[- ]?commercial\b", re.I)),
    ("no commercial use", re.compile(r"\bno commercial use\b", re.I)),
    ("not for commercial use", re.compile(r"\bnot for commercial use\b", re.I)),
    ("commercial use prohibited", re.compile(r"\bcommercial use (?:is )?prohibited\b", re.I)),
    ("permission required", re.compile(r"\bpermission (?:is )?required\b", re.I)),
    ("may not be used", re.compile(r"\bmay not be used\b", re.I)),
)


class YouTubeDiscoveryError(RuntimeError):
    """The selected discovery backend could not return a usable pool."""


def _tokens(text: str) -> set[str]:
    return {item.lower() for item in TOKEN_RE.findall(text or "")}


def _rights_text_flags(text: str) -> list[str]:
    return [
        label for label, pattern in RIGHTS_RESTRICTION_PATTERNS
        if pattern.search(text or "")
    ]


def _yt_dlp_path() -> str:
    configured = str(getattr(config, "YOUTUBE_DLP_PATH", "") or "").strip()
    if configured:
        return configured
    root = Path(__file__).resolve().parents[2]
    bundled = root / "yt-dlp.exe"
    if bundled.exists():
        return str(bundled)
    return shutil.which("yt-dlp") or "yt-dlp"


def _prepare_ytdlp_command(
    cmd: list[str],
    *,
    include_browser_cookies: bool = True,
) -> list[str]:
    inject: list[str] = []
    if "--js-runtimes" not in cmd and shutil.which("node"):
        inject.extend(["--js-runtimes", "node"])
    if include_browser_cookies and "--cookies-from-browser" not in cmd:
        browser = str(
            getattr(config, "YTDLP_COOKIES_BROWSER", "") or ""
        ).strip().lower()
        if not browser:
            try:
                from modules.yt_transcriber import _detect_browser

                browser = _detect_browser(_yt_dlp_path())
            except Exception:
                browser = ""
        if browser:
            inject.extend(["--cookies-from-browser", browser])
    return [cmd[0], *inject, *cmd[1:]] if inject else cmd


def _yt_env() -> dict[str, str]:
    env = dict(os.environ)
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    return env


def _load_plan(path: Path) -> dict[str, Any]:
    raw = json.loads(path.read_text(encoding="utf-8-sig"))
    return raw.get("montage_plan", raw) if isinstance(raw, dict) else {}


def _clip_text(project_dir: Path, clip: dict[str, Any]) -> str:
    for key in (
        "visual_intent",
        "youtube_query",
        "query",
        "voiceover",
        "text",
        "narration",
        "prompt",
    ):
        value = clip.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    transcript = project_dir / "transcription.json"
    try:
        data = json.loads(transcript.read_text(encoding="utf-8-sig"))
        fragments = data.get("transcription") or data.get("segments") or []
        start = float(clip.get("startTime", 0) or 0)
        end = float(clip.get("endTime", 0) or 0)
        return " ".join(
            str(item.get("text", ""))
            for item in fragments
            if float(item.get("start", 0) or 0) < end
            and float(item.get("end", 0) or 0) > start
        ).strip()
    except Exception:
        return ""


def _load_visual_context(project_dir: Path, clip: dict[str, Any]) -> dict[str, Any]:
    """Load the Auto Visual Story context packet for this scene when present."""
    inline = clip.get("context")
    if isinstance(inline, dict):
        return inline
    try:
        clip_id = int(clip.get("id"))
    except (TypeError, ValueError):
        return {}
    packet = (
        project_dir
        / "visual_story"
        / "context_packets"
        / f"{clip_id:03d}.json"
    )
    if not packet.exists():
        return {}
    try:
        data = json.loads(packet.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        return {}
    if not isinstance(data, dict):
        return {}
    return {
        key: data[key]
        for key in (
            "current_scene",
            "context_before",
            "context_after",
            "chapter_state",
            "entity_state",
            "visual_history",
            "continuity_constraints",
        )
        if data.get(key) not in (None, "", [], {})
    }


def _clip_duration(clip: dict[str, Any]) -> float:
    try:
        return max(
            0.1,
            float(clip.get("endTime", 0) or 0)
            - float(clip.get("startTime", 0) or 0),
        )
    except (TypeError, ValueError):
        return 1.0


def _run_json(
    cmd: list[str],
    timeout: int,
    stop_event: Optional[threading.Event],
    deadline_ts: Optional[float] = None,
) -> Any:
    if stop_event is not None and stop_event.is_set():
        return None
    flags = {}
    if os.name == "nt":
        flags["creationflags"] = subprocess.CREATE_NO_WINDOW
    for include_cookies in (True, False):
        try:
            proc = subprocess.Popen(
                _prepare_ytdlp_command(
                    cmd,
                    include_browser_cookies=include_cookies,
                ),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
                env=_yt_env(),
                **flags,
            )
            started = time.time()
            while True:
                try:
                    stdout, stderr = proc.communicate(timeout=0.2)
                    break
                except subprocess.TimeoutExpired:
                    pass
                if stop_event is not None and stop_event.is_set():
                    proc.kill()
                    proc.communicate()
                    return None
                if time.time() - started > timeout or (
                    deadline_ts is not None and time.time() >= deadline_ts
                ):
                    proc.kill()
                    proc.communicate()
                    return None
            if proc.returncode == 0:
                try:
                    return json.loads(stdout or "{}")
                except json.JSONDecodeError:
                    return None
            logging.warning(
                "yt-dlp JSON query failed (%s cookies): %s",
                "with" if include_cookies else "without",
                (stderr or "").strip()[-500:],
            )
        except Exception as exc:
            logging.warning(
                "yt-dlp JSON query exception (%s cookies): %s",
                "with" if include_cookies else "without",
                exc,
            )
    return None


def _discover_youtube(
    query: str,
    limit: int,
    stop_event: Optional[threading.Event],
    deadline_ts: Optional[float] = None,
) -> list[dict[str, Any]]:
    payload = _run_json(
        [
            _yt_dlp_path(),
            f"ytsearch{max(1, int(limit))}:{query}",
            "--flat-playlist",
            "--dump-single-json",
            "--skip-download",
            "--no-warnings",
        ],
        int(getattr(config, "YOUTUBE_SEARCH_TIMEOUT", 120) or 120),
        stop_event,
        deadline_ts,
    )
    entries = payload.get("entries", []) if isinstance(payload, dict) else []
    result = []
    seen: set[str] = set()
    for item in entries:
        video_id = str(item.get("id") or "").strip()
        if not video_id or video_id in seen:
            continue
        seen.add(video_id)
        result.append({
            "video_id": video_id,
            "title": str(item.get("title") or ""),
            "url": str(
                item.get("webpage_url")
                or f"https://www.youtube.com/watch?v={video_id}"
            ),
            "source": "youtube",
            "license": "unknown",
            "license_verified": False,
        })
    return result


def _iso8601_duration_seconds(value: str) -> int:
    match = re.fullmatch(
        r"P(?:\d+D)?T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?",
        str(value or "").strip(),
    )
    if not match:
        return 0
    hours, minutes, seconds = (int(part or 0) for part in match.groups())
    return hours * 3600 + minutes * 60 + seconds


def _discover_youtube_data_api(
    query: str,
    limit: int,
    stop_event: Optional[threading.Event],
    deadline_ts: Optional[float] = None,
) -> list[dict[str, Any]]:
    key = str(getattr(config, "YOUTUBE_DATA_API_KEY", "") or "").strip()
    if not key:
        raise YouTubeDiscoveryError("YouTube Data API key is not configured")
    if stop_event is not None and stop_event.is_set():
        return []
    timeout = min(
        int(getattr(config, "YOUTUBE_SEARCH_TIMEOUT", 120) or 120),
        max(1, int(deadline_ts - time.time())) if deadline_ts else 120,
    )
    policy = str(
        getattr(config, "YOUTUBE_LICENSE_POLICY", "creative_common")
        or "creative_common"
    ).lower()
    try:
        search = requests.get(
            f"{YOUTUBE_DATA_API_URL}/search",
            params={
                "key": key,
                "part": "snippet",
                "q": query,
                "type": "video",
                "videoEmbeddable": "true",
                "videoLicense": (
                    "creativeCommon" if policy == "creative_common" else "any"
                ),
                "maxResults": 50,
            },
            timeout=timeout,
        )
        search.raise_for_status()
        items = list((search.json() or {}).get("items") or [])
        video_ids = [
            str((item.get("id") or {}).get("videoId") or "").strip()
            for item in items
        ]
        video_ids = list(dict.fromkeys(item for item in video_ids if item))
        if not video_ids:
            return []
        details = requests.get(
            f"{YOUTUBE_DATA_API_URL}/videos",
            params={
                "key": key,
                "part": "snippet,contentDetails,status,statistics",
                "id": ",".join(video_ids[:50]),
                "maxResults": 50,
            },
            timeout=timeout,
        )
        details.raise_for_status()
    except requests.RequestException as exc:
        raise YouTubeDiscoveryError(
            f"YouTube Data API request failed: {exc}"
        ) from exc

    rights_policy = str(
        getattr(config, "YOUTUBE_RIGHTS_TEXT_POLICY", "exclude")
        or "exclude"
    ).lower()
    result = []
    for item in (details.json() or {}).get("items") or []:
        status = item.get("status") or {}
        license_name = str(status.get("license") or "").strip()
        if policy == "creative_common" and license_name != "creativeCommon":
            continue
        if status.get("embeddable") is False:
            continue
        snippet = item.get("snippet") or {}
        content = item.get("contentDetails") or {}
        stats = item.get("statistics") or {}
        description = str(snippet.get("description") or "")
        rights_flags = _rights_text_flags(description)
        if rights_policy == "exclude" and rights_flags:
            continue
        video_id = str(item.get("id") or "").strip()
        if not video_id:
            continue
        result.append({
            "video_id": video_id,
            "title": str(snippet.get("title") or ""),
            "description": description,
            "channel_title": str(snippet.get("channelTitle") or ""),
            "published_at": str(snippet.get("publishedAt") or ""),
            "duration_sec": _iso8601_duration_seconds(
                content.get("duration") or ""
            ),
            "view_count": int(stats.get("viewCount") or 0),
            "license": license_name or "unknown",
            "license_verified": True,
            "license_metadata_verified": True,
            "rights_text_flags": rights_flags,
            "url": f"https://www.youtube.com/watch?v={video_id}",
            "source": "youtube",
        })
        if len(result) >= max(1, int(limit)):
            break
    return result


def _discover_candidates(
    query: str,
    limit: int,
    stop_event: Optional[threading.Event],
    deadline_ts: Optional[float] = None,
) -> list[dict[str, Any]]:
    backend = str(
        getattr(config, "YOUTUBE_SEARCH_BACKEND", "auto") or "auto"
    ).lower()
    has_api_key = bool(str(getattr(config, "YOUTUBE_DATA_API_KEY", "") or "").strip())
    if backend == "data_api" or (backend == "auto" and has_api_key):
        return _discover_youtube_data_api(query, limit, stop_event, deadline_ts)
    if (
        str(getattr(config, "YOUTUBE_LICENSE_POLICY", "creative_common") or "")
        .lower()
        == "creative_common"
    ):
        raise YouTubeDiscoveryError(
            "Creative Commons policy requires YouTube Data API discovery"
        )
    return _discover_youtube(query, limit, stop_event, deadline_ts)


def _clip_search_queries(clip: dict[str, Any], fallback_query: str) -> list[str]:
    values = (
        clip.get("search_queries")
        or clip.get("youtube_queries")
        or clip.get("queries")
        or []
    )
    if isinstance(values, str):
        values = [values]
    queries = []
    for value in values:
        text = str(value or "").strip()
        if text and text not in queries:
            queries.append(text)
    fallback = str(fallback_query or "").strip()
    if fallback and fallback not in queries:
        queries.append(fallback)
    return queries or ["documentary footage"]


def _query_provider_model() -> tuple[str, str]:
    backend = str(
        getattr(config, "DIRECTOR_BACKEND", "") or ""
    ).strip().lower()
    provider = str(
        getattr(config, "GPT_PROVIDER", "") if backend == "gpt" else backend
    ).strip().lower()
    if provider not in CHAT_PROVIDERS:
        provider = str(
            getattr(config, "GPT_PROVIDER", "") or ""
        ).strip().lower()
    if provider not in CHAT_PROVIDERS:
        return "", ""
    model_names = {
        "cliproxy": "CLIPROXY_MODEL",
        "deepseek": "DEEPSEEK_MODEL",
        "openrouter": "OPENROUTER_MODEL",
        "meta_muse": "META_MUSE_MODEL",
        "claude_api": "CLAUDE_API_MODEL",
        "codex_reseller": "CODEX_RESELLER_MODEL",
        "gpt_nexus": "GPT_NEXUS_MODEL",
    }
    model = str(
        getattr(config, model_names[provider], "") or ""
    ).strip()
    return provider, model


def _normalize_search_queries(values: Any) -> list[str]:
    if isinstance(values, str):
        values = [values]
    result = []
    for value in values or []:
        query = re.sub(r"\s+", " ", str(value or "")).strip(" \t\r\n\"'")
        if not query:
            continue
        words = query.split()
        query = " ".join(words[:14])[:120].strip()
        if query and query.casefold() not in {
            item.casefold() for item in result
        }:
            result.append(query)
        if len(result) >= 4:
            break
    return result


def _fallback_search_queries(clip: dict[str, Any], scene_text: str) -> list[str]:
    explicit = _normalize_search_queries(
        clip.get("search_queries")
        or clip.get("youtube_queries")
        or clip.get("queries")
        or []
    )
    if explicit:
        return explicit
    compact = re.sub(r"[^\w\s-]+", " ", scene_text or "", flags=re.UNICODE)
    compact = re.sub(r"\s+", " ", compact).strip()
    words = compact.split()
    if not words:
        return ["documentary footage"]
    queries = [" ".join(words[:10])]
    if len(words) > 10:
        queries.append(" ".join(words[-10:]))
    return _normalize_search_queries(queries) or ["documentary footage"]


def _plan_search_queries(
    project: Path,
    clip: dict[str, Any],
    artifact_dir: Path,
    *,
    context: Optional[dict[str, Any]] = None,
) -> list[str]:
    scene_text = _clip_text(project, clip)
    context = context or _load_visual_context(project, clip)
    seed_queries = _normalize_search_queries(
        clip.get("search_queries")
        or clip.get("youtube_queries")
        or clip.get("queries")
        or []
    )
    provider, model = _query_provider_model()
    artifact: dict[str, Any] = {
        "method": "llm_query_planner",
        "provider": provider,
        "model": model,
        "scene_text": scene_text,
        "seed_queries": seed_queries,
        "context": context,
        "queries": [],
    }
    queries: list[str] = []
    if provider and model and scene_text:
        task = (
            "Create 3 concise YouTube search queries for real footage that "
            "visually illustrates the scene below. Queries must be search "
            "phrases, not narration, and should name the concrete subject, "
            "place, era, event, action, or filming context. Prefer English "
            "phrases because YouTube metadata is often English. Do not invent "
            "URLs, video IDs, timestamps, durations, or licensing claims. "
            "Use the supplied story context to disambiguate who, where, when, "
            "and which event the scene refers to. Preserve concrete names and "
            "locations from the context or seed queries. Do not replace a "
            "specific subject with a generic phrase such as 'a singer'. "
            "Return strict JSON only: {\"queries\":[\"...\",\"...\",\"...\"]}.\n\n"
            f"SCENE:\n{scene_text[:2000]}\n\n"
            f"SEED QUERIES:\n{json.dumps(seed_queries, ensure_ascii=False)}\n\n"
            f"STORY CONTEXT:\n{json.dumps(context, ensure_ascii=False)[:12000]}"
        )
        try:
            from modules.chat_client import chat_completion

            raw = chat_completion(
                provider,
                model,
                [{"role": "user", "content": task}],
                max_tokens=300,
                json_mode=True,
                timeout=180,
            )
            parsed = _parse_json_object(raw)
            queries = _normalize_search_queries(parsed.get("queries") or [])
            artifact["raw"] = raw
        except Exception as exc:
            artifact["error"] = str(exc)
    if not queries:
        queries = _fallback_search_queries(clip, scene_text)
        artifact["method"] = "deterministic_query_fallback"
    # Director/Auto Visual Story queries are concrete hints and must survive
    # the per-stage planner even when the short scene text is ambiguous.
    queries = _normalize_search_queries([*seed_queries, *queries])
    artifact["queries"] = queries
    artifact_dir.mkdir(parents=True, exist_ok=True)
    (artifact_dir / "query_planner.json").write_text(
        json.dumps(artifact, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return queries


def _discover_candidates_multi(
    queries: list[str],
    limit: int,
    stop_event: Optional[threading.Event],
    deadline_ts: Optional[float] = None,
) -> list[dict[str, Any]]:
    result = []
    seen: set[str] = set()
    for query in queries:
        if stop_event is not None and stop_event.is_set():
            break
        if deadline_ts is not None and time.time() >= deadline_ts:
            break
        for item in _discover_candidates(query, limit, stop_event, deadline_ts):
            video_id = str(item.get("video_id") or "").strip()
            if not video_id or video_id in seen:
                continue
            seen.add(video_id)
            item = dict(item)
            item["discovery_queries"] = [query]
            result.append(item)
            if len(result) >= max(1, int(limit)):
                return result
    return result


def _timestamp_seconds(value: str) -> Optional[float]:
    parts = str(value or "").strip().split(":")
    if len(parts) not in (2, 3) or not all(part.isdigit() for part in parts):
        return None
    values = [int(part) for part in parts]
    if len(values) == 2:
        return float(values[0] * 60 + values[1])
    return float(values[0] * 3600 + values[1] * 60 + values[2])


def _description_timestamps(description: str) -> list[float]:
    values = []
    for match in re.finditer(
        r"(?<!\d)(\d{1,2}:\d{2}(?::\d{2})?)(?!\d)",
        description or "",
    ):
        timestamp = _timestamp_seconds(match.group(1))
        if timestamp is not None and timestamp not in values:
            values.append(timestamp)
    return values


def _load_video_locator_detail(
    candidate: dict[str, Any],
    stop_event: Optional[threading.Event],
    deadline_ts: Optional[float] = None,
) -> dict[str, Any]:
    payload = _run_json(
        [
            _yt_dlp_path(),
            str(candidate.get("url") or ""),
            "--dump-single-json",
            "--skip-download",
            "--no-warnings",
        ],
        int(getattr(config, "YOUTUBE_SEARCH_TIMEOUT", 120) or 120),
        stop_event,
        deadline_ts,
    )
    if not isinstance(payload, dict):
        return dict(candidate)
    merged = dict(candidate)
    for key in ("duration", "description", "chapters"):
        if payload.get(key) is not None:
            merged[key] = payload[key]
    if payload.get("duration") is not None:
        merged["duration_sec"] = float(payload.get("duration") or 0)
    return merged


def _locate_candidate_windows(
    candidate: dict[str, Any],
    *,
    detail: Optional[dict[str, Any]] = None,
    max_windows: int = 6,
    scan_window_sec: float = 10.0,
) -> list[dict[str, Any]]:
    detail = detail or candidate
    video_id = str(candidate.get("video_id") or "").strip()
    duration = max(
        0.0,
        float(
            detail.get("duration_sec")
            or detail.get("duration")
            or candidate.get("duration_sec")
            or 0
        ),
    )
    windows = []
    chapters = detail.get("chapters") or []
    for index, chapter in enumerate(chapters):
        try:
            start = max(
                0.0,
                float(chapter.get("start_time", chapter.get("start", 0))),
            )
            next_chapter = (
                chapters[index + 1] if index + 1 < len(chapters) else None
            )
            end = float(
                chapter.get(
                    "end_time",
                    chapter.get(
                        "end",
                        next_chapter.get("start_time")
                        if next_chapter
                        else duration,
                    ),
                )
            )
        except (AttributeError, TypeError, ValueError):
            continue
        if end > start:
            windows.append({
                "video_id": video_id,
                "window_id": f"{video_id}:chapter:{index}",
                "start": start,
                "end": min(end, duration) if duration else end,
                "origin": "chapter",
                "pre_score": 0.85,
            })
    for index, timestamp in enumerate(
        _description_timestamps(
            str(detail.get("description") or candidate.get("description") or "")
        )
    ):
        if duration and timestamp >= duration:
            continue
        end = min(
            duration or timestamp + scan_window_sec,
            timestamp + max(3.0, scan_window_sec),
        )
        if end > timestamp:
            windows.append({
                "video_id": video_id,
                "window_id": f"{video_id}:description:{index}",
                "start": timestamp,
                "end": end,
                "origin": "description_timestamp",
                "pre_score": 0.75,
            })
    if not windows and duration > 0:
        step = max(scan_window_sec, duration / max(1, max_windows))
        for index in range(max_windows):
            start = min(
                max(0.0, duration - scan_window_sec),
                index * step,
            )
            end = min(duration, start + scan_window_sec)
            if end > start:
                windows.append({
                    "video_id": video_id,
                    "window_id": f"{video_id}:sparse:{index}",
                    "start": round(start, 3),
                    "end": round(end, 3),
                    "origin": "sparse_scan",
                    "pre_score": 0.25,
                })
    return windows[:max(1, int(max_windows))]


def _fixed_candidate_parts(
    windows: list[dict[str, Any]],
    *,
    max_fragment_sec: float,
    limit: int = 6,
    requested_duration_sec: Optional[float] = None,
) -> list[dict[str, Any]]:
    maximum = max(0.5, float(max_fragment_sec or 3.0))
    requested = (
        max(0.0, float(requested_duration_sec))
        if requested_duration_sec is not None
        else maximum
    )
    if requested <= 0 or requested > maximum + 1e-6:
        return []
    by_video: dict[str, list[dict[str, Any]]] = {}
    seen: set[tuple[str, float, float]] = set()
    for window in windows:
        video_id = str(window.get("video_id") or "").strip()
        if not video_id:
            continue
        try:
            start = max(0.0, float(window.get("start", 0)))
            end = max(start, float(window.get("end", start)))
        except (TypeError, ValueError):
            continue
        cursor = start
        while cursor + requested <= end + 1e-6:
            part_start = round(cursor, 3)
            part_end = round(cursor + requested, 3)
            key = (video_id, part_start, part_end)
            if key not in seen:
                seen.add(key)
                by_video.setdefault(video_id, []).append({
                    "video_id": video_id,
                    "start": part_start,
                    "end": part_end,
                    "duration": round(part_end - part_start, 3),
                    "origin": str(window.get("origin") or "unknown"),
                    "window_id": str(window.get("window_id") or ""),
                    "pre_score": float(window.get("pre_score", 0) or 0),
                })
            cursor += maximum
    result = []
    limit = max(1, int(limit))
    while len(result) < limit:
        added = False
        for bucket in by_video.values():
            if not bucket:
                continue
            part = bucket.pop(0)
            part["candidate_id"] = f"C{len(result) + 1}"
            result.append(part)
            added = True
            if len(result) >= limit:
                break
        if not added:
            break
    return result


def _parse_json_object(raw: str) -> dict[str, Any]:
    text = str(raw or "").strip()
    fenced = re.search(r"```(?:json)?\s*(.*?)```", text, flags=re.I | re.S)
    if fenced:
        text = fenced.group(1).strip()
    try:
        value = json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find("{"), text.rfind("}")
        if start < 0 or end <= start:
            return {}
        try:
            value = json.loads(text[start:end + 1])
        except json.JSONDecodeError:
            return {}
    return value if isinstance(value, dict) else {}


def _validate_candidate_ranking(
    raw: dict[str, Any],
    candidates: list[dict[str, Any]],
) -> list[str]:
    expected = [str(item.get("candidate_id") or "") for item in candidates]
    ranked = [
        str(value).strip()
        for value in raw.get("ranked_candidate_ids") or []
    ]
    if (
        len(ranked) != len(expected)
        or len(set(ranked)) != len(ranked)
        or set(ranked) != set(expected)
    ):
        raise ValueError(
            "Vision returned an incomplete or unknown candidate ID list"
        )
    return ranked


def _vision_candidate_contract(
    clip: dict[str, Any],
    candidates: list[dict[str, Any]],
    *,
    scene_text: str = "",
    search_queries: Optional[list[str]] = None,
    context: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    return {
        "visual_intent": str(
            clip.get("visual_intent")
            or clip.get("query")
            or clip.get("youtube_query")
            or scene_text
            or ""
        ).strip(),
        "search_queries": list(search_queries or []),
        "story_context": context or {},
        "must_have": list(clip.get("must_have") or []),
        "avoid": list(
            clip.get("avoid")
            or clip.get("negative_constraints")
            or []
        ),
        "candidates": [
            {
                "candidate_id": str(item["candidate_id"]),
                "duration": float(item["duration"]),
            }
            for item in candidates
        ],
        "response_schema": {
            "ranked_candidate_ids": ["C1", "C2"],
            "rejected_ids": [],
            "reasons": {"C1": "brief visual reason"},
        },
    }


def _extract_preview_frame(
    video_path: Path,
    timestamp: float,
    output_path: Path,
) -> Optional[Path]:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    flags = {}
    if os.name == "nt":
        flags["creationflags"] = subprocess.CREATE_NO_WINDOW
    try:
        result = subprocess.run(
            [
                shutil.which("ffmpeg") or "ffmpeg",
                "-hide_banner",
                "-loglevel",
                "error",
                "-ss",
                f"{max(0.0, float(timestamp)):.3f}",
                "-i",
                str(video_path),
                "-frames:v",
                "1",
                "-vf",
                "scale=480:-2",
                "-q:v",
                "5",
                "-y",
                str(output_path),
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            timeout=60,
            **flags,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if result.returncode != 0 or not output_path.exists():
        return None
    return output_path


def _build_candidate_contact_sheet(
    candidates: list[dict[str, Any]],
    preview_paths: dict[str, Path],
    output_path: Path,
) -> Optional[Path]:
    panels = []
    frame_dir = output_path.parent / "frames"
    for candidate in candidates:
        candidate_id = str(candidate.get("candidate_id") or "")
        video_path = preview_paths.get(candidate_id)
        if not candidate_id or not video_path or not video_path.exists():
            continue
        duration = max(0.1, float(candidate.get("duration", 0) or 0))
        images = []
        for label, timestamp in (
            ("start", 0.0),
            ("mid", duration / 2),
            ("end", max(0.0, duration - 0.05)),
        ):
            frame = _extract_preview_frame(
                video_path,
                timestamp,
                frame_dir / f"{candidate_id}_{label}.jpg",
            )
            if frame:
                try:
                    images.append(Image.open(frame).convert("RGB"))
                except (OSError, ValueError):
                    pass
        if not images:
            continue
        width = max(image.width for image in images)
        height = max(image.height for image in images)
        panel = Image.new(
            "RGB",
            (width * len(images), height + 32),
            "white",
        )
        ImageDraw.Draw(panel).text((8, 8), candidate_id, fill="black")
        for index, image in enumerate(images):
            panel.paste(image, (index * width, 32))
        panels.append(panel)
    if not panels:
        return None
    columns = 2
    rows = (len(panels) + columns - 1) // columns
    panel_width = max(panel.width for panel in panels)
    panel_height = max(panel.height for panel in panels)
    sheet = Image.new(
        "RGB",
        (panel_width * columns, panel_height * rows),
        "#d8d8d8",
    )
    for index, panel in enumerate(panels):
        sheet.paste(
            panel,
            ((index % columns) * panel_width, (index // columns) * panel_height),
        )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(output_path, format="JPEG", quality=82, optimize=True)
    return output_path


def _selector_provider_model() -> tuple[str, str]:
    provider = str(
        getattr(config, "YOUTUBE_SELECTOR_PROVIDER", "auto") or "auto"
    ).lower()
    if provider == "auto":
        backend = str(
            getattr(config, "DIRECTOR_BACKEND", "") or ""
        ).lower()
        provider = str(
            getattr(config, "GPT_PROVIDER", "")
            if backend == "gpt"
            else backend
        ).lower()
    if provider not in CHAT_PROVIDERS:
        return "", ""
    configured = str(
        getattr(config, "YOUTUBE_SELECTOR_MODEL", "") or ""
    ).strip()
    if configured:
        return provider, configured
    names = {
        "cliproxy": "CLIPROXY_MODEL",
        "deepseek": "DEEPSEEK_MODEL",
        "openrouter": "OPENROUTER_MODEL",
        "meta_muse": "META_MUSE_MODEL",
        "claude_api": "CLAUDE_API_MODEL",
        "codex_reseller": "CODEX_RESELLER_MODEL",
        "gpt_nexus": "GPT_NEXUS_MODEL",
    }
    return provider, str(getattr(config, names[provider], "") or "").strip()


def _vision_rank_candidate_parts(
    clip: dict[str, Any],
    candidates: list[dict[str, Any]],
    preview_paths: dict[str, Path],
    artifact_dir: Path,
    *,
    scene_text: str = "",
    search_queries: Optional[list[str]] = None,
    context: Optional[dict[str, Any]] = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    ids = [str(item.get("candidate_id") or "") for item in candidates]
    fallback = {
        "method": "pre_score_fallback",
        "ranked_candidate_ids": ids,
        "raw": "",
    }
    provider, model = _selector_provider_model()
    if not provider or not model:
        fallback["reason"] = "Vision provider/model is not configured"
        return sorted(
            candidates,
            key=lambda item: float(item.get("pre_score", 0) or 0),
            reverse=True,
        ), fallback
    sheet = _build_candidate_contact_sheet(
        candidates,
        preview_paths,
        artifact_dir / "contact_sheet.jpg",
    )
    if not sheet:
        fallback["reason"] = "Could not create contact sheet"
        return candidates, fallback
    contract = _vision_candidate_contract(
        clip,
        candidates,
        scene_text=scene_text,
        search_queries=search_queries,
        context=context,
    )
    task = (
        "Rank the fixed YouTube candidate parts shown in the labeled contact "
        "sheet for this scene. Judge only visible content. Return strict JSON. "
        "Rank every supplied candidate exactly once. Do not invent timestamps, "
        "video IDs, URLs, durations, or candidates. Candidate ranges are fixed.\n\n"
        + json.dumps(contract, ensure_ascii=False)
    )
    messages = [{
        "role": "user",
        "content": [
            {"type": "text", "text": task},
            {
                "type": "image_url",
                "image_url": {
                    "url": (
                        "data:image/jpeg;base64,"
                        + base64.b64encode(sheet.read_bytes()).decode("ascii")
                    ),
                },
            },
        ],
    }]
    artifact_dir.mkdir(parents=True, exist_ok=True)
    (artifact_dir / "vision_prompt.json").write_text(
        json.dumps(contract, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    try:
        from modules.chat_client import chat_completion

        raw = chat_completion(
            provider,
            model,
            messages,
            max_tokens=500,
            json_mode=True,
            timeout=240,
        )
        parsed = _parse_json_object(raw)
        ranked_ids = _validate_candidate_ranking(parsed, candidates)
        by_id = {str(item["candidate_id"]): item for item in candidates}
        (artifact_dir / "vision_response.txt").write_text(
            str(raw or ""),
            encoding="utf-8",
        )
        return [by_id[item] for item in ranked_ids], {
            "method": "vision_contact_sheet",
            "provider": provider,
            "model": model,
            "ranked_candidate_ids": ranked_ids,
            "rejected_ids": list(parsed.get("rejected_ids") or []),
            "reasons": parsed.get("reasons") or {},
            "contact_sheet": str(sheet),
            "raw": raw,
        }
    except Exception as exc:
        fallback["reason"] = str(exc)
        (artifact_dir / "vision_error.json").write_text(
            json.dumps({"error": str(exc)}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return candidates, fallback


def _download(
    candidate: dict[str, Any],
    target: Path,
    stop_event: Optional[threading.Event],
    deadline_ts: Optional[float] = None,
    *,
    start_sec: float,
    duration_sec: float,
) -> Optional[Path]:
    url = str(candidate.get("url") or "").strip()
    if not url:
        return None
    target.parent.mkdir(parents=True, exist_ok=True)
    end_sec = float(start_sec) + float(duration_sec)
    command = [
        _yt_dlp_path(),
        url,
        "--no-playlist",
        "--no-warnings",
        "-f",
        "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/b",
        "--merge-output-format",
        "mp4",
        "--download-sections",
        f"*{float(start_sec):.3f}-{end_sec:.3f}",
        "--force-keyframes-at-cuts",
        "-o",
        str(target.with_suffix(".%(ext)s")),
    ]
    flags = {}
    if os.name == "nt":
        flags["creationflags"] = subprocess.CREATE_NO_WINDOW
    for with_cookies in (True, False):
        try:
            proc = subprocess.Popen(
                _prepare_ytdlp_command(
                    command,
                    include_browser_cookies=with_cookies,
                ),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                env=_yt_env(),
                **flags,
            )
            started = time.time()
            while proc.poll() is None:
                if stop_event is not None and stop_event.is_set():
                    proc.kill()
                    proc.wait()
                    return None
                if time.time() - started > int(
                    getattr(config, "YOUTUBE_DOWNLOAD_TIMEOUT", 900) or 900
                ):
                    proc.kill()
                    proc.wait()
                    return None
                if deadline_ts is not None and time.time() >= deadline_ts:
                    proc.kill()
                    proc.wait()
                    return None
                time.sleep(0.25)
            if proc.returncode != 0:
                continue
            matches = [
                path for path in target.parent.glob(target.stem + ".*")
                if path.suffix.lower() in VIDEO_EXTENSIONS
                and path.stat().st_size > 1024
            ]
            if matches:
                return matches[0]
        except Exception as exc:
            logging.warning("YouTube download failed: %s", exc)
    return None


def _usage_path(project_dir: Path) -> Path:
    return project_dir / "youtube" / "source_usage.json"


def _load_usage(project_dir: Path) -> dict[str, Any]:
    try:
        value = json.loads(_usage_path(project_dir).read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _save_usage(project_dir: Path, usage: dict[str, Any]) -> None:
    path = _usage_path(project_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(usage, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


@contextmanager
def _usage_lock(project_dir: Path):
    try:
        from filelock import FileLock
    except ImportError:
        yield
        return
    with FileLock(str(_usage_path(project_dir)) + ".lock"):
        yield


def _reserve_locked(
    project_dir: Path,
    usage: dict[str, Any],
    video_id: str,
    start: float,
    end: float,
    clip_id: int,
) -> bool:
    gap = float(
        getattr(config, "YOUTUBE_SAME_VIDEO_MIN_SOURCE_GAP_SEC", 20.0)
        or 20.0
    )
    with _usage_lock(project_dir):
        fresh = _load_usage(project_dir)
        for old_start, old_end in fresh.get(video_id, {}).get("intervals", []):
            distance = max(
                float(old_start) - end,
                start - float(old_end),
                0.0,
            )
            if distance < gap:
                usage.clear()
                usage.update(fresh)
                return False
        item = fresh.setdefault(
            video_id,
            {"uses": 0, "intervals": [], "last_clip": None},
        )
        item["uses"] = int(item.get("uses", 0)) + 1
        item["last_clip"] = clip_id
        item.setdefault("intervals", []).append(
            [round(start, 3), round(end, 3)]
        )
        _save_usage(project_dir, fresh)
        usage.clear()
        usage.update(fresh)
        return True


def _release_reservations(
    project_dir: Path,
    usage: dict[str, Any],
    reservations: list[dict[str, Any]],
) -> None:
    if not reservations:
        return
    with _usage_lock(project_dir):
        fresh = _load_usage(project_dir)
        for reservation in reservations:
            video_id = str(reservation.get("video_id") or "")
            item = fresh.get(video_id)
            if not isinstance(item, dict):
                continue
            target = [
                round(float(reservation.get("start", 0)), 3),
                round(float(reservation.get("end", 0)), 3),
            ]
            intervals = list(item.get("intervals") or [])
            for index, interval in enumerate(intervals):
                if [
                    round(float(interval[0]), 3),
                    round(float(interval[1]), 3),
                ] == target:
                    intervals.pop(index)
                    item["uses"] = max(0, int(item.get("uses", 0)) - 1)
                    break
            item["intervals"] = intervals
            if not intervals:
                fresh.pop(video_id, None)
        _save_usage(project_dir, fresh)
        usage.clear()
        usage.update(fresh)


def _compose_parts(
    source_parts: list[tuple[Path, float]],
    output: Path,
    *,
    target_w: int,
    target_h: int,
    fps: int,
    stop_event: Optional[threading.Event],
) -> dict[str, Any]:
    if not source_parts:
        return {"ok": False, "error": "no selected YouTube parts"}
    work = output.parent / f".{output.stem}_youtube_parts"
    work.mkdir(parents=True, exist_ok=True)
    rendered = []
    try:
        for index, (source, duration) in enumerate(source_parts, start=1):
            target = work / f"{index:03d}.mp4"
            cut = cut_footage(
                source,
                target,
                duration,
                target_w=target_w,
                target_h=target_h,
                fps=fps,
                start_sec=0,
                mute=True,
                stop_event=stop_event,
            )
            if not cut.get("ok"):
                return cut
            rendered.append(target)
        list_path = work / "concat.txt"
        lines = []
        for path in rendered:
            lines.append(f"file '{path.as_posix().replace(chr(39), chr(39) + chr(92) + chr(39) + chr(39))}'\n")
        list_path.write_text("".join(lines), encoding="utf-8")
        flags = {}
        if os.name == "nt":
            flags["creationflags"] = subprocess.CREATE_NO_WINDOW
        result = subprocess.run(
            [
                shutil.which("ffmpeg") or "ffmpeg",
                "-y",
                "-hide_banner",
                "-loglevel",
                "error",
                "-f",
                "concat",
                "-safe",
                "0",
                "-i",
                str(list_path),
                "-c:v",
                "libx264",
                "-pix_fmt",
                "yuv420p",
                "-movflags",
                "+faststart",
                "-an",
                str(output),
            ],
            capture_output=True,
            timeout=int(getattr(config, "YOUTUBE_DOWNLOAD_TIMEOUT", 900) or 900),
            **flags,
        )
        if result.returncode != 0 or not output.exists():
            return {
                "ok": False,
                "error": (
                    result.stderr or b""
                ).decode("utf-8", "replace")[-500:] or "concat failed",
            }
        return {"ok": True, "file": str(output), "parts": len(rendered)}
    finally:
        shutil.rmtree(work, ignore_errors=True)


def _find_generated_image(project: Path, clip_id: int) -> Optional[Path]:
    generated = project / "generated"
    for suffix in (".jpg", ".jpeg", ".png", ".webp"):
        candidate = generated / f"{clip_id:03d}{suffix}"
        if candidate.is_file() and candidate.stat().st_size > 1024:
            return candidate
    return None


def _render_epf_tail(
    image_path: Path,
    output_path: Path,
    *,
    duration: float,
    target_w: int,
    target_h: int,
    fps: int,
) -> Path:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    frames = max(1, int(round(float(duration) * max(1, int(fps)))))
    zoom_step = 0.06 / max(1, frames)
    video_filter = (
        f"scale={target_w}:{target_h}:force_original_aspect_ratio=increase,"
        f"crop={target_w}:{target_h},"
        f"zoompan=z='min(zoom+{zoom_step:.8f},1.06)':"
        f"x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
        f"d={frames}:s={target_w}x{target_h}:fps={fps},"
        "format=yuv420p"
    )
    flags = {}
    if os.name == "nt":
        flags["creationflags"] = subprocess.CREATE_NO_WINDOW
    result = subprocess.run(
        [
            shutil.which("ffmpeg") or "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-loop",
            "1",
            "-i",
            str(image_path),
            "-vf",
            video_filter,
            "-t",
            f"{max(0.1, float(duration)):.3f}",
            "-an",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            "-movflags",
            "+faststart",
            str(output_path),
        ],
        capture_output=True,
        timeout=max(
            120,
            int(getattr(config, "YOUTUBE_DOWNLOAD_TIMEOUT", 900) or 900),
        ),
        **flags,
    )
    if result.returncode != 0 or not output_path.is_file():
        error = (result.stderr or b"").decode("utf-8", "replace")[-500:]
        raise RuntimeError(error or "EPF tail render failed")
    return output_path


def _run_epf_fallback(
    project: Path,
    clip: dict[str, Any],
    *,
    stop_event: Optional[threading.Event],
    deadline_ts: Optional[float],
    target_w: int,
    target_h: int,
) -> dict[str, Any]:
    from modules.real_photo import ClipSelection, RealPhotoProcessor

    selection = ClipSelection(
        clip_id=int(clip.get("id")),
        search_query=_clip_text(project, clip)[:500],
        search_query_local="",
        preferred_type="photo",
        preferred_sources=list(getattr(
            config,
            "REAL_PHOTO_SOURCES",
            ["wikimedia", "nasa", "loc", "archive"],
        )),
        reasoning="YouTube pipeline failed; route to EPF/Real Photo",
        confidence="medium",
        query_provider="youtube_fallback",
        query_path="fallback",
    )
    processor = RealPhotoProcessor(
        project_dir=project,
        target_ratio=1.0,
        min_ratio=1.0,
        max_ratio=1.0,
        sources=selection.preferred_sources,
        target_w=target_w,
        target_h=target_h,
        fps=getattr(config, "VIDEO_FPS", 60),
    )
    old_bridge = getattr(config, "REAL_PHOTO_EPF_BRIDGE", False)
    config.REAL_PHOTO_EPF_BRIDGE = True
    try:
        # The YouTube wait timer may already have expired. Once useful YouTube
        # parts are selected, finish only the missing tail with a fresh EPF
        # budget instead of cancelling the whole scene.
        fallback_timeout = max(
            30,
            int(getattr(config, "REAL_PHOTO_EPF_SEARCH_TIMEOUT", 180) or 180),
        )
        return processor.process_phase(
            [selection],
            stop_event=None,
            deadline_ts=time.time() + fallback_timeout,
        )
    finally:
        config.REAL_PHOTO_EPF_BRIDGE = old_bridge


def fallback_pending_youtube(
    project_dir: str | Path,
    *,
    target_w: int = 1920,
    target_h: int = 1080,
    fps: Optional[int] = None,
) -> dict[str, Any]:
    """Route every remaining ``youtube_pending`` clip through EPF/archive."""
    project = Path(project_dir).resolve()
    montage = project / "montage_plan.json"
    if not montage.exists():
        return {"selected": 0, "error": "montage_plan.json missing"}
    plan = _load_plan(montage)
    pending = [
        clip for clip in plan.get("clips", [])
        if clip.get("source") == "youtube_pending"
    ]
    if not pending:
        return {"selected": 0, "rendered": 0}

    from modules.clip_sources import apply_clip_source_delta
    from modules.real_photo import ClipSelection, RealPhotoProcessor

    clip_ids = [int(clip.get("id")) for clip in pending]
    apply_clip_source_delta(
        montage,
        {clip_id: {"source": "real_photo_pending"} for clip_id in clip_ids},
        log=lambda message: print(f"  [YouTube fallback] {message}"),
    )
    selections = [
        ClipSelection(
            clip_id=int(clip.get("id")),
            search_query=_clip_text(project, clip)[:500],
            search_query_local="",
            preferred_type="photo",
            preferred_sources=list(getattr(
                config,
                "REAL_PHOTO_SOURCES",
                ["wikimedia", "nasa", "loc", "archive"],
            )),
            reasoning="YouTube wait expired; route to EPF/Real Photo",
            confidence="medium",
            query_provider="youtube_wait_fallback",
            query_path="fallback",
        )
        for clip in pending
    ]
    processor = RealPhotoProcessor(
        project_dir=project,
        target_ratio=1.0,
        min_ratio=1.0,
        max_ratio=1.0,
        sources=selections[0].preferred_sources,
        target_w=target_w,
        target_h=target_h,
        fps=int(fps or getattr(config, "VIDEO_FPS", 60)),
    )
    timeout_per_clip = max(
        30,
        int(getattr(config, "REAL_PHOTO_EPF_SEARCH_TIMEOUT", 180) or 180),
    )
    old_bridge = getattr(config, "REAL_PHOTO_EPF_BRIDGE", False)
    config.REAL_PHOTO_EPF_BRIDGE = True
    try:
        result = processor.process_phase(
            selections,
            stop_event=None,
            deadline_ts=time.time() + timeout_per_clip * len(selections),
        )
        return {
            "selected": len(selections),
            "clip_ids": clip_ids,
            "result": result,
        }
    except Exception as exc:
        apply_clip_source_delta(
            montage,
            {clip_id: {"source": None} for clip_id in clip_ids},
            log=lambda message: print(f"  [YouTube fallback] {message}"),
        )
        return {
            "selected": len(selections),
            "clip_ids": clip_ids,
            "error": str(exc),
        }
    finally:
        config.REAL_PHOTO_EPF_BRIDGE = old_bridge


def _process_clip(
    project: Path,
    clip: dict[str, Any],
    candidates: list[dict[str, Any]],
    *,
    output_dir: Path,
    usage: dict[str, Any],
    target_w: int,
    target_h: int,
    fps: int,
    max_fragment: float,
    stop_event: Optional[threading.Event],
    deadline_ts: Optional[float],
    search_queries: Optional[list[str]] = None,
    context: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    clip_id = int(clip.get("id"))
    duration = _clip_duration(clip)
    clip_dir = project / "youtube" / "clips" / f"{clip_id:03d}"
    preview_dir = clip_dir / "previews"
    preview_dir.mkdir(parents=True, exist_ok=True)
    windows = []
    locator = []
    for candidate in candidates:
        detail = _load_video_locator_detail(
            candidate,
            stop_event,
            deadline_ts,
        )
        found = _locate_candidate_windows(
            candidate,
            detail=detail,
            max_windows=max(
                2,
                int(getattr(config, "YOUTUBE_POOL_TARGET", 6) or 6),
            ),
        )
        windows.extend(found)
        locator.append({
            "video_id": candidate.get("video_id"),
            "windows": len(found),
            "origins": sorted({item.get("origin") for item in found}),
        })
    parts = _fixed_candidate_parts(
        windows,
        max_fragment_sec=max_fragment,
        limit=max(6, int(getattr(config, "YOUTUBE_POOL_TARGET", 6) or 6)),
        requested_duration_sec=min(max_fragment, duration)
        if duration <= max_fragment
        else None,
    )
    metadata = {
        str(item.get("video_id")): item for item in candidates
    }
    enriched = [
        {**metadata[str(part["video_id"])], **part}
        for part in parts
        if str(part["video_id"]) in metadata
    ]
    if not enriched:
        raise RuntimeError("temporal locator produced no fixed candidate parts")
    previews = {}
    preview_rejections = []
    for part in enriched:
        preview = _download(
            part,
            preview_dir / str(part["candidate_id"]),
            stop_event,
            deadline_ts,
            start_sec=float(part["start"]),
            duration_sec=float(part["duration"]),
        )
        if preview:
            previews[str(part["candidate_id"])] = preview
        else:
            preview_rejections.append({
                "candidate_id": part["candidate_id"],
                "reason": "preview_download_failed",
            })
    usable = [
        part for part in enriched
        if str(part["candidate_id"]) in previews
    ]
    if not usable:
        raise RuntimeError("no usable YouTube preview parts")
    ranked, vision = _vision_rank_candidate_parts(
        clip,
        usable,
        previews,
        clip_dir,
        scene_text=_clip_text(project, clip),
        search_queries=search_queries,
        context=context,
    )
    remaining = duration
    selected = []
    source_parts = []
    reservations = []
    epf_tail = None
    try:
        for part in ranked:
            if remaining <= 0.05:
                break
            take = min(float(part["duration"]), remaining)
            reservation = {
                "video_id": str(part["video_id"]),
                "start": float(part["start"]),
                "end": round(float(part["start"]) + take, 3),
            }
            if not _reserve_locked(
                project,
                usage,
                reservation["video_id"],
                reservation["start"],
                reservation["end"],
                clip_id,
            ):
                continue
            reservations.append(reservation)
            selected.append({
                "candidate_id": part["candidate_id"],
                **reservation,
                "duration": round(take, 3),
                "url": part.get("url", ""),
                "license": part.get("license", "unknown"),
                "license_verified": bool(part.get("license_verified", False)),
            })
            source_parts.append((previews[str(part["candidate_id"])], take))
            remaining -= take
        if remaining > 0.05:
            if not selected:
                raise RuntimeError(
                    f"candidate parts are short by {remaining:.3f}s"
                )
            fallback_result = _run_epf_fallback(
                project,
                clip,
                stop_event=stop_event,
                deadline_ts=deadline_ts,
                target_w=target_w,
                target_h=target_h,
            )
            fallback_image = _find_generated_image(project, clip_id)
            if fallback_image is None:
                raise RuntimeError(
                    "EPF did not provide an image for the YouTube remainder"
                )
            fallback_video = _render_epf_tail(
                fallback_image,
                clip_dir / "epf_tail.mp4",
                duration=remaining,
                target_w=target_w,
                target_h=target_h,
                fps=fps,
            )
            source_parts.append((fallback_video, remaining))
            epf_tail = {
                "source": "epf",
                "duration": round(remaining, 3),
                "image": str(fallback_image),
                "video": str(fallback_video),
                "result": fallback_result,
            }
            remaining = 0.0
        output = output_dir / f"{clip_id:03d}.mp4"
        rendered = _compose_parts(
            source_parts,
            output,
            target_w=target_w,
            target_h=target_h,
            fps=fps,
            # A timeout signal stops further YouTube discovery. It must not
            # discard already selected parts while their EPF tail is composed.
            stop_event=None if epf_tail is not None else stop_event,
        )
        if not rendered.get("ok"):
            raise RuntimeError(
                rendered.get("error", "YouTube composition failed")
            )
    except Exception:
        _release_reservations(project, usage, reservations)
        raise
    selection = {
        "method": vision.get("method"),
        "queries": list(
            search_queries
            or _clip_search_queries(clip, _clip_text(project, clip))
        ),
        "context": context or {},
        "locator": locator,
        "candidate_parts": [
            {
                "candidate_id": part["candidate_id"],
                "video_id": part["video_id"],
                "start": part["start"],
                "end": part["end"],
                "duration": part["duration"],
                "origin": part["origin"],
                "window_id": part["window_id"],
            }
            for part in usable
        ],
        "vision": vision,
        "preview_rejections": preview_rejections,
        "selected_parts": selected,
        "epf_tail": epf_tail,
        "scene_duration": duration,
    }
    clip_dir.mkdir(parents=True, exist_ok=True)
    (clip_dir / "selection.json").write_text(
        json.dumps(selection, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (clip_dir / "provenance.json").write_text(
        json.dumps({
            "clip_id": clip_id,
            "scene_duration": duration,
            "queries": selection["queries"],
            "parts": selected,
            "epf_tail": epf_tail,
            "output": str(output),
        }, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return rendered


def run_youtube_stage(
    project_dir: str | Path,
    *,
    target_w: int = 1920,
    target_h: int = 1080,
    fps: Optional[int] = None,
    stop_event: Optional[threading.Event] = None,
    deadline_ts: Optional[float] = None,
) -> dict[str, Any]:
    project = Path(project_dir).resolve()
    montage = project / "montage_plan.json"
    if not montage.exists():
        return {
            "ok": 0,
            "failed": 0,
            "total": 0,
            "error": "montage_plan.json missing",
        }
    plan = _load_plan(montage)
    pending = [
        clip for clip in plan.get("clips", [])
        if clip.get("source") == "youtube_pending"
    ]
    if not pending:
        return {"ok": 0, "failed": 0, "total": 0}
    from modules.clip_sources import apply_clip_source_delta
    from modules.non_ai_image_policy import enabled as non_ai_enabled
    from modules.video_claims import acquire_clip_claim

    usage = _load_usage(project)
    output_dir = project / "vid_img"
    output_dir.mkdir(parents=True, exist_ok=True)
    fps = int(fps or getattr(config, "VIDEO_FPS", 60))
    max_fragment = max(
        0.5,
        float(getattr(config, "YOUTUBE_MAX_FRAGMENT_SEC", 3) or 3),
    )
    pool_cache: dict[str, list[dict[str, Any]]] = {}
    failures: dict[int, Any] = {}
    ok = failed = 0
    for clip in pending:
        if stop_event is not None and stop_event.is_set():
            break
        if deadline_ts is not None and time.time() >= deadline_ts:
            break
        clip_id = int(clip.get("id"))
        claim = acquire_clip_claim(output_dir, clip_id, owner="youtube")
        if claim is None:
            continue
        try:
            clip_dir = project / "youtube" / "clips" / f"{clip_id:03d}"
            context = _load_visual_context(project, clip)
            if context:
                (clip_dir / "context.json").write_text(
                    json.dumps(context, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
            queries = _plan_search_queries(
                project,
                clip,
                clip_dir,
                context=context,
            )
            cache_key = json.dumps(queries, ensure_ascii=False)
            if cache_key not in pool_cache:
                pool_cache[cache_key] = _discover_candidates_multi(
                    queries,
                    int(getattr(config, "YOUTUBE_POOL_TARGET", 6) or 6),
                    stop_event,
                    deadline_ts,
                )
                pool_path = project / "youtube" / "pools" / (
                    f"{hashlib.md5(cache_key.encode()).hexdigest()}.json"
                )
                pool_path.parent.mkdir(parents=True, exist_ok=True)
                pool_path.write_text(
                    json.dumps({
                        "queries": queries,
                        "candidates": pool_cache[cache_key],
                    }, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
            candidates = pool_cache[cache_key]
            if not candidates:
                raise RuntimeError(
                    "licensed YouTube discovery returned no candidates"
                )
            _process_clip(
                project,
                clip,
                candidates,
                output_dir=output_dir,
                usage=usage,
                target_w=target_w,
                target_h=target_h,
                fps=fps,
                max_fragment=max_fragment,
                stop_event=stop_event,
                deadline_ts=deadline_ts,
                search_queries=queries,
                context=context,
            )
            apply_clip_source_delta(
                montage,
                {clip_id: {
                    "source": "youtube",
                    "file": f"vid_img/{clip_id:03d}.mp4",
                }},
                log=lambda message: print(f"  [YouTube] {message}"),
            )
            ok += 1
        except Exception as exc:
            failed += 1
            failures[clip_id] = str(exc)
            failure_dir = (
                project / "youtube" / "clips" / f"{clip_id:03d}"
            )
            failure_dir.mkdir(parents=True, exist_ok=True)
            (failure_dir / "failure.json").write_text(
                json.dumps(
                    {"clip_id": clip_id, "error": str(exc)},
                    ensure_ascii=False,
                    indent=2,
                ),
                encoding="utf-8",
            )
            if stop_event is not None and stop_event.is_set():
                continue
            apply_clip_source_delta(
                montage,
                {clip_id: {
                    "source": "real_photo_pending"
                    if non_ai_enabled()
                    else "stock_pending",
                }},
                log=lambda message: print(f"  [YouTube] {message}"),
            )
            if non_ai_enabled():
                try:
                    failures[clip_id] = {
                        "youtube_error": str(exc),
                        "epf_fallback": _run_epf_fallback(
                            project,
                            clip,
                            stop_event=stop_event,
                            deadline_ts=deadline_ts,
                            target_w=target_w,
                            target_h=target_h,
                        ),
                    }
                except Exception as fallback_exc:
                    failures[clip_id] = {
                        "youtube_error": str(exc),
                        "epf_fallback_error": str(fallback_exc),
                    }
        finally:
            claim.release()
    return {
        "ok": ok,
        "failed": failed,
        "total": len(pending),
        "reasons": failures,
    }
