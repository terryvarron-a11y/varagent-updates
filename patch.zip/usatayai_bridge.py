#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
usatayai_bridge.py — v55.43
Stable final-render adapter for VAR -> Usataya Lentyayka.

This module is intentionally independent from VAR internals. VAR may keep changing
its director/concat logic; this bridge only needs the already prepared temporary
video from video_concat.py plus a JSON manifest from Usataya Lentyayka.

Activation:
  video_concat.py calls run_bridge_if_requested(...) only when either
  --usatayai-bridge-manifest or USATAYAI_BRIDGE_MANIFEST is set.

If no manifest is supplied, VAR behaves exactly as before.
"""
from __future__ import annotations

import json
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, Optional

if platform.system() == "Windows":
    SUBPROCESS_FLAGS = {"creationflags": 0x08000000}
else:
    SUBPROCESS_FLAGS = {}


def _resolve_ff(name: str) -> str:
    found = shutil.which(name)
    return found or name


def _bool(v: Any) -> bool:
    if isinstance(v, bool):
        return v
    return str(v).strip().lower() in {"1", "true", "yes", "y", "on", "да", "вкл"}


def _log(msg: str) -> None:
    print(f"[USATAYAI-BRIDGE] {msg}", flush=True)


def _probe_duration(ffprobe: str, path: str) -> float:
    try:
        r = subprocess.run(
            [ffprobe, "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=30,
            **SUBPROCESS_FLAGS,
        )
        return float((r.stdout or "").strip() or 0.0)
    except Exception:
        return 0.0


def _escape_filter_path(path: str) -> str:
    path = str(path)
    if platform.system() == "Windows":
        path = path.replace("\\", "/")
    return path.replace("'", r"\'").replace(":", r"\:")


def _srt_time_to_ass(s: str) -> str:
    h, m, rest = s.strip().split(":")
    sec, ms = re.split(r"[,.]", rest)
    return f"{int(h)}:{m}:{sec}.{(ms + '00')[:2]}"


def _hex_to_ass_color(value: str, default: str) -> str:
    s = str(value or "").strip()
    if not s:
        return default
    if s.lower().startswith("&h"):
        return s
    s = s.lstrip("#")
    try:
        if len(s) == 6:
            r, g, b = int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16)
            return f"&H00{b:02X}{g:02X}{r:02X}"
    except Exception:
        pass
    return default


def _srt_to_ass(srt_path: Path, ass_path: Path, preset: Dict[str, Any]) -> Optional[Path]:
    if not srt_path.exists():
        return None
    text = srt_path.read_text(encoding="utf-8-sig", errors="replace")
    blocks = [b.strip() for b in re.split(r"\n{2,}", text) if b.strip()]
    events = []
    for block in blocks:
        lines = [l.strip() for l in block.splitlines() if l.strip()]
        time_line = next((l for l in lines if "-->" in l), None)
        if not time_line:
            continue
        idx = lines.index(time_line)
        try:
            t0, t1 = [x.strip().split()[0] for x in time_line.split("-->", 1)]
            body = " ".join(lines[idx + 1:]).replace("\n", " ").strip()
            if body:
                events.append(f"Dialogue: 0,{_srt_time_to_ass(t0)},{_srt_time_to_ass(t1)},Default,,0,0,0,,{body}")
        except Exception:
            continue
    if not events:
        return None

    font_name = preset.get("font_name") or preset.get("font") or "Arial"
    font_size = preset.get("font_size") or preset.get("size") or "52"
    primary = _hex_to_ass_color(preset.get("primary_color") or preset.get("primary_colour") or "#ffffff", "&H00FFFFFF")
    outline = _hex_to_ass_color(preset.get("outline_color") or preset.get("outline_colour") or "#000000", "&H00000000")
    shadow = _hex_to_ass_color(preset.get("shadow_color") or preset.get("shadow_colour") or "#000000", "&H80000000")
    bold_raw = str(preset.get("bold", "-1")).strip().lower()
    bold = "-1" if bold_raw in ("1", "true", "yes", "on", "-1") else "0"
    outline_size = preset.get("outline", "2")
    shadow_size = preset.get("shadow", "0")
    margin_l = preset.get("margin_l", "10")
    margin_r = preset.get("margin_r", "10")
    margin_v = preset.get("margin_v", "60")
    alignment = preset.get("alignment", "2")
    header = (
        "[Script Info]\nScriptType: v4.00+\nPlayResX: 1920\nPlayResY: 1080\n\n"
        "[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, "
        "Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, "
        "Alignment, MarginL, MarginR, MarginV, Encoding\n"
        f"Style: Default,{font_name},{font_size},{primary},&H000000FF,{outline},{shadow},"
        f"{bold},0,0,0,100,100,0,0,1,{outline_size},{shadow_size},{alignment},{margin_l},{margin_r},{margin_v},1\n\n"
        "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
    )
    ass_path.write_text(header + "\n".join(events) + "\n", encoding="utf-8-sig")
    return ass_path


def _slugify_name(value: str) -> str:
    raw = str(value or "").strip()
    raw = re.sub(r"[^\w\-. ]+", "_", raw, flags=re.UNICODE)
    raw = re.sub(r"\s+", "_", raw, flags=re.UNICODE).strip("._ ")
    return raw or "audio"


def _find_srt(manifest: Dict[str, Any], project_dir: Path) -> Optional[Path]:
    candidates: list[Path] = []
    for key in ("srt_path", "subtitle_srt", "source_srt", "ass_source_srt"):
        if manifest.get(key):
            candidates.append(Path(str(manifest[key])).expanduser())
    candidates.extend([
        project_dir / "SRT" / "subtitles.srt",
        project_dir / "SRT" / "subtitles_split.srt",
        project_dir / "transcript.srt",
        project_dir / "subtitles.srt",
    ])

    audio = manifest.get("source_mp3") or manifest.get("audio")
    if audio:
        ap = Path(str(audio)).expanduser()
        candidates.append(ap.with_suffix(".srt"))
        candidates.append(ap.parent / "transcript.srt")
        if ap.parent.exists():
            candidates.extend(list(ap.parent.glob("*.srt")))

        # Основная добивка кладёт предтранскрибацию сюда:
        # <APP_ROOT>/projects/_parser_output/<slug(source_mp3.stem)>/transcript.srt
        stem_slug = _slugify_name(ap.stem)
        app_root = Path(__file__).resolve().parent.parent
        candidates.append(app_root / "projects" / "_parser_output" / stem_slug / "transcript.srt")

        # Если output_dir смотрит внутрь другой папки projects, проверяем и её.
        out_dir_raw = str(manifest.get("output_dir") or "").strip()
        if out_dir_raw:
            out_dir = Path(out_dir_raw).expanduser()
            for root in (out_dir, out_dir.parent, out_dir.parent.parent):
                candidates.append(root / "_parser_output" / stem_slug / "transcript.srt")

    seen = set()
    for c in candidates:
        try:
            rp = str(c.expanduser().resolve())
        except Exception:
            rp = str(c)
        if rp in seen:
            continue
        seen.add(rp)
        if c and c.exists() and c.is_file():
            _log(f"SRT found: {c}")
            return c
    _log("SRT not found for subtitles")
    return None


def _load_presets_from_disk(group_key: str) -> Dict[str, Any]:
    """Fallback: читает пресеты Лентяйки с диска, если manifest принёс только имя.

    Это страхует Коршун→VAR от голого рендера, когда subprocess получил
    subtitle_preset/logo_preset/music_preset, но словарь presets не попал в manifest.
    """
    filename_map = {
        "subtitle_presets": "subtitle_presets.json",
        "logo_presets": "logo_presets.json",
        "music_presets": "music_presets.json",
    }
    fname = filename_map.get(group_key)
    if not fname:
        return {}
    app_root = Path(__file__).resolve().parent.parent
    candidates = [
        Path.home() / "Documents" / "usatayai" / "presets" / fname,
        app_root / "presets" / fname,
        app_root / "config" / fname,
        Path.cwd() / "presets" / fname,
        Path.cwd() / fname,
    ]
    for fp in candidates:
        try:
            if not fp.exists() or not fp.is_file():
                continue
            data = json.loads(fp.read_text(encoding="utf-8-sig"))
            if isinstance(data, dict) and isinstance(data.get("presets"), dict):
                data = data.get("presets")
            if isinstance(data, dict):
                _log(f"preset fallback loaded: {group_key} <- {fp}")
                return data
        except Exception as exc:
            _log(f"preset fallback read failed: {fp} | {exc}")
    return {}


def _pick_preset(manifest: Dict[str, Any], group_key: str, name_key: str) -> Dict[str, Any]:
    presets = manifest.get(group_key) or {}
    name = str(manifest.get(name_key) or "").strip()

    def _find(src: Dict[str, Any]) -> Dict[str, Any]:
        if not isinstance(src, dict) or not name:
            return {}
        if name in src and isinstance(src[name], dict):
            return src[name]
        # Страховка от невидимых пробелов/разного регистра в имени пресета.
        nlow = name.casefold()
        for k, v in src.items():
            if str(k).strip().casefold() == nlow and isinstance(v, dict):
                return v
        return {}

    disk_presets = None

    def _merge_nonempty(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
        merged = dict(base or {})
        for k, v in (override or {}).items():
            if v is None:
                continue
            if isinstance(v, str) and not v.strip():
                continue
            merged[k] = v
        return merged

    picked = _find(presets)
    if picked:
        # Если manifest принёс неполный/старый словарь пресета, добираем
        # актуальные поля с диска. Особенно важно для LOGO: path может быть,
        # а scale_width/position/margins теряются, и прозрачный 1920px PNG
        # ужимается до дефолтных 190px.
        disk_presets = _load_presets_from_disk(group_key)
        disk_picked = _find(disk_presets)
        if disk_picked:
            return _merge_nonempty(disk_picked, picked)
        return picked
    if isinstance(presets, dict) and len(presets) == 1:
        only = next(iter(presets.values()))
        if isinstance(only, dict):
            return only
    if disk_presets is None:
        disk_presets = _load_presets_from_disk(group_key)
    picked = _find(disk_presets)
    if picked:
        return picked
    return {}


def _preset_path_value(preset: Dict[str, Any], *keys: str) -> str:
    for key in keys:
        val = str((preset or {}).get(key) or "").strip()
        if val:
            return val
    return ""


def _first_text(*values: Any) -> str:
    for v in values:
        val = str(v or "").strip()
        if val:
            return val
    return ""


def _first_number(*values: Any, default: Optional[int] = None, allow_zero: bool = False) -> Optional[int]:
    for v in values:
        try:
            val = str(v if v is not None else "").strip().replace(",", ".")
            if val == "":
                continue
            num = int(float(val))
            if num > 0 or (allow_zero and num == 0):
                return num
        except Exception:
            continue
    return default


def _probe_image_width(ffprobe: str, path: Path) -> Optional[int]:
    w, _h = _probe_image_size(ffprobe, path)
    return w


def _probe_image_size(ffprobe: str, path: Path) -> tuple[Optional[int], Optional[int]]:
    try:
        r = subprocess.run(
            [ffprobe, "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height", "-of", "csv=s=x:p=0", str(path)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=20,
            **SUBPROCESS_FLAGS,
        )
        raw = (r.stdout or "").strip().splitlines()[0].strip() if (r.stdout or "").strip() else ""
        if "x" not in raw:
            return None, None
        a, b = raw.split("x", 1)
        w = int(float(a.strip()))
        h = int(float(b.strip()))
        return (w if w > 0 else None), (h if h > 0 else None)
    except Exception:
        return None, None


def _logo_settings(manifest: Dict[str, Any], logo_preset: Dict[str, Any], ffprobe: str, logo_path: Path) -> tuple[int, str, int, int]:
    natural_w = _probe_image_width(ffprobe, logo_path)
    # Прямые поля из manifest имеют приоритет над fallback-пресетом с диска.
    # Для Коршун→VAR это критично: bridge может видеть старый ~/Documents preset,
    # а live UI уже хранит другой PNG/нулевые отступы.
    logo_w = _first_number(
        manifest.get("logo_width"),
        manifest.get("scale_width"),
        logo_preset.get("scale_width"),
        logo_preset.get("width"),
        logo_preset.get("logo_width"),
        logo_preset.get("Ширина логотипа"),
        default=natural_w or 190,
    ) or 190
    pos = _first_text(
        manifest.get("logo_position"),
        logo_preset.get("position"),
        logo_preset.get("pos"),
        logo_preset.get("logo_position"),
        logo_preset.get("Позиция"),
        "top_right",
    )
    mx_val = _first_number(
        manifest.get("logo_margin_x"),
        manifest.get("margin_x"),
        logo_preset.get("margin_x"),
        logo_preset.get("offset_x"),
        logo_preset.get("x"),
        logo_preset.get("Отступ X"),
        default=40,
        allow_zero=True,
    )
    my_val = _first_number(
        manifest.get("logo_margin_y"),
        manifest.get("margin_y"),
        logo_preset.get("margin_y"),
        logo_preset.get("offset_y"),
        logo_preset.get("y"),
        logo_preset.get("Отступ Y"),
        default=40,
        allow_zero=True,
    )
    mx = 40 if mx_val is None else mx_val
    my = 40 if my_val is None else my_val
    return int(logo_w), str(pos), int(mx), int(my)


def _parse_photo_timecode(path: Path) -> Optional[float]:
    """Понимает имена СОВЫ вида MM-SS.jpg или H-MM-SS.jpg."""
    stem = path.stem
    m = re.match(r"^(\d+)-(\d{2})-(\d{2})$", stem)
    if m:
        return float(int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3)))
    m = re.match(r"^(\d+)-(\d{2})$", stem)
    if m:
        return float(int(m.group(1)) * 60 + int(m.group(2)))
    m = re.search(r"(\d+)-(\d{2})(?:-(\d{2}))?", stem)
    if m:
        if m.group(3):
            return float(int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3)))
        return float(int(m.group(1)) * 60 + int(m.group(2)))
    return None


def _collect_overlay_photos(manifest: Dict[str, Any], project_dir: Path) -> list[Path]:
    if not (
        _bool(manifest.get("use_seva_photos", False))
        or _bool(manifest.get("send_fotki", False))
        or _bool(manifest.get("svoi_photki", False))
    ):
        return []
    exts = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}
    candidates: list[Path] = []
    svoi_dir = str(manifest.get("svoi_photki_dir") or "").strip()
    if _bool(manifest.get("svoi_photki", False)) and svoi_dir:
        candidates.append(Path(svoi_dir).expanduser())
    for key in ("seva_photos_dir", "korshun_photos_dir", "photos_dir"):
        raw = str(manifest.get(key) or "").strip()
        if raw:
            candidates.append(Path(raw).expanduser())
    candidates.append(project_dir / "photos")

    seen = set()
    result: list[Path] = []
    for d in candidates:
        if not d.exists() or not d.is_dir():
            continue
        for p in sorted(d.iterdir()):
            if not p.is_file() or p.suffix.lower() not in exts:
                continue
            rp = str(p.resolve())
            if rp in seen:
                continue
            seen.add(rp)
            # Основной вариант: фото СОВЫ с таймкодом в имени.
            # Резерв для одиночной фотки из Коршуна: если таймкода нет, положим её в начало.
            if _parse_photo_timecode(p) is not None:
                result.append(p)
        if result:
            break
        # fallback: хотя бы первая картинка, если СОВА/свои фотки пришли без таймкода
        fallback = [p for p in sorted(d.iterdir()) if p.is_file() and p.suffix.lower() in exts]
        if fallback:
            result.append(fallback[0])
            break
    return result



def _profile_dims(manifest: Dict[str, Any], fps_fallback: int) -> tuple[int, int, int]:
    name = str(manifest.get("output_profile") or "1080p25")
    m = re.match(r"(\d+)p(\d+)", name)
    if m:
        h = int(m.group(1)); fps = int(m.group(2))
        if h == 720:
            return 1280, 720, fps
        return 1920, 1080, fps
    res = str(manifest.get("resolution") or "1920x1080")
    rm = re.match(r"(\d+)x(\d+)", res)
    if rm:
        return int(rm.group(1)), int(rm.group(2)), int(fps_fallback or 25)
    return 1920, 1080, int(fps_fallback or 25)


def _norm_video_role(value: Any) -> str:
    raw = str(value or "").strip().lower()
    if raw in ("start", "intro", "begin", "beginning", "начало"):
        return "начало"
    if raw in ("end", "outro", "finish", "конец"):
        return "конец"
    return "сценарий"


def _collect_video_entries(manifest: Dict[str, Any]) -> list[Dict[str, Any]]:
    if not _bool(manifest.get("korshun_video_cycle_enabled")):
        return []
    raw_items = manifest.get("korshun_video_cycle_files") or manifest.get("korshun_video_insert_files") or []
    if not isinstance(raw_items, list):
        return []
    result = []
    for order, item in enumerate(raw_items):
        if not isinstance(item, dict):
            continue
        raw = str(item.get("path") or "").strip()
        if not raw:
            continue
        p = Path(raw).expanduser()
        if not p.exists() or p.suffix.lower() not in (".mp4", ".mov", ".mkv", ".m4v", ".avi"):
            continue
        try:
            ord_val = int(item.get("order", order))
        except Exception:
            ord_val = order
        result.append({"path": str(p), "role": _norm_video_role(item.get("role")), "order": ord_val, "name": item.get("name") or p.name})
    return result


def _parse_video_timecode(path: Path) -> Optional[float]:
    stem = path.stem
    patterns = [
        r"(?:^|_)(\d+)-(\d{2})-(\d{2})(?:$|_)",
        r"(?:^|_)(\d+)-(\d{2})(?:$|_)",
        r"(\d+)-(\d{2})-(\d{2})",
        r"(\d+)-(\d{2})",
    ]
    for pat in patterns:
        m = re.search(pat, stem)
        if not m:
            continue
        try:
            if len(m.groups()) == 3 and m.group(3) is not None:
                return float(int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3)))
            return float(int(m.group(1)) * 60 + int(m.group(2)))
        except Exception:
            continue
    return None


def _run_ffmpeg_checked(cmd: list[str], label: str) -> None:
    _log(label + ": " + " ".join(cmd))
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, **SUBPROCESS_FLAGS)
    tail: list[str] = []
    assert proc.stdout is not None
    for line in proc.stdout:
        line = line.rstrip()
        if line:
            tail.append(line)
            if len(tail) > 25:
                tail.pop(0)
            if "time=" in line or "frame=" in line:
                print(line, flush=True)
    rc = proc.wait()
    if rc != 0:
        raise RuntimeError(label + " failed:\n" + "\n".join(tail))


def _normalize_video_piece(ffmpeg: str, ffprobe: str, src: Path, out: Path, manifest: Dict[str, Any], fps: int, *, fade: bool = False) -> Path:
    width, height, fps2 = _profile_dims(manifest, fps)
    fps = fps2 or fps
    dur = _probe_duration(ffprobe, str(src))
    if dur <= 0:
        raise RuntimeError(f"video insert duration is zero: {src}")
    filters = [
        f"[0:v]setpts=PTS-STARTPTS,scale={width}:{height}:force_original_aspect_ratio=increase:force_divisible_by=2:flags=lanczos,crop={width}:{height},fps={fps},setsar=1,format=yuv420p"
    ]
    if fade:
        fd = min(0.45, max(0.10, dur / 5.0))
        filters[0] += f",fade=t=in:st=0:d={fd:.3f},fade=t=out:st={max(0.0, dur-fd):.3f}:d={fd:.3f}"
    filters[0] += "[vout]"
    cmd = [ffmpeg, "-y", "-fflags", "+genpts", "-i", str(src)]
    # Для видеовставок звук сохраняем, если он есть, иначе даём тишину.
    has_audio = False
    try:
        r = subprocess.run([ffprobe, "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=index", "-of", "csv=p=0", str(src)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=20, **SUBPROCESS_FLAGS)
        has_audio = bool((r.stdout or "").strip())
    except Exception:
        has_audio = False
    if has_audio:
        filters.append("[0:a]aresample=48000,asetpts=PTS-STARTPTS[aout]")
    else:
        cmd += ["-f", "lavfi", "-t", f"{dur:.3f}", "-i", "anullsrc=r=48000:cl=stereo"]
        filters.append("[1:a]aresample=48000,asetpts=PTS-STARTPTS[aout]")
    cmd += ["-filter_complex", ";".join(filters), "-map", "[vout]", "-map", "[aout]", "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", "-r", str(fps), "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", "-shortest", str(out)]
    _run_ffmpeg_checked(cmd, f"video insert normalize {src.name}")
    return out


def _cut_base_part(ffmpeg: str, ffprobe: str, base: Path, out: Path, start: float, duration: float, manifest: Dict[str, Any], fps: int, idx: int) -> Optional[Path]:
    if duration <= 0.05:
        return None
    width, height, fps2 = _profile_dims(manifest, fps)
    fps = fps2 or fps
    cmd = [ffmpeg, "-y", "-ss", f"{start:.3f}", "-t", f"{duration:.3f}", "-i", str(base)]
    filters = [f"[0:v]setpts=PTS-STARTPTS,scale={width}:{height}:force_original_aspect_ratio=increase:force_divisible_by=2:flags=lanczos,crop={width}:{height},fps={fps},setsar=1,format=yuv420p[vout]"]
    try:
        r = subprocess.run([ffprobe, "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=index", "-of", "csv=p=0", str(base)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=20, **SUBPROCESS_FLAGS)
        has_audio = bool((r.stdout or "").strip())
    except Exception:
        has_audio = False
    if has_audio:
        filters.append("[0:a]aresample=48000,asetpts=PTS-STARTPTS[aout]")
    else:
        cmd += ["-f", "lavfi", "-t", f"{duration:.3f}", "-i", "anullsrc=r=48000:cl=stereo"]
        filters.append("[1:a]aresample=48000,asetpts=PTS-STARTPTS[aout]")
    cmd += ["-filter_complex", ";".join(filters), "-map", "[vout]", "-map", "[aout]", "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", "-r", str(fps), "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", "-shortest", str(out)]
    _run_ffmpeg_checked(cmd, f"video insert base part {idx}")
    return out


def _concat_video_sequence(ffmpeg: str, sequence: list[Path], out_path: Path, tmp_dir: Path, manifest: Dict[str, Any], fps: int) -> Path:
    concat_txt = tmp_dir / "video_insert_concat.txt"
    concat_txt.write_text("\n".join(["file '" + str(Path(p).resolve()).replace("'", "'\\''") + "'" for p in sequence]) + "\n", encoding="utf-8")
    meta = [] if str(manifest.get("metadata_mode") or "Удалять") == "Оставлять" else ["-map_metadata", "-1", "-map_chapters", "-1"]
    cmd = [ffmpeg, "-y", "-f", "concat", "-safe", "0", "-i", str(concat_txt), *meta, "-c", "copy", str(out_path)]
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=7200, **SUBPROCESS_FLAGS)
    if proc.returncode != 0:
        _log("video insert concat copy failed, fallback reencode")
        width, height, fps2 = _profile_dims(manifest, fps)
        fps = fps2 or fps
        cmd = [ffmpeg, "-y", "-f", "concat", "-safe", "0", "-i", str(concat_txt), *meta, "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", "-r", str(fps), "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(out_path)]
        _run_ffmpeg_checked(cmd, "video insert final reencode")
    return out_path


def _apply_video_inserts(ffmpeg: str, ffprobe: str, base_video: Path, output_path: Path, manifest: Dict[str, Any], tmp_dir: Path, fps: int) -> bool:
    entries = _collect_video_entries(manifest)
    if not entries:
        return False
    _log(f"video inserts enabled: {len(entries)}")
    base_dur = _probe_duration(ffprobe, str(base_video))
    if base_dur <= 0:
        raise RuntimeError("base video duration is zero for video inserts")
    work = tmp_dir / "video_inserts"
    work.mkdir(parents=True, exist_ok=True)
    starts = [e for e in entries if e["role"] == "начало"]
    ends = [e for e in entries if e["role"] == "конец"]
    scenarios = [e for e in entries if e["role"] == "сценарий"]
    sequence: list[Path] = []
    cache: dict[tuple[str, str, int], Path] = {}

    def norm(entry: Dict[str, Any], prefix: str, n: int) -> Path:
        src = Path(entry["path"])
        key = (str(src), prefix, n)
        if key not in cache:
            clean_stem = re.sub(r'[^\w\-.]+', '_', src.stem, flags=re.UNICODE)
            out = work / f"{prefix}_{n:04d}_{clean_stem}.mp4"
            cache[key] = _normalize_video_piece(ffmpeg, ffprobe, src, out, manifest, fps, fade=True)
        return cache[key]

    for i, entry in enumerate(sorted(starts, key=lambda x: x["order"]), start=1):
        sequence.append(norm(entry, "start", i))
    prepared = []
    for entry in scenarios:
        tc = _parse_video_timecode(Path(entry["path"]))
        if tc is None:
            _log(f"video insert scenario without timecode skipped: {Path(entry['path']).name}")
            continue
        prepared.append((max(0.0, min(float(tc), base_dur)), int(entry.get("order") or 0), entry))
    prepared.sort(key=lambda x: (x[0], x[1]))
    if not prepared:
        sequence.append(base_video)
    else:
        cursor = 0.0
        part_idx = 0
        scen_idx = 0
        for target, _order, entry in prepared:
            if target < cursor:
                target = cursor
            if target > cursor + 0.05:
                part_idx += 1
                part = _cut_base_part(ffmpeg, ffprobe, base_video, work / f"base_{part_idx:04d}.mp4", cursor, target - cursor, manifest, fps, part_idx)
                if part:
                    sequence.append(part)
            scen_idx += 1
            sequence.append(norm(entry, "scenario", scen_idx))
            cursor = target
        if cursor < base_dur - 0.05:
            part_idx += 1
            part = _cut_base_part(ffmpeg, ffprobe, base_video, work / f"base_{part_idx:04d}.mp4", cursor, base_dur - cursor, manifest, fps, part_idx)
            if part:
                sequence.append(part)
    for i, entry in enumerate(sorted(ends, key=lambda x: x["order"]), start=1):
        sequence.append(norm(entry, "end", i))
    _concat_video_sequence(ffmpeg, sequence, output_path, work, manifest, fps)
    _log("video inserts done")
    return True

def render_final(
    temp_video: str,
    output_path: str,
    narration_audio: Optional[str],
    manifest_path: str,
    *,
    bitrate: str = "10M",
    fps: int = 60,
    encoder_type: str = "cpu",
    codec: str = "libx264",
) -> bool:
    manifest_file = Path(manifest_path).expanduser()
    if not manifest_file.exists():
        _log(f"manifest not found: {manifest_file}")
        return False

    manifest = json.loads(manifest_file.read_text(encoding="utf-8-sig"))
    ffmpeg = str(manifest.get("ffmpeg") or _resolve_ff("ffmpeg"))
    ffprobe = str(manifest.get("ffprobe") or _resolve_ff("ffprobe"))
    project_dir = Path(str(manifest.get("project_dir") or Path(output_path).parent)).expanduser()
    project_dir.mkdir(parents=True, exist_ok=True)
    tmp_base = project_dir / "_usatayai_bridge_temp"
    tmp_base.mkdir(parents=True, exist_ok=True)
    tmp_dir = Path(tempfile.mkdtemp(prefix="run_", dir=str(tmp_base)))

    source_audio = str(manifest.get("source_mp3") or manifest.get("audio") or narration_audio or "").strip()
    use_source_audio = bool(source_audio and Path(source_audio).exists())
    use_original_audio = _bool(manifest.get("keep_original_audio", False)) or _bool(manifest.get("veo_audio_inline", False))

    use_subs = _bool(manifest.get("use_subs", False))
    use_logo = _bool(manifest.get("use_logo", False))
    use_music = _bool(manifest.get("use_music", False))
    metadata_mode = str(manifest.get("metadata_mode") or "Удалять")
    source_volume = str(manifest.get("source_mp3_volume") or manifest.get("source_volume") or "1.0")

    sub_preset = _pick_preset(manifest, "subtitle_presets", "subtitle_preset")
    logo_preset = _pick_preset(manifest, "logo_presets", "logo_preset")
    music_preset = _pick_preset(manifest, "music_presets", "music_preset")

    # Если выбран конкретный слой или режим Коршун→VAR пришёл через dobivka,
    # не даём старому snapshot с use_* = 0 погасить пресеты набора.
    layer_mode = (
        _bool(manifest.get("dobivka", False))
        or str(manifest.get("origin_pipeline") or "").strip() == "parser_var"
        or bool(str(manifest.get("subtitle_preset") or "").strip())
        or bool(str(manifest.get("logo_preset") or "").strip())
        or bool(str(manifest.get("music_preset") or "").strip())
    )
    if layer_mode:
        if str(manifest.get("subtitle_preset") or "").strip() or str(manifest.get("srt_path") or manifest.get("source_srt") or "").strip():
            use_subs = True
        if str(manifest.get("logo_preset") or manifest.get("logo_path") or "").strip():
            use_logo = True
        if str(manifest.get("music_preset") or manifest.get("music_path") or "").strip():
            use_music = True

    overlay_photos = _collect_overlay_photos(manifest, project_dir)

    video_entries = _collect_video_entries(manifest)
    _log(
        "flags: "
        f"dobivka={manifest.get('dobivka')!r} "
        f"subs={use_subs}({manifest.get('subtitle_preset')!r}) "
        f"logo={use_logo}({manifest.get('logo_preset')!r}) "
        f"music={use_music}({manifest.get('music_preset')!r}) "
        f"photos={len(overlay_photos)} "
        f"video_inserts={len(video_entries)} "
        f"source_audio={bool(use_source_audio)}"
    )


    cmd = [ffmpeg, "-y", "-i", str(temp_video)]
    filters = []
    input_index = 1

    audio_inputs = []
    if use_source_audio:
        cmd += ["-i", source_audio]
        audio_inputs.append((input_index, source_volume, "source"))
        input_index += 1

    logo_idx = None
    logo_file_path: Optional[Path] = None
    logo_path = str(
        manifest.get("logo_path")
        or manifest.get("png_path")
        or manifest.get("file_png")
        or manifest.get("image_path")
        or manifest.get("Файл PNG")
        or _preset_path_value(
            logo_preset,
            "path", "file", "logo_path", "png_path", "file_png", "image_path", "Файл PNG"
        )
        or ""
    ).strip()
    if use_logo and logo_path and Path(logo_path).expanduser().exists():
        lp = Path(logo_path).expanduser()
        logo_file_path = lp
        if lp.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"}:
            cmd += ["-loop", "1", "-framerate", str(fps), "-i", str(lp)]
        else:
            cmd += ["-stream_loop", "-1", "-i", str(lp)]
        logo_idx = input_index
        input_index += 1
        _log(f"logo input: {lp}")
    elif use_logo:
        _log(f"logo requested but preset/path not found: preset={manifest.get('logo_preset')!r} path={logo_path!r}")
        try:
            _log(f"logo preset data keys: {sorted(list((logo_preset or {}).keys()))}")
        except Exception:
            pass

    if use_music:
        music_paths = []
        p1 = str(manifest.get("music_path") or _preset_path_value(music_preset, "path", "file", "music_path", "audio_path") or "").strip()
        if p1:
            music_paths.append((p1, str(music_preset.get("music_volume", manifest.get("music_volume", "0.12")) or "0.12")))
        p2 = str(music_preset.get("path_2") or "").strip()
        if _bool(music_preset.get("second_track_enabled", False)) and p2:
            music_paths.append((p2, str(music_preset.get("music_volume_2", "0.10") or "0.10")))
        _music_added = 0
        for mp, vol in music_paths:
            if Path(mp).expanduser().exists():
                cmd += ["-stream_loop", "-1", "-i", str(Path(mp).expanduser())]
                audio_inputs.append((input_index, vol, "music"))
                input_index += 1
                _music_added += 1
            elif mp:
                _log(f"music requested but file not found: {mp}")
        if _music_added == 0:
            _log(f"music requested but preset/path not found: preset={manifest.get('music_preset')!r}")

    vcur = "[0:v]"
    if use_subs:
        ass_direct = manifest.get("ass_path") or manifest.get("subtitle_ass")
        ass_path = Path(str(ass_direct)).expanduser() if ass_direct else None
        if not ass_path or not ass_path.exists():
            srt = _find_srt(manifest, project_dir)
            ass_path = _srt_to_ass(srt, tmp_dir / "usatayai_subs.ass", sub_preset) if srt else None
        if ass_path and ass_path.exists():
            filters.append(f"{vcur}ass='{_escape_filter_path(str(ass_path))}'[vsub]")
            vcur = "[vsub]"
            _log(f"subtitles enabled: {ass_path.name}")
        else:
            _log("subtitles requested but no SRT/ASS found")

    # FIX v55.43: лого клеим ДО фоток.
    # Если клеить лого ПОСЛЕ фоток (как было), vcur указывает на [vphotoN] —
    # поток фотки активен только в enable='between(t,...)' окне.
    # За пределами этого окна поток пустой, и лого поверх него тоже пропадает.
    # Порядок: сабы → лого → фотки. Фотки поверх лого — визуально правильно.
    if logo_idx is not None and logo_file_path is not None:
        logo_w, pos, mx, my = _logo_settings(manifest, logo_preset, ffprobe, logo_file_path)
        profile_w, profile_h, _fps_profile = _profile_dims(manifest, fps)
        natural_w, natural_h = _probe_image_size(ffprobe, logo_file_path)

        full_canvas_logo = bool(
            natural_w and natural_h
            and natural_w >= int(profile_w * 0.85)
            and natural_h >= int(profile_h * 0.85)
            and logo_w <= int(natural_w * 0.35)
        )

        if full_canvas_logo:
            x, y = "0", "0"
            pos = "top_left"
            mx, my = 0, 0
            logo_w = natural_w or profile_w
            filters.append(
                f"[{logo_idx}:v]"
                f"fps={fps},"
                f"scale={profile_w}:{profile_h}:force_original_aspect_ratio=decrease:force_divisible_by=2:flags=lanczos,"
                f"pad={profile_w}:{profile_h}:(ow-iw)/2:(oh-ih)/2:color=black@0,"
                f"format=rgba,setpts=N/FRAME_RATE/TB"
                f"[ulogo]"
            )
            _log(
                f"logo full-canvas mode: natural={natural_w}x{natural_h} "
                f"canvas={profile_w}x{profile_h} preset_width={logo_w} overlay=0,0"
            )
        else:
            if pos == "top_left":
                x, y = str(mx), str(my)
            elif pos == "bottom_left":
                x, y = str(mx), f"main_h-overlay_h-{my}"
            elif pos == "bottom_right":
                x, y = f"main_w-overlay_w-{mx}", f"main_h-overlay_h-{my}"
            else:
                x, y = f"main_w-overlay_w-{mx}", str(my)
            filters.append(
                f"[{logo_idx}:v]"
                f"fps={fps},"
                f"scale={logo_w}:-1:flags=lanczos,"
                f"format=rgba,setpts=N/FRAME_RATE/TB"
                f"[ulogo]"
            )

        filters.append(f"{vcur}[ulogo]overlay={x}:{y}:format=auto:eof_action=repeat:shortest=0:repeatlast=1[vlogo]")
        vcur = "[vlogo]"
        _log(
            f"logo enabled: width={logo_w} natural={natural_w}x{natural_h} "
            f"pos={pos} margin={mx},{my} top_layer=1 persistent=1 full_canvas={int(full_canvas_logo)}"
        )

    # v55.24: фотки СОВЫ/СВОИ ФОТКИ — после лого, поверх него.
    # Таймкод берём из имени файла: MM-SS или H-MM-SS.
    if overlay_photos:
        photo_duration = float(manifest.get("photo_duration") or 5.0)
        fade_duration = float(manifest.get("photo_fade_duration") or 1.0)
        max_photos = int(float(manifest.get("max_overlay_photos") or 120))
        for pi, photo in enumerate(overlay_photos[:max_photos]):
            tc = _parse_photo_timecode(photo)
            if tc is None:
                tc = 0.0
            cmd += ["-loop", "1", "-t", f"{photo_duration:.3f}", "-i", str(photo)]
            pidx = input_index
            input_index += 1
            pscaled = f"[uphoto{pi}]"
            pout = f"[vphoto{pi}]"
            fade_out_start = max(0.0, photo_duration - fade_duration)
            filters.append(
                f"[{pidx}:v]"
                f"fps={fps},"
                f"scale=1600:900:force_original_aspect_ratio=decrease:force_divisible_by=2:flags=lanczos,"
                f"pad=1600:900:(ow-iw)/2:(oh-ih)/2:color=black@0,"
                f"format=yuva420p,colorchannelmixer=aa=1,"
                f"fade=t=in:st=0:d={fade_duration:.3f}:alpha=1,"
                f"fade=t=out:st={fade_out_start:.3f}:d={fade_duration:.3f}:alpha=1,"
                f"setpts=PTS+{tc:.3f}/TB"
                f"{pscaled}"
            )
            filters.append(
                f"{vcur}{pscaled}overlay=(W-w)/2:(H-h)/2:alpha=1:"
                f"enable='between(t,{tc:.3f},{tc + photo_duration:.3f})'{pout}"
            )
            vcur = pout
        _log(f"photos enabled: {len(overlay_photos[:max_photos])}")

    mix_labels = []
    if use_original_audio:
        ov = str(manifest.get("original_volume") or music_preset.get("original_volume") or "1.0")
        filters.append(f"[0:a]volume={ov}[aorig]")
        mix_labels.append("[aorig]")
    for i, (idx, vol, _kind) in enumerate(audio_inputs, start=1):
        label = f"[ain{i}]"
        filters.append(f"[{idx}:a]volume={vol}{label}")
        mix_labels.append(label)

    if mix_labels:
        if len(mix_labels) == 1:
            filters.append(f"{mix_labels[0]}anull[afinal]")
        else:
            filters.append("".join(mix_labels) + f"amix=inputs={len(mix_labels)}:duration=first:dropout_transition=2[afinal]")
        map_audio = ["-map", "[afinal]"]
    else:
        map_audio = ["-map", "0:a?"]

    filter_args = []
    map_video = ["-map", vcur if filters and vcur != "[0:v]" else "0:v"]
    if filters:
        filter_args = ["-filter_complex", ";".join(filters)]

    if encoder_type == "nvidia":
        vcodec = ["-c:v", "h264_nvenc", "-preset", "p4", "-b:v", bitrate]
    elif encoder_type == "amd":
        vcodec = ["-c:v", "h264_amf", "-quality", "quality", "-b:v", bitrate]
    else:
        vcodec = ["-c:v", codec or "libx264", "-preset", "slow", "-crf", "18"]

    can_copy_video = not filters
    if can_copy_video:
        vcodec = ["-c:v", "copy"]

    meta_args = [] if metadata_mode == "Оставлять" else ["-map_metadata", "-1", "-map_chapters", "-1"]
    duration_args = []
    if use_source_audio:
        dur = _probe_duration(ffprobe, source_audio)
        if dur > 0:
            duration_args = ["-t", f"{dur + float(manifest.get('tail_seconds', 0) or 0):.3f}"]

    layer_output = tmp_dir / "base_with_layers.mp4" if video_entries else Path(output_path)
    final_cmd = cmd + filter_args + map_video + map_audio + meta_args + vcodec + ["-c:a", "aac", "-b:a", "192k", "-r", str(fps), "-movflags", "+faststart"]
    final_cmd += duration_args or ["-shortest"]
    final_cmd.append(str(layer_output))

    _log(f"final render: video_filters={bool(filters)} audio_inputs={len(audio_inputs)} original_audio={use_original_audio} output={layer_output}")
    try:
        _log("ffmpeg final cmd: " + " ".join(final_cmd))
    except Exception:
        pass
    proc = subprocess.Popen(final_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, **SUBPROCESS_FLAGS)
    tail = []
    assert proc.stdout is not None
    for line in proc.stdout:
        line = line.rstrip()
        if line:
            tail.append(line)
            if len(tail) > 20:
                tail.pop(0)
            if "time=" in line or "frame=" in line:
                print(line, flush=True)
    rc = proc.wait()
    if rc != 0:
        try:
            shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass
        _log("ffmpeg failed:\n" + "\n".join(tail))
        return False
    try:
        if video_entries:
            _apply_video_inserts(ffmpeg, ffprobe, Path(layer_output), Path(output_path), manifest, tmp_dir, int(fps))
    except Exception as exc:
        try:
            shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass
        _log(f"video inserts failed: {exc}")
        return False
    try:
        shutil.rmtree(tmp_dir, ignore_errors=True)
    except Exception:
        pass
    _log(f"done: {output_path}")
    return True


def run_bridge_if_requested(
    manifest_path: Optional[str],
    temp_video: str,
    output_path: str,
    narration_audio: Optional[str],
    *,
    bitrate: str = "10M",
    fps: int = 60,
    encoder_type: str = "cpu",
    codec: str = "libx264",
) -> bool:
    manifest_path = manifest_path or os.environ.get("USATAYAI_BRIDGE_MANIFEST")
    if not manifest_path:
        return False
    _log(f"manifest active: {manifest_path}")
    ok = render_final(temp_video, output_path, narration_audio, manifest_path, bitrate=bitrate, fps=fps, encoder_type=encoder_type, codec=codec)
    if not ok:
        raise RuntimeError("USATAYAI bridge final render failed")
    return True


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--temp-video", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--audio", default=None)
    ap.add_argument("--bitrate", default="10M")
    ap.add_argument("--fps", type=int, default=60)
    ap.add_argument("--encoder-type", default="cpu")
    ap.add_argument("--codec", default="libx264")
    ns = ap.parse_args()
    sys.exit(0 if render_final(ns.temp_video, ns.output, ns.audio, ns.manifest, bitrate=ns.bitrate, fps=ns.fps, encoder_type=ns.encoder_type, codec=ns.codec) else 1)
