﻿#!/usr/bin/env python3
"""
Р“Р РЈРџРџРћР’РђРЇ РЎРљР›Р•Р™РљРђ - v6 OVERLAP GUARD
вЂў Р’Р°Р»РёРґР°С†РёСЏ РјРѕРЅС‚Р°Р¶РЅРѕРіРѕ РїР»Р°РЅР°
вЂў РЎРѕСЂС‚РёСЂРѕРІРєР° РєР»РёРїРѕРІ РїРѕ startTime (Р·Р°С‰РёС‚Р° РѕС‚ JSON-РїРѕСЂСЏРґРєР° РѕС‚ Gemini)
вЂў РђРЅР°Р»РёР· Рё Р·Р°РїРѕР»РЅРµРЅРёРµ РІСЃРµС… РіСЌРїРѕРІ
вЂў РћР±РЅР°СЂСѓР¶РµРЅРёРµ Рё РєРѕСЂСЂРµРєС†РёСЏ РїРµСЂРµРєСЂС‹С‚РёР№ (РІРЅР°С…Р»С‘СЃС‚)
вЂў РџСЂРѕРІРµСЂРєР° СЃСѓС‰РµСЃС‚РІСѓСЋС‰РёС… С„Р°Р№Р»РѕРІ
вЂў Р“СЂСѓРїРїРѕРІР°СЏ СЃРєР»РµР№РєР° Р±РµР· РїРµСЂРµРєРѕРґРёСЂРѕРІР°РЅРёСЏ
вЂў РђРІС‚РѕРёСЃРїСЂР°РІР»РµРЅРёРµ С„РёРЅР°Р»СЊРЅРѕР№ СЃРёРЅС…СЂРѕРЅРёР·Р°С†РёРё (Р±С‹СЃС‚СЂРѕРµ РѕР±СЂРµР·Р°РЅРёРµ)
вЂў GPU СѓСЃРєРѕСЂРµРЅРёРµ
вЂў Р›РѕРіРіРёСЂРѕРІР°РЅРёРµ РІСЃРµС… РѕРїРµСЂР°С†РёР№
вЂў Р—Р°РїСЂРѕСЃ РїРµСЂРµРґ СѓРґР°Р»РµРЅРёРµРј temp РїР°РїРєРё
"""

import subprocess
import json
import sys
import os
import glob as _glob
import argparse
from pathlib import Path
from tqdm import tqdm
import platform
import time
import shutil
import logging
from datetime import datetime
import traceback

IS_PIPE = not sys.stdout.isatty()  # True РєРѕРіРґР° Р·Р°РїСѓС‰РµРЅ РєР°Рє subprocess (pipeline mode)

if platform.system() == 'Windows':
    SUBPROCESS_FLAGS = {'creationflags': 0x08000000}
    # РџСЂРёРЅСѓРґРёС‚РµР»СЊРЅРѕ UTF-8 РґР»СЏ stdout/stderr вЂ” РёРЅР°С‡Рµ РЅР° Р°РЅРіР»РёР№СЃРєРёС… Windows (cp1252)
    # РљРёСЂРёР»Р»РёС†Р° РІ print() РІС‹Р·С‹РІР°РµС‚ UnicodeEncodeError
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
else:
    SUBPROCESS_FLAGS = {}

# ============================================================================
# FFMPEG RESOLVER вЂ” РёС‰РµС‚ ffmpeg/ffprobe РІ PATH Рё С‚РёРїРёС‡РЅС‹С… РјРµСЃС‚Р°С… СѓСЃС‚Р°РЅРѕРІРєРё
# (РЅР° СЃР»СѓС‡Р°Р№ РµСЃР»Рё PATH РЅРµ РѕР±РЅРѕРІРёР»СЃСЏ РїРѕСЃР»Рµ winget/choco install)
# ============================================================================
def _resolve_ff(name: str) -> str:
    found = shutil.which(name)
    if found:
        return found
    if platform.system() == 'Windows':
        exe = name + '.exe'
        # winget (Gyan.FFmpeg) вЂ” СЃР°РјС‹Р№ С‡Р°СЃС‚С‹Р№ СЃРїРѕСЃРѕР± СѓСЃС‚Р°РЅРѕРІРєРё
        wg = os.path.expandvars('%LOCALAPPDATA%\\Microsoft\\WinGet\\Packages')
        if os.path.isdir(wg):
            import glob as _g2
            for candidate in _g2.glob(
                    os.path.join(wg, 'Gyan.FFmpeg_*', '**', exe), recursive=True):
                if os.path.isfile(candidate):
                    return candidate
        # Chocolatey
        choco = os.path.join(os.environ.get('ProgramData', 'C:\\ProgramData'),
                             'chocolatey', 'lib', 'ffmpeg', 'tools', 'ffmpeg', 'bin', exe)
        if os.path.isfile(choco):
            return choco
        # Р СѓС‡РЅР°СЏ СѓСЃС‚Р°РЅРѕРІРєР°
        for d in [r'C:\ffmpeg\bin', r'C:\Program Files\ffmpeg\bin',
                  r'C:\Program Files (x86)\ffmpeg\bin']:
            p = os.path.join(d, exe)
            if os.path.isfile(p):
                return p
    return name  # РЅР°РґРµРµРјСЃСЏ С‡С‚Рѕ PATH СѓР¶Рµ СЃРѕРґРµСЂР¶РёС‚ Р±РёРЅР°СЂРЅРёРє

FFMPEG  = _resolve_ff('ffmpeg')
FFPROBE = _resolve_ff('ffprobe')

# РљР»РёРїС‹ СЃ target_duration <= СЌС‚РѕРіРѕ РїРѕСЂРѕРіР° РѕР±СЂРµР·Р°СЋС‚СЃСЏ (trim) РІРјРµСЃС‚Рѕ СѓСЃРєРѕСЂРµРЅРёСЏ С‡РµСЂРµР· setpts.
# РЈСЃРєРѕСЂРµРЅРёРµ РєРѕСЂРѕС‚РєРёС… РєР»РёРїРѕРІ РґРѕ 2x Рё РІС‹С€Рµ РґР°С‘С‚ РЅРµРµСЃС‚РµСЃС‚РІРµРЅРЅРѕРµ РІРёРґРµРѕ; РѕР±СЂРµР·РєР° РІС‹РіР»СЏРґРёС‚ Р»СѓС‡С€Рµ.
TRIM_MAX_DURATION = 5.9

# ============================================================================
# ============================================================================
# SUBTITLE HELPERS
# ============================================================================

def _srt_to_ass(srt_path: str, template_path: str, output_path: str):
    """РљРѕРЅРІРµСЂС‚РёСЂСѓРµС‚ SRT РІ ASS, РїСЂРёРјРµРЅСЏСЏ СЃС‚РёР»Рё РёР· ASS-С€Р°Р±Р»РѕРЅР°."""
    import re as _re

    # Р§РёС‚Р°РµРј С€Р°Р±Р»РѕРЅ вЂ” Р±РµСЂС‘Рј РІСЃС‘ РґРѕ [Events]
    tpl = open(template_path, encoding='utf-8-sig').read()
    if '[Events]' in tpl:
        header = tpl[:tpl.index('[Events]')]
    else:
        header = tpl.rstrip() + '\n'

    # РџР°СЂСЃРёРј SRT
    srt_text = open(srt_path, encoding='utf-8-sig').read()
    blocks = [b.strip() for b in _re.split(r'\n{2,}', srt_text) if b.strip()]

    def _tc(s):
        # 00:00:01,500 в†’ 0:00:01.50
        h, m, rest = s.split(':')
        sec, ms = _re.split(r'[,.]', rest)
        return f"{int(h)}:{m}:{sec}.{ms[:2]}"

    events = ['[Events]',
              'Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text']
    for b in blocks:
        lines = b.splitlines()
        tc_line = next((l for l in lines if '-->' in l), None)
        if not tc_line:
            continue
        ti = lines.index(tc_line)
        t0, t1 = [s.strip() for s in tc_line.split('-->')]
        text = ' '.join(lines[ti + 1:]).strip()
        if not text:
            continue
        events.append(f"Dialogue: 0,{_tc(t0)},{_tc(t1)},Default,,0,0,0,,{text}")

    open(output_path, 'w', encoding='utf-8-sig').write(
        header + '\n'.join(events) + '\n')


# ============================================================================
# РќРђРЎРўР РћР™РљРђ Р›РћР“Р“РР РћР’РђРќРРЇ
# ============================================================================

def setup_logging():
    """РќР°СЃС‚СЂР°РёРІР°РµС‚ Р»РѕРіРіРёСЂРѕРІР°РЅРёРµ РІ С„Р°Р№Р» Рё РєРѕРЅСЃРѕР»СЊ"""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = f'video_concat_{timestamp}.log'

    logger = logging.getLogger('VideoConcat')
    logger.setLevel(logging.DEBUG)

    formatter = logging.Formatter(
        '%(asctime)s | %(levelname)-8s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.WARNING)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    logger.info("="*80)
    logger.info("РќРђР§РђР›Рћ Р РђР‘РћРўР« РЎРљР РРџРўРђ")
    logger.info("="*80)

    return logger, log_file

# Р“Р»РѕР±Р°Р»СЊРЅС‹Р№ Р»РѕРіРіРµСЂ
logger = None

# ============================================================================
# Р’РЎРџРћРњРћР“РђРўР•Р›Р¬РќР«Р• Р¤РЈРќРљР¦РР
# ============================================================================

def get_audio_duration(audio_path):
    """РџРѕР»СѓС‡Р°РµС‚ РґР»РёС‚РµР»СЊРЅРѕСЃС‚СЊ Р°СѓРґРёРѕС„Р°Р№Р»Р° РІ СЃРµРєСѓРЅРґР°С…"""
    try:
        logger.debug(f"РџРѕР»СѓС‡РµРЅРёРµ РґР»РёС‚РµР»СЊРЅРѕСЃС‚Рё Р°СѓРґРёРѕ: {audio_path}")
        result = subprocess.run(
            [FFPROBE, '-v', 'error', '-show_entries', 'format=duration',
             '-of', 'default=noprint_wrappers=1:nokey=1', audio_path],
            capture_output=True, text=True, check=True, **SUBPROCESS_FLAGS
        )
        duration = float(result.stdout.strip())
        logger.info(f"Р”Р»РёС‚РµР»СЊРЅРѕСЃС‚СЊ Р°СѓРґРёРѕ: {duration:.2f} СЃРµРє")
        return duration
    except Exception as e:
        logger.error(f"РћС€РёР±РєР° РїСЂРё РїРѕР»СѓС‡РµРЅРёРё РґР»РёС‚РµР»СЊРЅРѕСЃС‚Рё Р°СѓРґРёРѕ: {e}")
        logger.error(traceback.format_exc())
        print(f"вќЊ РћС€РёР±РєР° РїСЂРё РїРѕР»СѓС‡РµРЅРёРё РґР»РёС‚РµР»СЊРЅРѕСЃС‚Рё Р°СѓРґРёРѕ: {e}")
        sys.exit(1)

def get_video_duration(video_path):
    """РџРѕР»СѓС‡Р°РµС‚ РґР»РёС‚РµР»СЊРЅРѕСЃС‚СЊ РІРёРґРµРѕС„Р°Р№Р»Р° РІ СЃРµРєСѓРЅРґР°С…"""
    try:
        result = subprocess.run(
            [FFPROBE, '-v', 'error', '-show_entries', 'format=duration',
             '-of', 'default=noprint_wrappers=1:nokey=1', str(video_path)],
            capture_output=True, text=True, check=True, **SUBPROCESS_FLAGS
        )
        duration = float(result.stdout.strip())
        logger.debug(f"Р”Р»РёС‚РµР»СЊРЅРѕСЃС‚СЊ РІРёРґРµРѕ {video_path}: {duration:.2f} СЃРµРє")
        return duration
    except Exception as e:
        logger.warning(f"РќРµ СѓРґР°Р»РѕСЃСЊ РїРѕР»СѓС‡РёС‚СЊ РґР»РёС‚РµР»СЊРЅРѕСЃС‚СЊ {video_path}: {e}")
        return 0

def get_file_size_mb(file_path):
    """РџРѕР»СѓС‡Р°РµС‚ СЂР°Р·РјРµСЂ С„Р°Р№Р»Р° РІ РњР‘"""
    try:
        size = os.path.getsize(file_path) / (1024 * 1024)
        return size
    except:
        return 0

def check_processed_file(file_path, min_size_kb=100):
    """РџСЂРѕРІРµСЂСЏРµС‚ С‡С‚Рѕ РѕР±СЂР°Р±РѕС‚Р°РЅРЅС‹Р№ С„Р°Р№Р» СЃСѓС‰РµСЃС‚РІСѓРµС‚ Рё РЅРµ Р±РёС‚С‹Р№"""
    if not os.path.exists(file_path):
        return False
    if os.path.getsize(file_path) < min_size_kb * 1024:
        logger.debug(f"Р¤Р°Р№Р» {file_path} СЃР»РёС€РєРѕРј РјР°Р»")
        return False
    try:
        duration = get_video_duration(file_path)
        return duration > 0
    except:
        return False

def get_video_resolution(file_path):
    """Р’РѕР·РІСЂР°С‰Р°РµС‚ (width, height) РІРёРґРµРѕ РёР»Рё (0, 0) РїСЂРё РѕС€РёР±РєРµ."""
    try:
        result = subprocess.run(
            [FFPROBE, '-v', 'error', '-select_streams', 'v:0',
             '-show_entries', 'stream=width,height',
             '-of', 'csv=p=0', str(file_path)],
            capture_output=True, text=True, **SUBPROCESS_FLAGS
        )
        parts = result.stdout.strip().split(',')
        if len(parts) >= 2:
            return int(parts[0]), int(parts[1])
    except Exception:
        pass
    return 0, 0

def has_audio_stream(file_path):
    """Returns True if the media has at least one audio stream."""
    try:
        result = subprocess.run(
            [FFPROBE, '-v', 'error', '-select_streams', 'a:0',
             '-show_entries', 'stream=index',
             '-of', 'csv=p=0', str(file_path)],
            capture_output=True, text=True, **SUBPROCESS_FLAGS
        )
        return bool(result.stdout.strip())
    except Exception:
        return False

def validate_montage_plan(clips, audio_path):
    """Р’Р°Р»РёРґР°С†РёСЏ РјРѕРЅС‚Р°Р¶РЅРѕРіРѕ РїР»Р°РЅР°"""
    logger.info("Р­РўРђРџ 1: Р’РђР›РР”РђР¦РРЇ РњРћРќРўРђР–РќРћР“Рћ РџР›РђРќРђ")

    print("\n" + "="*80)
    print("рџ“‹ Р’РђР›РР”РђР¦РРЇ РњРћРќРўРђР–РќРћР“Рћ РџР›РђРќРђ")
    print("="*80)

    if not clips:
        logger.error("РћС€РёР±РєР°: РЅРµС‚ clips РІ РїР»Р°РЅРµ!")
        print("вќЊ РћС€РёР±РєР°: РЅРµС‚ clips РІ РїР»Р°РЅРµ!")
        sys.exit(1)

    if audio_path is None:
        # VEO audio inline mode without narration вЂ” derive timeline from clips
        actual_audio_duration = clips[-1]['endTime']
        logger.info(f"veo-audio-inline Р±РµР· РЅР°СЂР°С†РёРё: РґР»РёС‚РµР»СЊРЅРѕСЃС‚СЊ РёР· РєР»РёРїРѕРІ {actual_audio_duration:.2f}СЃ")
        print(f"\n[INFO] РќР°СЂР°С†РёСЏ РЅРµ Р·Р°РґР°РЅР° (veo-audio-inline СЂРµР¶РёРј). Р”Р»РёС‚РµР»СЊРЅРѕСЃС‚СЊ РёР· РјРѕРЅС‚Р°Р¶РЅРѕРіРѕ РїР»Р°РЅР°: {actual_audio_duration:.2f}СЃ")
    else:
        actual_audio_duration = get_audio_duration(audio_path)
        if actual_audio_duration is None:
            logger.error(f"РќРµ СѓРґР°Р»РѕСЃСЊ РїРѕР»СѓС‡РёС‚СЊ РґР»РёС‚РµР»СЊРЅРѕСЃС‚СЊ Р°СѓРґРёРѕ: {audio_path}")
            print(f"вќЊ РќРµ СѓРґР°Р»РѕСЃСЊ РїРѕР»СѓС‡РёС‚СЊ РґР»РёС‚РµР»СЊРЅРѕСЃС‚СЊ Р°СѓРґРёРѕ: {audio_path}")
            sys.exit(1)
    logger.info(f"РљРѕР»РёС‡РµСЃС‚РІРѕ clips РІ РїР»Р°РЅРµ: {len(clips)}")

    print(f"\nрџ“Љ Р”Р»РёС‚РµР»СЊРЅРѕСЃС‚СЊ Р°СѓРґРёРѕ: {actual_audio_duration:.2f} СЃРµРє")
    print(f"рџ“Љ РљРѕР»РёС‡РµСЃС‚РІРѕ clips: {len(clips)}")

    first_start = clips[0]['startTime']
    last_end = clips[-1]['endTime']

    logger.info(f"РџРµСЂРІС‹Р№ clip РЅР°С‡РёРЅР°РµС‚СЃСЏ: {first_start:.2f} СЃРµРє")
    logger.info(f"РџРѕСЃР»РµРґРЅРёР№ clip Р·Р°РєР°РЅС‡РёРІР°РµС‚СЃСЏ: {last_end:.2f} СЃРµРє")

    print(f"\nрџ“Љ РџРѕРєСЂС‹С‚РёРµ РїР»Р°РЅР°:")
    print(f"   вЂў РџРµСЂРІС‹Р№ clip: {first_start:.2f} СЃРµРє")
    print(f"   вЂў РџРѕСЃР»РµРґРЅРёР№ clip: {last_end:.2f} СЃРµРє")
    print(f"   вЂў РђСѓРґРёРѕ: 0.00 - {actual_audio_duration:.2f} СЃРµРє")

    if first_start > 0.1:
        logger.warning(f"Р“СЌРї РІ РЅР°С‡Р°Р»Рµ: {first_start:.2f} СЃРµРє")
        print(f"\nвљ пёЏ  Р’РќРРњРђРќРР•: РџРµСЂРІС‹Р№ clip РЅР°С‡РёРЅР°РµС‚СЃСЏ СЃ {first_start:.2f}СЃ (Р±СѓРґРµС‚ РёСЃРїСЂР°РІР»РµРЅРѕ)")

    if abs(last_end - actual_audio_duration) > 0.1:
        if last_end < actual_audio_duration:
            logger.warning(f"Р“СЌРї РІ РєРѕРЅС†Рµ: {actual_audio_duration - last_end:.2f} СЃРµРє")
            print(f"вљ пёЏ  Р’РќРРњРђРќРР•: РџРѕСЃР»РµРґРЅРёР№ clip {last_end:.2f}СЃ < Р°СѓРґРёРѕ {actual_audio_duration:.2f}СЃ (Р±СѓРґРµС‚ РёСЃРїСЂР°РІР»РµРЅРѕ)")
        else:
            logger.warning(f"РџРѕСЃР»РµРґРЅРёР№ clip РґР»РёРЅРЅРµРµ Р°СѓРґРёРѕ РЅР° {last_end - actual_audio_duration:.2f} СЃРµРє")
            print(f"вљ пёЏ  Р’РќРРњРђРќРР•: РџРѕСЃР»РµРґРЅРёР№ clip {last_end:.2f}СЃ > Р°СѓРґРёРѕ {actual_audio_duration:.2f}СЃ")

    print(f"\nвњ… Р’Р°Р»РёРґР°С†РёСЏ Р·Р°РІРµСЂС€РµРЅР°")
    print("="*80)
    logger.info("Р’Р°Р»РёРґР°С†РёСЏ РїР»Р°РЅР° Р·Р°РІРµСЂС€РµРЅР° СѓСЃРїРµС€РЅРѕ")

    return actual_audio_duration

def analyze_gaps(clips, audio_duration):
    """РђРЅР°Р»РёР·РёСЂСѓРµС‚ РІСЃРµ РіСЌРїС‹ Рё РїРµСЂРµРєСЂС‹С‚РёСЏ: РІ РЅР°С‡Р°Р»Рµ, РІРЅСѓС‚СЂРё, РІ РєРѕРЅС†Рµ"""
    logger.info("Р­РўРђРџ 2: РђРќРђР›РР— Р“Р­РџРћР’ Р РџР•Р Р•РљР Р«РўРР™")

    print("\n" + "="*80)
    print("рџ”Ќ РђРќРђР›РР— Р“Р­РџРћР’ Р РџР•Р Р•РљР Р«РўРР™")
    print("="*80)

    gaps_info = []
    corrections = []

    # 1. РџСЂРѕРІРµСЂРєР° РЅР°С‡Р°Р»СЊРЅРѕРіРѕ РіСЌРїР°
    first_start = clips[0]['startTime']
    if first_start > 0.01:
        gap = first_start
        logger.info(f"Р“Р­Рџ Р’ РќРђР§РђР›Р•: {gap:.2f} СЃРµРє")
        gaps_info.append(f"вљ пёЏ  Р“Р­Рџ Р’ РќРђР§РђР›Р•: {gap:.2f} СЃРµРє (РґРѕ РїРµСЂРІРѕРіРѕ clip)")
        corrections.append({
            'type': 'start_gap',
            'clip_index': 0,
            'original_start': first_start,
            'new_start': 0.0,
            'gap_size': gap
        })

    # 2. РџСЂРѕРІРµСЂРєР° РІРЅСѓС‚СЂРµРЅРЅРёС… РіСЌРїРѕРІ Рё РїРµСЂРµРєСЂС‹С‚РёР№
    for i in range(len(clips) - 1):
        end_current = clips[i]['endTime']
        start_next = clips[i+1]['startTime']
        diff = start_next - end_current

        if diff > 0.01:
            # Р“СЌРї вЂ” СЂР°СЃС‚СЏРіРёРІР°РµРј РїСЂРµРґС‹РґСѓС‰РёР№ РєР»РёРї
            gap = diff
            logger.info(f"Р’РќРЈРўР Р•РќРќРР™ Р“Р­Рџ #{i+1}: {gap:.2f} СЃРµРє РјРµР¶РґСѓ clip {clips[i]['id']} Рё {clips[i+1]['id']}")
            gaps_info.append(f"вљ пёЏ  Р“Р­Рџ #{i+1}: {gap:.2f} СЃРµРє РјРµР¶РґСѓ clip {clips[i]['id']} Рё {clips[i+1]['id']}")
            logger.info(f"  в†’ Р РµС€РµРЅРёРµ: Р Р•РўРђР™Рњ clip {clips[i]['id']} (+{gap:.2f} СЃРµРє)")
            corrections.append({
                'type': 'retime_extend',
                'clip_index': i,
                'gap_size': gap,
                'original_duration': end_current - clips[i]['startTime'],
                'new_duration': (end_current - clips[i]['startTime']) + gap
            })

        elif diff < -0.01:
            # РџРµСЂРµРєСЂС‹С‚РёРµ вЂ” РѕР±СЂРµР·Р°РµРј РїСЂРµРґС‹РґСѓС‰РёР№ РєР»РёРї
            overlap = -diff
            logger.warning(f"РџР•Р Р•РљР Р«РўРР• #{i+1}: {overlap:.2f} СЃРµРє РјРµР¶РґСѓ clip {clips[i]['id']} Рё {clips[i+1]['id']}")
            gaps_info.append(f"рџ”ґ РџР•Р Р•РљР Р«РўРР• #{i+1}: {overlap:.2f} СЃРµРє РјРµР¶РґСѓ clip {clips[i]['id']} Рё {clips[i+1]['id']}")
            logger.info(f"  в†’ Р РµС€РµРЅРёРµ: РћР‘Р Р•Р—РљРђ clip {clips[i]['id']} endTime {end_current:.2f} в†’ {start_next:.2f}")
            corrections.append({
                'type': 'trim_overlap',
                'clip_index': i,
                'overlap_size': overlap,
                'original_end': end_current,
                'new_end': start_next
            })

    # 3. РџСЂРѕРІРµСЂРєР° РєРѕРЅРµС‡РЅРѕРіРѕ РіСЌРїР°
    last_end = clips[-1]['endTime']
    if last_end < audio_duration - 0.01:
        gap = audio_duration - last_end
        logger.info(f"Р“Р­Рџ Р’ РљРћРќР¦Р•: {gap:.2f} СЃРµРє")
        gaps_info.append(f"вљ пёЏ  Р“Р­Рџ Р’ РљРћРќР¦Р•: {gap:.2f} СЃРµРє (РїРѕСЃР»Рµ РїРѕСЃР»РµРґРЅРµРіРѕ clip)")
        corrections.append({
            'type': 'end_gap',
            'clip_index': len(clips) - 1,
            'original_end': last_end,
            'new_end': audio_duration,
            'gap_size': gap
        })

    # Р’С‹РІРѕРґ СЂРµР·СѓР»СЊС‚Р°С‚РѕРІ
    if gaps_info:
        overlaps_count = sum(1 for c in corrections if c['type'] == 'trim_overlap')
        gaps_count = len(gaps_info) - overlaps_count
        logger.info(f"РќР°Р№РґРµРЅРѕ: РіСЌРїРѕРІ={gaps_count}, РїРµСЂРµРєСЂС‹С‚РёР№={overlaps_count}")
        print(f"\nрџ“Љ РќР°Р№РґРµРЅРѕ: РіСЌРїРѕРІ={gaps_count}, РїРµСЂРµРєСЂС‹С‚РёР№={overlaps_count}")
        for info in gaps_info:
            print(f"   {info}")

        print(f"\nрџ”§ РџР»Р°РЅ РєРѕСЂСЂРµРєС‚РёСЂРѕРІРѕРє:")
        for corr in corrections:
            if corr['type'] == 'start_gap':
                print(f"   вЂў Clip {clips[corr['clip_index']]['id']}: Р Р•РўРђР™Рњ РЅР°С‡Р°Р»Р° СЃ {corr['original_start']:.2f}в†’0.00 (+{corr['gap_size']:.2f}СЃ)")
            elif corr['type'] == 'end_gap':
                print(f"   вЂў Clip {clips[corr['clip_index']]['id']}: Р Р•РўРђР™Рњ РєРѕРЅС†Р° СЃ {corr['original_end']:.2f}в†’{corr['new_end']:.2f} (+{corr['gap_size']:.2f}СЃ)")
            elif corr['type'] == 'retime_extend':
                print(f"   вЂў Clip {clips[corr['clip_index']]['id']}: Р Р•РўРђР™Рњ РґР»РёС‚РµР»СЊРЅРѕСЃС‚Рё {corr['original_duration']:.2f}в†’{corr['new_duration']:.2f}СЃ")
            elif corr['type'] == 'trim_overlap':
                print(f"   вЂў Clip {clips[corr['clip_index']]['id']}: РћР‘Р Р•Р—РљРђ {corr['original_end']:.2f}в†’{corr['new_end']:.2f} (-{corr['overlap_size']:.2f}СЃ)")
    else:
        logger.info("Р“СЌРїРѕРІ Рё РїРµСЂРµРєСЂС‹С‚РёР№ РЅРµ РѕР±РЅР°СЂСѓР¶РµРЅРѕ")
        print(f"\nвњ… Р“СЌРїРѕРІ Рё РїРµСЂРµРєСЂС‹С‚РёР№ РЅРµ РѕР±РЅР°СЂСѓР¶РµРЅРѕ! РџР»Р°РЅ РёРґРµР°Р»РµРЅ!")

    print("="*80)
    logger.info(f"РђРЅР°Р»РёР· Р·Р°РІРµСЂС€РµРЅ. РљРѕСЂСЂРµРєС‚РёСЂРѕРІРѕРє: {len(corrections)}")

    return corrections

def fix_video_audio_sync(video_path, audio_path, temp_dir, encoder_type, codec, bitrate):
    """РђР’РўРћРњРђРўРР§Р•РЎРљРћР• РРЎРџР РђР’Р›Р•РќРР• СЂР°СЃСЃРёРЅС…СЂРѕРЅРёР·Р°С†РёРё РІРёРґРµРѕ Рё Р°СѓРґРёРѕ"""
    logger.info("Р­РўРђРџ 6: РџР РћР’Р•Р РљРђ Р¤РРќРђР›Р¬РќРћР™ РЎРРќРҐР РћРќРР—РђР¦РР")
    print("\n" + "="*80)
    print("рџ”§ РџР РћР’Р•Р РљРђ Р¤РРќРђР›Р¬РќРћР™ РЎРРќРҐР РћРќРР—РђР¦РР")
    print("="*80)

    video_duration = get_video_duration(video_path)
    audio_duration = get_audio_duration(audio_path)

    logger.info(f"Р”Р»РёС‚РµР»СЊРЅРѕСЃС‚СЊ СЃРєР»РµРµРЅРЅРѕРіРѕ РІРёРґРµРѕ: {video_duration:.2f} СЃРµРє")
    logger.info(f"Р”Р»РёС‚РµР»СЊРЅРѕСЃС‚СЊ Р°СѓРґРёРѕ РѕР·РІСѓС‡РєРё: {audio_duration:.2f} СЃРµРє")

    print(f"\nрџ“Љ Р”Р»РёС‚РµР»СЊРЅРѕСЃС‚СЊ СЃРєР»РµРµРЅРЅРѕРіРѕ РІРёРґРµРѕ: {video_duration:.2f} СЃРµРє")
    print(f"рџ“Љ Р”Р»РёС‚РµР»СЊРЅРѕСЃС‚СЊ Р°СѓРґРёРѕ РѕР·РІСѓС‡РєРё: {audio_duration:.2f} СЃРµРє")

    diff = video_duration - audio_duration
    print(f"рџ“Љ Р Р°Р·РЅРёС†Р°: {diff:.2f} СЃРµРє")
    logger.info(f"Р Р°Р·РЅРёС†Р°: {diff:.2f} СЃРµРє")

    # РРґРµР°Р»СЊРЅР°СЏ СЃРёРЅС…СЂРѕРЅРёР·Р°С†РёСЏ
    if abs(diff) <= 0.1:
        logger.info("РЎРёРЅС…СЂРѕРЅРёР·Р°С†РёСЏ РёРґРµР°Р»СЊРЅР°")
        print(f"\nвњ… РћС‚Р»РёС‡РЅРѕ! РЎРёРЅС…СЂРѕРЅРёР·Р°С†РёСЏ РёРґРµР°Р»СЊРЅР° (СЂР°Р·РЅРёС†Р° {abs(diff):.2f} СЃРµРє)")
        print("="*80)
        return str(video_path)

    # Р”РѕРїСѓСЃС‚РёРјР°СЏ СЂР°СЃСЃРёРЅС…СЂРѕРЅРёР·Р°С†РёСЏ
    if abs(diff) <= 0.5:
        logger.info("РќРµР±РѕР»СЊС€Р°СЏ СЂР°СЃСЃРёРЅС…СЂРѕРЅРёР·Р°С†РёСЏ, РґРѕРїСѓСЃС‚РёРјР°")
        print(f"\nвњ… РҐРѕСЂРѕС€Рѕ! РќРµР±РѕР»СЊС€Р°СЏ СЂР°СЃСЃРёРЅС…СЂРѕРЅРёР·Р°С†РёСЏ ({abs(diff):.2f} СЃРµРє)")
        print("="*80)
        return str(video_path)

    # Р‘С‹СЃС‚СЂР°СЏ РѕР±СЂРµР·РєР°/РґРѕРїРѕР»РЅРµРЅРёРµ С…РІРѕСЃС‚Р° (0.5-2.5 СЃРµРє) Р‘Р•Р— РїРµСЂРµРєРѕРґРёСЂРѕРІР°РЅРёСЏ
    if abs(diff) <= 2.5:
        logger.info(f"Р‘С‹СЃС‚СЂР°СЏ РєРѕСЂСЂРµРєС†РёСЏ С…РІРѕСЃС‚Р°: {abs(diff):.2f} СЃРµРє (trim Р±РµР· РїРµСЂРµРєРѕРґРёСЂРѕРІР°РЅРёСЏ)")
        print(f"\nрџ”§ РћР±РЅР°СЂСѓР¶РµРЅР° СЂР°СЃСЃРёРЅС…СЂРѕРЅРёР·Р°С†РёСЏ: {abs(diff):.2f} СЃРµРє")
        print(f"   РџСЂРёРјРµРЅСЏСЋ Р±С‹СЃС‚СЂСѓСЋ РѕР±СЂРµР·РєСѓ/РґРѕРїРѕР»РЅРµРЅРёРµ (Р‘Р•Р— РїРµСЂРµРєРѕРґРёСЂРѕРІР°РЅРёСЏ)...")

        fixed_video = temp_dir / 'concat_video_fixed.mp4'

        if diff > 0:
            # Р’РёРґРµРѕ РґР»РёРЅРЅРµРµ - РѕР±СЂРµР·Р°РµРј С…РІРѕСЃС‚
            logger.info(f"РћР±СЂРµР·Р°РµРј {diff:.2f} СЃРµРє СЃ С…РІРѕСЃС‚Р° (trim)")
            print(f"   Р’РёРґРµРѕ РґР»РёРЅРЅРµРµ Р°СѓРґРёРѕ РЅР° {diff:.2f} СЃРµРє")
            print(f"   РћР±СЂРµР·Р°РµРј С…РІРѕСЃС‚ С‡РµСЂРµР· trim...")
            cmd = [
                FFMPEG, '-y',
                '-i', str(video_path),
                '-t', str(audio_duration),
                '-c', 'copy',
                str(fixed_video)
            ]
        else:
            # Р’РёРґРµРѕ РєРѕСЂРѕС‡Рµ - РѕР±СЂРµР·Р°РµРј РїРѕ Р°СѓРґРёРѕ
            logger.info(f"Р’РёРґРµРѕ РєРѕСЂРѕС‡Рµ РЅР° {abs(diff):.2f} СЃРµРє - РѕР±СЂРµР·Р°РµРј РїРѕ Р°СѓРґРёРѕ (РєРѕРїРёСЏ)")
            print(f"   Р’РёРґРµРѕ РєРѕСЂРѕС‡Рµ Р°СѓРґРёРѕ РЅР° {abs(diff):.2f} СЃРµРє")
            print(f"   РћР±СЂРµР·Р°РµРј РїРѕ РґР»РёС‚РµР»СЊРЅРѕСЃС‚Рё Р°СѓРґРёРѕ (РєРѕРїРёСЏ)...")
            cmd = [
                FFMPEG, '-y',
                '-i', str(video_path),
                '-t', str(audio_duration),
                '-c', 'copy',
                str(fixed_video)
            ]

        logger.debug(f"FFmpeg РєРѕРјР°РЅРґР°: {' '.join(cmd)}")

        trim_success = False
        try:
            run_ffmpeg_with_spinner(cmd, "РћР±СЂРµР·РєР° С…РІРѕСЃС‚Р°")
            logger.info("Р‘С‹СЃС‚СЂР°СЏ РєРѕСЂСЂРµРєС†РёСЏ С…РІРѕСЃС‚Р° РІС‹РїРѕР»РЅРµРЅР° СѓСЃРїРµС€РЅРѕ")
            trim_success = True
        except subprocess.CalledProcessError as e:
            logger.error(f"РћС€РёР±РєР° РєРѕСЂСЂРµРєС†РёРё С…РІРѕСЃС‚Р°: {e}")
            logger.error(traceback.format_exc())
            print(f"   вљ пёЏ  Trim РЅРµ СЃСЂР°Р±РѕС‚Р°Р», РїРµСЂРµС…РѕР¶Сѓ РЅР° setpts...")

        if trim_success:
            fixed_duration = get_video_duration(fixed_video)
            final_diff = abs(fixed_duration - audio_duration)
            logger.info(f"РќРѕРІР°СЏ РґР»РёС‚РµР»СЊРЅРѕСЃС‚СЊ РІРёРґРµРѕ: {fixed_duration:.2f} СЃРµРє, СЂР°Р·РЅРёС†Р°: {final_diff:.2f} СЃРµРє")

            print(f"\nвњ… РСЃРїСЂР°РІР»РµРЅРёРµ Р·Р°РІРµСЂС€РµРЅРѕ!")
            print(f"   РќРѕРІР°СЏ РґР»РёС‚РµР»СЊРЅРѕСЃС‚СЊ РІРёРґРµРѕ: {fixed_duration:.2f} СЃРµРє")
            print(f"   Р Р°Р·РЅРёС†Р° СЃ Р°СѓРґРёРѕ: {final_diff:.2f} СЃРµРє")
            print("="*80)

            return str(fixed_video)
        # Р•СЃР»Рё trim РЅРµ СѓРґР°Р»СЃСЏ - РєРѕРґ РїСЂРѕРґРѕР»Р¶РёС‚ РІС‹РїРѕР»РЅРµРЅРёРµ Рё РїРµСЂРµР№РґС‘С‚ Рє setpts РЅРёР¶Рµ

    # Р Р°Р·РЅРёС†Р° > 2 СЃРµРє (РёР»Рё trim РЅРµ СЃСЂР°Р±РѕС‚Р°Р») - СЂР°РІРЅРѕРјРµСЂРЅР°СЏ РєРѕСЂСЂРµРєС†РёСЏ С‡РµСЂРµР· setpts (РїРµСЂРµРєРѕРґРёСЂРѕРІР°РЅРёРµ).
    # setpts СЂР°РІРЅРѕРјРµСЂРЅРѕ СЃР¶РёРјР°РµС‚/СЂР°СЃС‚СЏРіРёРІР°РµС‚ РІРµСЃСЊ РІРёРґРµРѕСЂСЏРґ - СЃРёРЅС…СЂРѕРЅ РёРґРµР°Р»РµРЅ РІ РєР°Р¶РґРѕР№ С‚РѕС‡РєРµ.

    logger.warning(f"Р Р°СЃСЃРёРЅС…СЂРѕРЅРёР·Р°С†РёСЏ {abs(diff):.2f} СЃРµРє - РїСЂРёРјРµРЅСЏСЋ setpts СѓСЃРєРѕСЂРµРЅРёРµ/Р·Р°РјРµРґР»РµРЅРёРµ")
    print(f"\nрџ”§ РћР±РЅР°СЂСѓР¶РµРЅР° СЂР°СЃСЃРёРЅС…СЂРѕРЅРёР·Р°С†РёСЏ: {abs(diff):.2f} СЃРµРє")
    print(f"   РџСЂРёРјРµРЅСЏСЋ СѓСЃРєРѕСЂРµРЅРёРµ/Р·Р°РјРµРґР»РµРЅРёРµ (С‚СЂРµР±СѓРµС‚ РїРµСЂРµРєРѕРґРёСЂРѕРІР°РЅРёСЏ)...")

    fixed_video = temp_dir / 'concat_video_fixed.mp4'
    encoder_params = get_encoder_params(encoder_type, codec, bitrate)
    speed_factor = video_duration / audio_duration

    if diff < 0:
        logger.info(f"Р—Р°РјРµРґР»СЏРµРј РІРёРґРµРѕ: {speed_factor:.4f}x")
        print(f"   Р’РёРґРµРѕ РєРѕСЂРѕС‡Рµ Р°СѓРґРёРѕ РЅР° {abs(diff):.2f} СЃРµРє")
        print(f"   Р—Р°РјРµРґР»СЏРµРј РІРёРґРµРѕ: {speed_factor:.4f}x")
    else:
        logger.info(f"РЈСЃРєРѕСЂСЏРµРј РІРёРґРµРѕ: {speed_factor:.4f}x")
        print(f"   Р’РёРґРµРѕ РґР»РёРЅРЅРµРµ Р°СѓРґРёРѕ РЅР° {diff:.2f} СЃРµРє")
        print(f"   РЈСЃРєРѕСЂСЏРµРј РІРёРґРµРѕ: {speed_factor:.4f}x")

    # РќРµ РёСЃРїРѕР»СЊР·СѓРµРј -r 60: РѕРЅ С„РѕСЂСЃРёСЂСѓРµС‚ N РєР°РґСЂРѕРІ/СЃРµРє РЅРµР·Р°РІРёСЃРёРјРѕ РѕС‚ PTS,
    # С‡С‚Рѕ РЅРµР№С‚СЂР°Р»РёР·СѓРµС‚ СЃР¶Р°С‚РёРµ setpts Рё РѕСЃС‚Р°РІР»СЏРµС‚ С‚Сѓ Р¶Рµ РґР»РёРЅСѓ РІРёРґРµРѕ.
    cmd = [
        FFMPEG, '-y',
        '-i', str(video_path),
        '-filter:v', f'setpts={1/speed_factor}*PTS',
    ] + encoder_params + [
        '-c:a', 'copy',
        str(fixed_video)
    ]

    logger.debug(f"FFmpeg РєРѕРјР°РЅРґР°: {' '.join(cmd)}")
    print(f"   РћР±СЂР°Р±РѕС‚РєР° (СЌС‚Рѕ Р·Р°Р№РјС‘С‚ РІСЂРµРјСЏ)...")

    try:
        subprocess.run(cmd, check=True, capture_output=True, **SUBPROCESS_FLAGS)
        logger.info("РЈСЃРєРѕСЂРµРЅРёРµ/Р·Р°РјРµРґР»РµРЅРёРµ РІС‹РїРѕР»РЅРµРЅРѕ СѓСЃРїРµС€РЅРѕ")
    except subprocess.CalledProcessError as e:
        logger.error(f"РћС€РёР±РєР° СѓСЃРєРѕСЂРµРЅРёСЏ/Р·Р°РјРµРґР»РµРЅРёСЏ: {e}")
        logger.error(traceback.format_exc())
        raise

    fixed_duration = get_video_duration(fixed_video)
    final_diff = abs(fixed_duration - audio_duration)
    logger.info(f"РќРѕРІР°СЏ РґР»РёС‚РµР»СЊРЅРѕСЃС‚СЊ РІРёРґРµРѕ: {fixed_duration:.2f} СЃРµРє, СЂР°Р·РЅРёС†Р°: {final_diff:.2f} СЃРµРє")

    print(f"\nвњ… РСЃРїСЂР°РІР»РµРЅРёРµ Р·Р°РІРµСЂС€РµРЅРѕ!")
    print(f"   РќРѕРІР°СЏ РґР»РёС‚РµР»СЊРЅРѕСЃС‚СЊ РІРёРґРµРѕ: {fixed_duration:.2f} СЃРµРє")
    print(f"   Р Р°Р·РЅРёС†Р° СЃ Р°СѓРґРёРѕ: {final_diff:.2f} СЃРµРє")
    print("="*80)

    return str(fixed_video)


def _test_encoder(codec):
    """РџСЂРѕРІРµСЂСЏРµС‚, СЂР°Р±РѕС‚Р°РµС‚ Р»Рё СЌРЅРєРѕРґРµСЂ СЂРµР°Р»СЊРЅРѕ (РЅРµ РїСЂРѕСЃС‚Рѕ СЃРєРѕРјРїРёР»РёСЂРѕРІР°РЅ)"""
    try:
        test_cmd = [
            FFMPEG, '-hide_banner', '-loglevel', 'error',
            '-f', 'lavfi', '-i', 'nullsrc=s=256x256:d=0.1',
            '-pix_fmt', 'yuv420p',
            '-c:v', codec, '-frames:v', '1', '-f', 'null', '-'
        ]
        r = subprocess.run(test_cmd, capture_output=True, timeout=10, **SUBPROCESS_FLAGS)
        return r.returncode == 0
    except Exception:
        return False


def detect_gpu_encoder(force_amd=False):
    """РћРїСЂРµРґРµР»СЏРµС‚ РґРѕСЃС‚СѓРїРЅС‹Р№ GPU СЌРЅРєРѕРґРµСЂ (СЃ СЂРµР°Р»СЊРЅРѕР№ РїСЂРѕРІРµСЂРєРѕР№ СЂР°Р±РѕС‚РѕСЃРїРѕСЃРѕР±РЅРѕСЃС‚Рё)"""
    logger.debug("РћРїСЂРµРґРµР»РµРЅРёРµ РґРѕСЃС‚СѓРїРЅРѕРіРѕ GPU СЌРЅРєРѕРґРµСЂР°")
    try:
        result = subprocess.run([FFMPEG, '-hide_banner', '-encoders'],
                              capture_output=True, text=True, **SUBPROCESS_FLAGS)
        if 'h264_amf' in result.stdout:
            if _test_encoder('h264_amf'):
                logger.info("РћР±РЅР°СЂСѓР¶РµРЅ AMD GPU (h264_amf)")
                return 'amd', 'h264_amf'
            else:
                logger.warning("h264_amf РІ СЃРїРёСЃРєРµ, РЅРѕ AMD GPU РЅРµРґРѕСЃС‚СѓРїРµРЅ вЂ” РїСЂРѕРїСѓСЃРє")
        # force_amd = "РїРѕРїСЂРѕР±СѓР№ AMD РїРµСЂРІС‹Рј", РЅРѕ РµСЃР»Рё AMD РЅРµРґРѕСЃС‚СѓРїРµРЅ вЂ” РІСЃС‘ СЂР°РІРЅРѕ РїСЂРѕР±СѓРµРј NVIDIA
        if 'h264_nvenc' in result.stdout:
            if _test_encoder('h264_nvenc'):
                logger.info("РћР±РЅР°СЂСѓР¶РµРЅ NVIDIA GPU (h264_nvenc)")
                return 'nvidia', 'h264_nvenc'
            else:
                logger.warning("h264_nvenc РІ СЃРїРёСЃРєРµ, РЅРѕ NVIDIA GPU РЅРµРґРѕСЃС‚СѓРїРµРЅ вЂ” РїСЂРѕРїСѓСЃРє")
        logger.info("GPU РЅРµ РѕР±РЅР°СЂСѓР¶РµРЅ, РёСЃРїРѕР»СЊР·СѓРµС‚СЃСЏ CPU (libx264)")
        return 'cpu', 'libx264'
    except Exception as e:
        logger.warning(f"РћС€РёР±РєР° РѕРїСЂРµРґРµР»РµРЅРёСЏ GPU: {e}")
        return 'cpu', 'libx264'

def get_encoder_params(encoder_type, codec, bitrate='10M'):
    """Р’РѕР·РІСЂР°С‰Р°РµС‚ РїР°СЂР°РјРµС‚СЂС‹ РґР»СЏ РІС‹Р±СЂР°РЅРЅРѕРіРѕ СЌРЅРєРѕРґРµСЂР°"""
    if encoder_type == 'nvidia':
        return ['-c:v', codec, '-preset', 'p4', '-tune', 'hq', '-b:v', bitrate,
                '-maxrate', bitrate, '-bufsize', f'{int(bitrate[:-1])*2}M',
                '-profile:v', 'high', '-pix_fmt', 'yuv420p']
    elif encoder_type == 'amd':
        return ['-c:v', codec, '-quality', 'speed', '-b:v', bitrate,
                '-maxrate', bitrate, '-bufsize', f'{int(bitrate[:-1])*2}M',
                '-profile:v', 'high', '-pix_fmt', 'yuv420p']
    else:
        return ['-c:v', codec, '-preset', 'medium', '-b:v', bitrate,
                '-maxrate', bitrate, '-bufsize', f'{int(bitrate[:-1])*2}M',
                '-profile:v', 'high', '-pix_fmt', 'yuv420p']

def create_freeze_frame(source_video, output_video, duration, encoder_type, codec, bitrate, fps=60):
    """РЎРѕР·РґР°С‘С‚ freeze frame РёР· РїРѕСЃР»РµРґРЅРµРіРѕ РєР°РґСЂР° РёСЃС‚РѕС‡РЅРёРєР°"""
    logger.debug(f"РЎРѕР·РґР°РЅРёРµ freeze frame РёР· {source_video} РґР»РёС‚РµР»СЊРЅРѕСЃС‚СЊСЋ {duration:.2f} СЃРµРє")

    encoder_params = get_encoder_params(encoder_type, codec, bitrate)
    temp_frame = output_video.parent / f'temp_frame_{output_video.stem}.png'

    try:
        cmd_extract = [
            FFMPEG, '-y',
            '-sseof', '-1',
            '-i', str(source_video),
            '-update', '1',
            '-q:v', '1',
            str(temp_frame)
        ]
        logger.debug(f"РР·РІР»РµС‡РµРЅРёРµ РїРѕСЃР»РµРґРЅРµРіРѕ РєР°РґСЂР°: {' '.join(cmd_extract)}")
        subprocess.run(cmd_extract, check=True, capture_output=True, **SUBPROCESS_FLAGS)

        cmd_create = [
            FFMPEG, '-y',
            '-loop', '1',
            '-i', str(temp_frame),
            '-t', str(duration),
            '-r', str(fps)
        ] + encoder_params + [
            '-an',
            str(output_video)
        ]
        logger.debug(f"РЎРѕР·РґР°РЅРёРµ РІРёРґРµРѕ РёР· РєР°РґСЂР°: {' '.join(cmd_create)}")
        subprocess.run(cmd_create, check=True, capture_output=True, **SUBPROCESS_FLAGS)

        temp_frame.unlink()
        logger.info(f"Freeze frame СЃРѕР·РґР°РЅ: {output_video}")
    except Exception as e:
        logger.error(f"РћС€РёР±РєР° СЃРѕР·РґР°РЅРёСЏ freeze frame: {e}")
        logger.error(traceback.format_exc())
        raise

def build_atempo_chain(speed_factor):
    """
    РЎРѕР·РґР°С‘С‚ С†РµРїРѕС‡РєСѓ atempo С„РёР»СЊС‚СЂРѕРІ РґР»СЏ СѓСЃРєРѕСЂРµРЅРёСЏ/Р·Р°РјРµРґР»РµРЅРёСЏ Р°СѓРґРёРѕ.
    FFmpeg atempo РїРѕРґРґРµСЂР¶РёРІР°РµС‚ С‚РѕР»СЊРєРѕ 0.5-2.0, РґР»СЏ Р±РѕР»СЊС€РёС… Р·РЅР°С‡РµРЅРёР№ РЅСѓР¶РЅР° С†РµРїРѕС‡РєР°.

    atempo=2.0 в†’ Р°СѓРґРёРѕ РІ 2 СЂР°Р·Р° Р±С‹СЃС‚СЂРµРµ (РґР»РёС‚РµР»СЊРЅРѕСЃС‚СЊ /2)
    atempo=0.5 в†’ Р°СѓРґРёРѕ РІ 2 СЂР°Р·Р° РјРµРґР»РµРЅРЅРµРµ (РґР»РёС‚РµР»СЊРЅРѕСЃС‚СЊ *2)

    speed_factor вЂ” РІРѕ СЃРєРѕР»СЊРєРѕ СЂР°Р· РЅСѓР¶РЅРѕ СѓСЃРєРѕСЂРёС‚СЊ (>1 = Р±С‹СЃС‚СЂРµРµ, <1 = РјРµРґР»РµРЅРЅРµРµ).
    atempo = speed_factor РЅР°РїСЂСЏРјСѓСЋ (РќР• 1/speed_factor!)
    """
    target_atempo = speed_factor  # Р‘Р•Р— РёРЅРІРµСЂСЃРёРё!

    if 0.5 <= target_atempo <= 2.0:
        return f'atempo={target_atempo:.5f}'

    chain = []
    current = target_atempo

    if current > 2.0:
        while current > 2.0:
            chain.append('atempo=2.0')
            current /= 2.0
        chain.append(f'atempo={current:.5f}')
    elif current < 0.5:
        while current < 0.5:
            chain.append('atempo=0.5')
            current *= 2.0
        chain.append(f'atempo={current:.5f}')

    return ','.join(chain)

_IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.webp', '.bmp', '.tiff', '.tif'}


def _image_to_zoom_video(input_file, output_file, target_duration, encoder_type, codec, bitrate,
                         logo_path=None, fps=60, keep_audio=False):
    """
    РљРѕРЅРІРµСЂС‚РёСЂСѓРµС‚ РёР·РѕР±СЂР°Р¶РµРЅРёРµ РІ РІРёРґРµРѕ СЃ РјРµРґР»РµРЅРЅС‹Рј Р·СѓРјРѕРј (Ken Burns effect).
    Р—СѓРј: 100% в†’ 110% Р·Р° target_duration СЃРµРєСѓРЅРґ.
    """
    logger.info(f"РР·РѕР±СЂР°Р¶РµРЅРёРµ в†’ Р·СѓРј-РІРёРґРµРѕ: {input_file} ({target_duration:.2f}СЃ)")
    print(f"   рџ–јпёЏ  РР·РѕР±СЂР°Р¶РµРЅРёРµ в†’ Р·СѓРј-РІРёРґРµРѕ ({target_duration:.2f}СЃ)")

    output_path = Path(output_file)
    encoder_params = get_encoder_params(encoder_type, codec, bitrate)
    total_frames = int(target_duration * fps)
    audio_input_args = []
    audio_output_args = ['-an']
    if keep_audio:
        # Keep stream layout compatible with VEO-audio-inline clips.
        audio_input_args = ['-f', 'lavfi', '-t', f'{target_duration:.6f}',
                            '-i', 'anullsrc=channel_layout=stereo:sample_rate=48000']
        audio_output_args = ['-c:a', 'aac', '-b:a', '192k', '-shortest']

    # zoompan: Р·СѓРј РѕС‚ 1.0 РґРѕ 1.1 Р·Р° РІРµСЃСЊ РєР»РёРї, С†РµРЅС‚СЂ РєР°РґСЂР°
    zoom_expr = f"'min(1.1, 1.0 + (in_w*0.1/in_w)*on/{total_frames})'"
    zoom_filter = (
        f"scale=8000:-1,"
        f"zoompan=z={zoom_expr}:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)'"
        f":d={total_frames}:s=1920x1080:fps={fps}"
    )

    if logo_path:
        # Р›РѕРіРѕ РЅР°РєР»Р°РґС‹РІР°РµС‚СЃСЏ AS-IS (РІ РёСЃС…РѕРґРЅС‹С… СЂР°Р·РјРµСЂР°С… PNG). Р®Р·РµСЂ СЃР°Рј СЂРµС€Р°РµС‚
        # РєР°РєРѕРіРѕ СЂР°Р·РјРµСЂР° РµРјСѓ РЅСѓР¶РЅРѕ вЂ” 150Г—150 / 350Г—500 вЂ” ffmpeg РЅРµ С‚СЂРѕРіР°РµС‚.
        video_filter = (f"[0:v]{zoom_filter}[v];"
                        f"[v][1:v]overlay=W-w-4:H-h-4")
        cmd = [FFMPEG, '-y', '-nostdin',
               '-loop', '1', '-i', input_file, '-i', str(logo_path),
               ] + audio_input_args + [
               '-filter_complex', video_filter,
               '-t', f'{target_duration:.6f}',
               '-r', str(fps)] + encoder_params + audio_output_args + [str(output_path)]
    else:
        cmd = [FFMPEG, '-y', '-nostdin',
               '-loop', '1', '-i', input_file,
               ] + audio_input_args + [
               '-filter:v', zoom_filter,
               '-t', f'{target_duration:.6f}',
               '-r', str(fps)] + encoder_params + audio_output_args + [str(output_path)]

    subprocess.run(cmd, check=True, capture_output=True, **SUBPROCESS_FLAGS)
    logger.info(f"Р—СѓРј-РІРёРґРµРѕ РіРѕС‚РѕРІРѕ: {output_file}")


def _build_atempo(speed_factor: float) -> str:
    """РЎС‚СЂРѕРёС‚ С†РµРїРѕС‡РєСѓ atempo С„РёР»СЊС‚СЂРѕРІ РґР»СЏ Р»СЋР±РѕРіРѕ speed_factor (РґРёР°РїР°Р·РѕРЅ РєР°Р¶РґРѕРіРѕ [0.5, 2.0])."""
    filters = []
    sf = speed_factor
    while sf > 2.0:
        filters.append("atempo=2.0")
        sf /= 2.0
    while sf < 0.5:
        filters.append("atempo=0.5")
        sf /= 0.5
    filters.append(f"atempo={sf:.6f}")
    return ",".join(filters)


def process_video(input_file, output_file, target_duration, encoder_type, codec, bitrate,
                   logo_path=None, blur_borders=False, keep_audio=False, upscale_1080=False, fps=60,
                   is_chain_extend=False, force_trim_to_target=False):
    """РћР±СЂР°Р±Р°С‚С‹РІР°РµС‚ РІРёРґРµРѕ СЃ СЂРµС‚Р°Р№РјРёРЅРіРѕРј РґРѕ РЅСѓР¶РЅРѕР№ РґР»РёС‚РµР»СЊРЅРѕСЃС‚Рё + С‚РѕС‡РЅР°СЏ РѕР±СЂРµР·РєР°.
    Р•СЃР»Рё input_file вЂ” РёР·РѕР±СЂР°Р¶РµРЅРёРµ, СЃРѕР·РґР°С‘С‚ Р·СѓРј-РІРёРґРµРѕ РЅСѓР¶РЅРѕР№ РґР»РёРЅС‹.
    blur_borders=True вЂ” СЂР°Р·РјС‹РІР°РµС‚ ~8% РєСЂР°СЏ РєР°РґСЂР° (СЃРєСЂС‹С‚РёРµ РІРѕРґСЏРЅС‹С… Р·РЅР°РєРѕРІ).
    keep_audio=True  вЂ” СЃРѕС…СЂР°РЅСЏРµС‚ VEO Р°СѓРґРёРѕ РІ СЂРµС‚Р°Р№РјР»РµРЅРЅРѕРј С„СЂР°РіРјРµРЅС‚Рµ (РґР»СЏ script-mode Р±РµР· РЅР°СЂР°С†РёРё).
    is_chain_extend=True вЂ” trim first N frames (duplicate from prev clip's last_frame) + mute audio (VEO artifacts)."""
    input_path = Path(input_file)

    # Chain extend: configurable trim offset (skip first N frames, fps-independent)
    _trim_frames = int(os.getenv('VIDEO_EXTEND_TRIM_FRAMES', '1'))

    # РР·РѕР±СЂР°Р¶РµРЅРёРµ в†’ Р·СѓРј-РІРёРґРµРѕ
    if input_path.suffix.lower() in _IMAGE_EXTENSIONS:
        _image_to_zoom_video(input_file, output_file, target_duration,
                             encoder_type, codec, bitrate, logo_path, fps=fps,
                             keep_audio=keep_audio)
        return get_video_duration(output_file)

    logger.debug(f"Р РµС‚Р°Р№РјРёРЅРі {input_file} в†’ {output_file} (С†РµР»РµРІР°СЏ РґР»РёС‚РµР»СЊРЅРѕСЃС‚СЊ: {target_duration:.2f} СЃРµРє)")

    output_path = Path(output_file)
    temp_output = output_path.with_suffix('.temp.mp4')

    try:
        result = subprocess.run(
            [FFPROBE, '-v', 'error', '-show_entries', 'format=duration',
             '-of', 'default=noprint_wrappers=1:nokey=1', input_file],
            capture_output=True, text=True, **SUBPROCESS_FLAGS
        )
        _dur_str = result.stdout.strip()
        if not _dur_str:
            logger.warning(f"ffprobe returned empty duration for {input_file} вЂ” file may be corrupt, skipping")
            return None
        current_duration = float(_dur_str)

        # Trim mode: РєРѕСЂРѕС‚РєРёРµ С†РµР»РµРІС‹Рµ РґР»РёС‚РµР»СЊРЅРѕСЃС‚Рё РѕР±СЂРµР·Р°РµРј РІРјРµСЃС‚Рѕ СѓСЃРєРѕСЂРµРЅРёСЏ.
        # Р•СЃР»Рё source РґРѕСЃС‚Р°С‚РѕС‡РЅРѕ РґР»РёРЅРЅС‹Р№ вЂ” speed_factor=1.0 в†’ setpts=PTS/1.0 (no-op) +
        # -t target_duration РѕР±СЂРµР¶РµС‚ С…РІРѕСЃС‚ Р±РµР· РїРµСЂРµРєРѕРґРёСЂРѕРІР°РЅРёСЏ С‚РµРјРїР°.
        # Р•СЃР»Рё source РєРѕСЂРѕС‡Рµ target вЂ” РЅРѕСЂРјР°Р»СЊРЅС‹Р№ СЂРµС‚Р°Р№Рј (Р·Р°РјРµРґР»РµРЅРёРµ).
        if (force_trim_to_target or target_duration <= TRIM_MAX_DURATION) and current_duration >= target_duration:
            speed_factor = 1.0
            logger.info(f"Trim mode: target {target_duration:.2f}s, source {current_duration:.2f}s -> trim without speed-up")
        else:
            speed_factor = current_duration / target_duration

        logger.debug(f"РўРµРєСѓС‰Р°СЏ РґР»РёС‚РµР»СЊРЅРѕСЃС‚СЊ: {current_duration:.2f} СЃРµРє, speed_factor: {speed_factor:.4f}")

        encoder_params = get_encoder_params(encoder_type, codec, bitrate)

        # Blur-borders: С‚РѕРЅРєРёРµ С‡С‘СЂРЅС‹Рµ РїРѕР»РѕСЃС‹ СЃРІРµСЂС…Сѓ Рё СЃРЅРёР·Сѓ РґР»СЏ СЃРєСЂС‹С‚РёСЏ watermark
        blur_suffix = ""
        if blur_borders:
            blur_suffix = ",drawbox=x=0:y=0:w=iw:h=ih*0.06:color=black:t=fill,drawbox=x=0:y=ih*0.94:w=iw:h=ih*0.06:color=black:t=fill"

        # РђРїСЃРєРµР№Р» РґРѕ 1080p РµСЃР»Рё Р·Р°РїСЂРѕС€РµРЅ
        scale_suffix = ",scale=1920:1080" if upscale_1080 else ""

        # РЁРђР“ 1: Р РµС‚Р°Р№РјРёРЅРі СЃ РїРµСЂРµРєРѕРґРёСЂРѕРІР°РЅРёРµРј (+ overlay Р»РѕРіРѕ РµСЃР»Рё Р·Р°РґР°РЅ)
        # keep_audio=False (РїРѕ СѓРјРѕР»С‡Р°РЅРёСЋ): Р°СѓРґРёРѕ СЃС‚СЂРёРїР°РµС‚СЃСЏ (-an), Р·Р°РјРµРЅСЏРµС‚СЃСЏ РЅР°СЂР°С†РёРµР№ РІ Р­С‚Р°РїРµ 8.
        # keep_audio=True (script-mode): Р°СѓРґРёРѕ СЂРµС‚Р°Р№РјРёС‚СЃСЏ С‡РµСЂРµР· atempo Рё СЃРѕС…СЂР°РЅСЏРµС‚СЃСЏ РІ РёС‚РѕРіРѕРІРѕРј РІРёРґРµРѕ.
        # is_chain_extend=True: force mute audio (VEO artifacts on extend clips)
        if is_chain_extend:
            audio_args = ['-an']
            keep_audio = False  # Override for chain extends
        else:
            audio_args = ['-filter:a', _build_atempo(speed_factor)] if keep_audio else ['-an']

        # Chain extend: will add select filter to skip exactly 1st frame (frame-perfect, fps-independent)
        input_args = ['-i', input_file]

        if logo_path:
            # filter_complex: СЂРµС‚Р°Р№РјРёРЅРі + overlay Р»РѕРіРѕ РІ РїСЂР°РІС‹Р№ РЅРёР¶РЅРёР№ СѓРіРѕР».
            # Р›РѕРіРѕ РЅР°РєР»Р°РґС‹РІР°РµС‚СЃСЏ AS-IS (РІ РёСЃС…РѕРґРЅС‹С… СЂР°Р·РјРµСЂР°С… PNG). Р®Р·РµСЂ СЃР°Рј СЂРµС€Р°РµС‚
            # РєР°РєРѕРіРѕ СЂР°Р·РјРµСЂР° РµРјСѓ РЅСѓР¶РЅРѕ вЂ” 150Г—150 / 350Г—500 вЂ” ffmpeg РЅРµ С‚СЂРѕРіР°РµС‚.
            # Chain extend: select='gt(n,N-1)' skips first N frames (fps-independent, configurable)
            if is_chain_extend:
                _n_thresh = _trim_frames - 1
                _setpts = f"select='gt(n,{_n_thresh})',setpts=(PTS-STARTPTS)/{speed_factor}{blur_suffix}{scale_suffix}"
            else:
                _setpts = f'setpts=PTS/{speed_factor}{blur_suffix}{scale_suffix}'
            video_filter = (
                f'[0:v]{_setpts}[v];'
                f'[v][1:v]overlay=W-w-4:H-h-4'
            )
            cmd = [FFMPEG, '-y', '-nostdin'] + input_args + [
                   '-i', str(logo_path),
                   '-filter_complex', video_filter] + audio_args + [
                   '-t', f'{target_duration:.6f}',
                   '-r', str(fps)] + encoder_params + [str(temp_output)]
        else:
            # Chain extend: select='gt(n,N-1)' skips first N frames (fps-independent, configurable)
            if is_chain_extend:
                _n_thresh = _trim_frames - 1
                vf = f"select='gt(n,{_n_thresh})',setpts=(PTS-STARTPTS)/{speed_factor}{blur_suffix}{scale_suffix}"
            else:
                vf = f'setpts=PTS/{speed_factor}{blur_suffix}{scale_suffix}'
            cmd = [FFMPEG, '-y', '-nostdin'] + input_args + [
                   '-filter:v', vf] + audio_args + [
                   '-t', f'{target_duration:.6f}',
                   '-r', str(fps)] + encoder_params + [str(temp_output)]

        subprocess.run(cmd, check=True, capture_output=True, **SUBPROCESS_FLAGS)

        # РџРµСЂРµРёРјРµРЅРѕРІС‹РІР°РµРј temp в†’ final
        if output_path.exists():
            output_path.unlink()
        temp_output.rename(output_path)

        result_duration = get_video_duration(output_path)
        diff = abs(result_duration - target_duration)
        logger.info(f"Clip {os.path.basename(input_file)}: {current_duration:.2f}СЃ в†’ {result_duration:.2f}СЃ (С†РµР»СЊ {target_duration:.2f}СЃ, СЂР°Р·РЅРёС†Р° {diff:.3f}СЃ)")

        logger.debug(f"Р РµС‚Р°Р№РјРёРЅРі Р·Р°РІРµСЂС€РµРЅ: {output_file}")
        return result_duration
    except subprocess.CalledProcessError as e:
        # ffmpeg СѓРїР°Р» РЅР° РїРµСЂРµРєРѕРґРёСЂРѕРІРєРµ вЂ” С„Р°Р№Р» С‡Р°СЃС‚РёС‡РЅРѕ Р±РёС‚С‹Р№ (ffprobe duration
        # РїСЂРѕС‡РёС‚Р°Р», РЅРѕ РґРµРєРѕРґРµСЂ РЅРµ РјРѕР¶РµС‚ РѕР±СЂР°Р±РѕС‚Р°С‚СЊ СЃРѕРґРµСЂР¶РёРјРѕРµ). Р’РѕР·РІСЂР°С‰Р°РµРј None,
        # С‡С‚РѕР±С‹ РЅР°СЂСѓР¶РЅС‹Р№ fallback РІ main() РїРѕРґС…РІР°С‚РёР» РєР°СЂС‚РёРЅРєСѓ РёР· generated/.
        logger.warning(f"ffmpeg failed on {input_file} (CalledProcessError) вЂ” triggering image fallback")
        try:
            if temp_output.exists():
                temp_output.unlink()
        except:
            pass
        return None
    except Exception as e:
        logger.error(f"РћС€РёР±РєР° СЂРµС‚Р°Р№РјРёРЅРіР° {input_file}: {e}")
        logger.error(traceback.format_exc())
        # РџСЂРѕР±СѓРµРј РѕС‡РёСЃС‚РёС‚СЊ temp С„Р°Р№Р»
        try:
            if temp_output.exists():
                temp_output.unlink()
        except:
            pass
        raise

def group_concat(file_list, output_file, temp_dir, group_size=9999, sub_path=None, encoder_type='cpu', bitrate='10M', total_duration=None):
    """Р“Р РЈРџРџРћР’РђРЇ РЎРљР›Р•Р™РљРђ"""
    logger.info("Р­РўРђРџ 5: Р“Р РЈРџРџРћР’РђРЇ РЎРљР›Р•Р™РљРђ")
    logger.info(f"Р’СЃРµРіРѕ С„Р°Р№Р»РѕРІ: {len(file_list)}, СЂР°Р·РјРµСЂ РіСЂСѓРїРїС‹: {group_size}")

    print(f"\nрџ”— Р“Р РЈРџРџРћР’РђРЇ РЎРљР›Р•Р™РљРђ {len(file_list)} С„Р°Р№Р»РѕРІ...")
    print(f"   рџ’Ў Р Р°Р·РјРµСЂ РіСЂСѓРїРїС‹: {group_size} С„Р°Р№Р»РѕРІ")

    num_groups = (len(file_list) + group_size - 1) // group_size
    print(f"   рџ“Љ Р“СЂСѓРїРї: {num_groups}")
    print()

    chunk_files = []
    start_time = time.time()

    print(f"рџ“¦ Р­С‚Р°Рї 1: РЎРєР»РµР№РєР° РіСЂСѓРїРї")
    for group_idx in range(num_groups):
        start_idx = group_idx * group_size
        end_idx = min(start_idx + group_size, len(file_list))
        group_files = file_list[start_idx:end_idx]

        chunk_file = temp_dir / f'chunk_{group_idx+1:02d}.mp4'

        logger.info(f"РЎРєР»РµР№РєР° РіСЂСѓРїРїС‹ {group_idx+1}/{num_groups}: С„Р°Р№Р»С‹ {start_idx+1}-{end_idx}")

        concat_list = temp_dir / f'group_{group_idx+1}.txt'
        with open(concat_list, 'w', encoding='utf-8') as f:
            for fpath in group_files:
                # Escape ' in path for ffmpeg concat demuxer (breaks on apostrophes in project names)
                _p = str(Path(fpath).absolute()).replace("'", r"'\''")
                f.write(f"file '{_p}'\n")

        print(f"   Р“СЂСѓРїРїР° {group_idx+1}/{num_groups}: С„Р°Р№Р»С‹ {start_idx+1}-{end_idx} в†’ chunk_{group_idx+1:02d}.mp4")

        cmd = [FFMPEG, '-y', '-nostdin', '-f', 'concat', '-safe', '0',
               '-i', str(concat_list), '-c', 'copy', '-reset_timestamps', '1', str(chunk_file)]

        group_start = time.time()
        try:
            # TTY (BAT) в†’ СЂРµР°Р»СЊРЅС‹Р№ tqdm РїСЂРѕРіСЂРµСЃСЃ-Р±Р°СЂ; IS_PIPE (GUI) в†’ РїСЂРѕСЃС‚РѕР№ С‚РµРєСЃС‚
            run_ffmpeg_with_progress(cmd, None, f"РЎРєР»РµР№РєР° {group_idx+1}/{num_groups}")

            elapsed = time.time() - group_start
            print(f"   вњ… РЎРєР»РµР№РєР° РіСЂСѓРїРїС‹ {group_idx+1}/{num_groups} ({elapsed:.1f}СЃ)")
            chunk_files.append(str(chunk_file))
            concat_list.unlink()
            logger.info(f"Р“СЂСѓРїРїР° {group_idx+1} СЃРєР»РµРµРЅР° Р·Р° {elapsed:.1f}СЃ")
        except subprocess.CalledProcessError as e:
            print(f"\n   вќЊ")
            logger.error(f"РћС€РёР±РєР° СЃРєР»РµР№РєРё РіСЂСѓРїРїС‹ {group_idx+1}: {e}")
            logger.error(traceback.format_exc())
            raise

    print()

    # Optimisation: if only 1 chunk and no subtitles вЂ” just rename, skip redundant ffmpeg pass
    if len(chunk_files) == 1 and not sub_path:
        import shutil as _shutil
        _shutil.move(str(chunk_files[0]), str(output_file))
        print(f"   вњ… Р•РґРёРЅСЃС‚РІРµРЅРЅС‹Р№ С‡Р°РЅРє в†’ С„РёРЅР°Р»СЊРЅС‹Р№ С„Р°Р№Р» (Р±РµР· РїРµСЂРµСЃРєР»РµР№РєРё)")
        logger.info("Р•РґРёРЅСЃС‚РІРµРЅРЅС‹Р№ С‡Р°РЅРє вЂ” РїРµСЂРµРјРµС‰С‘РЅ РЅР°РїСЂСЏРјСѓСЋ, ffmpeg РЅРµ РЅСѓР¶РµРЅ")
    else:
        print(f"рџ”— Р­С‚Р°Рї 2: РЎРєР»РµР№РєР° {len(chunk_files)} С‡Р°РЅРєРѕРІ...")
        logger.info(f"РЎРєР»РµР№РєР° {len(chunk_files)} С‡Р°РЅРєРѕРІ РІ С„РёРЅР°Р»СЊРЅС‹Р№ С„Р°Р№Р»")

        final_concat_list = temp_dir / 'final_chunks.txt'
        with open(final_concat_list, 'w', encoding='utf-8') as f:
            for chunk in chunk_files:
                _p = str(Path(chunk).absolute()).replace("'", r"'\''")
                f.write(f"file '{_p}'\n")

        if sub_path:
            # FFmpeg ass= filter chokes on non-ASCII paths вЂ” copy to system temp (guaranteed ASCII)
            # Also set fontsdir= so libass finds Book Antiqua from agent/fonts/ on macOS
            import shutil as _shutil, tempfile as _tempfile
            _ass_src = Path(sub_path).absolute()
            _ass_safe = Path(_tempfile.gettempdir()) / '_varagent_subs.ass'
            _shutil.copy2(str(_ass_src), str(_ass_safe))
            _ass_escaped = str(_ass_safe).replace('\\', '/').replace(':', '\\:')
            # Look for agent/fonts/ next to video_concat.py (portable install: project/../../../agent/fonts)
            _fonts_dir = None
            for _cand in [
                Path(__file__).parent / 'agent' / 'fonts',
                Path(__file__).parent.parent / 'agent' / 'fonts',
                Path(__file__).parent.parent.parent / 'agent' / 'fonts',
            ]:
                if _cand.exists():
                    _fonts_dir = _cand
                    break
            if _fonts_dir:
                _fd_escaped = str(_fonts_dir).replace('\\', '/').replace(':', '\\:')
                _vf = f"ass='{_ass_escaped}':fontsdir='{_fd_escaped}'"
                logger.info(f"Subtitle fontsdir: {_fonts_dir}")
            else:
                _vf = f"ass='{_ass_escaped}'"
            if encoder_type == 'amd':
                _vcodec = ['-c:v', 'h264_amf', '-quality', 'quality', '-b:v', bitrate]
            elif encoder_type == 'nvidia':
                _vcodec = ['-c:v', 'h264_nvenc', '-preset', 'p4', '-b:v', bitrate]
            else:
                _vcodec = ['-c:v', 'libx264', '-preset', 'slow', '-crf', '18']
            print(f"   [SUBTITLES] Burning {Path(sub_path).name} into video (re-encoding)...")
            logger.info(f"Subtitle burn-in: encoder={encoder_type} file={sub_path}")
            cmd = [FFMPEG, '-y', '-nostdin', '-f', 'concat', '-safe', '0',
                   '-i', str(final_concat_list), '-vf', _vf] + _vcodec + [
                   '-c:a', 'copy', '-reset_timestamps', '1', str(output_file)]
            # Re-encode with progress bar (reads stdout line-by-line, no RAM buildup)
            run_ffmpeg_with_progress(cmd, total_duration, description="Subtitle burn-in")
            final_concat_list.unlink()
        else:
            cmd = [FFMPEG, '-y', '-nostdin', '-f', 'concat', '-safe', '0',
                   '-i', str(final_concat_list), '-c', 'copy', '-reset_timestamps', '1', str(output_file)]
            try:
                # -c copy is fast вЂ” stderr is small, but still write to file not RAM
                _ff_log = Path(output_file).parent / 'ffmpeg_concat.log'
                with open(_ff_log, 'w') as _fl:
                    subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=_fl, **SUBPROCESS_FLAGS)
                final_concat_list.unlink()
            except subprocess.CalledProcessError as e:
                logger.error(f"РћС€РёР±РєР° С„РёРЅР°Р»СЊРЅРѕР№ СЃРєР»РµР№РєРё: {e}")
                if _ff_log.exists():
                    _tail = _ff_log.read_text(errors='replace')[-2000:]
                    logger.error(f"FFmpeg stderr (tail): {_tail}")
                logger.error(traceback.format_exc())
                raise

        print(f"   вњ… Р“РѕС‚РѕРІРѕ!")
        logger.info("Р¤РёРЅР°Р»СЊРЅР°СЏ СЃРєР»РµР№РєР° С‡Р°РЅРєРѕРІ Р·Р°РІРµСЂС€РµРЅР°")

        for chunk in chunk_files:
            Path(chunk).unlink()

    elapsed = time.time() - start_time
    final_size = get_file_size_mb(output_file)

    logger.info(f"Р“СЂСѓРїРїРѕРІР°СЏ СЃРєР»РµР№РєР° Р·Р°РІРµСЂС€РµРЅР°: СЂР°Р·РјРµСЂ {final_size:.0f} MB, РІСЂРµРјСЏ {elapsed/60:.1f} РјРёРЅ")

    print(f"\n   вњ… РЎРєР»РµР№РєР° Р·Р°РІРµСЂС€РµРЅР°!")
    print(f"      рџ’ѕ Р Р°Р·РјРµСЂ: {final_size:.0f} MB")
    print(f"      вЏ±пёЏ  Р’СЂРµРјСЏ: {elapsed/60:.1f} РјРёРЅ")
    print()

def run_ffmpeg_with_progress_by_files(cmd, total_files, description="РЎРєР»РµР№РєР°"):
    """
    Р—Р°РїСѓСЃРєР°РµС‚ FFmpeg СЃ РїСЂРѕРіСЂРµСЃСЃ-Р±Р°СЂРѕРј РїРѕ РєРѕР»РёС‡РµСЃС‚РІСѓ С„Р°Р№Р»РѕРІ.
    РСЃРїРѕР»СЊР·СѓРµС‚СЃСЏ РґР»СЏ СЃРєР»РµР№РєРё С‡РµСЂРµР· concat demuxer.
    """
    logger.debug(f"Р—Р°РїСѓСЃРє FFmpeg СЃ РїСЂРѕРіСЂРµСЃСЃ-Р±Р°СЂРѕРј РїРѕ С„Р°Р№Р»Р°Рј: {description}")

    cmd_with_progress = cmd + ['-progress', 'pipe:1']
    process = subprocess.Popen(cmd_with_progress, stdout=subprocess.PIPE,
                              stderr=subprocess.DEVNULL, universal_newlines=True,
                              **SUBPROCESS_FLAGS)

    start_time = time.time()
    last_refresh = time.time()

    # РџСЂРѕРіСЂРµСЃСЃ-Р±Р°СЂ РїРѕ РєРѕР»РёС‡РµСЃС‚РІСѓ С„Р°Р№Р»РѕРІ
    with tqdm(total=total_files, desc=description, unit="С„Р°Р№Р»",
              bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}]') as pbar:
        last_update = start_time

        for line in process.stdout:
            line = line.strip()

            # РџСЂРё СЃРєР»РµР№РєРµ ffmpeg РЅРµ РѕС‚РґР°С‘С‚ С‚РѕС‡РЅС‹Р№ РїСЂРѕРіСЂРµСЃСЃ,
            # РїРѕСЌС‚РѕРјСѓ РѕР±РЅРѕРІР»СЏРµРј РїР»Р°РІРЅРѕ РїРѕ РІСЂРµРјРµРЅРё
            now = time.time()
            if now - last_update >= 0.2:
                # Р­РјСѓР»РёСЂСѓРµРј РїСЂРѕРіСЂРµСЃСЃ РїРѕ elapsed РІСЂРµРјРµРЅРё
                elapsed = now - start_time
                # РџСЂРµРґРїРѕР»Р°РіР°РµРј Р»РёРЅРµР№РЅСѓСЋ СЃРєРѕСЂРѕСЃС‚СЊ: total_files / estimated_total
                # РќРѕ С‚Р°Рє РєР°Рє РЅРµ Р·РЅР°РµРј РѕР±С‰СѓСЋ РґР»РёС‚РµР»СЊРЅРѕСЃС‚СЊ, РїСЂРѕСЃС‚Рѕ РїСѓР»СЊСЃРёРј РїСЂРѕРіСЂРµСЃСЃ
                pbar.update(0)  # РћР±РЅРѕРІР»РµРЅРёРµ Р±РµР· РёР·РјРµРЅРµРЅРёСЏ РїСЂРѕРіСЂРµСЃСЃР°
                last_update = now

            now = time.time()
            if now - last_refresh >= 1.0:
                pbar.refresh()
                last_refresh = now

    process.wait()

    elapsed = time.time() - start_time
    logger.info(f"{description} Р·Р°РІРµСЂС€РµРЅР° Р·Р° {elapsed:.1f}СЃ")

    if process.returncode != 0:
        logger.error(f"FFmpeg Р·Р°РІРµСЂС€РёР»СЃСЏ СЃ РѕС€РёР±РєРѕР№: returncode={process.returncode}")
        raise subprocess.CalledProcessError(process.returncode, cmd)


def run_ffmpeg_with_spinner(cmd, description="РћР±СЂР°Р±РѕС‚РєР°"):
    """
    Р—Р°РїСѓСЃРєР°РµС‚ FFmpeg СЃРѕ СЃРїРёРЅРЅРµСЂРѕРј (Р°РЅРёРјР°С†РёСЏ РѕР¶РёРґР°РЅРёСЏ).
    Stdout РґСЂРµРЅРёСЂСѓРµС‚СЃСЏ РІ С„РѕРЅРѕРІРѕРј РїРѕС‚РѕРєРµ С‡С‚РѕР±С‹ РЅРµ Р±С‹Р»Рѕ pipe deadlock.
    """
    logger.debug(f"Р—Р°РїСѓСЃРє FFmpeg СЃРѕ СЃРїРёРЅРЅРµСЂРѕРј: {description}")

    process = subprocess.Popen(cmd, stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL,
                               **SUBPROCESS_FLAGS)

    spinners = ['в ‹', 'в ™', 'в №', 'в ё', 'в ј', 'в ґ', 'в ¦', 'в §', 'в ‡', 'в Џ']
    start_time = time.time()
    spinner_idx = 0
    last_refresh = start_time

    try:
        while process.poll() is None:
            now = time.time()
            if now - last_refresh >= 0.1:
                elapsed = now - start_time
                sys.stdout.write(f'\r   {spinners[spinner_idx]} {description}: {elapsed:.1f}СЃ')
                sys.stdout.flush()
                spinner_idx = (spinner_idx + 1) % len(spinners)
                last_refresh = now
            time.sleep(0.05)

        elapsed = time.time() - start_time
        sys.stdout.write(f'\r   вњ… {description} Р·Р°РІРµСЂС€РµРЅРѕ Р·Р° {elapsed:.1f}СЃ   \n')
        sys.stdout.flush()
        logger.info(f"{description} Р·Р°РІРµСЂС€РµРЅРѕ Р·Р° {elapsed:.1f}СЃ")

        if process.returncode != 0:
            logger.error(f"FFmpeg Р·Р°РІРµСЂС€РёР»СЃСЏ СЃ РѕС€РёР±РєРѕР№: returncode={process.returncode}")
            raise subprocess.CalledProcessError(process.returncode, cmd)

    except KeyboardInterrupt:
        process.kill()
        sys.stdout.write(f'\r   вќЊ {description} РїСЂРµСЂРІР°РЅРѕ   \n')
        sys.stdout.flush()
        raise


def run_ffmpeg_with_progress(cmd, total_duration, description="Processing"):
    """Р—Р°РїСѓСЃРєР°РµС‚ FFmpeg СЃ РїСЂРѕРіСЂРµСЃСЃ-Р±Р°СЂРѕРј"""
    logger.debug(f"Р—Р°РїСѓСЃРє FFmpeg СЃ РїСЂРѕРіСЂРµСЃСЃ-Р±Р°СЂРѕРј: {description}")

    cmd_with_progress = cmd + ['-progress', 'pipe:1']
    process = subprocess.Popen(cmd_with_progress, stdout=subprocess.PIPE,
                              stderr=subprocess.DEVNULL, universal_newlines=True,
                              **SUBPROCESS_FLAGS)

    start_time = time.time()
    got_any_progress = False
    last_refresh = start_time

    if total_duration is None or total_duration <= 0:
        bar_fmt = None
        tqdm_total = None
    else:
        tqdm_total = round(total_duration, 1)
        bar_fmt = None

    if IS_PIPE:
        # Pipeline mode: drain progress lines, РїРµС‡Р°С‚Р°РµРј РїСЂРѕСЃС‚РѕР№ С‚РµРєСЃС‚ РєР°Р¶РґС‹Рµ 5СЃ
        last_time = 0
        last_pipe_print = start_time
        for line in process.stdout:
            line = line.strip()
            if line.startswith('out_time_us=') or line.startswith('out_time_ms='):
                try:
                    val = line.split('=')[1]
                    if val and val != 'N/A':
                        time_s = int(val) / 1000000.0
                        if time_s > last_time:
                            last_time = time_s
                            got_any_progress = True
                            if tqdm_total and time.time() - last_pipe_print >= 5.0:
                                pct = min(100, int(time_s / tqdm_total * 100))
                                print(f"   {description}: {pct}% ({time_s:.0f}/{tqdm_total:.0f}s)")
                                last_pipe_print = time.time()
                except (ValueError, IndexError):
                    pass
    else:
        # TTY mode: tqdm РїСЂРѕРіСЂРµСЃСЃ-Р±Р°СЂ
        tqdm_kwargs = dict(total=tqdm_total, desc=description, unit="s")
        if bar_fmt:
            tqdm_kwargs['bar_format'] = bar_fmt
        with tqdm(**tqdm_kwargs) as pbar:
            last_time = 0
            for line in process.stdout:
                line = line.strip()
                if line.startswith('out_time_us=') or line.startswith('out_time_ms='):
                    try:
                        val = line.split('=')[1]
                        if val and val != 'N/A':
                            time_s = int(val) / 1000000.0
                            delta = time_s - last_time
                            if delta > 0:
                                pbar.update(delta)
                                last_time = time_s
                                got_any_progress = True
                    except (ValueError, IndexError):
                        pass
                elif line.startswith('out_time=') and not got_any_progress:
                    try:
                        val = line.split('=')[1]
                        if val and val != 'N/A':
                            parts = val.split(':')
                            time_s = float(parts[0])*3600 + float(parts[1])*60 + float(parts[2])
                            delta = time_s - last_time
                            if delta > 0:
                                pbar.update(delta)
                                last_time = time_s
                    except (ValueError, IndexError):
                        pass
                now = time.time()
                if now - last_refresh >= 1.0:
                    pbar.refresh()
                    last_refresh = now

    process.wait()

    elapsed = time.time() - start_time
    logger.info(f"{description} Р·Р°РІРµСЂС€РµРЅРѕ Р·Р° {elapsed:.1f}СЃ (РїСЂРѕРіСЂРµСЃСЃ РѕС‚СЃР»РµР¶РёРІР°Р»СЃСЏ: {got_any_progress})")

    if process.returncode != 0:
        logger.error(f"FFmpeg Р·Р°РІРµСЂС€РёР»СЃСЏ СЃ РѕС€РёР±РєРѕР№: returncode={process.returncode}")
        raise subprocess.CalledProcessError(process.returncode, cmd)

def ask_delete_temp_folder(temp_dir, no_cleanup=False):
    """РЎРїСЂР°С€РёРІР°РµС‚ РїРѕР»СЊР·РѕРІР°С‚РµР»СЏ РѕР± СѓРґР°Р»РµРЅРёРё РІСЂРµРјРµРЅРЅРѕР№ РїР°РїРєРё"""
    
    # Р•СЃР»Рё --no-cleanup, РїСЂРѕСЃС‚Рѕ РѕСЃС‚Р°РІР»СЏРµРј РїР°РїРєСѓ Р±РµР· РІРѕРїСЂРѕСЃРѕРІ
    if no_cleanup:
        logger.info("--no-cleanup: temp РїР°РїРєР° СЃРѕС…СЂР°РЅРµРЅР°")
        print(f"\nрџ§№ Р’СЂРµРјРµРЅРЅР°СЏ РїР°РїРєР°: {temp_dir}")
        print(f"   рџ’ѕ Р Р°Р·РјРµСЂ: {sum(f.stat().st_size for f in temp_dir.rglob('*') if f.is_file()) / (1024*1024):.0f} MB")
        print(f"   вњ… РџР°РїРєР° СЃРѕС…СЂР°РЅРµРЅР° (С„Р»Р°Рі --no-cleanup)")
        return
    
    print(f"\nрџ§№ Р’СЂРµРјРµРЅРЅР°СЏ РїР°РїРєР°: {temp_dir}")
    print(f"   рџ’ѕ Р Р°Р·РјРµСЂ: {sum(f.stat().st_size for f in temp_dir.rglob('*') if f.is_file()) / (1024*1024):.0f} MB")

    # Р•СЃР»Рё stdin РЅРµ РёРЅС‚РµСЂР°РєС‚РёРІРЅС‹Р№ (IS_PIPE, subprocess, redirected) вЂ” РЅРµ СЃРїСЂР°С€РёРІР°РµРј, СѓРґР°Р»СЏРµРј Р°РІС‚РѕРјР°С‚РёС‡РµСЃРєРё
    if not sys.stdin.isatty():
        logger.info("stdin РЅРµ TTY вЂ” СѓРґР°Р»СЏРµРј temp РїР°РїРєСѓ Р°РІС‚РѕРјР°С‚РёС‡РµСЃРєРё")
        try:
            shutil.rmtree(temp_dir)
            print(f"   вњ… РџР°РїРєР° СѓРґР°Р»РµРЅР° (auto)")
            logger.info("Р’СЂРµРјРµРЅРЅР°СЏ РїР°РїРєР° СѓРґР°Р»РµРЅР° (auto, non-TTY)")
        except Exception as e:
            print(f"   вљ пёЏ  РћС€РёР±РєР° СѓРґР°Р»РµРЅРёСЏ: {e}")
        return

    print()
    while True:
        try:
            response = input("РЈРґР°Р»РёС‚СЊ РІСЂРµРјРµРЅРЅСѓСЋ РїР°РїРєСѓ? (y/n): ").strip().lower()
        except EOFError:
            logger.info("stdin EOF вЂ” СѓРґР°Р»СЏРµРј temp РїР°РїРєСѓ Р°РІС‚РѕРјР°С‚РёС‡РµСЃРєРё")
            try:
                shutil.rmtree(temp_dir)
                print(f"\n   вњ… РџР°РїРєР° СѓРґР°Р»РµРЅР° (auto, EOF)")
                logger.info("Р’СЂРµРјРµРЅРЅР°СЏ РїР°РїРєР° СѓРґР°Р»РµРЅР° (auto, EOF)")
            except Exception as e:
                print(f"\n   вљ пёЏ  РћС€РёР±РєР° СѓРґР°Р»РµРЅРёСЏ: {e}")
            return
        if response in ['y', 'yes', 'Рґ', 'РґР°']:
            logger.info("РџРѕР»СЊР·РѕРІР°С‚РµР»СЊ РІС‹Р±СЂР°Р» СѓРґР°Р»РёС‚СЊ temp РїР°РїРєСѓ")
            try:
                shutil.rmtree(temp_dir)
                print("   вњ… РџР°РїРєР° СѓРґР°Р»РµРЅР°")
                logger.info("Р’СЂРµРјРµРЅРЅР°СЏ РїР°РїРєР° СѓРґР°Р»РµРЅР°")
            except Exception as e:
                print(f"   вљ пёЏ  РћС€РёР±РєР° СѓРґР°Р»РµРЅРёСЏ: {e}")
                logger.error(f"РћС€РёР±РєР° СѓРґР°Р»РµРЅРёСЏ temp РїР°РїРєРё: {e}")
            break
        elif response in ['n', 'no', 'РЅ', 'РЅРµС‚']:
            logger.info("РџРѕР»СЊР·РѕРІР°С‚РµР»СЊ РІС‹Р±СЂР°Р» РѕСЃС‚Р°РІРёС‚СЊ temp РїР°РїРєСѓ")
            print(f"   вњ… РџР°РїРєР° СЃРѕС…СЂР°РЅРµРЅР°: {temp_dir.absolute()}")
            break
        elif response == '':
            # Enter Р±РµР· РІРІРѕРґР° вЂ” РЅРµ С†РёРєР»РёС‡РёРј, СЃС‡РёС‚Р°РµРј РєР°Рє 'n'
            logger.info("РџСѓСЃС‚РѕР№ РІРІРѕРґ вЂ” temp РїР°РїРєР° СЃРѕС…СЂР°РЅРµРЅР°")
            print(f"   вњ… РџР°РїРєР° СЃРѕС…СЂР°РЅРµРЅР°")
            break
        else:
            print("   вљ пёЏ  Р’РІРµРґРёС‚Рµ 'y' (СѓРґР°Р»РёС‚СЊ) РёР»Рё 'n' (РѕСЃС‚Р°РІРёС‚СЊ)")

# ============================================================================
# MAIN
# ============================================================================

def main():
    global logger

    # Р¤РѕСЂСЃРёСЂСѓРµРј line-buffered РІС‹РІРѕРґ вЂ” Р±РµР· СЌС‚РѕРіРѕ BAT РЅР°РєР°РїР»РёРІР°РµС‚ РІРµСЃСЊ РІС‹РІРѕРґ Рё РІС‹РґР°С‘С‚ СЂР°Р·РѕРј
    try:
        sys.stdout.reconfigure(line_buffering=True)
    except AttributeError:
        pass  # Python < 3.7

    parser = argparse.ArgumentParser(description='Р“СЂСѓРїРїРѕРІР°СЏ СЃРєР»РµР№РєР° - v6 OVERLAP GUARD')
    parser.add_argument('plan', help='РџСѓС‚СЊ Рє montage_plan.json')
    parser.add_argument('-o', '--output', default='result.mp4', help='Р’С‹С…РѕРґРЅРѕР№ С„Р°Р№Р»')
    parser.add_argument('-a', '--audio', default=None, help='РђСѓРґРёРѕ РѕР·РІСѓС‡РєР° (РїРѕ СѓРјРѕР»С‡Р°РЅРёСЋ РёС‰РµС‚СЃСЏ Р»СЋР±РѕР№ .wav/.mp3 С„Р°Р№Р»)')
    parser.add_argument('-b', '--bitrate', default='10M', help='Р‘РёС‚СЂРµР№С‚ РІРёРґРµРѕ')
    parser.add_argument('-g', '--group-size', type=int, default=9999, help='Р Р°Р·РјРµСЂ РіСЂСѓРїРїС‹ РґР»СЏ СЃРєР»РµР№РєРё (РїРѕ СѓРјРѕР»С‡Р°РЅРёСЋ 9999 = РѕРґРёРЅ РїСЂРѕС…РѕРґ)')
    parser.add_argument('-r', '--resolution', default=None, help='Р Р°Р·СЂРµС€РµРЅРёРµ (1080, 720) вЂ” РѕРїС†РёРѕРЅР°Р»СЊРЅРѕ, РґР»СЏ СЃРѕРІРјРµСЃС‚РёРјРѕСЃС‚Рё')
    parser.add_argument('--no-gpu', action='store_true', help='РСЃРїРѕР»СЊР·РѕРІР°С‚СЊ CPU РІРјРµСЃС‚Рѕ GPU')
    parser.add_argument('--force-amd', action='store_true', help='РџСЂРёРЅСѓРґРёС‚РµР»СЊРЅРѕ РёСЃРїРѕР»СЊР·РѕРІР°С‚СЊ AMD GPU')
    parser.add_argument('--force-reprocess', action='store_true', help='РџРµСЂРµРѕР±СЂР°Р±РѕС‚Р°С‚СЊ РІСЃРµ С„Р°Р№Р»С‹')
    parser.add_argument('--logo', default=None, help='PNG Р»РѕРіРѕ РґР»СЏ РЅР°Р»РѕР¶РµРЅРёСЏ (РїСЂР°РІС‹Р№ РЅРёР¶РЅРёР№ СѓРіРѕР»). Р•СЃР»Рё РЅРµ СѓРєР°Р·Р°РЅ вЂ” РёС‰РµС‚СЃСЏ logo.png РІ РїР°РїРєРµ РїСЂРѕРµРєС‚Р°')
    parser.add_argument('--blur-borders', action='store_true', help='Р Р°Р·РјС‹С‚СЊ РіСЂР°РЅРёС†С‹ РІРёРґРµРѕ (Р·Р°С‰РёС‚Р° РѕС‚ РІРѕРґСЏРЅС‹С… Р·РЅР°РєРѕРІ)')
    parser.add_argument('--no-cleanup', action='store_true', help='РќРµ СѓРґР°Р»СЏС‚СЊ temp_processed РїРѕСЃР»Рµ Р·Р°РІРµСЂС€РµРЅРёСЏ')
    parser.add_argument('--veo-audio-inline', action='store_true', help='РћСЃС‚Р°РІРёС‚СЊ VEO Р°СѓРґРёРѕ РїСЂСЏРјРѕ РЅР° РІРёРґРµРѕСЂСЏРґРµ (РґР»СЏ script-mode Р±РµР· РЅР°СЂР°С†РёРё вЂ” РёС‚РѕРіРѕРІС‹Р№ concat Р±СѓРґРµС‚ СЃРѕ Р·РІСѓРєРѕРј VEO)')
    parser.add_argument('--subtitles', default=None, help='РџСѓС‚СЊ Рє .ass С„Р°Р№Р»Сѓ СЃСѓР±С‚РёС‚СЂРѕРІ РґР»СЏ РІС‹Р¶РёРіР°РЅРёСЏ. РСЃРїРѕР»СЊР·СѓР№ "auto" РґР»СЏ Р°РІС‚Рѕ-РїРѕРёСЃРєР° *.ass РІ РїР°РїРєРµ РїСЂРѕРµРєС‚Р°.')
    parser.add_argument('--fps', type=int, default=60, choices=[24, 25, 30, 50, 60],
                        help='FPS РґР»СЏ Р·СѓРј-РІРёРґРµРѕ РёР· РёР·РѕР±СЂР°Р¶РµРЅРёР№ Рё freeze-frame (default=60)')
    args = parser.parse_args()

    # РќРђРЎРўР РћР™РљРђ Р›РћР“Р“РР РћР’РђРќРРЇ
    logger, log_file = setup_logging()

    logger.info(f"РџР°СЂР°РјРµС‚СЂС‹ Р·Р°РїСѓСЃРєР°:")
    logger.info(f"  plan: {args.plan}")
    logger.info(f"  output: {args.output}")
    logger.info(f"  audio: {args.audio}")
    logger.info(f"  bitrate: {args.bitrate}")
    logger.info(f"  group_size: {args.group_size}")
    logger.info(f"  resolution: {args.resolution}")
    logger.info(f"  no_gpu: {args.no_gpu}")
    logger.info(f"  force_amd: {args.force_amd}")
    logger.info(f"  force_reprocess: {args.force_reprocess}")
    logger.info(f"  logo: {args.logo}")
    logger.info(f"  blur_borders: {args.blur_borders}")
    logger.info(f"  no_cleanup: {args.no_cleanup}")
    logger.info(f"  veo_audio_inline: {args.veo_audio_inline}")
    logger.info(f"  subtitles: {args.subtitles}")

    print("="*80)
    print("[VIDEO] Р“Р РЈРџРџРћР’РђРЇ РЎРљР›Р•Р™РљРђ - v6 OVERLAP GUARD")
    print("="*80)
    print(f"\n[LOG] Р›РѕРі-С„Р°Р№Р»: {log_file}")

    # РђРІС‚Рѕ-rename vid_img/ Рё generated/ РІ 3-Р·РЅР°С‡РЅС‹Р№ С„РѕСЂРјР°С‚ РїРµСЂРµРґ СЃРєР»РµР№РєРѕР№.
    # РСЃС‚РѕС‡РЅРёРєРё РіРµРЅРµСЂР°С†РёР№ С‡Р°СЃС‚Рѕ РїРёС€СѓС‚ С„Р°Р№Р»С‹ СЃ РґР»РёРЅРЅС‹РјРё РёРјРµРЅР°РјРё
    # (banana_0001_Late Renaissance_...png, veo3_generation_abc123.mp4 Рё С‚.Рї.),
    # СЃРєР»РµР№РєР° РѕР¶РёРґР°РµС‚ 001.mp4 / 001.png. rename_videos.py РёРґРµРјРїРѕС‚РµРЅС‚РµРЅ вЂ”
    # РїРѕРІС‚РѕСЂРЅС‹Р№ РІС‹Р·РѕРІ РЅР° СѓР¶Рµ РїРµСЂРµРёРјРµРЅРѕРІР°РЅРЅС‹С… С„Р°Р№Р»Р°С… РЅРёС‡РµРіРѕ РЅРµ РґРµР»Р°РµС‚.
    try:
        _proj_dir = Path(args.plan).resolve().parent
        for _sub in ('vid_img', 'generated'):
            _sd = _proj_dir / _sub
            if not _sd.is_dir():
                continue
            print(f"\n[AUTO-RENAME] {_sub}/ в†’ 3-digit format...")
            try:
                import sys as _sys
                _agent_dir = (Path(__file__).resolve().parent / 'agent')
                if str(_agent_dir) not in _sys.path:
                    _sys.path.insert(0, str(_agent_dir))
                from rename_videos import rename_videos as _rv
                _ok, _err, _w = _rv(directory=_sd, dry_run=False, verbose=False, zero_pad=3)
                print(f"  renamed OK={_ok}, errors={_err}, warnings={len(_w)}")
            except Exception as _re:
                print(f"  [WARN] auto-rename failed ({_re}) вЂ” РїСЂРѕРґРѕР»Р¶Р°РµРј СЃ С‚РµРј С‡С‚Рѕ РµСЃС‚СЊ")
    except Exception:
        pass

    # РћРїСЂРµРґРµР»РµРЅРёРµ СЌРЅРєРѕРґРµСЂР°
    encoder_type, codec = ('cpu', 'libx264') if args.no_gpu else detect_gpu_encoder(args.force_amd)

    if encoder_type == 'nvidia':
        print("\n[OK] NVIDIA GPU - h264_nvenc")
    elif encoder_type == 'amd':
        print("\n[OK] AMD GPU - h264_amf")
    else:
        print("\n[INFO] CPU - libx264")

    print(f"[INFO] Р‘РёС‚СЂРµР№С‚: {args.bitrate}")
    print(f"[INFO] РџР»Р°РЅ: {args.plan}")

    # РћРїСЂРµРґРµР»РµРЅРёРµ РїСѓС‚Рё Рє .ass СЃСѓР±С‚РёС‚СЂР°Рј (РµСЃР»Рё РїРµСЂРµРґР°РЅС‹)
    _sub_path = None
    if args.subtitles:
        if args.subtitles.lower() == 'auto':
            _ass_files = _glob.glob('*.ass')
            if _ass_files:
                _sub_path = str(Path(_ass_files[0]).absolute())
                print(f"[SUBTITLES] Auto-detected: {Path(_sub_path).name}")
                logger.info(f"Subtitles auto-detected: {_sub_path}")
            else:
                logger.info("Subtitles: auto mode, no .ass file found in project folder")
        elif os.path.exists(args.subtitles):
            _template_path = str(Path(args.subtitles).absolute())
            # Р•СЃР»Рё РїРµСЂРµРґР°РЅ .ass С€Р°Р±Р»РѕРЅ вЂ” РёС‰РµРј SRT РІ РїР°РїРєРµ РїСЂРѕРµРєС‚Р° Рё РјРµСЂР¶РёРј
            _srt_candidates = [
                Path(args.plan).parent / 'SRT' / 'subtitles.srt',
                Path(args.plan).parent / 'SRT' / 'subtitles_split.srt',
            ]
            _srt_found = next((p for p in _srt_candidates if p.exists()), None)
            if _srt_found:
                _merged_ass = Path(args.plan).parent / 'SRT' / '_subtitles_merged.ass'
                _srt_to_ass(str(_srt_found), _template_path, str(_merged_ass))
                _sub_path = str(_merged_ass.absolute())
                print(f"[SUBTITLES] Template: {Path(_template_path).name} + SRT: {_srt_found.name} в†’ merged")
                logger.info(f"Subtitles merged: {_sub_path}")
            else:
                # РќРµС‚ SRT вЂ” РІС‹Р¶РёРіР°РµРј С€Р°Р±Р»РѕРЅ РєР°Рє РµСЃС‚СЊ (РµСЃР»Рё РІ РЅС‘Рј СѓР¶Рµ РµСЃС‚СЊ СЃРѕР±С‹С‚РёСЏ)
                _sub_path = _template_path
                print(f"[SUBTITLES] Template only (no SRT found): {Path(_sub_path).name}")
                logger.info(f"Subtitles template only: {_sub_path}")
        else:
            print(f"[SUBTITLES] WARNING: file not found: {args.subtitles}")
            logger.warning(f"Subtitles file not found: {args.subtitles}")

    # Р—Р°РіСЂСѓР·РєР° РїР»Р°РЅР°
    try:
        logger.info(f"Р—Р°РіСЂСѓР·РєР° РїР»Р°РЅР°: {args.plan}")
        with open(args.plan, 'r', encoding='utf-8-sig') as f:
            plan = json.load(f)
        logger.info("РџР»Р°РЅ Р·Р°РіСЂСѓР¶РµРЅ СѓСЃРїРµС€РЅРѕ")
    except (FileNotFoundError, json.JSONDecodeError) as e:
        logger.error(f"РћС€РёР±РєР° Р·Р°РіСЂСѓР·РєРё РїР»Р°РЅР°: {e}")
        logger.error(traceback.format_exc())
        print(f"вќЊ РћС€РёР±РєР° Р·Р°РіСЂСѓР·РєРё РїР»Р°РЅР°: {e}")
        sys.exit(1)

    clips = plan.get('clips', [])
    if not clips:
        logger.error("РќРµС‚ clips РІ РїР»Р°РЅРµ")
        print("вќЊ РќРµС‚ clips РІ РїР»Р°РЅРµ!")
        sys.exit(1)

    # -----------------------------------------------------------------------
    # РЎРћР РўРР РћР’РљРђ РџРћ startTime
    # Gemini РёРЅРѕРіРґР° РІСЃС‚Р°РІР»СЏРµС‚ РєР»РёРїС‹ РЅРµ РІ С‚РѕРј РїРѕСЂСЏРґРєРµ РІ JSON-РјР°СЃСЃРёРІ.
    # РЎРѕСЂС‚РёСЂСѓРµРј РїРѕ startTime, С‡С‚РѕР±С‹ РіР°СЂР°РЅС‚РёСЂРѕРІР°С‚СЊ РїСЂР°РІРёР»СЊРЅС‹Р№ РїРѕСЂСЏРґРѕРє СЃРєР»РµР№РєРё.
    # -----------------------------------------------------------------------
    ids_before = [c['id'] for c in clips]
    clips = sorted(clips, key=lambda c: c['startTime'])
    ids_after = [c['id'] for c in clips]

    misplaced = [ids_before[i] for i in range(len(ids_before)) if ids_before[i] != ids_after[i]]
    if misplaced:
        logger.warning(f"РљР»РёРїС‹ РїРµСЂРµСѓРїРѕСЂСЏРґРѕС‡РµРЅС‹ РїРѕ startTime! Р‘С‹Р»Рѕ РЅРµ РЅР° РјРµСЃС‚Рµ: {misplaced}")
        print(f"\nвљ пёЏ  РџР Р•Р”РЈРџР Р•Р–Р”Р•РќРР•: {len(misplaced)} РєР»РёРїРѕРІ Р±С‹Р»Рё РЅРµ РІ С…СЂРѕРЅРѕР»РѕРіРёС‡РµСЃРєРѕРј РїРѕСЂСЏРґРєРµ РІ JSON")
        print(f"   РџРµСЂРµСЃС‚Р°РІР»РµРЅС‹: {misplaced}")
        print(f"   (Gemini РёРЅРѕРіРґР° РІСЃС‚Р°РІР»СЏРµС‚ РєР»РёРїС‹ РЅРµ РЅР° СЃРІРѕС‘ РјРµСЃС‚Рѕ вЂ” С‚РµРїРµСЂСЊ РёСЃРїСЂР°РІР»РµРЅРѕ)")
    else:
        logger.info("РџРѕСЂСЏРґРѕРє РєР»РёРїРѕРІ РїРѕ startTime: OK")

    # РџРѕРёСЃРє Р°СѓРґРёРѕС„Р°Р№Р»Р° РµСЃР»Рё РЅРµ СѓРєР°Р·Р°РЅ
    audio_file = args.audio
    if audio_file is None:
        logger.debug(f"Audio auto-search in cwd: {Path('.').resolve()}")
        all_audio = []
        for ext in ['*.wav', '*.WAV', '*.mp3', '*.MP3', '*.Mp3',
                    '*.flac', '*.FLAC', '*.m4a', '*.M4A', '*.aac', '*.AAC']:
            found = [f for f in Path('.').glob(ext) if '_original_audio' not in f.name]
            all_audio.extend(found)
            if found and audio_file is None:
                audio_file = str(found[0])
        if all_audio:
            logger.debug(f"Audio files found: {[f.name for f in all_audio]}")
        else:
            logger.debug(f"No audio files found. Files in cwd: {[f.name for f in Path('.').iterdir() if f.is_file()][:20]}")

    if audio_file is None or not os.path.exists(str(audio_file)):
        if getattr(args, 'veo_audio_inline', False):
            logger.warning("РќР°СЂР°С†РёСЏ РЅРµ РЅР°Р№РґРµРЅР° вЂ” veo-audio-inline СЂРµР¶РёРј: РІРёРґРµРѕ Р±СѓРґРµС‚ Р‘Р•Р— РЅР°СЂР°С†РёРё, С‚РѕР»СЊРєРѕ VEO-Р·РІСѓРє")
            print(f"\nвљ пёЏ  Р’РќРРњРђРќРР•: РђСѓРґРёРѕС„Р°Р№Р» РЅР°СЂР°С†РёРё РЅРµ РЅР°Р№РґРµРЅ РІ РїР°РїРєРµ РїСЂРѕРµРєС‚Р°!")
            print(f"   cwd: {Path('.').resolve()}")
            print(f"   Р’РёРґРµРѕ Р±СѓРґРµС‚ СЃРѕР±СЂР°РЅРѕ Р‘Р•Р— РЅР°СЂР°С†РёРё (С‚РѕР»СЊРєРѕ VEO-Р·РІСѓРє РєР»РёРїРѕРІ)")
            print(f"   Р§С‚РѕР±С‹ РґРѕР±Р°РІРёС‚СЊ РЅР°СЂР°С†РёСЋ вЂ” РїРѕР»РѕР¶РёС‚Рµ .mp3/.wav РІ РїР°РїРєСѓ РїСЂРѕРµРєС‚Р° Рё РїРµСЂРµР·Р°РїСѓСЃС‚РёС‚Рµ concat\n")
            audio_file = None
        else:
            logger.error(f"РђСѓРґРёРѕ С„Р°Р№Р» РЅРµ РЅР°Р№РґРµРЅ")
            print(f"вќЊ РђСѓРґРёРѕ С„Р°Р№Р» РЅРµ РЅР°Р№РґРµРЅ!")
            print(f"   РџРѕР»РѕР¶РёС‚Рµ .wav, .mp3, .flac, .m4a РёР»Рё .aac РІ РїР°РїРєСѓ РїСЂРѕРµРєС‚Р°")
            print(f"   РР»Рё СѓРєР°Р¶РёС‚Рµ СЏРІРЅРѕ: -a РёРјСЏ_С„Р°Р№Р»Р°.wav")
            sys.exit(1)

    logger.info(f"РСЃРїРѕР»СЊР·СѓРµРјС‹Р№ Р°СѓРґРёРѕС„Р°Р№Р»: {audio_file}")

    # РџРѕРёСЃРє Р»РѕРіРѕ РґР»СЏ РЅР°Р»РѕР¶РµРЅРёСЏ (logo.png РІ С‚РµРєСѓС‰РµР№ РїР°РїРєРµ РёР»Рё --logo)
    logo_path = None
    if args.logo:
        if os.path.exists(args.logo):
            logo_path = Path(args.logo)
            print(f"[INFO] Р›РѕРіРѕ: {logo_path}")
        else:
            print(f"вљ пёЏ  Р›РѕРіРѕ РЅРµ РЅР°Р№РґРµРЅРѕ: {args.logo} вЂ” РїСЂРѕРґРѕР»Р¶Р°РµРј Р±РµР· Р»РѕРіРѕ")
    else:
        auto_logo = Path('logo.png')
        if auto_logo.exists():
            logo_path = auto_logo
            print(f"[INFO] Р›РѕРіРѕ РЅР°Р№РґРµРЅРѕ: logo.png")
    if logo_path:
        logger.info(f"Р›РѕРіРѕ overlay: {logo_path}")
        # Runtime auto-trim: РµСЃР»Рё РІ PNG РµСЃС‚СЊ РїСЂРѕР·СЂР°С‡РЅС‹Рµ РєРѕР»РѕРЅРєРё/СЃС‚СЂРѕРєРё РїРѕ РєСЂР°СЏРј,
        # РѕРЅРё РІРёР·СѓР°Р»СЊРЅРѕ РЅРёС‡РµРіРѕ РЅРµ Р·РЅР°С‡Р°С‚, РЅРѕ СЃР±РёРІР°СЋС‚ overlay=W-w-4:H-h-4 вЂ”
        # ffmpeg РєР»Р°РґС‘С‚ РІ СѓРіРѕР» Р’Р•РЎР¬ С„Р°Р№Р» СЃ padding'РѕРј, Р° РІРёРґРёРјС‹Р№ РєРѕРЅС‚РµРЅС‚ РІРёСЃРёС‚
        # РІ РѕС‚СЃС‚СѓРїРµ = (РїСЂРѕР·СЂР°С‡РЅР°СЏ СЂР°РјРєР° + 4). РћР±СЂРµР·Р°РµРј alpha-bbox в†’ СЃРѕС…СЂР°РЅСЏРµРј
        # РІ tmp в†’ РїРѕРґРјРµРЅСЏРµРј logo_path. Р”Р»СЏ РєРѕСЂСЂРµРєС‚РЅРѕ СЃРІС‘СЂСЃС‚Р°РЅРЅС‹С… Р»РѕРіРѕС‚РёРїРѕРІ
        # (Р±РµР· РјС‘СЂС‚РІС‹С… РїРѕР»РµР№) bbox == СЂР°Р·РјРµСЂ С„Р°Р№Р»Р° в†’ РЅРёРєР°РєРёС… РёР·РјРµРЅРµРЅРёР№.
        try:
            from PIL import Image as _PILImage
            import tempfile as _tempfile
            _im = _PILImage.open(str(logo_path))
            if _im.mode in ('RGBA', 'LA'):
                _bbox = _im.getchannel('A').getbbox()
                if _bbox and _bbox != (0, 0, _im.size[0], _im.size[1]):
                    _trimmed = _im.crop(_bbox)
                    _tmp = Path(_tempfile.gettempdir()) / f'_logo_trimmed_{os.getpid()}.png'
                    _trimmed.save(str(_tmp))
                    _pad_l, _pad_t = _bbox[0], _bbox[1]
                    _pad_r = _im.size[0] - _bbox[2]
                    _pad_b = _im.size[1] - _bbox[3]
                    print(f"[LOGO] РћР±СЂРµР·Р°РЅР° РїСЂРѕР·СЂР°С‡РЅР°СЏ СЂР°РјРєР°: L={_pad_l} T={_pad_t} R={_pad_r} B={_pad_b} в†’ {_bbox[2]-_bbox[0]}x{_bbox[3]-_bbox[1]}")
                    logger.info(f"Logo trim: bbox={_bbox}, padding L/T/R/B={_pad_l}/{_pad_t}/{_pad_r}/{_pad_b}, saved to {_tmp}")
                    logo_path = _tmp
        except Exception as _e:
            logger.warning(f"Auto-trim Р»РѕРіРѕ РїСЂРѕРїСѓС‰РµРЅ: {_e}")
    else:
        logger.info("Р›РѕРіРѕ overlay: РЅРµ РёСЃРїРѕР»СЊР·СѓРµС‚СЃСЏ")

    try:
        # Р­РўРђРџ 1: Р’РђР›РР”РђР¦РРЇ РџР›РђРќРђ
        audio_duration = validate_montage_plan(clips, audio_file)

        # Р­РўРђРџ 2: РђРќРђР›РР— Р“Р­РџРћР’ Р РџР•Р Р•РљР Р«РўРР™
        corrections = analyze_gaps(clips, audio_duration)

        temp_dir = Path('temp_processed')
        temp_dir.mkdir(exist_ok=True)
        logger.info(f"РЎРѕР·РґР°РЅР° РІСЂРµРјРµРЅРЅР°СЏ РїР°РїРєР°: {temp_dir.absolute()}")

        # РџСЂРёРјРµРЅСЏРµРј РєРѕСЂСЂРµРєС‚РёСЂРѕРІРєРё Рє clips
        corrected_clips = clips.copy()
        for corr in corrections:
            idx = corr['clip_index']
            if corr['type'] == 'start_gap':
                corrected_clips[idx] = {
                    **corrected_clips[idx],
                    'startTime': 0.0,
                    'original_startTime': corrected_clips[idx]['startTime']
                }
            elif corr['type'] == 'end_gap':
                corrected_clips[idx] = {
                    **corrected_clips[idx],
                    'endTime': audio_duration,
                    'original_endTime': corrected_clips[idx]['endTime']
                }
            elif corr['type'] == 'retime_extend':
                corrected_clips[idx] = {
                    **corrected_clips[idx],
                    'endTime': corrected_clips[idx]['endTime'] + corr['gap_size'],
                    'original_endTime': corrected_clips[idx]['endTime']
                }
            elif corr['type'] == 'trim_overlap':
                corrected_clips[idx] = {
                    **corrected_clips[idx],
                    'endTime': corr['new_end'],
                    'original_endTime': corrected_clips[idx]['endTime']
                }

        # Р­РўРђРџ 3: РџР РћР’Р•Р РљРђ РЎРЈР©Р•РЎРўР’РЈР®Р©РРҐ Р¤РђР™Р›РћР’
        logger.info("Р­РўРђРџ 3: РџР РћР’Р•Р РљРђ РЎРЈР©Р•РЎРўР’РЈР®Р©РРҐ Р¤РђР™Р›РћР’")
        existing_files = {}
        if not args.force_reprocess:
            print(f"\nрџ”Ќ РџСЂРѕРІРµСЂРєР° СЃСѓС‰РµСЃС‚РІСѓСЋС‰РёС… С„Р°Р№Р»РѕРІ...")
            _total_clips = len(corrected_clips)
            if IS_PIPE:
                print(f"PROGRESS:0/{_total_clips}", flush=True)
            _check_iter = corrected_clips if IS_PIPE else tqdm(
                corrected_clips, desc="   Checking", unit="clip",
                bar_format="{desc}: {bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]"
            )
            for _ci, clip in enumerate(_check_iter, 1):
                clip_id = clip['id']
                target_duration = clip['endTime'] - clip['startTime']
                output_file = temp_dir / f"processed_{clip_id}.mp4"

                if check_processed_file(output_file):
                    actual_dur = get_video_duration(output_file)
                    if abs(actual_dur - target_duration) < 0.1:
                        # РџСЂРё 1080p вЂ” РґРѕРїРѕР»РЅРёС‚РµР»СЊРЅРѕ РїСЂРѕРІРµСЂСЏРµРј С‡С‚Рѕ С„Р°Р№Р» СѓР¶Рµ РІ 1920x1080
                        if args.resolution == '1080':
                            w, h = get_video_resolution(output_file)
                            if w != 1920 or h != 1080:
                                logger.debug(f"Р¤Р°Р№Р» {clip_id} РЅРµ 1080p ({w}x{h}), РїРµСЂРµСЃРѕР·РґР°С‘Рј")
                                continue
                        if getattr(args, 'veo_audio_inline', False) and not has_audio_stream(output_file):
                            logger.debug(f"File {clip_id} has no audio stream in veo-audio-inline mode; reprocessing")
                            continue
                        existing_files[clip_id] = str(output_file)
                        logger.debug(f"Р¤Р°Р№Р» {clip_id} СѓР¶Рµ РіРѕС‚РѕРІ")

                if IS_PIPE:
                    print(f"PROGRESS:{_ci}/{_total_clips}", flush=True)

            logger.info(f"РќР°Р№РґРµРЅРѕ РіРѕС‚РѕРІС‹С… С„Р°Р№Р»РѕРІ: {len(existing_files)}")
            logger.info(f"РўСЂРµР±СѓСЋС‚ РѕР±СЂР°Р±РѕС‚РєРё: {len(corrected_clips) - len(existing_files)}")

            print(f"   вњ… РќР°Р№РґРµРЅРѕ РіРѕС‚РѕРІС‹С…: {len(existing_files)}")
            print(f"   рџ”„ РўСЂРµР±СѓСЋС‚ РѕР±СЂР°Р±РѕС‚РєРё: {len(corrected_clips) - len(existing_files)}")
        else:
            logger.info("Р РµР¶РёРј force_reprocess - РІСЃРµ С„Р°Р№Р»С‹ Р±СѓРґСѓС‚ РїРµСЂРµРѕР±СЂР°Р±РѕС‚Р°РЅС‹")
            print(f"\nвљ пёЏ  Р РµР¶РёРј --force-reprocess: РїРµСЂРµРѕР±СЂР°Р±РѕС‚РєР° РІСЃРµС… С„Р°Р№Р»РѕРІ")

        # Р­РўРђРџ 4: РћР‘Р РђР‘РћРўРљРђ РљР›РРџРћР’
        logger.info("Р­РўРђРџ 4: Р Р•РўРђР™РњРРќР“ Р¤Р РђР“РњР•РќРўРћР’")
        files_to_process = []
        for clip in corrected_clips:
            if clip['id'] not in existing_files:
                files_to_process.append(clip)

        # РџР°РїРєР° РґР»СЏ СЂРµС‚Р°Р№РјР»РµРЅРЅС‹С… С„СЂР°РіРјРµРЅС‚РѕРІ СЃ РѕСЂРёРіРёРЅР°Р»СЊРЅС‹Рј VEO Р°СѓРґРёРѕ

        # РљСѓРјСѓР»СЏС‚РёРІРЅС‹Р№ С‚СЂРµРєРµСЂ РґСЂРёС„С‚Р°: СЂР°Р·РЅРёС†Р° ОЈ(actual) - ОЈ(planned).
        # РџСЂРё СЂРµС‚Р°Р№РјРёРЅРіРµ РєР°Р¶РґРѕРіРѕ СЃР»РµРґСѓСЋС‰РµРіРѕ РєР»РёРїР° РІС‹С‡РёС‚Р°РµРј РЅР°РєРѕРїР»РµРЅРЅС‹Р№ РґСЂРёС„С‚ РёР· target_duration,
        # С‡С‚РѕР±С‹ РёС‚РѕРіРѕРІР°СЏ СЃСѓРјРјР° РєР»РёРїРѕРІ С‚РѕС‡РЅРѕ СЃРѕРІРїР°Р»Р° СЃ РґР»РёРЅРѕР№ Р°СѓРґРёРѕ (Р±РµР· re-encode РІ С„РёРЅР°Р»Рµ).
        cumulative_planned = 0.0   # СЃСѓРјРјР° target_duration РёР· РїР»Р°РЅР°
        cumulative_actual  = 0.0   # СЃСѓРјРјР° С„Р°РєС‚РёС‡РµСЃРєРёС… РґР»РёРЅ РІС‹С…РѕРґРЅС‹С… РєР»РёРїРѕРІ

        if files_to_process:
            logger.info(f"РўСЂРµР±СѓСЋС‚ СЂРµС‚Р°Р№РјРёРЅРіР°: {len(files_to_process)} С„Р°Р№Р»РѕРІ")
            print(f"\nрџ”„ Р РµС‚Р°Р№РјРёРЅРі {len(files_to_process)} С„СЂР°РіРјРµРЅС‚РѕРІ (СЃ РєРѕСЂСЂРµРєС†РёРµР№ РґСЂРёС„С‚Р°)...", flush=True)
            files_to_process_ids = {clip['id'] for clip in files_to_process}
            _retime_total = len(files_to_process)
            _retime_done = 0
            if IS_PIPE:
                print(f"PROGRESS:0/{_retime_total}", flush=True)
                print(f"   Р’СЃРµРіРѕ Рє СЂРµС‚Р°Р№РјРёРЅРіСѓ: {_retime_total}", flush=True)
            _retime_pbar = None if IS_PIPE else tqdm(
                total=_retime_total, desc="   Р РµС‚Р°Р№РјРёРЅРі", unit="С„СЂ",
                bar_format="{desc}: {bar}| {n}/{total} С„СЂР°РіРјРµРЅС‚РѕРІ [{elapsed}<{remaining}]"
            )
            # Auto-detect target resolution: РµСЃР»Рё РІ vid_img/ РµСЃС‚СЊ 1080p РєР»РёРїС‹,
            # С‚Рѕ 720p РєР»РёРїС‹ (СѓРїР°РІС€РёРµ Р°РїСЃРєРµР№Р»С‹) Р°РІС‚РѕРјР°С‚РёС‡РµСЃРєРё РјР°СЃС€С‚Р°Р±РёСЂСѓСЋС‚СЃСЏ РґРѕ 1080p.
            _auto_target_1080 = False
            _vid_img_prescan = Path('vid_img')
            if _vid_img_prescan.exists():
                _max_prescan_h = 0
                for _pf in _vid_img_prescan.glob('*.mp4'):
                    _, _ph = get_video_resolution(str(_pf))
                    if _ph > _max_prescan_h:
                        _max_prescan_h = _ph
                if _max_prescan_h >= 1080:
                    _auto_target_1080 = True
                    logger.info(f"Auto-upscale: detected {_max_prescan_h}px source clips вЂ” sub-1080p clips will be scaled to 1080p")
                    print(f"   РђРІС‚Рѕ-Р°РїСЃРєРµР№Р»: РЅР°Р№РґРµРЅС‹ {_max_prescan_h}p РєР»РёРїС‹ вЂ” 720p РєР»РёРїС‹ Р±СѓРґСѓС‚ РѕС‚РјР°СЃС€С‚Р°Р±РёСЂРѕРІР°РЅС‹ РґРѕ 1080p", flush=True)
            # РС‚РµСЂРёСЂСѓРµРј Р’РЎР• РєР»РёРїС‹ РІ РїРѕСЂСЏРґРєРµ РјРѕРЅС‚Р°Р¶РЅРѕРіРѕ РїР»Р°РЅР° РґР»СЏ РєРѕСЂСЂРµРєС‚РЅРѕРіРѕ С‚СЂРµРєРёРЅРіР° РґСЂРёС„С‚Р°.
            # Р”Р»СЏ СѓР¶Рµ РіРѕС‚РѕРІС‹С… РєР»РёРїРѕРІ вЂ” С‚РѕР»СЊРєРѕ С‡РёС‚Р°РµРј С„Р°РєС‚РёС‡РµСЃРєСѓСЋ РґР»РёРЅСѓ Рё РѕР±РЅРѕРІР»СЏРµРј СЃС‡С‘С‚С‡РёРєРё.
            for clip_idx, clip in enumerate(corrected_clips):
                    clip_id = clip['id']

                    # Chain extend detection: clip N is extend if chain_id == chain_id of clip N-1
                    is_chain_extend = False
                    if clip_idx > 0 and clip.get('chain_id'):
                        prev_clip = corrected_clips[clip_idx - 1]
                        if prev_clip.get('chain_id') == clip['chain_id']:
                            is_chain_extend = True
                            logger.info(f"Clip {clip_id}: chain extend (chain_id={clip['chain_id']}) вЂ” will trim first frame + mute audio")
                    target_duration = clip['endTime'] - clip['startTime']
                    output_file = temp_dir / f"processed_{clip_id}.mp4"

                    if clip_id not in files_to_process_ids:
                        # Р¤Р°Р№Р» СѓР¶Рµ РіРѕС‚РѕРІ вЂ” РѕР±РЅРѕРІР»СЏРµРј С‚СЂРµРєРµСЂС‹ Р±РµР· РїРµСЂРµРєРѕРґРёСЂРѕРІР°РЅРёСЏ
                        actual_dur = get_video_duration(output_file)
                        cumulative_planned += target_duration
                        cumulative_actual  += actual_dur
                        continue

                    # РљСѓРјСѓР»СЏС‚РёРІРЅС‹Р№ РґСЂРёС„С‚: РµСЃР»Рё РїРѕР»РѕР¶РёС‚РµР»СЊРЅС‹Р№ вЂ” РјС‹ СѓР¶Рµ "СѓР±РµР¶Р°Р»Рё" РІРїРµСЂС‘Рґ,
                    # РЅСѓР¶РЅРѕ СѓРєРѕСЂРѕС‚РёС‚СЊ С‚РµРєСѓС‰РёР№ РєР»РёРї; РµСЃР»Рё РѕС‚СЂРёС†Р°С‚РµР»СЊРЅС‹Р№ вЂ” РјС‹ РѕС‚СЃС‚Р°С‘Рј.
                    drift = cumulative_actual - cumulative_planned
                    adjusted_target = max(0.1, target_duration - drift)
                    if abs(drift) > 0.001:
                        logger.debug(f"Clip {clip_id}: drift={drift:+.4f}СЃ в†’ target {target_duration:.4f}СЃ в†’ adjusted {adjusted_target:.4f}СЃ")

                    # РћРїСЂРµРґРµР»СЏРµРј РёСЃС‚РѕС‡РЅРёРє: vid_img/{id:03d}.mp4 в†’ clip['file'] в†’ fallback
                    source_file = None
                    vid_img_dir = Path('vid_img')
                    for fmt in [f'{clip_id:03d}', str(clip_id)]:
                        for ext in ('mp4', 'mov', 'png', 'jpg', 'jpeg', 'webp'):
                            candidate = vid_img_dir / f'{fmt}.{ext}'
                            if candidate.exists():
                                source_file = str(candidate)
                                break
                        if source_file:
                            break
                    if not source_file:
                        cf = clip.get('file')
                        if cf and Path(cf).exists():
                            source_file = cf
                    if not source_file:
                        # Slideshow fallback: look for image in generated/
                        gen_dir = Path('generated')
                        for fmt in [f'{clip_id:03d}', str(clip_id)]:
                            for ext in ('png', 'jpg', 'jpeg', 'webp'):
                                candidate = gen_dir / f'{fmt}.{ext}'
                                if candidate.exists():
                                    source_file = str(candidate)
                                    break
                            if source_file:
                                break
                    if not source_file:
                        logger.error(f"Clip {clip_id}: С„Р°Р№Р» РЅРµ РЅР°Р№РґРµРЅ (clip['file']={clip.get('file')}, vid_img/ РїСѓСЃС‚Рѕ)")
                        print(f"\nвќЊ Clip {clip_id}: С„Р°Р№Р» РЅРµ РЅР°Р№РґРµРЅ! РџСЂРѕРІРµСЂСЊС‚Рµ vid_img/")
                        sys.exit(1)

                    try:
                        # Per-clip upscale: СЏРІРЅС‹Р№ -r 1080, Р»РёР±Рѕ Р°РІС‚Рѕ РµСЃР»Рё РІ РїСЂРѕРµРєС‚Рµ СЃРјРµС€Р°РЅРЅС‹Рµ СЂР°Р·СЂРµС€РµРЅРёСЏ
                        if Path(source_file).suffix.lower() not in _IMAGE_EXTENSIONS:
                            _, _src_h = get_video_resolution(source_file)
                            _per_clip_upscale = (args.resolution == '1080') or (_auto_target_1080 and 0 < _src_h < 1080)
                        else:
                            _per_clip_upscale = (args.resolution == '1080')
                        _is_chain_clip = bool(clip.get('chain_id'))
                        processing_target = target_duration if _is_chain_clip else adjusted_target
                        actual_dur = process_video(source_file, str(output_file), processing_target,
                                    encoder_type, codec, args.bitrate, logo_path=logo_path,
                                    blur_borders=args.blur_borders,
                                    keep_audio=getattr(args, 'veo_audio_inline', False),
                                    upscale_1080=_per_clip_upscale,
                                    fps=getattr(args, 'fps', 60),
                                    is_chain_extend=is_chain_extend,
                                    force_trim_to_target=_is_chain_clip)
                        if actual_dur is None:
                            actual_dur = get_video_duration(output_file) if Path(output_file).exists() else None
                        if actual_dur is None:
                            # Corrupt video вЂ” try static fallback from generated/ image
                            _gen_dir = Path(source_file).parent.parent / 'generated'
                            _fallback_img = None
                            for _ext in ('.png', '.jpg', '.jpeg', '.webp'):
                                _candidate = _gen_dir / f"{clip_id:03d}{_ext}"
                                if _candidate.exists() and _candidate.stat().st_size > 1000:
                                    _fallback_img = str(_candidate)
                                    break
                            if _fallback_img:
                                logger.warning(f"Clip {clip_id}: corrupt video {source_file} вЂ” fallback to image {_fallback_img}")
                                print(f"   вљ пёЏ  Clip {clip_id}: Р±РёС‚С‹Р№ РІРёРґРµРѕ в†’ Р·СѓРј РёР· РєР°СЂС‚РёРЅРєРё")
                                _image_to_zoom_video(_fallback_img, str(output_file), processing_target,
                                                     encoder_type, codec, args.bitrate, logo_path=logo_path,
                                                     fps=getattr(args, 'fps', 60),
                                                     keep_audio=getattr(args, 'veo_audio_inline', False))
                                actual_dur = get_video_duration(output_file) if Path(output_file).exists() else processing_target
                                if actual_dur is None:
                                    actual_dur = processing_target
                            else:
                                raise RuntimeError(f"Clip {clip_id}: corrupt video {source_file} and no fallback image in generated/")
                        existing_files[clip_id] = str(output_file)
                        cumulative_planned += target_duration
                        cumulative_actual  += actual_dur

                        _retime_done += 1
                        if IS_PIPE:
                            print(f"   Р РµС‚Р°Р№РјРёРЅРі: {_retime_done}/{_retime_total} (clip {clip_id})", flush=True)
                        elif _retime_pbar is not None:
                            _retime_pbar.update(1)
                    except Exception as e:
                        logger.error(f"РљСЂРёС‚РёС‡РµСЃРєР°СЏ РѕС€РёР±РєР° РѕР±СЂР°Р±РѕС‚РєРё clip {clip_id}: {e}")
                        print(f"\nвќЊ РћС€РёР±РєР° РѕР±СЂР°Р±РѕС‚РєРё: {e}")
                        sys.exit(1)

            if _retime_pbar is not None:
                _retime_pbar.close()
            total_drift = cumulative_actual - cumulative_planned
            logger.info(f"Р РµС‚Р°Р№РјРёРЅРі Р·Р°РІРµСЂС€С‘РЅ. РЎСѓРјРјР°СЂРЅС‹Р№ РґСЂРёС„С‚ РїРѕСЃР»Рµ РєРѕСЂСЂРµРєС†РёРё: {total_drift:+.3f}СЃ")
            print(f"   рџ“Љ РЎСѓРјРјР°СЂРЅС‹Р№ РґСЂРёС„С‚ РїРѕСЃР»Рµ РєРѕСЂСЂРµРєС†РёРё: {total_drift:+.3f}СЃ")
        else:
            logger.info("Р’СЃРµ С„Р°Р№Р»С‹ СѓР¶Рµ РѕР±СЂР°Р±РѕС‚Р°РЅС‹")
            print(f"\nвњ… Р’СЃРµ С„Р°Р№Р»С‹ СѓР¶Рµ РѕР±СЂР°Р±РѕС‚Р°РЅС‹")

        # Р¤РѕСЂРјРёСЂСѓРµРј СѓРїРѕСЂСЏРґРѕС‡РµРЅРЅС‹Р№ СЃРїРёСЃРѕРє РѕР±СЂР°Р±РѕС‚Р°РЅРЅС‹С… С„Р°Р№Р»РѕРІ
        print(f"\nрџ“¦ Р¤РѕСЂРјРёСЂРѕРІР°РЅРёРµ С„РёРЅР°Р»СЊРЅРѕРіРѕ СЃРїРёСЃРєР° С„Р°Р№Р»РѕРІ...")
        logger.info("Р¤РѕСЂРјРёСЂРѕРІР°РЅРёРµ С„РёРЅР°Р»СЊРЅРѕРіРѕ СЃРїРёСЃРєР° С„Р°Р№Р»РѕРІ")
        processed_files_ordered = []

        for clip in corrected_clips:
            clip_id = clip['id']
            processed_files_ordered.append(existing_files[clip_id])

        logger.info(f"Р’СЃРµРіРѕ С„Р°Р№Р»РѕРІ РґР»СЏ СЃРєР»РµР№РєРё: {len(processed_files_ordered)}")
        print(f"   вњ… Р’СЃРµРіРѕ С„Р°Р№Р»РѕРІ РґР»СЏ СЃРєР»РµР№РєРё: {len(processed_files_ordered)}")

        # Р­РўРђРџ 5: Р“Р РЈРџРџРћР’РђРЇ РЎРљР›Р•Р™РљРђ
        temp_video = temp_dir / 'concat_video.mp4'
        group_concat(processed_files_ordered, temp_video, temp_dir, args.group_size, sub_path=_sub_path, encoder_type=encoder_type, bitrate=args.bitrate, total_duration=audio_duration)

        # Р­РўРђРџ 6: РђР’РўРћРРЎРџР РђР’Р›Р•РќРР• Р¤РРќРђР›Р¬РќРћР™ РЎРРќРҐР РћРќРР—РђР¦РР
        if audio_file is not None:
            temp_video = fix_video_audio_sync(temp_video, audio_file, temp_dir,
                                              encoder_type, codec, args.bitrate)
        else:
            logger.info("Р­РўРђРџ 6: РїСЂРѕРїСѓСЃРє (РЅРµС‚ РЅР°СЂР°С†РёРё, veo-audio-inline СЂРµР¶РёРј)")

        # Р­РўРђРџ 7: РР—Р’Р›Р•Р§Р•РќРР• РћР РР“РРќРђР›Р¬РќРћР“Рћ РђРЈР”РРћ
        logger.info("Р­РўРђРџ 7: РР—Р’Р›Р•Р§Р•РќРР• РћР РР“РРќРђР›Р¬РќРћР“Рћ РђРЈР”РРћ")
        print(f"\nрџ”Љ РР·РІР»РµС‡РµРЅРёРµ РѕСЂРёРіРёРЅР°Р»СЊРЅРѕРіРѕ Р°СѓРґРёРѕ...")
        original_audio = args.output.replace('.mp4', '_original_audio.wav')
        try:
            subprocess.run([FFMPEG, '-y', '-i', str(temp_video),
                           '-vn', '-acodec', 'pcm_s16le', original_audio],
                          check=True, capture_output=True, **SUBPROCESS_FLAGS)
            logger.info(f"РћСЂРёРіРёРЅР°Р»СЊРЅРѕРµ Р°СѓРґРёРѕ РёР·РІР»РµС‡РµРЅРѕ: {original_audio}")
            print(f"   вњ… {original_audio}")
        except Exception as e:
            logger.warning(f"РќРµ СѓРґР°Р»РѕСЃСЊ РёР·РІР»РµС‡СЊ РѕСЂРёРіРёРЅР°Р»СЊРЅРѕРµ Р°СѓРґРёРѕ: {e}")
            print(f"   вљ пёЏ  РќРµ СѓРґР°Р»РѕСЃСЊ")

        # Р­РўРђРџ 8: Р—РђРњР•РќРђ РђРЈР”РРћ (РёР»Рё РєРѕРїРёСЂРѕРІР°РЅРёРµ temp_video РІ veo-audio-inline СЂРµР¶РёРјРµ Р±РµР· РЅР°СЂР°С†РёРё)
        if audio_file is not None:
            logger.info("Р­РўРђРџ 8: Р—РђРњР•РќРђ РђРЈР”РРћ РќРђ РћР—Р’РЈР§РљРЈ")

            print(f"\nрџЋµ Р—Р°РјРµРЅР° Р°СѓРґРёРѕ РЅР° РѕР·РІСѓС‡РєСѓ...")
            pre_encoded_audio = temp_dir / 'narration_aac.m4a'
            if IS_PIPE:
                print(f"PROGRESS:0/2", flush=True)
            print(f"   РЁР°Рі 1/2: РљРѕРґРёСЂРѕРІР°РЅРёРµ Р°СѓРґРёРѕ WAV в†’ AAC...")
            cmd_aac = [FFMPEG, '-y', '-i', audio_file,
                       '-c:a', 'aac', '-b:a', '192k', str(pre_encoded_audio)]
            aac_duration = audio_duration if audio_duration else None
            try:
                run_ffmpeg_with_progress(cmd_aac, aac_duration, "AAC РєРѕРґРёСЂРѕРІР°РЅРёРµ")
                logger.info(f"РђСѓРґРёРѕ РїСЂРµРґРІР°СЂРёС‚РµР»СЊРЅРѕ Р·Р°РєРѕРґРёСЂРѕРІР°РЅРѕ")
            except subprocess.CalledProcessError as e:
                logger.error(f"РћС€РёР±РєР° РєРѕРґРёСЂРѕРІР°РЅРёСЏ Р°СѓРґРёРѕ: {e}")
                raise

            print(f"   РЁР°Рі 2/2: РЎР±РѕСЂРєР° РІРёРґРµРѕ + Р°СѓРґРёРѕ (Р±РµР· РїРµСЂРµРєРѕРґРёСЂРѕРІР°РЅРёСЏ)...")
            cmd_mux = [FFMPEG, '-y', '-i', str(temp_video), '-i', str(pre_encoded_audio),
                       '-map', '0:v', '-map', '1:a', '-c:v', 'copy',
                       '-c:a', 'copy', '-shortest', args.output]

            run_ffmpeg_with_progress(cmd_mux, aac_duration, "РЎР±РѕСЂРєР°")
            logger.info(f"Р¤РёРЅР°Р»СЊРЅС‹Р№ С„Р°Р№Р» СЃРѕР·РґР°РЅ: {args.output}")

            try:
                pre_encoded_audio.unlink()
            except:
                pass
        else:
            # veo-audio-inline Р±РµР· РЅР°СЂР°С†РёРё: temp_video СѓР¶Рµ СЃРѕРґРµСЂР¶РёС‚ СЂРµС‚Р°Р№РјР»РµРЅРЅС‹Р№ VEO Р·РІСѓРє
            logger.info("Р­РўРђРџ 8: РїСЂРѕРїСѓСЃРє Р·Р°РјРµРЅС‹ Р°СѓРґРёРѕ вЂ” РєРѕРїРёСЂСѓРµРј temp_video СЃ VEO Р·РІСѓРєРѕРј РІ РІС‹С…РѕРґРЅРѕР№ С„Р°Р№Р»")
            print(f"\n[OK] VEO audio inline: СЃРѕС…СЂР°РЅСЏРµРј VEO Р·РІСѓРє РІ С„РёРЅР°Р»СЊРЅРѕРј РІРёРґРµРѕ...")
            shutil.copy2(str(temp_video), args.output)
            logger.info(f"Р¤РёРЅР°Р»СЊРЅС‹Р№ С„Р°Р№Р» СЃРѕР·РґР°РЅ (VEO audio): {args.output}")

        # Р­РўРђРџ 9: РћР§РРЎРўРљРђ
        logger.info("Р­РўРђРџ 9: РћР§РРЎРўРљРђ")
        ask_delete_temp_folder(temp_dir, args.no_cleanup)

        # Р¤РРќРђР›
        print("\n" + "="*80)
        print("вњ… Р“РћРўРћР’Рћ!")
        print("="*80)
        print(f"\nрџ“№ Р’РёРґРµРѕ: {args.output}")
        print(f"   вЂў FPS: {getattr(args, 'fps', 60)}")
        print(f"   вЂў Р‘РёС‚СЂРµР№С‚: {args.bitrate}")
        print(f"   вЂў РљРѕРґРµРє: {codec} ({encoder_type.upper()})")
        print(f"\nрџ”Љ РћСЂРёРіРёРЅР°Р»СЊРЅРѕРµ Р°СѓРґРёРѕ: {original_audio}")
        print(f"рџЋµ РћР·РІСѓС‡РєР°: {audio_file if audio_file else '(VEO audio inline вЂ” РЅР°СЂР°С†РёСЏ РЅРµ РёСЃРїРѕР»СЊР·РѕРІР°Р»Р°СЃСЊ)'}")
        print(f"\nрџ“ќ Р›РѕРі-С„Р°Р№Р»: {log_file}")
        print("="*80)

        logger.info("="*80)
        logger.info("РЎРљР РРџРў Р—РђР’Р•Р РЁРЃРќ РЈРЎРџР•РЁРќРћ")
        logger.info("="*80)

    except Exception as e:
        logger.critical("РљР РРўРР§Р•РЎРљРђРЇ РћРЁРР‘РљРђ!")
        logger.critical(f"РћС€РёР±РєР°: {e}")
        logger.critical(traceback.format_exc())
        print(f"\nвќЊ РљР РРўРР§Р•РЎРљРђРЇ РћРЁРР‘РљРђ: {e}")
        print(f"\nрџ“ќ РџРѕРґСЂРѕР±РЅРѕСЃС‚Рё РІ Р»РѕРі-С„Р°Р№Р»Рµ: {log_file}")
        sys.exit(1)

if __name__ == '__main__':
    main()
