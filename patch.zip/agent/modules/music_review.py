"""
Music Review GUI — Tk + pygame.

Открывает music_plan.json, показывает список треков. Для каждого:
  • Play/Stop preview одного из 2 вариантов (Suno даёт 2 варианта)
  • Кнопка «Вариант 1» / «Вариант 2» — переключение какой пойдёт в финал
  • Slider громкости (-30 ... 0 dB)
  • Slider fade-in / fade-out (мс)
  • Кнопка «Сохранить» — пишет volume_db / fade_*_ms / selected_variant в music_plan.json

Использование:
    python -m modules.music_review <project_dir>
"""
from __future__ import annotations

import json
import logging
import sys
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import ttk, messagebox

# pygame для воспроизведения mp3 — импортируем лениво, чтобы import GUI не падал
# когда pygame не установлен (например, в headless-режиме).
_pygame = None
def _get_pygame():
    global _pygame
    if _pygame is None:
        try:
            import pygame  # type: ignore
            pygame.mixer.init()
            _pygame = pygame
        except ImportError:
            raise RuntimeError(
                "pygame не установлен. Запустите:\n"
                "    pip install pygame-ce\n"
                "(или из agent/requirements.txt)"
            )
    return _pygame


# =============================================================================
# Track row widget
# =============================================================================

class TrackRow(ttk.Frame):
    """Одна строка GUI = один трек из music_plan."""

    def __init__(self, master, track: dict, project_dir: Path, on_change):
        super().__init__(master, padding=6, relief='ridge', borderwidth=1)
        self.track = track
        self.project_dir = project_dir
        self.on_change = on_change   # callback при изменении любого поля
        self._playing_variant = None  # 1 / 2 / None

        self._build()

    def _build(self):
        # Header: ID + title + duration
        tid = self.track.get('id', '?')
        title = self.track.get('title', '') or self.track.get('mood', '') or 'Untitled'
        st = float(self.track.get('startTime', 0))
        en = float(self.track.get('endTime', 0))
        header = ttk.Label(
            self, text=f"#{tid}  {title}    {st:.1f}-{en:.1f}с ({en-st:.0f}с)",
            font=('Segoe UI', 10, 'bold'),
        )
        header.grid(row=0, column=0, columnspan=8, sticky='w', pady=(0, 4))

        # Mood / genre / energy
        mood = self.track.get('mood', '')
        genre = self.track.get('genre', '')
        energy = self.track.get('energy_arc') or self.track.get('energy', '')
        sub = f"{mood}  •  {genre}  •  energy: {energy}"
        ttk.Label(self, text=sub, foreground='#666').grid(
            row=1, column=0, columnspan=8, sticky='w', pady=(0, 4)
        )

        # Prompt (read-only multi-line)
        prompt = self.track.get('prompt', '')
        ttk.Label(self, text=f"Prompt: {prompt}", wraplength=900, foreground='#444').grid(
            row=2, column=0, columnspan=8, sticky='w', pady=(0, 6)
        )

        # Playback row: per-variant Play + Select radio
        clip_ids = self.track.get('suno_clip_ids', [])
        durations = self.track.get('suno_durations', [])
        variant_count = max(1, len(clip_ids), len(durations))
        try:
            selected_variant = int(self.track.get('selected_variant', 1))
        except (TypeError, ValueError):
            selected_variant = 1
        if selected_variant < 1 or selected_variant > variant_count:
            selected_variant = 1
        self.selected_var = tk.IntVar(value=selected_variant)

        variant_rows = max(1, (variant_count + 1) // 2)
        for v in range(1, variant_count + 1):
            present = len(clip_ids) >= v
            d = durations[v-1] if len(durations) >= v else 0
            txt = f"v{v}  ▶ Play"
            if present:
                txt = f"v{v}  ▶ Play ({d:.0f}с)"
            row = 3 + ((v - 1) // 2)
            col = ((v - 1) % 2) * 2
            btn = ttk.Button(
                self, text=txt, width=18,
                state=('normal' if present else 'disabled'),
                command=lambda vv=v: self._toggle_play(vv),
            )
            btn.grid(row=row, column=col, padx=4, pady=2, sticky='w')
            setattr(self, f'_play_btn_v{v}', btn)

            radio = ttk.Radiobutton(
                self, text=f"использовать v{v}",
                variable=self.selected_var, value=v,
                state=('normal' if present else 'disabled'),
                command=self._on_variant_change,
            )
            radio.grid(row=row, column=col + 1, padx=4, sticky='w')

        controls_row = 3 + variant_rows

        # Volume slider
        ttk.Label(self, text="Громкость музыки (dB):").grid(row=controls_row, column=0, sticky='w', pady=(8, 0))
        self.volume_var = tk.IntVar(value=int(self.track.get('volume_db', -21)))
        self.volume_lbl = ttk.Label(self, text=f"{self.volume_var.get()} dB")
        self.volume_lbl.grid(row=controls_row, column=4, sticky='w', pady=(8, 0))
        vs = ttk.Scale(
            self, from_=-30, to=0, orient='horizontal',
            command=self._on_volume_change,
        )
        vs.set(self.volume_var.get())
        vs.grid(row=controls_row, column=1, columnspan=3, sticky='ew', pady=(8, 0))

        # Fade in / out
        ttk.Label(self, text="Fade-in (мс):").grid(row=controls_row + 1, column=0, sticky='w', pady=(2, 0))
        self.fadein_var = tk.IntVar(value=int(self.track.get('fade_in_ms', 1500)))
        self.fadein_lbl = ttk.Label(self, text=f"{self.fadein_var.get()}")
        self.fadein_lbl.grid(row=controls_row + 1, column=4, sticky='w', pady=(2, 0))
        fis = ttk.Scale(
            self, from_=0, to=6000, orient='horizontal',
            command=lambda v: self._on_fade_change('fadein', v),
        )
        fis.set(self.fadein_var.get())
        fis.grid(row=controls_row + 1, column=1, columnspan=3, sticky='ew', pady=(2, 0))

        ttk.Label(self, text="Fade-out (мс):").grid(row=controls_row + 2, column=0, sticky='w', pady=(2, 0))
        self.fadeout_var = tk.IntVar(value=int(self.track.get('fade_out_ms', 2500)))
        self.fadeout_lbl = ttk.Label(self, text=f"{self.fadeout_var.get()}")
        self.fadeout_lbl.grid(row=controls_row + 2, column=4, sticky='w', pady=(2, 0))
        fos = ttk.Scale(
            self, from_=0, to=6000, orient='horizontal',
            command=lambda v: self._on_fade_change('fadeout', v),
        )
        fos.set(self.fadeout_var.get())
        fos.grid(row=controls_row + 2, column=1, columnspan=3, sticky='ew', pady=(2, 0))

        # Кнопка skip — выкинуть трек из плана (тишина в этом эпизоде)
        skip_btn = ttk.Button(self, text="🔇 Заглушить трек", command=self._on_skip)
        skip_btn.grid(row=controls_row + 3, column=0, columnspan=2, sticky='w', pady=(6, 0))

        # Stretch
        for c in range(8):
            self.columnconfigure(c, weight=1)

    # ---- Event handlers ----

    def _toggle_play(self, variant: int):
        try:
            pygame = _get_pygame()
        except RuntimeError as e:
            messagebox.showerror("pygame", str(e))
            return

        if self._playing_variant == variant:
            pygame.mixer.music.stop()
            self._playing_variant = None
            getattr(self, f'_play_btn_v{variant}').config(text=f"v{variant}  ▶ Play")
            return

        # Стоп предыдущего, если был
        if self._playing_variant:
            pygame.mixer.music.stop()
            getattr(self, f'_play_btn_v{self._playing_variant}').config(
                text=f"v{self._playing_variant}  ▶ Play"
            )

        track_id = self.track.get('id')
        path = self.project_dir / 'music' / 'raw' / str(track_id) / f'v{variant}.mp3'
        if not path.exists():
            messagebox.showwarning("Нет файла", f"Не найден: {path}")
            return

        try:
            pygame.mixer.music.load(str(path))
            # Громкость в pygame: 0.0..1.0. Применяем dB
            vol_db = self.volume_var.get()
            pygame.mixer.music.set_volume(_db_to_linear(vol_db))
            pygame.mixer.music.play()
        except Exception as e:
            messagebox.showerror("pygame", f"Не удалось проиграть: {e}")
            return

        self._playing_variant = variant
        getattr(self, f'_play_btn_v{variant}').config(text=f"v{variant}  ⏹ Stop")

    def _on_volume_change(self, val):
        v = int(float(val))
        self.volume_var.set(v)
        self.volume_lbl.config(text=f"{v} dB")
        # Применить к текущему playback в реальном времени
        if self._playing_variant:
            try:
                _get_pygame().mixer.music.set_volume(_db_to_linear(v))
            except Exception:
                pass
        self._notify_change()

    def _on_fade_change(self, kind, val):
        v = int(float(val))
        if kind == 'fadein':
            self.fadein_var.set(v)
            self.fadein_lbl.config(text=f"{v}")
        else:
            self.fadeout_var.set(v)
            self.fadeout_lbl.config(text=f"{v}")
        self._notify_change()

    def _on_variant_change(self):
        self._notify_change()

    def _on_skip(self):
        if not messagebox.askyesno(
            "Заглушить",
            f"Сделать трек #{self.track.get('id')} пустым (тишина) в финальном видео?\n"
            f"Музыка не будет наложена в этот эпизод."
        ):
            return
        self.track['genre'] = 'silence'
        self._notify_change()

    def _notify_change(self):
        # Вернуть текущие значения в track dict
        self.track['volume_db'] = self.volume_var.get()
        self.track['fade_in_ms'] = self.fadein_var.get()
        self.track['fade_out_ms'] = self.fadeout_var.get()
        self.track['selected_variant'] = self.selected_var.get()
        if self.on_change:
            self.on_change()


# =============================================================================
# Main window
# =============================================================================

class MusicReviewApp(tk.Tk):
    def __init__(self, project_dir: Path):
        super().__init__()
        self.project_dir = Path(project_dir)
        self.plan_path = self.project_dir / 'music_plan.json'

        self.title(f"VARAGENT — Music Review — {self.project_dir.name}")
        self.geometry("1100x780")

        self._dirty = False

        self._load_plan()
        self._build()

    def _load_plan(self):
        if not self.plan_path.exists():
            messagebox.showerror("Нет плана", f"Не найден music_plan.json:\n{self.plan_path}")
            self.destroy()
            return
        data = json.loads(self.plan_path.read_text(encoding='utf-8-sig'))
        self.plan = data.get('music_plan', data)

    def _build(self):
        # Top bar
        top = ttk.Frame(self, padding=8)
        top.pack(side='top', fill='x')

        ttk.Label(
            top, text=f"Проект: {self.project_dir.name}    "
                     f"Треков: {len(self.plan.get('tracks', []))}    "
                     f"Длительность: {self.plan.get('audioDuration', 0):.0f}с",
            font=('Segoe UI', 10, 'bold'),
        ).pack(side='left')

        ttk.Button(top, text="💾 Сохранить", command=self._save).pack(side='right', padx=4)
        ttk.Button(top, text="↻ Перечитать", command=self._reload).pack(side='right', padx=4)

        # Global volume
        gvol = ttk.Frame(self, padding=(8, 0))
        gvol.pack(side='top', fill='x')
        ttk.Label(gvol, text="Глобальная громкость музыки (dB):").pack(side='left')
        self.global_volume_var = tk.IntVar(value=int(self.plan.get('global_volume_db', -21)))
        self.global_volume_lbl = ttk.Label(gvol, text=f"{self.global_volume_var.get()} dB")
        self.global_volume_lbl.pack(side='right', padx=4)
        gs = ttk.Scale(
            gvol, from_=-30, to=0, orient='horizontal', length=400,
            command=self._on_global_volume,
        )
        gs.set(self.global_volume_var.get())
        gs.pack(side='left', fill='x', expand=True, padx=8)

        # Tip
        ttk.Label(
            self, padding=(8, 4),
            text="💡 Совет: для сторителлинга оптимально -18..-22 dB. "
                 "Side-chain ducking автоматически приглушит музыку под голосом.",
            foreground='#0a6',
        ).pack(side='top', fill='x')

        # Scrollable list of tracks
        canvas_frame = ttk.Frame(self)
        canvas_frame.pack(side='top', fill='both', expand=True, padx=8, pady=8)

        canvas = tk.Canvas(canvas_frame, borderwidth=0, highlightthickness=0)
        vsb = ttk.Scrollbar(canvas_frame, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)

        list_frame = ttk.Frame(canvas)
        canvas.create_window((0, 0), window=list_frame, anchor='nw')

        def _on_resize(event):
            canvas.itemconfig(canvas.find_all()[0], width=event.width)
        canvas.bind('<Configure>', _on_resize)

        def _on_frame_config(_):
            canvas.configure(scrollregion=canvas.bbox('all'))
        list_frame.bind('<Configure>', _on_frame_config)

        # Mouse wheel
        def _on_mousewheel(e):
            canvas.yview_scroll(-int(e.delta / 120), 'units')
        canvas.bind_all('<MouseWheel>', _on_mousewheel)

        # Track rows
        self.rows: list[TrackRow] = []
        for t in self.plan.get('tracks', []):
            row = TrackRow(list_frame, t, self.project_dir, on_change=self._mark_dirty)
            row.pack(fill='x', pady=4)
            self.rows.append(row)

        # Bottom status bar
        self.status_var = tk.StringVar(value="Готов к работе")
        status = ttk.Label(self, textvariable=self.status_var, padding=4, relief='sunken')
        status.pack(side='bottom', fill='x')

    # ---- Actions ----

    def _on_global_volume(self, val):
        v = int(float(val))
        self.global_volume_var.set(v)
        self.global_volume_lbl.config(text=f"{v} dB")
        self._mark_dirty()

    def _mark_dirty(self):
        self._dirty = True
        self.status_var.set("⚠️  Есть несохранённые изменения — нажми «Сохранить»")

    def _save(self):
        # Сбор плана из rows
        self.plan['global_volume_db'] = self.global_volume_var.get()
        # tracks уже модифицированы in-place через TrackRow._notify_change

        wrapped = {'music_plan': self.plan}
        self.plan_path.write_text(
            json.dumps(wrapped, indent=2, ensure_ascii=False),
            encoding='utf-8',
        )

        # Перенести выбранные варианты в music/<id>.mp3
        try:
            from modules.music_orchestrator import MusicOrchestrator
            orch = MusicOrchestrator(project_dir=self.project_dir, plan_path=self.plan_path)
            for t in self.plan.get('tracks', []):
                tid = t.get('id')
                v = int(t.get('selected_variant', 1))
                if t.get('genre') == 'silence':
                    continue
                if tid:
                    orch.select_variant(tid, v)
        except Exception as e:
            logging.warning(f"Не удалось переключить варианты: {e}")

        self._dirty = False
        self.status_var.set(f"✅ Сохранено в {self.plan_path}")
        messagebox.showinfo("Сохранено", f"music_plan.json обновлён.\n\nМожно запускать concat.")

    def _reload(self):
        if self._dirty and not messagebox.askyesno(
            "Перечитать", "Есть несохранённые изменения. Перечитать всё равно?"
        ):
            return
        for row in self.rows:
            row.destroy()
        self.rows.clear()
        self._load_plan()
        self._build()


# =============================================================================
# Helpers
# =============================================================================

def _db_to_linear(db: float) -> float:
    """Конвертирует dB в линейный коэффициент 0..1 для pygame."""
    if db <= -60:
        return 0.0
    return min(1.0, max(0.0, 10 ** (db / 20)))


# =============================================================================
# Entry point
# =============================================================================

def open_review(project_dir: str | Path):
    app = MusicReviewApp(Path(project_dir))
    app.mainloop()


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Использование: python -m modules.music_review <project_dir>")
        sys.exit(1)
    open_review(sys.argv[1])
