"""
tts_runner.py — запускатель TTS + продолжение пайплайна.

Вызывается из батников:
    python tts_runner.py --mode silent
    python tts_runner.py --mode interactive

Режимы:
    silent      — показывает настройки из .env, подтверждение уже получено батником.
                  После TTS автоматически запускает agent.py process --run.
    interactive — спрашивает каждый параметр. После TTS: pause (послушать),
                  подтверждение, выбор режима следующих этапов.
"""
import sys
import os
import subprocess
from pathlib import Path

# Добавляем agent/ в путь
_agent_dir = Path(__file__).parent.parent
sys.path.insert(0, str(_agent_dir))

import config
from modules.tts import run_tts, parse_script_file
from modules.queue import get_script_files


# ============================================================================
# ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
# ============================================================================

def _ask(prompt: str, default: str = '') -> str:
    val = input(f"{prompt} [{default}]: ").strip()
    return val if val else default


def _print_settings_table():
    """Выводит текущие настройки TTS из .env."""
    svc = config.TTS_SERVICE
    print()
    print("=" * 60)
    print("  TTS SETTINGS (from .env)")
    print("=" * 60)
    print(f"  Service:          {svc}")

    if svc == 'csv666':
        key_set = bool(config.TTS_API_KEY_CSV666)
        print(f"  API Key csv666:   {'[SET]' if key_set else '[NOT SET!]'}")
        print(f"  Chunk size:       {config.TTS_CSV666_CHUNK_SIZE}")
        print(f"  Output format:    {config.TTS_CSV666_OUTPUT_FORMAT}")
    else:
        key_set = bool(config.TTS_API_KEY_MAT3U)
        print(f"  API Key mat3u:    {'[SET]' if key_set else '[NOT SET!]'}")
        print(f"  Model ID:         {config.TTS_MAT3U_MODEL_ID}")
        print(f"  Split type:       {config.TTS_MAT3U_SPLIT_TYPE}")
        print(f"  Max chunk len:    {config.TTS_MAT3U_MAX_CHUNK_LENGTH}")
        print(f"  Split output:     {config.TTS_MAT3U_SPLIT_OUTPUT}")
        print(f"  Auto pause:       {config.TTS_MAT3U_AUTO_PAUSE_ENABLED}")
        if config.TTS_MAT3U_AUTO_PAUSE_ENABLED:
            print(f"  Pause duration:   {config.TTS_MAT3U_AUTO_PAUSE_DURATION}s")
            print(f"  Pause frequency:  every {config.TTS_MAT3U_AUTO_PAUSE_FREQUENCY} chunks")

    print(f"  Transcription:    {config.ASSEMBLYAI_LANGUAGE_CODE}")
    print(f"  Gemini model:     {config.GEMINI_MODEL}")
    print(f"  Clip mode:        video {config.VIDEO_CLIP_MIN_DURATION}-{config.VIDEO_CLIP_MAX_DURATION}s")
    print("=" * 60)


def _interactive_tts_settings() -> dict:
    """Спрашивает настройки TTS у пользователя. Возвращает dict с перегрузками."""
    overrides = {}

    print()
    print("=" * 60)
    print("  TTS INTERACTIVE SETUP")
    print("=" * 60)

    # Сервис
    print()
    print("  TTS service:")
    print("    [1] mat3u  (voicer.mat3u.com) — ElevenLabs")
    print("    [2] csv666 (voiceapi.csv666.ru)")
    print()
    svc_choice = _ask("  Choose [1/2]", "1")
    overrides['service'] = 'mat3u' if svc_choice != '2' else 'csv666'
    svc = overrides['service']

    if svc == 'mat3u':
        print()
        print("  mat3u model (ElevenLabs):")
        print("    [1] eleven_multilingual_v2  (recommended, quality)")
        print("    [2] eleven_v3               (newest generation)")
        print("    [3] eleven_turbo_v2_5       (fast + quality)")
        print("    [4] eleven_turbo_v2         (fast)")
        print("    [5] eleven_flash_v2_5       (ultra-fast)")
        print("    [6] eleven_flash_v2         (max speed)")
        m = _ask("  Model [1-6]", "1")
        models = {
            '1': 'eleven_multilingual_v2',
            '2': 'eleven_v3',
            '3': 'eleven_turbo_v2_5',
            '4': 'eleven_turbo_v2',
            '5': 'eleven_flash_v2_5',
            '6': 'eleven_flash_v2',
        }
        overrides['model_id'] = models.get(m, 'eleven_multilingual_v2')

        print()
        print("  Split type (how to split text into chunks):")
        print("    [1] smart       (AI-based, recommended)")
        print("    [2] sentences   (by sentences)")
        print("    [3] paragraphs  (by paragraphs)")
        print("    [4] max_length  (by character count)")
        st = _ask("  Split [1/2/3/4]", "1")
        splits = {'1': 'smart', '2': 'sentences', '3': 'paragraphs', '4': 'max_length'}
        overrides['split_type'] = splits.get(st, 'smart')

        overrides['max_chunk_length'] = int(_ask("  Max chunk length (100-1000)", str(config.TTS_MAT3U_MAX_CHUNK_LENGTH)))

        ap = _ask("  Auto pause? (y/n)", "n")
        overrides['auto_pause_enabled'] = ap.lower() == 'y'
        if overrides['auto_pause_enabled']:
            overrides['auto_pause_duration'] = float(_ask("  Pause duration (0.1-30.0 sec)", "0.5"))
            overrides['auto_pause_frequency'] = int(_ask("  Pause every N chunks", "1"))
    else:
        # csv666: модель и voice заданы внутри шаблона (template_uuid)
        # Шаблон создаётся в Telegram-боте csv666
        print()
        print("  csv666: model + voice are inside the template (template_uuid)")
        print("          Create/edit templates via csv666 Telegram bot")
        overrides['chunk_size'] = int(_ask("  Chunk size (500-2000)", str(config.TTS_CSV666_CHUNK_SIZE)))

    return overrides


def _apply_overrides(overrides: dict):
    """Применяет перегрузки настроек в config (in-place, для текущей сессии)."""
    if 'service' in overrides:
        config.TTS_SERVICE = overrides['service']
    if 'model_id' in overrides:
        config.TTS_MAT3U_MODEL_ID = overrides['model_id']
    if 'split_type' in overrides:
        config.TTS_MAT3U_SPLIT_TYPE = overrides['split_type']
    if 'max_chunk_length' in overrides:
        config.TTS_MAT3U_MAX_CHUNK_LENGTH = overrides['max_chunk_length']
    if 'auto_pause_enabled' in overrides:
        config.TTS_MAT3U_AUTO_PAUSE_ENABLED = overrides['auto_pause_enabled']
    if 'auto_pause_duration' in overrides:
        config.TTS_MAT3U_AUTO_PAUSE_DURATION = overrides['auto_pause_duration']
    if 'auto_pause_frequency' in overrides:
        config.TTS_MAT3U_AUTO_PAUSE_FREQUENCY = overrides['auto_pause_frequency']
    if 'chunk_size' in overrides:
        config.TTS_CSV666_CHUNK_SIZE = overrides['chunk_size']


def _run_pipeline(language: str = None, two_pass: bool = True, clip_mode: str = 'video', post_action: str = None):
    """Запускает agent.py process --run."""
    lang = language or config.ASSEMBLYAI_LANGUAGE_CODE
    cmd = [sys.executable, str(_agent_dir / 'agent.py'), 'process', '--run', '--language', lang]
    if two_pass:
        cmd.append('--two-pass')
    cmd += ['--clip-mode', clip_mode]
    if post_action:
        cmd += ['--post-action', post_action]
    print()
    print("=" * 60)
    print("  LAUNCHING PIPELINE: transcription + direction")
    print(f"  Command: {' '.join(cmd)}")
    print("=" * 60)
    result = subprocess.run(cmd, cwd=str(_agent_dir))
    return result.returncode


# ============================================================================
# MAIN
# ============================================================================

def main():
    mode = 'interactive'
    post_action = None
    clip_mode = None  # None = use default 'video' or interactive choice
    two_pass_override = None  # None = use config.GEMINI_TWO_PASS
    argv = sys.argv[1:]
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == '--mode' and i + 1 < len(argv):
            mode = argv[i + 1]
            i += 2
        elif arg in ('silent', 'interactive'):
            mode = arg
            i += 1
        elif arg == '--post-action' and i + 1 < len(argv):
            post_action = argv[i + 1]
            i += 2
        elif arg == '--clip-mode' and i + 1 < len(argv):
            clip_mode = argv[i + 1]
            i += 2
        elif arg == '--two-pass':
            two_pass_override = True
            i += 1
        elif arg == '--no-two-pass':
            two_pass_override = False
            i += 1
        else:
            i += 1

    base_dir = _agent_dir.parent
    ready_dir = base_dir / 'ready_to_go'

    if not ready_dir.exists():
        print(f"[ERROR] ready_to_go/ folder not found: {ready_dir}")
        sys.exit(1)

    # Находим скрипт-файлы
    script_files = get_script_files(ready_dir)
    if not script_files:
        print(f"\n[ERROR] No script files found in {ready_dir}")
        print("  Expected: .txt files (not SG_ALL*, *_style*, *_sg_*)")
        print("  First line must contain voice_id")
        sys.exit(1)

    print(f"\n  Found {len(script_files)} script file(s):")
    for sf in script_files:
        try:
            vid, txt = parse_script_file(sf)
            print(f"    {sf.name}  [voice: {vid[:20]}...]  [{len(txt)} chars]")
        except Exception as e:
            print(f"    {sf.name}  [ERROR: {e}]")

    # Настройки
    overrides = {}
    if mode == 'interactive':
        overrides = _interactive_tts_settings()
        _apply_overrides(overrides)
    else:
        _print_settings_table()

    print()

    # Обрабатываем каждый скрипт
    generated_audio = []

    for script_path in script_files:
        stem = script_path.stem
        output_path = ready_dir / stem  # расширение добавит tts.py

        print(f"\n[{script_path.name}] Starting TTS...")
        try:
            audio_path = run_tts(script_path, output_path, service=config.TTS_SERVICE)
            generated_audio.append(audio_path)
            print(f"  OK: {audio_path}")
        except Exception as e:
            print(f"  [ERROR] TTS failed for {script_path.name}: {e}")
            continue

        if mode == 'interactive':
            print()
            print(f"  Audio ready: {audio_path}")
            print("  Listen to the audio, edit the script if needed, then press Enter.")
            input("  Press Enter to continue... ")

            cont = input("  Continue to next stages? (y/n): ").strip().lower()
            if cont != 'y':
                print("  Skipping pipeline for this file.")
                continue

            print()
            print("  Next stages mode:")
            print("    [1] silent      (use .env defaults, no prompts)")
            print("    [2] interactive (ask each step)")
            next_mode = input("  Choose [1/2] (default=1): ").strip()

            if next_mode == '2':
                # interactive: ask each param
                tp_ans = input("  Two-pass direction? (y/n, default=y): ").strip().lower()
                two_pass = tp_ans != 'n'
                cm_ans = input("  Clip mode? (1=video / 2=slideshow, default=1): ").strip()
                cm = 'slideshow' if cm_ans == '2' else 'video'
            else:
                # silent: use config defaults
                two_pass = config.GEMINI_TWO_PASS
                cm = clip_mode or 'video'

            rc = _run_pipeline(two_pass=two_pass, clip_mode=cm, post_action=post_action)
            if rc != 0:
                print(f"\n  [ERROR] Pipeline failed (exit code {rc})")
        else:
            # silent — сразу продолжаем после всех скриптов
            pass

    # В silent режиме запускаем pipeline один раз после всех TTS
    if mode == 'silent' and generated_audio:
        two_pass = two_pass_override if two_pass_override is not None else config.GEMINI_TWO_PASS
        rc = _run_pipeline(two_pass=two_pass, clip_mode=clip_mode or 'video', post_action=post_action)
        if rc != 0:
            print(f"\n[ERROR] Pipeline failed (exit code {rc})")
            sys.exit(rc)

    print("\n[OK] TTS Runner complete.")


if __name__ == '__main__':
    main()
