#!/bin/bash
# RUN_DOGENERATOR.COMMAND - Find and generate missing FastGen clips (macOS)
# Run: double-click this file in Finder

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
chmod +x "$SCRIPT_DIR"/*.command 2>/dev/null

if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e 'tell app "Terminal" to do script "cd '\''$SCRIPT_DIR'\'' && exec '\''$0'\''"'
    exit 0
fi

clear
cd "$SCRIPT_DIR"

echo ""
echo "================================================================================"
echo " DOGENERATOR: Find and generate missing FastGen clips"
echo "================================================================================"
echo ""

# --- List projects ---
PROJECT=""
if [ -d "projects" ]; then
    echo " Available projects:"
    echo ""
    for p in projects/*/; do
        [ -d "$p" ] && echo "   $(basename "$p")"
    done
    echo ""
fi

echo -n " Enter project name: "
read PROJECT
echo ""

if [ -z "$PROJECT" ]; then
    echo " [ERROR] No project specified."
    echo "Press Enter to exit..." && read
    exit 1
fi

if [ ! -d "projects/$PROJECT" ]; then
    echo " [ERROR] Project not found: projects/$PROJECT"
    echo "Press Enter to exit..." && read
    exit 1
fi

# --- Find missing clips ---
echo " Project: $PROJECT"
echo " Scanning generated/ folder..."
echo ""

TMPFILE=$(mktemp)
python3 agent/find_missing_clips.py "$PROJECT" > "$TMPFILE" 2>&1
PY_EXIT=$?

if [ $PY_EXIT -eq 1 ]; then
    echo " [ERROR] Could not scan project:"
    cat "$TMPFILE"
    rm -f "$TMPFILE"
    echo "Press Enter to exit..." && read
    exit 1
fi

if [ $PY_EXIT -eq 2 ]; then
    echo " [OK] Nothing to generate - all clips already exist in generated/"
    rm -f "$TMPFILE"
    echo "Press Enter to exit..." && read
    exit 0
fi

# Parse output: line1=total, line2=missing_count, line3=ids_csv, line4+=details
TOTAL_COUNT=$(sed -n '1p' "$TMPFILE")
MISSING_COUNT=$(sed -n '2p' "$TMPFILE")
MISSING_IDS=$(sed -n '3p' "$TMPFILE")

echo " Total prompts:  $TOTAL_COUNT"
echo " Missing clips:  $MISSING_COUNT"
echo ""
echo "================================================================================"
echo " MISSING CLIPS:"
echo "================================================================================"
echo ""
tail -n +4 "$TMPFILE"
rm -f "$TMPFILE"

echo ""
echo "================================================================================"
echo " IDs to generate: $MISSING_IDS"
echo "================================================================================"
echo ""

# --- Engine selection ---
echo " Select engine:"
echo "   [1] NANO PRO FLOW    GEM_PIX_2   - best quality, Flow API"
echo "   [2] NANO PRO GEMINI  GEMINI      - Gemini native, fast"
echo "   [3] GROK             GROK        - Grok, 4 variants"
echo "   [4] NANO             GEM_PIX     - basic, Flow API"
echo "   [5] IMAGEN_3_5_FLOW  IMAGEN_3_5  - Imagen 4, Flow API"
echo "   [6] WHISK            WHISK       - Whisk, categorized refs"
echo ""
MODEL="GEM_PIX_2"
echo -n "  Engine [1-6] (Enter = GEM_PIX_2): "
read MODEL_CHOICE
case "$MODEL_CHOICE" in
    1|"") MODEL="GEM_PIX_2" ;;
    2) MODEL="GEMINI" ;;
    3) MODEL="GROK" ;;
    4) MODEL="GEM_PIX" ;;
    5) MODEL="IMAGEN_3_5" ;;
    6) MODEL="WHISK" ;;
esac
echo "   Selected: $MODEL"
echo ""

# --- Aspect ratio ---
echo " Select aspect ratio:"
echo "   [1] landscape  16:9  (recommended)"
echo "   [2] portrait   9:16"
echo "   [3] square     1:1"
echo ""
ASPECT="landscape"
echo -n "  Aspect [1/2/3] (Enter = landscape): "
read ASPECT_CHOICE
case "$ASPECT_CHOICE" in
    2) ASPECT="portrait" ;;
    3) ASPECT="square" ;;
esac
echo "   Selected: $ASPECT"
echo ""

# --- Parallel threads ---
PARALLEL=10
echo -n "  Parallel [1-10] (Enter = 10): "
read PARALLEL_INPUT
[ -n "$PARALLEL_INPUT" ] && PARALLEL="$PARALLEL_INPUT"
echo "   Selected: $PARALLEL"
echo ""

# --- Reference mode ---
MODE_ARG=""
if [ -d "projects/$PROJECT/ref" ]; then
    echo " ref/ folder found!"
    echo "   [1] Auto-detect"
    echo "   [2] Flow  - flat refs, up to 10"
    echo "   [3] Whisk - subject/scene/style categories"
    echo ""
    echo -n "  Ref mode [1/2/3] (Enter = auto): "
    read MODE_CHOICE
    case "$MODE_CHOICE" in
        2) MODE_ARG="--mode flow" ;;
        3) MODE_ARG="--mode whisk" ;;
    esac
    echo ""
else
    echo " No ref/ folder - generating without references"
    echo ""
fi

# --- Quota check ---
TMPQ=$(mktemp)
cd "$SCRIPT_DIR/agent"
python3 quota_check.py "$PROJECT" --ids "$MISSING_IDS" > "$TMPQ" 2>/dev/null
QC_EXIT=$?
cd "$SCRIPT_DIR"

QC_REMAINING=$(grep "^remaining=" "$TMPQ" | cut -d= -f2)
QC_NEEDED=$(grep "^needed=" "$TMPQ" | cut -d= -f2)
QC_HAS_BACKUP=$(grep "^has_backup=" "$TMPQ" | cut -d= -f2)
rm -f "$TMPQ"

BACKUP_ARG=""
if [ $QC_EXIT -eq 2 ]; then
    echo "================================================================================"
    echo " [WARN] QUOTA: remaining=$QC_REMAINING, needed=$QC_NEEDED - NOT ENOUGH"
    if [ "$QC_HAS_BACKUP" = "1" ]; then
        echo "   [1] Use BACKUP API key"
        echo "   [2] Continue with MAIN key anyway -- default --"
        echo "   [3] Cancel"
        echo "================================================================================"
        echo ""
        echo -n "  Choice [1/2/3] (Enter = main key): "
        read QC_CHOICE
        case "$QC_CHOICE" in
            1) BACKUP_ARG="--backup-key" ;;
            3) echo " Cancelled."; echo "Press Enter to exit..." && read; exit 0 ;;
        esac
    else
        echo "   No backup key in .env"
        echo "   [1] Continue with main key anyway -- default --"
        echo "   [2] Cancel"
        echo "================================================================================"
        echo ""
        echo -n "  Choice [1/2] (Enter = continue): "
        read QC_CHOICE
        [ "$QC_CHOICE" = "2" ] && echo " Cancelled." && echo "Press Enter to exit..." && read && exit 0
    fi
    echo ""
else
    echo " Quota: ${QC_REMAINING:-?} remaining / ${QC_NEEDED:-?} needed   [OK]"
    echo ""
fi

# --- Confirm ---
echo "================================================================================"
echo " SUMMARY:"
echo "   Project:  $PROJECT"
echo "   Clips:    $MISSING_COUNT missing ($MISSING_IDS)"
echo "   Engine:   $MODEL"
echo "   Aspect:   $ASPECT"
echo "   Parallel: $PARALLEL"
[ -n "$MODE_ARG" ] && echo "   Refs:     $MODE_ARG" || echo "   Refs:     auto"
[ -n "$BACKUP_ARG" ] && echo "   API key:  BACKUP" || echo "   API key:  main"
echo "================================================================================"
echo ""
echo -n "  Start? (y/n): "
read CONFIRM
if [ "$CONFIRM" != "y" ] && [ "$CONFIRM" != "Y" ]; then
    echo " Cancelled."
    echo "Press Enter to exit..." && read
    exit 0
fi

echo ""
echo "================================================================================"
echo " Starting generation..."
echo "================================================================================"
echo ""

cd "$SCRIPT_DIR/agent"
python3 agent.py generate     --project "$PROJECT"     --ids "$MISSING_IDS"     --model "$MODEL"     --aspect "$ASPECT"     --parallel "$PARALLEL"     $MODE_ARG $BACKUP_ARG
GEN_EXIT=$?
cd "$SCRIPT_DIR"

echo ""
echo "================================================================================"
if [ $GEN_EXIT -ne 0 ]; then
    echo " [ERROR] Generation finished with errors."
    echo " Check: projects/$PROJECT/generation_log.json"
else
    echo " [OK] Generation complete."
    echo " Output: projects/$PROJECT/generated/"
    echo " Log:    projects/$PROJECT/generation_log.json"
fi
echo "================================================================================"
echo ""
echo "Press Enter to exit..." && read
exit $GEN_EXIT
