"""
Batch-замена реальных имён в промптах на Character / Character1 / Character2.
Использует FastGen Prompt API (/v4/prompt/generate).

Использование:
  python rewrite_names.py --file PROMPTS.txt [--dry-run] [--ids 25,47,124]
"""

import sys
sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')
import os
import re
import time
import logging
from pathlib import Path

# Убираем modules/ из sys.path чтобы наш queue.py не затенял stdlib queue
_this_dir = str(Path(__file__).resolve().parent)
if _this_dir in sys.path:
    sys.path.remove(_this_dir)

import requests  # теперь безопасно — stdlib queue не затенён

# Добавляем agent/ для config.py
_agent_dir = str(Path(__file__).resolve().parent.parent)
if _agent_dir not in sys.path:
    sys.path.append(_agent_dir)
# Возвращаем modules/ обратно (для других импортов)
if _this_dir not in sys.path:
    sys.path.append(_this_dir)

import config

# ── FastGen Prompt API ────────────────────────────────────────────────

FASTGEN_BASE = 'https://api.fastgen.art'

def _rewrite_via_fastgen(prompt: str, api_key: str) -> str:
    """Отправить промпт в FastGen с инструкцией заменить имена на Character."""
    url = f"{FASTGEN_BASE}/v4/prompt/generate"
    headers = {
        'Authorization': f'Bearer {api_key}',
        'Content-Type': 'application/json',
    }
    body = {
        'user_prompt': (
            "In the following video generation prompt, replace ALL real person names "
            "(full names, surnames, first names of real historical or public figures) "
            "with the word 'Character'. "
            "If there are TWO different people in one prompt, use 'Character1' and 'Character2'. "
            "If the name appears with an adjective like 'Young Tesla' or 'Elderly Tesla', "
            "keep the adjective: 'Young Character', 'Elderly Character'. "
            "Do NOT change anything else — keep the scene, action, setting, "
            "camera, lighting, mood, composition, style tags, everything identical. "
            "Return ONLY the rewritten prompt, nothing else.\n\n"
            f"Prompt: {prompt}"
        ),
    }

    try:
        resp = requests.post(url, headers=headers, json=body, timeout=30)
        if resp.status_code != 200:
            print(f"  [WARN] FastGen returned {resp.status_code}: {resp.text[:100]}")
            return prompt
        data = resp.json()
        result = data.get('generated_text') or data.get('prompt') or data.get('text', '')
        return result.strip() if result else prompt
    except Exception as e:
        print(f"  [ERROR] FastGen request failed: {e}")
        return prompt


# ── Парсер промптов ───────────────────────────────────────────────────

def parse_prompts_file(path: str):
    """
    Парсит файл *_prompts_*.txt.
    Формат: непустые строки = промпты, разделённые пустыми строками.
    Нумерация clip_id = порядковый номер (1, 2, 3...).
    Возвращает dict {clip_id: prompt_text} и список оригинальных строк.
    """
    with open(path, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    prompts = {}
    clip_id = 0
    for line in lines:
        stripped = line.strip()
        if stripped:
            clip_id += 1
            prompts[clip_id] = stripped

    return prompts, lines


def write_prompts_file(path: str, original_lines: list, rewrites: dict):
    """
    Перезаписывает промпт-файл, заменяя только переписанные промпты.
    Сохраняет структуру (пустые строки между промптами).
    """
    clip_id = 0
    new_lines = []
    for line in original_lines:
        stripped = line.strip()
        if stripped:
            clip_id += 1
            if clip_id in rewrites:
                new_lines.append(rewrites[clip_id] + '\n')
            else:
                new_lines.append(line)
        else:
            new_lines.append(line)

    with open(path, 'w', encoding='utf-8') as f:
        f.writelines(new_lines)


# ── Детектор имён ─────────────────────────────────────────────────────

# Известные имена из проекта Tesla (расширяемый список)
KNOWN_NAMES = [
    'Tesla', 'Nikola Tesla', 'Nikola',
    'Trump', 'John G. Trump', 'John Trump',
    'Edison', 'Thomas Edison',
    'Westinghouse', 'George Westinghouse',
    'Morgan', 'J.P. Morgan', 'JP Morgan',
    'Marconi', 'Guglielmo Marconi',
    'Einstein', 'Albert Einstein',
]

def _has_person_name(prompt: str) -> bool:
    """Проверяет содержит ли промпт имя реальной личности."""
    prompt_lower = prompt.lower()
    for name in KNOWN_NAMES:
        if name.lower() in prompt_lower:
            return True
    return False


# ── Main ──────────────────────────────────────────────────────────────

def main():
    import argparse
    parser = argparse.ArgumentParser(description='Rewrite person names in prompts')
    parser.add_argument('--file', required=True, help='Path to prompts file')
    parser.add_argument('--dry-run', action='store_true', help='Show changes without writing')
    parser.add_argument('--ids', default=None, help='Only process these clip IDs (comma-separated)')
    parser.add_argument('--all', action='store_true', help='Process ALL prompts, not just ones with detected names')
    args = parser.parse_args()

    api_key = config.FASTGEN_API_KEY
    if not api_key:
        print("ERROR: FASTGEN_API_KEY not set in .env")
        sys.exit(1)

    prompts_path = args.file
    if not os.path.exists(prompts_path):
        print(f"ERROR: File not found: {prompts_path}")
        sys.exit(1)

    # Парсим
    prompts, original_lines = parse_prompts_file(prompts_path)
    print(f"Loaded {len(prompts)} prompts from {Path(prompts_path).name}")

    # Фильтр по IDs
    target_ids = None
    if args.ids:
        target_ids = set(int(x.strip()) for x in args.ids.split(','))

    # Определяем какие промпты нужно переписать
    to_rewrite = {}
    for cid, prompt in sorted(prompts.items()):
        if target_ids and cid not in target_ids:
            continue
        if args.all or _has_person_name(prompt):
            to_rewrite[cid] = prompt

    print(f"Prompts with person names: {len(to_rewrite)}")
    if not to_rewrite:
        print("Nothing to rewrite.")
        return

    # Показываем что будем переписывать
    print("\nClips to rewrite:")
    for cid in sorted(to_rewrite.keys()):
        snippet = to_rewrite[cid][:80].replace('\n', ' ')
        print(f"  #{cid:03d}: {snippet}...")

    if not args.dry_run:
        print(f"\nRewriting {len(to_rewrite)} prompts via FastGen API...")

    # Переписываем
    rewrites = {}
    for i, (cid, prompt) in enumerate(sorted(to_rewrite.items())):
        print(f"\n[{i+1}/{len(to_rewrite)}] Clip #{cid:03d}:")

        if args.dry_run:
            print(f"  ORIGINAL: {prompt[:120]}...")
            rewritten = _rewrite_via_fastgen(prompt, api_key)
            print(f"  REWRITE:  {rewritten[:120]}...")
            rewrites[cid] = rewritten
        else:
            rewritten = _rewrite_via_fastgen(prompt, api_key)
            if rewritten != prompt:
                rewrites[cid] = rewritten
                print(f"  OK: names replaced")
                # Показываем diff
                print(f"  WAS: ...{prompt[:100]}...")
                print(f"  NOW: ...{rewritten[:100]}...")
            else:
                print(f"  SKIP: no changes from API")

        # Пауза между запросами
        if i < len(to_rewrite) - 1:
            time.sleep(0.5)

    print(f"\n{'='*60}")
    print(f"Rewritten: {len(rewrites)} / {len(to_rewrite)}")

    if args.dry_run:
        print("DRY RUN — file not modified.")
        return

    if not rewrites:
        print("No changes needed.")
        return

    # Бэкап
    backup_path = prompts_path + '.bak'
    if not os.path.exists(backup_path):
        import shutil
        shutil.copy2(prompts_path, backup_path)
        print(f"Backup: {backup_path}")

    # Записываем
    write_prompts_file(prompts_path, original_lines, rewrites)
    print(f"Written: {prompts_path}")
    print("Done!")


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    main()
