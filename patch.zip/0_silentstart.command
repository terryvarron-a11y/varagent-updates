#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
chmod +x "$SCRIPT_DIR"/*.command 2>/dev/null

if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e 'tell app "Terminal" to do script "cd '\''$SCRIPT_DIR'\'' && exec '\''$0'\''"'
    exit 0
fi

clear

get_env() {
    local val
    val=$(grep -E "^$1=" "$SCRIPT_DIR/agent/.env" 2>/dev/null | tail -1 | cut -d'=' -f2-)
    echo "${val:-$2}"
}

TTS_SERVICE=$(get_env TTS_SERVICE mat3u)
TTS_MAT3U_MODEL_ID=$(get_env TTS_MAT3U_MODEL_ID eleven_multilingual_v2)
TTS_MAT3U_SPLIT_TYPE=$(get_env TTS_MAT3U_SPLIT_TYPE smart)
TTS_MAT3U_MAX_CHUNK_LENGTH=$(get_env TTS_MAT3U_MAX_CHUNK_LENGTH 1000)
TTS_MAT3U_AUTO_PAUSE_ENABLED=$(get_env TTS_MAT3U_AUTO_PAUSE_ENABLED false)
TTS_CSV666_CHUNK_SIZE=$(get_env TTS_CSV666_CHUNK_SIZE 1000)
TTS_CSV666_OUTPUT_FORMAT=$(get_env TTS_CSV666_OUTPUT_FORMAT mp3)
ASSEMBLYAI_LANGUAGE_CODE=$(get_env ASSEMBLYAI_LANGUAGE_CODE ru)
GEMINI_MODEL=$(get_env GEMINI_MODEL gemini-3.1-pro-preview)
VIDEO_CLIP_MIN_DURATION=$(get_env VIDEO_CLIP_MIN_DURATION 4)
VIDEO_CLIP_MAX_DURATION=$(get_env VIDEO_CLIP_MAX_DURATION 8)

echo ""
echo "================================================================================"
echo " 0_SILENTSTART  [TTS + Pipeline]  SILENT MODE"
echo "================================================================================"
echo ""
echo " CURRENT SETTINGS (.env):"
echo " -------------------------------------------------------"
echo " TTS service:          $TTS_SERVICE"
if [ "$TTS_SERVICE" = "mat3u" ]; then
    echo " Model ID:             $TTS_MAT3U_MODEL_ID"
    echo " Split type:           $TTS_MAT3U_SPLIT_TYPE"
    echo " Max chunk length:     $TTS_MAT3U_MAX_CHUNK_LENGTH"
    echo " Auto pause:           $TTS_MAT3U_AUTO_PAUSE_ENABLED"
else
    echo " Chunk size:           $TTS_CSV666_CHUNK_SIZE"
    echo " Output format:        $TTS_CSV666_OUTPUT_FORMAT"
fi
echo " Transcription lang:   $ASSEMBLYAI_LANGUAGE_CODE"
echo " Gemini model:         $GEMINI_MODEL"
echo " Clip duration:        ${VIDEO_CLIP_MIN_DURATION}-${VIDEO_CLIP_MAX_DURATION}s"
echo " -------------------------------------------------------"
echo ""
echo -n " All correct? Start pipeline? (y=start / n=switch to interactive): "
read CONFIRM
echo ""

if [ "$CONFIRM" = "n" ] || [ "$CONFIRM" = "N" ]; then
    echo " Switching to interactive mode..."
    exec "$SCRIPT_DIR/0_interactivestart.command"
fi

if [ "$CONFIRM" != "y" ] && [ "$CONFIRM" != "Y" ]; then
    echo " Cancelled."
    echo "Press Enter to exit..." && read
    exit 1
fi

echo " Starting TTS + Pipeline..."
echo ""
python3 "$SCRIPT_DIR/agent/tools/tts_runner.py" --mode silent
RESULT=$?

if [ $RESULT -ne 0 ]; then
    echo ""
    echo "[ERROR] TTS Runner failed!"
    echo "Press Enter to exit..." && read
    exit 1
fi

echo ""
echo "================================================================================"
echo " [OK] 0_SILENTSTART complete!"
echo "================================================================================"
echo "Press Enter to exit..." && read
exit 0
