#!/usr/bin/env python3
"""
VarAgent GUI — Visual Pipeline Manager
=======================================
Tab 1: Pipeline Launcher (replaces pipeline.bat)
Tab 2: Control Panel (project browser + .env editor)
Tab 3: VeoNonStop Generator (standalone generation)
"""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext, simpledialog
import threading
import re
import requests
import base64
import os
import sys
import subprocess
import importlib
import json
import time
import queue
import shutil
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from contextlib import contextmanager
from typing import Optional, List, Dict, Any

# ============ PATH SETUP ============
SCRIPT_DIR = Path(__file__).resolve().parent
AGENT_DIR = SCRIPT_DIR / 'agent'
AGENT_ENV_FILE = AGENT_DIR / '.env'
PRESETS_FILE   = AGENT_DIR / 'presets.json'
sys.path.insert(0, str(AGENT_DIR))
os.chdir(str(SCRIPT_DIR))

if sys.platform == 'win32':
    os.system('chcp 65001 >nul')

# Suppress tqdm in GUI mode
os.environ['TQDM_DISABLE'] = '1'

import config

# ============ COLORS ============
COLORS = {
    'bg_dark': '#181825',
    'bg_card': '#222236',
    'bg_input': '#2e2e44',
    'border': '#2d2d3a',
    'text': '#e8e8f2',
    'text_dim': '#a0a0b8',
    'text_muted': '#707088',
    'accent': '#7c5cfc',
    'accent_hover': '#9d7eff',
    'yellow': '#f5c842',
    'green': '#34d399',
    'orange': '#fb923c',
    'red': '#f87171',
    'blue': '#60a5fa',
    'cyan': '#22d3ee',
}

# Font sizes — bump for better readability on HiDPI
FONT_MAIN = ("Segoe UI", 11)
FONT_MAIN_BOLD = ("Segoe UI", 11, "bold")
FONT_DIM = ("Segoe UI", 10)
FONT_HEADER = ("Segoe UI", 18, "bold")
FONT_SECTION = ("Segoe UI", 12, "bold")
FONT_BUTTON = ("Segoe UI", 11, "bold")
FONT_LOG = ("Consolas", 10)
FONT_TAB = ("Segoe UI", 11, "bold")


def _find_ass_template(res: str = '720p') -> str | None:
    """Ищет *.ass шаблон под нужное разрешение в agent/templates/.
    Ищет файл содержащий res (720p/1080p) в имени, иначе первый попавшийся."""
    tdir = AGENT_DIR / 'templates'
    by_res = sorted(tdir.glob(f'*{res}*.ass'))
    if by_res:
        return str(by_res[0])
    fallback = sorted(tdir.glob('*.ass'))
    return str(fallback[0]) if fallback else None

# Display name → API model_key mapping
FASTGEN_MODELS = [
    ("Banana Pro", "GEM_PIX_2"),
    ("Banana 2", "NARWHAL"),
    ("Gemini", "GEMINI"),
    ("Grok", "GROK"),
    ("Imagen 4", "IMAGEN_3_5"),
    ("Banana", "GEM_PIX"),
]
FASTGEN_DISPLAY = [m[0] for m in FASTGEN_MODELS]
FASTGEN_NAME_TO_KEY = {m[0]: m[1] for m in FASTGEN_MODELS}
FASTGEN_KEY_TO_NAME = {m[1]: m[0] for m in FASTGEN_MODELS}

BANANA_MODELS = [("Banana Pro", "GEM_PIX_2"), ("Banana 2", "NARWHAL")]
BANANA_DISPLAY = [m[0] for m in BANANA_MODELS]
BANANA_NAME_TO_KEY = {m[0]: m[1] for m in BANANA_MODELS}
BANANA_KEY_TO_NAME = {m[1]: m[0] for m in BANANA_MODELS}

_GEMINI_MODEL_OPTS = [
    "gemini-2.5-pro", "gemini-2.5-flash",
    "gemini-3-flash-preview",
    "gemini-3.1-pro-preview",
]
_FASTGEN_MODEL_OPTS = [
    "GEM_PIX_2 — Banana Pro",
    "NARWHAL — Banana 2",
    "GEMINI — Gemini",
    "GROK — Grok",
    "GEM_PIX — Banana",
    "IMAGEN_3_5 — Imagen 4",
]

ENV_DROPDOWN_OPTIONS: dict = {
    # AssemblyAI
    "ASSEMBLYAI_LANGUAGE_CODE":   ["ru", "en", "es", "de", "fr", "it", "pl", "pt", "zh", "ja", "ko", "uk", "tr", "ar"],
    "ASSEMBLYAI_SPEECH_MODELS":   ["universal-3-pro,universal-2", "universal-3-pro", "universal-2"],
    "ASSEMBLYAI_SEGMENTATION_MODE": ["words", "sentences", "paragraphs"],
    # Gemini director
    "GEMINI_MODEL":               _GEMINI_MODEL_OPTS,
    "GEMINI_THINKING_LEVEL":      ["low", "medium", "high"],
    "GEMINI_THINKING_LEVEL_PASS2": ["low", "medium", "high"],
    "GEMINI_TWO_PASS":            ["false", "true"],
    "GENERATE_DIRECTOR_ANALYSIS": ["false", "true"],
    # TTS
    "TTS_SERVICE":                ["mat3u", "csv666"],
    "TTS_MAT3U_MODEL_ID":         ["eleven_multilingual_v2", "eleven_v3", "eleven_turbo_v2_5",
                                   "eleven_turbo_v2", "eleven_flash_v2_5", "eleven_flash_v2"],
    "TTS_MAT3U_SPLIT_TYPE":       ["smart", "sentences", "paragraphs", "max_length"],
    "TTS_MAT3U_SPLIT_OUTPUT":     ["false", "true"],
    "TTS_MAT3U_AUTO_PAUSE_ENABLED": ["false", "true"],
    "TTS_CSV666_OUTPUT_FORMAT":   ["mp3", "zip"],
    # FastGen
    "FASTGEN_MODEL":              _FASTGEN_MODEL_OPTS,
    "FASTGEN_ASPECT_RATIO":       ["landscape", "portrait", "square"],
    # VeoNonStop
    "VEONONSTOP_ASPECT_RATIO":    ["16:9", "9:16", "1:1", "4:3", "3:4"],
    "VEONONSTOP_IMGGEN_MODE":     ["banana", "banana_ref", "imagen"],
    "VEONONSTOP_BANANA_MODEL":    [
        "GEM_PIX_2 — Banana Pro",
        "NARWHAL — Banana 2",
    ],
    "VEONONSTOP_REQUEST_DELAY":   ["0.5", "1.0", "2.0", "3.0", "5.0", "10.0"],
    "VEONONSTOP_MAX_RETRIES":     ["1", "2", "3", "4", "5"],
    "VEONONSTOP_MAX_SILENT_CYCLES": ["1", "2", "3", "4", "5", "7", "10"],
    "VEONONSTOP_FAST_CENSOR":     ["off", "after_rewrites", "ultrafast"],
    # Pipeline defaults
    "PIPELINE_IMG_GEN":           ["veononstop", "fastgen", "skip"],
    # YT Packer
    "YT_PACK_MODEL":              _GEMINI_MODEL_OPTS,
    "YT_PACK_TRANSLATE_MODEL":    _GEMINI_MODEL_OPTS,
    "YT_PACK_CONTENT_MODEL":      _GEMINI_MODEL_OPTS,
    "YT_PACK_COVER_MODEL":        _FASTGEN_MODEL_OPTS,
    "YT_PACK_SUBTITLES":          ["false", "true"],
    "YT_PACK_DESCRIPTION":        ["false", "true"],
    "YT_PACK_COVERS":             ["false", "true"],
    "YT_PACK_LANGUAGES":          ["ru,en", "en,ru", "ru", "en", "es", "de", "fr"],
}

BASE_URL = "https://veononstop.org/api/v1"
REQUEST_TIMEOUT = 180
VIDEO_POLL_INTERVAL = 5
IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.webp'}


# ============ STDOUT CAPTURE ============

class LogRedirector:
    """Redirects sys.stdout to a log queue for GUI display."""
    def __init__(self, log_queue, tab_target, original, log_file=None, task_label=None, master_log=None):
        self.log_queue = log_queue
        self.tab_target = tab_target
        self.original = original
        self.buffer = ""
        self.log_file = log_file
        self.task_label = task_label  # shown as [Label] prefix in GUI log
        self.master_log = master_log  # pipeline_full.log (append across stages)

    def write(self, text):
        self.original.write(text)
        self.buffer += text
        while '\n' in self.buffer:
            line, self.buffer = self.buffer.split('\n', 1)
            if line.strip():
                level = 'INFO'
                low = line.lower()
                if any(x in low for x in ['error', 'fail', 'traceback']):
                    level = 'ERROR'
                elif any(x in low for x in ['[ok]', 'success', 'complete', 'saved']):
                    level = 'SUCCESS'
                elif any(x in low for x in ['warn', 'skip', 'retry']):
                    level = 'WARNING'
                self.log_queue.put((line.rstrip(), level, self.task_label, self.tab_target))
            if self.log_file:
                try:
                    self.log_file.write(line + '\n')
                    self.log_file.flush()
                except Exception:
                    pass
            if self.master_log:
                try:
                    self.master_log.write(line + '\n')
                    self.master_log.flush()
                except Exception:
                    pass

    def flush(self):
        self.original.flush()

    def isatty(self):
        return False


@contextmanager
def capture_stdout(log_queue, tab_target, log_file=None, task_label=None, master_log=None):
    old_out = sys.stdout
    old_err = sys.stderr
    redir = LogRedirector(log_queue, tab_target, old_out, log_file=log_file, task_label=task_label, master_log=master_log)
    sys.stdout = redir
    sys.stderr = redir
    try:
        yield
    finally:
        sys.stdout = old_out
        sys.stderr = old_err


def _image_to_base64(filepath):
    """Load image file as base64 + detect MIME type."""
    ext = Path(filepath).suffix.lower()
    mime_map = {'.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp'}
    mime = mime_map.get(ext, 'image/png')
    with open(filepath, 'rb') as f:
        b64 = base64.b64encode(f.read()).decode('utf-8')
    return b64, mime


def get_output_dir():
    output_dir = SCRIPT_DIR / "veononstop_output"
    try:
        output_dir.mkdir(exist_ok=True)
        return output_dir
    except PermissionError:
        fallback = Path.home() / "veononstop_output"
        fallback.mkdir(exist_ok=True)
        return fallback


# ════════════════════════════════════════════════════════════════════
# MAIN APPLICATION
# ════════════════════════════════════════════════════════════════════

class VarAgentGUI:
    """Main application: window, theme, Notebook, shared log queue."""

    def __init__(self, root):
        self.root = root
        self.root.title("VarAgent — Video Production Pipeline")
        self.root.geometry("1300x950")
        self.root.configure(bg=COLORS['bg_dark'])
        self.root.minsize(1100, 800)

        self.log_queue = queue.Queue()
        self.setup_styles()

        # Notebook with 4 tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.tab_pipeline  = PipelineLauncherTab(self.notebook, self)
        self.tab_control   = ControlPanelTab(self.notebook, self)
        self.tab_veo       = VeoGeneratorTab(self.notebook, self)
        self.tab_settings  = SettingsTab(self.notebook, self)
        self.tab_prompts   = PromptsTab(self.notebook, self)
        self.tab_brainstorm = BrainstormTab(self.notebook, self)
        self.tab_donate    = DonateTab(self.notebook, self)

        self.notebook.add(self.tab_pipeline.frame,   text="  Pipeline  ")
        self.notebook.add(self.tab_control.frame,    text="  Control Panel  ")
        self.notebook.add(self.tab_veo.frame,        text="  VeoNonStop  ")
        self.notebook.add(self.tab_settings.frame,   text="  Settings  ")
        self.notebook.add(self.tab_prompts.frame,    text="  Prompts  ")
        self.notebook.add(self.tab_brainstorm.frame, text="  Brainstorm  ")
        self.notebook.add(self.tab_donate.frame,     text="  Donate  ")

        self.process_log_queue()

        # Fix Ctrl+V/C/X/A/Z on non-Latin keyboard layouts (Russian etc.)
        # Tk maps Ctrl+V to <<Paste>> only for Latin keysym. On Russian layout
        # Ctrl+V sends keycode=86 but keysym='м' — Tk ignores it.
        # Fix: bind_all on KeyRelease, check keycode + Ctrl state, fire virtual event.
        _ENTRY_TYPES = (ttk.Entry, ttk.Combobox, tk.Entry)
        _undo_stacks = {}
        def _get_undo(w):
            wid = str(w)
            if wid not in _undo_stacks:
                _undo_stacks[wid] = []
            return _undo_stacks[wid]
        def _snapshot(w):
            try:
                stack = _get_undo(w)
                stack.append(w.get())
                if len(stack) > 50:
                    stack.pop(0)
            except Exception:
                pass
        def _on_key(event):
            if not isinstance(event.widget, _ENTRY_TYPES):
                return
            ctrl = (event.state & 0x4) != 0
            if not ctrl:
                return
            kc = event.keycode
            ks = event.keysym.lower()
            # Only fire if keysym is NOT the expected Latin letter (already handled by Tk)
            if kc == 86 and ks != 'v':    # V → Paste
                _snapshot(event.widget)
                event.widget.event_generate('<<Paste>>')
            elif kc == 67 and ks != 'c':  # C → Copy
                event.widget.event_generate('<<Copy>>')
            elif kc == 88 and ks != 'x':  # X → Cut
                _snapshot(event.widget)
                event.widget.event_generate('<<Cut>>')
            elif kc == 65 and ks != 'a':  # A → Select All
                event.widget.select_range(0, 'end')
                event.widget.icursor('end')
            elif kc == 90 and ks != 'z':  # Z → Undo
                stack = _get_undo(event.widget)
                if stack:
                    event.widget.delete(0, 'end')
                    event.widget.insert(0, stack.pop())
        root.bind_all('<KeyRelease>', _on_key, '+')
        # Undo for Latin layout too (Tk has no built-in undo for Entry)
        def _kb_undo(e):
            if not isinstance(e.widget, _ENTRY_TYPES):
                return
            stack = _get_undo(e.widget)
            if stack:
                e.widget.delete(0, 'end')
                e.widget.insert(0, stack.pop())
            return 'break'
        for _cls in ('TEntry', 'TCombobox', 'Entry'):
            root.bind_class(_cls, '<Control-z>', _kb_undo)
            root.bind_class(_cls, '<Control-Z>', _kb_undo)
            if sys.platform == 'darwin':
                root.bind_class(_cls, '<Command-z>', _kb_undo)
        # Snapshot on every keystroke for undo history (skip when Ctrl/Cmd held)
        def _on_char(event):
            if not isinstance(event.widget, _ENTRY_TYPES):
                return
            if event.state & 0x4:  # Ctrl held — not a real char input
                return
            if event.char and len(event.char) == 1 and ord(event.char) >= 32:
                _snapshot(event.widget)
        root.bind_all('<Key>', _on_char, '+')
        # Right-click context menu
        def _show_ctx_menu(e):
            w = e.widget
            m = tk.Menu(w, tearoff=0)
            m.add_command(label="Cut",        command=lambda: (_snapshot(w), w.event_generate("<<Cut>>")))
            m.add_command(label="Copy",       command=lambda: w.event_generate("<<Copy>>"))
            m.add_command(label="Paste",      command=lambda: (_snapshot(w), w.event_generate("<<Paste>>")))
            m.add_separator()
            m.add_command(label="Undo",       command=lambda: _kb_undo(type('E', (), {'widget': w})()))
            m.add_command(label="Select All", command=lambda: (w.select_range(0, 'end'), w.icursor('end')))
            m.tk_popup(e.x_root, e.y_root)
        for _cls in ('TEntry', 'TCombobox', 'Entry'):
            root.bind_class(_cls, '<Button-3>', _show_ctx_menu)
            if sys.platform == 'darwin':
                root.bind_class(_cls, '<Button-2>', _show_ctx_menu)

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure("TFrame", background=COLORS['bg_dark'])
        style.configure("Card.TFrame", background=COLORS['bg_card'])
        style.configure("TLabel", background=COLORS['bg_dark'],
                        foreground=COLORS['text'], font=FONT_MAIN)
        style.configure("Card.TLabel", background=COLORS['bg_card'],
                        foreground=COLORS['text'], font=FONT_MAIN)
        style.configure("Dim.TLabel", background=COLORS['bg_card'],
                        foreground=COLORS['text_dim'], font=FONT_DIM)
        style.configure("Header.TLabel", font=FONT_HEADER,
                        foreground=COLORS['accent'], background=COLORS['bg_dark'])
        style.configure("Section.TLabel", font=FONT_SECTION,
                        foreground=COLORS['accent'], background=COLORS['bg_card'])
        style.configure("Stats.TLabel", font=FONT_MAIN_BOLD,
                        background=COLORS['bg_card'])
        # Buttons — dark theme with readable hover
        style.configure("TButton", background=COLORS['bg_card'],
                        foreground=COLORS['text'], font=FONT_MAIN, padding=6,
                        borderwidth=1, relief="flat")
        style.map("TButton",
                  background=[("active", COLORS['accent']),
                              ("pressed", COLORS['accent']),
                              ("disabled", COLORS['border'])],
                  foreground=[("active", "#ffffff"),
                              ("pressed", "#ffffff"),
                              ("disabled", COLORS['text_muted'])])
        style.configure("Accent.TButton", font=FONT_BUTTON, padding=8,
                        background=COLORS['accent'], foreground="#ffffff")
        style.map("Accent.TButton",
                  background=[("active", COLORS['accent_hover']),
                              ("pressed", COLORS['accent']),
                              ("disabled", COLORS['border'])],
                  foreground=[("active", "#ffffff"),
                              ("pressed", "#ffffff"),
                              ("disabled", COLORS['text_muted'])])
        style.configure("Danger.TButton", font=FONT_BUTTON, padding=8,
                        background="#7a2020", foreground="#ffffff")
        style.map("Danger.TButton",
                  background=[("active", "#a83232"),
                              ("pressed", "#7a2020"),
                              ("disabled", COLORS['border'])],
                  foreground=[("active", "#ffffff"),
                              ("pressed", "#ffffff"),
                              ("disabled", COLORS['text_muted'])])
        style.configure("TCombobox", fieldbackground=COLORS['bg_input'],
                        background=COLORS['bg_input'],
                        foreground=COLORS['text'],
                        arrowcolor=COLORS['text_dim'],
                        borderwidth=0, relief="flat")
        style.map("TCombobox",
                  fieldbackground=[("readonly", COLORS['bg_input'])],
                  foreground=[("readonly", COLORS['text'])])
        style.configure("TRadiobutton", background=COLORS['bg_card'],
                        foreground=COLORS['text'], font=FONT_MAIN)
        style.map("TRadiobutton",
                  background=[("active", COLORS['bg_card'])],
                  foreground=[("active", COLORS['accent'])])
        style.configure("TCheckbutton", background=COLORS['bg_card'],
                        foreground=COLORS['text'], font=FONT_MAIN)
        style.map("TCheckbutton",
                  background=[("active", COLORS['bg_card'])],
                  foreground=[("active", COLORS['accent'])])
        style.configure("Green.Horizontal.TProgressbar",
                        troughcolor=COLORS['bg_input'],
                        background=COLORS['green'], thickness=8)
        style.configure("Custom.Horizontal.TProgressbar",
                        troughcolor=COLORS['bg_input'],
                        background=COLORS['accent'], thickness=8)
        # Notebook tab styling
        style.configure("TNotebook", background=COLORS['bg_dark'], borderwidth=0)
        style.configure("TNotebook.Tab", background=COLORS['bg_card'],
                        foreground=COLORS['text_dim'], font=FONT_TAB,
                        padding=[14, 7])
        style.map("TNotebook.Tab",
                  background=[("selected", COLORS['accent'])],
                  foreground=[("selected", "#ffffff")])

    def process_log_queue(self):
        try:
            for _ in range(50):  # batch up to 50 messages per tick
                message, level, thread_id, tab = self.log_queue.get_nowait()
                self._route_log(message, level, thread_id, tab)
        except queue.Empty:
            pass
        self.root.after(100, self.process_log_queue)

    def _route_log(self, message, level, thread_id, tab_target):
        """Route log message to the correct tab's log widget."""
        if tab_target == "pipeline" and hasattr(self.tab_pipeline, 'log_widget'):
            self._write_log(self.tab_pipeline.log_widget, message, level, thread_id)
        elif tab_target == "control" and hasattr(self.tab_control, 'log_widget'):
            self._write_log(self.tab_control.log_widget, message, level, thread_id)
        elif tab_target == "veo" and hasattr(self.tab_veo, 'log_widget'):
            self._write_log(self.tab_veo.log_widget, message, level, thread_id)
        elif tab_target == "brainstorm" and hasattr(self.tab_brainstorm, 'log_widget'):
            self._write_log(self.tab_brainstorm.log_widget, message, level, thread_id)

    def _write_log(self, widget, message, level, thread_id=None):
        ts = datetime.now().strftime("%H:%M:%S")
        prefix = {"INFO": "", "SUCCESS": "[OK]", "ERROR": "[ERR]", "WARNING": "[WARN]"}.get(level, "")
        thread_str = f"[{thread_id}] " if thread_id is not None else ""
        tag = level.lower() if level.lower() in ("success", "error", "warning", "info") else ""
        widget.insert(tk.END, f"[{ts}] {thread_str}{prefix} {message}\n", tag)
        if getattr(widget, '_autoscroll', True):
            widget.see(tk.END)

    def log(self, message, level="INFO", thread_id=None, tab="pipeline"):
        self.log_queue.put((message, level, thread_id, tab))

    @staticmethod
    def create_card(parent, title=None):
        card = ttk.Frame(parent, style="Card.TFrame", padding=12)
        card.pack(fill=tk.X, pady=4, padx=2)
        if title:
            ttk.Label(card, text=title, style="Section.TLabel").pack(anchor=tk.W)
        return card

    @staticmethod
    def create_log_widget(parent):
        log = scrolledtext.ScrolledText(parent, height=12, bg=COLORS['bg_input'],
                                        fg=COLORS['text'], font=FONT_LOG,
                                        insertbackground=COLORS['text'], relief=tk.FLAT,
                                        borderwidth=0, wrap=tk.WORD, spacing3=2)
        log.pack(fill=tk.BOTH, expand=True, pady=(4, 0))
        log.tag_configure("success", foreground=COLORS['green'])
        log.tag_configure("error", foreground=COLORS['red'])
        log.tag_configure("warning", foreground=COLORS['orange'])
        log.tag_configure("info", foreground=COLORS['blue'])
        # Double-click toggles auto-scroll: first double-click pauses, second resumes and jumps to bottom
        log._autoscroll = True
        def _toggle_autoscroll(event):
            log._autoscroll = not log._autoscroll
            if log._autoscroll:
                log.see(tk.END)
        log.bind("<Double-Button-1>", _toggle_autoscroll)
        log.bind("<Button-1>", lambda e: log.focus_set())

        def _do_copy(text):
            """Commit text to Windows clipboard via root window."""
            root = log.winfo_toplevel()
            root.clipboard_clear()
            root.clipboard_append(text)
            root.update()  # required to flush to Windows clipboard

        def _copy_selection(event=None):
            try:
                sel = log.get(tk.SEL_FIRST, tk.SEL_LAST)
                _do_copy(sel)
            except tk.TclError:
                pass
            return "break"

        def _copy_all(event=None):
            text = log.get("1.0", tk.END).rstrip()
            if text:
                _do_copy(text)
            return "break"

        def _show_context_menu(event):
            menu = tk.Menu(log, tearoff=0, bg=COLORS['bg_card'], fg=COLORS['text'],
                           activebackground=COLORS['accent'], activeforeground='#ffffff',
                           relief=tk.FLAT, borderwidth=1)
            menu.add_command(label="Copy selected  Ctrl+C", command=_copy_selection)
            menu.add_command(label="Copy all",              command=_copy_all)
            menu.add_separator()
            menu.add_command(label="Select all  Ctrl+A",
                             command=lambda: (log.tag_add(tk.SEL, "1.0", tk.END), log.focus_set()))
            menu.add_separator()
            menu.add_command(label="Clear log",
                             command=lambda: log.delete("1.0", tk.END))
            menu.tk_popup(event.x_root, event.y_root)

        log.bind("<Control-c>",      _copy_selection)
        log.bind("<Control-C>",      _copy_selection)
        log.bind("<Control-Insert>", _copy_selection)
        log.bind("<Control-a>",      lambda e: (log.tag_add(tk.SEL, "1.0", tk.END), "break"))
        log.bind("<Control-A>",      lambda e: (log.tag_add(tk.SEL, "1.0", tk.END), "break"))
        log.bind("<Button-3>",       _show_context_menu)
        return log


# ════════════════════════════════════════════════════════════════════
# TAB 1: PIPELINE LAUNCHER
# ════════════════════════════════════════════════════════════════════

class PipelineLauncherTab:
    """Replaces pipeline.bat — visual form for all pipeline settings."""

    def __init__(self, notebook, app: VarAgentGUI):
        self.app = app
        self.root = app.root
        self.frame = ttk.Frame(notebook)
        self.is_running = False

        # Variables (defaults from config)
        self.start_point    = tk.StringVar(value=getattr(config, 'PIPELINE_START_POINT', 'transcribe'))
        self.language       = tk.StringVar(value=getattr(config, 'ASSEMBLYAI_LANGUAGE_CODE', 'ru'))
        self.gemini_model   = tk.StringVar(value=getattr(config, 'GEMINI_MODEL', 'gemini-3.1-pro-preview'))
        self.direction_mode = tk.StringVar(value="2-pass" if getattr(config, 'GEMINI_TWO_PASS', False) else "1-pass")
        self.clip_mode         = tk.StringVar(value=getattr(config, 'PIPELINE_CLIP_MODE', 'video'))
        self.vislide_interval  = tk.IntVar(value=getattr(config, 'PIPELINE_VISLIDE_INTERVAL', 3))
        self.clip_min       = tk.IntVar(value=getattr(config, 'VIDEO_CLIP_MIN_DURATION', 4))
        self.clip_max       = tk.IntVar(value=getattr(config, 'VIDEO_CLIP_MAX_DURATION', 8))
        self.img_gen        = tk.StringVar(value=getattr(config, 'PIPELINE_IMG_GEN', 'veononstop'))
        self.fastgen_model  = tk.StringVar(value=FASTGEN_KEY_TO_NAME.get(getattr(config, 'FASTGEN_MODEL', 'GEMINI'), getattr(config, 'FASTGEN_MODEL', 'GEMINI')))
        self.fastgen_aspect = tk.StringVar(value=getattr(config, 'FASTGEN_ASPECT_RATIO', 'landscape'))
        self.fastgen_parallel = tk.IntVar(value=getattr(config, 'FASTGEN_MAX_PARALLEL', 4))
        self.fastgen_api_key  = tk.StringVar(value='main')
        self.veo_imggen_mode  = tk.StringVar(value=getattr(config, 'VEONONSTOP_IMGGEN_MODE', 'banana'))
        self.veo_banana_model = tk.StringVar(value=BANANA_KEY_TO_NAME.get(getattr(config, 'VEONONSTOP_BANANA_MODEL', 'GEM_PIX_2'), "Banana Pro"))
        self.video_mode     = tk.StringVar(value=getattr(config, 'PIPELINE_VIDEO_MODE', 'i2v'))
        self.veo_ratio      = tk.StringVar(value=getattr(config, 'VEONONSTOP_ASPECT_RATIO', '16:9'))
        self.veo_parallel   = tk.IntVar(value=getattr(config, 'VEONONSTOP_MAX_PARALLEL', 12))
        self.veo_request_delay = tk.DoubleVar(value=getattr(config, 'VEONONSTOP_REQUEST_DELAY', 10.0))
        self.veo_max_retries   = tk.IntVar(value=getattr(config, 'VEONONSTOP_MAX_RETRIES', 3))
        self.veo_max_silent_cycles = tk.IntVar(value=getattr(config, 'VEONONSTOP_MAX_SILENT_CYCLES', 3))
        self.veo_fast_censor   = tk.StringVar(value=getattr(config, 'VEONONSTOP_FAST_CENSOR', 'off'))
        self.prompt_mode    = tk.StringVar(value=getattr(config, 'PIPELINE_PROMPT_MODE', 'auto'))
        self.intro_duration = tk.IntVar(value=getattr(config, 'INTRO_BLOCK_DURATION', 30))
        self.intro_clip_min = tk.IntVar(value=getattr(config, 'INTRO_CLIP_MIN_DURATION', 3))
        self.intro_clip_max = tk.IntVar(value=getattr(config, 'INTRO_CLIP_MAX_DURATION', 6))
        self.p1_chunk_threshold = tk.IntVar(value=getattr(config, 'DIRECTOR_PASS1_CHUNK_THRESHOLD', 2400) // 60)
        self.p1_chunk_duration  = tk.IntVar(value=getattr(config, 'DIRECTOR_PASS1_CHUNK_DURATION',  1200) // 60)
        self.render_mode    = tk.StringVar(value=getattr(config, 'PIPELINE_RENDER_MODE', 'fast'))
        self.concat_fps     = tk.IntVar(value=getattr(config, 'VIDEO_FPS', 60))
        self.watermark      = tk.StringVar(value=getattr(config, 'PIPELINE_WATERMARK', 'none'))
        self.keep_files     = tk.BooleanVar(value=getattr(config, 'PIPELINE_KEEP_FILES', False))
        self.keep_veo_sound = tk.BooleanVar(value=getattr(config, 'PIPELINE_KEEP_VEO_SOUND', False))
        self.remix_engine   = tk.StringVar(value=getattr(config, 'REMIX_ENGINE', 'kieai'))
        self.image_upscale  = tk.StringVar(value=getattr(config, 'VEONONSTOP_IMAGE_UPSCALE', 'off'))
        self.video_upscale  = tk.BooleanVar(value=getattr(config, 'VEONONSTOP_VIDEO_UPSCALE', False))
        self.subtitles_enabled = tk.BooleanVar(value=False)
        self.subtitles_custom  = tk.BooleanVar(value=False)
        self.subtitles_path    = tk.StringVar(value='')
        self.script_type_var  = tk.StringVar(value="prose")
        self.ref_images: list[Path] = []
        self.ref_mode = tk.StringVar(value="one_for_all")
        self.ref_individual: dict[str, list[Path]] = {}
        self.veo_imggen_key      = tk.StringVar(value="1")
        self.veo_video_key       = tk.StringVar(value="1")
        # Per-slot BoolVars for multi-key checkboxes (slots 1-4)
        self._imggen_key_checks  = {i: tk.BooleanVar(value=(i == 1)) for i in range(1, 5)}
        self._video_key_checks   = {i: tk.BooleanVar(value=(i == 1)) for i in range(1, 5)}
        self.veo_imggen_parallel = tk.IntVar(value=config.VEONONSTOP_MAX_PARALLEL)
        self.inflight_mode       = tk.BooleanVar(value=False)
        self.skip_preflight      = tk.BooleanVar(value=False)
        self.cover_ref_images: list[Path] = []
        self.logo_path: Optional[Path] = None
        self.logo_mode = tk.StringVar(value="one_for_all")
        self.logo_individual: dict[str, Optional[Path]] = {}
        self.single_prompt_path: Optional[Path] = None
        self.yt_pack_enabled    = tk.BooleanVar(value=False)
        self.yt_pack_languages  = tk.StringVar(value=getattr(config, 'YT_PACK_LANGUAGES', 'ru,en') if not isinstance(getattr(config, 'YT_PACK_LANGUAGES', ''), list) else ','.join(config.YT_PACK_LANGUAGES))
        self.yt_pack_subtitles  = tk.BooleanVar(value=bool(getattr(config, 'YT_PACK_SUBTITLES', True)))
        self.yt_pack_description = tk.BooleanVar(value=bool(getattr(config, 'YT_PACK_DESCRIPTION', True)))
        self.yt_pack_covers     = tk.BooleanVar(value=bool(getattr(config, 'YT_PACK_COVERS', True)))
        self.cover_provider     = tk.StringVar(value=getattr(config, 'YT_PACK_COVER_PROVIDER', 'fastgen'))
        self.cover_model        = tk.StringVar(value=getattr(config, 'YT_PACK_COVER_MODEL', 'GEM_PIX_2'))

        self.create_ui()

    def _defaults_map(self):
        """Возвращает {ключ: tk.Variable} для сохранения/загрузки дефолтов."""
        return {
            'start_point':       self.start_point,
            'language':          self.language,
            'gemini_model':      self.gemini_model,
            'direction_mode':    self.direction_mode,
            'clip_mode':          self.clip_mode,
            'vislide_interval':   self.vislide_interval,
            'clip_min':          self.clip_min,
            'clip_max':          self.clip_max,
            'img_gen':           self.img_gen,
            'fastgen_model':     self.fastgen_model,
            'fastgen_aspect':    self.fastgen_aspect,
            'fastgen_parallel':  self.fastgen_parallel,
            'fastgen_api_key':   self.fastgen_api_key,
            'veo_imggen_mode':   self.veo_imggen_mode,
            'veo_banana_model':  self.veo_banana_model,
            'video_mode':        self.video_mode,
            'veo_ratio':         self.veo_ratio,
            'veo_parallel':      self.veo_parallel,
            'veo_request_delay': self.veo_request_delay,
            'veo_max_retries':   self.veo_max_retries,
            'veo_max_silent_cycles': self.veo_max_silent_cycles,
            'veo_fast_censor':   self.veo_fast_censor,
            'veo_imggen_key':      self.veo_imggen_key,
            'veo_video_key':       self.veo_video_key,
            'veo_imggen_parallel': self.veo_imggen_parallel,
            'inflight_mode':       self.inflight_mode,
            'prompt_mode':       self.prompt_mode,
            'render_mode':       self.render_mode,
            'watermark':         self.watermark,
            'keep_files':        self.keep_files,
            'keep_veo_sound':    self.keep_veo_sound,
            'remix_engine':      self.remix_engine,
            'image_upscale':     self.image_upscale,
            'video_upscale':     self.video_upscale,
            'intro_duration':    self.intro_duration,
            'intro_clip_min':    self.intro_clip_min,
            'intro_clip_max':    self.intro_clip_max,
            'p1_chunk_threshold': self.p1_chunk_threshold,
            'p1_chunk_duration':  self.p1_chunk_duration,
            'yt_pack_enabled':   self.yt_pack_enabled,
            'yt_pack_languages': self.yt_pack_languages,
            'yt_pack_subtitles': self.yt_pack_subtitles,
            'yt_pack_description': self.yt_pack_description,
            'yt_pack_covers':    self.yt_pack_covers,
            'cover_provider':    self.cover_provider,
            'cover_model':       self.cover_model,
            'concat_fps':        self.concat_fps,
        }

    # ── Presets ────────────────────────────────────────────────────────────

    def _load_presets_file(self) -> dict:
        if PRESETS_FILE.exists():
            try:
                return json.loads(PRESETS_FILE.read_text(encoding='utf-8'))
            except Exception:
                pass
        return {}

    def _save_presets_file(self, data: dict):
        PRESETS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

    def _refresh_preset_list(self):
        names = sorted(self._load_presets_file().keys())
        self._preset_cb['values'] = names

    def _save_preset(self):
        name = self._preset_var.get().strip()
        if not name:
            name = simpledialog.askstring("Save Preset", "Preset name:", parent=self.left)
            if not name:
                return
            name = name.strip()
        if not name:
            return
        data = self._load_presets_file()
        snapshot = {}
        for k, var in self._defaults_map().items():
            v = var.get()
            if isinstance(v, bool):
                snapshot[k] = v
            elif isinstance(v, (int, float)):
                snapshot[k] = v
            else:
                snapshot[k] = str(v)
        data[name] = snapshot
        self._save_presets_file(data)
        self._preset_var.set(name)
        self._refresh_preset_list()
        self.app.log(f"Preset saved: {name}", "SUCCESS")

    def _apply_preset(self, _event=None):
        name = self._preset_var.get().strip()
        if not name:
            return
        data = self._load_presets_file()
        preset = data.get(name)
        if not preset:
            return
        dmap = self._defaults_map()
        for k, var in dmap.items():
            if k not in preset:
                continue
            val = preset[k]
            try:
                var.set(val)
            except Exception:
                pass
        # Backward compat: 'both' → 'all'
        if self.veo_video_key.get() == 'both':
            self.veo_video_key.set('all')
        if self.veo_imggen_key.get() == 'both':
            self.veo_imggen_key.set('all')
        self.app.log(f"Preset loaded: {name}", "SUCCESS")
        if hasattr(self, 'preset_ind_listbox'):
            self._refresh_preset_ind_list()

    def _delete_preset(self):
        name = self._preset_var.get().strip()
        if not name:
            return
        data = self._load_presets_file()
        if name not in data:
            return
        if not messagebox.askyesno("Delete Preset", f"Delete preset '{name}'?", parent=self.left):
            return
        del data[name]
        self._save_presets_file(data)
        self._preset_var.set('')
        self._refresh_preset_list()
        self.app.log(f"Preset deleted: {name}", "SUCCESS")

    def _save_defaults(self):
        """Сохраняет текущие настройки пайплайна в agent/.env"""
        d = {k: v.get() for k, v in self._defaults_map().items()}

        def _b(val): return 'true' if val else 'false'

        updates = {
            'PIPELINE_START_POINT':      str(d['start_point']),
            'ASSEMBLYAI_LANGUAGE_CODE':  str(d['language']),
            'GEMINI_TWO_PASS':           'true' if d['direction_mode'] == '2-pass' else 'false',
            'PIPELINE_CLIP_MODE':        str(d['clip_mode']),
            'PIPELINE_VISLIDE_INTERVAL': str(d['vislide_interval']),
            'VIDEO_CLIP_MIN_DURATION':   str(d['clip_min']),
            'VIDEO_CLIP_MAX_DURATION':   str(d['clip_max']),
            'PIPELINE_IMG_GEN':          str(d['img_gen']),
            'FASTGEN_MODEL':             FASTGEN_NAME_TO_KEY.get(d['fastgen_model'], d['fastgen_model']),
            'FASTGEN_ASPECT_RATIO':      str(d['fastgen_aspect']),
            'FASTGEN_MAX_PARALLEL':      str(d['fastgen_parallel']),
            'VEONONSTOP_IMGGEN_MODE':    str(d['veo_imggen_mode']),
            'VEONONSTOP_BANANA_MODEL':   BANANA_NAME_TO_KEY.get(d['veo_banana_model'], 'GEM_PIX_2'),
            'PIPELINE_VIDEO_MODE':       str(d['video_mode']),
            'VEONONSTOP_ASPECT_RATIO':   str(d['veo_ratio']),
            'VEONONSTOP_MAX_PARALLEL':        str(d['veo_parallel']),
            'VEONONSTOP_REQUEST_DELAY':       str(d['veo_request_delay']),
            'VEONONSTOP_MAX_RETRIES':         str(d['veo_max_retries']),
            'VEONONSTOP_MAX_SILENT_CYCLES':   str(d['veo_max_silent_cycles']),
            'VEONONSTOP_FAST_CENSOR':         str(d['veo_fast_censor']),
            'VEONONSTOP_IMGGEN_KEY_SLOT':     str(d['veo_imggen_key']),
            'VEONONSTOP_VIDEO_KEY_SLOT':      str(d['veo_video_key']),
            'VEONONSTOP_IMGGEN_MAX_PARALLEL': str(d['veo_imggen_parallel']),
            'PIPELINE_INFLIGHT_MODE':         _b(d['inflight_mode']),
            'PIPELINE_PROMPT_MODE':      str(d['prompt_mode']),
            'PIPELINE_RENDER_MODE':      str(d['render_mode']),
            'PIPELINE_WATERMARK':        str(d['watermark']),
            'PIPELINE_KEEP_FILES':       _b(d['keep_files']),
            'PIPELINE_KEEP_VEO_SOUND':   _b(d['keep_veo_sound']),
            'REMIX_ENGINE':              str(d['remix_engine']),
            'VEONONSTOP_IMAGE_UPSCALE':  str(d['image_upscale']),
            'VEONONSTOP_VIDEO_UPSCALE':  _b(d['video_upscale']),
            'INTRO_BLOCK_DURATION':               str(d['intro_duration']),
            'INTRO_CLIP_MIN_DURATION':            str(d['intro_clip_min']),
            'INTRO_CLIP_MAX_DURATION':            str(d['intro_clip_max']),
            'DIRECTOR_PASS1_CHUNK_THRESHOLD':     str(d['p1_chunk_threshold'] * 60),
            'DIRECTOR_PASS1_CHUNK_DURATION':      str(d['p1_chunk_duration']  * 60),
            'YT_PACK_LANGUAGES':         str(d['yt_pack_languages']),
            'YT_PACK_SUBTITLES':         _b(d['yt_pack_subtitles']),
            'YT_PACK_DESCRIPTION':       _b(d['yt_pack_description']),
            'YT_PACK_COVERS':            _b(d['yt_pack_covers']),
        }

        try:
            lines = AGENT_ENV_FILE.read_text(encoding='utf-8').splitlines(keepends=True)
            remaining = set(updates.keys())
            new_lines = []
            for line in lines:
                stripped = line.rstrip('\r\n')
                if '=' in stripped and not stripped.startswith('#'):
                    key = stripped.split('=', 1)[0].strip()
                    if key in updates:
                        eol = '\r\n' if line.endswith('\r\n') else '\n'
                        new_lines.append(f'{key}={updates[key]}{eol}')
                        remaining.discard(key)
                        continue
                new_lines.append(line)
            if remaining:
                eol = '\r\n' if lines and lines[0].endswith('\r\n') else '\n'
                new_lines.append(f'{eol}# Pipeline GUI extras{eol}')
                for key in sorted(remaining):
                    new_lines.append(f'{key}={updates[key]}{eol}')
            AGENT_ENV_FILE.write_text(''.join(new_lines), encoding='utf-8')
            self.app.log("Pipeline defaults saved to .env", "SUCCESS", tab="pipeline")
        except Exception as e:
            self.app.log(f"Failed to save defaults: {e}", "ERROR", tab="pipeline")

    def create_ui(self):
        # Two columns: left = form, right = summary + log
        content = ttk.Frame(self.frame)
        content.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        # LEFT: scrollable settings
        left_outer = ttk.Frame(content)
        left_outer.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 5))

        canvas = tk.Canvas(left_outer, bg=COLORS['bg_dark'], highlightthickness=0, width=420)
        scrollbar = ttk.Scrollbar(left_outer, orient=tk.VERTICAL, command=canvas.yview)
        self.left = ttk.Frame(canvas)
        self.left.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.left, anchor=tk.NW)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        # mousewheel: only active while mouse is inside this canvas
        _mw = lambda e: canvas.yview_scroll(-1 * (e.delta // 120), "units")
        canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", _mw))
        canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))

        # RIGHT: static panels + expandable log
        right = ttk.Frame(content)
        right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self._build_form()
        self._build_right(right)

        # Dynamic VeoNonStop key labels + spinbox limits (background API fetch)
        self.veo_video_key.trace_add('write', self._on_veo_vid_key_changed)
        self.veo_imggen_key.trace_add('write', self._on_veo_img_key_changed)
        # Sync checkboxes when StringVar changes externally (preset load etc.)
        def _sync_img_checks(*_):
            self._sel_to_checks(self.veo_imggen_key.get(), self._imggen_key_checks)
        def _sync_vid_checks(*_):
            self._sel_to_checks(self.veo_video_key.get(), self._video_key_checks)
        self.veo_imggen_key.trace_add('write', _sync_img_checks)
        self.veo_video_key.trace_add('write', _sync_vid_checks)
        self._clamping = False
        self.veo_parallel.trace_add('write', self._clamp_vid_workers)
        self.veo_imggen_parallel.trace_add('write', self._clamp_img_workers)
        self._bind_workers_clamp()
        threading.Thread(target=self._fetch_veo_key_labels, daemon=True).start()

    def _fetch_veo_key_labels(self):
        """Background: query get_account_info() per key, update labels + limits incrementally."""
        import time
        try:
            from modules.veononstop import VeoNonStopClient
        except Exception:
            return
        failed = []
        for _slot, _api_key, _name, _has in self._all_veo_keys:
            if not _has:
                continue
            ok = False
            for _attempt in range(3):
                try:
                    c = VeoNonStopClient(api_key=_api_key)
                    acc = c.get_account_info()
                    plan = acc.get('plan', '?')
                    ct = acc.get('concurrent_tasks', '?')
                    if _name in (f'Key{_slot}', ''):
                        label = f"{plan} ({ct})"
                    else:
                        label = f"{_name} \u00b7 {plan} ({ct})"
                    limit = int(ct) if str(ct).isdigit() else 0
                    self.root.after(0, self._apply_single_key, _slot, label, limit)
                    ok = True
                    break
                except Exception:
                    time.sleep(2)
            if not ok:
                failed.append((_slot, _api_key, _name))
        # Final retry for stubborn keys
        for _slot, _api_key, _name in failed:
            try:
                time.sleep(5)
                c = VeoNonStopClient(api_key=_api_key)
                acc = c.get_account_info()
                ct = acc.get('concurrent_tasks', '?')
                plan = acc.get('plan', '?')
                label = f"{_name} \u00b7 {plan} ({ct})" if _name not in (f'Key{_slot}', '') else f"{plan} ({ct})"
                limit = int(ct) if str(ct).isdigit() else 0
                self.root.after(0, self._apply_single_key, _slot, label, limit)
            except Exception:
                pass

    def _apply_single_key(self, slot: str, label: str, limit: int):
        """Apply label + limit for one key, then recalc spinboxes."""
        for rb_dict in (self._veo_key_rbs_video, self._veo_key_rbs_img):
            rb = rb_dict.get(slot)
            if rb:
                rb.configure(text=label)
        self._veo_key_limits[slot] = limit
        self._on_veo_vid_key_changed()
        self._on_veo_img_key_changed()

    def _apply_veo_key_labels(self, labels: dict):
        """Apply dynamic labels to radiobuttons (main thread)."""
        for slot, text in labels.items():
            for rb_dict in (self._veo_key_rbs_video, self._veo_key_rbs_img):
                rb = rb_dict.get(slot)
                if rb:
                    rb.configure(text=text)

    def _apply_veo_key_limits(self, limits: dict):
        """Store per-key concurrent_tasks limits, update spinbox."""
        self._veo_key_limits = limits
        self._on_veo_vid_key_changed()
        self._on_veo_img_key_changed()
        # Also refresh Finalize panel parallel counts if it's built
        try:
            self.app.tab_control._refresh_fin_vid_par()
            self.app.tab_control._refresh_fin_img_par()
        except Exception:
            pass

    def _checks_to_sel(self, checks: dict) -> str:
        """Convert {1: BoolVar, ...} to comma-separated slot string e.g. '1,3'."""
        selected = [str(i) for i in sorted(checks) if checks[i].get()]
        if not selected:
            # Ensure at least one key selected — fallback to key1
            checks[1].set(True)
            return '1'
        return ','.join(selected)

    def _sel_to_checks(self, sel: str, checks: dict):
        """Apply selection string back to BoolVars."""
        active = _veo_sel_to_active(sel)
        for i, bv in checks.items():
            bv.set(i in active)

    def _on_imggen_key_check(self, *_):
        sel = self._checks_to_sel(self._imggen_key_checks)
        self.veo_imggen_key.set(sel)

    def _on_video_key_check(self, *_):
        sel = self._checks_to_sel(self._video_key_checks)
        self.veo_video_key.set(sel)

    def _calc_key_total(self, slot_var):
        """Calculate total concurrent_tasks for given key slot variable."""
        if not self._veo_key_limits:
            return 0
        slot = slot_var.get()
        if slot in ('both', 'all'):
            return sum(self._veo_key_limits.get(s, 0) for s in ('1', '2', '3', '4'))
        if ',' in slot:
            return sum(self._veo_key_limits.get(s.strip(), 0) for s in slot.split(','))
        return self._veo_key_limits.get(slot, 0)

    def _on_veo_vid_key_changed(self, *_):
        total = self._calc_key_total(self.veo_video_key)
        if total <= 0:
            return
        self._vid_workers_max = total
        self._vid_workers_spinbox.configure(to=total)
        self._clamping = True
        self.veo_parallel.set(total)
        self._clamping = False

    def _on_veo_img_key_changed(self, *_):
        total = self._calc_key_total(self.veo_imggen_key)
        if total <= 0:
            return
        self._img_workers_max = total
        self._img_workers_spinbox.configure(to=total)
        self._clamping = True
        self.veo_imggen_parallel.set(total)
        self._clamping = False

    def _clamp_vid_workers(self, *_):
        if self._clamping:
            return
        mx = getattr(self, '_vid_workers_max', 0)
        if mx <= 0:
            return
        try:
            val = int(self._vid_workers_spinbox.get())
        except (ValueError, tk.TclError):
            return
        if val > mx:
            self._clamping = True
            self.veo_parallel.set(mx)
            self._clamping = False

    def _clamp_img_workers(self, *_):
        if self._clamping:
            return
        mx = getattr(self, '_img_workers_max', 0)
        if mx <= 0:
            return
        try:
            val = int(self._img_workers_spinbox.get())
        except (ValueError, tk.TclError):
            return
        if val > mx:
            self._clamping = True
            self.veo_imggen_parallel.set(mx)
            self._clamping = False

    def _bind_workers_clamp(self):
        """Bind FocusOut/Return/KeyRelease on workers spinboxes to enforce key limits."""
        for sb, clamp_fn in [(self._vid_workers_spinbox, self._clamp_vid_workers),
                             (self._img_workers_spinbox, self._clamp_img_workers)]:
            sb.bind('<FocusOut>', lambda e, f=clamp_fn: f())
            sb.bind('<Return>', lambda e, f=clamp_fn: f())
            sb.bind('<KeyRelease>', lambda e, f=clamp_fn: f())

    def _build_form(self):
        # Key labels for VeoNonStop key selectors (computed once for all cards)
        # (slot, api_key_value, label, has_key)
        self._all_veo_keys = [
            ('1', config.VEONONSTOP_API_KEY,
             getattr(config, 'VEONONSTOP_KEY1_NAME', 'Key1'), bool(config.VEONONSTOP_API_KEY)),
            ('2', getattr(config, 'VEONONSTOP_API_KEY_2', ''),
             getattr(config, 'VEONONSTOP_KEY2_NAME', 'Key2'), bool(getattr(config, 'VEONONSTOP_API_KEY_2', ''))),
            ('3', getattr(config, 'VEONONSTOP_API_KEY_3', ''),
             getattr(config, 'VEONONSTOP_KEY3_NAME', 'Key3'), bool(getattr(config, 'VEONONSTOP_API_KEY_3', ''))),
            ('4', getattr(config, 'VEONONSTOP_API_KEY_4', ''),
             getattr(config, 'VEONONSTOP_KEY4_NAME', 'Key4'), bool(getattr(config, 'VEONONSTOP_API_KEY_4', ''))),
        ]
        self._veo_key_rbs_video = {}
        self._veo_key_rbs_img = {}
        self._veo_key_limits = {}
        _has_multi = sum(1 for _, _, _, h in self._all_veo_keys if h) > 1

        # ── Preset selector ──
        pcard = self.app.create_card(self.left, "Preset")
        prow = ttk.Frame(pcard, style="Card.TFrame")
        prow.pack(fill=tk.X, pady=2)
        self._preset_var = tk.StringVar()
        self._preset_cb = ttk.Combobox(prow, textvariable=self._preset_var, width=22, state='normal')
        self._preset_cb.pack(side=tk.LEFT, padx=(0, 6))
        self._preset_cb.bind('<<ComboboxSelected>>', self._apply_preset)
        ttk.Button(prow, text="Save", command=self._save_preset).pack(side=tk.LEFT, padx=(2, 0))
        ttk.Button(prow, text="Del", command=self._delete_preset).pack(side=tk.LEFT, padx=(1, 0))
        self._refresh_preset_list()

        # Start Point
        card = self.app.create_card(self.left, "Start Point")
        ttk.Radiobutton(card, text="From audio", variable=self.start_point,
                        value="audio", command=self._on_start_point_change).pack(anchor=tk.W)
        ttk.Radiobutton(card, text="From script (to audio)", variable=self.start_point,
                        value="script_tts", command=self._on_start_point_change).pack(anchor=tk.W)
        ttk.Radiobutton(card, text="From script (no audio)", variable=self.start_point,
                        value="script_no_audio", command=self._on_start_point_change).pack(anchor=tk.W)

        # Script type (shown only for script_no_audio)
        self.type_row = ttk.Frame(card, style="Card.TFrame")
        ttk.Label(self.type_row, text="Type:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Radiobutton(self.type_row, text="Prose", variable=self.script_type_var, value="prose").pack(side=tk.LEFT, padx=6)
        ttk.Radiobutton(self.type_row, text="Screenplay", variable=self.script_type_var, value="screenplay").pack(side=tk.LEFT)

        # Transcription + Direction
        card = self.app.create_card(self.left, "Transcription + Direction")
        self.lang_row = ttk.Frame(card, style="Card.TFrame")
        row = self.lang_row
        row.pack(fill=tk.X, pady=2)
        ttk.Label(row, text="Language:", style="Card.TLabel").pack(side=tk.LEFT)
        langs = ['ru', 'en', 'es', 'de', 'fr', 'it', 'pt', 'zh', 'pl']
        lang_cb = ttk.Combobox(row, textvariable=self.language, values=langs, width=5, state='readonly')
        lang_cb.pack(side=tk.LEFT, padx=5)

        row_model = ttk.Frame(card, style="Card.TFrame")
        row_model.pack(fill=tk.X, pady=2)
        ttk.Label(row_model, text="Model:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Combobox(row_model, textvariable=self.gemini_model, values=_GEMINI_MODEL_OPTS,
                     width=22, state='readonly').pack(side=tk.LEFT, padx=5)

        row2 = ttk.Frame(card, style="Card.TFrame")
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="Direction:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Radiobutton(row2, text="1-pass", variable=self.direction_mode, value="1-pass").pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(row2, text="2-pass", variable=self.direction_mode, value="2-pass").pack(side=tk.LEFT)

        row3 = ttk.Frame(card, style="Card.TFrame")
        row3.pack(fill=tk.X, pady=2)
        ttk.Label(row3, text="Clip mode:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Radiobutton(row3, text="video",     variable=self.clip_mode, value="video"    ).pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(row3, text="slideshow", variable=self.clip_mode, value="slideshow").pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(row3, text="vislide",   variable=self.clip_mode, value="vislide"  ).pack(side=tk.LEFT, padx=5)
        self._vislide_interval_lbl = ttk.Label(row3, text="every:", style="Card.TLabel")
        self._vislide_interval_spn = tk.Spinbox(row3, textvariable=self.vislide_interval,
                                                from_=2, to=20, width=3,
                                                bg=COLORS['bg_input'], fg=COLORS['text'])
        def _toggle_vislide_widgets(*_):
            if self.clip_mode.get() == 'vislide':
                self._vislide_interval_lbl.pack(side=tk.LEFT)
                self._vislide_interval_spn.pack(side=tk.LEFT, padx=2)
            else:
                self._vislide_interval_lbl.pack_forget()
                self._vislide_interval_spn.pack_forget()
        self.clip_mode.trace_add('write', _toggle_vislide_widgets)
        _toggle_vislide_widgets()

        row4 = ttk.Frame(card, style="Card.TFrame")
        row4.pack(fill=tk.X, pady=2)
        ttk.Label(row4, text="Duration:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row4, textvariable=self.clip_min, from_=1, to=30, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row4, text="—", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row4, textvariable=self.clip_max, from_=2, to=60, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row4, text="sec", style="Card.TLabel").pack(side=tk.LEFT)

        row5 = ttk.Frame(card, style="Card.TFrame")
        row5.pack(fill=tk.X, pady=2)
        ttk.Label(row5, text="P1 chunks:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Label(row5, text="if ≥", style="Dim.TLabel").pack(side=tk.LEFT, padx=(4, 1))
        tk.Spinbox(row5, textvariable=self.p1_chunk_threshold, from_=0, to=600, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=1)
        ttk.Label(row5, text="min →", style="Dim.TLabel").pack(side=tk.LEFT, padx=(1, 2))
        tk.Spinbox(row5, textvariable=self.p1_chunk_duration, from_=5, to=120, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=1)
        ttk.Label(row5, text="min/chunk  (0=off)", style="Dim.TLabel").pack(side=tk.LEFT, padx=4)

        # Intro Block
        card = self.app.create_card(self.left, "Intro Block")
        row_i1 = ttk.Frame(card, style="Card.TFrame")
        row_i1.pack(fill=tk.X, pady=2)
        ttk.Label(row_i1, text="Intro zone:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row_i1, textvariable=self.intro_duration, from_=0, to=9999, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row_i1, text="sec", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Label(row_i1, text="  (0 = off)", style="Dim.TLabel").pack(side=tk.LEFT, padx=4)

        row_i2 = ttk.Frame(card, style="Card.TFrame")
        row_i2.pack(fill=tk.X, pady=2)
        ttk.Label(row_i2, text="Intro clips:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row_i2, textvariable=self.intro_clip_min, from_=0, to=30, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row_i2, text="—", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row_i2, textvariable=self.intro_clip_max, from_=0, to=60, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row_i2, text="sec", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Label(row_i2, text="  (0 = inherit)", style="Dim.TLabel").pack(side=tk.LEFT, padx=4)

        # Image Generation
        card = self.app.create_card(self.left, "Image Generation")
        ttk.Radiobutton(card, text="FastGen", variable=self.img_gen, value="fastgen",
                        command=self._on_imggen_change).pack(anchor=tk.W)
        ttk.Radiobutton(card, text="VeoNonStop", variable=self.img_gen, value="veononstop",
                        command=self._on_imggen_change).pack(anchor=tk.W)
        ttk.Radiobutton(card, text="Skip (for t2v)", variable=self.img_gen, value="skip",
                        command=self._on_imggen_change).pack(anchor=tk.W)

        # FastGen sub-settings
        self.fg_frame = ttk.Frame(card, style="Card.TFrame")
        self.fg_frame.pack(fill=tk.X, pady=4)
        r = ttk.Frame(self.fg_frame, style="Card.TFrame")
        r.pack(fill=tk.X)
        ttk.Label(r, text="Model:", style="Dim.TLabel").pack(side=tk.LEFT)
        models = FASTGEN_DISPLAY
        ttk.Combobox(r, textvariable=self.fastgen_model, values=models, width=12, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(r, text="Aspect:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Combobox(r, textvariable=self.fastgen_aspect, values=['landscape', 'portrait', 'square'],
                     width=10, state='readonly').pack(side=tk.LEFT, padx=4)
        r2 = ttk.Frame(self.fg_frame, style="Card.TFrame")
        r2.pack(fill=tk.X, pady=(2, 0))
        ttk.Label(r2, text="Key:", style="Dim.TLabel").pack(side=tk.LEFT)
        _fg_has_k2 = bool(getattr(config, 'FASTGEN_API_KEY_2', '') or getattr(config, 'FASTGEN_API_KEY_BACKUP', ''))
        _fg_key_vals = ['main'] + (['backup', 'both'] if _fg_has_k2 else [])
        ttk.Combobox(r2, textvariable=self.fastgen_api_key, values=_fg_key_vals,
                     width=8, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(r2, text="Threads:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Spinbox(r2, textvariable=self.fastgen_parallel, from_=1, to=32,
                    width=4).pack(side=tk.LEFT, padx=4)

        # VeoNonStop sub-settings
        self.veo_img_frame = ttk.Frame(card, style="Card.TFrame")
        r = ttk.Frame(self.veo_img_frame, style="Card.TFrame")
        r.pack(fill=tk.X)
        ttk.Label(r, text="Mode:", style="Dim.TLabel").pack(side=tk.LEFT)
        for val, txt in [('banana', 'Banana'), ('banana_ref', 'Banana+ref'), ('imagen', 'Imagen')]:
            ttk.Radiobutton(r, text=txt, variable=self.veo_imggen_mode, value=val,
                            command=self._on_veo_mode_change).pack(side=tk.LEFT, padx=3)
        self.veo_model_row = ttk.Frame(self.veo_img_frame, style="Card.TFrame")
        self.veo_model_row.pack(fill=tk.X, pady=(4, 0))
        ttk.Label(self.veo_model_row, text="Model:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Combobox(self.veo_model_row, textvariable=self.veo_banana_model, values=BANANA_DISPLAY,
                     width=12, state='readonly').pack(side=tk.LEFT, padx=4)

        # VeoNonStop imggen: key selector (multi-select checkboxes) — two rows
        veo_img_key_row = ttk.Frame(self.veo_img_frame, style="Card.TFrame")
        veo_img_key_row.pack(fill=tk.X, pady=(4, 0))
        ttk.Label(veo_img_key_row, text="Img Key:", style="Dim.TLabel").pack(side=tk.LEFT)
        for _slot, _api_key, _name, _has in self._all_veo_keys[:2]:
            _n = int(_slot)
            _cb = ttk.Checkbutton(veo_img_key_row, text=_name,
                                  variable=self._imggen_key_checks[_n],
                                  command=self._on_imggen_key_check)
            _cb.pack(side=tk.LEFT, padx=3)
            if not _has:
                _cb.state(['disabled'])
            self._veo_key_rbs_img[_slot] = _cb
        veo_img_key_row2 = ttk.Frame(self.veo_img_frame, style="Card.TFrame")
        veo_img_key_row2.pack(fill=tk.X)
        for _slot, _api_key, _name, _has in self._all_veo_keys[2:]:
            _n = int(_slot)
            _cb = ttk.Checkbutton(veo_img_key_row2, text=_name,
                                  variable=self._imggen_key_checks[_n],
                                  command=self._on_imggen_key_check)
            _cb.pack(side=tk.LEFT, padx=3)
            if not _has:
                _cb.state(['disabled'])
            self._veo_key_rbs_img[_slot] = _cb

        # VeoNonStop imggen: workers
        veo_img_wrk_row = ttk.Frame(self.veo_img_frame, style="Card.TFrame")
        veo_img_wrk_row.pack(fill=tk.X, pady=(4, 0))
        ttk.Label(veo_img_wrk_row, text="Img Workers:", style="Dim.TLabel").pack(side=tk.LEFT)
        self._img_workers_spinbox = tk.Spinbox(veo_img_wrk_row, textvariable=self.veo_imggen_parallel,
                   from_=1, to=48, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text'])
        self._img_workers_spinbox.pack(side=tk.LEFT, padx=2)
        ttk.Label(veo_img_wrk_row, text="Upscale:", style="Dim.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        ttk.Combobox(veo_img_wrk_row, textvariable=self.image_upscale,
                     values=["off", "2K", "4K"], width=5, state='readonly').pack(side=tk.LEFT, padx=2)

        # Ref images picker (for FastGen and banana_ref)
        self.ref_row = ttk.Frame(card, style="Card.TFrame")
        # Title row with One for all / Individual toggle
        ref_title_row = ttk.Frame(self.ref_row, style="Card.TFrame")
        ref_title_row.pack(fill=tk.X)
        ttk.Label(ref_title_row, text="Refs:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Radiobutton(ref_title_row, text="One for all", variable=self.ref_mode,
                        value="one_for_all", command=self._on_ref_mode_change).pack(side=tk.LEFT, padx=(8, 3))
        ttk.Radiobutton(ref_title_row, text="Individual", variable=self.ref_mode,
                        value="individual", command=self._on_ref_mode_change).pack(side=tk.LEFT)
        _RC = COLORS['bg_card']
        ref_stack = tk.Frame(self.ref_row, bg=_RC)
        ref_stack.pack(fill=tk.X)
        # Individual panel (defines container height)
        self.ref_ind_frame = tk.Frame(ref_stack, bg=_RC)
        self.ref_ind_frame.pack(fill=tk.X)
        self.ref_ind_listbox = tk.Listbox(self.ref_ind_frame, height=3, width=1, bg=COLORS['bg_input'],
                                          fg=COLORS['text'], font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        self.ref_ind_listbox.pack(fill=tk.X, pady=(0, 2))
        ref_ind_btns = tk.Frame(self.ref_ind_frame, bg=_RC)
        ref_ind_btns.pack(fill=tk.X)
        ttk.Button(ref_ind_btns, text="Add", command=self._browse_ind_ref).pack(side=tk.LEFT, padx=2)
        ttk.Button(ref_ind_btns, text="Clear", command=self._clear_ind_ref).pack(side=tk.LEFT, padx=2)
        # One-for-all panel (placed over ind_frame)
        self.ref_one_frame = tk.Frame(ref_stack, bg=_RC)
        self.ref_one_frame.place(x=0, y=0, relwidth=1, relheight=1)
        ref_top = ttk.Frame(self.ref_one_frame, style="Card.TFrame")
        ref_top.pack(fill=tk.X)
        ttk.Button(ref_top, text="Add", command=self._browse_ref_images).pack(side=tk.LEFT, padx=2)
        ttk.Button(ref_top, text="Del", command=self._remove_ref_image).pack(side=tk.LEFT, padx=2)
        ttk.Button(ref_top, text="Clear", command=self._clear_ref_images).pack(side=tk.LEFT, padx=2)
        ref_list_frame = ttk.Frame(self.ref_one_frame, style="Card.TFrame")
        ref_list_frame.pack(fill=tk.X, pady=(2, 0))
        self.ref_listbox = tk.Listbox(ref_list_frame, height=2, width=1, bg=COLORS['bg_input'], fg=COLORS['text'],
                                      font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        ref_sb = ttk.Scrollbar(ref_list_frame, orient=tk.VERTICAL, command=self.ref_listbox.yview)
        self.ref_listbox.config(yscrollcommand=ref_sb.set)
        self.ref_listbox.pack(side=tk.LEFT, fill=tk.X, expand=True)
        ref_sb.pack(side=tk.RIGHT, fill=tk.Y)
        def _on_ref_mousewheel(event):
            if self.ref_listbox.size() > int(self.ref_listbox.cget('height')):
                self.ref_listbox.yview_scroll(-1 * (event.delta // 120), "units")
                return "break"
        self.ref_listbox.bind("<MouseWheel>", _on_ref_mousewheel)


        self._on_imggen_change()

        # Remixer engine
        remix_card = self.app.create_card(self.left, "Remixer")
        remix_row = ttk.Frame(remix_card, style="Card.TFrame")
        remix_row.pack(fill=tk.X)
        ttk.Radiobutton(remix_row, text="KieAI", variable=self.remix_engine,
                        value='kieai').pack(side=tk.LEFT, padx=(0, 8))
        ttk.Radiobutton(remix_row, text="Grok", variable=self.remix_engine,
                        value='grok').pack(side=tk.LEFT)

        # Video Generation
        card = self.app.create_card(self.left, "Video Generation")
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(fill=tk.X, pady=2)
        for val, txt in [('i2v', 'i2v'), ('t2v', 't2v'), ('components', 'components')]:
            ttk.Radiobutton(row, text=txt, variable=self.video_mode, value=val,
                            command=self._on_video_mode_change).pack(side=tk.LEFT, padx=5)

        row2 = ttk.Frame(card, style="Card.TFrame")
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="Ratio:", style="Card.TLabel").pack(side=tk.LEFT)
        for val in ['16:9', '9:16', '1:1']:
            ttk.Radiobutton(row2, text=val, variable=self.veo_ratio, value=val).pack(side=tk.LEFT, padx=3)

        # Video key selector (multi-select checkboxes) — two rows
        row2a = ttk.Frame(card, style="Card.TFrame")
        row2a.pack(fill=tk.X, pady=(2, 0))
        ttk.Label(row2a, text="Vid Key:", style="Card.TLabel").pack(side=tk.LEFT)
        for _slot, _api_key, _name, _has in self._all_veo_keys[:2]:
            _n = int(_slot)
            _cb = ttk.Checkbutton(row2a, text=_name,
                                  variable=self._video_key_checks[_n],
                                  command=self._on_video_key_check)
            _cb.pack(side=tk.LEFT, padx=3)
            if not _has:
                _cb.state(['disabled'])
            self._veo_key_rbs_video[_slot] = _cb
        row2a2 = ttk.Frame(card, style="Card.TFrame")
        row2a2.pack(fill=tk.X, pady=(0, 2))
        for _slot, _api_key, _name, _has in self._all_veo_keys[2:]:
            _n = int(_slot)
            _cb = ttk.Checkbutton(row2a2, text=_name,
                                  variable=self._video_key_checks[_n],
                                  command=self._on_video_key_check)
            _cb.pack(side=tk.LEFT, padx=3)
            if not _has:
                _cb.state(['disabled'])
            self._veo_key_rbs_video[_slot] = _cb

        # Inflight i2v mode checkbox
        _chk_row = ttk.Frame(card, style="Card.TFrame")
        _chk_row.pack(fill=tk.X, pady=(2, 0))
        ttk.Checkbutton(_chk_row, text="Inflight i2v",
                        variable=self.inflight_mode).pack(side=tk.LEFT, padx=(0, 12))
        ttk.Checkbutton(_chk_row, text="Skip preflight",
                        variable=self.skip_preflight).pack(side=tk.LEFT)
        ttk.Checkbutton(_chk_row, text="Upscale 1080p",
                        variable=self.video_upscale).pack(side=tk.LEFT, padx=(8, 0))

        row2b = ttk.Frame(card, style="Card.TFrame")
        row2b.pack(fill=tk.X, pady=2)
        ttk.Label(row2b, text="Workers:", style="Card.TLabel").pack(side=tk.LEFT)
        self._vid_workers_spinbox = tk.Spinbox(row2b, textvariable=self.veo_parallel, from_=1, to=48, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text'])
        self._vid_workers_spinbox.pack(side=tk.LEFT, padx=2)
        ttk.Label(row2b, text="  Delay:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row2b, textvariable=self.veo_request_delay, from_=0.5, to=30.0,
                   increment=0.5, width=4, format="%.1f",
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row2b, text="s", style="Dim.TLabel").pack(side=tk.LEFT)

        row2c = ttk.Frame(card, style="Card.TFrame")
        row2c.pack(fill=tk.X, pady=2)
        ttk.Label(row2c, text="Retries:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row2c, textvariable=self.veo_max_retries, from_=1, to=5, width=2,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row2c, text="  Cycles:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row2c, textvariable=self.veo_max_silent_cycles, from_=1, to=10, width=2,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)

        row2d = ttk.Frame(card, style="Card.TFrame")
        row2d.pack(fill=tk.X, pady=2)
        ttk.Label(row2d, text="Skiper mod:", style="Card.TLabel").pack(side=tk.LEFT)
        _fc_opts = ENV_DROPDOWN_OPTIONS.get('VEONONSTOP_FAST_CENSOR', ['off', 'after_rewrites', 'ultrafast'])
        ttk.Combobox(row2d, textvariable=self.veo_fast_censor, values=_fc_opts,
                     width=14, state='readonly').pack(side=tk.LEFT, padx=2)

        row3 = ttk.Frame(card, style="Card.TFrame")
        row3.pack(fill=tk.X, pady=2)
        ttk.Label(row3, text="Prompts:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Radiobutton(row3, text="single", variable=self.prompt_mode, value="single").pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(row3, text="per-clip", variable=self.prompt_mode, value="perclip").pack(side=tk.LEFT)

        # Single prompt file loader — shown only in "single" mode
        self.single_prompt_row = ttk.Frame(card, style="Card.TFrame")
        ttk.Label(self.single_prompt_row, text="Prompt file:", style="Dim.TLabel").pack(anchor=tk.W)
        self.single_prompt_lbl = ttk.Label(self.single_prompt_row, text="(none)", style="Dim.TLabel")
        self.single_prompt_lbl.pack(fill=tk.X)
        _sp_btns = ttk.Frame(self.single_prompt_row, style="Card.TFrame")
        _sp_btns.pack(fill=tk.X, pady=(2, 0))
        ttk.Button(_sp_btns, text="Add", command=self._browse_single_prompt).pack(side=tk.LEFT, padx=2)
        ttk.Button(_sp_btns, text="Clear", command=self._clear_single_prompt).pack(side=tk.LEFT, padx=2)
        self.prompt_mode.trace_add('write', lambda *a: self._on_prompt_mode_change())
        self._on_prompt_mode_change()

        # Render
        card = self.app.create_card(self.left, "Render & Concat")
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(fill=tk.X, pady=2)
        ttk.Radiobutton(row, text="Fast (no re-encode)", variable=self.render_mode, value="720p").pack(side=tk.LEFT, padx=5)
        self._rb_1080p = ttk.Radiobutton(row, text="1080p re-encode", variable=self.render_mode, value="1080p")
        self._rb_1080p.pack(side=tk.LEFT)

        def _on_vid_upscale_change(*_):
            if self.video_upscale.get():
                self.render_mode.set("720p")
                self._rb_1080p.config(state='disabled')
            else:
                self._rb_1080p.config(state='normal')
        self.video_upscale.trace_add('write', _on_vid_upscale_change)
        _on_vid_upscale_change()
        ttk.Label(row, text="FPS:", style="Card.TLabel").pack(side=tk.LEFT, padx=(12, 0))
        ttk.Combobox(row, textvariable=self.concat_fps,
                     values=[24, 25, 30, 50, 60], width=4, state='readonly').pack(side=tk.LEFT, padx=3)
        row2 = ttk.Frame(card, style="Card.TFrame")
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="Watermark:", style="Card.TLabel").pack(side=tk.LEFT)
        for val, txt in [('as_is', 'none'), ('logo', 'logo'), ('blur', 'blur')]:
            ttk.Radiobutton(row2, text=txt, variable=self.watermark, value=val).pack(side=tk.LEFT, padx=3)
        # Logo file picker (one-for-all / individual toggle)
        logo_title_row = ttk.Frame(card, style="Card.TFrame")
        logo_title_row.pack(fill=tk.X, pady=(4, 2))
        ttk.Label(logo_title_row, text="Logo:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Radiobutton(logo_title_row, text="One for all", variable=self.logo_mode,
                        value="one_for_all", command=self._on_logo_mode_change).pack(side=tk.LEFT, padx=(8, 3))
        ttk.Radiobutton(logo_title_row, text="Individual", variable=self.logo_mode,
                        value="individual", command=self._on_logo_mode_change).pack(side=tk.LEFT)
        _LC = COLORS['bg_card']
        logo_stack = tk.Frame(card, bg=_LC)
        logo_stack.pack(fill=tk.X)
        # Individual panel (defines container height)
        self.logo_ind_frame = tk.Frame(logo_stack, bg=_LC)
        self.logo_ind_frame.pack(fill=tk.X)
        self.logo_ind_listbox = tk.Listbox(self.logo_ind_frame, height=3, bg=COLORS['bg_input'],
                                           fg=COLORS['text'], font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        self.logo_ind_listbox.pack(fill=tk.X, pady=(0, 2))
        logo_ind_btns = tk.Frame(self.logo_ind_frame, bg=_LC)
        logo_ind_btns.pack(fill=tk.X)
        ttk.Button(logo_ind_btns, text="Add", command=self._browse_ind_logo).pack(side=tk.LEFT, padx=2)
        ttk.Button(logo_ind_btns, text="Clear", command=self._clear_ind_logo).pack(side=tk.LEFT, padx=2)
        # One-for-all panel (placed over ind_frame)
        self.logo_one_frame = tk.Frame(logo_stack, bg=_LC)
        self.logo_one_frame.place(x=0, y=0, relwidth=1, relheight=1)
        self.logo_lbl = ttk.Label(self.logo_one_frame, text="(none)", style="Dim.TLabel")
        self.logo_lbl.pack(fill=tk.X)
        logo_btn_row = ttk.Frame(self.logo_one_frame, style="Card.TFrame")
        logo_btn_row.pack(fill=tk.X, pady=(2, 0))
        ttk.Button(logo_btn_row, text="Add", command=self._browse_logo).pack(side=tk.LEFT, padx=2)
        ttk.Button(logo_btn_row, text="Clear", command=self._clear_logo).pack(side=tk.LEFT, padx=2)
        ttk.Checkbutton(card, text="Keep retiming files", variable=self.keep_files).pack(anchor=tk.W, pady=2)
        ttk.Checkbutton(card, text="Keep VEO sound (save retimed_sound/ folder)",
                        variable=self.keep_veo_sound).pack(anchor=tk.W, pady=2)
        sub_row = ttk.Frame(card, style="Card.TFrame")
        sub_row.pack(fill=tk.X, pady=2)
        ttk.Checkbutton(sub_row, text="Subtitles", variable=self.subtitles_enabled).pack(side=tk.LEFT)
        ttk.Checkbutton(sub_row, text="Custom template", variable=self.subtitles_custom,
                        command=lambda: _sub_custom_row.pack(fill=tk.X) if self.subtitles_custom.get()
                                        else _sub_custom_row.pack_forget()).pack(side=tk.LEFT, padx=(8, 0))
        _sub_custom_row = ttk.Frame(card, style="Card.TFrame")
        ttk.Entry(_sub_custom_row, textvariable=self.subtitles_path, width=36).pack(side=tk.LEFT, padx=4)
        ttk.Button(_sub_custom_row, text="Add",
                   command=lambda: self.subtitles_path.set(
                       filedialog.askopenfilename(filetypes=[("ASS subtitles", "*.ass"), ("All files", "*.*")])
                   )).pack(side=tk.LEFT)

        # YT Pack
        card = self.app.create_card(self.left, "YT Packer (final stage)")
        ttk.Checkbutton(card, text="Run YT Pack after pipeline", variable=self.yt_pack_enabled,
                        command=self._on_ytpack_toggle).pack(anchor=tk.W)
        self.yt_pack_subform = ttk.Frame(card, style="Card.TFrame")
        r1 = ttk.Frame(self.yt_pack_subform, style="Card.TFrame")
        r1.pack(fill=tk.X, pady=(4, 2))
        ttk.Label(r1, text="Languages:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Entry(r1, textvariable=self.yt_pack_languages, width=16).pack(side=tk.LEFT, padx=4)
        ttk.Label(r1, text="(comma-separated, e.g. ru,en)", style="Dim.TLabel").pack(side=tk.LEFT)
        r2 = ttk.Frame(self.yt_pack_subform, style="Card.TFrame")
        r2.pack(fill=tk.X, pady=2)
        ttk.Checkbutton(r2, text="Subtitles", variable=self.yt_pack_subtitles).pack(side=tk.LEFT, padx=2)
        ttk.Checkbutton(r2, text="Description", variable=self.yt_pack_description).pack(side=tk.LEFT, padx=6)
        ttk.Checkbutton(r2, text="Covers", variable=self.yt_pack_covers,
                        command=self._on_covers_toggle).pack(side=tk.LEFT, padx=6)
        # Cover ref images (for YT Packer thumbnails → project/ref_thumb/)
        self.cover_ref_row = ttk.Frame(self.yt_pack_subform, style="Card.TFrame")
        # Provider + model row
        _COVER_MODELS_FASTGEN   = ['GEM_PIX_2', 'GEM_PIX', 'GEMINI', 'NARWHAL', 'GROK', 'IMAGEN_3_5']
        _COVER_MODELS_VEONONSTOP = ['GEM_PIX_2', 'NARWHAL', 'IMAGEN_3_5']
        cr_prov = ttk.Frame(self.cover_ref_row, style="Card.TFrame")
        cr_prov.pack(fill=tk.X, pady=(0, 2))
        ttk.Label(cr_prov, text="Provider:", style="Dim.TLabel").pack(side=tk.LEFT)
        self._cover_model_combo = ttk.Combobox(cr_prov, textvariable=self.cover_model,
                                               values=_COVER_MODELS_FASTGEN, width=12, state='readonly')
        def _on_cover_provider_changed(*_):
            prov = self.cover_provider.get()
            opts = _COVER_MODELS_VEONONSTOP if prov == 'veononstop' else _COVER_MODELS_FASTGEN
            self._cover_model_combo['values'] = opts
            if self.cover_model.get() not in opts:
                self.cover_model.set(opts[0])
        ttk.Combobox(cr_prov, textvariable=self.cover_provider,
                     values=['fastgen', 'veononstop'], width=10, state='readonly',
                     ).pack(side=tk.LEFT, padx=(4, 8))
        self.cover_provider.trace_add('write', _on_cover_provider_changed)
        ttk.Label(cr_prov, text="Model:", style="Dim.TLabel").pack(side=tk.LEFT)
        self._cover_model_combo.pack(side=tk.LEFT, padx=4)
        # Refs row
        cr_top = ttk.Frame(self.cover_ref_row, style="Card.TFrame")
        cr_top.pack(fill=tk.X)
        ttk.Label(cr_top, text="Cover refs:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Button(cr_top, text="Add", command=self._browse_cover_refs).pack(side=tk.LEFT, padx=3)
        ttk.Button(cr_top, text="Clear", command=self._clear_cover_refs).pack(side=tk.LEFT, padx=2)
        cr_list_frame = ttk.Frame(self.cover_ref_row, style="Card.TFrame")
        cr_list_frame.pack(fill=tk.X, pady=(2, 0))
        self.cover_ref_listbox = tk.Listbox(cr_list_frame, height=2, bg=COLORS['bg_input'], fg=COLORS['text'],
                                            font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        cr_sb = ttk.Scrollbar(cr_list_frame, orient=tk.VERTICAL, command=self.cover_ref_listbox.yview)
        self.cover_ref_listbox.config(yscrollcommand=cr_sb.set)
        self.cover_ref_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        cr_sb.pack(side=tk.RIGHT, fill=tk.Y)
        def _on_cover_mousewheel(event):
            if self.cover_ref_listbox.size() > int(self.cover_ref_listbox.cget('height')):
                self.cover_ref_listbox.yview_scroll(-1 * (event.delta // 120), "units")
                return "break"
        self.cover_ref_listbox.bind("<MouseWheel>", _on_cover_mousewheel)
        self._on_covers_toggle()

    def _on_covers_toggle(self):
        if self.yt_pack_covers.get():
            self.cover_ref_row.pack(fill=tk.X, pady=(4, 0))
        else:
            self.cover_ref_row.pack_forget()

    def _browse_cover_refs(self):
        paths = filedialog.askopenfilenames(
            title="Select cover reference images",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp *.tiff *.tif *.gif *.heic *.heif *.avif *.svg *.ico *.jfif"), ("All files", "*.*")]
        )
        for p in paths:
            pp = Path(p)
            if pp not in self.cover_ref_images:
                self.cover_ref_images.append(pp)
        self._refresh_cover_ref_listbox()

    def _clear_cover_refs(self):
        self.cover_ref_images.clear()
        self._refresh_cover_ref_listbox()

    def _refresh_cover_ref_listbox(self):
        self.cover_ref_listbox.delete(0, tk.END)
        for p in self.cover_ref_images:
            self.cover_ref_listbox.insert(tk.END, p.name)
        self.cover_ref_listbox.config(height=max(2, min(len(self.cover_ref_images), 6)))

    def _on_ytpack_toggle(self):
        if self.yt_pack_enabled.get():
            self.yt_pack_subform.pack(fill=tk.X, pady=(2, 0))
        else:
            self.yt_pack_subform.pack_forget()

    def _build_right(self, parent):
        # Collapsible container for files/summary/presets
        self._right_collapsible = ttk.Frame(parent)
        self._right_collapsible.pack(fill=tk.X)
        self._right_collapsed = False

        # ── Source Files + Style Guide side by side ─────────────────────
        top_row = ttk.Frame(self._right_collapsible)
        top_row.pack(fill=tk.X, pady=4, padx=2)

        # Source Files (left half)
        files_card = ttk.Frame(top_row, style="Card.TFrame", padding=12)
        files_card.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 3))
        ttk.Label(files_card, text="Start Files", style="Section.TLabel").pack(anchor=tk.W)
        self.files_listbox = tk.Listbox(files_card, height=3, bg=COLORS['bg_input'], fg=COLORS['text'],
                                         font=FONT_DIM, selectbackground=COLORS['accent'],
                                         selectforeground='#ffffff', relief=tk.FLAT, borderwidth=0)
        self.files_listbox.pack(fill=tk.X, pady=(4, 4))
        self.loaded_files: list[Path] = []
        btn_row = ttk.Frame(files_card, style="Card.TFrame")
        btn_row.pack(fill=tk.X)
        ttk.Button(btn_row, text="Add", command=self._add_source_files).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="Remove", command=self._remove_source_file).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="Clear", command=self._clear_source_files).pack(side=tk.LEFT, padx=2)
        self.files_count_lbl = ttk.Label(files_card, text="0 files", style="Dim.TLabel")
        self.files_count_lbl.pack(anchor=tk.W, pady=(2, 0))

        # Style Guide (right half)
        sg_card = ttk.Frame(top_row, style="Card.TFrame", padding=12)
        sg_card.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(3, 0))
        # Title + radio buttons on the same line
        sg_title_row = ttk.Frame(sg_card, style="Card.TFrame")
        sg_title_row.pack(fill=tk.X)
        ttk.Label(sg_title_row, text="Style Guide", style="Section.TLabel").pack(side=tk.LEFT)
        self.sg_mode = tk.StringVar(value="one_for_all")
        ttk.Radiobutton(sg_title_row, text="One for all", variable=self.sg_mode,
                        value="one_for_all", command=self._on_sg_mode_change).pack(side=tk.LEFT, padx=(10, 4))
        ttk.Radiobutton(sg_title_row, text="Individual", variable=self.sg_mode,
                        value="individual", command=self._on_sg_mode_change).pack(side=tk.LEFT)
        # Sub-panels stacked via place — guaranteed full coverage, no size jump
        _C = COLORS['bg_card']
        sg_stack = tk.Frame(sg_card, bg=_C)
        sg_stack.pack(fill=tk.X)
        # Individual panel (defines the container height — taller of the two)
        self.sg_ind_frame = tk.Frame(sg_stack, bg=_C)
        self.sg_ind_frame.pack(fill=tk.X)   # drives height
        self.sg_ind_listbox = tk.Listbox(self.sg_ind_frame, height=3, bg=COLORS['bg_input'],
                                          fg=COLORS['text'], font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        self.sg_ind_listbox.pack(fill=tk.X, pady=(0, 4))
        self.sg_individual: dict[str, Optional[Path]] = {}
        sg_btn_row = tk.Frame(self.sg_ind_frame, bg=_C)
        sg_btn_row.pack(fill=tk.X)
        ttk.Button(sg_btn_row, text="Set", command=self._set_individual_sg).pack(side=tk.LEFT, padx=2)
        ttk.Button(sg_btn_row, text="Clear", command=self._clear_individual_sg).pack(side=tk.LEFT, padx=2)
        # One-for-all panel — placed over ind_frame, same size
        self.sg_one_frame = tk.Frame(sg_stack, bg=_C)
        self.sg_one_frame.place(x=0, y=0, relwidth=1, relheight=1)
        self.sg_global_path: Optional[Path] = None
        self.sg_global_lbl = ttk.Label(self.sg_one_frame, text="(none)", style="Dim.TLabel")
        self.sg_global_lbl.pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(self.sg_one_frame, text="Add", command=self._browse_sg_global).pack(side=tk.RIGHT, padx=2)

        # ── Preset per file ─────────────────────────────────────────────
        preset_ind_card = self.app.create_card(self._right_collapsible, "Preset per file")
        self.preset_ind_listbox = tk.Listbox(preset_ind_card, height=3,
            bg=COLORS['bg_input'], fg=COLORS['text'], font=FONT_DIM,
            relief=tk.FLAT, borderwidth=0)
        self.preset_ind_listbox.pack(fill=tk.X, pady=(0, 4))
        self.preset_individual: dict[str, str] = {}
        pi_btn_row = tk.Frame(preset_ind_card, bg=COLORS['bg_card'])
        pi_btn_row.pack(fill=tk.X)
        ttk.Button(pi_btn_row, text="Set", command=self._set_individual_preset).pack(side=tk.LEFT, padx=2)
        ttk.Button(pi_btn_row, text="Clear", command=self._clear_individual_preset).pack(side=tk.LEFT, padx=2)
        ttk.Button(pi_btn_row, text="Clear All", command=self._clear_all_presets).pack(side=tk.LEFT, padx=2)

        # ── Summary (2-column) ───────────────────────────────────────────
        card = self.app.create_card(self._right_collapsible, "Summary")
        sum_cols = ttk.Frame(card, style="Card.TFrame")
        sum_cols.pack(fill=tk.X, pady=4)
        self.summary_label_left = tk.Label(sum_cols, text="", bg=COLORS['bg_card'], fg=COLORS['text'],
                                           font=FONT_LOG, justify=tk.LEFT, anchor=tk.NW)
        self.summary_label_left.pack(side=tk.LEFT, fill=tk.X, expand=True, anchor=tk.NW)
        self.summary_label_right = tk.Label(sum_cols, text="", bg=COLORS['bg_card'], fg=COLORS['text'],
                                            font=FONT_LOG, justify=tk.LEFT, anchor=tk.NW)
        self.summary_label_right.pack(side=tk.LEFT, fill=tk.X, expand=True, anchor=tk.NW)
        self._update_summary()
        # Trace all variables to auto-update summary
        for var in [self.start_point, self.language, self.direction_mode, self.clip_mode,
                    self.img_gen, self.fastgen_model, self.video_mode, self.veo_ratio,
                    self.prompt_mode, self.render_mode, self.watermark, self.veo_imggen_mode,
                    self.veo_banana_model]:
            var.trace_add('write', lambda *a: self._update_summary())
        for var in [self.clip_min, self.clip_max, self.veo_parallel, self.fastgen_parallel,
                    self.keep_files, self.intro_duration, self.intro_clip_min, self.intro_clip_max,
                    self.p1_chunk_threshold, self.p1_chunk_duration]:
            var.trace_add('write', lambda *a: self._update_summary())

        # Stage progress
        card = self.app.create_card(parent, "Stage Progress")
        self.stage_frame = ttk.Frame(card, style="Card.TFrame")
        self.stage_frame.pack(fill=tk.X, pady=4)
        self.stage_labels = []
        stages = ["Queue", "Transcribe", "Direction", "ImgGen", "VideoGen", "Concat"]
        for i, name in enumerate(stages):
            lbl = tk.Label(self.stage_frame, text=name, bg=COLORS['bg_card'],
                           fg=COLORS['text_muted'], font=FONT_DIM)
            lbl.pack(side=tk.LEFT, padx=3)
            self.stage_labels.append(lbl)
            if i < len(stages) - 1:
                tk.Label(self.stage_frame, text="->", bg=COLORS['bg_card'],
                         fg=COLORS['text_muted'], font=FONT_DIM).pack(side=tk.LEFT)
        self.stage_progress = ttk.Progressbar(card, mode='determinate', maximum=len(stages),
                                               style="Custom.Horizontal.TProgressbar")
        self.stage_progress.pack(fill=tk.X, pady=(4, 2))
        # Per-stage task progress
        task_row = ttk.Frame(card, style="Card.TFrame")
        task_row.pack(fill=tk.X, pady=(2, 0))
        self.task_progress = ttk.Progressbar(task_row, mode='determinate', maximum=100,
                                              style="Green.Horizontal.TProgressbar")
        self.task_progress.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.task_progress_lbl = ttk.Label(task_row, text="", style="Dim.TLabel", width=10, anchor=tk.E)
        self.task_progress_lbl.pack(side=tk.RIGHT, padx=(6, 0))

        # Buttons
        btn_frame = ttk.Frame(parent, style="Card.TFrame")
        btn_frame.pack(fill=tk.X, pady=4, padx=2)
        self.start_btn = ttk.Button(btn_frame, text="Start Pipeline",
                                    command=self.start_pipeline, style="Accent.TButton")
        self.start_btn.pack(side=tk.LEFT, padx=4)
        self.stop_btn = ttk.Button(btn_frame, text="Stop", command=self.stop_pipeline,
                                   state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=4)
        ttk.Button(btn_frame, text="Open Projects",
                   command=lambda: os.startfile(str(SCRIPT_DIR / 'projects'))).pack(side=tk.LEFT, padx=4)
        ttk.Button(btn_frame, text="Save Defaults", command=self._save_defaults).pack(side=tk.RIGHT, padx=4)

        # Log — expand to fill remaining height
        log_card = ttk.Frame(parent, style="Card.TFrame", padding=12)
        log_card.pack(fill=tk.BOTH, expand=True, pady=4, padx=2)
        log_hdr = ttk.Frame(log_card, style="Card.TFrame")
        log_hdr.pack(fill=tk.X)
        ttk.Label(log_hdr, text="Pipeline Log", style="Section.TLabel").pack(side=tk.LEFT)
        ttk.Button(log_hdr, text="Clear", command=lambda: self.log_widget.delete("1.0", tk.END)).pack(side=tk.RIGHT)

        def _toggle_right_panels():
            if self._right_collapsed:
                self._right_collapsible.pack(fill=tk.X, before=log_card)
                self._right_collapsed = False
                _toggle_btn.config(text="Hide panels")
            else:
                self._right_collapsible.pack_forget()
                self._right_collapsed = True
                _toggle_btn.config(text="Show panels")
        _toggle_btn = ttk.Button(log_hdr, text="Hide panels", command=_toggle_right_panels)
        _toggle_btn.pack(side=tk.RIGHT, padx=4)
        self.log_widget = self.app.create_log_widget(log_card)
        self.spinner_lbl = ttk.Label(log_card, text="", style="Dim.TLabel", anchor=tk.W,
                                     font=FONT_DIM)
        self.spinner_lbl.pack(fill=tk.X, pady=(1, 0))

    def _on_imggen_change(self):
        mode = self.img_gen.get()
        self.fg_frame.pack_forget()
        self.veo_img_frame.pack_forget()
        self.ref_row.pack_forget()
        if mode == "fastgen":
            self.fg_frame.pack(fill=tk.X, pady=4)
            self.ref_row.pack(fill=tk.X, pady=(0, 4))
        elif mode == "veononstop":
            self.veo_img_frame.pack(fill=tk.X, pady=4)
            self._on_veo_mode_change()
        if self.video_mode.get() == 'components':
            self.ref_row.pack(fill=tk.X, pady=(0, 4))

    def _on_video_mode_change(self):
        if self.video_mode.get() == 'components':
            self.ref_row.pack(fill=tk.X, pady=(0, 4))
        else:
            self._on_imggen_change()

    def _on_prompt_mode_change(self):
        if self.prompt_mode.get() == "single":
            self.single_prompt_row.pack(fill=tk.X, pady=2)
        else:
            self.single_prompt_row.pack_forget()

    def _on_veo_mode_change(self):
        mode = self.veo_imggen_mode.get()
        if mode == 'imagen':
            self.veo_model_row.pack_forget()
            self.ref_row.pack_forget()
        elif mode == 'banana_ref':
            self.veo_model_row.pack(fill=tk.X, pady=(4, 0))
            self.ref_row.pack(fill=tk.X, pady=(4, 0))
        else:
            self.veo_model_row.pack(fill=tk.X, pady=(4, 0))
            self.ref_row.pack_forget()
        if self.video_mode.get() == 'components':
            self.ref_row.pack(fill=tk.X, pady=(4, 0))

    def _browse_ref_images(self):
        paths = filedialog.askopenfilenames(
            title="Select reference images",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp *.tiff *.tif *.gif *.heic *.heif *.avif *.svg *.ico *.jfif"), ("All files", "*.*")]
        )
        for p in paths:
            pp = Path(p)
            if pp not in self.ref_images:
                self.ref_images.append(pp)
        self._refresh_ref_listbox()

    def _remove_ref_image(self):
        sel = self.ref_listbox.curselection()
        if sel:
            self.ref_images.pop(sel[0])
            self._refresh_ref_listbox()

    def _clear_ref_images(self):
        self.ref_images.clear()
        self._refresh_ref_listbox()

    def _refresh_ref_listbox(self):
        self.ref_listbox.delete(0, tk.END)
        for p in self.ref_images:
            self.ref_listbox.insert(tk.END, p.name)
        self.ref_listbox.config(height=max(2, min(len(self.ref_images), 6)))

    # ── Individual refs ──

    def _on_ref_mode_change(self):
        if self.ref_mode.get() == "one_for_all":
            self.ref_one_frame.tkraise()
        else:
            self.ref_ind_frame.tkraise()
            self._refresh_ref_ind_list()

    def _refresh_ref_ind_list(self):
        self.ref_ind_listbox.delete(0, tk.END)
        for f in self.loaded_files:
            refs = self.ref_individual.get(f.name, [])
            n = len(refs)
            label = f"{f.name}  ->  {n} ref{'s' if n != 1 else ''}" if n else f"{f.name}  ->  (none)"
            self.ref_ind_listbox.insert(tk.END, label)
        self.ref_ind_listbox.config(height=max(2, min(len(self.loaded_files), 5)))

    def _browse_ind_ref(self):
        sel = self.ref_ind_listbox.curselection()
        if not sel:
            messagebox.showinfo("Info", "Select a file in the list first")
            return
        idx = sel[0]
        if idx >= len(self.loaded_files):
            return
        target = self.loaded_files[idx]
        paths = filedialog.askopenfilenames(
            title=f"Refs for {target.name}",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp *.tiff *.tif *.gif *.heic *.heif *.avif *.svg *.ico *.jfif"), ("All files", "*.*")]
        )
        if paths:
            existing = self.ref_individual.setdefault(target.name, [])
            for p in paths:
                pp = Path(p)
                if pp not in existing:
                    existing.append(pp)
            self._refresh_ref_ind_list()

    def _clear_ind_ref(self):
        sel = self.ref_ind_listbox.curselection()
        if not sel:
            messagebox.showinfo("Info", "Select a file in the list first")
            return
        idx = sel[0]
        if idx >= len(self.loaded_files):
            return
        target = self.loaded_files[idx]
        self.ref_individual.pop(target.name, None)
        self._refresh_ref_ind_list()

    def _browse_logo(self):
        path = filedialog.askopenfilename(title="Select logo image",
                                           filetypes=[("Images", "*.png *.jpg *.jpeg *.webp"), ("All", "*.*")])
        if path:
            self.logo_path = Path(path)
            self.logo_lbl.config(text=self.logo_path.name)

    def _clear_logo(self):
        self.logo_path = None
        self.logo_lbl.config(text="(none)")

    def _on_logo_mode_change(self):
        if self.logo_mode.get() == "one_for_all":
            self.logo_one_frame.lift()
        else:
            self.logo_ind_frame.lift()
            self._refresh_logo_ind_list()

    def _refresh_logo_ind_list(self):
        self.logo_ind_listbox.delete(0, tk.END)
        for f in self.loaded_files:
            logo = self.logo_individual.get(f.name)
            label = f"{f.name}  →  {logo.name}" if logo else f"{f.name}  →  (none)"
            self.logo_ind_listbox.insert(tk.END, label)

    def _browse_ind_logo(self):
        sel = self.logo_ind_listbox.curselection()
        if not sel or not self.loaded_files:
            return
        idx = sel[0]
        if idx >= len(self.loaded_files):
            return
        audio_file = self.loaded_files[idx]
        path = filedialog.askopenfilename(
            title=f"Select logo for {audio_file.name}",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp"), ("All", "*.*")]
        )
        if path:
            self.logo_individual[audio_file.name] = Path(path)
            self._refresh_logo_ind_list()

    def _clear_ind_logo(self):
        sel = self.logo_ind_listbox.curselection()
        if not sel or not self.loaded_files:
            return
        idx = sel[0]
        if idx >= len(self.loaded_files):
            return
        audio_file = self.loaded_files[idx]
        self.logo_individual.pop(audio_file.name, None)
        self._refresh_logo_ind_list()

    def _browse_single_prompt(self):
        path = filedialog.askopenfilename(title="Select single prompt file",
                                           filetypes=[("Text", "*.txt"), ("All", "*.*")])
        if path:
            self.single_prompt_path = Path(path)
            self.single_prompt_lbl.config(text=self.single_prompt_path.name)
            self._update_summary()

    def _clear_single_prompt(self):
        self.single_prompt_path = None
        self.single_prompt_lbl.config(text="(none)")
        self._update_summary()

    # ── Source Files management ──

    def _add_source_files(self):
        sp = self.start_point.get()
        if sp == "audio":
            ftypes = [("Audio", "*.mp3 *.wav *.flac *.m4a *.aac"), ("All", "*.*")]
        else:
            ftypes = [("Scripts", "*.txt *.md"), ("All", "*.*")]
        # initialdir: last loaded file's folder, or ready_to_go/, or script dir
        if self.loaded_files:
            _initdir = str(self.loaded_files[-1].parent)
        else:
            _rtg = SCRIPT_DIR / 'ready_to_go'
            _initdir = str(_rtg) if _rtg.is_dir() else str(SCRIPT_DIR)
        paths = filedialog.askopenfilenames(title="Select source files",
                                            filetypes=ftypes, initialdir=_initdir)
        if not paths:
            return
        for p in paths:
            pp = Path(p)
            if pp not in self.loaded_files:
                self.loaded_files.append(pp)
        self._refresh_files_list()

    def _remove_source_file(self):
        sel = self.files_listbox.curselection()
        if not sel:
            return
        idx = sel[0]
        removed = self.loaded_files.pop(idx)
        self.sg_individual.pop(removed.name, None)
        self.ref_individual.pop(removed.name, None)
        self.logo_individual.pop(removed.name, None)
        self.preset_individual.pop(removed.name, None)
        self._refresh_files_list()

    def _clear_source_files(self):
        self.loaded_files.clear()
        self.sg_individual.clear()
        self.ref_individual.clear()
        self.logo_individual.clear()
        self.preset_individual.clear()
        self._refresh_files_list()

    def _refresh_files_list(self):
        self.files_listbox.delete(0, tk.END)
        for f in self.loaded_files:
            self.files_listbox.insert(tk.END, f.name)
        n = len(self.loaded_files)
        self.files_count_lbl.config(text=f"{n} file{'s' if n != 1 else ''} loaded")
        self._refresh_sg_ind_list()
        self._refresh_ref_ind_list()
        self._refresh_logo_ind_list()
        self._refresh_preset_ind_list()
        self._update_summary()

    # ── Style Guide management ──

    def _on_sg_mode_change(self):
        if self.sg_mode.get() == "one_for_all":
            self.sg_one_frame.tkraise()
        else:
            self.sg_ind_frame.tkraise()
            self._refresh_sg_ind_list()

    def _browse_sg_global(self):
        path = filedialog.askopenfilename(title="Select style guide",
                                           filetypes=[("Text", "*.txt *.md"), ("All", "*.*")])
        if path:
            self.sg_global_path = Path(path)
            self.sg_global_lbl.config(text=self.sg_global_path.name)
            self._update_summary()

    def _refresh_sg_ind_list(self):
        self.sg_ind_listbox.delete(0, tk.END)
        for f in self.loaded_files:
            sg = self.sg_individual.get(f.name)
            sg_name = sg.name if sg else "(none)"
            self.sg_ind_listbox.insert(tk.END, f"{f.name}  ->  {sg_name}")

    def _set_individual_sg(self):
        sel = self.sg_ind_listbox.curselection()
        if not sel:
            messagebox.showinfo("Info", "Select a file in the list first")
            return
        idx = sel[0]
        if idx >= len(self.loaded_files):
            return
        target = self.loaded_files[idx]
        path = filedialog.askopenfilename(title=f"Style guide for {target.name}",
                                           filetypes=[("Text", "*.txt *.md"), ("All", "*.*")])
        if path:
            self.sg_individual[target.name] = Path(path)
            self._refresh_sg_ind_list()
            self._update_summary()

    def _clear_individual_sg(self):
        sel = self.sg_ind_listbox.curselection()
        if not sel:
            return
        idx = sel[0]
        if idx >= len(self.loaded_files):
            return
        target = self.loaded_files[idx]
        self.sg_individual.pop(target.name, None)
        self._refresh_sg_ind_list()

    # ── Preset per file management ──

    def _refresh_preset_ind_list(self):
        self.preset_ind_listbox.delete(0, tk.END)
        for f in self.loaded_files:
            pname = self.preset_individual.get(f.name)
            if not pname:
                _global = self._preset_var.get().strip()
                pname = f"({_global})" if _global else "(default)"
            self.preset_ind_listbox.insert(tk.END, f"{f.name}  ->  {pname}")

    def _set_individual_preset(self):
        sel = self.preset_ind_listbox.curselection()
        if not sel:
            messagebox.showinfo("Info", "Select a file in the list first")
            return
        idx = sel[0]
        if idx >= len(self.loaded_files):
            return
        target = self.loaded_files[idx]
        presets = self._load_presets_file()
        if not presets:
            messagebox.showinfo("Info", "No presets saved yet.\nSave a preset first via the Preset card.")
            return
        names = sorted(presets.keys())
        dlg = tk.Toplevel(self.root)
        dlg.title(f"Preset for {target.name}")
        # Position near the Preset per file card
        try:
            _x = self.preset_ind_listbox.winfo_rootx() + 20
            _y = self.preset_ind_listbox.winfo_rooty() + self.preset_ind_listbox.winfo_height() + 4
            dlg.geometry(f"300x220+{_x}+{_y}")
        except Exception:
            dlg.geometry("300x220")
        dlg.transient(self.root)
        dlg.grab_set()
        lb = tk.Listbox(dlg, bg=COLORS['bg_input'], fg=COLORS['text'], font=FONT_DIM)
        lb.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)
        for n in names:
            lb.insert(tk.END, n)
        result = [None]
        def on_ok():
            s = lb.curselection()
            if s:
                result[0] = names[s[0]]
            dlg.destroy()
        lb.bind('<Double-1>', lambda e: on_ok())
        ttk.Button(dlg, text="OK", command=on_ok).pack(pady=(0, 8))
        dlg.wait_window()
        if result[0]:
            self.preset_individual[target.name] = result[0]
            self._refresh_preset_ind_list()
            self._update_summary()

    def _clear_individual_preset(self):
        sel = self.preset_ind_listbox.curselection()
        if not sel:
            return
        idx = sel[0]
        if idx >= len(self.loaded_files):
            return
        target = self.loaded_files[idx]
        self.preset_individual.pop(target.name, None)
        self._refresh_preset_ind_list()
        self._update_summary()

    def _clear_all_presets(self):
        if not self.preset_individual:
            return
        self.preset_individual.clear()
        self._refresh_preset_ind_list()
        self._update_summary()

    def _build_preset_process_args(self, preset, file, start_mode):
        """Build process CLI args from a preset dict for a single file."""
        import json as _json
        p = preset
        ig = str(p.get('img_gen', 'skip'))
        vm = str(p.get('video_mode', 'skip'))
        if ig == "fastgen" and vm == "i2v":
            pa = 'fastgen_i2v'
        elif ig == "veononstop" and vm == "i2v":
            pa = 'veo_i2v'
        elif vm == "t2v":
            pa = 't2v'
        elif vm == "components":
            pa = 'components'
        else:
            pa = 'skip'
        args = ['python', str(AGENT_DIR / 'agent.py'), 'process', '--run',
                '--language', str(p.get('language', 'ru')),
                '--clip-mode', str(p.get('clip_mode', 'video')),
                '--clip-min', str(int(p.get('clip_min', 4))),
                '--clip-max', str(int(p.get('clip_max', 8))),
                '--post-action', pa,
                '--prompt-mode', str(p.get('prompt_mode', 'auto'))]
        if str(p.get('clip_mode', 'video')) == 'vislide':
            args.extend(['--vislide-interval', str(int(p.get('vislide_interval', 3)))])
        if str(p.get('direction_mode', '1-pass')) == '2-pass':
            args.append('--two-pass')
        # Style guide
        _sg_mode = self.sg_mode.get()
        if _sg_mode == 'one_for_all' and self.sg_global_path:
            args.extend(['--style', str(self.sg_global_path)])
        elif _sg_mode == 'individual':
            sg = self.sg_individual.get(file.name)
            if sg and sg.exists():
                _audio_key = (file.stem + '.mp3') if start_mode == 'script_tts' else file.name
                args.extend(['--style-map', _json.dumps({_audio_key: str(sg)}, ensure_ascii=False)])
        # Single file
        _pqueue = SCRIPT_DIR / 'pipeline_queue'
        _fname = (file.stem + '.mp3') if start_mode == 'script_tts' else file.name
        args.extend(['--file-list', _json.dumps([str(_pqueue / _fname)], ensure_ascii=False)])
        args.extend(['--queue-dir', str(_pqueue)])
        # Ref map
        if self.ref_mode.get() == "individual":
            _pref_root = SCRIPT_DIR / '.pending_refs'
            _sd = _pref_root / file.stem
            if _sd.exists() and any(_sd.iterdir()):
                args.extend(['--ref-map', _json.dumps({file.name: str(_sd)}, ensure_ascii=False)])
        # YT pack
        if p.get('yt_pack_enabled', False):
            args.append('--yt-pack')
        return args

    @staticmethod
    def _apply_preset_to_env(env, preset):
        """Override env vars with values from a preset dict."""
        p = preset
        _DIRECT = {
            'veo_parallel': 'VEONONSTOP_MAX_PARALLEL',
            'veo_ratio': 'VEONONSTOP_ASPECT_RATIO',
            'veo_request_delay': 'VEONONSTOP_REQUEST_DELAY',
            'veo_max_retries': 'VEONONSTOP_MAX_RETRIES',
            'veo_max_silent_cycles': 'VEONONSTOP_MAX_SILENT_CYCLES',
            'veo_fast_censor': 'VEONONSTOP_FAST_CENSOR',
            'veo_imggen_key': 'VARAGENT_IMGGEN_KEY_SLOT',
            'veo_video_key': 'VARAGENT_VIDEO_KEY_SLOT',
            'veo_imggen_parallel': 'VARAGENT_IMGGEN_PARALLEL',
            'fastgen_aspect': 'FASTGEN_ASPECT_RATIO',
            'fastgen_parallel': 'FASTGEN_MAX_PARALLEL',
            'clip_min': 'VIDEO_CLIP_MIN_DURATION',
            'clip_max': 'VIDEO_CLIP_MAX_DURATION',
            'language': 'ASSEMBLYAI_LANGUAGE_CODE',
            'intro_duration': 'INTRO_BLOCK_DURATION',
            'intro_clip_min': 'INTRO_CLIP_MIN_DURATION',
            'intro_clip_max': 'INTRO_CLIP_MAX_DURATION',
            'remix_engine': 'REMIX_ENGINE',
        }
        for key, env_var in _DIRECT.items():
            if key in p:
                env[env_var] = str(p[key])
        if 'veo_parallel' in p:
            env['VARAGENT_VIDEO_PARALLEL'] = str(p['veo_parallel'])
        if 'inflight_mode' in p:
            env['VARAGENT_INFLIGHT_MODE'] = '1' if p['inflight_mode'] else '0'
            env['VARAGENT_SKIP_PREFLIGHT'] = '1' if p.get('skip_preflight', False) else '0'
        if str(p.get('clip_mode', 'video')) == 'vislide' and 'vislide_interval' in p:
            env['VARAGENT_VISLIDE_INTERVAL'] = str(int(p['vislide_interval']))
        if 'fastgen_model' in p:
            env['FASTGEN_MODEL'] = FASTGEN_NAME_TO_KEY.get(str(p['fastgen_model']), str(p['fastgen_model']))
        if 'veo_imggen_mode' in p:
            env['VEONONSTOP_IMGGEN_MODE'] = str(p['veo_imggen_mode'])
        if 'veo_banana_model' in p:
            env['VEONONSTOP_BANANA_MODEL'] = BANANA_NAME_TO_KEY.get(str(p['veo_banana_model']), 'GEM_PIX_2')
        if 'p1_chunk_threshold' in p:
            env['DIRECTOR_PASS1_CHUNK_THRESHOLD'] = str(int(p['p1_chunk_threshold']) * 60)
        if 'p1_chunk_duration' in p:
            env['DIRECTOR_PASS1_CHUNK_DURATION'] = str(int(p['p1_chunk_duration']) * 60)
        if 'watermark' in p and str(p['watermark']) != 'as_is':
            env['WATERMARK_MODE'] = str(p['watermark'])
        if p.get('yt_pack_enabled', False):
            env['YT_PACK_LANGUAGES'] = str(p.get('yt_pack_languages', 'ru,en'))
            env['YT_PACK_SUBTITLES'] = 'true' if p.get('yt_pack_subtitles', True) else 'false'
            env['YT_PACK_DESCRIPTION'] = 'true' if p.get('yt_pack_description', True) else 'false'
            env['YT_PACK_COVERS'] = 'true' if p.get('yt_pack_covers', True) else 'false'
            env['YT_PACK_COVER_PROVIDER'] = str(p.get('cover_provider', 'fastgen'))
            env['YT_PACK_COVER_MODEL'] = str(p.get('cover_model', 'GEM_PIX_2'))

    def _on_start_point_change(self):
        mode = self.start_point.get()
        # Clear files to avoid stale audio/script mix
        self._clear_source_files()
        if mode == "script_no_audio":
            self.type_row.pack(fill=tk.X, pady=(4, 0))
            self.lang_row.pack_forget()
        else:  # audio or script_tts
            self.type_row.pack_forget()
            self.lang_row.pack(fill=tk.X, pady=2)
        self._update_summary()

    def _update_summary(self):
        ig = self.img_gen.get()
        if ig == "fastgen":
            img_desc = f"FastGen ({self.fastgen_model.get()}, {self.fastgen_aspect.get()})"
        elif ig == "veononstop":
            veo_mode = self.veo_imggen_mode.get()
            if veo_mode == 'imagen':
                img_desc = "VeoNonStop (Imagen)"
            else:
                img_desc = f"VeoNonStop ({veo_mode}, {self.veo_banana_model.get()})"
        else:
            img_desc = "Skip"

        intro_dur = self.intro_duration.get()
        if intro_dur > 0:
            imin = self.intro_clip_min.get()
            imax = self.intro_clip_max.get()
            intro_desc = f"{intro_dur}s zone, clips {imin}-{imax}s" if imin > 0 else f"{intro_dur}s zone (inherit)"
        else:
            intro_desc = "off"

        # Files info
        n_files = len(self.loaded_files)
        files_desc = f"{n_files} file{'s' if n_files != 1 else ''}" if n_files > 0 else "ready_to_go/"
        sg_mode = self.sg_mode.get()
        if sg_mode == "one_for_all" and self.sg_global_path:
            sg_desc = self.sg_global_path.name
        elif sg_mode == "individual":
            n_sg = sum(1 for v in self.sg_individual.values() if v)
            sg_desc = f"{n_sg}/{n_files} individual"
        else:
            sg_desc = "auto (ready_to_go/)"
        if self.logo_mode.get() == "individual":
            _n_logos = sum(1 for v in self.logo_individual.values() if v)
            logo_desc = f"individual ({_n_logos} set)" if _n_logos else "individual (none set)"
        else:
            logo_desc = self.logo_path.name if self.logo_path else "none"
        prompt_desc = self.single_prompt_path.name if self.single_prompt_path else "auto"
        n_preset_ind = len(self.preset_individual)
        preset_desc = f"{n_preset_ind}/{n_files} with preset" if n_preset_ind else "default"

        sp = self.start_point.get()
        if sp == "script_no_audio":
            script_name = self.loaded_files[0].name if self.loaded_files else "(none)"
            start_desc = f"script ({self.script_type_var.get()}: {script_name})"
            lang_desc = "—"
        elif sp == "script_tts":
            script_name = self.loaded_files[0].name if self.loaded_files else "(none)"
            start_desc = f"script→audio ({script_name})"
            lang_desc = self.language.get()
        else:
            start_desc = "audio"
            lang_desc = self.language.get()

        left_lines = [
            f"Files:     {files_desc}",
            f"Style:     {sg_desc}",
            f"Preset:    {preset_desc}",
            f"Start:     {start_desc}",
            f"Language:  {lang_desc}",
            f"Direction: {self.direction_mode.get()}",
            f"Clips:     {self.clip_mode.get()} ({self.clip_min.get()}-{self.clip_max.get()}s)",
        ]
        right_lines = [
            f"Intro:     {intro_desc}",
            f"ImgGen:    {img_desc}",
            f"VideoGen:  {self.video_mode.get()} ({self.veo_ratio.get()}, x{self.veo_parallel.get()})",
            f"Prompt:    {prompt_desc}",
            f"Render:    {'fast' if self.render_mode.get() == '720p' else '1080p'}, wm={self.watermark.get()}",
            f"Logo:      {logo_desc}",
        ]
        self.summary_label_left.config(text="\n".join(left_lines))
        self.summary_label_right.config(text="\n".join(right_lines))

    def _set_stage(self, index):
        for i, lbl in enumerate(self.stage_labels):
            if i == index:
                lbl.config(fg=COLORS['yellow'])   # active
            elif i < index:
                lbl.config(fg=COLORS['green'])    # done
            else:
                lbl.config(fg=COLORS['accent'])   # pending
        self.stage_progress['value'] = index
        # Reset task progress on new stage
        self.task_progress['value'] = 0
        self.task_progress['maximum'] = 100
        self.task_progress_lbl.config(text="")

    def _set_task_progress(self, current: int, total: int):
        self.task_progress['maximum'] = total
        self.task_progress['value'] = current
        self.task_progress_lbl.config(text=f"{current} / {total}")

    def start_pipeline(self):
        if self.is_running:
            return

        # Сброс лога и индикаторов стадий
        self.log_widget.delete("1.0", tk.END)
        for lbl in self.stage_labels:
            lbl.config(fg=COLORS['accent'])
        self.stage_progress['value'] = 0
        self.spinner_lbl.config(text="")

        if self.loaded_files:
            # GUI pipeline mode — используем изолированную папку pipeline_queue/
            rtg = SCRIPT_DIR / 'pipeline_queue'
            if rtg.exists():
                shutil.rmtree(str(rtg))   # очистить стейл с прошлого запуска
            rtg.mkdir(parents=True)
            for src in self.loaded_files:
                dst = rtg / src.name
                shutil.copy2(str(src), str(dst))
                self.app.log(f"Copied: {src.name} -> pipeline_queue/", "INFO", tab="pipeline")

            # Log style guides (individual SGs are passed via --style-map, NOT copied to pipeline_queue)
            sg_mode = self.sg_mode.get()
            if sg_mode == "one_for_all" and self.sg_global_path and self.sg_global_path.exists():
                self.app.log(f"Style guide (global): {self.sg_global_path.name}", "INFO", tab="pipeline")
            elif sg_mode == "individual":
                for f in self.loaded_files:
                    sg = self.sg_individual.get(f.name)
                    if sg and sg.exists():
                        self.app.log(f"Style guide: {sg.name}", "INFO", tab="pipeline")
        else:
            # No files loaded — fallback: ready_to_go/ (manual / BAT mode)
            rtg = SCRIPT_DIR / 'ready_to_go'
            rtg.mkdir(parents=True, exist_ok=True)
            audio = list(rtg.glob('*.mp3')) + list(rtg.glob('*.wav')) + list(rtg.glob('*.flac'))
            if not audio and self.start_point.get() == "audio":
                messagebox.showerror("Error", "No files loaded and no audio in ready_to_go/")
                return

        # Валидация: banana_ref требует референсов
        _has_refs = bool(self.ref_images) if self.ref_mode.get() == "one_for_all" \
                    else any(v for v in self.ref_individual.values())
        if self.img_gen.get() == "veononstop" and self.veo_imggen_mode.get() == "banana_ref" and not _has_refs:
            messagebox.showerror(
                "Refs required",
                "Mode is Banana+Ref but no reference images loaded.\n\n"
                "Add refs via the Refs picker, or switch to Banana / Imagen."
            )
            return

        # Валидация: components требует референсов
        if self.video_mode.get() == "components" and not _has_refs:
            messagebox.showerror(
                "Refs required",
                "Video mode is Components but no reference images loaded.\n\n"
                "Add refs via the Refs picker, or switch to i2v / t2v."
            )
            return

        # Stage ref images
        if self.ref_mode.get() == "individual":
            # Per-file staging: .pending_refs/<audio_stem>/
            _pref_root = SCRIPT_DIR / '.pending_refs'
            if _pref_root.exists():
                shutil.rmtree(str(_pref_root))
            for _f in self.loaded_files:
                _refs = self.ref_individual.get(_f.name, [])
                if not _refs:
                    continue
                _sd = _pref_root / _f.stem
                _sd.mkdir(parents=True)
                for _img in _refs:
                    shutil.copy2(str(_img), str(_sd / _img.name))
                self.app.log(f"Staged {len(_refs)} ref(s) for {_f.name} -> .pending_refs/{_f.stem}/", "INFO", tab="pipeline")
        else:
            # One-for-all staging: .pending_refs/ (flat)
            # Always clear old staging first — prevents stale refs from previous runs
            staging = SCRIPT_DIR / '.pending_refs'
            if staging.exists():
                shutil.rmtree(str(staging))
            if self.ref_images:
                staging.mkdir()
                for img in self.ref_images:
                    shutil.copy2(str(img), str(staging / img.name))
                self.app.log(f"Staged {len(self.ref_images)} ref image(s) -> .pending_refs/", "INFO", tab="pipeline")

        # Stage individual logos → .pending_logos/<audio_stem>/
        if self.logo_mode.get() == "individual":
            _plogo_root = SCRIPT_DIR / '.pending_logos'
            if _plogo_root.exists():
                shutil.rmtree(str(_plogo_root))
            for _f in self.loaded_files:
                _logo = self.logo_individual.get(_f.name)
                if not _logo or not _logo.exists():
                    continue
                _sd = _plogo_root / _f.stem
                _sd.mkdir(parents=True)
                shutil.copy2(str(_logo), str(_sd / _logo.name))
                self.app.log(f"Staged logo for {_f.name}: {_logo.name}", "INFO", tab="pipeline")

        # Stage cover ref images → .pending_cover_refs/ (queue.py copies to project/ref_thumb/)
        if self.cover_ref_images:
            staging = SCRIPT_DIR / '.pending_cover_refs'
            if staging.exists():
                shutil.rmtree(str(staging))
            staging.mkdir()
            for img in self.cover_ref_images:
                shutil.copy2(str(img), str(staging / img.name))
            self.app.log(f"Staged {len(self.cover_ref_images)} cover ref(s) -> .pending_cover_refs/", "INFO", tab="pipeline")

        # Script mode validation
        start_mode = self.start_point.get()
        if start_mode in ("script_no_audio", "script_tts"):
            if not self.loaded_files:
                messagebox.showerror("Error", "No script file loaded. Use Add in Start Files to select a .txt script.")
                return
            if not self.loaded_files[0].exists():
                messagebox.showerror("Error", f"Script file not found:\n{self.loaded_files[0]}")
                return
            if start_mode == "script_no_audio":
                sg_mode = self.sg_mode.get()
                if sg_mode == "one_for_all" and not (self.sg_global_path and self.sg_global_path.exists()):
                    messagebox.showerror("Error", "Style guide required for script mode.\nSet a global style guide in the Style Guide card.")
                    return
            # script_tts: files already copied to ready_to_go/ in the loaded_files loop above

        self.is_running = True
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self._cancel = threading.Event()
        threading.Thread(target=self._pipeline_worker, daemon=True).start()

    def stop_pipeline(self):
        self._cancel.set()
        self.app.log("Pipeline stop requested...", "WARNING", tab="pipeline")

    def _pipeline_worker(self):
        try:
            # Set config overrides
            two_pass = self.direction_mode.get() == "2-pass"
            post_action = 'skip'
            ig = self.img_gen.get()
            vm = self.video_mode.get()
            if ig == "fastgen" and vm == "i2v":
                post_action = 'fastgen_i2v'
            elif ig == "veononstop" and vm == "i2v":
                post_action = 'veo_i2v'
            elif vm == "t2v":
                post_action = 't2v'
            elif vm == "components":
                post_action = 'components'

            # Build CLI phases (list of arg lists, run sequentially)
            start_mode = self.start_point.get()

            # Standard process pipeline (used by audio and script_tts phase 2)
            process_args = ['python', str(AGENT_DIR / 'agent.py'), 'process', '--run',
                            '--language', self.language.get(),
                            '--clip-mode', self.clip_mode.get(),
                            '--clip-min', str(self.clip_min.get()),
                            '--clip-max', str(self.clip_max.get()),
                            '--post-action', post_action,
                            '--prompt-mode', self.prompt_mode.get()]
            if self.clip_mode.get() == 'vislide':
                process_args.extend(['--vislide-interval', str(self.vislide_interval.get())])
            if two_pass:
                process_args.append('--two-pass')
            # Передаём style guide из GUI — обходит автопоиск по ready_to_go
            import json as _json
            _sg_mode = self.sg_mode.get()
            if _sg_mode == 'one_for_all' and self.sg_global_path:
                process_args.extend(['--style', str(self.sg_global_path)])
            elif _sg_mode == 'individual' and self.sg_individual:
                _sg_map = {}
                for f in self.loaded_files:
                    sg = self.sg_individual.get(f.name)
                    if not (sg and sg.exists()):
                        continue
                    # script_tts: loaded files are .txt scripts, but TTS outputs .mp3 audio
                    # agent.py process sees the generated audio filename, not the script filename
                    if start_mode == 'script_tts':
                        audio_key = f.stem + '.mp3'
                    else:
                        audio_key = f.name
                    _sg_map[audio_key] = str(sg)
                if _sg_map:
                    process_args.extend(['--style-map', _json.dumps(_sg_map, ensure_ascii=False)])

            # Передаём порядок файлов из GUI + папку очереди (pipeline_queue вместо ready_to_go)
            # При preset_individual — file-list добавляется позже, per-file
            if self.loaded_files and start_mode not in ("script_no_audio",) and not self.preset_individual:
                _pqueue = SCRIPT_DIR / 'pipeline_queue'
                _fl = []
                for _f in self.loaded_files:
                    # script_tts: загружены .txt, но после TTS в pipeline_queue лежат .mp3
                    _fname = (_f.stem + '.mp3') if start_mode == 'script_tts' else _f.name
                    _fl.append(str(_pqueue / _fname))
                process_args.extend(['--file-list', _json.dumps(_fl, ensure_ascii=False)])
                process_args.extend(['--queue-dir', str(_pqueue)])

            if start_mode == "script_no_audio":
                script_path = str(self.loaded_files[0])
                sg_mode = self.sg_mode.get()
                _script_file = self.loaded_files[0]
                if sg_mode == "one_for_all" and self.sg_global_path:
                    style_path = str(self.sg_global_path)
                elif sg_mode == "individual":
                    _ind_sg = self.sg_individual.get(_script_file.name)
                    style_path = str(_ind_sg) if (_ind_sg and _ind_sg.exists()) else ""
                else:
                    style_path = ""
                project_name = Path(script_path).stem
                script_args = ['python', str(AGENT_DIR / 'agent.py'), 'script',
                               '--script', script_path,
                               '--style', style_path,
                               '--project', project_name,
                               '--script-type', self.script_type_var.get(),
                               '--clip-mode', self.clip_mode.get(),
                               '--clip-min', str(self.clip_min.get()),
                               '--clip-max', str(self.clip_max.get()),
                               '--post-action', post_action]
                if self.clip_mode.get() == 'vislide':
                    script_args.extend(['--vislide-interval', str(self.vislide_interval.get())])
                if two_pass:
                    script_args.append('--two-pass')
                phases = [script_args]
            elif start_mode == "script_tts":
                # Phase 1: TTS only → generates audio in ready_to_go/
                tts_args = ['python', str(AGENT_DIR / 'tools' / 'tts_runner.py'),
                            '--mode', 'silent', '--tts-only']
                # Phase 2: full pipeline with all GUI settings (identical to audio mode)
                phases = [tts_args, process_args]
            else:
                phases = [process_args]

            # Set env vars for the subprocess
            env = os.environ.copy()
            env['VEONONSTOP_MAX_PARALLEL'] = str(self.veo_parallel.get())
            env['VEONONSTOP_ASPECT_RATIO'] = self.veo_ratio.get()
            env['VEONONSTOP_REQUEST_DELAY'] = str(self.veo_request_delay.get())
            env['VEONONSTOP_MAX_RETRIES'] = str(self.veo_max_retries.get())
            env['VEONONSTOP_MAX_SILENT_CYCLES'] = str(self.veo_max_silent_cycles.get())
            env['VEONONSTOP_FAST_CENSOR'] = self.veo_fast_censor.get()
            env['VEONONSTOP_IMAGE_UPSCALE'] = self.image_upscale.get()
            env['VEONONSTOP_VIDEO_UPSCALE'] = 'true' if self.video_upscale.get() else ''
            env['VARAGENT_IMGGEN_KEY_SLOT']   = self.veo_imggen_key.get()
            env['VARAGENT_VIDEO_KEY_SLOT']    = self.veo_video_key.get()
            env['VARAGENT_IMGGEN_PARALLEL']   = str(self.veo_imggen_parallel.get())
            env['VARAGENT_VIDEO_PARALLEL']    = str(self.veo_parallel.get())
            env['VARAGENT_INFLIGHT_MODE']     = '1' if self.inflight_mode.get() else '0'
            env['VARAGENT_SKIP_PREFLIGHT']   = '1' if self.skip_preflight.get() else '0'
            if self.clip_mode.get() == 'vislide':
                env['VARAGENT_VISLIDE_INTERVAL'] = str(self.vislide_interval.get())
            env['FASTGEN_MODEL'] = FASTGEN_NAME_TO_KEY.get(self.fastgen_model.get(), self.fastgen_model.get())
            env['FASTGEN_ASPECT_RATIO'] = self.fastgen_aspect.get()
            env['FASTGEN_MAX_PARALLEL'] = str(self.fastgen_parallel.get())
            _fg_key_sel = self.fastgen_api_key.get()
            if _fg_key_sel == 'backup':
                bk = getattr(config, 'FASTGEN_API_KEY_BACKUP', '')
                if bk:
                    env['FASTGEN_API_KEY'] = bk
            elif _fg_key_sel == 'both':
                env['FASTGEN_DUAL_KEY'] = '1'
            env['VIDEO_CLIP_MIN_DURATION'] = str(self.clip_min.get())
            env['VIDEO_CLIP_MAX_DURATION'] = str(self.clip_max.get())
            env['ASSEMBLYAI_LANGUAGE_CODE'] = self.language.get()
            env['GEMINI_MODEL'] = self.gemini_model.get()
            env['INTRO_BLOCK_DURATION'] = str(self.intro_duration.get())
            env['INTRO_CLIP_MIN_DURATION'] = str(self.intro_clip_min.get())
            env['INTRO_CLIP_MAX_DURATION'] = str(self.intro_clip_max.get())
            env['DIRECTOR_PASS1_CHUNK_THRESHOLD'] = str(self.p1_chunk_threshold.get() * 60)
            env['DIRECTOR_PASS1_CHUNK_DURATION']  = str(self.p1_chunk_duration.get()  * 60)
            env['REMIX_ENGINE'] = self.remix_engine.get()
            if ig == "veononstop":
                env['VEONONSTOP_IMGGEN_MODE'] = self.veo_imggen_mode.get()
                env['VEONONSTOP_BANANA_MODEL'] = BANANA_NAME_TO_KEY.get(self.veo_banana_model.get(), 'GEM_PIX_2')
            wm = self.watermark.get()
            if wm != 'as_is':
                env['WATERMARK_MODE'] = wm
            if self.logo_mode.get() == "individual":
                _plogo_root = SCRIPT_DIR / '.pending_logos'
                _logo_map = {}
                for _f in self.loaded_files:
                    _sd = _plogo_root / _f.stem
                    if _sd.exists():
                        _logos = list(_sd.iterdir())
                        if _logos:
                            _audio_key = (_f.stem + '.mp3') if start_mode == 'script_tts' else _f.name
                            _logo_map[_audio_key] = str(_logos[0])
                if _logo_map:
                    env['VARAGENT_LOGO_MAP'] = _json.dumps(_logo_map, ensure_ascii=False)
            else:
                if self.logo_path and self.logo_path.exists():
                    env['LOGO_PATH'] = str(self.logo_path)
            if self.single_prompt_path and self.single_prompt_path.exists():
                env['SINGLE_PROMPT_FILE'] = str(self.single_prompt_path)
            if self.ref_mode.get() == "individual":
                # Individual refs: build ref-map from per-file staging dirs
                _pref_root = SCRIPT_DIR / '.pending_refs'
                _ref_map = {}
                for _f in self.loaded_files:
                    _sd = _pref_root / _f.stem
                    if _sd.exists() and any(_sd.iterdir()):
                        _ref_map[_f.name] = str(_sd)
                if _ref_map:
                    process_args.extend(['--ref-map', _json.dumps(_ref_map, ensure_ascii=False)])
            else:
                staging = SCRIPT_DIR / '.pending_refs'
                if staging.exists():
                    env['VARAGENT_REF_STAGING'] = str(staging)
            cover_staging = SCRIPT_DIR / '.pending_cover_refs'
            if cover_staging.exists():
                env['VARAGENT_COVER_REF_STAGING'] = str(cover_staging)
            if self.yt_pack_enabled.get():
                env['YT_PACK_LANGUAGES'] = self.yt_pack_languages.get()
                env['YT_PACK_SUBTITLES'] = 'true' if self.yt_pack_subtitles.get() else 'false'
                env['YT_PACK_DESCRIPTION'] = 'true' if self.yt_pack_description.get() else 'false'
                env['YT_PACK_COVERS'] = 'true' if self.yt_pack_covers.get() else 'false'
                env['YT_PACK_COVER_PROVIDER'] = self.cover_provider.get()
                env['YT_PACK_COVER_MODEL'] = self.cover_model.get()
                # Add --yt-pack to every agent.py phase (not tts_runner)
                for phase in phases:
                    if 'tts_runner' not in phase[1] and '--yt-pack' not in phase:
                        phase.append('--yt-pack')

            # ── Convert phases to (args, env) tuples ──
            if self.preset_individual and start_mode not in ("script_no_audio",):
                _presets_data = self._load_presets_file()
                _pqueue = SCRIPT_DIR / 'pipeline_queue'
                _tupled_phases = []
                for _phase in phases:
                    _is_process = any('agent.py' in str(a) for a in _phase) and 'process' in _phase
                    if not _is_process:
                        _tupled_phases.append((_phase, dict(env)))
                        continue
                    # Split process phase into per-file phases
                    for _f in self.loaded_files:
                        _pname = self.preset_individual.get(_f.name)
                        _pdata = _presets_data.get(_pname) if _pname else None
                        _fname = (_f.stem + '.mp3') if start_mode == 'script_tts' else _f.name
                        if _pdata:
                            _p_args = self._build_preset_process_args(_pdata, _f, start_mode)
                            _p_env = dict(env)
                            self._apply_preset_to_env(_p_env, _pdata)
                        else:
                            # Default: use current GUI args, add single-file --file-list
                            _p_args = list(_phase)
                            _p_args.extend(['--file-list', _json.dumps([str(_pqueue / _fname)], ensure_ascii=False)])
                            _p_args.extend(['--queue-dir', str(_pqueue)])
                            _p_env = dict(env)
                        self.app.log(f"  [{_f.name}] preset={_pname or 'default'}", "INFO", tab="pipeline")
                        _tupled_phases.append((_p_args, _p_env))
                phases = _tupled_phases
            else:
                phases = [(ph, dict(env)) for ph in phases]

            self.app.log("Starting pipeline...", "INFO", tab="pipeline")
            # ── Settings dump ──
            self.app.log("━" * 56, tab="pipeline")
            files_str = ", ".join(f.name for f in self.loaded_files) if self.loaded_files else "(none)"
            self.app.log(f"  Start:     {start_mode}  |  Files: {files_str}", tab="pipeline")
            self.app.log(f"  Language:  {self.language.get()}  |  Direction: {self.direction_mode.get()}", tab="pipeline")
            self.app.log(f"  Clips:     {self.clip_mode.get()} {self.clip_min.get()}-{self.clip_max.get()}s  |  Intro: {self.intro_duration.get()}s block {self.intro_clip_min.get()}-{self.intro_clip_max.get()}s", tab="pipeline")
            self.app.log(f"  Post:      {post_action}  |  Prompt: {self.prompt_mode.get()}  |  Render: {'fast' if self.render_mode.get() == '720p' else '1080p'}", tab="pipeline")
            if ig == "veononstop":
                self.app.log(f"  VeoNonStop: imggen={self.veo_imggen_mode.get()} model={self.veo_banana_model.get()} ratio={self.veo_ratio.get()} x{self.veo_parallel.get()}", tab="pipeline")
            elif ig == "fastgen":
                self.app.log(f"  FastGen:   model={self.fastgen_model.get()} ratio={self.fastgen_aspect.get()} x{self.fastgen_parallel.get()}", tab="pipeline")
            extras = []
            if wm != 'as_is':
                extras.append(f"watermark={wm}")
            if self.logo_path and self.logo_path.exists():
                extras.append(f"logo={self.logo_path.name}")
            if self.ref_mode.get() == "individual":
                _n_ind = sum(len(v) for v in self.ref_individual.values())
                if _n_ind:
                    extras.append(f"refs=individual ({_n_ind} total across {len(self.ref_individual)} files)")
            elif self.ref_images:
                extras.append(f"refs={len(self.ref_images)} ({', '.join(r.name for r in self.ref_images)})")
            if self.single_prompt_path and self.single_prompt_path.exists():
                extras.append(f"prompt={self.single_prompt_path.name}")
            if extras:
                self.app.log(f"  Extras:    {' | '.join(extras)}", tab="pipeline")
            if self.yt_pack_enabled.get():
                self.app.log(f"  YT Pack:   langs={self.yt_pack_languages.get()} subs={self.yt_pack_subtitles.get()} desc={self.yt_pack_description.get()} covers={self.yt_pack_covers.get()}", tab="pipeline")
            self.app.log(f"  Phases:    {len(phases)}", tab="pipeline")
            for _pi, (_ph, _) in enumerate(phases, 1):
                self.app.log(f"    [{_pi}] {' '.join(_ph)}", tab="pipeline")
            self.app.log("━" * 56, tab="pipeline")
            self.root.after(0, lambda: self._set_stage(0))

            stage_map = {
                # English keys
                'STAGE 1': 1, 'Transcrib': 1,
                'STAGE 2': 2, 'Direction': 2, 'Director': 2,
                'STAGE 3:': 3, 'Image gen': 3, 'FastGen': 3, 'imggen': 3,
                'STAGE 3.5': 4, 'Video gen': 4, 'veo_video': 4,
                'STAGE 4': 5, 'Concat': 5, 'video_concat': 5,
                'YT Pack': 6, 'YT PACKER': 6, 'yt_pack': 6,
                # Russian keys (agent outputs in Russian)
                'транскрипц': 1, 'загрузка аудио': 1,
                'режиссерск': 2, 'монтажный план': 2, 'проход 1/2': 2, 'отправка запроса': 2,
                'img2video': 4, 'i2v': 4,
            }

            _SPINNER_CHARS = set('⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏⏳')
            failed = False

            # Concat: запускается сразу на каждый PROJECT_DONE в отдельном потоке
            import concurrent.futures as _cf
            render   = self.render_mode.get()
            bitrate  = '20M' if render == '1080p' else '10M'
            _concat_pool = _cf.ThreadPoolExecutor(max_workers=1)
            _concat_futs = []

            def _do_concat(proj_dir):
                proj_path = Path(proj_dir)
                proj_name = proj_path.name
                _full_log_path = proj_path / 'pipeline_full.log'
                self.app.log(f"── Concat: {proj_name} ({render}, {bitrate}) ──", "INFO", tab="pipeline")
                self.root.after(0, lambda: self._set_stage(5))
                cmd = ['python', 'video_concat.py',
                       'montage_plan.json', '-o', f'{proj_name}.mp4', '-b', bitrate,
                       '--fps', str(self.concat_fps.get())]
                if render == '1080p':
                    cmd.extend(['-r', '1080'])
                if self.watermark.get() == 'blur':
                    cmd.append('--blur-borders')
                if (self.logo_mode.get() == "one_for_all"
                        and self.watermark.get() == 'logo'
                        and self.logo_path and self.logo_path.exists()):
                    cmd.extend(['--logo', str(self.logo_path)])
                # Individual + logo watermark: logo.png placed by queue.py, auto-detected by video_concat.py
                if self.keep_veo_sound.get():
                    cmd.append('--veo-audio-inline')
                if self.subtitles_enabled.get():
                    _tpl = self.subtitles_path.get() if self.subtitles_custom.get() else _find_ass_template(self.render_mode.get())
                    if _tpl:
                        cmd.extend(['--subtitles', _tpl])
                if self.keep_files.get():
                    cmd.append('--no-cleanup')
                cp = subprocess.Popen(
                    cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    stdin=subprocess.DEVNULL,
                    text=True, encoding='utf-8', errors='replace',
                    cwd=str(proj_path), env=env
                )
                _flog = open(_full_log_path, 'a', encoding='utf-8')
                _flog.write(f"\n── Concat: {proj_name} ({render}, {bitrate}) ──\n")
                for ln in cp.stdout:
                    if self._cancel.is_set():
                        cp.terminate()
                        break
                    ln = ln.rstrip()
                    if not ln:
                        continue
                    if ln.startswith('PROGRESS:'):
                        pm = re.match(r'PROGRESS:(\d+)/(\d+)', ln)
                        if pm:
                            pc, pt = int(pm.group(1)), int(pm.group(2))
                            if 0 <= pc <= pt <= 50000:
                                self.root.after(0, lambda c=pc, t=pt: self._set_task_progress(c, t))
                        continue
                    # Concat progress: "AAC кодирование: 50% ..." or "Сборка: 52% ..."
                    _pct_m = re.search(r'(?:кодирование|Сборка):\s*(\d+)%', ln)
                    if _pct_m:
                        _pct = int(_pct_m.group(1))
                        self.root.after(0, lambda c=_pct, t=100: self._set_task_progress(c, t))
                    m2 = re.search(r'\b(\d+)\s*/\s*(\d+)\b', ln)
                    if m2:
                        c2, t2 = int(m2.group(1)), int(m2.group(2))
                        if 0 < t2 <= 50000 and 0 <= c2 <= t2:
                            self.root.after(0, lambda c=c2, t=t2: self._set_task_progress(c, t))
                    lv = 'INFO'
                    lo = ln.lower()
                    if any(x in lo for x in ['error', 'fail', 'traceback']):
                        lv = 'ERROR'
                    elif any(x in lo for x in ['done', 'ok', 'complete', 'success', 'written']):
                        lv = 'SUCCESS'
                    self.app.log(ln, lv, tab="pipeline")
                    _flog.write(ln + '\n')
                _flog.close()
                cp.wait()
                return cp.returncode == 0
            # ETA tracking for imggen (stage 3) and videogen (stage 4)
            _eta_stage = 0       # current stage index
            _eta_start = None    # time when first clip of current stage arrived
            _eta_start_cur = 0   # clips already done when we started tracking
            for _phase_idx, (phase_args, phase_env) in enumerate(phases, 1):
                if self._cancel.is_set():
                    break
                if len(phases) > 1:
                    phase_label = Path(phase_args[1]).name if len(phase_args) > 1 else phase_args[0]
                    self.app.log(f"── Phase {_phase_idx}/{len(phases)}: {phase_label} ──", "INFO", tab="pipeline")
                proc = subprocess.Popen(
                    phase_args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    stdin=subprocess.DEVNULL,
                    text=True, encoding='utf-8', errors='replace',
                    cwd=str(SCRIPT_DIR), env=phase_env
                )
                for line in proc.stdout:
                    if self._cancel.is_set():
                        proc.terminate()
                        break
                    line = line.rstrip()
                    if not line:
                        continue
                    # Spinner lines (braille frames from director _run_with_spinner)
                    stripped = line.strip()
                    if stripped and stripped[0] in _SPINNER_CHARS and '✅' not in line:
                        self.root.after(0, lambda t=stripped: self.spinner_lbl.config(text=t))
                        ms = re.search(r'\b(\d+)\s*/\s*(\d+)\b', stripped)
                        if ms:
                            sc, st = int(ms.group(1)), int(ms.group(2))
                            if 0 < st <= 50000 and 0 <= sc <= st:
                                self.root.after(0, lambda c=sc, t=st: self._set_task_progress(c, t))
                        continue
                    # Done line — clear spinner
                    if '✅' in line:
                        self.root.after(0, lambda: self.spinner_lbl.config(text=""))
                    # Сигнал от agent.py: проект полностью готов к конкату
                    if line.startswith('PROJECT_DONE:'):
                        ppath = line.split(':', 1)[1].strip()
                        if ppath:
                            _concat_futs.append(_concat_pool.submit(_do_concat, ppath))
                        continue
                    # Явный сигнал прогресса от director.py / imggen / veo_video
                    if line.startswith('PROGRESS:'):
                        pm = re.match(r'PROGRESS:(\d+)/(\d+)', line)
                        if pm:
                            _pc, _pt = int(pm.group(1)), int(pm.group(2))
                            if 0 <= _pc <= _pt <= 50000:
                                self.root.after(0, lambda c=_pc, t=_pt: self._set_task_progress(c, t))
                                if _eta_stage in (3, 4) and _pc > 0 and _pt > 1:
                                    _now = time.time()
                                    if _eta_start is None:
                                        _eta_start = _now
                                        _eta_start_cur = _pc - 1
                                    _clips_since = _pc - _eta_start_cur
                                    _elapsed = _now - _eta_start
                                    if _clips_since > 0 and _elapsed > 0:
                                        _avg = _elapsed / _clips_since
                                        _rem = _pt - _pc
                                        _eta_sec = max(0.0, _avg * _rem)
                                        _cpm = 60.0 / _avg
                                        _mm, _ss = divmod(int(_eta_sec), 60)
                                        _eta_str = f"~{_mm}м {_ss:02d}с" if _mm > 0 else f"~{_ss}с"
                                        _lbl = (f"Final Stage {_eta_str}  "
                                                f"({_pc}/{_pt} клипов, ~{_avg:.0f}с/клип, ~{_cpm:.1f} кл/мин)")
                                        self.root.after(0, lambda t=_lbl: self.spinner_lbl.config(text=t))
                        continue
                    for key, idx in stage_map.items():
                        if key.lower() in line.lower():
                            if idx != _eta_stage:
                                if idx in (3, 4):
                                    _eta_start = None
                                    _eta_start_cur = 0
                                _eta_stage = idx
                            self.root.after(0, lambda i=idx: self._set_stage(i))
                            break
                    m = re.search(r'\b(\d+)\s*/\s*(\d+)\b', line)
                    if m:
                        cur, total = int(m.group(1)), int(m.group(2))
                        if 0 < total <= 50000 and 0 <= cur <= total:
                            if _eta_stage not in (2, 3, 4):
                                self.root.after(0, lambda c=cur, t=total: self._set_task_progress(c, t))
                    level = 'INFO'
                    low = line.lower()
                    stripped_low = low.strip()
                    if stripped_low.startswith('[ok]') or stripped_low.startswith('✅'):
                        level = 'SUCCESS'
                    elif any(x in low for x in ['error', 'fail', 'traceback']):
                        level = 'ERROR'
                    elif any(x in low for x in ['warn', 'skip', 'retry']):
                        level = 'WARNING'
                    self.app.log(line, level, tab="pipeline")
                proc.wait()
                if proc.returncode != 0:
                    self.app.log(f"Phase failed (exit code {proc.returncode})", "ERROR", tab="pipeline")
                    failed = True
                    break

            self.root.after(0, lambda: self.spinner_lbl.config(text=""))

            # ── Ждём завершения всех конкатов (запускались сразу по PROJECT_DONE) ──
            _concat_pool.shutdown(wait=True)
            for _fut in _concat_futs:
                try:
                    if not _fut.result():
                        failed = True
                except Exception as _fe:
                    self.app.log(f"Concat error: {_fe}", "ERROR", tab="pipeline")
                    failed = True

            if not failed and not self._cancel.is_set():
                self.app.log("Pipeline complete!", "SUCCESS", tab="pipeline")
                self.root.after(0, lambda: self._set_stage(len(self.stage_labels)))
            elif self._cancel.is_set():
                self.app.log("Pipeline cancelled.", "WARNING", tab="pipeline")

        except Exception as e:
            self.app.log(f"Pipeline error: {e}", "ERROR", tab="pipeline")
        finally:
            self.is_running = False
            self.root.after(0, lambda: self.start_btn.config(state=tk.NORMAL))
            self.root.after(0, lambda: self.stop_btn.config(state=tk.DISABLED))


# ════════════════════════════════════════════════════════════════════
# TAB 2: CONTROL PANEL
# ════════════════════════════════════════════════════════════════════

def _veo_key_options() -> list:
    """All single-key and multi-key combos for configured VeoNonStop keys."""
    from itertools import combinations as _combs
    _attrs = ['VEONONSTOP_API_KEY', 'VEONONSTOP_API_KEY_2', 'VEONONSTOP_API_KEY_3', 'VEONONSTOP_API_KEY_4']
    configured = [i + 1 for i, attr in enumerate(_attrs) if bool(getattr(config, attr, ''))]
    if not configured:
        return ['1']
    opts = [str(k) for k in configured]
    for r in range(2, len(configured) + 1):
        for combo in _combs(configured, r):
            opts.append(','.join(str(k) for k in combo))
    return opts


def _veo_sel_to_active(sel: str) -> list:
    """Convert key selection string to active_keys list for generate_all_*.
    Formats: 'key1' | 'all' | 'both' | '1,2,3' (comma-separated slot numbers)."""
    _ALL_ATTRS = ['VEONONSTOP_API_KEY', 'VEONONSTOP_API_KEY_2', 'VEONONSTOP_API_KEY_3', 'VEONONSTOP_API_KEY_4']
    if sel in ('both', 'all'):
        active = [i + 1 for i, a in enumerate(_ALL_ATTRS) if bool(getattr(config, a, ''))]
        return active if active else [1]
    # Comma-separated: "1,2" or "1,3"
    if ',' in sel:
        try:
            return [int(x) for x in sel.split(',') if x.strip()]
        except Exception:
            pass
    try:
        n = int(sel.replace('key', ''))
        return [n]
    except Exception:
        return [1]


class ControlPanelTab:
    """Project browser, per-stage buttons, .env editor."""

    def __init__(self, notebook, app: VarAgentGUI):
        self.app = app
        self.root = app.root
        self.frame = ttk.Frame(notebook)
        self.active_tasks = 0
        self._active_subproc = None  # текущий subprocess.Popen (Concat и др.)
        self.create_ui()

    def create_ui(self):
        # Static layout (same as Pipeline tab): panels pack top-down, log at bottom with expand=True
        self._inner = self.frame  # alias for finalize panel compatibility

        # Collapsible project list
        self._projects_frame = ttk.Frame(self._inner)
        self._projects_frame.pack(fill=tk.X)
        self._projects_collapsed = False
        card = self.app.create_card(self._projects_frame, "Projects")

        btn_row = ttk.Frame(card, style="Card.TFrame")
        btn_row.pack(fill=tk.X, pady=(0, 4))
        ttk.Button(btn_row, text="Refresh", command=self.refresh_projects).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="Delete", command=self._delete_projects,
                   style="Danger.TButton").pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="Dry-Run", command=self._run_dryrun).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="Mock Run", command=self._run_mock).pack(side=tk.LEFT, padx=2)
        self._pl_mode_btn = ttk.Button(btn_row, text="Pipeline Mode ▼",
                                       command=self._toggle_finalize_panel,
                                       style="Accent.TButton")
        self._pl_mode_btn.pack(side=tk.RIGHT, padx=2)

        cols = ("name", "audio", "transcr", "plan", "images", "videos", "mp4", "status")
        self.tree = ttk.Treeview(card, columns=cols, show='headings', height=8)
        col_widths = [180, 40, 40, 40, 50, 50, 40, 140]
        for c, w in zip(cols, col_widths):
            self.tree.column(c, width=w, anchor=tk.CENTER if w < 100 else tk.W)
        self.tree.pack(fill=tk.BOTH, expand=True)
        self.tree.bind('<Double-1>', self._open_project_folder)

        # Sort state: col key → ('fresh'=mtime desc by default), reverse flag
        self._sort_col = 'fresh'
        self._sort_reverse = True
        self._update_tree_headings()

        # Stage buttons
        card2 = self.app.create_card(self._inner, "Run Stage")
        self.stage_buttons = []
        # Row 1: start stages (no project required — will create one)
        row1 = ttk.Frame(card2, style="Card.TFrame")
        row1.pack(fill=tk.X)
        for label, cmd in [
            ("Script→Audio", self._run_script_tts),
            ("Script→Video", self._run_script_video),
            ("Transcribe", self._run_transcribe),
        ]:
            btn = ttk.Button(row1, text=label, command=cmd)
            btn.pack(side=tk.LEFT, padx=3, pady=2)
            self.stage_buttons.append(btn)
        # Row 2: continuation stages (require existing project)
        row2 = ttk.Frame(card2, style="Card.TFrame")
        row2.pack(fill=tk.X, pady=(2, 0))
        for label, cmd in [
            ("Scene Director", self._run_direct),
            ("ImageGen", self._run_imagegen),
            ("VideoGen", self._run_videogen),
            ("Concat", self._run_concat),
            ("YT Pack", self._run_ytpack),
        ]:
            btn = ttk.Button(row2, text=label, command=cmd)
            btn.pack(side=tk.LEFT, padx=3, pady=2)
            self.stage_buttons.append(btn)

        # Status bar + progress
        status_frame = ttk.Frame(card2, style="Card.TFrame")
        status_frame.pack(fill=tk.X, pady=(6, 0))
        self.status_label = tk.Label(status_frame, text="Ready", bg=COLORS['bg_card'],
                                     fg=COLORS['text_dim'], font=FONT_DIM, anchor=tk.W)
        self.status_label.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self._ctrl_stop_btn = ttk.Button(status_frame, text="Stop", command=self._stop_tasks, state=tk.DISABLED)
        self._ctrl_stop_btn.pack(side=tk.RIGHT, padx=4)
        self.progress_bar = ttk.Progressbar(card2, style="Custom.Horizontal.TProgressbar",
                                            mode='indeterminate', length=300)
        self.progress_bar.pack(fill=tk.X, pady=(4, 0))

        # Log — expands to fill remaining height (same pattern as Pipeline tab)
        log_card = ttk.Frame(self._inner, style="Card.TFrame", padding=12)
        log_card.pack(fill=tk.BOTH, expand=True, pady=4, padx=2)
        _ctrl_log_hdr = ttk.Frame(log_card, style="Card.TFrame")
        _ctrl_log_hdr.pack(fill=tk.X)
        ttk.Label(_ctrl_log_hdr, text="Task Log", style="Section.TLabel").pack(side=tk.LEFT)
        ttk.Button(_ctrl_log_hdr, text="Clear", command=lambda: self.log_widget.delete("1.0", tk.END)).pack(side=tk.RIGHT)

        def _toggle_projects():
            if self._projects_collapsed:
                self._projects_frame.pack(fill=tk.X, before=card2)
                self._projects_collapsed = False
                _prj_toggle_btn.config(text="Hide projects")
            else:
                self._projects_frame.pack_forget()
                self._projects_collapsed = True
                _prj_toggle_btn.config(text="Show projects")
        _prj_toggle_btn = ttk.Button(_ctrl_log_hdr, text="Hide projects", command=_toggle_projects)
        _prj_toggle_btn.pack(side=tk.RIGHT, padx=4)

        self.log_widget = self.app.create_log_widget(log_card)
        self._log_card = log_card

        # Finalize panel (hidden by default — toggled via Pipeline Mode button)
        self._finalize_visible = False
        self._finalize_frame = self._build_finalize_panel(self._inner)

        # Load data
        self.root.after(200, self.refresh_projects)

    _STATUS_ORDER = {
        'Complete': 0, 'Ready for Concat': 1, 'Ready for VideoGen': 2,
        'Ready for ImgGen': 3, 'Transcribed': 4, 'New': 5,
    }

    def _update_tree_headings(self):
        """Refresh column header labels with sort indicator."""
        cols = ("name", "audio", "transcr", "plan", "images", "videos", "mp4", "status")
        labels = {
            'name': 'Name', 'audio': 'Aud', 'transcr': 'Tr', 'plan': 'Plan',
            'images': 'Img', 'videos': 'Vid', 'mp4': 'MP4', 'status': 'Status',
            'fresh': None,  # virtual col — shown on Name
        }
        asc_desc = '▲' if not self._sort_reverse else '▼'
        for c in cols:
            display_col = 'name' if self._sort_col == 'fresh' else self._sort_col
            if c == display_col:
                prefix = asc_desc + ' '
            elif c == 'name' and self._sort_col == 'fresh':
                prefix = '🕐 '
            else:
                prefix = ''
            self.tree.heading(c, text=prefix + labels[c],
                              command=lambda col=c: self._sort_by(col))

    def _sort_by(self, col):
        if col == self._sort_col:
            self._sort_reverse = not self._sort_reverse
        else:
            self._sort_col = col
            self._sort_reverse = col in ('fresh', 'images', 'videos')  # desc by default
        self._update_tree_headings()
        self.refresh_projects()

    def refresh_projects(self):
        # Remember selection
        sel_names = {self.tree.item(i)['values'][0] for i in self.tree.selection()}

        self.tree.delete(*self.tree.get_children())
        projects_dir = SCRIPT_DIR / 'projects'
        if not projects_dir.exists():
            return

        projects = [p for p in projects_dir.iterdir()
                    if p.is_dir() and not p.name.startswith('_')]
        infos = [(p, self._scan_project(p)) for p in projects]

        col = self._sort_col
        rev = self._sort_reverse
        if col == 'fresh':
            infos.sort(key=lambda x: x[0].stat().st_mtime, reverse=rev)
        elif col == 'name':
            infos.sort(key=lambda x: x[1]['name'].lower(), reverse=rev)
        elif col == 'status':
            infos.sort(key=lambda x: self._STATUS_ORDER.get(x[1]['status'], 99), reverse=rev)
        elif col == 'images':
            infos.sort(key=lambda x: x[1]['img_count'], reverse=rev)
        elif col == 'videos':
            infos.sort(key=lambda x: x[1]['vid_count'], reverse=rev)
        else:
            infos.sort(key=lambda x: x[1]['name'].lower(), reverse=rev)

        for p, info in infos:
            iid = self.tree.insert('', tk.END, values=(
                info['name'],
                'Y' if info['has_audio'] else '-',
                'Y' if info['has_transcription'] else '-',
                'Y' if info['has_plan'] else '-',
                str(info['img_count']) if info['img_count'] else '-',
                str(info['vid_count']) if info['vid_count'] else '-',
                'Y' if info['has_mp4'] else '-',
                info['status'],
            ))
            if info['name'] in sel_names:
                self.tree.selection_add(iid)

    def _scan_project(self, p: Path) -> dict:
        has_audio = bool(list(p.glob('*.mp3')) + list(p.glob('*.wav')) + list(p.glob('*.flac')))
        has_tr = (p / 'transcription.json').exists()
        has_plan = (p / 'montage_plan.json').exists()
        gen = p / 'generated'
        vid = p / 'vid_img'
        img_count = len(list(gen.glob('*.png'))) if gen.exists() else 0
        vid_count = len(list(vid.glob('*.mp4'))) if vid.exists() else 0
        has_mp4 = bool([f for f in p.glob('*.mp4') if f.parent == p])

        if has_mp4:
            status = 'Complete'
        elif vid_count > 0:
            status = 'Ready for Concat'
        elif img_count > 0:
            status = 'Ready for VideoGen'
        elif has_plan:
            status = 'Ready for ImgGen'
        elif has_tr:
            status = 'Ready for Direction'
        elif has_audio:
            status = 'Ready for Transcription'
        else:
            status = 'Empty'
        return dict(name=p.name, has_audio=has_audio, has_transcription=has_tr,
                    has_plan=has_plan, img_count=img_count, vid_count=vid_count,
                    has_mp4=has_mp4, status=status)

    def _open_project_folder(self, event=None):
        sel = self.tree.selection()
        if not sel:
            return
        name = self.tree.item(sel[0])['values'][0]
        folder = SCRIPT_DIR / 'projects' / name
        if folder.exists():
            os.startfile(str(folder))

    def _delete_projects(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Warning", "Select a project first")
            return
        names = [self.tree.item(i)['values'][0] for i in sel]
        if len(names) == 1:
            msg = f"Delete project '{names[0]}' from disk?\nThis cannot be undone."
        else:
            listing = '\n'.join(f"  • {n}" for n in names)
            msg = f"Delete {len(names)} projects from disk?\n{listing}\n\nThis cannot be undone."
        if not messagebox.askyesno("Delete Projects", msg, icon='warning'):
            return
        errors = []
        for name in names:
            folder = SCRIPT_DIR / 'projects' / name
            try:
                shutil.rmtree(str(folder))
            except Exception as e:
                errors.append(f"{name}: {e}")
        self.refresh_projects()
        if errors:
            messagebox.showerror("Delete failed", "\n".join(errors))

    def _get_selected(self) -> Optional[Path]:
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Warning", "Select a project first")
            return None
        name = self.tree.item(sel[0])['values'][0]
        return SCRIPT_DIR / 'projects' / name

    def _update_status(self):
        n = self.active_tasks
        if n > 0:
            self.status_label.config(text=f"Running: {n} task{'s' if n > 1 else ''}", fg=COLORS['accent'])
            self.progress_bar.start(15)
            self._ctrl_stop_btn.config(state=tk.NORMAL)
        else:
            self.status_label.config(text="Ready", fg=COLORS['text_dim'])
            self.progress_bar.stop()
            self._ctrl_stop_btn.config(state=tk.DISABLED)

    def _stop_tasks(self):
        """Signal running generators to stop gracefully and cancel server-side tasks."""
        # imggen: set shutdown + cancel all server-side tasks
        try:
            from modules.imggen import _shutdown_event as _img_stop, _active_clients as _img_clients
            _img_stop.set()
            _cancelled_total = 0
            for _cc in _img_clients:
                try:
                    _cancelled_total += len(_cc.cancel_all_tasks())
                except Exception:
                    pass
            if _cancelled_total:
                self.app.log(f"Cancelled {_cancelled_total} imggen server task(s)", "WARNING", tab="control")
        except Exception:
            pass
        # veo_video: set shutdown + cancel all server-side tasks
        try:
            from modules.veo_video import _shutdown_requested as _veo_stop
            _veo_stop.set()
        except Exception:
            pass
        try:
            from modules.veo_video import _active_clients as _veo_clients
            _cancelled_v = 0
            for _cc in _veo_clients:
                try:
                    _cancelled_v += len(_cc.cancel_all_tasks())
                except Exception:
                    pass
            if _cancelled_v:
                self.app.log(f"Cancelled {_cancelled_v} videogen server task(s)", "WARNING", tab="control")
        except Exception:
            pass
        # Kill active subprocess (Concat / video_concat.py)
        proc = self._active_subproc
        if proc and proc.poll() is None:
            try:
                proc.terminate()
                self.app.log("Concat process terminated", "WARNING", tab="control")
            except Exception:
                pass
        self.status_label.config(text="Stopping...", fg=COLORS.get('warning', COLORS['accent']))
        self.app.log("Stop signal sent — cancelling server tasks", "WARNING", tab="control")

    def _run_in_thread(self, func, *args, task_name="", project_dir=None):
        self.active_tasks += 1
        self.root.after(0, self._update_status)
        self.app.log(f"Started: {task_name}", "INFO", tab="control")
        t_start = time.time()
        def worker():
            import datetime
            log_fh = None
            master_fh = None
            if project_dir:
                try:
                    ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
                    safe = "".join(c if c.isalnum() or c in '-_' else '_' for c in task_name)
                    log_path = Path(project_dir) / f"stage_{safe}_{ts}.log"
                    log_fh = open(log_path, 'w', encoding='utf-8')
                    log_fh.write(f"=== {task_name} | {datetime.datetime.now()} ===\n\n")
                    master_path = Path(project_dir) / 'pipeline_full.log'
                    master_fh = open(master_path, 'a', encoding='utf-8')
                    master_fh.write(f"\n{'='*60}\n=== {task_name} | {datetime.datetime.now()} ===\n{'='*60}\n\n")
                except Exception:
                    log_fh = None
                    master_fh = None
            try:
                with capture_stdout(self.app.log_queue, "control", log_file=log_fh, task_label=task_name, master_log=master_fh):
                    func(*args)
                elapsed = time.time() - t_start
                m, s = divmod(int(elapsed), 60)
                self.app.log(f"Done: {task_name} ({m}m {s}s)", "SUCCESS", tab="control")
                if log_fh:
                    log_fh.write(f"\n=== DONE: {m}m {s}s ===\n")
                if master_fh:
                    master_fh.write(f"\n=== DONE: {m}m {s}s ===\n")
            except Exception as e:
                elapsed = time.time() - t_start
                m, s = divmod(int(elapsed), 60)
                self.app.log(f"Error in {task_name} after {m}m {s}s: {e}", "ERROR", tab="control")
                if log_fh:
                    log_fh.write(f"\n=== ERROR after {m}m {s}s: {e} ===\n")
                if master_fh:
                    master_fh.write(f"\n=== ERROR after {m}m {s}s: {e} ===\n")
            finally:
                if log_fh:
                    try:
                        log_fh.close()
                    except Exception:
                        pass
                if master_fh:
                    try:
                        master_fh.close()
                    except Exception:
                        pass
                self.active_tasks = max(0, self.active_tasks - 1)
                self.root.after(0, self._update_status)
                self.root.after(0, self.refresh_projects)
        threading.Thread(target=worker, daemon=True).start()

    def _run_subprocess_in_thread(self, args_list, cwd=None, task_name="", env=None, project_dir=None):
        """Run subprocess with stdout piped to GUI log and optionally to stage/master log files."""
        self.active_tasks += 1
        self.root.after(0, self._update_status)
        self.app.log(f"Started: {task_name}", "INFO", tab="control")
        t_start = time.time()
        def worker():
            import datetime
            stage_fh = None
            master_fh = None
            if project_dir:
                try:
                    ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
                    safe = "".join(c if c.isalnum() or c in '-_' else '_' for c in task_name)
                    stage_path = Path(project_dir) / f"stage_{safe}_{ts}.log"
                    stage_fh = open(stage_path, 'w', encoding='utf-8')
                    stage_fh.write(f"=== {task_name} | {datetime.datetime.now()} ===\n\n")
                    master_path = Path(project_dir) / 'pipeline_full.log'
                    master_fh = open(master_path, 'a', encoding='utf-8')
                    master_fh.write(f"\n{'='*60}\n=== {task_name} | {datetime.datetime.now()} ===\n{'='*60}\n\n")
                except Exception:
                    stage_fh = None
                    master_fh = None
            try:
                _run_env = {**(env or os.environ), 'PYTHONIOENCODING': 'utf-8'}
                proc = subprocess.Popen(
                    args_list, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    stdin=subprocess.DEVNULL,
                    text=True, encoding='utf-8', errors='replace',
                    cwd=cwd or str(SCRIPT_DIR), env=_run_env
                )
                try:
                    for line in proc.stdout:
                        line = line.rstrip()
                        if not line:
                            continue
                        level = 'INFO'
                        low = line.lower()
                        if any(x in low for x in ['error', 'fail', 'traceback']):
                            level = 'ERROR'
                        elif any(x in low for x in ['[ok]', 'success', 'complete', 'saved']):
                            level = 'SUCCESS'
                        elif any(x in low for x in ['warn', 'skip', 'retry']):
                            level = 'WARNING'
                        self.app.log(line, level, tab="control")
                        if stage_fh:
                            try:
                                stage_fh.write(line + '\n')
                                stage_fh.flush()
                            except Exception:
                                pass
                        if master_fh:
                            try:
                                master_fh.write(line + '\n')
                                master_fh.flush()
                            except Exception:
                                pass
                except OSError:
                    pass  # pipe closed after terminate()
                proc.wait()
                elapsed = time.time() - t_start
                m, s = divmod(int(elapsed), 60)
                if proc.returncode == 0:
                    self.app.log(f"Done: {task_name} ({m}m {s}s)", "SUCCESS", tab="control")
                    if stage_fh:
                        stage_fh.write(f"\n=== DONE: {m}m {s}s ===\n")
                    if master_fh:
                        master_fh.write(f"\n=== DONE: {m}m {s}s ===\n")
                else:
                    self.app.log(f"Failed: {task_name} (exit {proc.returncode}, {m}m {s}s)", "ERROR", tab="control")
                    if stage_fh:
                        stage_fh.write(f"\n=== FAILED exit={proc.returncode}: {m}m {s}s ===\n")
                    if master_fh:
                        master_fh.write(f"\n=== FAILED exit={proc.returncode}: {m}m {s}s ===\n")
            except Exception as e:
                self.app.log(f"Error in {task_name}: {e}", "ERROR", tab="control")
                if stage_fh:
                    try:
                        stage_fh.write(f"\n=== ERROR: {e} ===\n")
                    except Exception:
                        pass
                if master_fh:
                    try:
                        master_fh.write(f"\n=== ERROR: {e} ===\n")
                    except Exception:
                        pass
            finally:
                if stage_fh:
                    try:
                        stage_fh.close()
                    except Exception:
                        pass
                if master_fh:
                    try:
                        master_fh.close()
                    except Exception:
                        pass
                self.active_tasks = max(0, self.active_tasks - 1)
                self.root.after(0, self._update_status)
                self.root.after(0, self.refresh_projects)
        threading.Thread(target=worker, daemon=True).start()

    # ── Stage Settings Dialog ──────────────────────────────────────
    def _show_stage_dialog(self, title, defaults: dict, on_run):
        """Show a dialog with stage defaults. User can edit or approve as-is.
        defaults = {label: (tk_var_class, default_value, options_or_range), ...}
        on_run(settings_dict) called if user confirms.
        """
        dlg = tk.Toplevel(self.root)
        dlg.title(title)
        dlg.configure(bg=COLORS['bg_dark'])
        dlg.resizable(False, False)
        dlg.transient(self.root)
        dlg.grab_set()

        # Center on parent
        dlg.geometry("+%d+%d" % (self.root.winfo_x() + 200, self.root.winfo_y() + 150))

        ttk.Label(dlg, text=title, style="Header.TLabel").pack(padx=20, pady=(12, 4))

        settings_frame = ttk.Frame(dlg, style="Card.TFrame", padding=12)
        settings_frame.pack(fill=tk.X, padx=12, pady=4)

        vars_map = {}
        for label, (var_cls, default, opts) in defaults.items():
            row = ttk.Frame(settings_frame, style="Card.TFrame")
            row.pack(fill=tk.X, pady=3)
            ttk.Label(row, text=f"{label}:", style="Card.TLabel", width=18).pack(side=tk.LEFT)

            var = var_cls(value=default)
            vars_map[label] = var

            if isinstance(opts, list):
                ttk.Combobox(row, textvariable=var, values=opts, width=16, state='readonly').pack(side=tk.LEFT, padx=4)
            elif isinstance(opts, tuple) and len(opts) == 2:
                tk.Spinbox(row, textvariable=var, from_=opts[0], to=opts[1], width=6,
                           bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=4)
            else:
                ttk.Entry(row, textvariable=var, width=20).pack(side=tk.LEFT, padx=4)

        # Buttons
        btn_row = ttk.Frame(dlg, padding=8)
        btn_row.pack(fill=tk.X)
        result = {'confirmed': False}

        def confirm():
            result['confirmed'] = True
            dlg.destroy()

        def cancel():
            dlg.destroy()

        ttk.Button(btn_row, text="Run", command=confirm, style="Accent.TButton").pack(side=tk.RIGHT, padx=4)
        ttk.Button(btn_row, text="Cancel", command=cancel).pack(side=tk.RIGHT, padx=4)

        dlg.bind('<Return>', lambda e: confirm())
        dlg.bind('<Escape>', lambda e: cancel())
        dlg.wait_window()

        if result['confirmed']:
            settings = {k: v.get() for k, v in vars_map.items()}
            on_run(settings)

    # ── Per-stage runners ──────────────────────────────────────────

    def _run_script_tts(self):
        """Script → Audio: run TTS on a .txt script, put audio in ready_to_go/."""
        script_path = filedialog.askopenfilename(
            title="Select script file (.txt)",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if not script_path:
            return
        script_file = Path(script_path)

        # Copy script to ready_to_go/ so tts_runner.py picks it up
        rtg = SCRIPT_DIR / 'ready_to_go'
        rtg.mkdir(exist_ok=True)
        dst = rtg / script_file.name
        if not dst.exists():
            shutil.copy2(str(script_file), str(dst))
        self.app.log(f"Script copied to ready_to_go/: {script_file.name}", "INFO", tab="control")

        defaults = {
            'TTS service': (tk.StringVar, getattr(config, 'TTS_SERVICE', 'mat3u'), ['mat3u', 'csv666']),
        }

        def do_run(s):
            env = os.environ.copy()
            env['TTS_SERVICE'] = s['TTS service']
            cmd = ['python', str(AGENT_DIR / 'tools' / 'tts_runner.py'), '--mode', 'silent', '--tts-only']
            self._run_subprocess_in_thread(cmd, cwd=str(AGENT_DIR), task_name=f"TTS {script_file.stem}", env=env)

        self._show_stage_dialog(f"Script → Audio — {script_file.name}", defaults, do_run)

    def _run_script_video(self):
        """Script -> Video: rich dialog -- 1 file dialog, all pipeline stages configurable."""
        script_path = filedialog.askopenfilename(
            title="Select script file (.txt)",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if not script_path:
            return
        script_file = Path(script_path)

        # --- Rich custom dialog ---
        dlg = tk.Toplevel(self.root)
        dlg.title("Script -> Video")
        dlg.configure(bg=COLORS['bg_dark'])
        dlg.resizable(False, False)
        dlg.transient(self.root)
        dlg.grab_set()
        dlg.geometry("+%d+%d" % (self.root.winfo_x() + 160, self.root.winfo_y() + 60))

        outer = ttk.Frame(dlg)
        outer.pack(fill=tk.BOTH, expand=True)
        canvas = tk.Canvas(outer, bg=COLORS['bg_dark'], highlightthickness=0, width=540)
        vsb = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        sf = ttk.Frame(canvas, style="Card.TFrame", padding=14)
        sf.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=sf, anchor="nw")
        canvas.configure(yscrollcommand=vsb.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)

        ttk.Label(sf, text=f"Script -> Video  |  {script_file.name}",
                  style="Header.TLabel").pack(anchor=tk.W, pady=(0, 6))

        # --- Style guide ---
        ttk.Separator(sf, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=(0, 4))
        ttk.Label(sf, text="Style Guide", style="Section.TLabel").pack(anchor=tk.W)
        sg_row = ttk.Frame(sf, style="Card.TFrame"); sg_row.pack(fill=tk.X, pady=3)
        ttk.Label(sg_row, text="Style file:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        style_path_var = tk.StringVar(value='')
        sg_lbl = ttk.Label(sg_row, text="(required)", style="Dim.TLabel")
        sg_lbl.pack(side=tk.LEFT, padx=4, fill=tk.X, expand=True)
        def _browse_style():
            sp = filedialog.askopenfilename(title="Select style guide (.txt)",
                                            filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
            if sp:
                style_path_var.set(sp)
                sg_lbl.config(text=Path(sp).name)
        ttk.Button(sg_row, text="Add", command=_browse_style).pack(side=tk.RIGHT, padx=4)

        # --- Direction ---
        ttk.Separator(sf, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=(4, 2))
        ttk.Label(sf, text="Direction", style="Section.TLabel").pack(anchor=tk.W)
        dr1 = ttk.Frame(sf, style="Card.TFrame"); dr1.pack(fill=tk.X, pady=2)
        ttk.Label(dr1, text="Script type:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        script_type_var = tk.StringVar(value='prose')
        ttk.Combobox(dr1, textvariable=script_type_var, values=['prose', 'screenplay'],
                     width=12, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(dr1, text="2-pass:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        twopass_var = tk.StringVar(value='true' if getattr(config, 'GEMINI_TWO_PASS', False) else 'false')
        ttk.Combobox(dr1, textvariable=twopass_var, values=['true', 'false'],
                     width=6, state='readonly').pack(side=tk.LEFT, padx=4)
        dr2 = ttk.Frame(sf, style="Card.TFrame"); dr2.pack(fill=tk.X, pady=2)
        ttk.Label(dr2, text="Clip mode:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        clipmode_var = tk.StringVar(value='video')
        ttk.Combobox(dr2, textvariable=clipmode_var, values=['video', 'slideshow', 'vislide'],
                     width=10, state='readonly').pack(side=tk.LEFT, padx=4)
        _vs_lbl2 = ttk.Label(dr2, text="every:", style="Card.TLabel")
        vislide_var2 = tk.IntVar(value=getattr(config, 'PIPELINE_VISLIDE_INTERVAL', 3))
        _vs_spn2 = tk.Spinbox(dr2, textvariable=vislide_var2, from_=2, to=20, width=3,
                              bg=COLORS['bg_input'], fg=COLORS['text'])
        def _toggle_vislide2(*_):
            if clipmode_var.get() == 'vislide':
                _vs_lbl2.pack(side=tk.LEFT, padx=(6, 0))
                _vs_spn2.pack(side=tk.LEFT, padx=2)
            else:
                _vs_lbl2.pack_forget()
                _vs_spn2.pack_forget()
        clipmode_var.trace_add('write', _toggle_vislide2)
        _toggle_vislide2()
        ttk.Label(dr2, text="min:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        clipmin_var = tk.IntVar(value=getattr(config, 'VIDEO_CLIP_MIN_DURATION', 4))
        tk.Spinbox(dr2, textvariable=clipmin_var, from_=1, to=30, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(dr2, text="max:", style="Card.TLabel").pack(side=tk.LEFT, padx=(4, 0))
        clipmax_var = tk.IntVar(value=getattr(config, 'VIDEO_CLIP_MAX_DURATION', 8))
        tk.Spinbox(dr2, textvariable=clipmax_var, from_=2, to=60, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        dr3 = ttk.Frame(sf, style="Card.TFrame"); dr3.pack(fill=tk.X, pady=2)
        ttk.Label(dr3, text="Intro zone:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        intro_var = tk.IntVar(value=getattr(config, 'INTRO_BLOCK_DURATION', 45))
        tk.Spinbox(dr3, textvariable=intro_var, from_=0, to=9999, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(dr3, text="s  clip:", style="Card.TLabel").pack(side=tk.LEFT, padx=(4, 0))
        intro_min_var = tk.IntVar(value=getattr(config, 'INTRO_CLIP_MIN_DURATION', 0))
        tk.Spinbox(dr3, textvariable=intro_min_var, from_=0, to=30, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(dr3, text="-", style="Card.TLabel").pack(side=tk.LEFT)
        intro_max_var = tk.IntVar(value=getattr(config, 'INTRO_CLIP_MAX_DURATION', 0))
        tk.Spinbox(dr3, textvariable=intro_max_var, from_=0, to=60, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(dr3, text="s", style="Card.TLabel").pack(side=tk.LEFT)

        # --- ImageGen ---
        ttk.Separator(sf, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=(4, 2))
        ttk.Label(sf, text="ImageGen", style="Section.TLabel").pack(anchor=tk.W)
        ig_row = ttk.Frame(sf, style="Card.TFrame"); ig_row.pack(fill=tk.X, pady=2)
        ttk.Label(ig_row, text="Engine:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_engine_var = tk.StringVar(value='skip')
        ttk.Combobox(ig_row, textvariable=sv_engine_var,
                     values=['skip', 'FastGen', 'VeoNonStop'], width=12, state='readonly').pack(side=tk.LEFT, padx=4)

        sv_fg_frame = ttk.Frame(sf, style="Card.TFrame")
        fg_r1 = ttk.Frame(sv_fg_frame, style="Card.TFrame"); fg_r1.pack(fill=tk.X, pady=2)
        ttk.Label(fg_r1, text="API Key:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_fg_key_var = tk.StringVar(value='main')
        ttk.Combobox(fg_r1, textvariable=sv_fg_key_var, values=['main', 'backup'],
                     width=10, state='readonly').pack(side=tk.LEFT, padx=4)
        fg_r2 = ttk.Frame(sv_fg_frame, style="Card.TFrame"); fg_r2.pack(fill=tk.X, pady=2)
        ttk.Label(fg_r2, text="Model:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_fg_model_var = tk.StringVar(value=FASTGEN_KEY_TO_NAME.get(config.FASTGEN_MODEL, config.FASTGEN_MODEL))
        ttk.Combobox(fg_r2, textvariable=sv_fg_model_var, values=FASTGEN_DISPLAY,
                     width=14, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(fg_r2, text="x", style="Card.TLabel").pack(side=tk.LEFT, padx=(6, 0))
        sv_fg_par_var = tk.IntVar(value=config.FASTGEN_MAX_PARALLEL)
        tk.Spinbox(fg_r2, textvariable=sv_fg_par_var, from_=1, to=20, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)

        sv_veo_frame = ttk.Frame(sf, style="Card.TFrame")
        veo_r1 = ttk.Frame(sv_veo_frame, style="Card.TFrame"); veo_r1.pack(fill=tk.X, pady=2)
        ttk.Label(veo_r1, text="Mode:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_veo_mode_var = tk.StringVar(value='banana')
        ttk.Combobox(veo_r1, textvariable=sv_veo_mode_var,
                     values=['banana', 'banana+ref', 'imagen'], width=12, state='readonly').pack(side=tk.LEFT, padx=4)
        veo_r2 = ttk.Frame(sv_veo_frame, style="Card.TFrame"); veo_r2.pack(fill=tk.X, pady=2)
        ttk.Label(veo_r2, text="Model:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_veo_model_var = tk.StringVar(value='Banana Pro')
        ttk.Combobox(veo_r2, textvariable=sv_veo_model_var, values=BANANA_DISPLAY,
                     width=12, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(veo_r2, text="x", style="Card.TLabel").pack(side=tk.LEFT, padx=(6, 0))
        sv_veo_par_var = tk.IntVar(value=config.VEONONSTOP_MAX_PARALLEL)
        tk.Spinbox(veo_r2, textvariable=sv_veo_par_var, from_=1, to=48, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        veo_r3 = ttk.Frame(sv_veo_frame, style="Card.TFrame"); veo_r3.pack(fill=tk.X, pady=2)
        ttk.Label(veo_r3, text="Aspect:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_veo_ratio_var = tk.StringVar(value=config.VEONONSTOP_ASPECT_RATIO)
        ttk.Combobox(veo_r3, textvariable=sv_veo_ratio_var, values=["16:9", "9:16", "1:1"],
                     width=8, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(veo_r3, text="Keys:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        sv_veo_keys_var = tk.StringVar(value='key1')
        ttk.Combobox(veo_r3, textvariable=sv_veo_keys_var,
                     values=_veo_key_options(),
                     width=6, state='readonly').pack(side=tk.LEFT, padx=4)
        sv_ref_dir: list = [None]
        sv_veo_ref_row = ttk.Frame(sv_veo_frame, style="Card.TFrame")
        ttk.Label(sv_veo_ref_row, text="Ref dir:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_ref_lbl = ttk.Label(sv_veo_ref_row, text="(project/ref/)", style="Dim.TLabel")
        sv_ref_lbl.pack(side=tk.LEFT, padx=4, fill=tk.X, expand=True)
        def _sv_browse_ref():
            d = filedialog.askdirectory(title="Select ref images folder")
            if d:
                sv_ref_dir[0] = d
                sv_ref_lbl.config(text=Path(d).name)
        ttk.Button(sv_veo_ref_row, text="Add", command=_sv_browse_ref).pack(side=tk.RIGHT, padx=4)

        def _sv_on_veo_mode(*_):
            if sv_veo_mode_var.get() == 'banana+ref':
                sv_veo_ref_row.pack(fill=tk.X, pady=2)
            else:
                sv_veo_ref_row.pack_forget()
        sv_veo_mode_var.trace_add('write', _sv_on_veo_mode)
        _sv_on_veo_mode()

        def _on_imgeng(*_):
            sv_fg_frame.pack_forget()
            sv_veo_frame.pack_forget()
            if sv_engine_var.get() == 'FastGen':
                sv_fg_frame.pack(fill=tk.X, pady=2)
            elif sv_engine_var.get() == 'VeoNonStop':
                sv_veo_frame.pack(fill=tk.X, pady=2)
        sv_engine_var.trace_add('write', _on_imgeng)
        _on_imgeng()

        # --- VideoGen ---
        ttk.Separator(sf, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=(4, 2))
        ttk.Label(sf, text="VideoGen", style="Section.TLabel").pack(anchor=tk.W)
        vg_row = ttk.Frame(sf, style="Card.TFrame"); vg_row.pack(fill=tk.X, pady=2)
        ttk.Label(vg_row, text="Mode:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_vid_mode_var = tk.StringVar(value='skip')
        ttk.Combobox(vg_row, textvariable=sv_vid_mode_var,
                     values=['skip', 'i2v', 't2v', 'components'],
                     width=12, state='readonly').pack(side=tk.LEFT, padx=4)

        # --- Concat ---
        ttk.Separator(sf, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=(4, 2))
        ttk.Label(sf, text="Concat", style="Section.TLabel").pack(anchor=tk.W)
        sv_concat_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(sf, text="Run concat after pipeline", variable=sv_concat_var,
                        style="Card.TCheckbutton").pack(anchor=tk.W, pady=2)
        sv_cc_settings = ttk.Frame(sf, style="Card.TFrame")
        cc_r1 = ttk.Frame(sv_cc_settings, style="Card.TFrame"); cc_r1.pack(fill=tk.X, pady=2)
        ttk.Label(cc_r1, text="Quality:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_quality_var = tk.StringVar(value='720p')
        ttk.Combobox(cc_r1, textvariable=sv_quality_var, values=['720p', '1080p'],
                     width=6, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(cc_r1, text="Bitrate:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        sv_bitrate_var = tk.StringVar(value='10M')
        ttk.Combobox(cc_r1, textvariable=sv_bitrate_var, values=['5M', '8M', '10M', '15M', '20M'],
                     width=6, state='readonly').pack(side=tk.LEFT, padx=4)
        sv_keep_veo_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(cc_r1, text="Keep VEO sound", variable=sv_keep_veo_var,
                        style="Card.TCheckbutton").pack(side=tk.LEFT, padx=8)
        sv_keep_files_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(cc_r1, text="Keep temp files", variable=sv_keep_files_var,
                        style="Card.TCheckbutton").pack(side=tk.LEFT)
        cc_r2 = ttk.Frame(sv_cc_settings, style="Card.TFrame")
        cc_r2.pack(fill=tk.X, pady=2)
        sv_subtitles_var        = tk.BooleanVar(value=False)
        sv_subtitles_custom_var = tk.BooleanVar(value=False)
        sv_subtitles_path_var   = tk.StringVar(value='')
        ttk.Checkbutton(cc_r2, text="Subtitles", variable=sv_subtitles_var,
                        style="Card.TCheckbutton").pack(side=tk.LEFT)
        _sv_custom_row = ttk.Frame(sv_cc_settings, style="Card.TFrame")
        ttk.Checkbutton(cc_r2, text="Custom template", variable=sv_subtitles_custom_var,
                        style="Card.TCheckbutton",
                        command=lambda: _sv_custom_row.pack(fill=tk.X) if sv_subtitles_custom_var.get()
                                        else _sv_custom_row.pack_forget()).pack(side=tk.LEFT, padx=(8, 0))
        ttk.Entry(_sv_custom_row, textvariable=sv_subtitles_path_var, width=36).pack(side=tk.LEFT, padx=4)
        ttk.Button(_sv_custom_row, text="Add",
                   command=lambda: sv_subtitles_path_var.set(
                       filedialog.askopenfilename(filetypes=[("ASS subtitles", "*.ass"), ("All files", "*.*")])
                   )).pack(side=tk.LEFT)

        def _on_concat_toggle(*_):
            if sv_concat_var.get():
                sv_cc_settings.pack(fill=tk.X)
            else:
                sv_cc_settings.pack_forget()
        sv_concat_var.trace_add('write', _on_concat_toggle)

        # --- YT Pack ---
        ttk.Separator(sf, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=(4, 2))
        ttk.Label(sf, text="YT Pack", style="Section.TLabel").pack(anchor=tk.W)
        sv_ytpack_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(sf, text="Run YT Pack after pipeline", variable=sv_ytpack_var,
                        style="Card.TCheckbutton").pack(anchor=tk.W, pady=2)
        sv_yt_settings = ttk.Frame(sf, style="Card.TFrame")
        _yt_l = getattr(config, 'YT_PACK_LANGUAGES', ['ru', 'en'])
        _yt_l_str = (','.join(str(x).strip(" '\"") for x in _yt_l if str(x).strip(" '\""))
                     if isinstance(_yt_l, (list, tuple)) else
                     ','.join(x.strip() for x in str(_yt_l).strip("[]'\"").split(',') if x.strip()))
        yt_r1 = ttk.Frame(sv_yt_settings, style="Card.TFrame"); yt_r1.pack(fill=tk.X, pady=2)
        ttk.Label(yt_r1, text="Languages:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_yt_langs_var = tk.StringVar(value=_yt_l_str)
        ttk.Entry(yt_r1, textvariable=sv_yt_langs_var, width=16).pack(side=tk.LEFT, padx=4)
        yt_r2 = ttk.Frame(sv_yt_settings, style="Card.TFrame"); yt_r2.pack(fill=tk.X, pady=2)
        ttk.Label(yt_r2, text="Generate:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_yt_subs_var = tk.BooleanVar(value=bool(getattr(config, 'YT_PACK_SUBTITLES', True)))
        sv_yt_desc_var = tk.BooleanVar(value=bool(getattr(config, 'YT_PACK_DESCRIPTION', True)))
        sv_yt_cov_var  = tk.BooleanVar(value=bool(getattr(config, 'YT_PACK_COVERS', True)))
        ttk.Checkbutton(yt_r2, text="Subtitles",   variable=sv_yt_subs_var,  style="Card.TCheckbutton").pack(side=tk.LEFT, padx=2)
        ttk.Checkbutton(yt_r2, text="Description", variable=sv_yt_desc_var,  style="Card.TCheckbutton").pack(side=tk.LEFT, padx=6)
        ttk.Checkbutton(yt_r2, text="Covers",      variable=sv_yt_cov_var,   style="Card.TCheckbutton").pack(side=tk.LEFT, padx=6)

        def _on_ytpack_toggle(*_):
            if sv_ytpack_var.get():
                sv_yt_settings.pack(fill=tk.X)
            else:
                sv_yt_settings.pack_forget()
        sv_ytpack_var.trace_add('write', _on_ytpack_toggle)

        # --- Buttons ---
        btn_row = ttk.Frame(dlg, padding=8)
        btn_row.pack(fill=tk.X, side=tk.BOTTOM)
        result = {'confirmed': False}
        def _confirm():
            if not style_path_var.get():
                messagebox.showerror("Missing", "Style guide file is required", parent=dlg)
                return
            result['confirmed'] = True
            dlg.destroy()
        ttk.Button(btn_row, text="Run", command=_confirm, style="Accent.TButton").pack(side=tk.RIGHT, padx=4)
        ttk.Button(btn_row, text="Cancel", command=dlg.destroy).pack(side=tk.RIGHT, padx=4)
        dlg.bind('<Escape>', lambda e: dlg.destroy())

        dlg.update_idletasks()
        _h = min(sf.winfo_reqheight() + 50, int(self.root.winfo_screenheight() * 0.85))
        canvas.configure(height=_h)
        dlg.wait_window()

        if not result['confirmed']:
            return

        # --- Collect and execute ---
        project_name = script_file.stem
        projects_dir = SCRIPT_DIR / 'projects'
        projects_dir.mkdir(exist_ok=True)
        p = projects_dir / project_name

        _eng = sv_engine_var.get()
        _vid = sv_vid_mode_var.get()
        if _eng == 'FastGen' and _vid == 'i2v':
            post_action = 'fastgen_i2v'
        elif _eng == 'FastGen' and _vid == 'skip':
            post_action = 'fastgen'
        elif _eng == 'VeoNonStop' and _vid == 'i2v':
            post_action = 'veo_i2v'
        elif _eng == 'skip' and _vid == 't2v':
            post_action = 't2v'
        elif _eng == 'skip' and _vid == 'components':
            post_action = 'components'
        elif _eng == 'skip' and _vid == 'i2v':
            post_action = 'i2v'
        else:
            post_action = 'skip'

        cmd = ['python', str(AGENT_DIR / 'agent.py'), 'script',
               '--script', str(script_file),
               '--style',  style_path_var.get(),
               '--project', project_name,
               '--output',  str(p),
               '--script-type', script_type_var.get(),
               '--clip-mode',   clipmode_var.get(),
               '--clip-min',    str(clipmin_var.get()),
               '--clip-max',    str(clipmax_var.get()),
               '--post-action', post_action]
        if clipmode_var.get() == 'vislide':
            cmd.extend(['--vislide-interval', str(vislide_var2.get())])
        if twopass_var.get() == 'true':
            cmd.append('--two-pass')

        import os as _os
        _sub_env = _os.environ.copy()
        _sub_env['INTRO_BLOCK_DURATION']    = str(intro_var.get())
        _sub_env['INTRO_CLIP_MIN_DURATION'] = str(intro_min_var.get())
        _sub_env['INTRO_CLIP_MAX_DURATION'] = str(intro_max_var.get())
        if _eng == 'VeoNonStop':
            _sub_env['VEONONSTOP_BANANA_MODEL'] = BANANA_NAME_TO_KEY.get(sv_veo_model_var.get(), 'GEM_PIX_2')
            _sub_env['VEONONSTOP_MAX_PARALLEL'] = str(sv_veo_par_var.get())
            _sub_env['VEONONSTOP_ASPECT_RATIO'] = sv_veo_ratio_var.get()
        elif _eng == 'FastGen':
            _sub_env['FASTGEN_MODEL']        = FASTGEN_NAME_TO_KEY.get(sv_fg_model_var.get(), sv_fg_model_var.get())
            _sub_env['FASTGEN_MAX_PARALLEL'] = str(sv_fg_par_var.get())

        cc_settings = {
            'quality': sv_quality_var.get(), 'bitrate': sv_bitrate_var.get(),
            'keep_veo_sound': sv_keep_veo_var.get(), 'keep_files': sv_keep_files_var.get(),
            'subtitles_path': (sv_subtitles_path_var.get() if sv_subtitles_custom_var.get()
                               else _find_ass_template(sv_quality_var.get())) if sv_subtitles_var.get() else '',
            'yt_langs': sv_yt_langs_var.get(), 'yt_subs': sv_yt_subs_var.get(),
            'yt_desc': sv_yt_desc_var.get(),   'yt_covers': sv_yt_cov_var.get(),
        }
        run_concat = sv_concat_var.get()
        run_ytpack = sv_ytpack_var.get()

        self.app.log(
            f"Script Director: {script_file.name} ({script_type_var.get()}, post={post_action})...",
            "INFO", tab="control"
        )

        def _worker():
            import subprocess as _sp
            self.active_tasks += 1
            self.root.after(0, self._update_status)
            _delegated = False
            try:
                _sub_env.setdefault('PYTHONIOENCODING', 'utf-8')
                proc = _sp.Popen(cmd, stdout=_sp.PIPE, stderr=_sp.STDOUT,
                                 stdin=_sp.DEVNULL,
                                 text=True, encoding='utf-8', errors='replace',
                                 cwd=str(AGENT_DIR), env=_sub_env)
                for line in proc.stdout:
                    line = line.rstrip()
                    if not line:
                        continue
                    low = line.lower()
                    level = 'ERROR' if any(x in low for x in ['error', 'fail', 'traceback']) else 'INFO'
                    self.app.log(line, level, tab="control")
                if proc.wait() != 0:
                    raise RuntimeError(f"Script Director failed (exit {proc.returncode})")
                self.app.log(f"Script Director done: {project_name}", "SUCCESS", tab="control")
                post_stages = []
                if run_concat:
                    post_stages.append('Concat')
                if run_ytpack:
                    post_stages.append('YT Pack')
                if post_stages:
                    _delegated = True
                    self._finalize_worker(p, post_stages, cc_settings)
            except Exception as e:
                self.app.log(f"Script Director FAILED: {e}", "ERROR", tab="control")
            finally:
                if not _delegated:
                    self.active_tasks = max(0, self.active_tasks - 1)
                    self.root.after(0, self._update_status)
                    self.root.after(0, self.refresh_projects)

        threading.Thread(target=_worker, daemon=True).start()

        if False:  # unreachable — kept for matching sentinel
            self._show_stage_dialog(f"Script → Video — {script_file.name}", defaults, do_run)

    def _run_transcribe(self):
        # Always ask for audio file — create project from it
        audio_path = filedialog.askopenfilename(
            title="Select audio file to transcribe",
            filetypes=[("Audio", "*.mp3 *.wav *.flac *.m4a *.aac"), ("All", "*.*")]
        )
        if not audio_path:
            return
        audio_file = Path(audio_path)
        projects_dir = SCRIPT_DIR / 'projects'
        projects_dir.mkdir(exist_ok=True)
        project_name = audio_file.stem
        p = projects_dir / project_name
        p.mkdir(exist_ok=True)
        dst = p / audio_file.name
        if not dst.exists():
            shutil.copy2(str(audio_file), str(dst))
        audio = [dst]
        self.app.log(f"Project: {project_name}", "INFO", tab="control")
        self.refresh_projects()
        for item in self.tree.get_children():
            if self.tree.item(item)['values'][0] == project_name:
                self.tree.selection_set(item)
                self.tree.see(item)
                break

        defaults = {
            'Language': (tk.StringVar, config.ASSEMBLYAI_LANGUAGE_CODE,
                        ['ru', 'en', 'es', 'de', 'fr', 'it', 'pt', 'zh', 'pl']),
            'Speech model': (tk.StringVar, 'universal-3-pro',
                            ['universal-3-pro', 'universal-2']),
            'Segmentation': (tk.StringVar, getattr(config, 'ASSEMBLYAI_SEGMENTATION_MODE', 'sentences'),
                            ['sentences', 'paragraphs', 'words']),
        }

        def do_run(s):
            from modules.transcriber import transcribe_audio
            out = str(p / 'transcription.json')
            config.ASSEMBLYAI_LANGUAGE_CODE     = s['Language']
            config.ASSEMBLYAI_SEGMENTATION_MODE = s['Segmentation']
            self.app.log(f"Transcribing {audio[0].name} ({s['Language']}, {s['Speech model']})...", "INFO", tab="control")
            self._run_in_thread(transcribe_audio, str(audio[0]), out, task_name=f"Transcribe {p.name}", project_dir=p)

        self._show_stage_dialog(f"Transcribe — {p.name}", defaults, do_run)

    def _run_direct(self):
        p = self._get_selected()
        if not p:
            return
        tr = p / 'transcription.json'
        if not tr.exists():
            messagebox.showerror("Error", "No transcription.json")
            return
        styles = list(p.glob('*style*')) + list(p.glob('*.txt'))
        style = str(styles[0]) if styles else ''

        defaults = {
            'Mode': (tk.StringVar, 'full', ['full', 'prompts-only']),
            'Model': (tk.StringVar, getattr(config, 'GEMINI_MODEL', _GEMINI_MODEL_OPTS[0]), _GEMINI_MODEL_OPTS),
            'Two-pass': (tk.StringVar, 'true' if config.GEMINI_TWO_PASS else 'false', ['true', 'false']),
            'Clip mode': (tk.StringVar, 'video', ['video', 'slideshow']),
            'Clip min': (tk.IntVar, config.VIDEO_CLIP_MIN_DURATION, (1, 30)),
            'Clip max': (tk.IntVar, config.VIDEO_CLIP_MAX_DURATION, (2, 60)),
            'Intro zone (s)': (tk.IntVar, getattr(config, 'INTRO_BLOCK_DURATION', 45), (0, 9999)),
            'Intro clip min': (tk.IntVar, getattr(config, 'INTRO_CLIP_MIN_DURATION', 0), (0, 30)),
            'Intro clip max': (tk.IntVar, getattr(config, 'INTRO_CLIP_MAX_DURATION', 0), (0, 60)),
        }

        def do_run(s):
            from modules.director import direct_project
            mode = s.get('Mode', 'full')
            prompts_only = (mode == 'prompts-only')
            config.GEMINI_MODEL    = s['Model']
            config.GEMINI_TWO_PASS = s['Two-pass'].lower() in ('true', '1', 'yes')
            cm = s['Clip mode']
            if cm == 'video':
                config.VIDEO_CLIP_MIN_DURATION = int(s['Clip min'])
                config.VIDEO_CLIP_MAX_DURATION = int(s['Clip max'])
            else:
                config.SLIDESHOW_CLIP_MIN_DURATION = int(s['Clip min'])
                config.SLIDESHOW_CLIP_MAX_DURATION = int(s['Clip max'])
            config.INTRO_BLOCK_DURATION    = int(s['Intro zone (s)'])
            config.INTRO_CLIP_MIN_DURATION = int(s['Intro clip min'])
            config.INTRO_CLIP_MAX_DURATION = int(s['Intro clip max'])

            # Resume logic for prompts-only mode
            resume_path = None
            if prompts_only:
                _candidates = sorted(p.glob(f"{p.name}_prompts_*.txt"))
                _non_over = [f for f in _candidates if 'OVERPROMPT' not in f.name]
                _best = _non_over[-1] if _non_over else (_candidates[-1] if _candidates else None)
                if _best:
                    answer = messagebox.askyesno(
                        "Resume prompts?",
                        f"Found existing prompts file:\n{_best.name}\n\nContinue from where left off?\n\n[Yes] Resume   [No] Start fresh"
                    )
                    if answer:
                        resume_path = str(_best)

            mode_label = f"prompts-only{'(resume)' if resume_path else ''}" if prompts_only else f"two-pass={s['Two-pass']}"
            self.app.log(f"Directing {p.name} ({mode_label}, {cm} {s['Clip min']}-{s['Clip max']}s)...", "INFO", tab="control")
            _po, _rp = prompts_only, resume_path
            _fn = lambda *a: direct_project(*a, prompts_only=_po, resume_path=_rp)
            self._run_in_thread(_fn, str(tr), style, str(p), p.name, task_name=f"Direct {p.name}", project_dir=p)

        self._show_stage_dialog(f"Direct — {p.name}", defaults, do_run)

    def _fetch_fastgen_quota(self, api_key):
        """Fetch remaining quota for a FastGen API key."""
        try:
            from modules.fastgen import FastGenClient, parse_usage_remaining, parse_usage_threads
            client = FastGenClient(api_key=api_key)
            usage = client.get_usage()
            remaining = parse_usage_remaining(usage)
            threads = parse_usage_threads(usage)
            return remaining, threads
        except Exception:
            return None, '?'

    def _run_imagegen(self):
        p = self._get_selected()
        if not p:
            return

        # Fetch quotas
        main_key = getattr(config, 'FASTGEN_API_KEY', '')
        backup_key = getattr(config, 'FASTGEN_API_KEY_BACKUP', '')
        main_q, main_t = self._fetch_fastgen_quota(main_key) if main_key else (None, '?')
        backup_q, backup_t = self._fetch_fastgen_quota(backup_key) if backup_key else (None, '?')
        mq = main_q if main_q is not None else '?'
        bq = backup_q if backup_q is not None else '?'

        # Custom dialog with dynamic fields
        dlg = tk.Toplevel(self.root)
        dlg.title(f"Image Gen — {p.name}")
        dlg.configure(bg=COLORS['bg_dark'])
        dlg.resizable(False, False)
        dlg.transient(self.root)
        dlg.grab_set()
        dlg.geometry("+%d+%d" % (self.root.winfo_x() + 200, self.root.winfo_y() + 150))

        ttk.Label(dlg, text=f"Image Gen — {p.name}", style="Header.TLabel").pack(padx=20, pady=(12, 4))

        sf = ttk.Frame(dlg, style="Card.TFrame", padding=12)
        sf.pack(fill=tk.X, padx=12, pady=4)

        # Engine selector
        engine_var = tk.StringVar(value='fastgen')
        row = ttk.Frame(sf, style="Card.TFrame"); row.pack(fill=tk.X, pady=3)
        ttk.Label(row, text="Engine:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        engine_cb = ttk.Combobox(row, textvariable=engine_var, values=['fastgen', 'veononstop'], width=16, state='readonly')
        engine_cb.pack(side=tk.LEFT, padx=4)

        # FastGen fields
        fg_frame = ttk.Frame(sf, style="Card.TFrame")

        r1 = ttk.Frame(fg_frame, style="Card.TFrame"); r1.pack(fill=tk.X, pady=3)
        ttk.Label(r1, text="API Key:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        api_key_var = tk.StringVar(value='main')
        ttk.Combobox(r1, textvariable=api_key_var, values=['main', 'backup'], width=16, state='readonly').pack(side=tk.LEFT, padx=4)

        r1q = ttk.Frame(fg_frame, style="Card.TFrame"); r1q.pack(fill=tk.X, pady=1)
        ttk.Label(r1q, text="", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        ttk.Label(r1q, text=f"Main: {mq}/hr, {main_t} thr  |  Backup: {bq}/hr, {backup_t} thr",
                  style="Dim.TLabel").pack(side=tk.LEFT)

        r2 = ttk.Frame(fg_frame, style="Card.TFrame"); r2.pack(fill=tk.X, pady=3)
        ttk.Label(r2, text="Model:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        fg_model_var = tk.StringVar(value=FASTGEN_KEY_TO_NAME.get(config.FASTGEN_MODEL, config.FASTGEN_MODEL))
        ttk.Combobox(r2, textvariable=fg_model_var, values=FASTGEN_DISPLAY, width=16, state='readonly').pack(side=tk.LEFT, padx=4)

        r3 = ttk.Frame(fg_frame, style="Card.TFrame"); r3.pack(fill=tk.X, pady=3)
        ttk.Label(r3, text="Aspect:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        fg_aspect_var = tk.StringVar(value=config.FASTGEN_ASPECT_RATIO)
        ttk.Combobox(r3, textvariable=fg_aspect_var, values=['landscape', 'portrait', 'square'], width=16, state='readonly').pack(side=tk.LEFT, padx=4)

        r4 = ttk.Frame(fg_frame, style="Card.TFrame"); r4.pack(fill=tk.X, pady=3)
        ttk.Label(r4, text="Parallel:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        fg_par_var = tk.IntVar(value=config.FASTGEN_MAX_PARALLEL)
        tk.Spinbox(r4, textvariable=fg_par_var, from_=1, to=20, width=6,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=4)

        # VeoNonStop fields
        veo_frame = ttk.Frame(sf, style="Card.TFrame")

        rv1 = ttk.Frame(veo_frame, style="Card.TFrame"); rv1.pack(fill=tk.X, pady=3)
        ttk.Label(rv1, text="Mode:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        veo_mode_var = tk.StringVar(value='banana')
        ttk.Combobox(rv1, textvariable=veo_mode_var, values=['banana', 'banana+ref', 'imagen'], width=16, state='readonly').pack(side=tk.LEFT, padx=4)

        rv2 = ttk.Frame(veo_frame, style="Card.TFrame")
        ttk.Label(rv2, text="Model:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        veo_model_var = tk.StringVar(value='Banana Pro')
        ttk.Combobox(rv2, textvariable=veo_model_var, values=BANANA_DISPLAY, width=16, state='readonly').pack(side=tk.LEFT, padx=4)

        rv3 = ttk.Frame(veo_frame, style="Card.TFrame"); rv3.pack(fill=tk.X, pady=3)
        ttk.Label(rv3, text="Parallel:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        veo_par_var = tk.IntVar(value=config.VEONONSTOP_MAX_PARALLEL)
        tk.Spinbox(rv3, textvariable=veo_par_var, from_=1, to=48, width=6,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=4)

        rv4 = ttk.Frame(veo_frame, style="Card.TFrame"); rv4.pack(fill=tk.X, pady=3)
        ttk.Label(rv4, text="Aspect ratio:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        veo_ratio_var = tk.StringVar(value=config.VEONONSTOP_ASPECT_RATIO)
        ttk.Combobox(rv4, textvariable=veo_ratio_var, values=["16:9", "9:16", "1:1"],
                     width=8, state='readonly').pack(side=tk.LEFT, padx=4)

        _veo_key2_ok = bool(getattr(config, 'VEONONSTOP_API_KEY_2', ''))
        rv5 = ttk.Frame(veo_frame, style="Card.TFrame"); rv5.pack(fill=tk.X, pady=3)
        ttk.Label(rv5, text="Keys:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        veo_key_var = tk.StringVar(value='key1')
        ttk.Combobox(rv5, textvariable=veo_key_var,
                     values=['key1', 'key2', 'both'] if _veo_key2_ok else ['key1'],
                     width=8, state='readonly').pack(side=tk.LEFT, padx=4)

        rv6 = ttk.Frame(veo_frame, style="Card.TFrame"); rv6.pack(fill=tk.X, pady=3)
        ttk.Label(rv6, text="Upscale:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        veo_ups_var = tk.StringVar(value='off')
        ttk.Combobox(rv6, textvariable=veo_ups_var, values=["off", "2K", "4K"],
                     width=8, state='readonly').pack(side=tk.LEFT, padx=4)

        # Ref dir row (shown only for banana+ref)
        veo_ref_dir: list = [None]
        rv_ref = ttk.Frame(veo_frame, style="Card.TFrame")
        ttk.Label(rv_ref, text="Ref dir:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        ref_path_lbl = ttk.Label(rv_ref, text="(project/ref/)", style="Dim.TLabel")
        ref_path_lbl.pack(side=tk.LEFT, padx=4, fill=tk.X, expand=True)
        def _browse_veo_ref():
            d = filedialog.askdirectory(title="Select ref images folder", initialdir=str(p))
            if d:
                veo_ref_dir[0] = d
                ref_path_lbl.config(text=Path(d).name)
        ttk.Button(rv_ref, text="Add", command=_browse_veo_ref).pack(side=tk.RIGHT, padx=4)

        # Show/hide model and ref rows based on veo mode
        def on_veo_mode_change(*_):
            m = veo_mode_var.get()
            if m == 'imagen':
                rv2.pack_forget()
                rv_ref.pack_forget()
            elif m == 'banana+ref':
                rv2.pack(fill=tk.X, pady=3, after=rv1)
                rv_ref.pack(fill=tk.X, pady=3)
            else:
                rv2.pack(fill=tk.X, pady=3, after=rv1)
                rv_ref.pack_forget()

        veo_mode_var.trace_add('write', on_veo_mode_change)
        on_veo_mode_change()

        # Toggle visibility
        def on_engine_change(*_):
            if engine_var.get() == 'fastgen':
                veo_frame.pack_forget()
                fg_frame.pack(fill=tk.X, pady=4)
            else:
                fg_frame.pack_forget()
                veo_frame.pack(fill=tk.X, pady=4)

        engine_var.trace_add('write', on_engine_change)
        on_engine_change()  # show fastgen by default

        # Buttons
        btn_row = ttk.Frame(dlg, padding=8); btn_row.pack(fill=tk.X)
        result = {'confirmed': False}
        def confirm():
            result['confirmed'] = True
            dlg.destroy()
        ttk.Button(btn_row, text="Run", command=confirm, style="Accent.TButton").pack(side=tk.RIGHT, padx=4)
        ttk.Button(btn_row, text="Cancel", command=dlg.destroy).pack(side=tk.RIGHT, padx=4)
        dlg.bind('<Return>', lambda e: confirm())
        dlg.bind('<Escape>', lambda e: dlg.destroy())
        dlg.wait_window()

        if not result['confirmed']:
            return

        if engine_var.get() == 'fastgen':
            key_name   = api_key_var.get()
            actual_key = (backup_key if key_name == 'backup' and backup_key else main_key)
            actual_model    = FASTGEN_NAME_TO_KEY.get(fg_model_var.get(), fg_model_var.get())
            actual_aspect   = fg_aspect_var.get()
            actual_parallel = fg_par_var.get()
            from modules.fastgen import generate_all_images
            self.app.log(
                f"ImageGen (FastGen {fg_model_var.get()}, {key_name}, x{actual_parallel}) for {p.name}...",
                "INFO", tab="control"
            )
            self._run_in_thread(
                lambda: generate_all_images(
                    str(p),
                    api_key=actual_key,
                    max_parallel=actual_parallel,
                    model=actual_model,
                    aspect_ratio=actual_aspect,
                ),
                task_name=f"ImageGen {p.name}",
                project_dir=p,
            )
        else:
            config.VEONONSTOP_MAX_PARALLEL = veo_par_var.get()
            config.VEONONSTOP_BANANA_MODEL = BANANA_NAME_TO_KEY.get(veo_model_var.get(), 'GEM_PIX_2')
            mode_str = veo_mode_var.get()
            actual_mode = 'banana_ref' if mode_str == 'banana+ref' else mode_str
            ref_d = veo_ref_dir[0]
            from modules.imggen import generate_all_images as veo_gen
            config.VEONONSTOP_BANANA_MODEL = BANANA_NAME_TO_KEY.get(veo_model_var.get(), 'GEM_PIX_2')
            self.app.log(f"ImageGen (VeoNonStop {mode_str}, {veo_model_var.get()}) for {p.name}...", "INFO", tab="control")
            actual_ratio    = veo_ratio_var.get()
            actual_parallel = veo_par_var.get()
            _veo_active     = _veo_sel_to_active(sv_veo_keys_var.get())
            _UPS_MAP = {'2k': 'UPSAMPLE_IMAGE_RESOLUTION_2K', '4k': 'UPSAMPLE_IMAGE_RESOLUTION_4K'}
            _ups_res = _UPS_MAP.get(veo_ups_var.get().lower())
            self._run_in_thread(
                lambda: veo_gen(str(p), mode=actual_mode, ref_dir=ref_d,
                                aspect_ratio=actual_ratio, max_parallel=actual_parallel,
                                active_keys=_veo_active, upscale_resolution=_ups_res),
                task_name=f"ImageGen {p.name}", project_dir=p,
            )

    def _run_videogen(self):
        p = self._get_selected()
        if not p:
            return

        defaults = {
            'Mode': (tk.StringVar, 'i2v', ['i2v', 't2v', 'components']),
            'Aspect ratio': (tk.StringVar, config.VEONONSTOP_ASPECT_RATIO, ['16:9', '9:16', '1:1']),
            'Parallel': (tk.IntVar, config.VEONONSTOP_MAX_PARALLEL, (1, 200)),
            'Keys': (tk.StringVar, '1', _veo_key_options()),
            'Prompt': (tk.StringVar, 'per-clip', ['per-clip', 'single']),
            'Upscale 1080p': (tk.BooleanVar, False, None),
        }

        def do_run(s):
            from modules.veo_video import generate_all_videos
            _mode = s['Mode']
            _par  = s['Parallel']
            _ar   = s['Aspect ratio']
            _keys = s['Keys']
            _active = _veo_sel_to_active(_keys)
            _sp = None
            if s.get('Prompt') == 'single':
                _sp_file = p / 'single_prompt.txt'
                if _sp_file.exists():
                    _sp = _sp_file.read_text(encoding='utf-8').strip() or None
            self.app.log(f"VideoGen ({_mode}, {_ar}, x{_par}, {_keys}, prompt={s.get('Prompt','per-clip')}) for {p.name}...", "INFO", tab="control")
            self._run_in_thread(
                lambda: generate_all_videos(str(p), mode=_mode, max_parallel=_par, aspect_ratio=_ar,
                                            active_keys=_active, single_prompt=_sp,
                                            upscale_video=s.get('Upscale 1080p', False)),
                task_name=f"VideoGen {p.name}",
                project_dir=p,
            )

        self._show_stage_dialog(f"Video Gen — {p.name}", defaults, do_run)

    def _run_concat(self):
        p = self._get_selected()
        if not p:
            return
        plan = p / 'montage_plan.json'
        if not plan.exists():
            messagebox.showerror("Error", "No montage_plan.json")
            return

        # Check if vid_img clips are already 1080p (from video upscale)
        _vid_already_1080 = False
        _sample = sorted((p / 'vid_img').glob('*.mp4'))[:1]
        if _sample:
            try:
                import subprocess as _sp
                _probe = _sp.run(
                    ['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                     '-show_entries', 'stream=height', '-of', 'csv=p=0', str(_sample[0])],
                    capture_output=True, text=True, timeout=10)
                _h = int(_probe.stdout.strip())
                _vid_already_1080 = _h >= 1080
            except Exception:
                pass
        _quality_opts = ['720p'] if _vid_already_1080 else ['720p', '1080p']

        defaults = {
            'Quality':        (tk.StringVar, '720p',   _quality_opts),
            'Bitrate':        (tk.StringVar, '10M',    ['5M', '8M', '10M', '15M', '20M']),
            'FPS':            (tk.StringVar, '60',     ['24', '25', '30', '50', '60']),
            'Watermark':      (tk.StringVar, 'as_is',  ['as_is', 'logo', 'blur']),
            'Force AMD':      (tk.StringVar, 'yes',    ['yes', 'no']),
            'Keep VEO Sound': (tk.StringVar, 'no',     ['no', 'yes']),
            'Burn Subtitles': (tk.StringVar, 'no',     ['no', 'yes']),
        }

        def do_run(s):
            cmd = ['python', str(SCRIPT_DIR / 'video_concat.py'),
                    'montage_plan.json', '-o', f'{p.name}.mp4', '-b', s['Bitrate'],
                    '--fps', s['FPS']]
            if s['Force AMD'] == 'yes':
                cmd.append('--force-amd')
            if s['Watermark'] == 'blur':
                cmd.append('--blur-borders')
            if s['Quality'] == '1080p':
                cmd.extend(['-r', '1080'])
            if s['Keep VEO Sound'] == 'yes':
                cmd.append('--veo-audio-inline')
            if s['Burn Subtitles'] == 'yes':
                ass_files = list(p.glob('*.ass'))
                if ass_files:
                    cmd.extend(['--subtitles', str(ass_files[0])])
            self._run_subprocess_in_thread(cmd, cwd=str(p), task_name=f"Concat {p.name}", project_dir=p)

        self._show_stage_dialog(f"Concat — {p.name}", defaults, do_run)

    def _run_ytpack(self):
        p = self._get_selected()
        if not p:
            return

        _yt_langs = getattr(config, 'YT_PACK_LANGUAGES', ['ru', 'en'])
        if isinstance(_yt_langs, (list, tuple)):
            _yt_langs_str = ','.join(str(l).strip(" '\"[]()") for l in _yt_langs if str(l).strip(" '\"[]()"))
        else:
            _yt_langs_str = ','.join(l.strip() for l in str(_yt_langs).strip("[]'\"()").split(',') if l.strip())
        defaults = {
            'Content model':   (tk.StringVar, getattr(config, 'YT_PACK_CONTENT_MODEL',   _GEMINI_MODEL_OPTS[0]), _GEMINI_MODEL_OPTS),
            'Translate model': (tk.StringVar, getattr(config, 'YT_PACK_TRANSLATE_MODEL', _GEMINI_MODEL_OPTS[0]), _GEMINI_MODEL_OPTS),
            'Languages': (tk.StringVar, _yt_langs_str, None),
            'Subtitles': (tk.StringVar, 'true' if getattr(config, 'YT_PACK_SUBTITLES', False) else 'false', ['true', 'false']),
            'Description': (tk.StringVar, 'true' if getattr(config, 'YT_PACK_DESCRIPTION', False) else 'false', ['true', 'false']),
            'Covers': (tk.StringVar, 'true' if getattr(config, 'YT_PACK_COVERS', False) else 'false', ['true', 'false']),
        }

        def do_run(s):
            from modules.yt_packer import run_yt_packer
            config.YT_PACK_CONTENT_MODEL   = s['Content model']
            config.YT_PACK_TRANSLATE_MODEL = s['Translate model']
            config.YT_PACK_LANGUAGES  = [lang.strip() for lang in s['Languages'].split(',') if lang.strip()]
            config.YT_PACK_SUBTITLES  = s['Subtitles'].lower() in ('true', '1', 'yes')
            config.YT_PACK_DESCRIPTION = s['Description'].lower() in ('true', '1', 'yes')
            config.YT_PACK_COVERS     = s['Covers'].lower() in ('true', '1', 'yes')
            self.app.log(f"YT Packing {p.name} (langs={s['Languages']})...", "INFO", tab="control")
            self._run_in_thread(run_yt_packer, str(p), task_name=f"YT Pack {p.name}", project_dir=p)

        self._show_stage_dialog(f"YT Pack — {p.name}", defaults, do_run)

    # ── Pipeline Mode: Finalize Project ───────────────────────────

    def _fin_browse_img_refs(self):
        paths = filedialog.askopenfilenames(
            title="Select reference images for banana_ref mode",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp *.tiff *.tif *.gif *.heic *.heif *.avif *.svg *.ico *.jfif"), ("All files", "*.*")]
        )
        for p in paths:
            pp = Path(p)
            if pp not in self._fin_img_refs:
                self._fin_img_refs.append(pp)
        self._fin_refresh_img_ref_listbox()

    def _fin_clear_img_refs(self):
        self._fin_img_refs.clear()
        self._fin_refresh_img_ref_listbox()

    def _fin_refresh_img_ref_listbox(self):
        self._fin_img_ref_listbox.delete(0, tk.END)
        for p in self._fin_img_refs:
            self._fin_img_ref_listbox.insert(tk.END, p.name)
        self._fin_img_ref_listbox.config(height=max(2, min(len(self._fin_img_refs), 5)))

    def _fin_browse_refs(self):
        paths = filedialog.askopenfilenames(
            title="Select reference images for components mode",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp *.tiff *.tif *.gif *.heic *.heif *.avif *.svg *.ico *.jfif"), ("All files", "*.*")]
        )
        for p in paths:
            pp = Path(p)
            if pp not in self._fin_vid_refs:
                self._fin_vid_refs.append(pp)
        self._fin_refresh_ref_listbox()

    def _fin_clear_refs(self):
        self._fin_vid_refs.clear()
        self._fin_refresh_ref_listbox()

    def _fin_refresh_ref_listbox(self):
        self._fin_ref_listbox.delete(0, tk.END)
        for p in self._fin_vid_refs:
            self._fin_ref_listbox.insert(tk.END, p.name)
        self._fin_ref_listbox.config(height=max(2, min(len(self._fin_vid_refs), 5)))

    def _toggle_finalize_panel(self):
        if self._finalize_visible:
            self._finalize_frame.pack_forget()
            self._finalize_visible = False
            self._pl_mode_btn.config(text="Pipeline Mode ▼")
        else:
            self._finalize_frame.pack(fill=tk.X, padx=2, pady=2, before=self._log_card)
            self._finalize_visible = True
            self._pl_mode_btn.config(text="Pipeline Mode ▲")

    def _build_finalize_panel(self, parent) -> ttk.Frame:
        # Scrollable wrapper — finalize panel can be tall, needs its own scroll
        wrapper = ttk.Frame(parent, style="Card.TFrame")
        _fin_canvas = tk.Canvas(wrapper, bg=COLORS['bg_card'], highlightthickness=0, height=350)
        _fin_vsb = ttk.Scrollbar(wrapper, orient=tk.VERTICAL, command=_fin_canvas.yview)
        outer = ttk.Frame(_fin_canvas, style="Card.TFrame", padding=8)
        outer.bind("<Configure>", lambda e: _fin_canvas.configure(scrollregion=_fin_canvas.bbox("all")))
        _fin_canvas.create_window((0, 0), window=outer, anchor=tk.NW)
        _fin_canvas.configure(yscrollcommand=_fin_vsb.set)
        _fin_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        _fin_vsb.pack(side=tk.RIGHT, fill=tk.Y)
        # Mousewheel
        _fin_mw = lambda e: _fin_canvas.yview_scroll(-1 * (e.delta // 120), "units")
        _fin_canvas.bind("<Enter>", lambda e: _fin_canvas.bind_all("<MouseWheel>", _fin_mw))
        _fin_canvas.bind("<Leave>", lambda e: _fin_canvas.unbind_all("<MouseWheel>"))
        # Stretch inner to canvas width
        def _fin_on_configure(e):
            _fin_canvas.itemconfigure(_fin_canvas.find_all()[0], width=e.width)
        _fin_canvas.bind("<Configure>", _fin_on_configure)

        # Shared BooleanVar (used by both ImageGen and VideoGen sections)
        self._fin_skip_preflight = tk.BooleanVar(value=False)

        # Description
        ttk.Label(outer, text="Resume pipeline from a specific stage for the selected project",
                  style="Dim.TLabel").pack(anchor=tk.W, pady=(0, 4))

        # Row: Start from + YT Pack toggle
        r0 = ttk.Frame(outer, style="Card.TFrame")
        r0.pack(fill=tk.X, pady=2)
        ttk.Label(r0, text="Start from:", style="Card.TLabel", width=12).pack(side=tk.LEFT)
        _STAGES = ["Direction", "ImageGen", "VideoGen", "Concat", "YT Pack"]
        self._fin_start = tk.StringVar(value="ImageGen")
        ttk.Combobox(r0, textvariable=self._fin_start, values=_STAGES,
                     width=12, state='readonly').pack(side=tk.LEFT, padx=4)
        self._fin_ytpack = tk.BooleanVar(value=False)
        ttk.Checkbutton(r0, text="Run YT Pack after", variable=self._fin_ytpack,
                        style="Card.TCheckbutton").pack(side=tk.LEFT, padx=16)

        ttk.Separator(outer, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=(4, 2))

        # ── Direction section ──
        self._fin_dir_section = ttk.Frame(outer, style="Card.TFrame")
        ttk.Label(self._fin_dir_section, text="Direction", style="Section.TLabel").pack(anchor=tk.W)
        dr1 = ttk.Frame(self._fin_dir_section, style="Card.TFrame"); dr1.pack(fill=tk.X, pady=2)
        ttk.Label(dr1, text="Model:", style="Card.TLabel", width=12).pack(side=tk.LEFT)
        self._fin_dir_model = tk.StringVar(value=getattr(config, 'GEMINI_MODEL', _GEMINI_MODEL_OPTS[0]))
        ttk.Combobox(dr1, textvariable=self._fin_dir_model, values=_GEMINI_MODEL_OPTS,
                     width=20, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(dr1, text="2-pass:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_dir_twopass = tk.StringVar(value='true' if getattr(config, 'GEMINI_TWO_PASS', False) else 'false')
        ttk.Combobox(dr1, textvariable=self._fin_dir_twopass, values=['true', 'false'],
                     width=6, state='readonly').pack(side=tk.LEFT, padx=4)
        dr2 = ttk.Frame(self._fin_dir_section, style="Card.TFrame"); dr2.pack(fill=tk.X, pady=2)
        ttk.Label(dr2, text="Clip mode:", style="Card.TLabel", width=12).pack(side=tk.LEFT)
        self._fin_dir_clipmode = tk.StringVar(value='video')
        ttk.Combobox(dr2, textvariable=self._fin_dir_clipmode, values=['video', 'slideshow'],
                     width=10, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(dr2, text="min:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_dir_clipmin = tk.IntVar(value=getattr(config, 'VIDEO_CLIP_MIN_DURATION', 4))
        tk.Spinbox(dr2, textvariable=self._fin_dir_clipmin, from_=1, to=30, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(dr2, text="max:", style="Card.TLabel").pack(side=tk.LEFT, padx=(4, 0))
        self._fin_dir_clipmax = tk.IntVar(value=getattr(config, 'VIDEO_CLIP_MAX_DURATION', 8))
        tk.Spinbox(dr2, textvariable=self._fin_dir_clipmax, from_=2, to=60, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        dr3 = ttk.Frame(self._fin_dir_section, style="Card.TFrame"); dr3.pack(fill=tk.X, pady=2)
        ttk.Label(dr3, text="Intro zone:", style="Card.TLabel", width=12).pack(side=tk.LEFT)
        self._fin_dir_intro = tk.IntVar(value=getattr(config, 'INTRO_BLOCK_DURATION', 45))
        tk.Spinbox(dr3, textvariable=self._fin_dir_intro, from_=0, to=9999, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(dr3, text="s  clip:", style="Card.TLabel").pack(side=tk.LEFT, padx=(4, 0))
        self._fin_dir_intro_min = tk.IntVar(value=getattr(config, 'INTRO_CLIP_MIN_DURATION', 0))
        tk.Spinbox(dr3, textvariable=self._fin_dir_intro_min, from_=0, to=30, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(dr3, text="-", style="Card.TLabel").pack(side=tk.LEFT)
        self._fin_dir_intro_max = tk.IntVar(value=getattr(config, 'INTRO_CLIP_MAX_DURATION', 0))
        tk.Spinbox(dr3, textvariable=self._fin_dir_intro_max, from_=0, to=60, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(dr3, text="s", style="Card.TLabel").pack(side=tk.LEFT)

        # ── ImageGen section ──
        self._fin_ig_section = ttk.Frame(outer, style="Card.TFrame")
        ttk.Label(self._fin_ig_section, text="ImageGen", style="Section.TLabel").pack(anchor=tk.W)

        ig_row = ttk.Frame(self._fin_ig_section, style="Card.TFrame")
        ig_row.pack(fill=tk.X, pady=2)
        ttk.Label(ig_row, text="Engine:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        self._fin_engine = tk.StringVar(value="veononstop")
        eng_cb = ttk.Combobox(ig_row, textvariable=self._fin_engine,
                               values=["veononstop", "fastgen"], width=12, state='readonly')
        eng_cb.pack(side=tk.LEFT, padx=4)

        # VeoNonStop sub-settings
        self._fin_veo_sub = ttk.Frame(self._fin_ig_section, style="Card.TFrame")
        vr = ttk.Frame(self._fin_veo_sub, style="Card.TFrame")
        vr.pack(fill=tk.X, pady=2)
        ttk.Label(vr, text="Mode:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        self._fin_veo_mode = tk.StringVar(value="banana")
        ttk.Combobox(vr, textvariable=self._fin_veo_mode,
                     values=["banana", "banana_ref", "imagen"], width=12, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(vr, text="Ratio:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_veo_ratio = tk.StringVar(value=config.VEONONSTOP_ASPECT_RATIO)
        ttk.Combobox(vr, textvariable=self._fin_veo_ratio,
                     values=["16:9", "9:16", "1:1"], width=6, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(vr, text="Parallel:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_veo_par = tk.IntVar(value=config.VEONONSTOP_MAX_PARALLEL)
        tk.Spinbox(vr, textvariable=self._fin_veo_par, from_=1, to=200, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=4)
        vr2 = ttk.Frame(self._fin_veo_sub, style="Card.TFrame")
        vr2.pack(fill=tk.X, pady=2)
        ttk.Label(vr2, text="Model:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        self._fin_veo_model = tk.StringVar(value=BANANA_KEY_TO_NAME.get(
            getattr(config, 'VEONONSTOP_BANANA_MODEL', 'GEM_PIX_2'), 'Banana Pro'))
        ttk.Combobox(vr2, textvariable=self._fin_veo_model,
                     values=BANANA_DISPLAY, width=12, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(vr2, text="Keys:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_veo_imgkeys = tk.StringVar(value='1')
        self._fin_img_key_checks = {}
        _img_kf = ttk.Frame(vr2, style="Card.TFrame")
        _img_kf.pack(side=tk.LEFT)
        def _update_img_keys(*_):
            sel = ','.join(str(i) for i in sorted(self._fin_img_key_checks)
                          if self._fin_img_key_checks[i].get())
            if not sel:
                sel = '1'
                if 1 in self._fin_img_key_checks:
                    self._fin_img_key_checks[1].set(True)
            self._fin_veo_imgkeys.set(sel)
            try:
                lims = self.app.tab_pipeline._veo_key_limits
                total = sum(lims.get(s.strip(), 0) for s in sel.split(','))
                if total > 0:
                    self._fin_veo_par.set(total)
            except Exception:
                pass
        _IKA = [(1, 'VEONONSTOP_API_KEY', config.VEONONSTOP_KEY1_NAME),
                (2, 'VEONONSTOP_API_KEY_2', config.VEONONSTOP_KEY2_NAME),
                (3, 'VEONONSTOP_API_KEY_3', config.VEONONSTOP_KEY3_NAME),
                (4, 'VEONONSTOP_API_KEY_4', config.VEONONSTOP_KEY4_NAME)]
        for _ki, _kattr, _kname in _IKA:
            if getattr(config, _kattr, ''):
                _bv = tk.BooleanVar(value=(_ki == 1))
                self._fin_img_key_checks[_ki] = _bv
                ttk.Checkbutton(_img_kf, text=_kname[:6], variable=_bv,
                                style="Card.TCheckbutton",
                                command=_update_img_keys).pack(side=tk.LEFT, padx=1)
        self._refresh_fin_img_par = _update_img_keys
        _update_img_keys()

        vr3 = ttk.Frame(self._fin_veo_sub, style="Card.TFrame")
        vr3.pack(fill=tk.X, pady=2)
        ttk.Label(vr3, text="Upscale:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        self._fin_img_upscale = tk.StringVar(value=getattr(config, 'VEONONSTOP_IMAGE_UPSCALE', 'off'))
        ttk.Combobox(vr3, textvariable=self._fin_img_upscale,
                     values=["off", "2K", "4K"], width=6, state='readonly').pack(side=tk.LEFT, padx=4)

        # Ref images for banana_ref mode
        self._fin_img_ref_row = ttk.Frame(self._fin_veo_sub, style="Card.TFrame")
        self._fin_img_refs: list = []
        _iref_top = ttk.Frame(self._fin_img_ref_row, style="Card.TFrame")
        _iref_top.pack(fill=tk.X)
        ttk.Label(_iref_top, text="Refs:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        ttk.Button(_iref_top, text="Add", command=self._fin_browse_img_refs).pack(side=tk.LEFT, padx=2)
        ttk.Button(_iref_top, text="Clear", command=self._fin_clear_img_refs).pack(side=tk.LEFT, padx=2)
        ttk.Label(_iref_top, text="(if empty: project/ref/)", style="Dim.TLabel").pack(side=tk.LEFT, padx=4)
        self._fin_img_ref_listbox = tk.Listbox(self._fin_img_ref_row, height=3,
                                               bg=COLORS['bg_input'], fg=COLORS['text'],
                                               selectbackground=COLORS['accent'], font=FONT_DIM)
        self._fin_img_ref_listbox.pack(fill=tk.X, pady=(2, 0))

        def _toggle_img_ref_row(*_):
            if self._fin_veo_mode.get() == 'banana_ref':
                self._fin_img_ref_row.pack(fill=tk.X, pady=2)
            else:
                self._fin_img_ref_row.pack_forget()
        self._fin_veo_mode.trace_add('write', _toggle_img_ref_row)
        _toggle_img_ref_row()

        # FastGen sub-settings
        self._fin_fg_sub = ttk.Frame(self._fin_ig_section, style="Card.TFrame")
        fr = ttk.Frame(self._fin_fg_sub, style="Card.TFrame")
        fr.pack(fill=tk.X, pady=2)
        ttk.Label(fr, text="Model:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        self._fin_fg_model = tk.StringVar(
            value=FASTGEN_KEY_TO_NAME.get(config.FASTGEN_MODEL, config.FASTGEN_MODEL))
        ttk.Combobox(fr, textvariable=self._fin_fg_model, values=FASTGEN_DISPLAY,
                     width=12, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(fr, text="Parallel:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_fg_par = tk.IntVar(value=config.FASTGEN_MAX_PARALLEL)
        tk.Spinbox(fr, textvariable=self._fin_fg_par, from_=1, to=20, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=4)

        def _on_engine(*_):
            if self._fin_engine.get() == 'veononstop':
                self._fin_fg_sub.pack_forget()
                self._fin_veo_sub.pack(fill=tk.X)
            else:
                self._fin_veo_sub.pack_forget()
                self._fin_fg_sub.pack(fill=tk.X)
        eng_cb.bind('<<ComboboxSelected>>', _on_engine)
        _on_engine()

        # Skip preflight for ImageGen (shown when refs are involved)
        self._fin_ig_skip_pf = ttk.Checkbutton(self._fin_ig_section, text="Skip preflight",
                                                variable=self._fin_skip_preflight,
                                                style="Card.TCheckbutton")
        def _toggle_ig_skip_pf(*_):
            engine = self._fin_engine.get()
            veo_mode = self._fin_veo_mode.get()
            # Show when: FastGen (always has refs support) or VeoNonStop banana_ref
            show = (engine == 'fastgen') or (engine == 'veononstop' and veo_mode == 'banana_ref')
            if show:
                self._fin_ig_skip_pf.pack(anchor=tk.W, pady=(2, 0))
            else:
                self._fin_ig_skip_pf.pack_forget()
        self._fin_engine.trace_add('write', _toggle_ig_skip_pf)
        self._fin_veo_mode.trace_add('write', _toggle_ig_skip_pf)
        _toggle_ig_skip_pf()

        # ── VideoGen section ──
        self._fin_vg_section = ttk.Frame(outer, style="Card.TFrame")
        ttk.Label(self._fin_vg_section, text="VideoGen", style="Section.TLabel").pack(anchor=tk.W)
        vg_row = ttk.Frame(self._fin_vg_section, style="Card.TFrame")
        vg_row.pack(fill=tk.X, pady=2)
        ttk.Label(vg_row, text="Mode:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        self._fin_vid_mode = tk.StringVar(value="i2v")
        ttk.Combobox(vg_row, textvariable=self._fin_vid_mode,
                     values=["i2v", "t2v", "components"], width=10, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(vg_row, text="Ratio:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_vid_ratio = tk.StringVar(value=config.VEONONSTOP_ASPECT_RATIO)
        ttk.Combobox(vg_row, textvariable=self._fin_vid_ratio,
                     values=["16:9", "9:16", "1:1"], width=6, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(vg_row, text="x", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_vid_par = tk.IntVar(value=config.VEONONSTOP_MAX_PARALLEL)
        tk.Spinbox(vg_row, textvariable=self._fin_vid_par, from_=1, to=200, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(vg_row, text="Keys:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_vid_keys = tk.StringVar(value="1")
        self._fin_vid_key_checks = {}
        _vid_kf = ttk.Frame(vg_row, style="Card.TFrame")
        _vid_kf.pack(side=tk.LEFT)
        def _update_vid_keys(*_):
            sel = ','.join(str(i) for i in sorted(self._fin_vid_key_checks)
                          if self._fin_vid_key_checks[i].get())
            if not sel:
                sel = '1'
                if 1 in self._fin_vid_key_checks:
                    self._fin_vid_key_checks[1].set(True)
            self._fin_vid_keys.set(sel)
            try:
                lims = self.app.tab_pipeline._veo_key_limits
                total = sum(lims.get(s.strip(), 0) for s in sel.split(','))
                if total > 0:
                    self._fin_vid_par.set(total)
            except Exception:
                pass
        _VKA = [(1, 'VEONONSTOP_API_KEY', config.VEONONSTOP_KEY1_NAME),
                (2, 'VEONONSTOP_API_KEY_2', config.VEONONSTOP_KEY2_NAME),
                (3, 'VEONONSTOP_API_KEY_3', config.VEONONSTOP_KEY3_NAME),
                (4, 'VEONONSTOP_API_KEY_4', config.VEONONSTOP_KEY4_NAME)]
        for _ki, _kattr, _kname in _VKA:
            if getattr(config, _kattr, ''):
                _bv = tk.BooleanVar(value=(_ki == 1))
                self._fin_vid_key_checks[_ki] = _bv
                ttk.Checkbutton(_vid_kf, text=_kname[:6], variable=_bv,
                                style="Card.TCheckbutton",
                                command=_update_vid_keys).pack(side=tk.LEFT, padx=1)
        self._refresh_fin_vid_par = _update_vid_keys
        _update_vid_keys()
        vg_row2 = ttk.Frame(self._fin_vg_section, style="Card.TFrame")
        vg_row2.pack(fill=tk.X, pady=2)
        ttk.Label(vg_row2, text="Prompt:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        self._fin_vid_prompt_mode = tk.StringVar(value="per-clip")
        ttk.Combobox(vg_row2, textvariable=self._fin_vid_prompt_mode,
                     values=["per-clip", "single"], width=8, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(vg_row2, text="(single reads single_prompt.txt)", style="Dim.TLabel").pack(side=tk.LEFT, padx=4)
        ttk.Label(vg_row2, text="Skipper:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_fast_censor = tk.StringVar(value=getattr(config, 'VEONONSTOP_FAST_CENSOR', 'off'))
        ttk.Combobox(vg_row2, textvariable=self._fin_fast_censor,
                     values=['off', 'after_rewrites', 'ultrafast'], width=14, state='readonly').pack(side=tk.LEFT, padx=2)
        self._fin_vg_skip_pf = ttk.Checkbutton(vg_row2, text="Skip preflight",
                                                variable=self._fin_skip_preflight,
                                                style="Card.TCheckbutton")
        # shown/hidden dynamically based on vid_mode
        self._fin_vid_upscale = tk.BooleanVar(value=getattr(config, 'VEONONSTOP_VIDEO_UPSCALE', False))
        ttk.Checkbutton(vg_row2, text="Upscale 1080p", variable=self._fin_vid_upscale,
                        style="Card.TCheckbutton").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_inflight = tk.BooleanVar(value=False)
        ttk.Checkbutton(vg_row2, text="Inflight", variable=self._fin_inflight,
                        style="Card.TCheckbutton").pack(side=tk.LEFT, padx=(8, 0))

        # Ref images for components mode
        self._fin_vid_ref_row = ttk.Frame(self._fin_vg_section, style="Card.TFrame")
        self._fin_vid_refs: list = []
        _ref_top = ttk.Frame(self._fin_vid_ref_row, style="Card.TFrame")
        _ref_top.pack(fill=tk.X)
        ttk.Label(_ref_top, text="Refs:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        ttk.Button(_ref_top, text="Add", command=self._fin_browse_refs).pack(side=tk.LEFT, padx=2)
        ttk.Button(_ref_top, text="Clear", command=self._fin_clear_refs).pack(side=tk.LEFT, padx=2)
        ttk.Label(_ref_top, text="(if empty: project/ref/)", style="Dim.TLabel").pack(side=tk.LEFT, padx=4)
        self._fin_ref_listbox = tk.Listbox(self._fin_vid_ref_row, height=3,
                                           bg=COLORS['bg_input'], fg=COLORS['text'],
                                           selectbackground=COLORS['accent'], font=FONT_DIM)
        self._fin_ref_listbox.pack(fill=tk.X, pady=(2, 0))

        def _toggle_ref_row(*_):
            if self._fin_vid_mode.get() == 'components':
                self._fin_vid_ref_row.pack(fill=tk.X, pady=2, after=vg_row2)
                self._fin_vg_skip_pf.pack(side=tk.LEFT, padx=(8, 0))
            else:
                self._fin_vid_ref_row.pack_forget()
                self._fin_vg_skip_pf.pack_forget()
        self._fin_vid_mode.trace_add('write', _toggle_ref_row)
        _toggle_ref_row()

        # ── Concat section ──
        self._fin_cc_section = ttk.Frame(outer, style="Card.TFrame")
        ttk.Label(self._fin_cc_section, text="Concat", style="Section.TLabel").pack(anchor=tk.W)
        cc_row = ttk.Frame(self._fin_cc_section, style="Card.TFrame")
        cc_row.pack(fill=tk.X, pady=2)
        ttk.Label(cc_row, text="Quality:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        self._fin_quality = tk.StringVar(value="720p")
        self._fin_quality_cb = ttk.Combobox(cc_row, textvariable=self._fin_quality,
                     values=["720p", "1080p"], width=6, state='readonly')
        self._fin_quality_cb.pack(side=tk.LEFT, padx=4)

        def _on_fin_vid_upscale(*_):
            if self._fin_vid_upscale.get():
                self._fin_quality.set("720p")
                self._fin_quality_cb.config(state='disabled')
            else:
                self._fin_quality_cb.config(state='readonly')
        self._fin_vid_upscale.trace_add('write', _on_fin_vid_upscale)
        _on_fin_vid_upscale()
        ttk.Label(cc_row, text="Bitrate:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_bitrate = tk.StringVar(value="10M")
        ttk.Combobox(cc_row, textvariable=self._fin_bitrate,
                     values=["5M", "8M", "10M", "15M", "20M"], width=6, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(cc_row, text="FPS:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_fps = tk.IntVar(value=60)
        ttk.Combobox(cc_row, textvariable=self._fin_fps,
                     values=[24, 25, 30, 50, 60], width=4, state='readonly').pack(side=tk.LEFT, padx=4)
        self._fin_keep_veo = tk.BooleanVar(value=False)
        ttk.Checkbutton(cc_row, text="Keep VEO Sound", variable=self._fin_keep_veo,
                        style="Card.TCheckbutton").pack(side=tk.LEFT, padx=12)
        self._fin_keep_files = tk.BooleanVar(value=False)
        ttk.Checkbutton(cc_row, text="Keep temp files", variable=self._fin_keep_files,
                        style="Card.TCheckbutton").pack(side=tk.LEFT)
        sub_row = ttk.Frame(self._fin_cc_section, style="Card.TFrame")
        sub_row.pack(fill=tk.X, pady=2)
        self._fin_subtitles_enabled = tk.BooleanVar(value=False)
        self._fin_subtitles_custom  = tk.BooleanVar(value=False)
        self._fin_subtitles_path    = tk.StringVar(value='')
        ttk.Checkbutton(sub_row, text="Subtitles", variable=self._fin_subtitles_enabled,
                        style="Card.TCheckbutton").pack(side=tk.LEFT)
        _fin_custom_row = ttk.Frame(self._fin_cc_section, style="Card.TFrame")
        ttk.Checkbutton(sub_row, text="Custom template", variable=self._fin_subtitles_custom,
                        style="Card.TCheckbutton",
                        command=lambda: _fin_custom_row.pack(fill=tk.X) if self._fin_subtitles_custom.get()
                                        else _fin_custom_row.pack_forget()).pack(side=tk.LEFT, padx=(8, 0))
        ttk.Entry(_fin_custom_row, textvariable=self._fin_subtitles_path, width=36).pack(side=tk.LEFT, padx=4)
        ttk.Button(_fin_custom_row, text="Add",
                   command=lambda: self._fin_subtitles_path.set(
                       filedialog.askopenfilename(filetypes=[("ASS subtitles", "*.ass"), ("All files", "*.*")])
                   )).pack(side=tk.LEFT)

        # ── YT Pack settings section ──
        _yt_langs_p = getattr(config, 'YT_PACK_LANGUAGES', ['ru', 'en'])
        if isinstance(_yt_langs_p, (list, tuple)):
            _yt_langs_p_str = ','.join(str(l).strip(" '\"[]()") for l in _yt_langs_p if str(l).strip(" '\"[]()"))
        else:
            _yt_langs_p_str = ','.join(l.strip() for l in str(_yt_langs_p).strip("[]'\"()").split(',') if l.strip())
        self._fin_yt_section = ttk.Frame(outer, style="Card.TFrame")
        ttk.Label(self._fin_yt_section, text="YT Pack", style="Section.TLabel").pack(anchor=tk.W)
        yt1 = ttk.Frame(self._fin_yt_section, style="Card.TFrame"); yt1.pack(fill=tk.X, pady=2)
        ttk.Label(yt1, text="Languages:", style="Card.TLabel", width=12).pack(side=tk.LEFT)
        self._fin_yt_langs = tk.StringVar(value=_yt_langs_p_str)
        ttk.Entry(yt1, textvariable=self._fin_yt_langs, width=16).pack(side=tk.LEFT, padx=4)
        yt2 = ttk.Frame(self._fin_yt_section, style="Card.TFrame"); yt2.pack(fill=tk.X, pady=2)
        ttk.Label(yt2, text="Generate:", style="Card.TLabel", width=12).pack(side=tk.LEFT)
        self._fin_yt_subs = tk.BooleanVar(value=bool(getattr(config, 'YT_PACK_SUBTITLES', True)))
        ttk.Checkbutton(yt2, text="Subtitles", variable=self._fin_yt_subs, style="Card.TCheckbutton").pack(side=tk.LEFT, padx=2)
        self._fin_yt_desc = tk.BooleanVar(value=bool(getattr(config, 'YT_PACK_DESCRIPTION', True)))
        ttk.Checkbutton(yt2, text="Description", variable=self._fin_yt_desc, style="Card.TCheckbutton").pack(side=tk.LEFT, padx=6)
        self._fin_yt_covers = tk.BooleanVar(value=bool(getattr(config, 'YT_PACK_COVERS', True)))
        ttk.Checkbutton(yt2, text="Covers", variable=self._fin_yt_covers, style="Card.TCheckbutton").pack(side=tk.LEFT, padx=6)

        # Finalize button
        btn_f = ttk.Frame(outer, style="Card.TFrame")
        btn_f.pack(fill=tk.X, pady=(6, 0))
        ttk.Button(btn_f, text="Finalize Project →", command=self._finalize_project,
                   style="Accent.TButton").pack(side=tk.RIGHT)

        # Show/hide sections based on start stage and ytpack toggle
        def _update_visibility(*_):
            start = self._fin_start.get()
            order = ["Direction", "ImageGen", "VideoGen", "Concat", "YT Pack"]
            idx = order.index(start)
            for sec in (self._fin_dir_section, self._fin_ig_section, self._fin_vg_section,
                        self._fin_cc_section, self._fin_yt_section):
                sec.pack_forget()
            if idx == 0:
                self._fin_dir_section.pack(fill=tk.X, pady=2, before=btn_f)
            if idx <= 1:
                self._fin_ig_section.pack(fill=tk.X, pady=2, before=btn_f)
            if idx <= 2:
                self._fin_vg_section.pack(fill=tk.X, pady=2, before=btn_f)
            if idx <= 3:
                self._fin_cc_section.pack(fill=tk.X, pady=2, before=btn_f)
            if start == "YT Pack" or self._fin_ytpack.get():
                self._fin_yt_section.pack(fill=tk.X, pady=2, before=btn_f)

        self._fin_start.trace_add('write', _update_visibility)
        self._fin_ytpack.trace_add('write', _update_visibility)
        _update_visibility()

        return wrapper

    def _finalize_project(self):
        p = self._get_selected()
        if not p:
            return
        _STAGE_ORDER = ["Direction", "ImageGen", "VideoGen", "Concat", "YT Pack"]
        start = self._fin_start.get()
        start_idx = _STAGE_ORDER.index(start)
        stages = list(_STAGE_ORDER[start_idx:])
        if not self._fin_ytpack.get():
            stages = [s for s in stages if s != "YT Pack"]
        if not stages:
            return

        # Validate prerequisites
        if "Direction" in stages and not (p / 'transcription.json').exists():
            messagebox.showerror("Missing file", "No transcription.json — cannot run Direction stage")
            return
        if any(s in stages for s in ("ImageGen", "VideoGen", "Concat")) and \
                not (p / 'montage_plan.json').exists() and "Direction" not in stages:
            messagebox.showerror("Missing file", "No montage_plan.json — run Direction stage first")
            return

        settings = {
            'engine':       self._fin_engine.get(),
            'veo_mode':     self._fin_veo_mode.get(),
            'veo_ratio':    self._fin_veo_ratio.get(),
            'veo_parallel': self._fin_veo_par.get(),
            'veo_model':    BANANA_NAME_TO_KEY.get(self._fin_veo_model.get(), 'GEM_PIX_2'),
            'veo_imgkeys':  self._fin_veo_imgkeys.get(),
            'fg_model':     FASTGEN_NAME_TO_KEY.get(self._fin_fg_model.get(), self._fin_fg_model.get()),
            'fg_parallel':  self._fin_fg_par.get(),
            'vid_mode':     self._fin_vid_mode.get(),
            'vid_ratio':    self._fin_vid_ratio.get(),
            'vid_parallel':     self._fin_vid_par.get(),
            'vid_keys':         self._fin_vid_keys.get(),
            'vid_prompt_mode':  self._fin_vid_prompt_mode.get(),
            'vid_ref_files':    list(self._fin_vid_refs),
            'img_ref_files':    list(self._fin_img_refs),
            'skip_preflight':   self._fin_skip_preflight.get(),
            'fast_censor':      self._fin_fast_censor.get(),
            'img_upscale':      self._fin_img_upscale.get(),
            'vid_upscale':      self._fin_vid_upscale.get(),
            'inflight_mode':    self._fin_inflight.get(),
            'quality':      self._fin_quality.get(),
            'bitrate':      self._fin_bitrate.get(),
            'fps':          int(self._fin_fps.get()),
            'keep_veo_sound': self._fin_keep_veo.get(),
            'keep_files': self._fin_keep_files.get(),
            'subtitles_path': (self._fin_subtitles_path.get() if self._fin_subtitles_custom.get()
                               else _find_ass_template(self._fin_quality.get())) if self._fin_subtitles_enabled.get() else '',
            # Direction settings
            'dir_model':      self._fin_dir_model.get(),
            'dir_twopass':    self._fin_dir_twopass.get(),
            'dir_clipmode':   self._fin_dir_clipmode.get(),
            'dir_clipmin':    self._fin_dir_clipmin.get(),
            'dir_clipmax':    self._fin_dir_clipmax.get(),
            'dir_intro':      self._fin_dir_intro.get(),
            'dir_intro_min':  self._fin_dir_intro_min.get(),
            'dir_intro_max':  self._fin_dir_intro_max.get(),
            # YT Pack settings
            'yt_langs':    self._fin_yt_langs.get(),
            'yt_subs':     self._fin_yt_subs.get(),
            'yt_desc':     self._fin_yt_desc.get(),
            'yt_covers':   self._fin_yt_covers.get(),
        }
        self.active_tasks += 1
        self.root.after(0, self._update_status)
        self.app.log(
            f"Finalize {p.name}  |  from: {start}  |  stages: {', '.join(stages)}",
            "INFO", tab="control"
        )
        threading.Thread(target=self._finalize_worker,
                         args=(p, stages, settings), daemon=True).start()

    def _finalize_worker(self, p: Path, stages: list, settings: dict):
        import datetime
        t_start = time.time()
        master_path = p / 'pipeline_full.log'
        _current_stage = "(init)"

        def _open_logs(label):
            ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
            safe = "".join(c if c.isalnum() or c in '-_' else '_' for c in label)
            log_fh = open(p / f"stage_{safe}_{ts}.log", 'w', encoding='utf-8')
            log_fh.write(f"=== {label} | {datetime.datetime.now()} ===\n\n")
            mfh = open(master_path, 'a', encoding='utf-8')
            mfh.write(f"\n{'='*60}\n=== {label} | {datetime.datetime.now()} ===\n{'='*60}\n\n")
            return log_fh, mfh

        def _close_logs(log_fh, mfh, elapsed):
            m, s = divmod(int(elapsed), 60)
            for fh in (log_fh, mfh):
                if fh:
                    try:
                        fh.write(f"\n=== DONE: {m}m {s}s ===\n")
                        fh.close()
                    except Exception:
                        pass

        try:
            with open(master_path, 'a', encoding='utf-8') as f:
                f.write(
                    f"\n{'='*60}\n=== FINALIZE PIPELINE | {datetime.datetime.now()} ===\n"
                    f"Stages: {', '.join(stages)}\n{'='*60}\n"
                )

            for stage in stages:
                _current_stage = stage
                t_stage = time.time()
                self.app.log(f"── Finalize: {stage} ({p.name}) ──", "INFO", tab="control")
                log_fh, mfh = _open_logs(f"Finalize_{stage}")
                try:
                    if stage == "Direction":
                        tr = p / 'transcription.json'
                        styles = list(p.glob('*style*')) + list(p.glob('*.txt'))
                        style = str(styles[0]) if styles else ''
                        from modules.director import direct_project
                        config.GEMINI_MODEL    = settings['dir_model']
                        config.GEMINI_TWO_PASS = settings['dir_twopass'].lower() in ('true', '1', 'yes')
                        if settings['dir_clipmode'] == 'video':
                            config.VIDEO_CLIP_MIN_DURATION = settings['dir_clipmin']
                            config.VIDEO_CLIP_MAX_DURATION = settings['dir_clipmax']
                        else:
                            config.SLIDESHOW_CLIP_MIN_DURATION = settings['dir_clipmin']
                            config.SLIDESHOW_CLIP_MAX_DURATION = settings['dir_clipmax']
                        config.INTRO_BLOCK_DURATION    = settings['dir_intro']
                        config.INTRO_CLIP_MIN_DURATION = settings['dir_intro_min']
                        config.INTRO_CLIP_MAX_DURATION = settings['dir_intro_max']
                        with capture_stdout(self.app.log_queue, "control",
                                           log_file=log_fh, task_label=f"Direction {p.name}",
                                           master_log=mfh):
                            direct_project(str(tr), style, str(p), p.name)

                    elif stage == "ImageGen":
                        # Inflight: launch watch_i2v.py BEFORE ImageGen
                        _inflight_proc = None
                        if settings.get('inflight_mode') and 'VideoGen' in stages:
                            _watch_script = AGENT_DIR / 'watch_i2v.py'
                            if _watch_script.exists():
                                _vid_keys_str = settings.get('vid_keys', '1')
                                _vid_par = settings.get('vid_parallel', config.VEONONSTOP_MAX_PARALLEL)
                                _vid_ar = settings.get('vid_ratio', config.VEONONSTOP_ASPECT_RATIO)
                                _w_cmd = [sys.executable, str(_watch_script),
                                          '--project', str(p),
                                          '--parallel', str(_vid_par),
                                          '--key-slot', _vid_keys_str,
                                          '--aspect', _vid_ar,
                                          '--no-cancel']
                                if settings.get('vid_prompt_mode') == 'single':
                                    _w_cmd.append('--single-prompt')
                                _w_env = dict(os.environ)
                                _w_env['PYTHONUTF8'] = '1'
                                try:
                                    _inflight_proc = subprocess.Popen(
                                        _w_cmd, cwd=str(AGENT_DIR), env=_w_env,
                                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                        bufsize=1, text=True, encoding='utf-8', errors='replace')
                                    # Stream subprocess output to GUI log in background
                                    def _stream_inflight():
                                        for line in _inflight_proc.stdout:
                                            line = line.rstrip('\n\r')
                                            if line:
                                                self.app.log(f"[INFLIGHT] {line}", tab="control")
                                                if log_fh:
                                                    try:
                                                        log_fh.write(f"[INFLIGHT] {line}\n")
                                                        log_fh.flush()
                                                    except Exception:
                                                        pass
                                    threading.Thread(target=_stream_inflight, daemon=True).start()
                                    self.app.log(f"[INFLIGHT] watch_i2v started (parallel={_vid_par})",
                                                 "INFO", tab="control")
                                except Exception as _ie:
                                    self.app.log(f"[INFLIGHT] Failed to start: {_ie}", "WARN", tab="control")

                        if settings['engine'] == 'fastgen':
                            from modules.fastgen import generate_all_images
                            with capture_stdout(self.app.log_queue, "control",
                                               log_file=log_fh, task_label=f"ImageGen {p.name}",
                                               master_log=mfh):
                                generate_all_images(
                                    str(p),
                                    api_key=getattr(config, 'FASTGEN_API_KEY', None),
                                    max_parallel=settings['fg_parallel'],
                                    model=settings['fg_model'],
                                    silent=True,
                                )
                        else:
                            from modules.imggen import generate_all_images as veo_gen
                            config.VEONONSTOP_BANANA_MODEL = settings.get('veo_model', 'GEM_PIX_2')
                            _ig_active = _veo_sel_to_active(settings.get('veo_imgkeys', 'key1'))
                            # Copy img refs to project/ref/ for banana_ref
                            if settings['veo_mode'] == 'banana_ref':
                                _iref_files = settings.get('img_ref_files', [])
                                if _iref_files:
                                    _ird = p / 'ref'
                                    _ird.mkdir(exist_ok=True)
                                    import shutil as _sh2
                                    _copied_refs = 0
                                    for _irf in _iref_files:
                                        _dst = str(_ird / Path(_irf).name)
                                        if Path(_irf).resolve() != Path(_dst).resolve():
                                            _sh2.copy(str(_irf), _dst)
                                            _copied_refs += 1
                                    if _copied_refs:
                                        self.app.log(f"Copied {_copied_refs} img refs → ref/", tab="control")
                            with capture_stdout(self.app.log_queue, "control",
                                               log_file=log_fh, task_label=f"ImageGen {p.name}",
                                               master_log=mfh):
                                _UPS_MAP = {'2k': 'UPSAMPLE_IMAGE_RESOLUTION_2K', '4k': 'UPSAMPLE_IMAGE_RESOLUTION_4K'}
                                _ups_res = _UPS_MAP.get(settings.get('img_upscale', 'off').lower())
                                veo_gen(str(p), mode=settings['veo_mode'],
                                        aspect_ratio=settings['veo_ratio'],
                                        max_parallel=settings['veo_parallel'],
                                        active_keys=_ig_active,
                                        upscale_resolution=_ups_res,
                                        preflight=not settings.get('skip_preflight', False),
                                        silent=True)

                        # Inflight: wait for watch_i2v to finish
                        if _inflight_proc is not None:
                            self.app.log("[INFLIGHT] ImageGen done, waiting for watch_i2v...",
                                         "INFO", tab="control")
                            _inflight_proc.wait()
                            self.app.log("[INFLIGHT] watch_i2v done → vid_img/", "INFO", tab="control")

                    elif stage == "VideoGen":
                        # Skip VideoGen if inflight already handled it
                        if settings.get('inflight_mode') and 'ImageGen' in stages:
                            self.app.log("[INFLIGHT] VideoGen skipped — already done by watch_i2v",
                                         "INFO", tab="control")
                            _close_logs(log_fh, mfh, time.time() - t_stage)
                            continue
                        from modules.veo_video import generate_all_videos
                        if settings.get('skip_preflight'):
                            os.environ['VARAGENT_SKIP_PREFLIGHT'] = '1'
                        else:
                            os.environ.pop('VARAGENT_SKIP_PREFLIGHT', None)
                        if settings.get('fast_censor'):
                            config.VEONONSTOP_FAST_CENSOR = settings['fast_censor']
                        _vid_active = _veo_sel_to_active(settings.get('vid_keys', 'key1'))
                        _sp = None
                        if settings.get('vid_prompt_mode') == 'single':
                            _sp_file = p / 'single_prompt.txt'
                            if _sp_file.exists():
                                _sp = _sp_file.read_text(encoding='utf-8').strip() or None
                            else:
                                self.app.log("single_prompt.txt not found — using per-clip", "WARN", tab="control")
                        # Vislide: фильтрация clip_ids
                        _vislide_cids = None
                        _vi = int(os.environ.get('VARAGENT_VISLIDE_INTERVAL', '0'))
                        if _vi >= 2:
                            try:
                                import json as _json
                                _mp = p / 'montage_plan.json'
                                if _mp.exists():
                                    _md = _json.loads(_mp.read_text(encoding='utf-8'))
                                    _plan = _md.get('montage_plan', _md)
                                    _clips = _plan.get('clips', [])
                                    _animated = set()
                                    _all_ids = [c['id'] for c in _clips]
                                    for _ii, _cid in enumerate(_all_ids):
                                        if (_ii + 1) % _vi == 0:
                                            _animated.add(_cid)
                                    _intro_dur = config.INTRO_BLOCK_DURATION
                                    if _intro_dur > 0:
                                        for _c in _clips:
                                            if _c.get('startTime', 0) < _intro_dur:
                                                _animated.add(_c['id'])
                                    _vislide_cids = sorted(_animated)
                                    self.app.log(f"Vislide: {len(_vislide_cids)}/{len(_clips)} clips → i2v", tab="control")
                            except Exception as _ve:
                                self.app.log(f"Vislide filter error: {_ve}", "WARN", tab="control")
                        # Components: copy ref files to project/ref/ BEFORE capture_stdout
                        _ref_dir = None
                        if settings['vid_mode'] == 'components':
                            _ref_files = settings.get('vid_ref_files', [])
                            _rd = p / 'ref'
                            if _ref_files:
                                _rd.mkdir(exist_ok=True)
                                import shutil as _sh
                                _copied_vrefs = 0
                                for _rf in _ref_files:
                                    _vdst = str(_rd / Path(_rf).name)
                                    if Path(_rf).resolve() != Path(_vdst).resolve():
                                        _sh.copy(str(_rf), _vdst)
                                        _copied_vrefs += 1
                                if _copied_vrefs:
                                    self.app.log(f"Copied {_copied_vrefs} ref images → ref/", tab="control")
                            _ref_dir = str(_rd)
                        with capture_stdout(self.app.log_queue, "control",
                                           log_file=log_fh, task_label=f"VideoGen {p.name}",
                                           master_log=mfh):
                            _vg_result = generate_all_videos(
                                str(p),
                                mode=settings['vid_mode'],
                                max_parallel=settings['vid_parallel'],
                                aspect_ratio=settings['vid_ratio'],
                                active_keys=_vid_active,
                                single_prompt=_sp,
                                clip_ids=_vislide_cids,
                                ref_dir=_ref_dir,
                                upscale_video=settings.get('vid_upscale', False),
                                silent=True,
                            )
                        _vg_ok = _vg_result.get('generated', 0) if isinstance(_vg_result, dict) else 0
                        _vg_fail = _vg_result.get('failed', 0) if isinstance(_vg_result, dict) else 0
                        if _vg_ok == 0:
                            raise RuntimeError(f"VideoGen produced 0 clips ({_vg_fail} failed). Cannot proceed.")
                        if _vg_fail > 0:
                            # Find missing clips in vid_img/
                            _vid_dir_check = p / 'vid_img'
                            _gen_dir_check = p / 'generated'
                            _mp_path = p / 'montage_plan.json'
                            _missing_ids = []
                            if _mp_path.exists():
                                import json as _json2
                                _mp_data = _json2.loads(_mp_path.read_text(encoding='utf-8'))
                                _plan = _mp_data.get('montage_plan', _mp_data)
                                for _c in _plan.get('clips', []):
                                    _cid = _c['id']
                                    if _vislide_cids and _cid not in set(_vislide_cids):
                                        continue
                                    if not any((_vid_dir_check / f"{_cid:03d}{_e}").exists()
                                               for _e in ('.mp4', '.png', '.jpg', '.jpeg', '.webp')):
                                        _missing_ids.append(_cid)
                            if _missing_ids:
                                self.app.log(f"VideoGen: {len(_missing_ids)} clips missing, retrying...",
                                             "WARN", tab="control")
                                # Retry missing clips
                                try:
                                    with capture_stdout(self.app.log_queue, "control",
                                                       log_file=log_fh, task_label=f"VideoGen retry {p.name}",
                                                       master_log=mfh):
                                        generate_all_videos(
                                            str(p), mode=settings['vid_mode'],
                                            max_parallel=settings['vid_parallel'],
                                            aspect_ratio=settings['vid_ratio'],
                                            active_keys=_vid_active,
                                            single_prompt=_sp,
                                            clip_ids=_missing_ids,
                                            upscale_video=settings.get('vid_upscale', False),
                                            silent=True,
                                        )
                                except Exception as _retry_e:
                                    self.app.log(f"VideoGen retry failed: {_retry_e}", "WARN", tab="control")

                                # Static fallback for anything still missing
                                _still_missing = []
                                for _cid in _missing_ids:
                                    if any((_vid_dir_check / f"{_cid:03d}{_e}").exists()
                                           for _e in ('.mp4', '.png', '.jpg', '.jpeg', '.webp')):
                                        continue
                                    # Copy static image from generated/
                                    _found = False
                                    for _ext in ('.png', '.jpg', '.jpeg', '.webp'):
                                        _src_img = _gen_dir_check / f"{_cid:03d}{_ext}"
                                        if _src_img.exists():
                                            import shutil as _sh3
                                            _vid_dir_check.mkdir(exist_ok=True)
                                            _sh3.copy(str(_src_img), str(_vid_dir_check / f"{_cid:03d}{_ext}"))
                                            _found = True
                                            break
                                    if not _found:
                                        _still_missing.append(_cid)
                                if _still_missing:
                                    self.app.log(f"WARNING: {len(_still_missing)} clips have no video or image: {_still_missing[:20]}",
                                                 "WARN", tab="control")
                                elif _missing_ids:
                                    _recovered = len(_missing_ids) - len(_still_missing)
                                    self.app.log(f"Recovered {_recovered} missing clips (retry + static fallback)",
                                                 "INFO", tab="control")
                        # Vislide: copy static fallback for non-animated clips
                        if _vislide_cids:
                            import shutil as _shutil
                            _gen_dir = p / 'generated'
                            _vid_dir = p / 'vid_img'
                            _vid_dir.mkdir(exist_ok=True)
                            _all_ids = [c['id'] for c in _clips] if '_clips' in dir() else []
                            _anim_set = set(_vislide_cids)
                            _copied = 0
                            for _cid in _all_ids:
                                if _cid in _anim_set or (_vid_dir / f"{_cid:03d}.mp4").exists():
                                    continue
                                for _ext in ('.png', '.jpg', '.jpeg', '.webp'):
                                    _src = _gen_dir / f"{_cid:03d}{_ext}"
                                    if _src.exists():
                                        _shutil.copy(str(_src), str(_vid_dir / f"{_cid:03d}{_ext}"))
                                        _copied += 1
                                        break
                            if _copied:
                                self.app.log(f"Vislide static fallback: {_copied} images → vid_img/", tab="control")

                    elif stage == "Concat":
                        # Check vid_img/ has files before running concat
                        _vid_check = p / 'vid_img'
                        _vid_files = list(_vid_check.glob('*.*')) if _vid_check.exists() else []
                        if not _vid_files:
                            raise RuntimeError("vid_img/ is empty — VideoGen produced no output. Skipping Concat.")
                        cmd = ['python', str(SCRIPT_DIR / 'video_concat.py'),
                               'montage_plan.json', '-o', f'{p.name}.mp4',
                               '-b', settings['bitrate'], '--force-amd',
                               '--fps', str(settings.get('fps', 60))]
                        if settings['quality'] == '1080p':
                            cmd.extend(['-r', '1080'])
                        if settings['keep_veo_sound']:
                            cmd.append('--veo-audio-inline')
                        if settings.get('subtitles_path'):
                            cmd.extend(['--subtitles', settings['subtitles_path']])
                        if settings.get('keep_files'):
                            cmd.append('--no-cleanup')
                        _env = {**os.environ, 'PYTHONIOENCODING': 'utf-8'}
                        proc = subprocess.Popen(
                            cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            stdin=subprocess.DEVNULL,
                            text=True, encoding='utf-8', errors='replace',
                            cwd=str(p), env=_env
                        )
                        self._active_subproc = proc
                        try:
                            for line in proc.stdout:
                                line = line.rstrip()
                                if not line:
                                    continue
                                low = line.lower()
                                level = 'ERROR' if any(x in low for x in ['error', 'fail', 'traceback']) else 'INFO'
                                self.app.log(line, level, tab="control")
                                log_fh.write(line + '\n')
                                mfh.write(line + '\n')
                        except OSError:
                            pass  # pipe closed after terminate()
                        finally:
                            self._active_subproc = None
                        if proc.wait() != 0:
                            raise RuntimeError(f"Concat failed (exit {proc.returncode})")

                    elif stage == "YT Pack":
                        from modules.yt_packer import run_yt_packer
                        config.YT_PACK_LANGUAGES   = [l.strip() for l in settings['yt_langs'].split(',') if l.strip()]
                        config.YT_PACK_SUBTITLES   = settings['yt_subs']
                        config.YT_PACK_DESCRIPTION = settings['yt_desc']
                        config.YT_PACK_COVERS      = settings['yt_covers']
                        with capture_stdout(self.app.log_queue, "control",
                                           log_file=log_fh, task_label=f"YT Pack {p.name}",
                                           master_log=mfh):
                            run_yt_packer(str(p))

                    elapsed_stage = time.time() - t_stage
                    _close_logs(log_fh, mfh, elapsed_stage)
                    m, s = divmod(int(elapsed_stage), 60)
                    self.app.log(f"Stage {stage}: done ({m}m {s}s)", "SUCCESS", tab="control")

                except Exception:
                    _close_logs(log_fh, mfh, time.time() - t_stage)
                    raise

            elapsed_total = time.time() - t_start
            m, s = divmod(int(elapsed_total), 60)
            self.app.log(f"Finalize complete: {p.name} ({m}m {s}s)", "SUCCESS", tab="control")
            with open(master_path, 'a', encoding='utf-8') as f:
                f.write(f"\n=== FINALIZE DONE: {m}m {s}s ===\n")

        except Exception as e:
            elapsed_total = time.time() - t_start
            m, s = divmod(int(elapsed_total), 60)
            self.app.log(
                f"Finalize FAILED at '{_current_stage}' ({m}m {s}s): {e}",
                "ERROR", tab="control"
            )
            try:
                with open(master_path, 'a', encoding='utf-8') as f:
                    f.write(f"\n=== FINALIZE ERROR at '{_current_stage}': {e} ===\n")
            except Exception:
                pass
        finally:
            self.active_tasks = max(0, self.active_tasks - 1)
            self.root.after(0, self._update_status)
            self.root.after(0, self.refresh_projects)

    def _run_dryrun(self):
        self._run_subprocess_in_thread(
            ['python', str(AGENT_DIR / 'agent.py'), 'dry-run'],
            task_name="Dry-Run")

    def _run_mock(self):
        self._run_subprocess_in_thread(
            ['python', str(AGENT_DIR / 'agent.py'), 'dry-run', '--mock'],
            task_name="Mock Run")


# ════════════════════════════════════════════════════════════════════
# TAB: PROMPTS EDITOR
# ════════════════════════════════════════════════════════════════════

_PROMPT_FILES = [
    ("Director Instruction (pass 2)",   AGENT_DIR / "prompts" / "director_instruction.txt"),
    ("Director Instruction (pass 1)",   AGENT_DIR / "prompts" / "director_instruction_pass1.txt"),
    ("Director Pause Guide",            AGENT_DIR / "prompts" / "director_pause_guide.txt"),
    ("Script Director — Prose",         AGENT_DIR / "prompts" / "script_director_prose.txt"),
    ("Script Director — Screenplay",    AGENT_DIR / "prompts" / "script_director_screenplay.txt"),
    ("Rewrite Prompt (censorship)",     AGENT_DIR / "prompts" / "rewrite_prompt.txt"),
    ("Ref Remix (Grok)",                AGENT_DIR / "prompts" / "ref_remix_prompt.txt"),
    ("i2v Remix (Grok)",                AGENT_DIR / "prompts" / "i2v_remix_prompt.txt"),
    ("YT Packer Prompt",                AGENT_DIR / "prompts" / "yt_packer_prompt.txt"),
    ("Subtitle Template 720p (.ass)",   AGENT_DIR / "templates" / "subtitles_720p.ass"),
    ("Subtitle Template 1080p (.ass)",  AGENT_DIR / "templates" / "subtitles_1080p.ass"),
]

class PromptsTab:
    """Prompt files editor — view and edit all agent prompt files."""

    def __init__(self, notebook, app: VarAgentGUI):
        self.app = app
        self.frame = ttk.Frame(notebook)
        self._current_path: Optional[Path] = None
        self._modified = False
        self.create_ui()

    def create_ui(self):
        # Top bar
        top = ttk.Frame(self.frame)
        top.pack(fill=tk.X, padx=10, pady=(8, 0))
        self.save_btn = ttk.Button(top, text="Save", command=self._save,
                                   style="Accent.TButton")
        self.save_btn.pack(side=tk.LEFT, padx=(0, 4))
        ttk.Button(top, text="Reload", command=self._reload).pack(side=tk.LEFT, padx=4)
        ttk.Button(top, text="Open Folder", command=self._open_folder).pack(side=tk.LEFT, padx=4)
        self.status_lbl = ttk.Label(top, text="", style="Dim.TLabel")
        self.status_lbl.pack(side=tk.LEFT, padx=10)
        self.file_lbl = ttk.Label(top, text="", style="Dim.TLabel")
        self.file_lbl.pack(side=tk.RIGHT, padx=4)

        # Body: left list + right editor
        body = ttk.Frame(self.frame)
        body.pack(fill=tk.BOTH, expand=True, padx=10, pady=6)

        # Left: prompt file list
        left = ttk.Frame(body, style="Card.TFrame")
        left.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 6))
        ttk.Label(left, text="Prompts", style="Section.TLabel").pack(anchor=tk.W, padx=10, pady=(8, 4))
        self.listbox = tk.Listbox(left, width=28, bg=COLORS['bg_card'], fg=COLORS['text'],
                                   font=FONT_DIM, selectbackground=COLORS['accent'],
                                   selectforeground='#ffffff', relief=tk.FLAT,
                                   borderwidth=0, activestyle='none')
        for label, _ in _PROMPT_FILES:
            self.listbox.insert(tk.END, f"  {label}")
        self.listbox.pack(fill=tk.Y, expand=True, padx=4, pady=(0, 8))
        self.listbox.bind("<<ListboxSelect>>", self._on_select)

        # Right: text editor
        right = ttk.Frame(body, style="Card.TFrame")
        right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        right.rowconfigure(0, weight=1)
        right.columnconfigure(0, weight=1)
        self.text = tk.Text(right, bg=COLORS['bg_input'], fg=COLORS['text'],
                             insertbackground=COLORS['text'], font=FONT_LOG,
                             relief=tk.FLAT, wrap=tk.WORD, padx=10, pady=8,
                             undo=True)
        vsb = ttk.Scrollbar(right, orient=tk.VERTICAL, command=self.text.yview)
        self.text.configure(yscrollcommand=vsb.set)
        self.text.grid(row=0, column=0, sticky='nsew', padx=(6, 0), pady=6)
        vsb.grid(row=0, column=1, sticky='ns', pady=6, padx=(0, 4))
        self.text.bind("<<Modified>>", self._on_text_modified)

        # Select first by default
        self.listbox.selection_set(0)
        self.frame.after(100, lambda: self._load_file(_PROMPT_FILES[0][1]))

    def _on_select(self, event=None):
        sel = self.listbox.curselection()
        if not sel:
            return
        if self._modified and self._current_path:
            if not messagebox.askyesno("Unsaved changes",
                                        f"Discard changes to {self._current_path.name}?"):
                return
        _, path = _PROMPT_FILES[sel[0]]
        self._load_file(path)

    def _load_file(self, path: Path):
        self._current_path = path
        self.text.edit_modified(False)
        self._modified = False
        self.text.delete('1.0', tk.END)
        if path.exists():
            self.text.insert('1.0', path.read_text(encoding='utf-8'))
        else:
            self.text.insert('1.0', f"# File not found: {path}\n")
        self.text.edit_modified(False)
        self.file_lbl.config(text=str(path.relative_to(AGENT_DIR.parent)
                                       if path.is_relative_to(AGENT_DIR.parent) else path))
        self.status_lbl.config(text="")

    def _on_text_modified(self, event=None):
        if self.text.edit_modified():
            self._modified = True
            self.status_lbl.config(text="● unsaved", foreground=COLORS.get('yellow', '#f5c842'))

    def _save(self):
        if not self._current_path:
            return
        content = self.text.get('1.0', 'end-1c')
        self._current_path.write_text(content, encoding='utf-8')
        # Sync to PORTABLE
        portable_path = Path(str(self._current_path).replace('VARAGENT_API', 'VARAGENT_API_PORTABLE'))
        if portable_path.parent.exists():
            portable_path.write_text(content, encoding='utf-8')
        self.text.edit_modified(False)
        self._modified = False
        self.status_lbl.config(text="Saved", foreground=COLORS['green'])
        self.frame.after(3000, lambda: self.status_lbl.config(text=""))

    def _reload(self):
        if self._current_path:
            self._load_file(self._current_path)

    def _open_folder(self):
        folder = AGENT_DIR / "prompts"
        if folder.exists():
            os.startfile(str(folder))


# ════════════════════════════════════════════════════════════════════
# TAB 3: SETTINGS (.env Editor)
# ════════════════════════════════════════════════════════════════════

class SettingsTab:
    """.env editor — view and edit all config values."""

    def __init__(self, notebook, app: VarAgentGUI):
        self.app = app
        self.root = app.root
        self.frame = ttk.Frame(notebook)
        self.env_entries = {}
        self.env_lines = []
        self.create_ui()

    def create_ui(self):
        # Top buttons
        top = ttk.Frame(self.frame)
        top.pack(fill=tk.X, padx=10, pady=(8, 0))
        ttk.Button(top, text="Save .env", command=self._save_env, style="Accent.TButton").pack(side=tk.LEFT, padx=4)
        ttk.Button(top, text="Reload", command=self._load_env_editor).pack(side=tk.LEFT, padx=4)
        self.save_status = ttk.Label(top, text="", style="Dim.TLabel")
        self.save_status.pack(side=tk.LEFT, padx=8)

        # Scrollable two-column layout
        outer = ttk.Frame(self.frame)
        outer.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        canvas = tk.Canvas(outer, bg=COLORS['bg_dark'], highlightthickness=0)
        scrollbar = ttk.Scrollbar(outer, orient=tk.VERTICAL, command=canvas.yview)
        self.scroll_inner = ttk.Frame(canvas, style="TFrame")
        self.scroll_inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        self._canvas_win = canvas.create_window((0, 0), window=self.scroll_inner, anchor=tk.NW)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self._canvas = canvas
        # Stretch inner frame to canvas width
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(self._canvas_win, width=e.width))
        _mw = lambda e: canvas.yview_scroll(-1 * (e.delta // 120), "units")
        canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", _mw))
        canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))

        # Two columns
        self.col_left = ttk.Frame(self.scroll_inner, style="TFrame")
        self.col_left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 4))
        self.col_right = ttk.Frame(self.scroll_inner, style="TFrame")
        self.col_right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(4, 0))

        self.root.after(200, self._load_env_editor)

    def _load_env_editor(self):
        env_path = AGENT_DIR / '.env'
        if not env_path.exists():
            return
        # Патч: добавить недостающие ключи (Key3/Key4 и т.д.) если их нет
        try:
            from modules.updater import patch_env
            patch_env(SCRIPT_DIR)
        except Exception:
            pass
        self.env_entries = {}
        self.env_lines = []
        for widget in self.col_left.winfo_children():
            widget.destroy()
        for widget in self.col_right.winfo_children():
            widget.destroy()

        with open(env_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        # Parse into sections
        sections = []
        current_title = "General"
        current_items = []
        for line in lines:
            raw = line.rstrip('\n')
            self.env_lines.append(raw)
            if raw.startswith('# ====') or raw.startswith('# ----'):
                title = raw.strip('# =- ')
                if title:
                    if current_items:
                        sections.append((current_title, current_items))
                    current_title = title
                    current_items = []
            elif '=' in raw and not raw.startswith('#'):
                key, _, val = raw.partition('=')
                current_items.append((key.strip(), val.strip()))
        if current_items:
            sections.append((current_title, current_items))

        # Distribute sections to two columns (left-right by count balance)
        left_count = 0
        right_count = 0
        for title, items in sections:
            if left_count <= right_count:
                col = self.col_left
                left_count += len(items) + 1
            else:
                col = self.col_right
                right_count += len(items) + 1

            card = ttk.Frame(col, style="Card.TFrame", padding=10)
            card.pack(fill=tk.X, pady=4, padx=2)
            ttk.Label(card, text=title, style="Section.TLabel").pack(anchor=tk.W, pady=(0, 4))
            for key, val in items:
                row = ttk.Frame(card, style="Card.TFrame")
                row.pack(fill=tk.X, pady=1)
                ttk.Label(row, text=key, style="Dim.TLabel", width=30).pack(side=tk.LEFT)
                opts = ENV_DROPDOWN_OPTIONS.get(key)
                if opts:
                    entry = ttk.Combobox(row, values=opts, state='normal', font=FONT_DIM)
                    # Match current .env value to a display option (e.g. "GEM_PIX_2" → "GEM_PIX_2 — Banana Pro")
                    matched = next((o for o in opts if o.split(' \u2014')[0].strip() == val), val)
                    entry.set(matched)
                else:
                    show = '•' if 'API_KEY' in key.upper() else ''
                    entry = tk.Entry(row, bg=COLORS['bg_input'], fg=COLORS['text'],
                                     insertbackground=COLORS['text'], relief=tk.FLAT, show=show,
                                     font=FONT_DIM)
                    entry.insert(0, val)
                    # Full clipboard support for Entry fields (show='•' blocks defaults on Windows)
                    def _setup_entry(w):
                        _undo_stack = []
                        def _snapshot():
                            _undo_stack.append(w.get())
                            if len(_undo_stack) > 50:
                                _undo_stack.pop(0)
                        def _paste(e=None):
                            try:
                                text = w.clipboard_get()
                            except tk.TclError:
                                return 'break'
                            _snapshot()
                            try:
                                w.delete(tk.SEL_FIRST, tk.SEL_LAST)
                            except tk.TclError:
                                pass
                            w.insert(tk.INSERT, text)
                            return 'break'
                        def _cut(e=None):
                            try:
                                sel = w.selection_get()
                            except tk.TclError:
                                return 'break'
                            _snapshot()
                            w.clipboard_clear()
                            w.clipboard_append(sel)
                            w.delete(tk.SEL_FIRST, tk.SEL_LAST)
                            return 'break'
                        def _copy(e=None):
                            try:
                                sel = w.selection_get()
                            except tk.TclError:
                                return 'break'
                            w.clipboard_clear()
                            w.clipboard_append(sel)
                            return 'break'
                        def _undo(e=None):
                            if _undo_stack:
                                cur = w.get()
                                prev = _undo_stack.pop()
                                w.delete(0, tk.END)
                                w.insert(0, prev)
                            return 'break'
                        def _select_all(e=None):
                            w.select_range(0, tk.END)
                            w.icursor(tk.END)
                            return 'break'
                        def _ctx(e):
                            m = tk.Menu(w, tearoff=0)
                            m.add_command(label='Cut', command=_cut)
                            m.add_command(label='Copy', command=_copy)
                            m.add_command(label='Paste', command=_paste)
                            m.add_separator()
                            m.add_command(label='Undo', command=_undo)
                            m.add_separator()
                            m.add_command(label='Select All', command=_select_all)
                            m.post(e.x_root, e.y_root)
                        # Snapshot before each keystroke for undo
                        w.bind('<Key>', lambda e: _snapshot() if len(e.char) == 1 else None)
                        # Clipboard shortcuts (virtual events + key combos)
                        w.bind('<<Paste>>', lambda e: _paste())
                        w.bind('<Control-v>', lambda e: _paste())
                        w.bind('<Control-V>', lambda e: _paste())
                        w.bind('<Command-v>', lambda e: _paste())
                        w.bind('<Control-c>', lambda e: _copy())
                        w.bind('<Control-C>', lambda e: _copy())
                        w.bind('<Command-c>', lambda e: _copy())
                        w.bind('<Control-x>', lambda e: _cut())
                        w.bind('<Control-X>', lambda e: _cut())
                        w.bind('<Command-x>', lambda e: _cut())
                        w.bind('<Control-z>', lambda e: _undo())
                        w.bind('<Control-Z>', lambda e: _undo())
                        w.bind('<Command-z>', lambda e: _undo())
                        w.bind('<Control-a>', lambda e: _select_all())
                        w.bind('<Control-A>', lambda e: _select_all())
                        w.bind('<Command-a>', lambda e: _select_all())
                        w.bind('<Button-3>', _ctx)
                    _setup_entry(entry)
                    if show:
                        def _make_toggle(ent, r):
                            def _toggle():
                                if ent.cget('show') == '•':
                                    ent.configure(show='')
                                    _btn.configure(text='Hide')
                                else:
                                    ent.configure(show='•')
                                    _btn.configure(text='Show')
                            _btn = ttk.Button(r, text='Show', width=5, command=_toggle)
                            _btn.pack(side=tk.RIGHT, padx=(0, 2))
                        _make_toggle(entry, row)
                entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)
                self.env_entries[key] = entry

    def _save_env(self):
        env_path = AGENT_DIR / '.env'
        new_lines = []
        written_keys = set()
        with open(env_path, 'r', encoding='utf-8') as f:
            for line in f:
                raw = line.rstrip('\n')
                if '=' in raw and not raw.startswith('#'):
                    key = raw.split('=', 1)[0].strip()
                    if key in self.env_entries:
                        new_val = self.env_entries[key].get()
                        # Strip display label suffix (e.g. "GEM_PIX_2 — Banana Pro" → "GEM_PIX_2")
                        if ' \u2014 ' in new_val:
                            new_val = new_val.split(' \u2014 ')[0].strip()
                        new_lines.append(f"{key}={new_val}")
                        written_keys.add(key)
                        continue
                new_lines.append(raw)

        # Append keys that user edited in GUI but didn't exist in .env file
        for key, entry in self.env_entries.items():
            if key not in written_keys:
                val = entry.get()
                if ' \u2014 ' in val:
                    val = val.split(' \u2014 ')[0].strip()
                if val:  # only add if user actually entered a value
                    new_lines.append(f"{key}={val}")

        with open(env_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(new_lines) + '\n')

        # Reload config: push saved values into os.environ so config.py picks them up
        for key, entry in self.env_entries.items():
            val = entry.get()
            if ' \u2014 ' in val:
                val = val.split(' \u2014 ')[0].strip()
            os.environ[key] = val
        try:
            from dotenv import load_dotenv
            load_dotenv(str(env_path), override=True)
        except ImportError:
            pass
        importlib.reload(config)
        self.save_status.config(text="Saved + reloaded", foreground=COLORS['green'])
        self.root.after(3000, lambda: self.save_status.config(text=""))
        self.app.log(".env saved and config reloaded", "SUCCESS", tab="control")


# ════════════════════════════════════════════════════════════════════
# TAB 4: VEONONSTOP GENERATOR
# ════════════════════════════════════════════════════════════════════

class VeoGeneratorTab:
    """Standalone VeoNonStop generator — port of 2.py with VeoNonStopClient."""

    def __init__(self, notebook, app: VarAgentGUI):
        self.app = app
        self.root = app.root
        self.frame = ttk.Frame(notebook)
        self.output_dir = get_output_dir()

        # State
        self.api_key = tk.StringVar(value=config.VEONONSTOP_API_KEY or '')
        self.mode = tk.StringVar(value="video_t2v")
        self.aspect_ratio = tk.StringVar(value="16:9")
        self.generation_count = tk.IntVar(value=1)
        self.model_key = tk.StringVar(value="Banana Pro")
        self.thread_count = tk.IntVar(value=min(4, config.VEONONSTOP_MAX_PARALLEL))
        self.max_threads = 24

        self.reference_images = []
        self.video_images = []
        self.single_image = None
        self.single_image_list = []
        self.batch_start_images: list = []   # [{image_base64, mime_type, name}, ...]
        self.batch_end_images: list = []
        self.prompts_list = []
        self.is_generating = False
        self.last_video_result = None
        self.stats = {"success": 0, "failed": 0, "total": 0}
        self.stats_lock = threading.Lock()

        self.create_ui()

    def create_ui(self):
        content = ttk.Frame(self.frame)
        content.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        # LEFT column (fixed width)
        left = ttk.Frame(content)
        left.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 5))

        # RIGHT column
        right = ttk.Frame(content)
        right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self._build_left(left)
        self._build_right(right)

    def _build_left(self, parent):
        # API Key
        card = self.app.create_card(parent, "API Key")
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(fill=tk.X)
        self.api_entry = tk.Entry(row, textvariable=self.api_key, bg=COLORS['bg_input'],
                                  fg=COLORS['text'], insertbackground=COLORS['text'],
                                  relief=tk.FLAT, show='*')
        self.api_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 4))
        ttk.Button(row, text="Show", command=self._toggle_key, width=5).pack(side=tk.LEFT, padx=1)
        ttk.Button(row, text="Account", command=self.check_account, width=8).pack(side=tk.LEFT, padx=1)

        # Mode
        card = self.app.create_card(parent, "Generation Mode")
        modes = [
            ("Text to Video", "video_t2v"),
            ("Image to Video", "video_i2v"),
            ("Text2Video + References", "video_multi"),
            ("Batch Frame", "video_batch"),
            ("Banana (image)", "image_banana"),
            ("IMAGEN 3.5", "image_imagen"),
        ]
        for label, val in modes:
            ttk.Radiobutton(card, text=label, variable=self.mode, value=val,
                            command=self._on_mode_change).pack(anchor=tk.W)

        # Parameters
        card = self.app.create_card(parent, "Parameters")
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(fill=tk.X, pady=2)
        ttk.Label(row, text="Ratio:", style="Card.TLabel").pack(side=tk.LEFT)
        for v in ['16:9', '9:16', '1:1']:
            ttk.Radiobutton(row, text=v, variable=self.aspect_ratio, value=v).pack(side=tk.LEFT, padx=3)
        row2 = ttk.Frame(card, style="Card.TFrame")
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="Count:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row2, textvariable=self.generation_count, from_=1, to=8, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=4)

        # Threads
        card = self.app.create_card(parent, "Threads")
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(fill=tk.X)
        self.thread_label = ttk.Label(row, text=f"Threads: {self.thread_count.get()}", style="Card.TLabel")
        self.thread_label.pack(side=tk.LEFT)
        slider = tk.Scale(row, from_=1, to=self.max_threads, orient=tk.HORIZONTAL,
                          variable=self.thread_count, bg=COLORS['bg_card'], fg=COLORS['text'],
                          highlightbackground=COLORS['bg_card'], troughcolor=COLORS['bg_input'],
                          command=lambda v: self.thread_label.config(text=f"Threads: {v}"))
        slider.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)
        presets = ttk.Frame(card, style="Card.TFrame")
        presets.pack(fill=tk.X, pady=2)
        for n in [1, 4, 8, 12, 24]:
            ttk.Button(presets, text=str(n), width=3,
                       command=lambda x=n: self.thread_count.set(x)).pack(side=tk.LEFT, padx=2)

        # Images (dynamic based on mode)
        card = self.app.create_card(parent, "Images")
        # i2v: single image
        self.single_frame = ttk.Frame(card, style="Card.TFrame")
        self.single_img_label = ttk.Label(self.single_frame, text="No image", style="Dim.TLabel")
        self.single_img_label.pack(side=tk.LEFT)
        ttk.Button(self.single_frame, text="Select", command=self._select_single_image).pack(side=tk.RIGHT)

        # multi: image list
        self.multi_frame = ttk.Frame(card, style="Card.TFrame")
        multi_top = ttk.Frame(self.multi_frame, style="Card.TFrame")
        multi_top.pack(fill=tk.X)
        self.multi_label = ttk.Label(multi_top, text="Images: (0)", style="Dim.TLabel")
        self.multi_label.pack(side=tk.LEFT)
        ttk.Button(multi_top, text="Add", command=self._add_video_image).pack(side=tk.RIGHT, padx=2)
        ttk.Button(multi_top, text="Remove", command=self._remove_selected_video_image).pack(side=tk.RIGHT, padx=2)
        ttk.Button(multi_top, text="Clear", command=self._clear_video_images).pack(side=tk.RIGHT)
        self.multi_listbox = tk.Listbox(self.multi_frame, height=3, bg=COLORS['bg_input'],
                                        fg=COLORS['text'], font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        self.multi_listbox.pack(fill=tk.X, pady=(2, 0))

        # batch: start + end
        self.batch_frame = ttk.Frame(card, style="Card.TFrame")
        # Start images
        row_s = ttk.Frame(self.batch_frame, style="Card.TFrame")
        row_s.pack(fill=tk.X, pady=(0, 2))
        self.start_count_lbl = ttk.Label(row_s, text="Start (0):", style="Dim.TLabel")
        self.start_count_lbl.pack(side=tk.LEFT)
        ttk.Button(row_s, text="Clear", command=lambda: self._clear_batch("start")).pack(side=tk.RIGHT, padx=2)
        ttk.Button(row_s, text="Remove", command=lambda: self._remove_batch_item("start")).pack(side=tk.RIGHT, padx=2)
        ttk.Button(row_s, text="Select", command=lambda: self._select_batch("start")).pack(side=tk.RIGHT, padx=2)
        self.start_listbox = tk.Listbox(self.batch_frame, height=3, bg=COLORS['bg_input'],
                                         fg=COLORS['text'], font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        self.start_listbox.pack(fill=tk.X, pady=(0, 4))
        # End images
        row_e = ttk.Frame(self.batch_frame, style="Card.TFrame")
        row_e.pack(fill=tk.X, pady=(0, 2))
        self.end_count_lbl = ttk.Label(row_e, text="End (0):", style="Dim.TLabel")
        self.end_count_lbl.pack(side=tk.LEFT)
        ttk.Button(row_e, text="Clear", command=lambda: self._clear_batch("end")).pack(side=tk.RIGHT, padx=2)
        ttk.Button(row_e, text="Remove", command=lambda: self._remove_batch_item("end")).pack(side=tk.RIGHT, padx=2)
        ttk.Button(row_e, text="Select", command=lambda: self._select_batch("end")).pack(side=tk.RIGHT, padx=2)
        self.end_listbox = tk.Listbox(self.batch_frame, height=3, bg=COLORS['bg_input'],
                                       fg=COLORS['text'], font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        self.end_listbox.pack(fill=tk.X)
        self.batch_pairs_lbl = ttk.Label(self.batch_frame, text="", style="Dim.TLabel")
        self.batch_pairs_lbl.pack(anchor=tk.W, pady=(2, 0))

        # banana: model + refs
        self.model_frame = ttk.Frame(card, style="Card.TFrame")
        row_m = ttk.Frame(self.model_frame, style="Card.TFrame")
        row_m.pack(fill=tk.X)
        ttk.Label(row_m, text="Model:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Combobox(row_m, textvariable=self.model_key, values=BANANA_DISPLAY,
                     width=12, state='readonly').pack(side=tk.LEFT, padx=4)

        self.ref_frame = ttk.Frame(card, style="Card.TFrame")
        ref_row = ttk.Frame(self.ref_frame, style="Card.TFrame")
        ref_row.pack(fill=tk.X)
        self.ref_count_label = ttk.Label(ref_row, text="Refs: (0)", style="Dim.TLabel")
        self.ref_count_label.pack(side=tk.LEFT)
        ttk.Button(ref_row, text="Add Named", command=self._add_named_reference).pack(side=tk.RIGHT, padx=2)
        ttk.Button(ref_row, text="Load ref/", command=self._load_refs_from_dir).pack(side=tk.RIGHT, padx=2)
        ttk.Button(ref_row, text="Remove", command=self._remove_selected_ref).pack(side=tk.RIGHT, padx=2)
        ttk.Button(ref_row, text="Clear", command=self._clear_references).pack(side=tk.RIGHT)
        self.ref_veo_listbox = tk.Listbox(self.ref_frame, height=3, bg=COLORS['bg_input'],
                                          fg=COLORS['text'], font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        self.ref_veo_listbox.pack(fill=tk.X, pady=(2, 0))

        self._on_mode_change()

    def _build_right(self, parent):
        # Prompts
        card = self.app.create_card(parent, "Prompts")
        btn_row = ttk.Frame(card, style="Card.TFrame")
        btn_row.pack(fill=tk.X, pady=(0, 4))
        ttk.Button(btn_row, text="Load File", command=self._load_prompts_file).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="Clipboard", command=self._load_clipboard).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="Clear", command=self._clear_prompts).pack(side=tk.LEFT, padx=2)
        self.prompts_count_label = ttk.Label(btn_row, text="0 prompts", style="Dim.TLabel")
        self.prompts_count_label.pack(side=tk.RIGHT)
        self.prompt_text = scrolledtext.ScrolledText(card, height=5, bg=COLORS['bg_input'],
                                                     fg=COLORS['text'], font=FONT_LOG,
                                                     insertbackground=COLORS['text'], relief=tk.FLAT)
        self.prompt_text.pack(fill=tk.X)
        self.prompt_text.bind('<KeyRelease>', self._on_prompt_change)

        # Actions + Stats
        card = self.app.create_card(parent, "Actions")
        stats_row = ttk.Frame(card, style="Card.TFrame")
        stats_row.pack(fill=tk.X, pady=2)
        self.stats_success = ttk.Label(stats_row, text="OK: 0", style="Stats.TLabel")
        self.stats_success.pack(side=tk.LEFT, padx=6)
        self.stats_failed = ttk.Label(stats_row, text="Fail: 0", style="Stats.TLabel")
        self.stats_failed.pack(side=tk.LEFT, padx=6)
        self.stats_progress = ttk.Label(stats_row, text="0/0", style="Stats.TLabel")
        self.stats_progress.pack(side=tk.LEFT, padx=6)
        self.active_threads_label = ttk.Label(stats_row, text="0 active", style="Stats.TLabel")
        self.active_threads_label.pack(side=tk.RIGHT, padx=6)

        self.progress_bar = ttk.Progressbar(card, style="Green.Horizontal.TProgressbar",
                                            mode='determinate', length=300)
        self.progress_bar.pack(fill=tk.X, pady=4)

        # Project name row (для Generate All — создаёт папку с датой+именем)
        proj_row = ttk.Frame(card, style="Card.TFrame")
        proj_row.pack(fill=tk.X, pady=(4, 2))
        ttk.Label(proj_row, text="Project name:", style="Dim.TLabel").pack(side=tk.LEFT)
        self.project_name = tk.StringVar(value="")
        ttk.Entry(proj_row, textvariable=self.project_name,
                  style="Dark.TEntry", width=24).pack(side=tk.LEFT, padx=6)

        btn_row = ttk.Frame(card, style="Card.TFrame")
        btn_row.pack(fill=tk.X, pady=4)
        self.generate_btn = ttk.Button(btn_row, text="Генерировать 1", command=self.start_generation,
                                       style="Accent.TButton")
        self.generate_btn.pack(side=tk.LEFT, padx=3)
        self.multithread_btn = ttk.Button(btn_row, text="Генерировать все",
                                          command=self.start_multithread, style="Accent.TButton")
        self.multithread_btn.pack(side=tk.LEFT, padx=3)
        self.stop_btn = ttk.Button(btn_row, text="Stop", command=self.stop_generation,
                                   state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=3)

        btn_row2 = ttk.Frame(card, style="Card.TFrame")
        btn_row2.pack(fill=tk.X, pady=2)
        ttk.Button(btn_row2, text="Upsample 4K", command=self.upsample_video).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_row2, text="Cancel All", command=self.cancel_all).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_row2, text="Open Folder",
                   command=lambda: os.startfile(str(self.output_dir))).pack(side=tk.LEFT, padx=3)

        # Log
        log_card = self.app.create_card(parent, "Log")
        self.log_widget = self.app.create_log_widget(log_card)
        ttk.Button(log_card, text="Clear Log",
                   command=lambda: self.log_widget.delete("1.0", tk.END)).pack(anchor=tk.W, pady=2)

    # ═══════════ MODE SWITCHING ═══════════

    def _on_mode_change(self):
        mode = self.mode.get()
        for f in (self.single_frame, self.multi_frame, self.batch_frame, self.model_frame, self.ref_frame):
            f.pack_forget()
        if mode == "video_i2v":
            self.single_frame.pack(fill=tk.X, pady=4)
        elif mode == "video_multi":
            self.multi_frame.pack(fill=tk.X, pady=4)
        elif mode == "video_batch":
            self.batch_frame.pack(fill=tk.X, pady=4)
        elif mode == "image_banana":
            self.model_frame.pack(fill=tk.X, pady=4)
            self.ref_frame.pack(fill=tk.X, pady=4)

    # ═══════════ IMAGE MANAGEMENT ═══════════

    def _select_single_image(self):
        files = filedialog.askopenfilenames(filetypes=[("Images", "*.png *.jpg *.jpeg *.webp")])
        if not files:
            return
        if len(files) == 1:
            b64, mime = _image_to_base64(files[0])
            self.single_image = {"image_base64": b64, "mime_type": mime}
            self.single_img_label.config(text=Path(files[0]).name[:20])
            self._log(f"Image: {Path(files[0]).name}")
        else:
            # Multiple images → batch i2v (one request per image)
            self.single_image_list = []
            for fp in files:
                b64, mime = _image_to_base64(fp)
                self.single_image_list.append({"image_base64": b64, "mime_type": mime, "name": Path(fp).stem})
            self.single_image = self.single_image_list[0]  # keep compat
            self.single_img_label.config(text=f"{len(files)} images")
            self._log(f"Images for i2v: {len(files)} loaded")

    def _add_video_image(self):
        files = filedialog.askopenfilenames(filetypes=[("Images", "*.png *.jpg *.jpeg *.webp")])
        for fp in files:
            b64, mime = _image_to_base64(fp)
            name = Path(fp).stem
            self.video_images.append({"name": name, "image_base64": b64, "mime_type": mime})
            self._log(f"Added: {name}")
        if files:
            self.multi_listbox.insert(tk.END, name)
            self.multi_listbox.config(height=max(3, min(len(self.video_images), 6)))
            self.multi_label.config(text=f"Images: ({len(self.video_images)})")

    def _remove_selected_video_image(self):
        sel = self.multi_listbox.curselection()
        if sel:
            self.video_images.pop(sel[0])
            self.multi_listbox.delete(sel[0])
            self.multi_listbox.config(height=max(3, min(len(self.video_images), 6)))
            self.multi_label.config(text=f"Images: ({len(self.video_images)})")

    def _clear_video_images(self):
        self.video_images = []
        self.multi_listbox.delete(0, tk.END)
        self.multi_listbox.config(height=3)
        self.multi_label.config(text="Images: (0)")

    def _select_batch(self, which):
        fps = filedialog.askopenfilenames(filetypes=[("Images", "*.png *.jpg *.jpeg *.webp")])
        if not fps:
            return
        # Сортируем по имени файла — порядок пар определяется именем
        fps = sorted(fps, key=lambda p: Path(p).name)
        imgs = []
        for fp in fps:
            b64, mime = _image_to_base64(fp)
            imgs.append({"image_base64": b64, "mime_type": mime, "name": Path(fp).name})
        if which == "start":
            self.batch_start_images = imgs
            self.start_listbox.delete(0, tk.END)
            for img in imgs:
                self.start_listbox.insert(tk.END, img["name"])
            self.start_listbox.config(height=max(3, min(len(imgs), 6)))
            self.start_count_lbl.config(text=f"Start ({len(imgs)}):")
        else:
            self.batch_end_images = imgs
            self.end_listbox.delete(0, tk.END)
            for img in imgs:
                self.end_listbox.insert(tk.END, img["name"])
            self.end_listbox.config(height=max(3, min(len(imgs), 6)))
            self.end_count_lbl.config(text=f"End ({len(imgs)}):")
        self._update_batch_pairs_lbl()

    def _remove_batch_item(self, which):
        lb = self.start_listbox if which == "start" else self.end_listbox
        imgs = self.batch_start_images if which == "start" else self.batch_end_images
        sel = lb.curselection()
        if sel:
            imgs.pop(sel[0])
            lb.delete(sel[0])
            lb.config(height=max(3, min(len(imgs), 6)))
            lbl = self.start_count_lbl if which == "start" else self.end_count_lbl
            lbl.config(text=f"{'Start' if which == 'start' else 'End'} ({len(imgs)}):")
            self._update_batch_pairs_lbl()

    def _clear_batch(self, which):
        if which == "start":
            self.batch_start_images = []
            self.start_listbox.delete(0, tk.END)
            self.start_count_lbl.config(text="Start (0):")
        else:
            self.batch_end_images = []
            self.end_listbox.delete(0, tk.END)
            self.end_count_lbl.config(text="End (0):")
        self._update_batch_pairs_lbl()

    def _update_batch_pairs_lbl(self):
        ns, ne = len(self.batch_start_images), len(self.batch_end_images)
        if ns == 0 and ne == 0:
            self.batch_pairs_lbl.config(text="")
        else:
            pairs = min(ns, ne)
            warn = "  ⚠ unequal!" if ns != ne else ""
            self.batch_pairs_lbl.config(text=f"Pairs: {pairs}{warn}")

    def _add_named_reference(self):
        files = filedialog.askopenfilenames(filetypes=[("Images", "*.png *.jpg *.jpeg *.webp")])
        for fp in files:
            name = Path(fp).stem
            b64, mime = _image_to_base64(fp)
            self.reference_images.append({"name": name, "image_base64": b64, "mime_type": mime})
            self._log(f"Reference added: {name}")
        if files:
            self._refresh_ref_list()

    def _load_refs_from_dir(self):
        dirpath = filedialog.askdirectory(initialdir=str(SCRIPT_DIR / 'projects'))
        if dirpath:
            ref_dir = Path(dirpath) / 'ref' if (Path(dirpath) / 'ref').exists() else Path(dirpath)
            from modules.veononstop import _load_ref_images
            refs = _load_ref_images(str(ref_dir))
            if refs:
                self.reference_images = refs
                self._refresh_ref_list()
                self._log(f"Loaded {len(refs)} refs from {ref_dir}")
            else:
                messagebox.showwarning("Warning", f"No images found in {ref_dir}")

    def _clear_references(self):
        self.reference_images = []
        self._refresh_ref_list()

    def _refresh_ref_list(self):
        self.ref_veo_listbox.delete(0, tk.END)
        self.ref_count_label.config(text=f"Refs: ({len(self.reference_images)})")
        for ref in self.reference_images:
            self.ref_veo_listbox.insert(tk.END, ref['name'])
        self.ref_veo_listbox.config(height=max(3, min(len(self.reference_images), 6)))

    def _remove_selected_ref(self):
        sel = self.ref_veo_listbox.curselection()
        if sel:
            self.reference_images.pop(sel[0])
            self._refresh_ref_list()

    def _remove_ref(self, idx):
        self.reference_images.pop(idx)
        self._refresh_ref_list()

    def _rename_ref(self, idx):
        old_name = self.reference_images[idx]['name']
        new_name = simpledialog.askstring("Rename", "New name:", initialvalue=old_name)
        if new_name:
            self.reference_images[idx]['name'] = new_name
            self._refresh_ref_list()

    # ═══════════ PROMPTS ═══════════

    def _on_prompt_change(self, event=None):
        text = self.prompt_text.get("1.0", tk.END).strip()
        self.prompts_list = [l.strip() for l in text.split("\n") if l.strip()]
        self.prompts_count_label.config(text=f"{len(self.prompts_list)} prompts")

    def _load_prompts_file(self):
        fp = filedialog.askopenfilename(filetypes=[("Text", "*.txt")])
        if fp:
            with open(fp, 'r', encoding='utf-8') as f:
                self.prompt_text.delete("1.0", tk.END)
                self.prompt_text.insert("1.0", f.read())
            self._on_prompt_change()

    def _load_clipboard(self):
        try:
            text = self.root.clipboard_get()
            self.prompt_text.insert("1.0", text)
            self._on_prompt_change()
        except tk.TclError:
            pass

    def _clear_prompts(self):
        self.prompt_text.delete("1.0", tk.END)
        self.prompts_list = []
        self.prompts_count_label.config(text="0 prompts")

    # ═══════════ LOGGING ═══════════

    def _log(self, msg, level="INFO", tid=None):
        self.app.log(msg, level, tid, tab="veo")

    def _update_stats(self):
        with self.stats_lock:
            s, f = self.stats['success'], self.stats['failed']
            t = self.stats['total']
            done = s + f
        self.root.after(0, lambda: self.stats_success.config(text=f"OK: {s}"))
        self.root.after(0, lambda: self.stats_failed.config(text=f"Fail: {f}"))
        self.root.after(0, lambda: self.stats_progress.config(text=f"{done}/{t}"))
        if t > 0:
            self.root.after(0, lambda: self.progress_bar.config(value=(done / t) * 100))

    def _reset_stats(self):
        with self.stats_lock:
            self.stats = {"success": 0, "failed": 0, "total": 0}
        self._update_stats()
        self.progress_bar.config(value=0)

    def _reset_ui(self):
        self.generate_btn.config(state=tk.NORMAL)
        self.multithread_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        self.progress_bar.stop()
        self.active_threads_label.config(text="0 active")

    # ═══════════ API ═══════════

    def _get_headers(self):
        return {"X-API-Key": self.api_key.get().strip(), "Content-Type": "application/json"}

    def _toggle_key(self):
        self.api_entry.config(show="" if self.api_entry.cget('show') == '*' else "*")

    def check_account(self):
        key = self.api_key.get().strip()
        if not key:
            messagebox.showerror("Error", "Enter API key")
            return
        try:
            resp = requests.get(f"{BASE_URL}/account/info", headers=self._get_headers(), timeout=10)
            data = resp.json()
            if data.get("success"):
                info = data['data']
                plan = info.get('plan', '?')
                slots = info.get('concurrent_tasks', '?')
                expires = info.get('expires_at', '?')
                self.thread_count.set(min(int(slots) if isinstance(slots, int) else 4, self.max_threads))
                messagebox.showinfo("Account", f"Plan: {plan}\nSlots: {slots}\nExpires: {expires}")
            else:
                messagebox.showerror("Error", data.get("error", "Unknown"))
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def cancel_all(self):
        if not messagebox.askyesno("Cancel All", "Cancel all active tasks on server?"):
            return
        try:
            resp = requests.post(f"{BASE_URL}/video/cancel-all", headers=self._get_headers(), timeout=30)
            data = resp.json()
            cancelled = data.get("data", {}).get("cancelled_count", 0)
            self._log(f"Cancelled {cancelled} tasks", "SUCCESS")
        except Exception as e:
            self._log(f"Cancel error: {e}", "ERROR")

    # ═══════════ GENERATION ═══════════

    def start_generation(self):
        if self.is_generating:
            return
        key = self.api_key.get().strip()
        if not key:
            messagebox.showerror("Error", "Enter API key")
            return
        prompt = self.prompt_text.get("1.0", tk.END).strip()
        if not prompt:
            messagebox.showerror("Error", "Enter prompt")
            return
        first = prompt.split("\n")[0].strip()
        self.is_generating = True
        self.generate_btn.config(state=tk.DISABLED)
        self.multithread_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.progress_bar.config(mode='indeterminate')
        self.progress_bar.start()

        def worker():
            try:
                self._generate_single(first)
                self._log("Done!", "SUCCESS")
            except Exception as e:
                self._log(f"Error: {e}", "ERROR")
            finally:
                self.is_generating = False
                self.root.after(0, self._reset_ui)

        threading.Thread(target=worker, daemon=True).start()

    def start_multithread(self):
        if self.is_generating:
            return
        if not self.api_key.get().strip():
            messagebox.showerror("Error", "Enter API key")
            return
        self._on_prompt_change()
        tc = self.thread_count.get()

        # Batch Frame: итерируем по парам изображений, промпты цикличны
        if self.mode.get() == "video_batch":
            ns, ne = len(self.batch_start_images), len(self.batch_end_images)
            pc = min(ns, ne)
            if pc == 0:
                messagebox.showerror("Error", "Select start and end images")
                return
            if not self.prompts_list:
                messagebox.showerror("Error", "Enter at least one prompt")
                return
        else:
            if not self.prompts_list:
                messagebox.showerror("Error", "No prompts")
                return
            pc = len(self.prompts_list)
            if pc == 1:
                self.start_generation()
                return

        if not messagebox.askyesno("Confirm", f"Generate {pc} items with {tc} threads?"):
            return

        # Создаём папку проекта: veononstop_output/YYYYMMDD_HHMMSS[_name]/
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        name_part = self.project_name.get().strip()
        folder_name = f"{ts}_{name_part}" if name_part else ts
        # Очищаем от символов, недопустимых в именах папок
        folder_name = "".join(c for c in folder_name if c not in r'\/:*?"<>|')
        session_dir = get_output_dir() / folder_name
        session_dir.mkdir(parents=True, exist_ok=True)
        self.output_dir = session_dir

        self.is_generating = True
        self.generate_btn.config(state=tk.DISABLED)
        self.multithread_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.progress_bar.config(mode='determinate')
        self._reset_stats()
        with self.stats_lock:
            self.stats['total'] = pc
        self._update_stats()
        self._log(f"Output folder: {session_dir.name}", "INFO")

        threading.Thread(target=self._multithread_worker, daemon=True).start()

    def _multithread_worker(self):
        tc = self.thread_count.get()
        is_batch_frame = self.mode.get() == "video_batch"

        if is_batch_frame:
            # Итерируем по парам, промпты цикличны
            ns, ne = len(self.batch_start_images), len(self.batch_end_images)
            pairs = list(zip(self.batch_start_images[:min(ns, ne)],
                             self.batch_end_images[:min(ns, ne)]))
            prompts = self.prompts_list.copy()
            tasks = [(i, pairs[i][0], pairs[i][1], prompts[i % len(prompts)])
                     for i in range(len(pairs))]
            self._log(f"Batch Frame: {len(tasks)} pairs, {tc} threads", "INFO")
        else:
            prompts = self.prompts_list.copy()
            tasks = None
            self._log(f"Starting {len(prompts)} tasks with {tc} threads", "INFO")

        active = [0]
        active_lock = threading.Lock()

        def update_active(delta):
            with active_lock:
                active[0] += delta
                c = active[0]
            self.root.after(0, lambda: self.active_threads_label.config(text=f"{c} active"))

        def process(args):
            tid = threading.current_thread().name.split('_')[-1]
            if not self.is_generating:
                return False
            update_active(1)
            try:
                if is_batch_frame:
                    idx, s_img, e_img, prompt = args
                    self._log(f"Pair {idx+1}: {s_img['name']} → {e_img['name']}", "INFO", tid)
                    self._video_batch(prompt, tid, start_img=s_img, end_img=e_img)
                else:
                    idx, prompt = args
                    self._log(f"Start: {prompt[:40]}...", "INFO", tid)
                    self._generate_single(prompt, tid)
                with self.stats_lock:
                    self.stats['success'] += 1
                self._update_stats()
                return True
            except Exception as e:
                with self.stats_lock:
                    self.stats['failed'] += 1
                self._update_stats()
                self._log(f"Failed: {str(e)[:60]}", "ERROR", tid)
                return False
            finally:
                update_active(-1)

        if is_batch_frame:
            task_args = tasks
        else:
            task_args = [(i, p) for i, p in enumerate(prompts)]

        with ThreadPoolExecutor(max_workers=tc, thread_name_prefix="Gen") as exe:
            futures = {exe.submit(process, a): a for a in task_args}
            for f in as_completed(futures):
                if not self.is_generating:
                    exe.shutdown(wait=False, cancel_futures=True)
                    break

        with self.stats_lock:
            s, f, t = self.stats['success'], self.stats['failed'], self.stats['total']
        self._log(f"Done: {s} ok, {f} failed, {t} total", "SUCCESS")
        self.is_generating = False
        self.root.after(0, self._reset_ui)

    def _generate_single(self, prompt, tid=None):
        mode = self.mode.get()
        if mode == "video_t2v":
            self._video_t2v(prompt, tid)
        elif mode == "video_i2v":
            self._video_i2v(prompt, tid)
        elif mode == "video_multi":
            self._video_multi(prompt, tid)
        elif mode == "video_batch":
            self._video_batch(prompt, tid)
        elif mode == "image_banana":
            self._image_banana(prompt, tid)
        elif mode == "image_imagen":
            self._image_imagen(prompt, tid)

    def stop_generation(self):
        self.is_generating = False
        self._log("Stopping...", "WARNING")
        self._reset_ui()

    # ═══════════ VIDEO MODES ═══════════

    def _video_t2v(self, prompt, tid=None):
        self._log("Text to Video...", "INFO", tid)
        payload = {"prompt": prompt, "aspect_ratio": self.aspect_ratio.get(),
                   "count": self.generation_count.get()}
        self._submit_video("/video/text-to-video", payload, tid)

    def _video_i2v(self, prompt, tid=None):
        if not self.single_image:
            raise Exception("Select image first")
        img_list = getattr(self, 'single_image_list', None)
        if img_list and len(img_list) > 1:
            self._log(f"Batch i2v: {len(img_list)} images...", "INFO", tid)
            for i, img in enumerate(img_list):
                self._log(f"  i2v [{i+1}/{len(img_list)}] {img.get('name', '')}...", "INFO", tid)
                payload = {"prompt": prompt, "image_base64": img["image_base64"],
                           "mime_type": img["mime_type"],
                           "aspect_ratio": self.aspect_ratio.get(), "count": self.generation_count.get()}
                self._submit_video("/video/image-to-video", payload, tid)
        else:
            self._log("Image to Video...", "INFO", tid)
            payload = {"prompt": prompt, "image_base64": self.single_image["image_base64"],
                       "mime_type": self.single_image["mime_type"],
                       "aspect_ratio": self.aspect_ratio.get(), "count": self.generation_count.get()}
            self._submit_video("/video/image-to-video", payload, tid)

    def _video_multi(self, prompt, tid=None):
        if not self.video_images:
            raise Exception("Add images first")
        self._log(f"Multi-Image ({len(self.video_images)})...", "INFO", tid)
        payload = {"prompt": prompt, "images": self.video_images,
                   "aspect_ratio": self.aspect_ratio.get(), "count": self.generation_count.get()}
        self._submit_video("/video/multi-image-to-video", payload, tid)

    def _video_batch(self, prompt, tid=None, start_img=None, end_img=None):
        s = start_img or (self.batch_start_images[0] if self.batch_start_images else None)
        e = end_img or (self.batch_end_images[0] if self.batch_end_images else None)
        if not s or not e:
            raise Exception("Select start and end images")
        self._log(f"Batch Frame: {s['name']} → {e['name']}", "INFO", tid)
        payload = {"prompt": prompt, "start_image_base64": s["image_base64"],
                   "end_image_base64": e["image_base64"],
                   "aspect_ratio": self.aspect_ratio.get(), "count": self.generation_count.get()}
        self._submit_video("/video/batch-frame", payload, tid)

    def _submit_video(self, endpoint, payload, tid=None):
        resp = requests.post(f"{BASE_URL}{endpoint}", json=payload,
                             headers=self._get_headers(), timeout=REQUEST_TIMEOUT)
        data = resp.json()
        if not data.get("success"):
            raise Exception(data.get("error", "Unknown error"))
        task_id = data.get("data", {}).get("task_id")
        if not task_id:
            raise Exception("No task_id")
        self._log(f"Task: {task_id[:20]}...", "SUCCESS", tid)
        self._poll_video(task_id, tid)

    def _poll_video(self, task_id, tid=None):
        while self.is_generating:
            try:
                resp = requests.get(f"{BASE_URL}/video/status/{task_id}",
                                    headers=self._get_headers(), timeout=30)
                result = resp.json().get("data", {})
                status = result.get("status", "unknown")
                if status == "completed":
                    self.last_video_result = result
                    self._download_videos(result, tid)
                    return
                elif status in ("failed", "error"):
                    raise Exception(result.get("error", "Failed"))
                time.sleep(VIDEO_POLL_INTERVAL)
            except Exception as e:
                if "failed" in str(e).lower():
                    raise
                time.sleep(VIDEO_POLL_INTERVAL)

    def _download_videos(self, result, tid=None):
        videos = result.get("videos", [])
        self.output_dir.mkdir(parents=True, exist_ok=True)
        for i, v in enumerate(videos):
            url = v.get("fifeUrl")
            if url:
                try:
                    r = requests.get(url, timeout=120)
                    fn = self.output_dir / f"video_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}_{i+1}.mp4"
                    fn.write_bytes(r.content)
                    self._log(f"Saved: {fn.name}", "SUCCESS", tid)
                except Exception as e:
                    self._log(f"Download error: {e}", "ERROR", tid)

    # ═══════════ IMAGE MODES ═══════════

    def _image_banana(self, prompt, tid=None):
        display = self.model_key.get()
        api_key = BANANA_NAME_TO_KEY.get(display, display)
        self._log(f"Banana ({display})...", "INFO", tid)
        payload = {"prompt": prompt, "aspect_ratio": self.aspect_ratio.get(),
                   "num_images": self.generation_count.get(), "model_key": api_key}
        if self.reference_images:
            payload["reference_images"] = self.reference_images
        resp = requests.post(f"{BASE_URL}/image/banana/generate", json=payload,
                             headers=self._get_headers(), timeout=REQUEST_TIMEOUT)
        data = resp.json()
        if not data.get("success"):
            raise Exception(data.get("error", "Unknown error"))
        media = data.get("data", {}).get("media", [])
        self.output_dir.mkdir(parents=True, exist_ok=True)
        for i, m in enumerate(media):
            url = m.get("fifeUrl")
            if url:
                try:
                    r = requests.get(url, timeout=60)
                    fn = self.output_dir / f"banana_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}_{i+1}.png"
                    fn.write_bytes(r.content)
                    self._log(f"Saved: {fn.name}", "SUCCESS", tid)
                except Exception as e:
                    self._log(f"Error: {e}", "ERROR", tid)

    def _image_imagen(self, prompt, tid=None):
        self._log("IMAGEN 3.5...", "INFO", tid)
        payload = {"prompt": prompt, "aspect_ratio": self.aspect_ratio.get()}
        resp = requests.post(f"{BASE_URL}/image/generate", json=payload,
                             headers=self._get_headers(), timeout=REQUEST_TIMEOUT)
        data = resp.json()
        if not data.get("success"):
            raise Exception(data.get("error", "Unknown error"))
        media_id = data.get("data", {}).get("mediaGenerationId")
        if media_id:
            self._log(f"ID: {media_id[:30]}...", "SUCCESS", tid)

    # ═══════════ UPSAMPLE ═══════════

    def upsample_video(self):
        if not self.last_video_result:
            messagebox.showwarning("Warning", "Generate video first")
            return
        videos = self.last_video_result.get("videos", [])
        if not videos:
            return
        media_id = videos[0].get("mediaGenerationId")
        if not media_id:
            messagebox.showerror("Error", "No mediaGenerationId")
            return
        self.is_generating = True
        self.generate_btn.config(state=tk.DISABLED)
        self.progress_bar.config(mode='indeterminate')
        self.progress_bar.start()

        def do_upsample():
            try:
                self._log("Upsampling to 4K...", "INFO")
                payload = {"media_generation_id": media_id, "aspect_ratio": self.aspect_ratio.get()}
                resp = requests.post(f"{BASE_URL}/video/upsample", json=payload,
                                     headers=self._get_headers(), timeout=REQUEST_TIMEOUT)
                data = resp.json()
                if data.get("success"):
                    tid = data.get("data", {}).get("task_id")
                    self._poll_video(tid)
                    self._log("Upsample done!", "SUCCESS")
                else:
                    raise Exception(data.get("error", "Failed"))
            except Exception as e:
                self._log(f"Upsample error: {e}", "ERROR")
            finally:
                self.is_generating = False
                self.root.after(0, self._reset_ui)

        threading.Thread(target=do_upsample, daemon=True).start()


# ════════════════════════════════════════════════════════════════════
# TAB: DONATE
# ════════════════════════════════════════════════════════════════════

class DonateTab:
    def __init__(self, notebook, app: 'VarAgentGUI'):
        self.app = app
        self.frame = ttk.Frame(notebook)
        self._build()

    def _build(self):
        outer = ttk.Frame(self.frame)
        outer.pack(expand=True)  # center vertically

        card = ttk.Frame(outer, style="Card.TFrame", padding=32)
        card.pack(padx=40, pady=40)

        # Header text
        lines = [
            "Пока Вар ещё на пути к первым миллионам на YouTube,",
            "вы можете сказать спасибо Вару,",
            "если программа оказалась вам полезной,",
            "по реквизитам ниже:",
        ]
        for line in lines:
            ttk.Label(card, text=line, style="Card.TLabel",
                      font=("Segoe UI", 11)).pack(anchor=tk.W, pady=1)

        ttk.Separator(card, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=16)

        def _card_row(icon, label, action_text, action):
            row = ttk.Frame(card, style="Card.TFrame")
            row.pack(fill=tk.X, pady=6)
            ttk.Label(row, text=icon, font=("Segoe UI", 16), style="Card.TLabel").pack(side=tk.LEFT, padx=(0, 10))
            ttk.Label(row, text=label, style="Card.TLabel",
                      font=("Segoe UI", 12)).pack(side=tk.LEFT, expand=True, anchor=tk.W)
            btn = ttk.Button(row, text=action_text, command=action)
            btn.pack(side=tk.RIGHT, padx=(12, 0))

        CARD_NUM = "5599002019861089"
        def _copy_card():
            self.frame.clipboard_clear()
            self.frame.clipboard_append(CARD_NUM)
            self.frame.update()

        def _open(url):
            import webbrowser
            webbrowser.open(url)

        _card_row("\u20BD", f"Карта  {CARD_NUM}", "Скопировать", _copy_card)
        _card_row("\u20BD", "ЮMoney", "Открыть",
                  lambda: _open("https://yoomoney.ru/to/410017958835828"))
        _card_row("$ \u20AC \u20BF", "DeStream (USD / EUR / BTC)",
                  "Открыть", lambda: _open("https://destream.net/live/VARGART/don"))

        ttk.Separator(card, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=16)

        # ── Обновления ──────────────────────────────────────────────
        upd_row = ttk.Frame(card, style="Card.TFrame")
        upd_row.pack(fill=tk.X, pady=6)
        ttk.Label(upd_row, text="↑", font=("Segoe UI", 16), style="Card.TLabel").pack(side=tk.LEFT, padx=(0, 10))
        self._upd_label = ttk.Label(upd_row, text="Обновления программы", style="Card.TLabel", font=("Segoe UI", 12))
        self._upd_label.pack(side=tk.LEFT, expand=True, anchor=tk.W)
        ttk.Button(upd_row, text="Перезапустить",
                   command=self._restart).pack(side=tk.RIGHT, padx=(4, 0))
        self._upd_btn = ttk.Button(upd_row, text="Проверить", command=self._check_updates)
        self._upd_btn.pack(side=tk.RIGHT, padx=(12, 0))

        ttk.Separator(card, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=16)

        _card_row("\u2708", "Написать Вару",
                  "Telegram", lambda: _open("https://t.me/vargartor"))

    def _restart(self):
        import subprocess
        subprocess.Popen([sys.executable] + sys.argv)
        self.app.root.destroy()

    def _check_updates(self):
        self._upd_btn.config(state='disabled', text='Проверка...')
        self._upd_label.config(text='Проверка обновлений...')

        def _do():
            try:
                import importlib, modules.updater as _mu
                importlib.reload(_mu)
                return _mu.check_updates(SCRIPT_DIR)
            except Exception as e:
                return {'available': False, 'error': str(e)}

        def _done(result):
            self._upd_btn.config(state='normal', text='Проверить')
            if result.get('error'):
                self._upd_label.config(text=f"Ошибка: {result['error']}")
                return
            if not result['available']:
                self._upd_label.config(text="Обновлений нет — у вас актуальная версия")
                return
            changelog = result.get('changelog', [])
            n = len(result.get('changed_files', []))
            self._upd_label.config(text=f"Доступно обновление v{result['version']} ({n} файлов)")
            msg = "Доступно обновление!\n\n"
            msg += "\n".join(f"• {c}" for c in changelog)
            msg += f"\n\nИзменено файлов: {n}"
            msg += "\n\nУстановить?"
            if messagebox.askyesno("Обновление VarAgent", msg):
                self._install_updates()

        import threading
        threading.Thread(target=lambda: self.frame.after(0, _done, _do()), daemon=True).start()

    def _install_updates(self):
        self._upd_btn.config(state='disabled', text='Установка...')
        self._upd_label.config(text='Установка обновления...')

        def _do():
            try:
                import importlib, modules.updater as _mu
                importlib.reload(_mu)
                return _mu.install_update(SCRIPT_DIR, progress_cb=lambda m: self.app.log(m, tab='pipeline'))
            except Exception as e:
                return {'ok': False, 'error': str(e)}

        def _done(result):
            self._upd_btn.config(state='normal', text='Проверить')
            if result.get('ok'):
                n = len(result.get('installed', []))
                needs_restart = result.get('requires_restart', False)
                if needs_restart:
                    self._upd_label.config(text=f"Установлено ({n} файлов). Перезапустите программу.")
                    messagebox.showinfo("Обновление установлено",
                        f"Установлено файлов: {n}\n\nПерезапустите VarAgent для применения изменений.")
                else:
                    self._upd_label.config(text=f"Установлено ({n} файлов). Готово.")
                    messagebox.showinfo("Обновление установлено",
                        f"Установлено файлов: {n}\n\nОбновление применено, перезапуск не нужен.")
            else:
                self._upd_label.config(text=f"Ошибка установки: {result['error']}")
                messagebox.showerror("Ошибка обновления", result['error'])

        import threading
        threading.Thread(target=lambda: self.frame.after(0, _done, _do()), daemon=True).start()


# ════════════════════════════════════════════════════════════════════
# TAB 7: BRAINSTORM  (YouTube channel transcription)
# ════════════════════════════════════════════════════════════════════

class BrainstormTab:
    """YouTube channel subtitle downloader + script builder via AssemblyAI."""

    SORT_OPTIONS = ["latest", "popular", "oldest", "random"]
    SORT_LABELS  = ["Свежие", "Популярные", "Старые", "Случайные"]

    def __init__(self, notebook, app: 'VarAgentGUI'):
        self.app  = app
        self.frame = ttk.Frame(notebook)
        self._stop_event = threading.Event()
        self._running    = False
        self._build()

    # ── UI ───────────────────────────────────────────────────────────────

    def _build(self):
        outer = ttk.Frame(self.frame)
        outer.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

        # ── TOP: controls card ────────────────────────────────────────
        top_card = ttk.Frame(outer, style="Card.TFrame", padding=14)
        top_card.pack(fill=tk.X, pady=(0, 6))

        # Row 1 — channel URL
        r1 = ttk.Frame(top_card, style="Card.TFrame")
        r1.pack(fill=tk.X, pady=3)
        ttk.Label(r1, text="Канал YouTube:", style="Card.TLabel", width=16).pack(side=tk.LEFT)
        self._channel_var = tk.StringVar(value="https://www.youtube.com/@/videos")
        ttk.Entry(r1, textvariable=self._channel_var, width=60).pack(side=tk.LEFT, padx=(4, 0), fill=tk.X, expand=True)

        # Row 2 — sort + max videos + output folder
        r2 = ttk.Frame(top_card, style="Card.TFrame")
        r2.pack(fill=tk.X, pady=3)

        ttk.Label(r2, text="Сортировка:", style="Card.TLabel", width=16).pack(side=tk.LEFT)
        self._sort_var = tk.StringVar(value="Свежие")
        sort_cb = ttk.Combobox(r2, textvariable=self._sort_var,
                               values=self.SORT_LABELS, width=12, state="readonly")
        sort_cb.pack(side=tk.LEFT, padx=(4, 16))

        ttk.Label(r2, text="Макс. видео:", style="Card.TLabel").pack(side=tk.LEFT)
        self._max_var = tk.StringVar(value="0")
        max_e = ttk.Entry(r2, textvariable=self._max_var, width=6)
        max_e.pack(side=tk.LEFT, padx=(4, 4))
        ttk.Label(r2, text="(0 = все)", style="Dim.TLabel").pack(side=tk.LEFT, padx=(0, 16))

        # Row 3 — output directory
        r3 = ttk.Frame(top_card, style="Card.TFrame")
        r3.pack(fill=tk.X, pady=3)
        ttk.Label(r3, text="Папка вывода:", style="Card.TLabel", width=16).pack(side=tk.LEFT)
        default_out = str(SCRIPT_DIR / "projects" / "yt_subs")
        self._out_var = tk.StringVar(value=default_out)
        ttk.Entry(r3, textvariable=self._out_var, width=55).pack(side=tk.LEFT, padx=(4, 4), fill=tk.X, expand=True)
        ttk.Button(r3, text="Add",
                   command=lambda: self._out_var.set(
                       filedialog.askdirectory(title="Выберите папку для субтитров") or self._out_var.get()
                   )).pack(side=tk.LEFT, padx=4)

        # Row 4 — yt-dlp path (optional)
        r4 = ttk.Frame(top_card, style="Card.TFrame")
        r4.pack(fill=tk.X, pady=3)
        ttk.Label(r4, text="yt-dlp путь:", style="Card.TLabel", width=16).pack(side=tk.LEFT)
        self._ytdlp_var = tk.StringVar(value="")
        ttk.Entry(r4, textvariable=self._ytdlp_var, width=40).pack(side=tk.LEFT, padx=(4, 4))
        ttk.Label(r4, text="(пусто = авто)", style="Dim.TLabel").pack(side=tk.LEFT, padx=(0, 16))
        ttk.Button(r4, text="Add",
                   command=lambda: self._ytdlp_var.set(
                       filedialog.askopenfilename(
                           title="Выберите yt-dlp",
                           filetypes=[("yt-dlp", "yt-dlp.exe yt-dlp"), ("All", "*.*")]
                       ) or self._ytdlp_var.get()
                   )).pack(side=tk.LEFT, padx=4)

        # Row 5 — subtitle download options
        r5 = ttk.Frame(top_card, style="Card.TFrame")
        r5.pack(fill=tk.X, pady=3)
        self._try_subs_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(r5, text="Сначала скачать субтитры (без AssemblyAI)",
                        variable=self._try_subs_var, style="Card.TCheckbutton").pack(side=tk.LEFT)
        ttk.Label(r5, text="Язык:", style="Card.TLabel").pack(side=tk.LEFT, padx=(16, 0))
        self._subs_lang_var = tk.StringVar(value="ru")
        ttk.Combobox(r5, textvariable=self._subs_lang_var,
                     values=["ru", "en", "es", "fr", "de", "it", "pt", "pl", "ja", "zh", "ko", "ar", "hi"],
                     width=5, state="readonly").pack(side=tk.LEFT, padx=4)
        ttk.Label(r5, text="Режим:", style="Card.TLabel").pack(side=tk.LEFT, padx=(16, 0))
        self._subs_segmode_var = tk.StringVar(value="sentences")
        ttk.Combobox(r5, textvariable=self._subs_segmode_var,
                     values=["words", "sentences", "paragraphs"],
                     width=11, state="readonly").pack(side=tk.LEFT, padx=4)

        # ── Action buttons (TOP RIGHT area) ──────────────────────────
        btn_row = ttk.Frame(top_card, style="Card.TFrame")
        btn_row.pack(fill=tk.X, pady=(10, 0))

        self._run_btn = ttk.Button(btn_row, text="▶  Скачать субтитры",
                                   style="Accent.TButton", command=self._start)
        self._run_btn.pack(side=tk.LEFT, padx=(0, 8))

        self._stop_btn = ttk.Button(btn_row, text="■  Стоп", command=self._stop,
                                    state="disabled")
        self._stop_btn.pack(side=tk.LEFT, padx=(0, 16))

        self._open_btn = ttk.Button(btn_row, text="Открыть папку",
                                    command=self._open_out_dir)
        self._open_btn.pack(side=tk.LEFT)

        self._status_lbl = ttk.Label(btn_row, text="", style="Dim.TLabel")
        self._status_lbl.pack(side=tk.RIGHT, padx=8)

        # ── Progress bar ──────────────────────────────────────────────
        self._progress = ttk.Progressbar(outer, style="Green.Horizontal.TProgressbar",
                                         mode="determinate", length=400)
        self._progress.pack(fill=tk.X, pady=(0, 4))

        # ── Log ───────────────────────────────────────────────────────
        log_card = ttk.Frame(outer, style="Card.TFrame", padding=10)
        log_card.pack(fill=tk.BOTH, expand=True)
        ttk.Label(log_card, text="Log", style="Section.TLabel").pack(anchor=tk.W)
        self.log_widget = self.app.create_log_widget(log_card)

    # ── Helpers ──────────────────────────────────────────────────────────

    def _log(self, msg: str, level: str = "INFO"):
        self.app.log(msg, level, tab="brainstorm")

    def _set_status(self, txt: str):
        self.frame.after(0, lambda: self._status_lbl.config(text=txt))

    def _set_progress(self, val: float, maximum: float = 100.0):
        self.frame.after(0, lambda: (
            self._progress.config(maximum=max(1, maximum), value=val)
        ))

    def _open_out_dir(self):
        p = self._out_var.get()
        if p and Path(p).exists():
            if sys.platform == "win32":
                os.startfile(p)
            else:
                subprocess.Popen(["open" if sys.platform == "darwin" else "xdg-open", p])

    # ── Run ──────────────────────────────────────────────────────────────

    def _start(self):
        if self._running:
            return

        channel = self._channel_var.get().strip()
        if not channel or channel == "https://www.youtube.com/@/videos":
            messagebox.showwarning("Brainstorm", "Введите URL канала YouTube")
            return

        out_dir = self._out_var.get().strip()
        if not out_dir:
            messagebox.showwarning("Brainstorm", "Укажите папку вывода")
            return

        try:
            max_v = int(self._max_var.get() or "0")
        except ValueError:
            max_v = 0

        sort_label = self._sort_var.get()
        try:
            sort_mode = self.SORT_OPTIONS[self.SORT_LABELS.index(sort_label)]
        except (ValueError, IndexError):
            sort_mode = "latest"

        ytdlp_path = self._ytdlp_var.get().strip() or None

        self._running = True
        self._stop_event.clear()
        self._run_btn.config(state="disabled")
        self._stop_btn.config(state="normal")
        self._set_status("Запущено...")
        self._set_progress(0)
        self.log_widget.delete("1.0", tk.END)

        def _worker():
            try:
                from modules.yt_transcriber import run_channel_transcription

                total_known = [0]

                def _cb(msg: str, level: str = "INFO"):
                    self._log(msg, level)
                    # parse progress from "Транскрибируем N видео"
                    if msg.startswith("Транскрибируем"):
                        import re as _re
                        m = _re.search(r"(\d+) видео", msg)
                        if m:
                            total_known[0] = int(m.group(1))
                    # parse "[i/N]" lines
                    m2 = __import__('re').match(r"\[(\d+)/(\d+)\]", msg.strip())
                    if m2:
                        cur, tot = int(m2.group(1)), int(m2.group(2))
                        total_known[0] = tot
                        self._set_progress(cur - 1, tot)
                        self._set_status(f"{cur}/{tot}")

                result = run_channel_transcription(
                    channel_url=channel,
                    out_dir=Path(out_dir),
                    max_videos=max_v,
                    sort_mode=sort_mode,
                    ytdlp_path=ytdlp_path,
                    progress_cb=_cb,
                    stop_event=self._stop_event,
                    try_subs_first=self._try_subs_var.get(),
                    subs_lang=self._subs_lang_var.get(),
                    seg_mode=self._subs_segmode_var.get(),
                )
                done, total = result["done"], result["total"]
                self._set_progress(total, total)
                self._set_status(f"Готово: {done}/{total}")
                self._log(f"Результат в: {result['srt_dir']}", "SUCCESS")

            except Exception as e:
                self._log(f"FATAL: {e}", "ERROR")
                self._set_status(f"Ошибка: {e}")
            finally:
                self._running = False
                self.frame.after(0, lambda: (
                    self._run_btn.config(state="normal"),
                    self._stop_btn.config(state="disabled"),
                ))

        threading.Thread(target=_worker, daemon=True).start()

    def _stop(self):
        self._stop_event.set()
        self._set_status("Остановка...")
        self._log("Запрошена остановка...", "WARNING")


# ════════════════════════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════════════════════════

def main():
    root = tk.Tk()
    app = VarAgentGUI(root)
    root.mainloop()


if __name__ == '__main__':
    main()
