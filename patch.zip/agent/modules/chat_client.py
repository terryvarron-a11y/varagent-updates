"""
Chat client — прямой HTTP-транспорт к OpenAI-совместимым chat/completions API.

Общий транспорт для chat_director.py (режиссёр) и gemini_rewrite.py (rewrite).
Провайдеры: deepseek, openrouter. БЕЗ Codex и Moon Bridge — модель просто
отвечает текстом, никакого агентского поведения / записи файлов.

Доказано тестами (см. reference_chat_director_api): прямой API обоих провайдеров
возвращает чистый JSON, в отличие от Codex-агента, который на больших проектах
писал Python-скрипты вместо ответа.
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Optional

import requests

import config


# Эндпоинты провайдеров (OpenAI-совместимый chat/completions)
def _claude_api_endpoint() -> str:
    """Claude API (reseller codexhub и совместимые) в OpenAI-формате → /chat/completions."""
    base = str(getattr(config, 'CLAUDE_API_BASE', 'https://api.codexhub.click/v1') or '').strip().rstrip('/')
    if not base.endswith('/chat/completions'):
        base += '/chat/completions'
    return base


_ENDPOINTS = {
    'deepseek': 'https://api.deepseek.com/chat/completions',
    'openrouter': 'https://openrouter.ai/api/v1/chat/completions',
    # CLIProxyAPI — локальный прокси к Gemini Pro (Antigravity OAuth). OpenAI-совместимый.
    'cliproxy': getattr(config, 'CLIPROXY_BASE_URL', 'http://localhost:8317/v1/chat/completions'),
    # Claude API через reseller (codexhub) — OpenAI-совместимый формат (CLAUDE_API_FORMAT=openai).
    # Нативный api.anthropic.com (/v1/messages) здесь НЕ поддерживается — только OpenAI-совместимый.
    'claude_api': _claude_api_endpoint(),
}


# ── cliproxy round-robin по инстансам аккаунтов (Plan Б) ──────────────────────
# Если в реестре есть живые per-account инстансы — раскидываем запросы по ним
# (изоляция акк↔прокси + суммирование квоты). Иначе — легаси одиночный :8317.
_cliproxy_rr_lock = threading.Lock()
_cliproxy_rr_i = 0


def _cliproxy_endpoints() -> list:
    """Base chat/completions URL'ы cliproxy: живые инстансы аккаунтов или легаси :8317."""
    try:
        from modules import cliproxy_mgr as _m
        ports = _m.running_account_ports()
        if ports:
            return [f'http://127.0.0.1:{p}/v1/chat/completions' for p in ports]
    except Exception:
        pass
    return [_ENDPOINTS['cliproxy']]


def _next_cliproxy_url(endpoints: list) -> str:
    """Следующий endpoint по кругу (thread-safe — Pass2 параллелит запросы)."""
    global _cliproxy_rr_i
    with _cliproxy_rr_lock:
        u = endpoints[_cliproxy_rr_i % len(endpoints)]
        _cliproxy_rr_i += 1
    return u


def _api_key(provider: str) -> str:
    if provider == 'deepseek':
        return getattr(config, 'DEEPSEEK_API_KEY', '') or ''
    if provider == 'openrouter':
        return getattr(config, 'OPENROUTER_API_KEY', '') or ''
    if provider == 'cliproxy':
        return getattr(config, 'CLIPROXY_API_KEY', '') or ''
    if provider == 'claude_api':
        return getattr(config, 'CLAUDE_API_KEY', '') or ''
    return ''


def _resolve_model(provider: str, model: str, web: bool) -> str:
    """OpenRouter web search = суффикс ':online' к модели. DeepSeek — без изменений."""
    model = (model or '').strip()
    if provider == 'openrouter' and web and not model.endswith(':online'):
        return f'{model}:online'
    return model


class ChatError(Exception):
    """Ошибка chat-запроса (после исчерпания ретраев или фатальная)."""


def chat_completion(
    provider: str,
    model: str,
    messages: list,
    *,
    max_tokens: Optional[int] = None,
    reasoning_level: Optional[str] = None,
    web: bool = False,
    json_mode: bool = False,
    timeout: int = 300,
    max_retries: int = 4,
) -> str:
    """Один запрос к chat/completions провайдера. Возвращает текст ответа (content).

    Args:
        provider: 'deepseek' | 'openrouter'
        model: имя модели (slug). Для openrouter web=True → добавит ':online'.
        messages: список сообщений [{role, content}, ...]
        max_tokens: лимит output-токенов. None (дефолт) → не ограничиваем,
                    провайдер отдаёт свой максимум (обрезки ловит валидатор).
        reasoning_level: off|low|medium|high|max (дефолт config.CHAT_REASONING_LEVEL).
                         Маппится в нативные параметры провайдера.
        web: OpenRouter — web search через ':online'. DeepSeek игнорирует.
        json_mode: True → response_format json_object (строгий JSON-вывод).
        timeout: таймаут запроса в секундах.
        max_retries: ретраи на 429/5xx с экспоненциальным backoff.

    Returns:
        content финального сообщения (str). Reasoning/COT отбрасывается.

    Raises:
        ChatError: если ключ не задан, провайдер неизвестен или все ретраи исчерпаны.
    """
    provider = (provider or '').strip().lower()
    if provider not in _ENDPOINTS:
        raise ChatError(f"Неизвестный chat-провайдер: {provider}")

    key = _api_key(provider)
    if not key:
        raise ChatError(f"{provider}: API ключ не задан")

    real_model = _resolve_model(provider, model, web)

    body = {
        'model': real_model,
        'messages': messages,
        'stream': False,
    }
    # max_tokens=None → не ограничиваем вывод (провайдер отдаёт свой максимум).
    # Обрезанный план/промпт ловит валидатор и перезапрашивает недостающее.
    if max_tokens is not None:
        body['max_tokens'] = max_tokens
    if json_mode:
        body['response_format'] = {'type': 'json_object'}

    # Reasoning-параметры (нативные для провайдера). DeepSeek кладёт thinking в
    # top-level (не extra_body — мы шлём сырой JSON, а не через OpenAI SDK).
    rp = config.reasoning_params_for_provider(provider, reasoning_level)
    body.update(rp)

    headers = {
        'Authorization': f'Bearer {key}',
        'Content-Type': 'application/json',
    }
    if provider == 'openrouter':
        # OpenRouter рекомендует (опционально) для атрибуции; не критично
        headers['HTTP-Referer'] = 'https://varagent.local'
        headers['X-Title'] = 'VARAGENT'

    # cliproxy → список инстансов аккаунтов (round-robin по попыткам); иначе один URL.
    _cp_eps = _cliproxy_endpoints() if provider == 'cliproxy' else None
    url = None if provider == 'cliproxy' else _ENDPOINTS[provider]
    # localhost-прокси не нужен (внешние хосты) — но уважаем system proxy если задан
    last_err = None
    for attempt in range(1, max_retries + 1):
        if provider == 'cliproxy':
            url = _next_cliproxy_url(_cp_eps)  # ротация: 429/дохлый инстанс → следующий акк
        try:
            resp = requests.post(url, headers=headers, json=body, timeout=timeout)
        except requests.RequestException as e:
            last_err = f"network: {e}"
            _backoff(attempt, last_err)
            continue

        if resp.status_code == 200:
            try:
                data = resp.json()
            except ValueError as e:
                raise ChatError(f"{provider}: невалидный JSON-ответ: {e}; body={resp.text[:300]}")
            return _extract_content(data)

        # 429 / 5xx — ретраим с backoff
        if resp.status_code == 429 or resp.status_code >= 500:
            last_err = f"HTTP {resp.status_code}: {resp.text[:200]}"
            _backoff(attempt, last_err, retry_after=resp.headers.get('Retry-After'))
            continue

        # 4xx (кроме 429) — фатально, не ретраим
        raise ChatError(f"{provider} HTTP {resp.status_code}: {resp.text[:400]}")

    raise ChatError(f"{provider}: исчерпаны {max_retries} ретраев. Последняя ошибка: {last_err}")


def _backoff(attempt: int, err: str, retry_after: Optional[str] = None):
    """Экспоненциальный backoff между ретраями. Уважает Retry-After если задан."""
    if retry_after:
        try:
            delay = min(float(retry_after), 60.0)
        except (ValueError, TypeError):
            delay = min(2 ** attempt, 30)
    else:
        delay = min(2 ** attempt, 30)  # 2,4,8,16,30...
    logging.warning(f"chat_completion retry {attempt}: {err} — sleep {delay:.0f}s")
    time.sleep(delay)


def _extract_content(data: dict) -> str:
    """Достаёт content из chat/completions ответа. Reasoning/COT игнорируется."""
    choices = data.get('choices') or []
    if not choices:
        raise ChatError(f"ответ без choices: {str(data)[:300]}")
    msg = choices[0].get('message') or {}
    content = msg.get('content')
    if content is None:
        # Некоторые провайдеры могут вернуть reasoning без content при обрыве
        finish = choices[0].get('finish_reason', '?')
        raise ChatError(f"пустой content (finish_reason={finish}): {str(msg)[:200]}")
    return content.strip()
