#!/bin/bash
# START_DIRECTOR.COMMAND - Director without transcription (macOS - double click)
# Run: double-click this file in Finder
# Use if Stage 1 broke after transcription

PROJECT_NAME="{project_name}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
AGENT_DIR="$(cd "$SCRIPT_DIR/../../agent" && pwd)"

# Auto-set execute permissions
chmod +x *.command *.sh 2>/dev/null
[ -f "$SCRIPT_DIR/.venv/bin/activate" ] && source "$SCRIPT_DIR/.venv/bin/activate"

# Open Terminal.app for interactive mode
if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e "tell app \"Terminal\" to do script \"cd '$SCRIPT_DIR' && exec '$0'\""
    exit 0
fi

clear

echo ""
echo "================================================================================"
echo " DIRECTOR ONLY: $PROJECT_NAME"
echo " Use if Stage 1 broke after transcription"
echo "================================================================================"
echo ""

# Check transcription.json
if [ ! -f "$SCRIPT_DIR/transcription.json" ]; then
    echo "[ERROR] transcription.json not found in project folder!"
    echo "Run Stage 1 first."
    echo "Press Enter to exit..."
    read
    exit 1
fi

# Find style guide file
STYLE_FILE=""
for F in "$SCRIPT_DIR"/*_style_*.txt; do
    [ -f "$F" ] && STYLE_FILE="$F" && break
done

if [ -z "$STYLE_FILE" ]; then
    echo "[ERROR] Style guide file not found: *_style_*.txt"
    echo "Press Enter to exit..."
    read
    exit 1
fi

echo "   Project:  $PROJECT_NAME"
echo "   Style:    $STYLE_FILE"
echo "   Trans:    $SCRIPT_DIR/transcription.json"
echo ""

# Mode selection
echo " Select mode:"
echo "   [1] Full director - pass 1 + pass 2"
echo "   [2] Two-pass      - pass 1 JSON plan + pass 2 prompts"
echo "   [3] Prompts only  - pass 2 only, use existing montage_plan.json"
echo ""
MODE_ARG=""
RESUME_ARG=""
echo -n "  Mode [1/2/3] (Enter = 1): "
read MODE_CHOICE
case "$MODE_CHOICE" in
    2) MODE_ARG="--two-pass" ;;
    3) MODE_ARG="--prompts-only" ;;
esac
echo ""

# Mode 3: check for existing prompts file and offer resume
if [ "$MODE_ARG" = "--prompts-only" ]; then
    FOUND_PROMPTS=""
    for F in "$SCRIPT_DIR"/*_prompts_*.txt; do
        [ -f "$F" ] && FOUND_PROMPTS="$F" && break
    done
    if [ -n "$FOUND_PROMPTS" ]; then
        echo " Found existing prompts file:"
        echo "   $(basename "$FOUND_PROMPTS")"
        echo ""
        echo " Continue from where left off?"
        echo "   [1] Yes - append missing prompts (resume)"
        echo "   [2] No  - start fresh (new file)"
        echo ""
        echo -n "  [1/2] (Enter = 1 resume): "
        read RESUME_CHOICE
        if [ "$RESUME_CHOICE" != "2" ]; then
            RESUME_ARG="--resume"
            echo "   Resume: YES"
        else
            echo "   Resume: NO (fresh start)"
        fi
        echo ""
    fi
fi

# Scene duration (not needed for prompts-only)
if [ "$MODE_ARG" != "--prompts-only" ]; then
    echo " Scene duration, seconds:"
    CLIP_MIN=4
    CLIP_MAX=8
    echo -n "  Min duration [2-8] Enter=4: "
    read INPUT; [ -n "$INPUT" ] && CLIP_MIN=$INPUT
    echo -n "  Max duration [4-12] Enter=8: "
    read INPUT; [ -n "$INPUT" ] && CLIP_MAX=$INPUT
    echo "   Min: ${CLIP_MIN}s  Max: ${CLIP_MAX}s"
    echo ""
    export VIDEO_CLIP_MIN_DURATION=$CLIP_MIN
    export VIDEO_CLIP_MAX_DURATION=$CLIP_MAX

    echo " Intro block (first N seconds use shorter clips):"
    INTRO_DUR=50
    INTRO_MIN=5
    INTRO_MAX=5
    echo -n "  Intro block duration, s [Enter=50]: "
    read INPUT; [ -n "$INPUT" ] && INTRO_DUR=$INPUT
    echo -n "  Intro clip min, s [Enter=5]: "
    read INPUT; [ -n "$INPUT" ] && INTRO_MIN=$INPUT
    echo -n "  Intro clip max, s [Enter=5]: "
    read INPUT; [ -n "$INPUT" ] && INTRO_MAX=$INPUT
    echo "   Intro: first ${INTRO_DUR}s  clip ${INTRO_MIN}-${INTRO_MAX}s"
    echo ""
    export INTRO_BLOCK_DURATION=$INTRO_DUR
    export INTRO_CLIP_MIN_DURATION=$INTRO_MIN
    export INTRO_CLIP_MAX_DURATION=$INTRO_MAX
fi

cd "$AGENT_DIR"

python3 agent.py direct \
    --transcription "$SCRIPT_DIR/transcription.json" \
    --style "$STYLE_FILE" \
    --project "$PROJECT_NAME" \
    $MODE_ARG $RESUME_ARG

DIRECTOR_EXIT=$?

echo ""
if [ $DIRECTOR_EXIT -ne 0 ]; then
    echo "[ERROR] Director failed!"
else
    echo "[OK] Director done!"
fi
echo "================================================================================"
echo ""
echo "Press Enter to exit..."
read
exit $DIRECTOR_EXIT
