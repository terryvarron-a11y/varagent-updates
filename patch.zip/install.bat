@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo ================================================================================
echo  SCENAGENT RTG - AUTO INSTALLER
echo ================================================================================
echo.

set "NEED_RESTART=0"
set "PYTHON_CMD=python"

REM ============================================================================
REM 1. PYTHON
REM    Logika: nayden -> OK
REM            ne nayden -> winget -> skachat installer
REM            posle ustanovki -> obnovlyaem PATH cherez PowerShell v tekushchey sessi
REM            esli PATH ne obnovils -> ishchem po izvestnym putyam
REM ============================================================================
echo [1/4] Python...

REM --- Variant 1: komanda "python" ---
python --version >nul 2>&1
if not errorlevel 1 (
    for /f "tokens=2" %%v in ('python --version 2^>^&1') do set PYVER=%%v
    echo  [OK] Python !PYVER! (komanda: python)
    goto :python_version_check
)

REM --- Variant 2: Windows py launcher ("py -3") ---
py --version >nul 2>&1
if not errorlevel 1 (
    for /f "tokens=2" %%v in ('py --version 2^>^&1') do set PYVER=%%v
    set "PYTHON_CMD=py"
    echo  [OK] Python !PYVER! (komanda: py)
    goto :python_version_check
)

:python_version_check
REM --- Proverka minimalnoj versii (3.10+ dlya google-genai) ---
for /f "tokens=1,2 delims=." %%a in ("!PYVER!") do (
    set "PY_MAJOR=%%a"
    set "PY_MINOR=%%b"
)
if !PY_MAJOR! LSS 3 goto :python_too_old
if !PY_MAJOR! EQU 3 if !PY_MINOR! LSS 10 goto :python_too_old
goto :pip_check

:python_too_old
echo  [WARN] Python !PYVER! slishkom staryy (nuzhno 3.10+, dlya google-genai)
echo  Ustanavlivaem novuyu versiyu...
echo.

echo  Python ne nayden. Ustanavlivaem...
echo.

REM --- Probuyem winget ---
winget --version >nul 2>&1
if not errorlevel 1 (
    echo  [winget] Ustanavlivaem Python 3.11...
    winget install --id Python.Python.3.11 --silent --accept-package-agreements --accept-source-agreements
    if not errorlevel 1 goto :python_refresh
    echo  winget ne smog. Perekluchaems na installer...
)

REM --- Skachivaem installer ---
echo  Skachaem Python 3.11 installer (python.org)...
curl -L --progress-bar -o "%TEMP%\py_installer.exe" "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe"
if errorlevel 1 (
    echo.
    echo  [ERROR] Ne udalos skachat installer.
    echo  Skachayte vruchnuyu: https://www.python.org/downloads/
    echo  Otmette "Add python.exe to PATH" pri ustanovke!
    pause
    exit /b 1
)
echo  Ustanavlivaem Python 3.11 (tihaya ustanovka)...
"%TEMP%\py_installer.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_test=0
del "%TEMP%\py_installer.exe" >nul 2>&1

REM --- Obnovlyaem PATH v tekushchey CMD-sessi cherez reestr (PowerShell) ---
:python_refresh
echo  Obnovlyaem PATH dlya tekushchey sessi...
for /f "usebackq delims=" %%P in (`powershell -NoProfile -Command "[Environment]::GetEnvironmentVariable('PATH','Machine') + ';' + [Environment]::GetEnvironmentVariable('PATH','User')"`) do set "PATH=%%P"

REM --- Proveryaem: stalo li python dostupno ---
python --version >nul 2>&1
if not errorlevel 1 (
    for /f "tokens=2" %%v in ('python --version 2^>^&1') do set PYVER=%%v
    echo  [OK] Python !PYVER! (PATH obnovlon)
    goto :pip_check
)

REM --- Ishchem po izvestnym putyam (na sluchaj esli PATH eshcho ne primenilsya) ---
echo  Ishchem python.exe po standartnym putyam...
set "PYTHON_CMD="
if exist "%LOCALAPPDATA%\Programs\Python\Python314\python.exe" (
    set "PYTHON_CMD=%LOCALAPPDATA%\Programs\Python\Python314\python.exe"
    goto :python_found_by_path
)
if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" (
    set "PYTHON_CMD=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
    goto :python_found_by_path
)
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
    set "PYTHON_CMD=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    goto :python_found_by_path
)
if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" (
    set "PYTHON_CMD=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
    goto :python_found_by_path
)
if exist "%LOCALAPPDATA%\Programs\Python\Python310\python.exe" (
    set "PYTHON_CMD=%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
    goto :python_found_by_path
)
if exist "C:\Python314\python.exe" (
    set "PYTHON_CMD=C:\Python314\python.exe"
    goto :python_found_by_path
)
if exist "C:\Python313\python.exe" (
    set "PYTHON_CMD=C:\Python313\python.exe"
    goto :python_found_by_path
)
if exist "C:\Python312\python.exe" (
    set "PYTHON_CMD=C:\Python312\python.exe"
    goto :python_found_by_path
)
if exist "C:\Python311\python.exe" (
    set "PYTHON_CMD=C:\Python311\python.exe"
    goto :python_found_by_path
)
if exist "C:\Program Files\Python314\python.exe" (
    set "PYTHON_CMD=C:\Program Files\Python314\python.exe"
    goto :python_found_by_path
)
if exist "C:\Program Files\Python313\python.exe" (
    set "PYTHON_CMD=C:\Program Files\Python313\python.exe"
    goto :python_found_by_path
)
if exist "C:\Program Files\Python311\python.exe" (
    set "PYTHON_CMD=C:\Program Files\Python311\python.exe"
    goto :python_found_by_path
)

echo  [ERROR] Python ustanovlen, no ne nayden ni v PATH ni po izvestnym putyam.
echo  Zakrojte CMD, otkrojte novyy terminal i zapustite install.bat snova.
pause
exit /b 1

:python_found_by_path
echo  [OK] Python nayden: !PYTHON_CMD!
goto :pip_check

:pip_check
REM ============================================================================
REM 2. PIP - vsegda cherez "python -m pip", NIE cherez bare "pip"
REM    Eto garantiruet rabotu dazhe esli pip net v PATH otdelno
REM ============================================================================
echo.
echo [2/4] pip...

"!PYTHON_CMD!" -m pip --version >nul 2>&1
if not errorlevel 1 (
    echo  [OK] pip dostupno (cherez python -m pip)
    goto :packages
)

echo  pip ne nayden. Ustanavlivaem cherez ensurepip...
"!PYTHON_CMD!" -m ensurepip --upgrade
if errorlevel 1 (
    echo  [ERROR] ensurepip ne smog ustanovit pip!
    echo  Poprobujte: "!PYTHON_CMD!" -m ensurepip --upgrade
    pause
    exit /b 1
)

REM Proverka posle ensurepip
"!PYTHON_CMD!" -m pip --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] pip vsyo eshcho ne rabotaet posle ensurepip.
    pause
    exit /b 1
)
echo  [OK] pip ustanovlen

:packages
REM ============================================================================
REM 3. PYTHON PAKETY
REM    Ispolzuem "python -m pip install" - rabotaet nezavisimo ot PATH pip
REM ============================================================================
echo.
echo [3/4] Python pakety...
echo.

REM Snachala obnovim pip s --trusted-host (pomogaet pri SSL/proxy problemakh)
"!PYTHON_CMD!" -m pip install --upgrade pip --trusted-host pypi.org --trusted-host files.pythonhosted.org

echo.
echo  Ustanavlivaem pakety (assemblyai, google-genai, python-dotenv, tqdm, httpx, pydantic, colorama)...
echo.

REM Proveryaem uzhe li ustanovleny pakety
"!PYTHON_CMD!" -c "import assemblyai, google.genai, dotenv, tqdm, httpx, pydantic, colorama" 2>nul
if not errorlevel 1 (
    echo  [OK] Vse pakety uzhe ustanovleny
    goto :ffmpeg_section
)

REM Pakety ne ustanovleny - ustanavlivaem
"!PYTHON_CMD!" -m pip install assemblyai google-genai python-dotenv tqdm httpx pydantic colorama ^
    --trusted-host pypi.org ^
    --trusted-host files.pythonhosted.org

if errorlevel 1 (
    echo.
    echo  [ERROR] Oshibka ustanovki paketov!
    echo.
    echo  VOZMOZHNYE PRICHINY I RESHENIYA:
    echo  1. Proverite internet-soedinenie
    echo  2. Otklyuchite VPN/proksi (ili vklyuchite, esli pypi blokiruet v regione)
    echo  3. Otklyuchite vremenno antiviurs/brandmauer
    echo  4. Zapustite s --trusted-host (uzhe dobavleno v etom install.bat)
    echo  5. Poprobujte drugoy DNS: 8.8.8.8 ili 1.1.1.1
    echo  6. Korporativnaya set'? - nastroite proksi:
    echo     set HTTP_PROXY=http://proxy:port
    echo     set HTTPS_PROXY=http://proxy:port
    echo  7. Zapustite vruchnuyu s podrobnym vyvodom:
    echo     python -m pip install -v assemblyai google-genai python-dotenv tqdm httpx pydantic colorama
    echo.
    pause
    exit /b 1
)
echo.
echo  [OK] Vse pakety ustanovleny
goto :ffmpeg_section

:ffmpeg_section
REM ============================================================================
REM 4. FFMPEG
REM    winget -> choco -> instrukcziya vruchnuyu
REM    posle winget obnovlyaem PATH v tekushchey sessi
REM ============================================================================
echo.
echo [4/4] FFmpeg...

ffmpeg -version >nul 2>&1
if not errorlevel 1 (
    echo  [OK] FFmpeg uzhe est
    goto :ffmpeg_ok
)

echo  FFmpeg ne nayden. Ustanavlivaem...
echo.

REM --- Probuyem winget ---
echo  Probuem winget...
winget --version >nul 2>&1
if not errorlevel 1 (
    echo  [winget] Ustanavlivaem Gyan.FFmpeg...
    winget install --id Gyan.FFmpeg --silent --accept-package-agreements --accept-source-agreements
    REM Obnovlyaem PATH iz reestra (kak v sekczii Python)
    for /f "usebackq delims=" %%P in (`powershell -NoProfile -Command "[Environment]::GetEnvironmentVariable('PATH','Machine') + ';' + [Environment]::GetEnvironmentVariable('PATH','User')"`) do set "PATH=%%P"
    ffmpeg -version >nul 2>&1
    if not errorlevel 1 (
        echo  [OK] FFmpeg ustanovlen i dostupno
        goto :ffmpeg_ok
    )
    echo  FFmpeg ustanovlen. Esli ne rabotaet - zapustite install_ffmpeg.bat.
    set "NEED_RESTART=1"
    goto :ffmpeg_ok
)
echo  winget ne nayden. Probuyem Chocolatey...

choco --version >nul 2>&1
if not errorlevel 1 (
    echo  [choco] Ustanavlivaem FFmpeg...
    choco install ffmpeg -y
    timeout /t 3 /nobreak >nul
    ffmpeg -version >nul 2>&1
    if not errorlevel 1 (
        echo  [OK] FFmpeg ustanovlen cherez Chocolatey
        goto :ffmpeg_ok
    )
    echo  FFmpeg ustanovlen, no nuzhen restart terminala.
    set "NEED_RESTART=1"
    goto :ffmpeg_ok
)
echo  Chocolatey ne nayden. Downloading FFmpeg directly...
echo.
call "%SCRIPT_DIR%\install_ffmpeg.bat"
for /f "usebackq delims=" %%P in (`powershell -NoProfile -Command "[Environment]::GetEnvironmentVariable('PATH','Machine') + ';' + [Environment]::GetEnvironmentVariable('PATH','User')"`) do set "PATH=%%P"
ffmpeg -version >nul 2>&1
if errorlevel 1 set "NEED_RESTART=1"

:ffmpeg_ok

REM ============================================================================
REM .ENV
REM ============================================================================
echo.
echo ================================================================================
echo  Konfiguracziya (.env)...
echo ================================================================================

if not exist "agent\.env" (
    if exist "agent\.env.example" (
        copy "agent\.env.example" "agent\.env" >nul
        echo  [OK] Sozdan agent\.env iz shablona
        echo.
        echo  [!!!] TREBUYUTSYA API KLYUCHI!
        echo  Otkrojte fayl  agent\.env  i zapolnite:
        echo.
        echo    ASSEMBLYAI_API_KEY  = poluchit: https://www.assemblyai.com/app/
        echo    GEMINI_API_KEY      = poluchit: https://aistudio.google.com/app/apikey
        echo    FASTGEN_API_KEY     = poluchit: https://fast-gen.ai
        echo.
    ) else (
        echo  [WARN] agent\.env.example ne nayden. Sozdajte agent\.env vruchnuyu.
    )
) else (
    echo  [OK] agent\.env uzhe sushchestvuet
)

REM ============================================================================
REM ITOG
REM ============================================================================
echo.
echo ================================================================================
echo  USTANOVKA ZAVERSHENA!
echo ================================================================================
echo.

if "!NEED_RESTART!"=="1" (
    echo  [!] VAZHNO: Perezapustite terminal pered ispolzovaniem!
    echo      Posle perezapuska proverite:
    echo        python --version
    echo        ffmpeg -version
    echo.
)

echo  Sleduyushchie shagi:
echo.
echo  1. Otkrojte agent\.env i ukazite API klyuchi
echo  2. Polozhite audiofayl (.mp3/.wav/.m4a) v papku  ready_to_go\
echo  3. Dobavte style guide v papku  style_guides\  (nazvanie: proekt.txt)
echo  4. Zapustite: run_stage1_simple.bat
echo.
echo ================================================================================
echo.
pause
