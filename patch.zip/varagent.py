#!/usr/bin/env python3
"""
VarAgent GUI — Visual Pipeline Manager
=======================================
Tab 1: Pipeline Launcher (replaces pipeline.bat)
Tab 2: Control Panel (project browser + .env editor)
Tab 3: VeoNonStop Generator (standalone generation)
"""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext, simpledialog
import threading
import re
import requests
import base64
import os
import sys
import subprocess
import importlib
import json
import time
import queue
import shutil
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from contextlib import contextmanager
from typing import Optional, List, Dict, Any

# ============ PATH SETUP ============
SCRIPT_DIR = Path(__file__).resolve().parent
AGENT_DIR = SCRIPT_DIR / 'agent'
AGENT_ENV_FILE = AGENT_DIR / '.env'
# ── Watermark removal tool presence flags (checked at GUI start + after install) ──
# All files that must exist for the tool to be considered "installed"
_AUDIO_REQUIRED = [
    AGENT_DIR / 'tools' / '_mmm_repo' / '.installed',
]
_SYNTHID_REQUIRED = [
    AGENT_DIR / 'tools' / '_synthid_bypass.py',
    AGENT_DIR / 'tools' / 'robust_extractor.py',
]
# Primary file (used as shorthand in legacy checks)
_AUDIO_REMOVER_TOOL = _AUDIO_REQUIRED[0]
_SYNTHID_TOOL       = _SYNTHID_REQUIRED[0]

_CONCAT_IMAGE_EXTS = ('.png', '.jpg', '.jpeg', '.webp')
_CONCAT_MEDIA_EXTS = ('.mp4', '.mov', '.mkv', '.avi', '.webm') + _CONCAT_IMAGE_EXTS


def _load_concat_montage_clips(project_dir: Path) -> list:
    plan_path = Path(project_dir) / 'montage_plan.json'
    if not plan_path.exists():
        raise FileNotFoundError(f"montage_plan.json not found: {plan_path}")
    data = json.loads(plan_path.read_text(encoding='utf-8-sig'))
    plan = data.get('montage_plan', data)
    return plan.get('clips', [])


def _concat_real_photo_image(project_dir: Path, clip_id: int) -> Optional[Path]:
    gen_dir = Path(project_dir) / 'generated'
    for fmt in (f'{clip_id:03d}', str(clip_id)):
        for ext in _CONCAT_IMAGE_EXTS:
            candidate = gen_dir / f'{fmt}{ext}'
            if candidate.exists() and candidate.stat().st_size > 1000:
                return candidate
    return None


def _concat_clip_media_exists(project_dir: Path, clip: dict) -> bool:
    clip_id = clip.get('id')
    if clip_id is None:
        return False

    vid_dir = Path(project_dir) / 'vid_img'
    for fmt in (f'{int(clip_id):03d}', str(clip_id)):
        for ext in _CONCAT_MEDIA_EXTS:
            candidate = vid_dir / f'{fmt}{ext}'
            if candidate.exists() and candidate.stat().st_size > 1000:
                return True

    cf = clip.get('file')
    if cf:
        cfp = Path(cf)
        candidates = [cfp] if cfp.is_absolute() else [Path(project_dir) / cfp, cfp]
        for candidate in candidates:
            if candidate.exists() and candidate.stat().st_size > 1000:
                return True

    return _concat_real_photo_image(Path(project_dir), int(clip_id)) is not None


def _concat_readiness_status(project_dir: Path) -> tuple[bool, str]:
    """Check whether video_concat.py can safely start for this project."""
    project_dir = Path(project_dir)
    clips = _load_concat_montage_clips(project_dir)
    if not clips:
        return False, "montage_plan has no clips"

    pending_real = [
        int(c['id']) for c in clips
        if c.get('source') == 'real_photo_pending' and 'id' in c
    ]
    if pending_real:
        return False, f"RealPhoto still pending: {pending_real[:12]}{'...' if len(pending_real) > 12 else ''}"

    real_missing_image = []
    real_missing_meta = []
    missing_media = []
    for clip in clips:
        cid = clip.get('id')
        if cid is None:
            continue
        cid = int(cid)
        if clip.get('source') == 'real_photo':
            if _concat_real_photo_image(project_dir, cid) is None:
                real_missing_image.append(cid)
            if not clip.get('real_meta'):
                real_missing_meta.append(cid)
        if not _concat_clip_media_exists(project_dir, clip):
            missing_media.append(cid)

    if real_missing_image:
        return False, f"RealPhoto images missing in generated/: {real_missing_image[:12]}{'...' if len(real_missing_image) > 12 else ''}"
    if real_missing_meta:
        return False, f"RealPhoto metadata missing in montage_plan: {real_missing_meta[:12]}{'...' if len(real_missing_meta) > 12 else ''}"
    if missing_media:
        return False, f"Media missing for clips: {missing_media[:12]}{'...' if len(missing_media) > 12 else ''}"
    return True, f"ready ({len(clips)} clips)"


def _load_project_config(project_dir: Path) -> dict:
    """Читает pipeline_config.json из папки проекта — слепок настроек первого запуска.

    Если файла нет — fallback на парсинг строки [ARGS] из pipeline_full.log (legacy проекты).
    Возвращает dict с ключами: clip_mode, vislide_interval, intro_block_duration,
    clip_min, clip_max, director_backend, gpt_model, gemini_model, prompt_mode,
    post_action, img_gen, video_mode, video_engine, story_mode, language.
    Пустой dict если ничего не нашлось.
    """
    project_dir = Path(project_dir)
    cfg_path = project_dir / 'pipeline_config.json'
    if cfg_path.exists():
        try:
            import json as _json
            return _json.loads(cfg_path.read_text(encoding='utf-8'))
        except Exception:
            pass

    # Legacy fallback: парсим [ARGS] из pipeline_full.log
    log_path = project_dir / 'pipeline_full.log'
    if not log_path.exists():
        return {}
    try:
        text = log_path.read_text(encoding='utf-8', errors='replace')
    except Exception:
        return {}
    import re as _re
    m = _re.search(r'^\s*\[ARGS\]\s+(.+)$', text, _re.MULTILINE)
    if not m:
        return {}
    args = m.group(1)
    cfg: dict = {}

    def _grab(flag: str) -> Optional[str]:
        mm = _re.search(rf'{_re.escape(flag)}\s+([^\s\'"]+)', args)
        return mm.group(1) if mm else None

    cm = _grab('--clip-mode')
    if cm:
        cfg['clip_mode'] = cm
    vi = _grab('--vislide-interval')
    if vi:
        try:
            cfg['vislide_interval'] = int(vi)
        except ValueError:
            pass
    cmin = _grab('--clip-min')
    if cmin:
        try:
            cfg['clip_min'] = int(cmin)
        except ValueError:
            pass
    cmax = _grab('--clip-max')
    if cmax:
        try:
            cfg['clip_max'] = int(cmax)
        except ValueError:
            pass
    lang = _grab('--language')
    if lang:
        cfg['language'] = lang
    pa = _grab('--post-action')
    if pa:
        cfg['post_action'] = pa
    pm = _grab('--prompt-mode')
    if pm:
        cfg['prompt_mode'] = pm
    if '--two-pass' in args:
        cfg['two_pass'] = True

    # intro_block_duration ловим из _codex_pass1_control_task.md если есть
    task_md = project_dir / '_codex_pass1_control_task.md'
    if task_md.exists():
        try:
            tm = task_md.read_text(encoding='utf-8', errors='replace')
            mi = _re.search(r'\{intro_block_dur\}\s*=\s*(\d+)', tm)
            if mi:
                cfg['intro_block_duration'] = int(mi.group(1))
        except Exception:
            pass

    return cfg


def _inject_project_config_env(target_env: dict, project_dir: Path) -> dict:
    """Подмешивает в target_env переменные из pipeline_config.json проекта.

    Используется в Finalize Stage перед запуском подпроцессов (watch_i2v, imggen, etc),
    чтобы восстановить vislide_interval / intro_block_duration / etc, которые иначе теряются.
    Возвращает изменённый target_env (мутирует и возвращает для удобства).
    """
    cfg = _load_project_config(project_dir)
    if not cfg:
        return target_env
    if cfg.get('clip_mode') == 'vislide':
        vi = int(cfg.get('vislide_interval', 0) or 0)
        if vi >= 2:
            target_env['VARAGENT_VISLIDE_INTERVAL'] = str(vi)
    ibd = cfg.get('intro_block_duration')
    if ibd:
        target_env['INTRO_BLOCK_DURATION'] = str(int(ibd))
    cmin = cfg.get('clip_min')
    if cmin:
        target_env['VIDEO_CLIP_MIN_DURATION'] = str(int(cmin))
    cmax = cfg.get('clip_max')
    if cmax:
        target_env['VIDEO_CLIP_MAX_DURATION'] = str(int(cmax))
    return target_env


def _wait_for_concat_readiness(project_dir: Path, log_cb, cancel_cb=None, timeout_s: Optional[float] = None):
    """Barrier before concat: wait for VideoGen outputs and RealPhoto final metadata."""
    project_dir = Path(project_dir)
    if timeout_s is None:
        timeout_s = float(os.environ.get('VARAGENT_CONCAT_READY_TIMEOUT', '86400'))
    start = time.time()
    last_msg = None
    last_log_t = 0.0

    while True:
        if cancel_cb and cancel_cb():
            raise RuntimeError("Concat cancelled while waiting for project readiness")
        ready, msg = _concat_readiness_status(project_dir)
        if ready:
            if last_msg is not None:
                log_cb(f"[ConcatGuard] Project ready for concat: {msg}", "INFO")
            return msg
        now = time.time()
        if msg != last_msg or now - last_log_t >= 30:
            log_cb(f"[ConcatGuard] Waiting before concat: {msg}", "INFO")
            last_msg = msg
            last_log_t = now
        if timeout_s and now - start > timeout_s:
            raise RuntimeError(f"Concat readiness timeout after {int(timeout_s)}s: {msg}")
        time.sleep(3)


def _audio_installed() -> bool:
    return all(p.exists() for p in _AUDIO_REQUIRED)

def _synthid_installed() -> bool:
    return all(p.exists() for p in _SYNTHID_REQUIRED)

# ── WM Tools guide texts (used in Settings card + ? popups) ──────────────────
_WM_AUDIO_LEVELS = [
    ("gentle",     "Минимальная обработка. Порядок фильтра 2, шум 1e-5, джиттер ±0.1%.\n"
                   "Гармонические корректировки отключены. Лучшее качество звука."),
    ("moderate",   "Сбалансированно. Порядок 2, шум 5e-5, джиттер ±0.3%.\n"
                   "Гармоники включены. Рекомендуемый режим по умолчанию."),
    ("aggressive", "Сильная обработка. Порядок 3, шум 1e-4, джиттер ±0.5%.\n"
                   "Заметная потеря качества. Когда moderate недостаточно."),
    ("extreme",    "Максимум. Порядок 4, шум 5e-4, джиттер ±1.0%.\n"
                   "Существенная деградация звука — только в крайнем случае."),
]
_WM_SYNTHID_STRENGTH = [
    ("gentle",     "v2: JPEG q=85, σ=3 — минимальные визуальные изменения.\n"
                   "v3: 1 спектральный проход."),
    ("moderate",   "v2: JPEG q=60, σ=6 — лёгкие артефакты сжатия.\n"
                   "v3: 3 прохода. Рекомендуемый режим."),
    ("aggressive", "v2: JPEG q=45, σ=10 + Gaussian blur.\n"
                   "v3: 3 прохода с нарастанием gentle→moderate→aggressive."),
    ("extreme",    "v2: JPEG q=35, σ=15 — заметная потеря качества.\n"
                   "v3: 3 прохода на максимальной силе."),
]
_WM_SYNTHID_VERSIONS = [
    ("v1", "Режимовый обход без кодбука.\n"
           "Наименее эффективен, но универсален — работает с любыми изображениями."),
    ("v2", "JPEG-сжатие + размытие + инъекция шума.\n"
           "Разрушает фазовый шаблон SynthID."),
    ("v3", "Вычитание спектрального кодбука в FFT-области.\n"
           "Наиболее эффективен (~43.5 дБ PSNR, снижение фазовой когерентности на 91%).\n"
           "Требует codebook.npz, собранного из примеров изображений."),
]
PRESETS_FILE   = AGENT_DIR / 'presets.json'
sys.path.insert(0, str(AGENT_DIR))
os.chdir(str(SCRIPT_DIR))

if sys.platform == 'win32':
    os.system('chcp 65001 >nul')

# Suppress tqdm in GUI mode
os.environ['TQDM_DISABLE'] = '1'

import config

# ============ COLORS + THEMES ============
_DEFAULT_COLORS = {
    'bg_dark': '#181825',
    'bg_card': '#222236',
    'bg_input': '#2e2e44',
    'border': '#2d2d3a',
    'text': '#e8e8f2',
    'text_dim': '#a0a0b8',
    'text_muted': '#707088',
    'accent': '#7c5cfc',
    'accent_hover': '#9d7eff',
    'yellow': '#f5c842',
    'green': '#34d399',
    'orange': '#fb923c',
    'red': '#f87171',
    'blue': '#60a5fa',
    'cyan': '#22d3ee',
    'pink': '#f472b6',
}

_THEMES_DIR = SCRIPT_DIR / 'themes'
_ACTIVE_THEME = {}  # filled by _load_theme()

def _load_theme(name: str = '') -> dict:
    """Load a theme JSON from themes/ dir. Returns full theme dict."""
    if not name:
        name = os.environ.get('VARAGENT_THEME', 'default')
    theme_file = _THEMES_DIR / f'{name}.json'
    theme = {'name': 'Default', 'colors': dict(_DEFAULT_COLORS),
             'header': {'enabled': False}, 'title': 'VarAgent — Video Production Pipeline'}
    if theme_file.exists():
        try:
            import json as _j
            data = _j.loads(theme_file.read_text(encoding='utf-8'))
            if 'colors' in data:
                theme['colors'].update(data['colors'])
            if 'header' in data:
                theme['header'] = data['header']
            if 'title' in data:
                theme['title'] = data['title']
            theme['name'] = data.get('name', name)
        except Exception as e:
            print(f"[WARN] Theme load failed ({theme_file}): {e}")
    _ACTIVE_THEME.update(theme)
    return theme

def _available_themes() -> list:
    """List available theme names from themes/ dir."""
    if not _THEMES_DIR.exists():
        return ['default']
    return sorted(p.stem for p in _THEMES_DIR.glob('*.json'))

_theme = _load_theme()
COLORS = _theme['colors']

# Font sizes — bump for better readability on HiDPI
FONT_MAIN = ("Segoe UI", 11)
FONT_MAIN_BOLD = ("Segoe UI", 11, "bold")
FONT_DIM = ("Segoe UI", 10)
FONT_HEADER = ("Segoe UI", 18, "bold")
FONT_SECTION = ("Segoe UI", 12, "bold")
FONT_BUTTON = ("Segoe UI", 11, "bold")
FONT_LOG = ("Consolas", 10)
FONT_TAB = ("Segoe UI", 11, "bold")


def _find_ass_template(res: str = '720p', preset: str = 'bottom') -> str | None:
    """Find ASS subtitle template for resolution and placement preset."""
    tdir = AGENT_DIR / 'templates'
    res = '1080p' if str(res) in ('1080', '1080p') else '720p'
    preset = (preset or 'bottom').lower()
    explicit_name = f"subtitles_{res}_center.ass" if preset == 'center' else f"subtitles_{res}.ass"
    explicit = tdir / explicit_name
    if explicit.exists():
        return str(explicit)
    by_res = sorted(tdir.glob(f'*{res}*.ass'))
    if by_res:
        return str(by_res[0])
    fallback = sorted(tdir.glob('*.ass'))
    return str(fallback[0]) if fallback else None

# Display name → API model_key mapping
FASTGEN_MODELS = [
    ("Flower", "FLOWER"),
    ("Banana Pro", "GEM_PIX_2"),
    ("Banana 2", "NARWHAL"),
    ("Grok", "GROK"),
    ("ChatGPT Image", "OPENAI"),
    ("Banana", "GEM_PIX"),
]
FASTGEN_DISPLAY = [m[0] for m in FASTGEN_MODELS]
FASTGEN_NAME_TO_KEY = {m[0]: m[1] for m in FASTGEN_MODELS}
FASTGEN_KEY_TO_NAME = {m[1]: m[0] for m in FASTGEN_MODELS}

BANANA_MODELS = [("Banana Pro", "GEM_PIX_2"), ("Banana 2", "NARWHAL")]
BANANA_DISPLAY = [m[0] for m in BANANA_MODELS]
BANANA_NAME_TO_KEY = {m[0]: m[1] for m in BANANA_MODELS}

# --- OpenRouter Director: короткие лейблы → (model_slug, web_search) ---
# web: 'disabled' (чистый slug) | 'enabled' (суффикс :online в chat_director)
OR_DIRECTOR_MODELS = [
    ("Free авто — web off (быстро)", "openrouter/free",                          "disabled"),
    ("Free авто — web on",           "openrouter/free",                          "enabled"),
    ("Qwen3 Coder (free, 1M)",       "qwen/qwen3-coder:free",                    "enabled"),
    ("Nemotron Ultra 550B (free,1M)","nvidia/nemotron-3-ultra-550b-a55b:free",   "enabled"),
    ("Qwen3 235B ($0.10)",           "qwen/qwen3-235b-a22b-2507",                "enabled"),
    ("Qwen3.5 Flash ($0.26, 1M)",    "qwen/qwen3.5-flash-02-23",                 "enabled"),
    ("DeepSeek v3.2 ($0.34)",        "deepseek/deepseek-v3.2",                   "enabled"),
    ("DeepSeek V4 Flash ($0.09)",    "deepseek/deepseek-v4-flash",               "enabled"),
    ("DeepSeek V4 Pro ($0.44)",      "deepseek/deepseek-v4-pro",                 "enabled"),
    ("Claude Sonnet 4.6 ($3/$15)",   "anthropic/claude-sonnet-4.6",              "enabled"),
]
OR_DIRECTOR_DISPLAY = [m[0] for m in OR_DIRECTOR_MODELS]
OR_DIRECTOR_LABEL_TO_MV = {m[0]: (m[1], m[2]) for m in OR_DIRECTOR_MODELS}       # label -> (model, web)
OR_DIRECTOR_MV_TO_LABEL = {(m[1], m[2]): m[0] for m in OR_DIRECTOR_MODELS}       # (model, web) -> label

# --- Rewrite: короткие лейблы → spec 'provider:model' ---
REWRITE_MODELS = [
    ("Gemini 3.5 Flash",              "gemini:gemini-3.5-flash"),
    ("Gemini 3 Flash Preview",        "gemini:gemini-3-flash-preview"),
    ("Gemini 3.1 Flash-Lite",         "gemini:gemini-3.1-flash-lite"),
    ("Gemini 3.1 Flash-Lite Preview", "gemini:gemini-3.1-flash-lite-preview"),
    ("Gemini 2.5 Flash",              "gemini:gemini-2.5-flash"),
    ("Gemini 2.5 Flash-Lite",         "gemini:gemini-2.5-flash-lite"),
    ("GPT-5.4-mini (Codex)",          "gpt:gpt-5.4-mini"),
    ("DeepSeek v4 Flash",             "deepseek:deepseek-v4-flash"),
    ("Dolphin Venice (uncensored)",   "openrouter:cognitivecomputations/dolphin-mistral-24b-venice-edition:free"),
    ("Hermes 405B (uncensored)",      "openrouter:nousresearch/hermes-3-llama-3.1-405b:free"),
    ("OpenRouter Free (авто)",        "openrouter:openrouter/free"),
    ("Nemotron Ultra 550B",           "openrouter:nvidia/nemotron-3-ultra-550b-a55b:free"),
    ("Llama 3.3 70B",                 "openrouter:meta-llama/llama-3.3-70b-instruct:free"),
]
REWRITE_DISPLAY = [m[0] for m in REWRITE_MODELS]
REWRITE_LABEL_TO_SPEC = {m[0]: m[1] for m in REWRITE_MODELS}
REWRITE_SPEC_TO_LABEL = {m[1]: m[0] for m in REWRITE_MODELS}
BANANA_KEY_TO_NAME = {m[1]: m[0] for m in BANANA_MODELS}

_GEMINI_MODEL_OPTS = [
    "gemini-2.5-pro", "gemini-2.5-flash",
    "gemini-3-flash-preview",
    "gemini-3.1-pro-preview",
]
_FASTGEN_MODEL_OPTS = [
    "FLOWER — Flower",
    "GEM_PIX_2 — Banana Pro",
    "NARWHAL — Banana 2",
    "GROK — Grok",
    "OPENAI — ChatGPT Image",
    "GEM_PIX — Banana",
]

# Список доступных VeoNonStop base URLs — используется в ENV_DROPDOWN_OPTIONS
# для VEONONSTOP_API_BASE и per-key вариантов (_2/_3/_4)
_VEO_BASE_URLS = [
    "https://veononstop.org/api/v1",
    "https://viet.veo.kotsklad.ru/api/v1",
    "http://127.0.0.1:3001/api/v1",
    "http://127.0.0.1:3002/api/v1",
    "http://127.0.0.1:3003/api/v1",
]

ENV_DROPDOWN_OPTIONS: dict = {
    # Zoom (Ken Burns в video_concat)
    "ZOOM_AMOUNT": [
        "0.05 — Слабый зум (еле заметный)",
        "0.10 — Средний (рекомендуется)",
        "0.15 — Заметный",
        "0.20 — Сильный",
    ],
    "ZOOM_CURVE": [
        "linear — Равномерный (постоянная скорость по клипу)",
        "constant_speed — Фиксированная скорость в секунду",
        "ease_out — Замедление к концу (киношный)",
    ],
    # AssemblyAI
    "ASSEMBLYAI_LANGUAGE_CODE":   ["ru", "en", "es", "de", "fr", "it", "pl", "pt", "zh", "ja", "ko", "uk", "tr", "ar"],
    "ASSEMBLYAI_SPEECH_MODELS":   ["universal-3-pro,universal-2", "universal-3-pro", "universal-2"],
    "ASSEMBLYAI_SEGMENTATION_MODE": ["words", "sentences", "paragraphs"],
    # Gemini director
    "GEMINI_MODEL":               _GEMINI_MODEL_OPTS,
    "GEMINI_THINKING_LEVEL":      ["low", "medium", "high"],
    "GEMINI_THINKING_LEVEL_PASS2": ["low", "medium", "high"],
    "GEMINI_TWO_PASS":            ["false", "true"],
    "GENERATE_DIRECTOR_ANALYSIS": ["false", "true"],
    # TTS
    "TTS_SERVICE":                ["mat3u", "csv666"],
    "TTS_MAT3U_MODEL_ID":         ["eleven_multilingual_v2", "eleven_v3", "eleven_turbo_v2_5",
                                   "eleven_turbo_v2", "eleven_flash_v2_5", "eleven_flash_v2"],
    "TTS_MAT3U_SPLIT_TYPE":       ["smart", "sentences", "paragraphs", "max_length"],
    "TTS_MAT3U_SPLIT_OUTPUT":     ["false", "true"],
    "TTS_MAT3U_AUTO_PAUSE_ENABLED": ["false", "true"],
    "TTS_CSV666_OUTPUT_FORMAT":   ["mp3", "zip"],
    # FastGen
    "FASTGEN_MODEL":              _FASTGEN_MODEL_OPTS,
    "FASTGEN_ASPECT_RATIO":       ["landscape", "portrait", "square"],
    # VeoNonStop
    "VEONONSTOP_API_BASE":        _VEO_BASE_URLS,
    "VEONONSTOP_API_BASE_2":      _VEO_BASE_URLS,
    "VEONONSTOP_API_BASE_3":      _VEO_BASE_URLS,
    "VEONONSTOP_API_BASE_4":      _VEO_BASE_URLS,
    "VEONONSTOP_ASPECT_RATIO":    ["16:9", "9:16", "1:1", "4:3", "3:4"],
    "VEONONSTOP_IMGGEN_MODE":     ["banana", "banana_ref", "imagen"],
    "VEONONSTOP_BANANA_MODEL":    [
        "GEM_PIX_2 — Banana Pro",
        "NARWHAL — Banana 2",
    ],
    "VEONONSTOP_REF_MODE":        ["name_match", "use_all"],
    "VEONONSTOP_REQUEST_DELAY":     ["0.5", "1.0", "2.0", "3.0", "5.0", "10.0"],
    "VEONONSTOP_RECAPTCHA_DELAY":   ["3.0", "5.0", "8.0", "10.0", "15.0", "20.0", "30.0"],
    "VEONONSTOP_RECAPTCHA_JITTER":  ["1.0", "2.0", "3.0", "5.0"],
    "VEONONSTOP_MAX_RETRIES":       ["1", "2", "3", "4", "5"],
    "VEONONSTOP_MAX_RESUBMITS":     ["1", "2", "3", "4", "5"],
    "VEONONSTOP_MAX_SILENT_CYCLES": ["1", "2", "3", "4", "5", "7", "10"],
    "VEONONSTOP_FAST_CENSOR":     ["off", "after_rewrites", "ultrafast"],
    # Pipeline defaults
    "PIPELINE_IMG_GEN":           ["veononstop", "fastgen", "skip"],
    # YT Packer
    "YT_PACK_MODEL":              _GEMINI_MODEL_OPTS + ['gpt-5.5', 'gpt-5.4', 'gpt-5.4-mini'],
    "YT_PACK_TRANSLATE_MODEL":    _GEMINI_MODEL_OPTS + ['gpt-5.5', 'gpt-5.4', 'gpt-5.4-mini'],
    "YT_PACK_CONTENT_MODEL":      _GEMINI_MODEL_OPTS + ['gpt-5.5', 'gpt-5.4', 'gpt-5.4-mini'],
    "YT_PACK_COVER_MODEL":        _FASTGEN_MODEL_OPTS,
    "YT_PACK_SUBTITLES":          ["false", "true"],
    "YT_PACK_DESCRIPTION":        ["false", "true"],
    "YT_PACK_COVERS":             ["false", "true"],
    "YT_PACK_LANGUAGES":          ["ru,en", "en,ru", "ru", "en", "es", "de", "fr"],
}

BASE_URL = getattr(config, 'VEONONSTOP_API_BASE', 'https://veononstop.org/api/v1')
REQUEST_TIMEOUT = 180
VIDEO_POLL_INTERVAL = 5
IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.webp'}


# ============ STDOUT CAPTURE ============

# False-positive guards for subprocess log level classification.
# Substring 'error' / 'fail' / 'traceback' alone не надёжно: строки-статистики
# ("renamed OK=99, errors=0, warnings=0", "no errors", "failed=0") ложно
# попадали в ERROR и окрашивались красным. Ниже regex'ы исключают их.
_LOG_ZERO_COUNTER_RE = re.compile(
    r'\b(errors?|fails?|failures?|failed)\s*[=:]\s*0\b',
    re.IGNORECASE,
)
_LOG_NO_ERR_RE = re.compile(
    r'\bno\s+(errors?|fails?|failures?|failed|traceback)\b',
    re.IGNORECASE,
)


def _is_false_error_signal(line: str) -> bool:
    """True if line contains error/fail substrings but only in success-context
    (statistics counters = 0 / "no errors" / etc). Use to suppress false ERROR
    classification in subprocess stdout streaming.
    Does NOT neutralize real 'traceback' — only 'no traceback'."""
    if 'traceback' in line.lower() and 'no traceback' not in line.lower():
        return False
    if _LOG_ZERO_COUNTER_RE.search(line):
        return True
    if _LOG_NO_ERR_RE.search(line):
        return True
    return False


class LogRedirector:
    """Redirects sys.stdout to a log queue for GUI display."""
    def __init__(self, log_queue, tab_target, original, log_file=None, task_label=None, master_log=None):
        self.log_queue = log_queue
        self.tab_target = tab_target
        self.original = original
        self.buffer = ""
        self.log_file = log_file
        self.task_label = task_label  # shown as [Label] prefix in GUI log
        self.master_log = master_log  # pipeline_full.log (append across stages)

    def write(self, text):
        try:
            self.original.write(text)
        except (UnicodeEncodeError, UnicodeDecodeError):
            try:
                self.original.write(text.encode('utf-8', errors='replace').decode('ascii', errors='replace'))
            except Exception:
                pass
        self.buffer += text
        while '\n' in self.buffer:
            line, self.buffer = self.buffer.split('\n', 1)
            if line.strip():
                level = 'INFO'
                low = line.lower()
                # Explicit error/failure markers have highest priority — guards against
                # false SUCCESS match on lines like `{"success":false,"error":"..."}`.
                if ('[error]' in low or '[failed]' in low or 'failed (' in low
                        or 'traceback' in low or '"success":false' in low
                        or '"success": false' in low):
                    level = 'ERROR'
                elif '[synthid]' in low and ': ok' in low:
                    level = 'SYNTHID'
                elif '[ok]' in low or 'complete' in low or 'saved' in low:
                    level = 'SUCCESS'
                elif ('error' in low or 'fail' in low) and not _is_false_error_signal(line):
                    level = 'ERROR'
                elif 'warn' in low or 'skip' in low or 'retry' in low:
                    level = 'WARNING'
                self.log_queue.put((line.rstrip(), level, self.task_label, self.tab_target))
            if self.log_file:
                try:
                    self.log_file.write(line + '\n')
                    self.log_file.flush()
                except Exception:
                    pass
            if self.master_log:
                try:
                    self.master_log.write(line + '\n')
                    self.master_log.flush()
                except Exception:
                    pass

    def flush(self):
        self.original.flush()

    def isatty(self):
        return False


@contextmanager
def capture_stdout(log_queue, tab_target, log_file=None, task_label=None, master_log=None):
    old_out = sys.stdout
    old_err = sys.stderr
    redir = LogRedirector(log_queue, tab_target, old_out, log_file=log_file, task_label=task_label, master_log=master_log)
    sys.stdout = redir
    sys.stderr = redir
    try:
        yield
    finally:
        sys.stdout = old_out
        sys.stderr = old_err


def _image_to_base64(filepath):
    """Load image file as base64 + detect MIME type."""
    ext = Path(filepath).suffix.lower()
    mime_map = {'.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp'}
    mime = mime_map.get(ext, 'image/png')
    with open(filepath, 'rb') as f:
        b64 = base64.b64encode(f.read()).decode('utf-8')
    return b64, mime


def get_output_dir():
    output_dir = SCRIPT_DIR / "veononstop_output"
    try:
        output_dir.mkdir(exist_ok=True)
        return output_dir
    except PermissionError:
        fallback = Path.home() / "veononstop_output"
        fallback.mkdir(exist_ok=True)
        return fallback


# ════════════════════════════════════════════════════════════════════
# CODEX QUOTA MONITOR (global, shared by header + Pipeline tab)
# ════════════════════════════════════════════════════════════════════

class CodexQuotaMonitor:
    """Background poller for Codex / ChatGPT quota. Notifies observer callbacks."""

    API_REFRESH_SEC = 300   # 5 minutes
    SESSION_POLL_SEC = 5    # 5 seconds — checks JSONL tail if session active

    def __init__(self, root):
        self.root = root
        self._observers = []
        self._last_data = None
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self._thread = None

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()

    def subscribe(self, callback):
        """Register a callback(data: dict) to be called on updates.
        callback will be invoked via root.after() on the main thread."""
        with self._lock:
            self._observers.append(callback)
        # Push latest cached data immediately if available
        if self._last_data:
            try:
                self.root.after(0, callback, self._last_data)
            except Exception:
                pass

    def refresh_now(self, force_api=True):
        """Trigger an immediate fetch in the background thread."""
        threading.Thread(target=self._fetch_and_notify,
                         kwargs={'force_api': force_api},
                         daemon=True).start()

    def _fetch_and_notify(self, force_api=False):
        try:
            from modules.codex_usage import get_quota
            data = get_quota(force_api=force_api)
        except Exception as e:
            data = {'ok': False, 'error': f'import: {e}', 'source': 'api'}
        with self._lock:
            self._last_data = data
            observers = list(self._observers)
        for cb in observers:
            try:
                self.root.after(0, cb, data)
            except Exception:
                pass

    def _run(self):
        last_api_fetch = 0.0
        while not self._stop.is_set():
            now = time.time()
            need_api = (now - last_api_fetch) >= self.API_REFRESH_SEC
            try:
                if need_api:
                    from modules.codex_usage import fetch_via_api
                    data = fetch_via_api()
                    last_api_fetch = now
                    if data.get('ok'):
                        self._deliver(data)
                        continue
                # Session tail poll (free, no network)
                from modules.codex_usage import fetch_via_session
                sess = fetch_via_session()
                if sess and sess.get('session_active'):
                    self._deliver(sess)
            except Exception:
                pass
            # Sleep short interval, break early on stop
            self._stop.wait(self.SESSION_POLL_SEC)

    def _deliver(self, data):
        with self._lock:
            self._last_data = data
            observers = list(self._observers)
        for cb in observers:
            try:
                self.root.after(0, cb, data)
            except Exception:
                pass


# ════════════════════════════════════════════════════════════════════
# MAIN APPLICATION
# ════════════════════════════════════════════════════════════════════

class VarAgentGUI:
    """Main application: window, theme, Notebook, shared log queue."""

    def __init__(self, root):
        self.root = root
        self.root.title(_ACTIVE_THEME.get('title', 'VarAgent — Video Production Pipeline'))
        # Adaptive geometry: fit to screen, cap at 1300x950
        _sw = self.root.winfo_screenwidth()
        _sh = self.root.winfo_screenheight()
        _w = min(1300, _sw - 80)
        _h = min(950, _sh - 80)
        _x = max(0, (_sw - _w) // 2)
        _y = max(0, (_sh - _h) // 2)
        self.root.geometry(f"{_w}x{_h}+{_x}+{_y}")
        self.root.configure(bg=COLORS['bg_dark'])
        self.root.minsize(min(1100, _sw - 40), min(700, _sh - 80))

        self.log_queue = queue.Queue()
        self._hard_stop_event = threading.Event()
        self.setup_styles()

        # Codex quota monitor (shared by theme header + Pipeline tab)
        self.quota_monitor = CodexQuotaMonitor(self.root)

        # Theme header bar (optional, from theme JSON) + embedded GPT quota + refresh
        _hdr = _ACTIVE_THEME.get('header', {})
        _hdr_bg = _hdr.get('bg', '#6b1010')
        _hdr_fg = _hdr.get('fg', '#ffffff')
        if _hdr.get('enabled'):
            _hbar = tk.Frame(self.root, bg=_hdr_bg, height=36)
            _hbar.pack(fill=tk.X, side=tk.TOP)
            _hbar.pack_propagate(False)
            # Left side: theme title
            tk.Label(_hbar, text=_hdr.get('text', ''),
                     bg=_hdr_bg, fg=_hdr_fg,
                     font=("Segoe UI", _hdr.get('font_size', 13), "bold")
                     ).pack(side=tk.LEFT, padx=14, pady=6)
            # Right side: quota refresh button
            tk.Button(_hbar, text="↻ Refresh quota",
                      bg=_hdr_bg, fg=_hdr_fg,
                      activebackground=_hdr_bg, activeforeground=_hdr_fg,
                      relief=tk.FLAT, borderwidth=0,
                      font=("Segoe UI", 9),
                      command=lambda: self.quota_monitor.refresh_now(force_api=True)
                      ).pack(side=tk.RIGHT, padx=8, pady=4)
            # Right side: quota compact label (between title and button)
            self._quota_compact_label = tk.Label(_hbar,
                                                 text="GPT quota: loading...",
                                                 bg=_hdr_bg, fg=_hdr_fg,
                                                 font=("Segoe UI", 10))
            self._quota_compact_label.pack(side=tk.RIGHT, padx=10, pady=6)
        else:
            # No theme header — fall back to a thin ttk bar
            _qbar = ttk.Frame(self.root, style="TFrame")
            _qbar.pack(fill=tk.X, side=tk.TOP, padx=6, pady=(4, 0))
            self._quota_compact_label = ttk.Label(_qbar,
                                                  text="GPT quota: loading...",
                                                  style="Dim.TLabel")
            self._quota_compact_label.pack(side=tk.LEFT, padx=6)
            ttk.Button(_qbar, text="↻ Refresh quota", width=16,
                       command=lambda: self.quota_monitor.refresh_now(force_api=True)
                       ).pack(side=tk.RIGHT, padx=6)
        self.quota_monitor.subscribe(self._update_quota_header)

        # ── Chain Mode settings ───────────────────────────────────────────────
        self.chain_trim_frames       = tk.IntVar(value=getattr(config, 'VIDEO_EXTEND_TRIM_FRAMES', 1))
        self.chain_frame_offset      = tk.DoubleVar(value=getattr(config, 'VIDEO_EXTEND_FRAME_OFFSET', 0.5))
        self.chain_mute_audio        = tk.BooleanVar(value=getattr(config, 'VIDEO_EXTEND_MUTE_AUDIO', True))
        self.chain_imggen_heads_only = tk.BooleanVar(value=getattr(config, 'CHAIN_IMGGEN_HEADS_ONLY', True))
        self.chain_max_chain         = tk.IntVar(value=getattr(config, 'VIDEO_EXTEND_MAX_CHAIN', 10))
        self.chain_cascade_recovery  = tk.BooleanVar(value=getattr(config, 'CHAIN_CASCADE_RECOVERY', True))
        self.chain_max_fails         = tk.IntVar(value=getattr(config, 'CHAIN_MAX_SAME_CLIP_FAILS', 3))

        # Notebook with 4 tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.tab_pipeline  = PipelineLauncherTab(self.notebook, self)
        self.tab_control   = ControlPanelTab(self.notebook, self)
        self.tab_veo       = VeoGeneratorTab(self.notebook, self)
        self.tab_settings  = SettingsTab(self.notebook, self)
        self.tab_prompts   = PromptsTab(self.notebook, self)
        self.tab_chat      = ChatTab(self.notebook, self)
        self.tab_claude    = ClaudeChatTab(self.notebook, self)
        self.tab_brainstorm = BrainstormTab(self.notebook, self)
        self.tab_donate    = DonateTab(self.notebook, self)

        self.notebook.add(self.tab_pipeline.frame,   text="  Pipeline  ")
        self.notebook.add(self.tab_control.frame,    text="  Control Panel  ")
        self.notebook.add(self.tab_veo.frame,        text="  VeoNonStop  ")
        self.notebook.add(self.tab_settings.frame,   text="  Settings  ")
        self.notebook.add(self.tab_prompts.frame,    text="  Prompts  ")
        self.notebook.add(self.tab_chat.frame,       text="  GPT Chat  ")
        self.notebook.add(self.tab_claude.frame,     text="  Claude Chat  ")
        self.notebook.add(self.tab_brainstorm.frame, text="  Brainstorm  ")
        self.notebook.add(self.tab_donate.frame,     text="  Donate  ")

        # Start quota monitor after tabs are built (so Pipeline tab can subscribe)
        self.quota_monitor.start()
        self.quota_monitor.refresh_now(force_api=True)

        self.process_log_queue()

        # Fix Ctrl+V/C/X/A/Z on non-Latin keyboard layouts (Russian etc.)
        # Tk maps Ctrl+V to <<Paste>> only for Latin keysym. On Russian layout
        # Ctrl+V sends keycode=86 but keysym='м' — Tk ignores it.
        # Fix: bind_all on KeyRelease, check keycode + Ctrl state, fire virtual event.
        _ENTRY_TYPES = (ttk.Entry, ttk.Combobox, tk.Entry)
        _undo_stacks = {}
        def _get_undo(w):
            wid = str(w)
            if wid not in _undo_stacks:
                _undo_stacks[wid] = []
            return _undo_stacks[wid]
        def _snapshot(w):
            try:
                stack = _get_undo(w)
                stack.append(w.get())
                if len(stack) > 50:
                    stack.pop(0)
            except Exception:
                pass
        def _on_key(event):
            w = event.widget
            is_entry = isinstance(w, _ENTRY_TYPES)
            is_text = isinstance(w, tk.Text)
            if not (is_entry or is_text):
                return
            ctrl = (event.state & 0x4) != 0
            if not ctrl:
                return
            kc = event.keycode
            ks = event.keysym.lower()
            # Only fire if keysym is NOT the expected Latin letter (already handled by Tk)
            if kc == 86 and ks != 'v':    # V → Paste
                if is_entry:
                    _snapshot(w)
                w.event_generate('<<Paste>>')
            elif kc == 67 and ks != 'c':  # C → Copy
                w.event_generate('<<Copy>>')
            elif kc == 88 and ks != 'x':  # X → Cut
                if is_entry:
                    _snapshot(w)
                w.event_generate('<<Cut>>')
            elif kc == 65 and ks != 'a':  # A → Select All
                if is_entry:
                    w.select_range(0, 'end')
                    w.icursor('end')
                elif is_text:
                    w.tag_add('sel', '1.0', 'end-1c')
                    w.mark_set('insert', 'end-1c')
                    w.see('insert')
            elif kc == 90 and ks != 'z':  # Z → Undo
                if is_entry:
                    stack = _get_undo(w)
                    if stack:
                        w.delete(0, 'end')
                        w.insert(0, stack.pop())
                elif is_text:
                    try:
                        w.event_generate('<<Undo>>')
                    except Exception:
                        pass
        root.bind_all('<KeyRelease>', _on_key, '+')
        # Undo for Latin layout too (Tk has no built-in undo for Entry)
        def _kb_undo(e):
            if not isinstance(e.widget, _ENTRY_TYPES):
                return
            stack = _get_undo(e.widget)
            if stack:
                e.widget.delete(0, 'end')
                e.widget.insert(0, stack.pop())
            return 'break'
        for _cls in ('TEntry', 'TCombobox', 'Entry'):
            root.bind_class(_cls, '<Control-z>', _kb_undo)
            root.bind_class(_cls, '<Control-Z>', _kb_undo)
            if sys.platform == 'darwin':
                root.bind_class(_cls, '<Command-z>', _kb_undo)
        # Snapshot on every keystroke for undo history (skip when Ctrl/Cmd held)
        def _on_char(event):
            if not isinstance(event.widget, _ENTRY_TYPES):
                return
            if event.state & 0x4:  # Ctrl held — not a real char input
                return
            if event.char and len(event.char) == 1 and ord(event.char) >= 32:
                _snapshot(event.widget)
        root.bind_all('<Key>', _on_char, '+')
        # Right-click context menu
        def _show_ctx_menu(e):
            w = e.widget
            m = tk.Menu(w, tearoff=0)
            m.add_command(label="Cut",        command=lambda: (_snapshot(w), w.event_generate("<<Cut>>")))
            m.add_command(label="Copy",       command=lambda: w.event_generate("<<Copy>>"))
            m.add_command(label="Paste",      command=lambda: (_snapshot(w), w.event_generate("<<Paste>>")))
            m.add_separator()
            m.add_command(label="Undo",       command=lambda: _kb_undo(type('E', (), {'widget': w})()))
            m.add_command(label="Select All", command=lambda: (w.select_range(0, 'end'), w.icursor('end')))
            m.tk_popup(e.x_root, e.y_root)
        for _cls in ('TEntry', 'TCombobox', 'Entry'):
            root.bind_class(_cls, '<Button-3>', _show_ctx_menu)
            if sys.platform == 'darwin':
                root.bind_class(_cls, '<Button-2>', _show_ctx_menu)

    def _update_quota_header(self, data):
        """Called on main thread with latest quota dict — updates compact header label."""
        if not data or not data.get('ok'):
            err = (data or {}).get('error', 'unknown')
            try:
                self._quota_compact_label.configure(text=f"GPT quota: ✗ {err[:40]}")
            except Exception:
                pass
            return
        try:
            from modules.codex_usage import format_time_delta
            plan = data.get('plan_type', '?')
            p_pct = data.get('primary_pct', 0)
            s_pct = data.get('secondary_pct', 0)
            p_reset = data.get('primary_resets_at', 0)
            s_reset = data.get('secondary_resets_at', 0)
            src = data.get('source', '?')
            now = time.time()
            p_delta = format_time_delta(int(max(0, p_reset - now)))
            s_delta = format_time_delta(int(max(0, s_reset - now)))
            src_tag = '📡' if src == 'api' else ('📂' if src == 'session' else '·')
            def _dot(pct):
                if pct < 50: return '✅'
                if pct < 80: return '⚠'
                return '❌'
            def _circle_elapsed(window_sec, reset_at):
                if not window_sec or not reset_at:
                    return '○'
                elapsed_pct = ((window_sec - max(0, reset_at - now)) / window_sec) * 100
                if elapsed_pct < 20:  return '○'
                if elapsed_pct < 45:  return '◔'
                if elapsed_pct < 70:  return '◑'
                if elapsed_pct < 90:  return '◕'
                return '●'
            p_circle = _circle_elapsed(data.get('primary_window_sec'), p_reset)
            s_circle = _circle_elapsed(data.get('secondary_window_sec'), s_reset)
            txt = (f"GPT {plan} {src_tag} · "
                   f"5h: {_dot(p_pct)} {p_pct}% ▲ {p_delta} {p_circle} · "
                   f"wk: {_dot(s_pct)} {s_pct}% ▲ {s_delta} {s_circle}")
            self._quota_compact_label.configure(text=txt)
        except Exception as e:
            try:
                self._quota_compact_label.configure(text=f"GPT quota: display error: {e}")
            except Exception:
                pass

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure("TFrame", background=COLORS['bg_dark'])
        style.configure("Card.TFrame", background=COLORS['bg_card'])
        style.configure("TLabel", background=COLORS['bg_dark'],
                        foreground=COLORS['text'], font=FONT_MAIN)
        style.configure("Card.TLabel", background=COLORS['bg_card'],
                        foreground=COLORS['text'], font=FONT_MAIN)
        style.configure("Dim.TLabel", background=COLORS['bg_card'],
                        foreground=COLORS['text_dim'], font=FONT_DIM)
        style.configure("Header.TLabel", font=FONT_HEADER,
                        foreground=COLORS['accent'], background=COLORS['bg_dark'])
        style.configure("Section.TLabel", font=FONT_SECTION,
                        foreground=COLORS['accent'], background=COLORS['bg_card'])
        style.configure("Stats.TLabel", font=FONT_MAIN_BOLD,
                        background=COLORS['bg_card'])
        # Buttons — dark theme with readable hover
        style.configure("TButton", background=COLORS['bg_card'],
                        foreground=COLORS['text'], font=FONT_MAIN, padding=6,
                        borderwidth=1, relief="flat")
        style.map("TButton",
                  background=[("active", COLORS['accent']),
                              ("pressed", COLORS['accent']),
                              ("disabled", COLORS['border'])],
                  foreground=[("active", "#ffffff"),
                              ("pressed", "#ffffff"),
                              ("disabled", COLORS['text_muted'])])
        style.configure("Accent.TButton", font=FONT_BUTTON, padding=8,
                        background=COLORS['accent'], foreground="#ffffff")
        style.map("Accent.TButton",
                  background=[("active", COLORS['accent_hover']),
                              ("pressed", COLORS['accent']),
                              ("disabled", COLORS['border'])],
                  foreground=[("active", "#ffffff"),
                              ("pressed", "#ffffff"),
                              ("disabled", COLORS['text_muted'])])
        style.configure("Danger.TButton", font=FONT_BUTTON, padding=8,
                        background="#7a2020", foreground="#ffffff")
        style.map("Danger.TButton",
                  background=[("active", "#a83232"),
                              ("pressed", "#7a2020"),
                              ("disabled", COLORS['border'])],
                  foreground=[("active", "#ffffff"),
                              ("pressed", "#ffffff"),
                              ("disabled", COLORS['text_muted'])])
        style.configure("TCombobox", fieldbackground=COLORS['bg_input'],
                        background=COLORS['bg_input'],
                        foreground=COLORS['text'],
                        arrowcolor=COLORS['text_dim'],
                        borderwidth=0, relief="flat")
        style.map("TCombobox",
                  fieldbackground=[("readonly", COLORS['bg_input'])],
                  foreground=[("readonly", COLORS['text'])])
        style.configure("TRadiobutton", background=COLORS['bg_card'],
                        foreground=COLORS['text'], font=FONT_MAIN)
        style.map("TRadiobutton",
                  background=[("active", COLORS['bg_card'])],
                  foreground=[("active", COLORS['accent'])])
        style.configure("TCheckbutton", background=COLORS['bg_card'],
                        foreground=COLORS['text'], font=FONT_MAIN)
        style.map("TCheckbutton",
                  background=[("active", COLORS['bg_card'])],
                  foreground=[("active", COLORS['accent'])])
        style.configure("Green.Horizontal.TProgressbar",
                        troughcolor=COLORS['bg_input'],
                        background=COLORS['green'], thickness=8)
        style.configure("Custom.Horizontal.TProgressbar",
                        troughcolor=COLORS['bg_input'],
                        background=COLORS['accent'], thickness=8)
        # Notebook tab styling
        style.configure("TNotebook", background=COLORS['bg_dark'], borderwidth=0)
        style.configure("TNotebook.Tab", background=COLORS['bg_card'],
                        foreground=COLORS['text_dim'], font=FONT_TAB,
                        padding=[14, 7])
        style.map("TNotebook.Tab",
                  background=[("selected", COLORS['accent'])],
                  foreground=[("selected", "#ffffff")])

    def process_log_queue(self):
        try:
            for _ in range(50):  # batch up to 50 messages per tick
                message, level, thread_id, tab = self.log_queue.get_nowait()
                self._route_log(message, level, thread_id, tab)
        except queue.Empty:
            pass
        self.root.after(100, self.process_log_queue)

    _SPINNER_CHARS = set('⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏')

    def _route_log(self, message, level, thread_id, tab_target):
        """Route log message to the correct tab's log widget."""
        if tab_target == "pipeline" and hasattr(self.tab_pipeline, 'log_widget'):
            self._write_log(self.tab_pipeline.log_widget, message, level, thread_id)
        elif tab_target == "control" and hasattr(self.tab_control, 'log_widget'):
            stripped = message.strip()
            if stripped and stripped[0] in self._SPINNER_CHARS and hasattr(self.tab_control, 'spinner_lbl'):
                self.tab_control.spinner_lbl.config(text=stripped)
                return
            if '✅' in message and hasattr(self.tab_control, 'spinner_lbl'):
                self.tab_control.spinner_lbl.config(text="")
            self._write_log(self.tab_control.log_widget, message, level, thread_id)
        elif tab_target == "veo" and hasattr(self.tab_veo, 'log_widget'):
            self._write_log(self.tab_veo.log_widget, message, level, thread_id)
        elif tab_target == "brainstorm" and hasattr(self.tab_brainstorm, 'log_widget'):
            self._write_log(self.tab_brainstorm.log_widget, message, level, thread_id)

    def _write_log(self, widget, message, level, thread_id=None):
        ts = datetime.now().strftime("%H:%M:%S")
        prefix = {"INFO": "", "SUCCESS": "[OK]", "ERROR": "[ERR]", "WARNING": "[WARN]", "SYNTHID": "[SynthID]"}.get(level, "")
        thread_str = f"[{thread_id}] " if thread_id is not None else ""
        tag = level.lower() if level.lower() in ("success", "error", "warning", "info", "synthid") else ""
        widget.insert(tk.END, f"[{ts}] {thread_str}{prefix} {message}\n", tag)
        if getattr(widget, '_autoscroll', True):
            widget.see(tk.END)

    def log(self, message, level="INFO", thread_id=None, tab="pipeline"):
        self.log_queue.put((message, level, thread_id, tab))

    @staticmethod
    def _parse_openrouter_choice(choice: str) -> tuple:
        """Разбирает выбор юзера из дропдауна → (реальный_slug, web_search).

        UI-суффикс 'web_off'/'web_on' управляет web search (в chat_director → ':online').
        Дефолт (без суффикса) = enabled (web включён). Возвращает (model_slug, 'enabled'|'disabled').
        """
        choice = (choice or 'openrouter/free').strip()
        web = 'enabled'
        if choice.endswith('web_off'):
            web = 'disabled'
            choice = choice[:-len('web_off')].strip()
        elif choice.endswith('web_on'):
            web = 'enabled'
            choice = choice[:-len('web_on')].strip()
        return choice, web

    def _ensure_moonbridge(self, provider: str, model: str) -> bool:
        """Поднимает Moon Bridge (прокси Codex→chat API) перед запуском пайплайна.

        Проверяет ключ и бинарь, стартует прокси, генерит codex config.toml.
        Возвращает True если всё готово, иначе показывает ошибку и False.

        Args:
            provider: 'deepseek' | 'openrouter'
            model: модель провайдера (deepseek-v4-flash | openrouter/free | ...)
        """
        from tkinter import messagebox
        if provider == 'deepseek':
            key = getattr(config, 'DEEPSEEK_API_KEY', '')
            key_name = 'DEEPSEEK_API_KEY'
            provider_label = 'DeepSeek'
        elif provider == 'openrouter':
            key = getattr(config, 'OPENROUTER_API_KEY', '')
            key_name = 'OPENROUTER_API_KEY'
            provider_label = 'OpenRouter'
        else:
            messagebox.showerror("Неизвестный провайдер", f"GPT_PROVIDER={provider} не поддерживается Moon Bridge.", parent=self.root)
            return False

        if not key:
            messagebox.showerror(
                f"{provider_label} API key",
                f"Не задан {key_name}.\n\nОткройте Settings → впишите ключ {provider_label} "
                f"(поле {key_name}) → Save, затем запустите снова.",
                parent=self.root)
            return False
        try:
            # Обновляем env + reload config чтобы moonbridge_mgr увидел новые значения
            if provider == 'deepseek':
                os.environ['DEEPSEEK_API_KEY'] = key
                os.environ['DEEPSEEK_MODEL'] = model
            elif provider == 'openrouter':
                # Из выбора юзера достаём реальный slug + web_search флаг
                real_model, web = self._parse_openrouter_choice(model)
                os.environ['OPENROUTER_API_KEY'] = key
                os.environ['OPENROUTER_MODEL'] = real_model
                os.environ['OPENROUTER_WEB_SEARCH'] = web
                model = real_model  # для логов
            os.environ['GPT_PROVIDER'] = provider
            importlib.reload(config)
            from modules import moonbridge_mgr as mb
            _web_note = f", web={web}" if provider == 'openrouter' else ""
            self.log(f"Moon Bridge: запуск прокси Codex→{provider_label} ({model}{_web_note})...", "INFO", tab="pipeline")
            # restart=True гарантирует перегенерацию config.yml (модель/web могли смениться
            # с прошлого запуска — ensure_ready без рестарта оставил бы старый конфиг).
            mb.ensure_ready(restart=True)
            self.log(f"Moon Bridge: готов на {mb.base_url()}", "SUCCESS", tab="pipeline")
            return True
        except FileNotFoundError as e:
            messagebox.showerror(
                "Moon Bridge не собран",
                f"{e}\n\nMoon Bridge — это прокси между Codex и chat API провайдерами. "
                f"Соберите его (нужен Go 1.25+):\n\n"
                f"cd moonbridge\ngo build -o moonbridge.exe ./cmd/moonbridge",
                parent=self.root)
            return False
        except Exception as e:
            messagebox.showerror("Moon Bridge", f"Не удалось запустить Moon Bridge:\n{e}", parent=self.root)
            self.log(f"Moon Bridge FAILED: {e}", "ERROR", tab="pipeline")
            return False

    @staticmethod
    def create_card(parent, title=None):
        card = ttk.Frame(parent, style="Card.TFrame", padding=12)
        card.pack(fill=tk.X, pady=4, padx=2)
        if title:
            ttk.Label(card, text=title, style="Section.TLabel").pack(anchor=tk.W)
        return card

    @staticmethod
    def create_log_widget(parent):
        log = scrolledtext.ScrolledText(parent, height=12, bg=COLORS['bg_input'],
                                        fg=COLORS['text'], font=FONT_LOG,
                                        insertbackground=COLORS['text'], relief=tk.FLAT,
                                        borderwidth=0, wrap=tk.WORD, spacing3=2)
        log.pack(fill=tk.BOTH, expand=True, pady=(4, 0))
        log.tag_configure("success", foreground=COLORS['green'])
        log.tag_configure("error", foreground=COLORS['red'])
        log.tag_configure("warning", foreground=COLORS['orange'])
        log.tag_configure("info", foreground=COLORS['blue'])
        log.tag_configure("synthid", foreground=COLORS['pink'])
        # Double-click toggles auto-scroll: first double-click pauses, second resumes and jumps to bottom
        log._autoscroll = True
        def _toggle_autoscroll(event):
            log._autoscroll = not log._autoscroll
            if log._autoscroll:
                log.see(tk.END)
        log.bind("<Double-Button-1>", _toggle_autoscroll)
        log.bind("<Button-1>", lambda e: log.focus_set())

        def _do_copy(text):
            """Commit text to Windows clipboard via root window."""
            root = log.winfo_toplevel()
            root.clipboard_clear()
            root.clipboard_append(text)
            root.update()  # required to flush to Windows clipboard

        def _copy_selection(event=None):
            try:
                sel = log.get(tk.SEL_FIRST, tk.SEL_LAST)
                _do_copy(sel)
            except tk.TclError:
                pass
            return "break"

        def _copy_all(event=None):
            text = log.get("1.0", tk.END).rstrip()
            if text:
                _do_copy(text)
            return "break"

        def _show_context_menu(event):
            menu = tk.Menu(log, tearoff=0, bg=COLORS['bg_card'], fg=COLORS['text'],
                           activebackground=COLORS['accent'], activeforeground='#ffffff',
                           relief=tk.FLAT, borderwidth=1)
            menu.add_command(label="Copy selected  Ctrl+C", command=_copy_selection)
            menu.add_command(label="Copy all",              command=_copy_all)
            menu.add_separator()
            menu.add_command(label="Select all  Ctrl+A",
                             command=lambda: (log.tag_add(tk.SEL, "1.0", tk.END), log.focus_set()))
            menu.add_separator()
            menu.add_command(label="Clear log",
                             command=lambda: log.delete("1.0", tk.END))
            menu.tk_popup(event.x_root, event.y_root)

        log.bind("<Control-c>",      _copy_selection)
        log.bind("<Control-C>",      _copy_selection)
        log.bind("<Control-Insert>", _copy_selection)
        log.bind("<Control-a>",      lambda e: (log.tag_add(tk.SEL, "1.0", tk.END), "break"))
        log.bind("<Control-A>",      lambda e: (log.tag_add(tk.SEL, "1.0", tk.END), "break"))
        log.bind("<Button-3>",       _show_context_menu)
        return log


# ════════════════════════════════════════════════════════════════════
# TAB 1: PIPELINE LAUNCHER
# ════════════════════════════════════════════════════════════════════

class PipelineLauncherTab:
    """Replaces pipeline.bat — visual form for all pipeline settings."""

    def __init__(self, notebook, app: VarAgentGUI):
        self.app = app
        self.root = app.root
        self.frame = ttk.Frame(notebook)
        self.is_running = False

        # Variables (defaults from config)
        self.start_point    = tk.StringVar(value=getattr(config, 'PIPELINE_START_POINT', 'transcribe'))
        self.language       = tk.StringVar(value=getattr(config, 'ASSEMBLYAI_LANGUAGE_CODE', 'ru'))
        self.gemini_model   = tk.StringVar(value=getattr(config, 'GEMINI_MODEL', 'gemini-3.1-pro-preview'))
        self.director_backend = tk.StringVar(value=getattr(config, 'DIRECTOR_BACKEND', 'gpt'))
        self.gpt_model      = tk.StringVar(value=getattr(config, 'GPT_MODEL', 'gpt-5.4'))
        # GPT провайдер: openai (Codex auth) | deepseek | openrouter (API key via Moon Bridge)
        self.gpt_provider     = tk.StringVar(value=getattr(config, 'GPT_PROVIDER', 'openai'))
        self.deepseek_model   = tk.StringVar(value=getattr(config, 'DEEPSEEK_MODEL', 'deepseek-v4-flash'))
        # openrouter_model хранит ЛЕЙБЛ (короткое имя); реальный slug+web по OR_DIRECTOR_LABEL_TO_MV
        _or_init_label = OR_DIRECTOR_MV_TO_LABEL.get(
            (getattr(config, 'OPENROUTER_MODEL', 'openrouter/free'),
             getattr(config, 'OPENROUTER_WEB_SEARCH', 'disabled')),
            OR_DIRECTOR_DISPLAY[0])
        self.openrouter_model = tk.StringVar(value=_or_init_label)
        # Chat director (deepseek|openrouter прямой API): reasoning + max output tokens
        self.chat_reasoning   = tk.StringVar(value=getattr(config, 'CHAT_REASONING_LEVEL', 'medium'))
        self.chat_max_tokens  = tk.IntVar(value=getattr(config, 'CHAT_MAX_TOKENS', 64000))
        # --- Экономия токенов: вынос стиль/негатив блоков (mode: neuro|regex|off) ---
        _sx_mode = getattr(config, 'STYLE_EXTRACT_MODE', 'neuro')
        self.style_extract_neuro = tk.BooleanVar(value=(_sx_mode == 'neuro'))
        self.style_extract_regex = tk.BooleanVar(value=(_sx_mode == 'regex'))
        self.style_extract_backend = tk.StringVar(value=getattr(config, 'STYLE_EXTRACT_BACKEND', '') or 'auto')
        self.gpt_chunk_size = tk.IntVar(value=getattr(config, 'GPT_PASS2_CHUNK_SIZE', 150))
        self.gpt_parallel   = tk.IntVar(value=getattr(config, 'GPT_PASS2_PARALLEL', 6))
        # Claude director (claude_code CLI | claude_api codexhub): модель + chunk pass2.
        # claude_api → CLAUDE_API_MODEL (codexhub kr/*), claude_code → CLAUDE_MODEL (CLI alias).
        self.claude_api_model  = tk.StringVar(value=getattr(config, 'CLAUDE_API_MODEL', 'kr/claude-sonnet-4.6'))
        self.claude_code_model = tk.StringVar(value=getattr(config, 'CLAUDE_MODEL', 'sonnet'))
        self.claude_chunk_size = tk.IntVar(value=getattr(config, 'CLAUDE_API_PASS2_CHUNK_SIZE', 20))
        # rewrite_model хранит ЛЕЙБЛ; реальный spec по REWRITE_LABEL_TO_SPEC
        self.rewrite_model  = tk.StringVar(value=REWRITE_SPEC_TO_LABEL.get(
            getattr(config, 'REWRITE_MODEL', 'gemini:gemini-2.5-flash-lite'), REWRITE_DISPLAY[0]))
        self.direction_mode = tk.StringVar(value="2-pass" if getattr(config, 'GEMINI_TWO_PASS', False) else "1-pass")
        # --- MUSIC (Pass 3 — Suno) ---
        self.music_enabled      = tk.BooleanVar(value=False)
        self.music_provider     = tk.StringVar(value=getattr(config, 'MUSIC_PROVIDER', 'suno'))
        self.music_backend      = tk.StringVar(value=getattr(config, 'MUSIC_DIRECTOR_BACKEND', '') or 'gpt')
        self.music_browser      = tk.StringVar(value=getattr(config, 'SUNO_COOKIE_BROWSER', 'firefox'))
        self.music_model        = tk.StringVar(value=getattr(config, 'SUNO_MODEL', 'chirp-fenix'))
        self.music_volume_db    = tk.IntVar(value=int(getattr(config, 'MUSIC_DEFAULT_VOLUME_DB', -21)))
        self.music_ducking_db   = tk.IntVar(value=int(getattr(config, 'MUSIC_DUCKING_DB', -5)))
        self.music_review_gui   = tk.BooleanVar(value=False)
        self.music_chat_model   = tk.StringVar(value='')  # модель для music chat-backend (openrouter/deepseek)
        # --- Entity overlays (карточки персон/мест из Wikipedia) ---
        self.entity_overlay_enabled = tk.BooleanVar(value=bool(getattr(config, 'ENTITY_OVERLAY_ENABLED', False)))
        self.entity_overlay_max     = tk.IntVar(value=int(getattr(config, 'ENTITY_OVERLAY_MAX', 20)))
        self.entity_overlay_backend = tk.StringVar(value=getattr(config, 'ENTITY_OVERLAY_BACKEND', 'auto'))
        self.clip_mode         = tk.StringVar(value=getattr(config, 'PIPELINE_CLIP_MODE', 'video'))
        self.vislide_interval  = tk.IntVar(value=getattr(config, 'PIPELINE_VISLIDE_INTERVAL', 3))
        self.clip_min       = tk.IntVar(value=getattr(config, 'VIDEO_CLIP_MIN_DURATION', 4))
        self.clip_max       = tk.IntVar(value=getattr(config, 'VIDEO_CLIP_MAX_DURATION', 8))
        self.img_gen        = tk.StringVar(value=getattr(config, 'PIPELINE_IMG_GEN', 'veononstop'))
        self.fastgen_model  = tk.StringVar(value=FASTGEN_KEY_TO_NAME.get(getattr(config, 'FASTGEN_MODEL', 'FLOWER'), getattr(config, 'FASTGEN_MODEL', 'FLOWER')))
        self.fastgen_aspect = tk.StringVar(value=getattr(config, 'FASTGEN_ASPECT_RATIO', 'landscape'))
        self.fastgen_parallel = tk.IntVar(value=getattr(config, 'FASTGEN_MAX_PARALLEL', 4))
        self.fastgen_api_key  = tk.StringVar(value='main')
        self.veo_imggen_mode  = tk.StringVar(value=getattr(config, 'VEONONSTOP_IMGGEN_MODE', 'banana'))
        self.veo_banana_model = tk.StringVar(value=BANANA_KEY_TO_NAME.get(getattr(config, 'VEONONSTOP_BANANA_MODEL', 'GEM_PIX_2'), "Banana Pro"))
        self.video_mode     = tk.StringVar(value=getattr(config, 'PIPELINE_VIDEO_MODE', 'i2v'))
        self.video_engine   = tk.StringVar(value='veononstop')  # veononstop | fastgen_ultra | both
        self._pipe_fu_keys  = tk.StringVar(value='key1')         # key1 | key2 | both  (FU keys in Pipeline tab)
        self._pipe_fu_end   = tk.BooleanVar(value=False)         # FU keyframes end-image (pair mode)
        self.veo_ratio      = tk.StringVar(value=getattr(config, 'VEONONSTOP_ASPECT_RATIO', '16:9'))
        self.veo_parallel   = tk.IntVar(value=getattr(config, 'VEONONSTOP_MAX_PARALLEL', 12))
        self.veo_request_delay    = tk.DoubleVar(value=getattr(config, 'VEONONSTOP_REQUEST_DELAY',    10.0))
        self.story_mode     = tk.StringVar(value=getattr(config, 'STORY_MODE', 'off'))  # off | batch | morph | chain
        self.veo_recaptcha_delay  = tk.DoubleVar(value=getattr(config, 'VEONONSTOP_RECAPTCHA_DELAY',  8.0))
        self.veo_recaptcha_jitter = tk.DoubleVar(value=getattr(config, 'VEONONSTOP_RECAPTCHA_JITTER', 3.0))
        self.veo_max_retries      = tk.IntVar(value=getattr(config, 'VEONONSTOP_MAX_RETRIES', 3))
        self.veo_max_silent_cycles = tk.IntVar(value=getattr(config, 'VEONONSTOP_MAX_SILENT_CYCLES', 3))
        self.veo_fast_censor   = tk.StringVar(value=getattr(config, 'VEONONSTOP_FAST_CENSOR', 'off'))
        self.prompt_mode    = tk.StringVar(value=getattr(config, 'PIPELINE_PROMPT_MODE', 'auto'))
        self.codex_adapt_var = tk.BooleanVar(value=False)
        self.intro_duration = tk.IntVar(value=getattr(config, 'INTRO_BLOCK_DURATION', 30))
        self.intro_clip_min = tk.IntVar(value=getattr(config, 'INTRO_CLIP_MIN_DURATION', 3))
        self.intro_clip_max = tk.IntVar(value=getattr(config, 'INTRO_CLIP_MAX_DURATION', 6))
        self.p1_chunk_threshold = tk.IntVar(value=getattr(config, 'DIRECTOR_PASS1_CHUNK_THRESHOLD', 2400) // 60)
        self.p1_chunk_duration  = tk.IntVar(value=getattr(config, 'DIRECTOR_PASS1_CHUNK_DURATION',  1200) // 60)
        self.render_mode    = tk.StringVar(value=getattr(config, 'PIPELINE_RENDER_MODE', 'fast'))
        self.concat_fps     = tk.IntVar(value=getattr(config, 'VIDEO_FPS', 60))
        self.concat_bitrate = tk.StringVar(value=getattr(config, 'CONCAT_BITRATE', '20M'))
        self.watermark      = tk.StringVar(value=getattr(config, 'PIPELINE_WATERMARK', 'none'))
        self.keep_files     = tk.BooleanVar(value=getattr(config, 'PIPELINE_KEEP_FILES', False))
        self.keep_veo_sound = tk.BooleanVar(value=getattr(config, 'PIPELINE_KEEP_VEO_SOUND', False))
        self.remix_engine   = tk.StringVar(value=getattr(config, 'REMIX_ENGINE', 'kieai'))
        self.image_upscale  = tk.StringVar(value=getattr(config, 'VEONONSTOP_IMAGE_UPSCALE', 'off'))
        self.video_upscale  = tk.BooleanVar(value=getattr(config, 'VEONONSTOP_VIDEO_UPSCALE', False))
        self.subtitles_enabled = tk.BooleanVar(value=False)
        self.subtitles_preset  = tk.StringVar(value='bottom')
        self.subtitles_custom  = tk.BooleanVar(value=False)
        self.subtitles_path    = tk.StringVar(value='')
        self.script_type_var  = tk.StringVar(value="prose")
        self.ref_images: list[Path] = []
        self.ref_mode = tk.StringVar(value="one_for_all")
        self.ref_individual: dict[str, list[Path]] = {}
        _veo_imggen_key_default = (
            os.environ.get('VARAGENT_IMGGEN_KEY_SLOT')
            or os.environ.get('VEONONSTOP_IMGGEN_KEY_SLOT')
            or "1"
        )
        _veo_video_key_default = (
            os.environ.get('VARAGENT_VIDEO_KEY_SLOT')
            or os.environ.get('VEONONSTOP_VIDEO_KEY_SLOT')
            or "1"
        )
        self.veo_imggen_key      = tk.StringVar(value=_veo_imggen_key_default)
        self.veo_video_key       = tk.StringVar(value=_veo_video_key_default)
        # Per-slot BoolVars for multi-key checkboxes (slots 1-4)
        self._imggen_key_checks  = {i: tk.BooleanVar(value=(i == 1)) for i in range(1, 5)}
        self._video_key_checks   = {i: tk.BooleanVar(value=(i == 1)) for i in range(1, 5)}
        self.veo_imggen_parallel = tk.IntVar(value=config.VEONONSTOP_MAX_PARALLEL)
        self.inflight_mode       = tk.BooleanVar(value=False)
        self.skip_preflight      = tk.BooleanVar(value=False)
        self.cover_ref_images: list[Path] = []
        self.logo_path: Optional[Path] = None
        self.logo_mode = tk.StringVar(value="one_for_all")
        self.logo_individual: dict[str, Optional[Path]] = {}
        self.single_prompt_path: Optional[Path] = None
        self.yt_pack_enabled    = tk.BooleanVar(value=False)
        self.yt_pack_languages  = tk.StringVar(value=getattr(config, 'YT_PACK_LANGUAGES', 'ru,en') if not isinstance(getattr(config, 'YT_PACK_LANGUAGES', ''), list) else ','.join(config.YT_PACK_LANGUAGES))
        self.yt_pack_subtitles  = tk.BooleanVar(value=bool(getattr(config, 'YT_PACK_SUBTITLES', True)))
        self.yt_pack_description = tk.BooleanVar(value=bool(getattr(config, 'YT_PACK_DESCRIPTION', True)))
        self.yt_pack_covers     = tk.BooleanVar(value=bool(getattr(config, 'YT_PACK_COVERS', True)))
        self.cover_provider     = tk.StringVar(value=getattr(config, 'YT_PACK_COVER_PROVIDER', 'fastgen'))
        self.cover_model        = tk.StringVar(value=getattr(config, 'YT_PACK_COVER_MODEL', 'GEM_PIX_2'))

        # ── Watermark / fingerprint removal ──────────────────────────────────
        self.audio_clean_enabled   = tk.BooleanVar(value=getattr(config, 'AUDIO_CLEAN_ENABLED',   False))
        self.audio_clean_level     = tk.StringVar(value=getattr(config, 'AUDIO_CLEAN_LEVEL',     'moderate'))
        self.synthid_clean_enabled = tk.BooleanVar(value=getattr(config, 'SYNTHID_CLEAN_ENABLED', False))
        self.synthid_strength      = tk.StringVar(value=getattr(config, 'SYNTHID_STRENGTH',      'moderate'))
        self.synthid_version       = tk.StringVar(value=getattr(config, 'SYNTHID_VERSION',       'v1'))
        self.synthid_save_orig     = tk.BooleanVar(value=getattr(config, 'SYNTHID_SAVE_ORIG',    False))

        # ── Real Photo Stage (archival photo/video insertion) ────────────────
        self.real_photo_enabled = tk.BooleanVar(value=getattr(config, 'REAL_PHOTO_ENABLED', False))
        self.real_photo_target  = tk.IntVar(value=int(getattr(config, 'REAL_PHOTO_RATIO_TARGET', 0.40) * 100))
        self.real_photo_min     = tk.IntVar(value=int(getattr(config, 'REAL_PHOTO_RATIO_MIN',    0.30) * 100))
        self.real_photo_max     = tk.IntVar(value=int(getattr(config, 'REAL_PHOTO_RATIO_MAX',    0.55) * 100))
        _rp_default_sources = getattr(config, 'REAL_PHOTO_SOURCES',
                                      ['wikimedia', 'nasa', 'loc', 'met', 'europeana', 'smithsonian', 'archive'])
        self.real_photo_src_wikimedia   = tk.BooleanVar(value='wikimedia'   in _rp_default_sources)
        self.real_photo_src_nasa        = tk.BooleanVar(value='nasa'        in _rp_default_sources)
        self.real_photo_src_loc         = tk.BooleanVar(value='loc'         in _rp_default_sources)
        self.real_photo_src_met         = tk.BooleanVar(value='met'         in _rp_default_sources)
        self.real_photo_src_getty       = tk.BooleanVar(value='getty'       in _rp_default_sources)
        self.real_photo_src_europeana   = tk.BooleanVar(value='europeana'   in _rp_default_sources)
        self.real_photo_src_smithsonian = tk.BooleanVar(value='smithsonian' in _rp_default_sources)
        self.real_photo_src_rijksmuseum = tk.BooleanVar(value='rijksmuseum' in _rp_default_sources)
        self.real_photo_src_archive     = tk.BooleanVar(value='archive'     in _rp_default_sources)

        self.create_ui()

    # Variables that are UI state, NOT pipeline settings — exclude from presets
    _PRESET_BLACKLIST = frozenset({
        '_preset_var', 'script_type_var', 'codex_adapt_var',
        'subtitles_enabled', 'subtitles_preset', 'subtitles_custom', 'subtitles_path',
        'ref_mode', 'logo_mode', 'sg_adapt',
    })

    def _defaults_map(self):
        """Auto-discover all tk.*Var attributes → {name: var} for presets/defaults.
        Any new tk variable added to __init__ is automatically included."""
        result = {}
        for k, v in self.__dict__.items():
            if k.startswith('_'):
                continue
            if not isinstance(v, (tk.StringVar, tk.IntVar, tk.BooleanVar, tk.DoubleVar)):
                continue
            if k in self._PRESET_BLACKLIST:
                continue
            result[k] = v
        return result

    # ── Per-file generation snapshot (очередь = серия одиночных запусков) ─────
    _TKVAR_TYPES = (tk.StringVar, tk.IntVar, tk.BooleanVar, tk.DoubleVar)

    def _snapshot_gen_settings(self) -> dict:
        """Снимок ВСЕХ tk-переменных, влияющих на запуск генерации.

        Авто-обнаружение через self.__dict__ (как _defaults_map), но БЕЗ
        preset-blacklist — для слепка генерации нужны и ref_mode/logo_mode/
        subtitles/sg_adapt. Плюс группа chain_* настроек живёт на self.app.
        Любая новая tk-переменная подхватывается сама — ручного списка нет.
        Вызывать только из главного потока (tkinter не потокобезопасен).
        """
        snap = {'self': {}, 'app': {}}
        for k, v in self.__dict__.items():
            if k.startswith('_'):
                continue
            if isinstance(v, self._TKVAR_TYPES):
                try:
                    snap['self'][k] = v.get()
                except Exception:
                    pass
        # chain_* настройки Chain Mode читаются из env как self.app.chain_*
        for k, v in self.app.__dict__.items():
            if not k.startswith('chain_'):
                continue
            if isinstance(v, self._TKVAR_TYPES):
                try:
                    snap['app'][k] = v.get()
                except Exception:
                    pass
        return snap

    def _apply_gen_snapshot(self, snap: dict):
        """Восстановить tk-переменные из снимка. Только из главного потока.

        Трогает лишь ключи, реально присутствующие в снимке — переменные, не
        попавшие в слепок, не сбрасываются."""
        for k, val in snap.get('self', {}).items():
            var = self.__dict__.get(k)
            if isinstance(var, self._TKVAR_TYPES):
                try:
                    var.set(val)
                except Exception:
                    pass
        for k, val in snap.get('app', {}).items():
            var = self.app.__dict__.get(k)
            if isinstance(var, self._TKVAR_TYPES):
                try:
                    var.set(val)
                except Exception:
                    pass

    # ── Presets ────────────────────────────────────────────────────────────

    def _load_presets_file(self) -> dict:
        if PRESETS_FILE.exists():
            try:
                return json.loads(PRESETS_FILE.read_text(encoding='utf-8'))
            except Exception:
                pass
        return {}

    def _save_presets_file(self, data: dict):
        PRESETS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

    def _refresh_preset_list(self):
        names = sorted(self._load_presets_file().keys())
        self._preset_cb['values'] = names

    def _save_preset(self):
        name = self._preset_var.get().strip()
        if not name:
            name = simpledialog.askstring("Save Preset", "Preset name:", parent=self.left)
            if not name:
                return
            name = name.strip()
        if not name:
            return
        data = self._load_presets_file()
        snapshot = {}
        for k, var in self._defaults_map().items():
            v = var.get()
            if isinstance(v, bool):
                snapshot[k] = v
            elif isinstance(v, (int, float)):
                snapshot[k] = v
            else:
                snapshot[k] = str(v)
        data[name] = snapshot
        self._save_presets_file(data)
        self._preset_var.set(name)
        self._refresh_preset_list()
        self.app.log(f"Preset saved: {name}", "SUCCESS")

    def _apply_preset(self, _event=None):
        name = self._preset_var.get().strip()
        if not name:
            return
        data = self._load_presets_file()
        preset = data.get(name)
        if not preset:
            return
        dmap = self._defaults_map()
        for k, var in dmap.items():
            if k not in preset:
                continue
            val = preset[k]
            try:
                var.set(val)
            except Exception:
                pass
        # Backward compat: 'both' → 'all'
        if self.veo_video_key.get() == 'both':
            self.veo_video_key.set('all')
        if self.veo_imggen_key.get() == 'both':
            self.veo_imggen_key.set('all')
        self.app.log(f"Preset loaded: {name}", "SUCCESS")
        if hasattr(self, 'preset_ind_listbox'):
            self._refresh_preset_ind_list()

    def _delete_preset(self):
        name = self._preset_var.get().strip()
        if not name:
            return
        data = self._load_presets_file()
        if name not in data:
            return
        if not messagebox.askyesno("Delete Preset", f"Delete preset '{name}'?", parent=self.left):
            return
        del data[name]
        self._save_presets_file(data)
        self._preset_var.set('')
        self._refresh_preset_list()
        self.app.log(f"Preset deleted: {name}", "SUCCESS")

    def _openrouter_chat_defaults(self, d: dict) -> dict:
        """Лейбл openrouter_model → реальный slug + web/reasoning/max_tokens для .env."""
        _real, _web = OR_DIRECTOR_LABEL_TO_MV.get(
            d.get('openrouter_model', ''), ('openrouter/free', 'disabled'))
        return {
            'OPENROUTER_MODEL':     _real,
            'OPENROUTER_WEB_SEARCH': _web,
            'CHAT_REASONING_LEVEL':  str(d.get('chat_reasoning', 'medium')),
            'CHAT_MAX_TOKENS':       str(d.get('chat_max_tokens', 8000)),
        }

    def _save_defaults(self):
        """Сохраняет текущие настройки пайплайна в agent/.env"""
        d = {k: v.get() for k, v in self._defaults_map().items()}

        def _b(val): return 'true' if val else 'false'

        updates = {
            'PIPELINE_START_POINT':      str(d['start_point']),
            'ASSEMBLYAI_LANGUAGE_CODE':  str(d['language']),
            'GEMINI_TWO_PASS':           'true' if d['direction_mode'] == '2-pass' else 'false',
            'DIRECTOR_BACKEND':          str(d['director_backend']),
            'GPT_MODEL':                 str(d['gpt_model']),
            'GPT_PROVIDER':              str(d['gpt_provider']),
            'DEEPSEEK_MODEL':            str(d['deepseek_model']),
            **self._openrouter_chat_defaults(d),
            'GPT_PASS2_CHUNK_SIZE':      str(d['gpt_chunk_size']),
            'GPT_PASS2_PARALLEL':        str(d['gpt_parallel']),
            'PIPELINE_CLIP_MODE':        str(d['clip_mode']),
            'PIPELINE_VISLIDE_INTERVAL': str(d['vislide_interval']),
            'VIDEO_CLIP_MIN_DURATION':   str(d['clip_min']),
            'VIDEO_CLIP_MAX_DURATION':   str(d['clip_max']),
            'PIPELINE_IMG_GEN':          str(d['img_gen']),
            'FASTGEN_MODEL':             FASTGEN_NAME_TO_KEY.get(d['fastgen_model'], d['fastgen_model']),
            'FASTGEN_ASPECT_RATIO':      str(d['fastgen_aspect']),
            'FASTGEN_MAX_PARALLEL':      str(d['fastgen_parallel']),
            'VEONONSTOP_IMGGEN_MODE':    str(d['veo_imggen_mode']),
            'VEONONSTOP_BANANA_MODEL':   BANANA_NAME_TO_KEY.get(d['veo_banana_model'], 'GEM_PIX_2'),
            'PIPELINE_VIDEO_MODE':       str(d['video_mode']),
            'VEONONSTOP_ASPECT_RATIO':   str(d['veo_ratio']),
            'VEONONSTOP_MAX_PARALLEL':        str(d['veo_parallel']),
            'VEONONSTOP_REQUEST_DELAY':       str(d['veo_request_delay']),
            'VEONONSTOP_RECAPTCHA_DELAY':     str(d['veo_recaptcha_delay']),
            'VEONONSTOP_RECAPTCHA_JITTER':    str(d['veo_recaptcha_jitter']),
            'VEONONSTOP_MAX_RETRIES':         str(d['veo_max_retries']),
            'VEONONSTOP_MAX_SILENT_CYCLES':   str(d['veo_max_silent_cycles']),
            'VEONONSTOP_FAST_CENSOR':         str(d['veo_fast_censor']),
            'VARAGENT_IMGGEN_KEY_SLOT':       str(d['veo_imggen_key']),
            'VARAGENT_VIDEO_KEY_SLOT':        str(d['veo_video_key']),
            'VEONONSTOP_IMGGEN_KEY_SLOT':     str(d['veo_imggen_key']),
            'VEONONSTOP_VIDEO_KEY_SLOT':      str(d['veo_video_key']),
            'VEONONSTOP_IMGGEN_MAX_PARALLEL': str(d['veo_imggen_parallel']),
            'PIPELINE_INFLIGHT_MODE':         _b(d['inflight_mode']),
            'PIPELINE_PROMPT_MODE':      str(d['prompt_mode']),
            'PIPELINE_RENDER_MODE':      str(d['render_mode']),
            'PIPELINE_WATERMARK':        str(d['watermark']),
            'PIPELINE_KEEP_FILES':       _b(d['keep_files']),
            'PIPELINE_KEEP_VEO_SOUND':   _b(d['keep_veo_sound']),
            'REMIX_ENGINE':              str(d['remix_engine']),
            'VEONONSTOP_IMAGE_UPSCALE':  str(d['image_upscale']),
            'VEONONSTOP_VIDEO_UPSCALE':  _b(d['video_upscale']),
            'INTRO_BLOCK_DURATION':               str(d['intro_duration']),
            'INTRO_CLIP_MIN_DURATION':            str(d['intro_clip_min']),
            'INTRO_CLIP_MAX_DURATION':            str(d['intro_clip_max']),
            'DIRECTOR_PASS1_CHUNK_THRESHOLD':     str(d['p1_chunk_threshold'] * 60),
            'DIRECTOR_PASS1_CHUNK_DURATION':      str(d['p1_chunk_duration']  * 60),
            'REWRITE_MODEL':             REWRITE_LABEL_TO_SPEC.get(d.get('rewrite_model', ''), 'gemini:gemini-2.5-flash-lite'),
            'GEMINI_MODEL':              str(d.get('gemini_model', '')),
            'VIDEO_FPS':                 str(d.get('concat_fps', 60)),
            'CONCAT_BITRATE':            str(d.get('concat_bitrate', '20M')),
            'YT_PACK_COVER_PROVIDER':    str(d.get('cover_provider', 'fastgen')),
            'YT_PACK_COVER_MODEL':       str(d.get('cover_model', 'GEM_PIX_2')),
            'YT_PACK_CONTENT_MODEL':     str(d.get('yt_pack_content_model', '')),
            'YT_PACK_LANGUAGES':         str(d['yt_pack_languages']),
            'YT_PACK_SUBTITLES':         _b(d['yt_pack_subtitles']),
            'YT_PACK_DESCRIPTION':       _b(d['yt_pack_description']),
            'YT_PACK_COVERS':            _b(d['yt_pack_covers']),
        }

        try:
            lines = AGENT_ENV_FILE.read_text(encoding='utf-8').splitlines(keepends=True)
            remaining = set(updates.keys())
            new_lines = []
            for line in lines:
                stripped = line.rstrip('\r\n')
                if '=' in stripped and not stripped.startswith('#'):
                    key = stripped.split('=', 1)[0].strip()
                    if key in updates:
                        eol = '\r\n' if line.endswith('\r\n') else '\n'
                        new_lines.append(f'{key}={updates[key]}{eol}')
                        remaining.discard(key)
                        continue
                new_lines.append(line)
            if remaining:
                eol = '\r\n' if lines and lines[0].endswith('\r\n') else '\n'
                new_lines.append(f'{eol}# Pipeline GUI extras{eol}')
                for key in sorted(remaining):
                    new_lines.append(f'{key}={updates[key]}{eol}')
            AGENT_ENV_FILE.write_text(''.join(new_lines), encoding='utf-8')
            # Push saved values into os.environ so config.py picks them up on reload
            for key, val in updates.items():
                os.environ[key] = val
            importlib.reload(config)
            self.app.log("Pipeline defaults saved to .env", "SUCCESS", tab="pipeline")
        except Exception as e:
            self.app.log(f"Failed to save defaults: {e}", "ERROR", tab="pipeline")

    def create_ui(self):
        # Two columns: left = form, right = summary + log
        # PanedWindow для перемещаемого разделителя (tk.PanedWindow для minsize support)
        content = tk.PanedWindow(self.frame, orient=tk.HORIZONTAL,
                                 bg=COLORS['bg_dark'], bd=0, sashwidth=4,
                                 sashrelief=tk.RAISED, showhandle=False)
        content.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        # LEFT: scrollable settings
        left_outer = ttk.Frame(content)

        canvas = tk.Canvas(left_outer, bg=COLORS['bg_dark'], highlightthickness=0)
        scrollbar = ttk.Scrollbar(left_outer, orient=tk.VERTICAL, command=canvas.yview)
        self.left = ttk.Frame(canvas)
        self.left.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas_window = canvas.create_window((0, 0), window=self.left, anchor=tk.NW)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        # Resize canvas window when parent frame resizes
        def _on_left_resize(event):
            canvas.itemconfig(canvas_window, width=event.width - scrollbar.winfo_reqwidth())
        left_outer.bind('<Configure>', _on_left_resize)
        # mousewheel: only active while mouse is inside this canvas
        _mw = lambda e: canvas.yview_scroll(-1 * (e.delta // 120), "units")
        canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", _mw))
        canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))

        # Combobox/Spinbox: колесо мыши НЕ меняет значение (защита от случайной смены
        # настройки при прокрутке колонки) — вместо этого скроллит родительский Canvas.
        def _wheel_redirect(event):
            w = event.widget
            while w is not None:
                if isinstance(w, tk.Canvas):
                    w.yview_scroll(-1 * (event.delta // 120), "units")
                    break
                w = getattr(w, 'master', None)
            return "break"
        _root = canvas.winfo_toplevel()
        for _cls in ('TCombobox', 'TSpinbox', 'Spinbox'):
            _root.bind_class(_cls, '<MouseWheel>', _wheel_redirect)

        # RIGHT: static panels + expandable log
        right = ttk.Frame(content)

        self._build_form()
        self._build_right(right)

        # Add panels to PanedWindow (left min 350px, right expandable)
        content.add(left_outer, minsize=350, sticky='nsew')
        content.add(right, minsize=400, sticky='nsew')

        # Dynamic VeoNonStop key labels + spinbox limits (background API fetch)
        self.veo_video_key.trace_add('write', self._on_veo_vid_key_changed)
        self.veo_imggen_key.trace_add('write', self._on_veo_img_key_changed)
        # Sync checkboxes when StringVar changes externally (preset load etc.)
        def _sync_img_checks(*_):
            self._sel_to_checks(self.veo_imggen_key.get(), self._imggen_key_checks)
        def _sync_vid_checks(*_):
            self._sel_to_checks(self.veo_video_key.get(), self._video_key_checks)
        self.veo_imggen_key.trace_add('write', _sync_img_checks)
        self.veo_video_key.trace_add('write', _sync_vid_checks)
        _sync_img_checks()
        _sync_vid_checks()
        self._clamping = False
        self.veo_parallel.trace_add('write', self._clamp_vid_workers)
        self.veo_imggen_parallel.trace_add('write', self._clamp_img_workers)
        self._bind_workers_clamp()
        threading.Thread(target=self._fetch_veo_key_labels, daemon=True).start()

    def _fetch_veo_key_labels(self):
        """Background: query get_account_info() per key, update labels + limits incrementally."""
        import time
        try:
            from modules.veononstop import VeoNonStopClient
        except Exception:
            return
        failed = []
        # Per-key base URL: slot '1'..'4' -> config.VEONONSTOP_API_BASE[_N]
        def _base_for_slot(s: str) -> str:
            attr = 'VEONONSTOP_API_BASE' if s == '1' else f'VEONONSTOP_API_BASE_{s}'
            return getattr(config, attr, config.VEONONSTOP_API_BASE)
        for _slot, _api_key, _name, _has in self._all_veo_keys:
            if not _has:
                continue
            _base = _base_for_slot(_slot)
            ok = False
            for _attempt in range(3):
                try:
                    c = VeoNonStopClient(api_key=_api_key, base_url=_base)
                    acc = c.get_account_info()
                    plan = acc.get('plan', '?')
                    ct = acc.get('concurrent_tasks', '?')
                    # Fetch active tasks count
                    _active = '?'
                    try:
                        import requests as _req
                        _u = _req.get(f"{c.base_url}/account/usage", headers=c.headers, timeout=10)
                        if _u.status_code == 200:
                            _active = _u.json().get('data', {}).get('active_tasks', '?')
                    except Exception:
                        pass
                    if _name in (f'Key{_slot}', ''):
                        label = f"{plan} ({_active}/{ct})"
                    else:
                        label = f"{_name} \u00b7 {plan} ({_active}/{ct})"
                    limit = int(ct) if str(ct).isdigit() else 0
                    self.root.after(0, self._apply_single_key, _slot, label, limit)
                    ok = True
                    break
                except Exception:
                    time.sleep(2)
            if not ok:
                failed.append((_slot, _api_key, _name))
        # Final retry for stubborn keys
        for _slot, _api_key, _name in failed:
            try:
                time.sleep(5)
                c = VeoNonStopClient(api_key=_api_key, base_url=_base_for_slot(_slot))
                acc = c.get_account_info()
                ct = acc.get('concurrent_tasks', '?')
                plan = acc.get('plan', '?')
                _active = '?'
                try:
                    import requests as _req
                    _u = _req.get(f"{c.base_url}/account/usage", headers=c.headers, timeout=10)
                    if _u.status_code == 200:
                        _active = _u.json().get('data', {}).get('active_tasks', '?')
                except Exception:
                    pass
                label = f"{_name} \u00b7 {plan} ({_active}/{ct})" if _name not in (f'Key{_slot}', '') else f"{plan} ({_active}/{ct})"
                limit = int(ct) if str(ct).isdigit() else 0
                self.root.after(0, self._apply_single_key, _slot, label, limit)
            except Exception:
                pass

    def _apply_single_key(self, slot: str, label: str, limit: int):
        """Apply label + limit for one key, then recalc spinboxes."""
        for rb_dict in (self._veo_key_rbs_video, self._veo_key_rbs_img):
            rb = rb_dict.get(slot)
            if rb:
                rb.configure(text=label)
        self._veo_key_limits[slot] = limit
        self._on_veo_vid_key_changed()
        self._on_veo_img_key_changed()

    def _apply_veo_key_labels(self, labels: dict):
        """Apply dynamic labels to radiobuttons (main thread)."""
        for slot, text in labels.items():
            for rb_dict in (self._veo_key_rbs_video, self._veo_key_rbs_img):
                rb = rb_dict.get(slot)
                if rb:
                    rb.configure(text=text)

    def _apply_veo_key_limits(self, limits: dict):
        """Store per-key concurrent_tasks limits, update spinbox."""
        self._veo_key_limits = limits
        self._on_veo_vid_key_changed()
        self._on_veo_img_key_changed()
        # Also refresh Finalize panel parallel counts if it's built
        try:
            self.app.tab_control._refresh_fin_vid_par()
            self.app.tab_control._refresh_fin_img_par()
        except Exception:
            pass

    def _checks_to_sel(self, checks: dict) -> str:
        """Convert {1: BoolVar, ...} to comma-separated slot string e.g. '1,3'."""
        selected = [str(i) for i in sorted(checks) if checks[i].get()]
        if not selected:
            # Ensure at least one key selected — fallback to key1
            checks[1].set(True)
            return '1'
        return ','.join(selected)

    def _sel_to_checks(self, sel: str, checks: dict):
        """Apply selection string back to BoolVars."""
        active = _veo_sel_to_active(sel)
        for i, bv in checks.items():
            bv.set(i in active)

    def _update_quota_pipeline(self, data):
        """Called on main thread with latest quota dict — updates detailed Pipeline tab block."""
        def _color_for(pct):
            if pct < 50:
                return '#3cb371'  # green
            if pct < 80:
                return '#ffa500'  # orange
            return '#ff4444'      # red

        if not data or not data.get('ok'):
            err = (data or {}).get('error', 'unknown')
            try:
                self._gpt_plan_lbl.configure(text=f"✗ {err[:60]}")
                self._gpt_5h_val.configure(text="—", fg=COLORS['text'])
                self._gpt_wk_val.configure(text="—", fg=COLORS['text'])
            except Exception:
                pass
            return
        try:
            from modules.codex_usage import format_time_delta
            plan = data.get('plan_type', '?')
            p_pct = data.get('primary_pct', 0)
            s_pct = data.get('secondary_pct', 0)
            p_reset = data.get('primary_resets_at', 0)
            s_reset = data.get('secondary_resets_at', 0)
            src = data.get('source', '?')
            now = time.time()
            p_delta = format_time_delta(int(max(0, p_reset - now)))
            s_delta = format_time_delta(int(max(0, s_reset - now)))
            src_label = {
                'api': '📡 live',
                'session': '📂 session',
                'session_fallback': '⚠ stale',
            }.get(src, src)
            self._gpt_plan_lbl.configure(text=f"Plan: {plan}  ·  {src_label}")
            def _circle_elapsed(window_sec, reset_at):
                if not window_sec or not reset_at:
                    return '○'
                elapsed_pct = ((window_sec - max(0, reset_at - now)) / window_sec) * 100
                if elapsed_pct < 20:  return '○'
                if elapsed_pct < 45:  return '◔'
                if elapsed_pct < 70:  return '◑'
                if elapsed_pct < 90:  return '◕'
                return '●'
            p_circle = _circle_elapsed(data.get('primary_window_sec'), p_reset)
            s_circle = _circle_elapsed(data.get('secondary_window_sec'), s_reset)
            self._gpt_5h_val.configure(text=f"{p_pct}% ▲ {p_delta} {p_circle}", fg=_color_for(p_pct))
            self._gpt_wk_val.configure(text=f"{s_pct}% ▲ {s_delta} {s_circle}", fg=_color_for(s_pct))
        except Exception as e:
            try:
                self._gpt_plan_lbl.configure(text=f"display error: {e}")
            except Exception:
                pass

    def _on_imggen_key_check(self, *_):
        sel = self._checks_to_sel(self._imggen_key_checks)
        self.veo_imggen_key.set(sel)

    def _on_video_key_check(self, *_):
        sel = self._checks_to_sel(self._video_key_checks)
        self.veo_video_key.set(sel)

    def _calc_key_total(self, slot_var):
        """Calculate total concurrent_tasks for given key slot variable."""
        if not self._veo_key_limits:
            return 0
        slot = slot_var.get()
        if slot in ('both', 'all'):
            return sum(self._veo_key_limits.get(s, 0) for s in ('1', '2', '3', '4'))
        if ',' in slot:
            return sum(self._veo_key_limits.get(s.strip(), 0) for s in slot.split(','))
        return self._veo_key_limits.get(slot, 0)

    def _on_veo_vid_key_changed(self, *_):
        total = self._calc_key_total(self.veo_video_key)
        if total <= 0:
            return
        self._vid_workers_max = total
        self._vid_workers_spinbox.configure(to=total)
        self._clamping = True
        self.veo_parallel.set(total)
        self._clamping = False

    def _on_veo_img_key_changed(self, *_):
        total = self._calc_key_total(self.veo_imggen_key)
        if total <= 0:
            return
        self._img_workers_max = total
        self._img_workers_spinbox.configure(to=total)
        self._clamping = True
        self.veo_imggen_parallel.set(total)
        self._clamping = False

    def _clamp_vid_workers(self, *_):
        if self._clamping:
            return
        mx = getattr(self, '_vid_workers_max', 0)
        if mx <= 0:
            return
        try:
            val = int(self._vid_workers_spinbox.get())
        except (ValueError, tk.TclError):
            return
        if val > mx:
            self._clamping = True
            self.veo_parallel.set(mx)
            self._clamping = False

    def _clamp_img_workers(self, *_):
        if self._clamping:
            return
        mx = getattr(self, '_img_workers_max', 0)
        if mx <= 0:
            return
        try:
            val = int(self._img_workers_spinbox.get())
        except (ValueError, tk.TclError):
            return
        if val > mx:
            self._clamping = True
            self.veo_imggen_parallel.set(mx)
            self._clamping = False

    def _bind_workers_clamp(self):
        """Bind FocusOut/Return/KeyRelease on workers spinboxes to enforce key limits."""
        for sb, clamp_fn in [(self._vid_workers_spinbox, self._clamp_vid_workers),
                             (self._img_workers_spinbox, self._clamp_img_workers)]:
            sb.bind('<FocusOut>', lambda e, f=clamp_fn: f())
            sb.bind('<Return>', lambda e, f=clamp_fn: f())
            sb.bind('<KeyRelease>', lambda e, f=clamp_fn: f())

    def _on_music_toggle(self):
        """Показывает/скрывает подменю настроек музыки по чекбоксу."""
        sub = getattr(self, '_music_sub', None)
        if sub is None:
            return
        if self.music_enabled.get():
            sub.pack(fill=tk.X, pady=2)
        else:
            sub.pack_forget()

    def _build_form(self):
        # Key labels for VeoNonStop key selectors (computed once for all cards)
        # (slot, api_key_value, label, has_key)
        self._all_veo_keys = [
            ('1', config.VEONONSTOP_API_KEY,
             getattr(config, 'VEONONSTOP_KEY1_NAME', 'Key1'), bool(config.VEONONSTOP_API_KEY)),
            ('2', getattr(config, 'VEONONSTOP_API_KEY_2', ''),
             getattr(config, 'VEONONSTOP_KEY2_NAME', 'Key2'), bool(getattr(config, 'VEONONSTOP_API_KEY_2', ''))),
            ('3', getattr(config, 'VEONONSTOP_API_KEY_3', ''),
             getattr(config, 'VEONONSTOP_KEY3_NAME', 'Key3'), bool(getattr(config, 'VEONONSTOP_API_KEY_3', ''))),
            ('4', getattr(config, 'VEONONSTOP_API_KEY_4', ''),
             getattr(config, 'VEONONSTOP_KEY4_NAME', 'Key4'), bool(getattr(config, 'VEONONSTOP_API_KEY_4', ''))),
        ]
        self._veo_key_rbs_video = {}
        self._veo_key_rbs_img = {}
        self._veo_key_limits = {}
        _has_multi = sum(1 for _, _, _, h in self._all_veo_keys if h) > 1

        # ── Preset selector ──
        pcard = self.app.create_card(self.left, "Preset")
        prow = ttk.Frame(pcard, style="Card.TFrame")
        prow.pack(fill=tk.X, pady=2, padx=(0, 4))  # 4px отступ справа для scrollbar
        self._preset_var = tk.StringVar()
        self._preset_cb = ttk.Combobox(prow, textvariable=self._preset_var, state='normal')
        self._preset_cb.pack(fill=tk.X)  # без expand=True — не растягиваем за границы
        self._preset_cb.bind('<<ComboboxSelected>>', self._apply_preset)
        # Save + Del row UNDER the combobox
        pbtn_row = ttk.Frame(pcard, style="Card.TFrame")
        pbtn_row.pack(fill=tk.X, pady=(2, 0))
        ttk.Button(pbtn_row, text="Save", command=self._save_preset).pack(side=tk.LEFT, padx=(0, 2))
        ttk.Button(pbtn_row, text="Del", command=self._delete_preset).pack(side=tk.LEFT)
        self._refresh_preset_list()

        # Start Point + GPT Quota row (horizontal: two cards side-by-side)
        _sp_row = ttk.Frame(self.left, style="TFrame")
        _sp_row.pack(fill=tk.X, pady=4, padx=2)

        card = ttk.Frame(_sp_row, style="Card.TFrame", padding=12)
        card.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 4))
        ttk.Label(card, text="Start Point", style="Section.TLabel").pack(anchor=tk.W)
        ttk.Radiobutton(card, text="From audio", variable=self.start_point,
                        value="audio", command=self._on_start_point_change).pack(anchor=tk.W)
        ttk.Radiobutton(card, text="From script (to audio)", variable=self.start_point,
                        value="script_tts", command=self._on_start_point_change).pack(anchor=tk.W)
        ttk.Radiobutton(card, text="From script (no audio)", variable=self.start_point,
                        value="script_no_audio", command=self._on_start_point_change).pack(anchor=tk.W)
        # ── Audio WM Remover ─────────────────────────────────────────────────
        _ac_fg = COLORS['text'] if _audio_installed() else COLORS['text_muted']
        self._audio_clean_cb = tk.Checkbutton(
            card, text="Audio WM cleaner",
            variable=self.audio_clean_enabled,
            bg=COLORS['bg_card'], fg=COLORS['text_muted'],
            selectcolor=COLORS['bg_card'],
            activebackground=COLORS['bg_card'],
            activeforeground=COLORS['text'],
            bd=0, highlightthickness=0,
            state=tk.DISABLED,
        )
        self._audio_clean_cb.pack(anchor=tk.W, pady=(6, 0))
        _ac_lvl_row = ttk.Frame(card, style="Card.TFrame")
        _ac_lvl_row.pack(anchor=tk.W, padx=(18, 0))
        ttk.Combobox(_ac_lvl_row, textvariable=self.audio_clean_level,
                     values=['gentle', 'moderate', 'aggressive', 'extreme'],
                     width=12, state='disabled').pack(side=tk.LEFT)
        ttk.Button(_ac_lvl_row, text="?", width=2, state='disabled',
                   command=lambda: messagebox.showinfo(
                       "Audio WM Cleaner — уровни",
                       "\n\n".join(f"{l}:\n  {d}" for l, d in _WM_AUDIO_LEVELS),
                       parent=self.root)).pack(side=tk.LEFT, padx=(3, 0))

        # Script type (shown only for script_no_audio)
        self.type_row = ttk.Frame(card, style="Card.TFrame")
        ttk.Label(self.type_row, text="Type:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Radiobutton(self.type_row, text="Prose", variable=self.script_type_var, value="prose").pack(side=tk.LEFT, padx=6)
        ttk.Radiobutton(self.type_row, text="Screenplay", variable=self.script_type_var, value="screenplay").pack(side=tk.LEFT)

        # GPT Quota detailed card (right side)
        _qcard = ttk.Frame(_sp_row, style="Card.TFrame", padding=12)
        _qcard.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(4, 0))
        ttk.Label(_qcard, text="GPT Quota", style="Section.TLabel").pack(anchor=tk.W)
        self._gpt_plan_lbl = ttk.Label(_qcard, text="loading...", style="Card.TLabel")
        self._gpt_plan_lbl.pack(anchor=tk.W, pady=(4, 0))
        self._gpt_5h_title = ttk.Label(_qcard, text="Session limit (5h):", style="Dim.TLabel")
        self._gpt_5h_title.pack(anchor=tk.W, pady=(6, 0))
        # Use tk.Label for value rows — reliable foreground color control
        self._gpt_5h_val = tk.Label(_qcard, text="—",
                                    bg=COLORS['bg_card'], fg=COLORS['text'],
                                    font=FONT_DIM, anchor=tk.W)
        self._gpt_5h_val.pack(anchor=tk.W, fill=tk.X)
        self._gpt_wk_title = ttk.Label(_qcard, text="Weekly limit:", style="Dim.TLabel")
        self._gpt_wk_title.pack(anchor=tk.W, pady=(4, 0))
        self._gpt_wk_val = tk.Label(_qcard, text="—",
                                    bg=COLORS['bg_card'], fg=COLORS['text'],
                                    font=FONT_DIM, anchor=tk.W)
        self._gpt_wk_val.pack(anchor=tk.W, fill=tk.X)
        # Subscribe to quota updates
        self.app.quota_monitor.subscribe(self._update_quota_pipeline)

        # Transcription + Direction
        card = self.app.create_card(self.left, "Transcription + Direction")
        self.lang_row = ttk.Frame(card, style="Card.TFrame")
        row = self.lang_row
        row.pack(fill=tk.X, pady=2)
        ttk.Label(row, text="Language:", style="Card.TLabel").pack(side=tk.LEFT)
        langs = ['ru', 'en', 'es', 'de', 'fr', 'it', 'pt', 'zh', 'pl']
        lang_cb = ttk.Combobox(row, textvariable=self.language, values=langs, width=5, state='readonly')
        lang_cb.pack(side=tk.LEFT, padx=5)

        # --- Director selector (своя строка) ---
        row_director = ttk.Frame(card, style="Card.TFrame")
        row_director.pack(fill=tk.X, pady=2)
        ttk.Label(row_director, text="Director:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Combobox(row_director, textvariable=self.director_backend,
                     values=['gemini', 'gpt', 'claude_code', 'claude_api'], width=12,
                     state='readonly').pack(side=tk.LEFT, padx=5)

        # --- Model row (provider + модель — ОТДЕЛЬНОЙ строкой ниже, не вправо) ---
        row_model = ttk.Frame(card, style="Card.TFrame")
        row_model.pack(fill=tk.X, pady=2)
        ttk.Label(row_model, text="Model:", style="Card.TLabel").pack(side=tk.LEFT)
        self._gpt_provider_label = ttk.Label(row_model, text="API:", style="Dim.TLabel")
        self._gpt_provider_combo = ttk.Combobox(
            row_model, textvariable=self.gpt_provider,
            values=['openai', 'deepseek', 'openrouter'], width=11, state='readonly')
        self._gemini_model_combo = ttk.Combobox(
            row_model, textvariable=self.gemini_model,
            values=_GEMINI_MODEL_OPTS, width=20, state='readonly')
        self._gpt_model_combo = ttk.Combobox(
            row_model, textvariable=self.gpt_model,
            values=['gpt-5.5', 'gpt-5.4'],  # через Codex (по подписке, токены не тарифицируются)
            width=16, state='readonly')
        self._deepseek_model_combo = ttk.Combobox(
            row_model, textvariable=self.deepseek_model,
            values=['deepseek-v4-flash', 'deepseek-v4-pro'],
            width=16, state='readonly')
        self._openrouter_model_combo = ttk.Combobox(
            row_model, textvariable=self.openrouter_model,
            values=OR_DIRECTOR_DISPLAY, width=28, state='readonly')
        self._claude_model_hint = ttk.Label(row_model, text="(из .env: CLAUDE_MODEL)", style="Dim.TLabel")
        # Claude model dropdowns: api → codexhub kr/*, code → CLI alias
        self._claude_api_model_combo = ttk.Combobox(
            row_model, textvariable=self.claude_api_model,
            values=['kr/claude-sonnet-4.6', 'kr/claude-opus-4.7', 'kr/claude-opus-4.6',
                    'kr/claude-sonnet-4.5', 'kr/claude-haiku-4.5'],
            width=22, state='readonly')
        self._claude_code_model_combo = ttk.Combobox(
            row_model, textvariable=self.claude_code_model,
            values=['sonnet', 'opus', 'haiku'], width=12, state='readonly')

        # --- Direction row (только режим прохода) ---
        row2 = ttk.Frame(card, style="Card.TFrame")
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="Direction:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Radiobutton(row2, text="1-pass", variable=self.direction_mode, value="1-pass").pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(row2, text="2-pass", variable=self.direction_mode, value="2-pass").pack(side=tk.LEFT)

        # --- Gen-options: 2 подстроки. Строка А: Chunk/Parallel. Строка Б: Reasoning/MaxTok ---
        row_gen = ttk.Frame(card, style="Card.TFrame")
        row_gen.pack(fill=tk.X, pady=2)
        self._gpt_chunk_label = ttk.Label(row_gen, text="Chunk:", style="Dim.TLabel")
        self._gpt_chunk_spin = ttk.Spinbox(row_gen, textvariable=self.gpt_chunk_size,
                                           from_=50, to=1000, increment=50, width=5)
        self._gpt_parallel_label = ttk.Label(row_gen, text="Parallel:", style="Dim.TLabel")
        self._gpt_parallel_spin = ttk.Spinbox(row_gen, textvariable=self.gpt_parallel,
                                              from_=1, to=20, increment=1, width=4)
        # Claude pass2 chunk (parallel у claude фиксирован = 1)
        self._claude_chunk_label = ttk.Label(row_gen, text="Chunk:", style="Dim.TLabel")
        self._claude_chunk_spin = ttk.Spinbox(row_gen, textvariable=self.claude_chunk_size,
                                              from_=5, to=200, increment=5, width=5)
        # Chat director (deepseek|openrouter): reasoning level + max output tokens — ВТОРАЯ подстрока
        row_gen2 = ttk.Frame(card, style="Card.TFrame")
        row_gen2.pack(fill=tk.X, pady=(0, 2))
        self._chat_reasoning_label = ttk.Label(row_gen2, text="Reasoning:", style="Dim.TLabel")
        self._chat_reasoning_combo = ttk.Combobox(row_gen2, textvariable=self.chat_reasoning,
                                                  values=['off', 'low', 'medium', 'high', 'max'],
                                                  width=7, state='readonly')
        self._chat_tokens_label = ttk.Label(row_gen2, text="MaxTok:", style="Dim.TLabel")
        self._chat_tokens_spin = ttk.Spinbox(row_gen2, textvariable=self.chat_max_tokens,
                                             from_=2000, to=64000, increment=2000, width=6)

        def _on_director_change(*_):
            for _w in (self._gemini_model_combo, self._gpt_model_combo, self._deepseek_model_combo,
                       self._openrouter_model_combo, self._gpt_provider_label, self._gpt_provider_combo,
                       self._claude_model_hint, self._claude_api_model_combo, self._claude_code_model_combo,
                       self._claude_chunk_label, self._claude_chunk_spin,
                       self._gpt_chunk_label, self._gpt_chunk_spin,
                       self._gpt_parallel_label, self._gpt_parallel_spin, self._chat_reasoning_label,
                       self._chat_reasoning_combo, self._chat_tokens_label, self._chat_tokens_spin):
                _w.pack_forget()
            if self.director_backend.get() == 'gpt':
                # Model row: provider + model
                self._gpt_provider_label.pack(side=tk.LEFT, padx=(8, 0))
                self._gpt_provider_combo.pack(side=tk.LEFT, padx=3)
                if self.gpt_provider.get() == 'deepseek':
                    self._deepseek_model_combo.pack(side=tk.LEFT, padx=3)
                elif self.gpt_provider.get() == 'openrouter':
                    self._openrouter_model_combo.pack(side=tk.LEFT, padx=3)
                else:
                    self._gpt_model_combo.pack(side=tk.LEFT, padx=3)
                # Gen-options row: chunk/parallel (+ reasoning/tokens для chat)
                self._gpt_chunk_label.pack(side=tk.LEFT)
                self._gpt_chunk_spin.pack(side=tk.LEFT, padx=3)
                self._gpt_parallel_label.pack(side=tk.LEFT, padx=(10, 0))
                self._gpt_parallel_spin.pack(side=tk.LEFT, padx=3)
                if self.gpt_provider.get() in ('deepseek', 'openrouter'):
                    self._chat_reasoning_label.pack(side=tk.LEFT, padx=(10, 0))
                    self._chat_reasoning_combo.pack(side=tk.LEFT, padx=3)
                    self._chat_tokens_label.pack(side=tk.LEFT, padx=(10, 0))
                    self._chat_tokens_spin.pack(side=tk.LEFT, padx=3)
            elif self.director_backend.get() in ('claude_code', 'claude_api'):
                # Model dropdown: api → codexhub kr/*, code → CLI alias
                if self.director_backend.get() == 'claude_api':
                    self._claude_api_model_combo.pack(side=tk.LEFT, padx=(8, 3))
                else:
                    self._claude_code_model_combo.pack(side=tk.LEFT, padx=(8, 3))
                # Gen-options row: chunk pass2 (parallel у claude фиксирован = 1)
                self._claude_chunk_label.pack(side=tk.LEFT)
                self._claude_chunk_spin.pack(side=tk.LEFT, padx=3)
            else:
                self._gemini_model_combo.pack(side=tk.LEFT, padx=3)
        self.director_backend.trace_add('write', _on_director_change)
        self.gpt_provider.trace_add('write', _on_director_change)
        _on_director_change()

        # --- Экономия токенов: вынос стиль/негатив блоков (два режима + off) ---
        row_sx_title = ttk.Frame(card, style="Card.TFrame")
        row_sx_title.pack(fill=tk.X, pady=(4, 0))
        ttk.Label(row_sx_title, text="Экономия токенов (вынос стиль/негатив):",
                  style="Card.TLabel").pack(side=tk.LEFT)

        row_sx = ttk.Frame(card, style="Card.TFrame")
        row_sx.pack(fill=tk.X, pady=2)

        def _sx_sync_model_row(*_):
            # дропдаун модели — строкой ПОД чекбоксом нейро (перед пояснялкой), виден только при нейро
            if self.style_extract_neuro.get():
                self._sx_model_row.pack(fill=tk.X, before=self._sx_hint_frame)
            else:
                self._sx_model_row.pack_forget()

        def _on_sx_neuro():
            if self.style_extract_neuro.get():
                self.style_extract_regex.set(False)  # взаимоисключение
            _sx_sync_model_row()

        def _on_sx_regex():
            if self.style_extract_regex.get():
                self.style_extract_neuro.set(False)  # взаимоисключение
            _sx_sync_model_row()

        # Строка 1: Питон-регекс
        tk.Checkbutton(
            row_sx, text="Питон-регекс (по якорям в SG)",
            variable=self.style_extract_regex, command=_on_sx_regex,
            bg=COLORS['bg_card'], fg=COLORS['text'], selectcolor=COLORS['bg_card'],
            activebackground=COLORS['bg_card'], activeforeground=COLORS['text'],
        ).pack(side=tk.LEFT)

        # Строка 2: Нейро-регекс (чекбокс)
        row_sx2 = ttk.Frame(card, style="Card.TFrame")
        row_sx2.pack(fill=tk.X, pady=(2, 0))
        tk.Checkbutton(
            row_sx2, text="Нейро-регекс",
            variable=self.style_extract_neuro, command=_on_sx_neuro,
            bg=COLORS['bg_card'], fg=COLORS['text'], selectcolor=COLORS['bg_card'],
            activebackground=COLORS['bg_card'], activeforeground=COLORS['text'],
        ).pack(side=tk.LEFT)
        # Строка модели — ПОД чекбоксом, с отступом, узкая (label + combo width=12);
        # показывается/скрывается в _sx_sync_model_row перед пояснялкой
        self._sx_model_row = ttk.Frame(card, style="Card.TFrame")
        ttk.Label(self._sx_model_row, text="    модель:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Combobox(
            self._sx_model_row, textvariable=self.style_extract_backend, width=12, state='readonly',
            values=['auto', 'deepseek', 'openrouter', 'gemini', 'claude_api']).pack(side=tk.LEFT, padx=3)
        # Пояснялка ниже
        self._sx_hint_frame = ttk.Frame(card, style="Card.TFrame")
        self._sx_hint_frame.pack(fill=tk.X)
        ttk.Label(self._sx_hint_frame, text="    (если стиль и негатив чётко не определены в SG)",
                  style="Dim.TLabel").pack(side=tk.LEFT)
        _sx_sync_model_row()

        row3 = ttk.Frame(card, style="Card.TFrame")
        row3.pack(fill=tk.X, pady=2)
        ttk.Label(row3, text="Clip mode:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Radiobutton(row3, text="video",     variable=self.clip_mode, value="video"    ).pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(row3, text="slideshow", variable=self.clip_mode, value="slideshow").pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(row3, text="vislide",   variable=self.clip_mode, value="vislide"  ).pack(side=tk.LEFT, padx=5)
        self._vislide_interval_lbl = ttk.Label(row3, text="every:", style="Card.TLabel")
        self._vislide_interval_spn = tk.Spinbox(row3, textvariable=self.vislide_interval,
                                                from_=2, to=20, width=3,
                                                bg=COLORS['bg_input'], fg=COLORS['text'])
        def _toggle_vislide_widgets(*_):
            if self.clip_mode.get() == 'vislide':
                self._vislide_interval_lbl.pack(side=tk.LEFT)
                self._vislide_interval_spn.pack(side=tk.LEFT, padx=2)
            else:
                self._vislide_interval_lbl.pack_forget()
                self._vislide_interval_spn.pack_forget()
        self.clip_mode.trace_add('write', _toggle_vislide_widgets)
        _toggle_vislide_widgets()

        row4 = ttk.Frame(card, style="Card.TFrame")
        row4.pack(fill=tk.X, pady=2)
        ttk.Label(row4, text="Duration:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row4, textvariable=self.clip_min, from_=1, to=30, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row4, text="—", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row4, textvariable=self.clip_max, from_=2, to=60, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row4, text="sec", style="Card.TLabel").pack(side=tk.LEFT)

        row5 = ttk.Frame(card, style="Card.TFrame")
        row5.pack(fill=tk.X, pady=2)
        ttk.Label(row5, text="P1 chunks:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Label(row5, text="if ≥", style="Dim.TLabel").pack(side=tk.LEFT, padx=(4, 1))
        tk.Spinbox(row5, textvariable=self.p1_chunk_threshold, from_=0, to=600, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=1)
        ttk.Label(row5, text="min →", style="Dim.TLabel").pack(side=tk.LEFT, padx=(1, 2))
        tk.Spinbox(row5, textvariable=self.p1_chunk_duration, from_=5, to=120, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=1)
        ttk.Label(row5, text="min/chunk  (0=off)", style="Dim.TLabel").pack(side=tk.LEFT, padx=4)

        # Intro Block
        card = self.app.create_card(self.left, "Intro Block")
        row_i1 = ttk.Frame(card, style="Card.TFrame")
        row_i1.pack(fill=tk.X, pady=2)
        ttk.Label(row_i1, text="Intro zone:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row_i1, textvariable=self.intro_duration, from_=0, to=9999, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row_i1, text="sec", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Label(row_i1, text="  (0 = off)", style="Dim.TLabel").pack(side=tk.LEFT, padx=4)

        row_i2 = ttk.Frame(card, style="Card.TFrame")
        row_i2.pack(fill=tk.X, pady=2)
        ttk.Label(row_i2, text="Intro clips:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row_i2, textvariable=self.intro_clip_min, from_=0, to=30, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row_i2, text="—", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row_i2, textvariable=self.intro_clip_max, from_=0, to=60, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row_i2, text="sec", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Label(row_i2, text="  (0 = inherit)", style="Dim.TLabel").pack(side=tk.LEFT, padx=4)

        # ── Music (Pass 3) + Entity cards ────────────────────────────────────
        card = self.app.create_card(self.left, "Music (Pass 3)")

        # Entity cards — ВВЕРХУ карточки (чтобы настройки музыки раскрывались ПОД музыкой)
        _erow = ttk.Frame(card, style="Card.TFrame")
        _erow.pack(fill=tk.X, pady=(0, 2))
        tk.Checkbutton(
            _erow, text="Entity cards (персоны/места)",
            variable=self.entity_overlay_enabled,
            bg=COLORS['bg_card'], fg=COLORS['text'], selectcolor=COLORS['bg_card'],
            activebackground=COLORS['bg_card'], activeforeground=COLORS['text'],
        ).pack(side=tk.LEFT)
        ttk.Label(_erow, text="max:", style="Dim.TLabel").pack(side=tk.LEFT, padx=(8, 1))
        tk.Spinbox(_erow, textvariable=self.entity_overlay_max, from_=0, to=240, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=1)
        ttk.Combobox(_erow, textvariable=self.entity_overlay_backend, width=11, state='readonly',
                     values=['auto', 'gpt', 'deepseek', 'openrouter', 'gemini', 'claude', 'regex']
                     ).pack(side=tk.LEFT, padx=4)

        # Background music — её настройки раскрываются НИЖЕ при включении
        self._music_cb = tk.Checkbutton(
            card, text="Background music (Suno)",
            variable=self.music_enabled,
            bg=COLORS['bg_card'], fg=COLORS['text'],
            selectcolor=COLORS['bg_card'],
            activebackground=COLORS['bg_card'],
            activeforeground=COLORS['text'],
            command=self._on_music_toggle,
        )
        self._music_cb.pack(anchor=tk.W)
        self._music_sub = ttk.Frame(card, style="Card.TFrame")

        _mrow1 = ttk.Frame(self._music_sub, style="Card.TFrame")
        _mrow1.pack(fill=tk.X, pady=2)
        ttk.Label(_mrow1, text="Provider:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Combobox(_mrow1, textvariable=self.music_provider, width=11, state='readonly',
                     values=['suno', 'safe_stock', 'pixabay', 'pexels']).pack(side=tk.LEFT, padx=3)
        ttk.Label(_mrow1, text="Director:", style="Dim.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        ttk.Combobox(_mrow1, textvariable=self.music_backend, width=12, state='readonly',
                     values=['gpt', 'deepseek', 'openrouter', 'claude_code', 'claude_api', 'gemini']).pack(side=tk.LEFT, padx=3)

        # модель для chat-backend музыки (openrouter/deepseek) — независимо от director
        self._music_model_row = ttk.Frame(self._music_sub, style="Card.TFrame")
        ttk.Label(self._music_model_row, text="Chat model:", style="Dim.TLabel").pack(side=tk.LEFT)
        self._music_model_combo = ttk.Combobox(self._music_model_row, textvariable=self.music_chat_model,
                                               width=26, state='readonly')
        self._music_model_combo.pack(side=tk.LEFT, padx=3)

        # Suno-only строка: Browser (cookie) + Suno Model
        self._music_suno_row = ttk.Frame(self._music_sub, style="Card.TFrame")
        ttk.Label(self._music_suno_row, text="Browser:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Combobox(self._music_suno_row, textvariable=self.music_browser, width=9, state='readonly',
                     values=['firefox', 'edge', 'chrome', 'opera', 'brave']).pack(side=tk.LEFT, padx=3)
        ttk.Label(self._music_suno_row, text="Model:", style="Dim.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        ttk.Combobox(self._music_suno_row, textvariable=self.music_model, width=12, state='readonly',
                     values=['chirp-fenix', 'chirp-v4', 'chirp-v3-5']).pack(side=tk.LEFT, padx=3)

        _mrow3 = ttk.Frame(self._music_sub, style="Card.TFrame")
        _mrow3.pack(fill=tk.X, pady=2)
        ttk.Label(_mrow3, text="Vol dB:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(_mrow3, textvariable=self.music_volume_db, from_=-60, to=0, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(_mrow3, text="Ducking dB:", style="Dim.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        tk.Spinbox(_mrow3, textvariable=self.music_ducking_db, from_=-30, to=0, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(_mrow3, text="(0 = без дакинга)", style="Dim.TLabel").pack(side=tk.LEFT, padx=2)

        tk.Checkbutton(
            self._music_sub, text="Open Music Review GUI before concat",
            variable=self.music_review_gui,
            bg=COLORS['bg_card'], fg=COLORS['text'], selectcolor=COLORS['bg_card'],
            activebackground=COLORS['bg_card'], activeforeground=COLORS['text'],
        ).pack(anchor=tk.W, pady=(2, 0))

        def _on_music_backend_change(*_):
            _b = self.music_backend.get()
            if _b == 'openrouter':
                self._music_model_combo['values'] = OR_DIRECTOR_DISPLAY
                if self.music_chat_model.get() not in OR_DIRECTOR_DISPLAY:
                    self.music_chat_model.set(OR_DIRECTOR_DISPLAY[0])
                self._music_model_row.pack(fill=tk.X, pady=2, before=self._music_suno_row)
            elif _b == 'deepseek':
                _dm = ['deepseek-v4-flash', 'deepseek-v4-pro']
                self._music_model_combo['values'] = _dm
                if self.music_chat_model.get() not in _dm:
                    self.music_chat_model.set(_dm[0])
                self._music_model_row.pack(fill=tk.X, pady=2, before=self._music_suno_row)
            else:
                self._music_model_row.pack_forget()
        self.music_backend.trace_add('write', _on_music_backend_change)
        self._music_backend_sync = _on_music_backend_change

        # Browser/Model (Suno-only) показываются только при provider=suno
        def _on_music_provider_change(*_):
            if self.music_provider.get() == 'suno':
                self._music_suno_row.pack(fill=tk.X, pady=2, before=_mrow3)
            else:
                self._music_suno_row.pack_forget()
        self.music_provider.trace_add('write', _on_music_provider_change)
        self._music_provider_sync = _on_music_provider_change

        self._music_backend_sync()
        self._music_provider_sync()
        self._on_music_toggle()

        # ── Real Photos (archive insert) ─────────────────────────────────────
        card = self.app.create_card(self.left, "Real Photos")
        self._real_photo_cb = tk.Checkbutton(
            card, text="Real Photos (archive insert)",
            variable=self.real_photo_enabled,
            bg=COLORS['bg_card'], fg=COLORS['text'],
            selectcolor=COLORS['bg_card'],
            activebackground=COLORS['bg_card'],
            activeforeground=COLORS['text'],
            bd=0, highlightthickness=0,
        )
        self._real_photo_cb.pack(anchor=tk.W, pady=(2, 0))

        _rp_target_row = ttk.Frame(card, style="Card.TFrame")
        _rp_target_row.pack(anchor=tk.W, padx=(18, 0))
        ttk.Label(_rp_target_row, text="Target:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Spinbox(_rp_target_row, textvariable=self.real_photo_target,
                    from_=10, to=80, increment=5, width=4).pack(side=tk.LEFT, padx=3)
        ttk.Label(_rp_target_row, text="%", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Button(_rp_target_row, text="?", width=2,
                   command=lambda: messagebox.showinfo(
                       "Real Photos — what does it do?",
                       "Replaces a portion of AI-generated clips with real archival\n"
                       "photos from Wikimedia Commons, NASA, Library of Congress,\n"
                       "Met Museum, Getty, Europeana, Smithsonian, Rijksmuseum.\n"
                       "Only Public Domain / CC0 / CC-BY material is used,\n"
                       "with credits saved to real_photos_credits.json.\n\n"
                       "Director Pass 1 marks suitable clips; downloads run\n"
                       "in background parallel with ImgGen. Final concat applies\n"
                       "Ken Burns zoom + credit overlay automatically.\n\n"
                       "Recommended target: 30–45%.\n\n"
                       "* Europeana / Smithsonian / Rijksmuseum require free\n"
                       "  API keys (configurable in Settings tab).",
                       parent=self.root)).pack(side=tk.LEFT, padx=(3, 0))

        _rp_src1_row = ttk.Frame(card, style="Card.TFrame")
        _rp_src1_row.pack(anchor=tk.W, padx=(18, 0), pady=(2, 0))
        for _v, _t in [
            (self.real_photo_src_wikimedia, "Wiki"),
            (self.real_photo_src_nasa,      "NASA"),
            (self.real_photo_src_loc,       "LoC"),
            (self.real_photo_src_met,       "Met"),
            (self.real_photo_src_getty,     "Getty"),
        ]:
            tk.Checkbutton(_rp_src1_row, text=_t, variable=_v,
                           bg=COLORS['bg_card'], fg=COLORS['text'],
                           selectcolor=COLORS['bg_card'],
                           activebackground=COLORS['bg_card'],
                           activeforeground=COLORS['text'],
                           bd=0, highlightthickness=0).pack(side=tk.LEFT, padx=1)

        _rp_src2_row = ttk.Frame(card, style="Card.TFrame")
        _rp_src2_row.pack(anchor=tk.W, padx=(18, 0))
        for _v, _t in [
            (self.real_photo_src_europeana,   "Europ.*"),
            (self.real_photo_src_smithsonian, "Smith.*"),
            (self.real_photo_src_archive,     "Archive"),
        ]:
            tk.Checkbutton(_rp_src2_row, text=_t, variable=_v,
                           bg=COLORS['bg_card'], fg=COLORS['text'],
                           selectcolor=COLORS['bg_card'],
                           activebackground=COLORS['bg_card'],
                           activeforeground=COLORS['text'],
                           bd=0, highlightthickness=0).pack(side=tk.LEFT, padx=1)
        # Rijksmuseum — заморожен (new keyless API требует rewrite в Linked Art format,
        # legacy API недоступен без Rijksstudio Advanced settings которые на текущем
        # UI Rijksmuseum'а скрыты/убраны). Force OFF + disable до отдельного решения.
        self.real_photo_src_rijksmuseum.set(False)
        tk.Checkbutton(_rp_src2_row, text="Rijks.* (frozen)",
                       variable=self.real_photo_src_rijksmuseum,
                       state='disabled',
                       bg=COLORS['bg_card'], fg=COLORS['text_muted'],
                       selectcolor=COLORS['bg_card'],
                       disabledforeground=COLORS['text_muted'],
                       activebackground=COLORS['bg_card'],
                       activeforeground=COLORS['text_muted'],
                       bd=0, highlightthickness=0).pack(side=tk.LEFT, padx=1)

        # Image Generation
        card = self.app.create_card(self.left, "Image Generation")
        ttk.Radiobutton(card, text="FastGen", variable=self.img_gen, value="fastgen",
                        command=self._on_imggen_change).pack(anchor=tk.W)
        ttk.Radiobutton(card, text="VeoNonStop", variable=self.img_gen, value="veononstop",
                        command=self._on_imggen_change).pack(anchor=tk.W)
        ttk.Radiobutton(card, text="Skip (for t2v)", variable=self.img_gen, value="skip",
                        command=self._on_imggen_change).pack(anchor=tk.W)
        # ── SynthID WM Remover ───────────────────────────────────────────────
        _sid_row = ttk.Frame(card, style="Card.TFrame")
        _sid_row.pack(anchor=tk.W, fill=tk.X, pady=(6, 0))
        _sid_fg = COLORS['text'] if _synthid_installed() else COLORS['text_muted']
        self._synthid_clean_cb = tk.Checkbutton(
            _sid_row, text="SynthID remover",
            variable=self.synthid_clean_enabled,
            bg=COLORS['bg_card'], fg=_sid_fg,
            selectcolor=COLORS['bg_card'],
            activebackground=COLORS['bg_card'],
            activeforeground=COLORS['text'],
            bd=0, highlightthickness=0,
        )
        self._synthid_clean_cb.pack(side=tk.LEFT)
        ttk.Combobox(_sid_row, textvariable=self.synthid_strength,
                     values=['gentle', 'moderate', 'aggressive', 'extreme'],
                     width=10, state='readonly').pack(side=tk.LEFT, padx=(4, 0))
        ttk.Combobox(_sid_row, textvariable=self.synthid_version,
                     values=['v1', 'v2', 'v3'],
                     width=4, state='readonly').pack(side=tk.LEFT, padx=(2, 0))
        tk.Checkbutton(
            _sid_row, text="save orig",
            variable=self.synthid_save_orig,
            bg=COLORS['bg_card'], fg=COLORS['text_muted'], selectcolor=COLORS['bg_card'],
            activebackground=COLORS['bg_card'], activeforeground=COLORS['text'],
            bd=0, highlightthickness=0,
        ).pack(side=tk.LEFT, padx=(6, 0))
        ttk.Button(_sid_row, text="?", width=2,
                   command=lambda: messagebox.showinfo(
                       "SynthID Remover — гайд",
                       "СИЛА:\n" + "\n\n".join(f"{l}:\n  {d}" for l, d in _WM_SYNTHID_STRENGTH)
                       + "\n\nВЕРСИЯ:\n" + "\n\n".join(f"{v}:\n  {d}" for v, d in _WM_SYNTHID_VERSIONS),
                       parent=self.root)).pack(side=tk.LEFT, padx=(3, 0))

        # FastGen sub-settings
        self.fg_frame = ttk.Frame(card, style="Card.TFrame")
        self.fg_frame.pack(fill=tk.X, pady=4)
        r = ttk.Frame(self.fg_frame, style="Card.TFrame")
        r.pack(fill=tk.X)
        ttk.Label(r, text="Model:", style="Dim.TLabel").pack(side=tk.LEFT)
        models = FASTGEN_DISPLAY
        ttk.Combobox(r, textvariable=self.fastgen_model, values=models, width=12, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(r, text="Aspect:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Combobox(r, textvariable=self.fastgen_aspect, values=['landscape', 'portrait', 'square'],
                     width=10, state='readonly').pack(side=tk.LEFT, padx=4)
        r2 = ttk.Frame(self.fg_frame, style="Card.TFrame")
        r2.pack(fill=tk.X, pady=(2, 0))
        ttk.Label(r2, text="Key:", style="Dim.TLabel").pack(side=tk.LEFT)
        _fg_main = getattr(config, 'FASTGEN_API_KEY', '')
        _fg_has_k2 = bool((getattr(config, 'FASTGEN_API_KEY_2', '') or getattr(config, 'FASTGEN_API_KEY_BACKUP', '')) and
                          (getattr(config, 'FASTGEN_API_KEY_2', '') or getattr(config, 'FASTGEN_API_KEY_BACKUP', '')) != _fg_main)
        _fg_has_k3 = bool(getattr(config, 'FASTGEN_API_KEY_3', '') and getattr(config, 'FASTGEN_API_KEY_3', '') != _fg_main)
        _fg_has_k4 = bool(getattr(config, 'FASTGEN_API_KEY_4', '') and getattr(config, 'FASTGEN_API_KEY_4', '') != _fg_main)
        _fg_key_vals = ['main']
        if _fg_has_k2:
            _fg_key_vals.append('backup')
        if _fg_has_k3:
            _fg_key_vals.append('key3')
        if _fg_has_k4:
            _fg_key_vals.append('key4')
        if _fg_has_k2 or _fg_has_k3 or _fg_has_k4:
            _fg_key_vals.append('both')
        ttk.Combobox(r2, textvariable=self.fastgen_api_key, values=_fg_key_vals,
                     width=8, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(r2, text="Threads:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Spinbox(r2, textvariable=self.fastgen_parallel, from_=1, to=32,
                    width=4).pack(side=tk.LEFT, padx=4)

        # VeoNonStop sub-settings
        self.veo_img_frame = ttk.Frame(card, style="Card.TFrame")
        r = ttk.Frame(self.veo_img_frame, style="Card.TFrame")
        r.pack(fill=tk.X)
        ttk.Label(r, text="Mode:", style="Dim.TLabel").pack(side=tk.LEFT)
        for val, txt in [('banana', 'Banana'), ('banana_ref', 'Banana+ref'), ('imagen', 'Imagen')]:
            ttk.Radiobutton(r, text=txt, variable=self.veo_imggen_mode, value=val,
                            command=self._on_veo_mode_change).pack(side=tk.LEFT, padx=3)
        self.veo_model_row = ttk.Frame(self.veo_img_frame, style="Card.TFrame")
        self.veo_model_row.pack(fill=tk.X, pady=(4, 0))
        ttk.Label(self.veo_model_row, text="Model:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Combobox(self.veo_model_row, textvariable=self.veo_banana_model, values=BANANA_DISPLAY,
                     width=12, state='readonly').pack(side=tk.LEFT, padx=4)

        # VeoNonStop imggen: key selector (multi-select checkboxes) — two rows
        veo_img_key_row = ttk.Frame(self.veo_img_frame, style="Card.TFrame")
        veo_img_key_row.pack(fill=tk.X, pady=(4, 0))
        ttk.Label(veo_img_key_row, text="Img Key:", style="Dim.TLabel").pack(side=tk.LEFT)
        for _slot, _api_key, _name, _has in self._all_veo_keys[:2]:
            _n = int(_slot)
            _cb = ttk.Checkbutton(veo_img_key_row, text=_name,
                                  variable=self._imggen_key_checks[_n],
                                  command=self._on_imggen_key_check)
            _cb.pack(side=tk.LEFT, padx=3)
            if not _has:
                _cb.state(['disabled'])
            self._veo_key_rbs_img[_slot] = _cb
        veo_img_key_row2 = ttk.Frame(self.veo_img_frame, style="Card.TFrame")
        veo_img_key_row2.pack(fill=tk.X)
        for _slot, _api_key, _name, _has in self._all_veo_keys[2:]:
            _n = int(_slot)
            _cb = ttk.Checkbutton(veo_img_key_row2, text=_name,
                                  variable=self._imggen_key_checks[_n],
                                  command=self._on_imggen_key_check)
            _cb.pack(side=tk.LEFT, padx=3)
            if not _has:
                _cb.state(['disabled'])
            self._veo_key_rbs_img[_slot] = _cb

        # VeoNonStop imggen: workers
        veo_img_wrk_row = ttk.Frame(self.veo_img_frame, style="Card.TFrame")
        veo_img_wrk_row.pack(fill=tk.X, pady=(4, 0))
        ttk.Label(veo_img_wrk_row, text="Img Workers:", style="Dim.TLabel").pack(side=tk.LEFT)
        self._img_workers_spinbox = tk.Spinbox(veo_img_wrk_row, textvariable=self.veo_imggen_parallel,
                   from_=1, to=48, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text'])
        self._img_workers_spinbox.pack(side=tk.LEFT, padx=2)
        ttk.Label(veo_img_wrk_row, text="Upscale:", style="Dim.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        ttk.Combobox(veo_img_wrk_row, textvariable=self.image_upscale,
                     values=["off", "2K", "4K"], width=5, state='readonly').pack(side=tk.LEFT, padx=2)

        # Ref images picker (for FastGen and banana_ref)
        self.ref_row = ttk.Frame(card, style="Card.TFrame")
        # Title row with One for all / Individual toggle
        ref_title_row = ttk.Frame(self.ref_row, style="Card.TFrame")
        ref_title_row.pack(fill=tk.X)
        ttk.Label(ref_title_row, text="Refs:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Radiobutton(ref_title_row, text="One for all", variable=self.ref_mode,
                        value="one_for_all", command=self._on_ref_mode_change).pack(side=tk.LEFT, padx=(8, 3))
        ttk.Radiobutton(ref_title_row, text="Individual", variable=self.ref_mode,
                        value="individual", command=self._on_ref_mode_change).pack(side=tk.LEFT)
        _RC = COLORS['bg_card']
        ref_stack = tk.Frame(self.ref_row, bg=_RC)
        ref_stack.pack(fill=tk.X)
        # Individual panel (defines container height)
        self.ref_ind_frame = tk.Frame(ref_stack, bg=_RC)
        self.ref_ind_frame.pack(fill=tk.X)
        self.ref_ind_listbox = tk.Listbox(self.ref_ind_frame, height=3, width=1, bg=COLORS['bg_input'],
                                          fg=COLORS['text'], font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        self.ref_ind_listbox.pack(fill=tk.X, pady=(0, 2))
        ref_ind_btns = tk.Frame(self.ref_ind_frame, bg=_RC)
        ref_ind_btns.pack(fill=tk.X)
        ttk.Button(ref_ind_btns, text="Add", command=self._browse_ind_ref).pack(side=tk.LEFT, padx=2)
        ttk.Button(ref_ind_btns, text="Clear", command=self._clear_ind_ref).pack(side=tk.LEFT, padx=2)
        # One-for-all panel (placed over ind_frame)
        self.ref_one_frame = tk.Frame(ref_stack, bg=_RC)
        self.ref_one_frame.place(x=0, y=0, relwidth=1, relheight=1)
        ref_top = ttk.Frame(self.ref_one_frame, style="Card.TFrame")
        ref_top.pack(fill=tk.X)
        ttk.Button(ref_top, text="Add", command=self._browse_ref_images).pack(side=tk.LEFT, padx=2)
        ttk.Button(ref_top, text="Del", command=self._remove_ref_image).pack(side=tk.LEFT, padx=2)
        ttk.Button(ref_top, text="Clear", command=self._clear_ref_images).pack(side=tk.LEFT, padx=2)
        ref_list_frame = ttk.Frame(self.ref_one_frame, style="Card.TFrame")
        ref_list_frame.pack(fill=tk.X, pady=(2, 0))
        self.ref_listbox = tk.Listbox(ref_list_frame, height=2, width=1, bg=COLORS['bg_input'], fg=COLORS['text'],
                                      font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        ref_sb = ttk.Scrollbar(ref_list_frame, orient=tk.VERTICAL, command=self.ref_listbox.yview)
        self.ref_listbox.config(yscrollcommand=ref_sb.set)
        self.ref_listbox.pack(side=tk.LEFT, fill=tk.X, expand=True)
        ref_sb.pack(side=tk.RIGHT, fill=tk.Y)
        def _on_ref_mousewheel(event):
            if self.ref_listbox.size() > int(self.ref_listbox.cget('height')):
                self.ref_listbox.yview_scroll(-1 * (event.delta // 120), "units")
                return "break"
        self.ref_listbox.bind("<MouseWheel>", _on_ref_mousewheel)


        self._on_imggen_change()
        # Trigger on any img_gen change (presets, var.set, not just click)
        self.img_gen.trace_add('write', lambda *_: self._on_imggen_change())

        # Remixer engine
        remix_card = self.app.create_card(self.left, "Remixer")
        remix_row = ttk.Frame(remix_card, style="Card.TFrame")
        remix_row.pack(fill=tk.X)
        ttk.Radiobutton(remix_row, text="KieAI", variable=self.remix_engine,
                        value='kieai').pack(side=tk.LEFT, padx=(0, 8))
        ttk.Radiobutton(remix_row, text="Grok", variable=self.remix_engine,
                        value='grok').pack(side=tk.LEFT)

        # Video Generation
        card = self.app.create_card(self.left, "Video Generation")
        # Engine selector (veononstop | fastgen_ultra | both)
        _eng_row = ttk.Frame(card, style="Card.TFrame")
        _eng_row.pack(fill=tk.X, pady=2)
        ttk.Label(_eng_row, text="Engine:", style="Card.TLabel").pack(side=tk.LEFT)
        for _ev, _et in [('veononstop', 'VeoNonStop'), ('fastgen_ultra', 'FastGen Ultra'), ('both', 'Both')]:
            ttk.Radiobutton(_eng_row, text=_et, variable=self.video_engine, value=_ev).pack(
                side=tk.LEFT, padx=5)
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(fill=tk.X, pady=2)
        self._vm_radios = {}
        for val, txt in [('i2v', 'i2v'), ('t2v', 't2v'), ('components', 'components')]:
            rb = ttk.Radiobutton(row, text=txt, variable=self.video_mode, value=val,
                            command=self._on_video_mode_change)
            rb.pack(side=tk.LEFT, padx=5)
            self._vm_radios[val] = rb

        row2 = ttk.Frame(card, style="Card.TFrame")
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="Ratio:", style="Card.TLabel").pack(side=tk.LEFT)
        for val in ['16:9', '9:16', '1:1']:
            ttk.Radiobutton(row2, text=val, variable=self.veo_ratio, value=val).pack(side=tk.LEFT, padx=3)

        # Video key selector — single container with engine-dependent content:
        #   engine=veononstop: two rows of VeoNonStop key checkboxes (MY/VEOCAT/OP/AMIR)
        #   engine=fastgen_ultra: FU Key1/Key2/Both radio + End-frame checkbox
        # Both child frames live in keys_area so show/hide doesn't disturb card layout below.
        self._pipe_keys_area = ttk.Frame(card, style="Card.TFrame")
        self._pipe_keys_area.pack(fill=tk.X, pady=(2, 0))

        # VeoNonStop wrap (2 rows of checkboxes)
        self._pipe_veo_keys_wrap = ttk.Frame(self._pipe_keys_area, style="Card.TFrame")
        row2a = ttk.Frame(self._pipe_veo_keys_wrap, style="Card.TFrame")
        row2a.pack(fill=tk.X)
        ttk.Label(row2a, text="Vid Key:", style="Card.TLabel").pack(side=tk.LEFT)
        for _slot, _api_key, _name, _has in self._all_veo_keys[:2]:
            _n = int(_slot)
            _cb = ttk.Checkbutton(row2a, text=_name,
                                  variable=self._video_key_checks[_n],
                                  command=self._on_video_key_check)
            _cb.pack(side=tk.LEFT, padx=3)
            if not _has:
                _cb.state(['disabled'])
            self._veo_key_rbs_video[_slot] = _cb
        row2a2 = ttk.Frame(self._pipe_veo_keys_wrap, style="Card.TFrame")
        row2a2.pack(fill=tk.X, pady=(0, 2))
        for _slot, _api_key, _name, _has in self._all_veo_keys[2:]:
            _n = int(_slot)
            _cb = ttk.Checkbutton(row2a2, text=_name,
                                  variable=self._video_key_checks[_n],
                                  command=self._on_video_key_check)
            _cb.pack(side=tk.LEFT, padx=3)
            if not _has:
                _cb.state(['disabled'])
            self._veo_key_rbs_video[_slot] = _cb

        # FastGen Ultra keys frame (one row: FU Key + end-frame checkbox)
        self._pipe_fu_kf = ttk.Frame(self._pipe_keys_area, style="Card.TFrame")
        _fg_k2_avail_pipe = False
        ttk.Label(self._pipe_fu_kf, text="FU Key:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Radiobutton(self._pipe_fu_kf, text="Key1", variable=self._pipe_fu_keys,
                        value='key1').pack(side=tk.LEFT, padx=3)
        self._pipe_fu_rb_k2 = ttk.Radiobutton(
            self._pipe_fu_kf, text="Key2", variable=self._pipe_fu_keys, value='key2')
        self._pipe_fu_rb_k2.pack(side=tk.LEFT, padx=3)
        self._pipe_fu_rb_both = ttk.Radiobutton(
            self._pipe_fu_kf, text="Both", variable=self._pipe_fu_keys, value='both')
        self._pipe_fu_rb_both.pack(side=tk.LEFT, padx=3)
        if not _fg_k2_avail_pipe:
            self._pipe_fu_rb_k2.state(['disabled'])
            self._pipe_fu_rb_both.state(['disabled'])
        # End-frame opt-in (keyframes mode: end = next clip's generated/ image)
        ttk.Checkbutton(self._pipe_fu_kf, text="End frame (next clip)",
                        variable=self._pipe_fu_end).pack(side=tk.LEFT, padx=(12, 0))

        def _toggle_pipe_video_engine(*_):
            # Swap content of keys_area; outer card layout stays intact
            _eng = self.video_engine.get()
            if _eng == 'both':
                if self.video_mode.get() != 'i2v':
                    self.video_mode.set('i2v')
                for _mode, _rb in getattr(self, '_vm_radios', {}).items():
                    _rb.config(state='normal' if _mode == 'i2v' else 'disabled')
            else:
                for _rb in getattr(self, '_vm_radios', {}).values():
                    _rb.config(state='normal')
                self._on_imggen_change()
            if _eng == 'fastgen_ultra':
                self._pipe_veo_keys_wrap.pack_forget()
                self._pipe_fu_kf.pack(fill=tk.X)
            elif _eng == 'both':
                self._pipe_veo_keys_wrap.pack(fill=tk.X)
                self._pipe_fu_kf.pack(fill=tk.X)
            else:
                self._pipe_fu_kf.pack_forget()
                self._pipe_veo_keys_wrap.pack(fill=tk.X)
        self.video_engine.trace_add('write', _toggle_pipe_video_engine)
        _toggle_pipe_video_engine()

        # Inflight i2v mode checkbox
        _chk_row = ttk.Frame(card, style="Card.TFrame")
        _chk_row.pack(fill=tk.X, pady=(2, 0))
        ttk.Checkbutton(_chk_row, text="Inflight i2v",
                        variable=self.inflight_mode).pack(side=tk.LEFT, padx=(0, 12))
        ttk.Checkbutton(_chk_row, text="Skip preflight",
                        variable=self.skip_preflight).pack(side=tk.LEFT)
        ttk.Checkbutton(_chk_row, text="Upscale 1080p",
                        variable=self.video_upscale).pack(side=tk.LEFT, padx=(8, 0))

        # Story Mode (Chain extends)
        _sm_card = self.app.create_card(self.left, "Story Mode")
        for _val, _txt in [
            ('off',   'Off (independent clips)'),
            ('batch', 'Batch (Start -> End video)'),
            ('morph', 'Morph (one continuous chain)'),
            ('chain', 'Chain (LLM scene breaks)')
        ]:
            ttk.Radiobutton(_sm_card, text=_txt, variable=self.story_mode, value=_val,
                            command=self._toggle_chain_settings_pipe).pack(anchor=tk.W, pady=2)

        # Chain Mode Settings (показывается только при Chain)
        self._chain_pipe_frame = ttk.Frame(_sm_card, style="Card.TFrame")
        ttk.Separator(self._chain_pipe_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=(4, 6))
        _r1 = ttk.Frame(self._chain_pipe_frame, style="Card.TFrame")
        _r1.pack(fill=tk.X, pady=2)
        ttk.Checkbutton(_r1, text="Mute audio", variable=self.app.chain_mute_audio).pack(side=tk.LEFT)
        ttk.Checkbutton(_r1, text="ImgGen heads only", variable=self.app.chain_imggen_heads_only).pack(side=tk.LEFT, padx=(8, 0))
        _r1b = ttk.Frame(self._chain_pipe_frame, style="Card.TFrame")
        _r1b.pack(fill=tk.X, pady=2)
        ttk.Checkbutton(_r1b, text="Cascade recovery", variable=self.app.chain_cascade_recovery).pack(side=tk.LEFT)
        _r2 = ttk.Frame(self._chain_pipe_frame, style="Card.TFrame")
        _r2.pack(fill=tk.X, pady=2)
        ttk.Label(_r2, text="Trim:", style="Card.TLabel", width=6).pack(side=tk.LEFT)
        ttk.Spinbox(_r2, from_=1, to=5, textvariable=self.app.chain_trim_frames, width=5).pack(side=tk.LEFT, padx=2)
        ttk.Label(_r2, text="Offset:", style="Card.TLabel", width=7).pack(side=tk.LEFT, padx=(10, 0))
        ttk.Spinbox(_r2, from_=0.1, to=2.0, increment=0.1, textvariable=self.app.chain_frame_offset, width=5).pack(side=tk.LEFT, padx=2)
        _r3 = ttk.Frame(self._chain_pipe_frame, style="Card.TFrame")
        _r3.pack(fill=tk.X, pady=2)
        ttk.Label(_r3, text="Max chain:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        ttk.Spinbox(_r3, from_=1, to=50, textvariable=self.app.chain_max_chain, width=5).pack(side=tk.LEFT, padx=2)
        ttk.Label(_r3, text="Max fails:", style="Card.TLabel", width=9).pack(side=tk.LEFT, padx=(10, 0))
        ttk.Spinbox(_r3, from_=1, to=10, textvariable=self.app.chain_max_fails, width=5).pack(side=tk.LEFT, padx=2)
        self._toggle_chain_settings_pipe()  # Initial visibility

        row2b = ttk.Frame(card, style="Card.TFrame")
        row2b.pack(fill=tk.X, pady=2)
        ttk.Label(row2b, text="Workers:", style="Card.TLabel").pack(side=tk.LEFT)
        self._vid_workers_spinbox = tk.Spinbox(row2b, textvariable=self.veo_parallel, from_=1, to=48, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text'])
        self._vid_workers_spinbox.pack(side=tk.LEFT, padx=2)
        ttk.Label(row2b, text="  Delay:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row2b, textvariable=self.veo_request_delay, from_=0.5, to=30.0,
                   increment=0.5, width=4, format="%.1f",
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row2b, text="s", style="Dim.TLabel").pack(side=tk.LEFT)

        row2b2 = ttk.Frame(card, style="Card.TFrame")
        row2b2.pack(fill=tk.X, pady=2)
        ttk.Label(row2b2, text="reCAPTCHA delay:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row2b2, textvariable=self.veo_recaptcha_delay, from_=1.0, to=60.0,
                   increment=1.0, width=4, format="%.1f",
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row2b2, text="s  jitter:", style="Dim.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row2b2, textvariable=self.veo_recaptcha_jitter, from_=0.5, to=30.0,
                   increment=0.5, width=4, format="%.1f",
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row2b2, text="s", style="Dim.TLabel").pack(side=tk.LEFT)

        row2c = ttk.Frame(card, style="Card.TFrame")
        row2c.pack(fill=tk.X, pady=2)
        ttk.Label(row2c, text="Retries:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row2c, textvariable=self.veo_max_retries, from_=1, to=5, width=2,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(row2c, text="  Cycles:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row2c, textvariable=self.veo_max_silent_cycles, from_=1, to=10, width=2,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)

        row2d = ttk.Frame(card, style="Card.TFrame")
        row2d.pack(fill=tk.X, pady=2)
        ttk.Label(row2d, text="Skiper mod:", style="Card.TLabel").pack(side=tk.LEFT)
        _fc_opts = ENV_DROPDOWN_OPTIONS.get('VEONONSTOP_FAST_CENSOR', ['off', 'after_rewrites', 'ultrafast'])
        ttk.Combobox(row2d, textvariable=self.veo_fast_censor, values=_fc_opts,
                     width=14, state='readonly').pack(side=tk.LEFT, padx=2)

        row3 = ttk.Frame(card, style="Card.TFrame")
        row3.pack(fill=tk.X, pady=2)
        ttk.Label(row3, text="Prompts:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Radiobutton(row3, text="single", variable=self.prompt_mode, value="single").pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(row3, text="per-clip", variable=self.prompt_mode, value="perclip").pack(side=tk.LEFT)

        # Single prompt file loader — shown only in "single" mode
        # Default = VEO_I2V_UNIVERSAL_STYLE_v1.md
        _default_sp = SCRIPT_DIR / 'prompts_other' / 'VEO_I2V_UNIVERSAL_STYLE_v1.md'
        self.single_prompt_path = _default_sp if _default_sp.exists() else None
        self.single_prompt_row = ttk.Frame(card, style="Card.TFrame")
        self.single_prompt_lbl = ttk.Label(
            self.single_prompt_row,
            text="VEO prompt: " + (_default_sp.name if _default_sp.exists() else "(none)"),
            style="Dim.TLabel")
        self.single_prompt_lbl.pack(fill=tk.X)
        _sp_btns = ttk.Frame(self.single_prompt_row, style="Card.TFrame")
        _sp_btns.pack(fill=tk.X, pady=(2, 0))
        ttk.Button(_sp_btns, text="Browse", command=self._browse_single_prompt).pack(side=tk.LEFT, padx=2)
        ttk.Button(_sp_btns, text="Reset", command=self._reset_single_prompt).pack(side=tk.LEFT, padx=2)
        # Codex VEO adapt — shown only in per-clip mode
        self._codex_adapt_row = ttk.Frame(card, style="Card.TFrame")
        ttk.Checkbutton(self._codex_adapt_row, text="GPT adapt VEO prompts",
                        variable=self.codex_adapt_var).pack(side=tk.LEFT)
        self._veo_adapt_lbl = ttk.Label(self._codex_adapt_row, text="(default)", style="Dim.TLabel")
        self._veo_adapt_lbl.pack(side=tk.LEFT, padx=(6, 0))
        ttk.Button(self._codex_adapt_row, text="Browse",
                   command=self._browse_veo_adapt_prompt).pack(side=tk.LEFT, padx=4)
        self.veo_adapt_prompt_path = None
        # Rewrite model selector
        _rw_row = ttk.Frame(card, style="Card.TFrame")
        _rw_row.pack(fill=tk.X, pady=2)
        ttk.Label(_rw_row, text="Rewrite:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Combobox(_rw_row, textvariable=self.rewrite_model,
                     values=REWRITE_DISPLAY, width=30, state='readonly').pack(side=tk.LEFT, padx=5)

        self.prompt_mode.trace_add('write', lambda *a: self._on_prompt_mode_change())
        self._on_prompt_mode_change()

        # Render
        card = self.app.create_card(self.left, "Render & Concat")
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(fill=tk.X, pady=2)
        ttk.Radiobutton(row, text="Fast (no re-encode)", variable=self.render_mode, value="720p").pack(side=tk.LEFT, padx=5)
        self._rb_1080p = ttk.Radiobutton(row, text="1080p re-encode", variable=self.render_mode, value="1080p")
        self._rb_1080p.pack(side=tk.LEFT)
        self._rb_4k = ttk.Radiobutton(row, text="4K (lanczos)", variable=self.render_mode, value="4k")
        self._rb_4k.pack(side=tk.LEFT, padx=(5, 0))

        def _on_vid_upscale_change(*_):
            if self.video_upscale.get():
                self.render_mode.set("720p")
                self._rb_1080p.config(state='disabled')
                self._rb_4k.config(state='disabled')
            else:
                self._rb_1080p.config(state='normal')
                self._rb_4k.config(state='normal')
        self.video_upscale.trace_add('write', _on_vid_upscale_change)
        _on_vid_upscale_change()
        _br_fps_row = ttk.Frame(card, style="Card.TFrame")
        _br_fps_row.pack(fill=tk.X, pady=2)
        ttk.Label(_br_fps_row, text="Bitrate:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Combobox(_br_fps_row, textvariable=self.concat_bitrate,
                     values=['5M', '8M', '10M', '15M', '20M', '25M', '30M', '35M', '40M'], width=5, state='readonly').pack(side=tk.LEFT, padx=3)
        ttk.Label(_br_fps_row, text="FPS:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        ttk.Combobox(_br_fps_row, textvariable=self.concat_fps,
                     values=[24, 25, 30, 50, 60], width=4, state='readonly').pack(side=tk.LEFT, padx=3)
        row2 = ttk.Frame(card, style="Card.TFrame")
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="Watermark:", style="Card.TLabel").pack(side=tk.LEFT)
        for val, txt in [('as_is', 'none'), ('logo', 'logo'), ('blur', 'blur')]:
            ttk.Radiobutton(row2, text=txt, variable=self.watermark, value=val).pack(side=tk.LEFT, padx=3)
        # Logo file picker (one-for-all / individual toggle)
        logo_title_row = ttk.Frame(card, style="Card.TFrame")
        logo_title_row.pack(fill=tk.X, pady=(4, 2))
        ttk.Label(logo_title_row, text="Logo:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Radiobutton(logo_title_row, text="One for all", variable=self.logo_mode,
                        value="one_for_all", command=self._on_logo_mode_change).pack(side=tk.LEFT, padx=(8, 3))
        ttk.Radiobutton(logo_title_row, text="Individual", variable=self.logo_mode,
                        value="individual", command=self._on_logo_mode_change).pack(side=tk.LEFT)
        _LC = COLORS['bg_card']
        logo_stack = tk.Frame(card, bg=_LC)
        logo_stack.pack(fill=tk.X)
        # Individual panel (defines container height)
        self.logo_ind_frame = tk.Frame(logo_stack, bg=_LC)
        self.logo_ind_frame.pack(fill=tk.X)
        self.logo_ind_listbox = tk.Listbox(self.logo_ind_frame, height=3, bg=COLORS['bg_input'],
                                           fg=COLORS['text'], font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        self.logo_ind_listbox.pack(fill=tk.X, pady=(0, 2))
        logo_ind_btns = tk.Frame(self.logo_ind_frame, bg=_LC)
        logo_ind_btns.pack(fill=tk.X)
        ttk.Button(logo_ind_btns, text="Add", command=self._browse_ind_logo).pack(side=tk.LEFT, padx=2)
        ttk.Button(logo_ind_btns, text="Clear", command=self._clear_ind_logo).pack(side=tk.LEFT, padx=2)
        # One-for-all panel (placed over ind_frame)
        self.logo_one_frame = tk.Frame(logo_stack, bg=_LC)
        self.logo_one_frame.place(x=0, y=0, relwidth=1, relheight=1)
        self.logo_lbl = ttk.Label(self.logo_one_frame, text="(none)", style="Dim.TLabel")
        self.logo_lbl.pack(fill=tk.X)
        logo_btn_row = ttk.Frame(self.logo_one_frame, style="Card.TFrame")
        logo_btn_row.pack(fill=tk.X, pady=(2, 0))
        ttk.Button(logo_btn_row, text="Add", command=self._browse_logo).pack(side=tk.LEFT, padx=2)
        ttk.Button(logo_btn_row, text="Clear", command=self._clear_logo).pack(side=tk.LEFT, padx=2)
        ttk.Checkbutton(card, text="Keep retiming files", variable=self.keep_files).pack(anchor=tk.W, pady=2)
        ttk.Checkbutton(card, text="Keep VEO sound (save retimed_sound/ folder)",
                        variable=self.keep_veo_sound).pack(anchor=tk.W, pady=2)
        sub_row = ttk.Frame(card, style="Card.TFrame")
        sub_row.pack(fill=tk.X, pady=2)
        ttk.Checkbutton(sub_row, text="Subtitles", variable=self.subtitles_enabled).pack(side=tk.LEFT)
        ttk.Label(sub_row, text="Preset:", style="Dim.TLabel").pack(side=tk.LEFT, padx=(10, 2))
        ttk.Radiobutton(sub_row, text="Bottom", variable=self.subtitles_preset,
                        value='bottom').pack(side=tk.LEFT)
        ttk.Radiobutton(sub_row, text="Center", variable=self.subtitles_preset,
                        value='center').pack(side=tk.LEFT, padx=(4, 0))
        ttk.Checkbutton(sub_row, text="Custom template", variable=self.subtitles_custom,
                        command=lambda: _sub_custom_row.pack(fill=tk.X) if self.subtitles_custom.get()
                                        else _sub_custom_row.pack_forget()).pack(side=tk.LEFT, padx=(8, 0))
        _sub_custom_row = ttk.Frame(card, style="Card.TFrame")
        ttk.Entry(_sub_custom_row, textvariable=self.subtitles_path, width=36).pack(side=tk.LEFT, padx=4)
        ttk.Button(_sub_custom_row, text="Add",
                   command=lambda: self.subtitles_path.set(
                       filedialog.askopenfilename(filetypes=[("ASS subtitles", "*.ass"), ("All files", "*.*")])
                   )).pack(side=tk.LEFT)

        # YT Pack
        card = self.app.create_card(self.left, "YT Packer (final stage)")
        ttk.Checkbutton(card, text="Run YT Pack after pipeline", variable=self.yt_pack_enabled,
                        command=self._on_ytpack_toggle).pack(anchor=tk.W)
        self.yt_pack_subform = ttk.Frame(card, style="Card.TFrame")
        r0 = ttk.Frame(self.yt_pack_subform, style="Card.TFrame")
        r0.pack(fill=tk.X, pady=(4, 2))
        ttk.Label(r0, text="Model:", style="Dim.TLabel").pack(side=tk.LEFT)
        self.yt_pack_content_model = tk.StringVar(value=getattr(config, 'YT_PACK_CONTENT_MODEL', 'gpt-5.4'))
        ttk.Combobox(r0, textvariable=self.yt_pack_content_model,
                     values=_GEMINI_MODEL_OPTS + ['gpt-5.5', 'gpt-5.4', 'gpt-5.4-mini'],
                     width=22, state='readonly').pack(side=tk.LEFT, padx=4)
        r1 = ttk.Frame(self.yt_pack_subform, style="Card.TFrame")
        r1.pack(fill=tk.X, pady=(2, 2))
        ttk.Label(r1, text="Languages:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Entry(r1, textvariable=self.yt_pack_languages, width=16).pack(side=tk.LEFT, padx=4)
        ttk.Label(r1, text="(comma-separated, e.g. ru,en)", style="Dim.TLabel").pack(side=tk.LEFT)
        r2 = ttk.Frame(self.yt_pack_subform, style="Card.TFrame")
        r2.pack(fill=tk.X, pady=2)
        ttk.Checkbutton(r2, text="Subtitles", variable=self.yt_pack_subtitles).pack(side=tk.LEFT, padx=2)
        ttk.Checkbutton(r2, text="Description", variable=self.yt_pack_description).pack(side=tk.LEFT, padx=6)
        ttk.Checkbutton(r2, text="Covers", variable=self.yt_pack_covers,
                        command=self._on_covers_toggle).pack(side=tk.LEFT, padx=6)
        # Cover ref images (for YT Packer thumbnails → project/ref_thumb/)
        self.cover_ref_row = ttk.Frame(self.yt_pack_subform, style="Card.TFrame")
        # Provider + model row
        _COVER_MODELS_FASTGEN   = ['GEM_PIX_2', 'GEM_PIX', 'GEMINI', 'NARWHAL', 'GROK', 'IMAGEN_3_5']
        _COVER_MODELS_VEONONSTOP = ['GEM_PIX_2', 'NARWHAL', 'IMAGEN_3_5']
        cr_prov = ttk.Frame(self.cover_ref_row, style="Card.TFrame")
        cr_prov.pack(fill=tk.X, pady=(0, 2))
        ttk.Label(cr_prov, text="Provider:", style="Dim.TLabel").pack(side=tk.LEFT)
        self._cover_model_combo = ttk.Combobox(cr_prov, textvariable=self.cover_model,
                                               values=_COVER_MODELS_FASTGEN, width=12, state='readonly')
        def _on_cover_provider_changed(*_):
            prov = self.cover_provider.get()
            opts = _COVER_MODELS_VEONONSTOP if prov == 'veononstop' else _COVER_MODELS_FASTGEN
            self._cover_model_combo['values'] = opts
            if self.cover_model.get() not in opts:
                self.cover_model.set(opts[0])
        ttk.Combobox(cr_prov, textvariable=self.cover_provider,
                     values=['fastgen', 'veononstop'], width=10, state='readonly',
                     ).pack(side=tk.LEFT, padx=(4, 8))
        self.cover_provider.trace_add('write', _on_cover_provider_changed)
        ttk.Label(cr_prov, text="Model:", style="Dim.TLabel").pack(side=tk.LEFT)
        self._cover_model_combo.pack(side=tk.LEFT, padx=4)
        # Refs row
        cr_top = ttk.Frame(self.cover_ref_row, style="Card.TFrame")
        cr_top.pack(fill=tk.X)
        ttk.Label(cr_top, text="Cover refs:", style="Dim.TLabel").pack(side=tk.LEFT)
        ttk.Button(cr_top, text="Add", command=self._browse_cover_refs).pack(side=tk.LEFT, padx=3)
        ttk.Button(cr_top, text="Clear", command=self._clear_cover_refs).pack(side=tk.LEFT, padx=2)
        cr_list_frame = ttk.Frame(self.cover_ref_row, style="Card.TFrame")
        cr_list_frame.pack(fill=tk.X, pady=(2, 0))
        self.cover_ref_listbox = tk.Listbox(cr_list_frame, height=2, bg=COLORS['bg_input'], fg=COLORS['text'],
                                            font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        cr_sb = ttk.Scrollbar(cr_list_frame, orient=tk.VERTICAL, command=self.cover_ref_listbox.yview)
        self.cover_ref_listbox.config(yscrollcommand=cr_sb.set)
        self.cover_ref_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        cr_sb.pack(side=tk.RIGHT, fill=tk.Y)
        def _on_cover_mousewheel(event):
            if self.cover_ref_listbox.size() > int(self.cover_ref_listbox.cget('height')):
                self.cover_ref_listbox.yview_scroll(-1 * (event.delta // 120), "units")
                return "break"
        self.cover_ref_listbox.bind("<MouseWheel>", _on_cover_mousewheel)
        self._on_covers_toggle()

    def _refresh_remover_status(self):
        """Update WM remover checkbox colors based on whether tool files are installed."""
        if hasattr(self, '_audio_clean_cb') and self._audio_clean_cb:
            fg = COLORS['text'] if _audio_installed() else COLORS['text_muted']
            self._audio_clean_cb.config(fg=fg)
        if hasattr(self, '_synthid_clean_cb') and self._synthid_clean_cb:
            fg = COLORS['text'] if _synthid_installed() else COLORS['text_muted']
            self._synthid_clean_cb.config(fg=fg)

    def _on_covers_toggle(self):
        if self.yt_pack_covers.get():
            self.cover_ref_row.pack(fill=tk.X, pady=(4, 0))
        else:
            self.cover_ref_row.pack_forget()

    def _browse_cover_refs(self):
        paths = filedialog.askopenfilenames(
            title="Select cover reference images",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp *.tiff *.tif *.gif *.heic *.heif *.avif *.svg *.ico *.jfif"), ("All files", "*.*")]
        )
        for p in paths:
            pp = Path(p)
            if pp not in self.cover_ref_images:
                self.cover_ref_images.append(pp)
        self._refresh_cover_ref_listbox()

    def _clear_cover_refs(self):
        self.cover_ref_images.clear()
        self._refresh_cover_ref_listbox()

    def _refresh_cover_ref_listbox(self):
        self.cover_ref_listbox.delete(0, tk.END)
        for p in self.cover_ref_images:
            self.cover_ref_listbox.insert(tk.END, p.name)
        self.cover_ref_listbox.config(height=max(2, min(len(self.cover_ref_images), 6)))

    def _on_ytpack_toggle(self):
        if self.yt_pack_enabled.get():
            self.yt_pack_subform.pack(fill=tk.X, pady=(2, 0))
        else:
            self.yt_pack_subform.pack_forget()

    def _build_right(self, parent):
        # Collapsible container for files/summary/presets
        self._right_collapsible = ttk.Frame(parent)
        self._right_collapsible.pack(fill=tk.X)
        self._right_collapsed = False

        # ── Source Files + Style Guide side by side ─────────────────────
        top_row = ttk.Frame(self._right_collapsible)
        top_row.pack(fill=tk.X, pady=4, padx=2)

        # Source Files (left half)
        files_card = ttk.Frame(top_row, style="Card.TFrame", padding=12)
        files_card.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 3))
        ttk.Label(files_card, text="Start Files", style="Section.TLabel").pack(anchor=tk.W)
        self.files_listbox = tk.Listbox(files_card, height=3, bg=COLORS['bg_input'], fg=COLORS['text'],
                                         font=FONT_DIM, selectbackground=COLORS['accent'],
                                         selectforeground='#ffffff', relief=tk.FLAT, borderwidth=0)
        self.files_listbox.pack(fill=tk.X, pady=(4, 4))
        self.loaded_files: list[Path] = []
        btn_row = ttk.Frame(files_card, style="Card.TFrame")
        btn_row.pack(fill=tk.X)
        ttk.Button(btn_row, text="Add", command=self._add_source_files).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="Remove", command=self._remove_source_file).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="Clear", command=self._clear_source_files).pack(side=tk.LEFT, padx=2)
        # Кнопка слепка — отдельной строкой, чтобы не растягивать карточку Start Files
        btn_row2 = ttk.Frame(files_card, style="Card.TFrame")
        btn_row2.pack(fill=tk.X, pady=(3, 0))
        ttk.Button(btn_row2, text="★ Сохранить настройки генерации",
                   command=self._save_gen_settings_for_file).pack(side=tk.LEFT, padx=2)
        self.files_count_lbl = ttk.Label(files_card, text="0 files  (drag & drop supported)", style="Dim.TLabel")
        self.files_count_lbl.pack(anchor=tk.W, pady=(2, 0))
        # Drag-and-drop support (requires tkinterdnd2)
        try:
            self.files_listbox.drop_target_register('DND_Files')
            self.files_listbox.dnd_bind('<<Drop>>', self._on_files_drop)
        except Exception:
            pass  # tkinterdnd2 not available — skip silently

        # Style Guide (right half)
        sg_card = ttk.Frame(top_row, style="Card.TFrame", padding=12)
        sg_card.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(3, 0))
        # Title + radio buttons on the same line
        sg_title_row = ttk.Frame(sg_card, style="Card.TFrame")
        sg_title_row.pack(fill=tk.X)
        ttk.Label(sg_title_row, text="Style Guide", style="Section.TLabel").pack(side=tk.LEFT)
        self.sg_mode = tk.StringVar(value="one_for_all")
        ttk.Radiobutton(sg_title_row, text="One for all", variable=self.sg_mode,
                        value="one_for_all", command=self._on_sg_mode_change).pack(side=tk.LEFT, padx=(10, 4))
        ttk.Radiobutton(sg_title_row, text="Individual", variable=self.sg_mode,
                        value="individual", command=self._on_sg_mode_change).pack(side=tk.LEFT)
        # Sub-panels stacked via place — guaranteed full coverage, no size jump
        _C = COLORS['bg_card']
        sg_stack = tk.Frame(sg_card, bg=_C)
        sg_stack.pack(fill=tk.X)
        # Individual panel (defines the container height — taller of the two)
        self.sg_ind_frame = tk.Frame(sg_stack, bg=_C)
        self.sg_ind_frame.pack(fill=tk.X)   # drives height
        self.sg_ind_listbox = tk.Listbox(self.sg_ind_frame, height=3, bg=COLORS['bg_input'],
                                          fg=COLORS['text'], font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        self.sg_ind_listbox.pack(fill=tk.X, pady=(0, 4))
        self.sg_individual: dict[str, Optional[Path]] = {}
        sg_btn_row = tk.Frame(self.sg_ind_frame, bg=_C)
        sg_btn_row.pack(fill=tk.X)
        ttk.Button(sg_btn_row, text="Set", command=self._set_individual_sg).pack(side=tk.LEFT, padx=2)
        ttk.Button(sg_btn_row, text="Clear", command=self._clear_individual_sg).pack(side=tk.LEFT, padx=2)
        # One-for-all panel — placed over ind_frame, same size
        self.sg_one_frame = tk.Frame(sg_stack, bg=_C)
        self.sg_one_frame.place(x=0, y=0, relwidth=1, relheight=1)
        self.sg_global_path: Optional[Path] = None
        self.sg_global_lbl = ttk.Label(self.sg_one_frame, text="(none)", style="Dim.TLabel")
        self.sg_global_lbl.pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(self.sg_one_frame, text="Add", command=self._browse_sg_global).pack(side=tk.RIGHT, padx=2)
        # Adapt SG checkbox
        self.sg_adapt = tk.BooleanVar(value=False)
        sg_adapt_row = tk.Frame(sg_card, bg=_C)
        sg_adapt_row.pack(fill=tk.X, pady=(2, 0))
        ttk.Checkbutton(sg_adapt_row, text="Adapt SG to script (GPT)",
                        variable=self.sg_adapt).pack(side=tk.LEFT)
        self.view_adapted_sg_btn = ttk.Button(sg_adapt_row, text="View Adapted SG",
                                              command=self._view_adapted_sg, state=tk.DISABLED)
        self.view_adapted_sg_btn.pack(side=tk.LEFT, padx=(8, 0))

        # ── Preset per file ─────────────────────────────────────────────
        preset_ind_card = self.app.create_card(self._right_collapsible, "Preset per file")
        self.preset_ind_listbox = tk.Listbox(preset_ind_card, height=3,
            bg=COLORS['bg_input'], fg=COLORS['text'], font=FONT_DIM,
            relief=tk.FLAT, borderwidth=0)
        self.preset_ind_listbox.pack(fill=tk.X, pady=(0, 4))
        self.preset_individual: dict[str, str] = {}
        # Per-file снимки настроек генерации (кнопка «Сохранить настройки генерации»).
        # {file.name: snapshot_dict из _snapshot_gen_settings()}. Очередь = серия
        # одиночных запусков: каждый файл прогоняется со своим слепком.
        self.settings_individual: dict[str, dict] = {}
        pi_btn_row = tk.Frame(preset_ind_card, bg=COLORS['bg_card'])
        pi_btn_row.pack(fill=tk.X)
        ttk.Button(pi_btn_row, text="Set", command=self._set_individual_preset).pack(side=tk.LEFT, padx=2)
        ttk.Button(pi_btn_row, text="Clear", command=self._clear_individual_preset).pack(side=tk.LEFT, padx=2)
        ttk.Button(pi_btn_row, text="Clear All", command=self._clear_all_presets).pack(side=tk.LEFT, padx=2)

        # ── Summary (2-column) ───────────────────────────────────────────
        card = self.app.create_card(self._right_collapsible, "Summary")
        sum_cols = ttk.Frame(card, style="Card.TFrame")
        sum_cols.pack(fill=tk.X, pady=4)
        self.summary_label_left = tk.Label(sum_cols, text="", bg=COLORS['bg_card'], fg=COLORS['text'],
                                           font=FONT_LOG, justify=tk.LEFT, anchor=tk.NW)
        self.summary_label_left.pack(side=tk.LEFT, fill=tk.X, expand=True, anchor=tk.NW)
        self.summary_label_right = tk.Label(sum_cols, text="", bg=COLORS['bg_card'], fg=COLORS['text'],
                                            font=FONT_LOG, justify=tk.LEFT, anchor=tk.NW)
        self.summary_label_right.pack(side=tk.LEFT, fill=tk.X, expand=True, anchor=tk.NW)
        self._update_summary()
        # Trace all variables to auto-update summary
        for var in [self.start_point, self.language, self.direction_mode, self.clip_mode,
                    self.img_gen, self.fastgen_model, self.video_mode, self.veo_ratio,
                    self.prompt_mode, self.render_mode, self.watermark, self.veo_imggen_mode,
                    self.veo_banana_model]:
            var.trace_add('write', lambda *a: self._update_summary())
        for var in [self.clip_min, self.clip_max, self.veo_parallel, self.fastgen_parallel,
                    self.keep_files, self.intro_duration, self.intro_clip_min, self.intro_clip_max,
                    self.p1_chunk_threshold, self.p1_chunk_duration]:
            var.trace_add('write', lambda *a: self._update_summary())

        # Stage progress
        card = self.app.create_card(parent, None)
        _sp_hdr = ttk.Frame(card, style="Card.TFrame")
        _sp_hdr.pack(fill=tk.X)
        ttk.Label(_sp_hdr, text="Stage Progress", style="Section.TLabel").pack(side=tk.LEFT)
        self.stage_file_lbl = tk.Label(_sp_hdr, text="", bg=COLORS['bg_card'],
                                        fg=COLORS['accent'], font=FONT_DIM)
        self.stage_file_lbl.pack(side=tk.LEFT, padx=(12, 0))
        self._sp_toggle_btn = ttk.Button(_sp_hdr, text="Hide panels",
                                         command=self._toggle_right_panels)
        self._sp_toggle_btn.pack(side=tk.RIGHT, padx=2)

        self.stage_frame = ttk.Frame(card, style="Card.TFrame")
        self.stage_frame.pack(fill=tk.X, pady=4)
        self.stage_labels = []
        stages = ["Queue", "Transcribe", "Direction", "ImgGen", "VideoGen", "Concat"]
        for i, name in enumerate(stages):
            lbl = tk.Label(self.stage_frame, text=name, bg=COLORS['bg_card'],
                           fg=COLORS['text_muted'], font=FONT_DIM)
            lbl.pack(side=tk.LEFT, padx=3)
            self.stage_labels.append(lbl)
            if i < len(stages) - 1:
                tk.Label(self.stage_frame, text="->", bg=COLORS['bg_card'],
                         fg=COLORS['text_muted'], font=FONT_DIM).pack(side=tk.LEFT)
        self.stage_progress = ttk.Progressbar(card, mode='determinate', maximum=len(stages),
                                               style="Custom.Horizontal.TProgressbar")
        self.stage_progress.pack(fill=tk.X, pady=(4, 2))
        # Per-stage task progress
        task_row = ttk.Frame(card, style="Card.TFrame")
        task_row.pack(fill=tk.X, pady=(2, 0))
        self.task_progress = ttk.Progressbar(task_row, mode='determinate', maximum=100,
                                              style="Green.Horizontal.TProgressbar")
        self.task_progress.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.task_progress_lbl = ttk.Label(task_row, text="", style="Dim.TLabel", width=10, anchor=tk.E)
        self.task_progress_lbl.pack(side=tk.RIGHT, padx=(6, 0))

        # Buttons — grid with auto-reflow on resize
        btn_frame = tk.Frame(parent, bg=COLORS['bg_card'])
        btn_frame.pack(fill=tk.X, pady=4, padx=2)
        self.start_btn = ttk.Button(btn_frame, text="Start Pipeline",
                                    command=self.start_pipeline, style="Accent.TButton")
        self.stop_btn = ttk.Button(btn_frame, text="Stop", command=self.stop_pipeline,
                                   state=tk.DISABLED)
        self._pipeline_btns = [
            self.start_btn,
            self.stop_btn,
            ttk.Button(btn_frame, text="Restart Key", command=self._restart_key),
            ttk.Button(btn_frame, text="Update Key", command=self._update_key_labels),
            ttk.Button(btn_frame, text="QM", command=self._open_queue_manager),
            ttk.Button(btn_frame, text="Open Projects",
                       command=lambda: os.startfile(str(SCRIPT_DIR / 'projects'))),
            ttk.Button(btn_frame, text="Save Defaults", command=self._save_defaults),
        ]
        self._btn_last_cols = 0
        self._btn_reflow_pending = None
        def _reflow_btns():
            self._btn_reflow_pending = None
            btn_frame.update_idletasks()
            fw = btn_frame.winfo_width()
            if fw < 10:
                return
            cols, used = 0, 0
            for b in self._pipeline_btns:
                b.update_idletasks()
                bw = b.winfo_reqwidth() + 8
                if used + bw > fw and cols > 0:
                    break
                used += bw
                cols += 1
            cols = max(1, cols)
            if cols == self._btn_last_cols:
                return
            self._btn_last_cols = cols
            for b in self._pipeline_btns:
                b.grid_forget()
            for i, b in enumerate(self._pipeline_btns):
                r, c = divmod(i, cols)
                b.grid(row=r, column=c, padx=3, pady=2, sticky='w')
        def _on_btn_frame_resize(event=None):
            if self._btn_reflow_pending:
                self.root.after_cancel(self._btn_reflow_pending)
            self._btn_reflow_pending = self.root.after(150, _reflow_btns)
        btn_frame.bind('<Configure>', _on_btn_frame_resize)
        self.root.after(200, _reflow_btns)

        # Log — expand to fill remaining height
        log_card = ttk.Frame(parent, style="Card.TFrame", padding=12)
        log_card.pack(fill=tk.BOTH, expand=True, pady=4, padx=2)
        log_hdr = ttk.Frame(log_card, style="Card.TFrame")
        log_hdr.pack(fill=tk.X)
        ttk.Label(log_hdr, text="Pipeline Log", style="Section.TLabel").pack(side=tk.LEFT)
        ttk.Button(log_hdr, text="Clear", command=lambda: self.log_widget.delete("1.0", tk.END)).pack(side=tk.RIGHT)

        # log_card ref needed for _toggle_right_panels
        self._log_card = log_card
        self.log_widget = self.app.create_log_widget(log_card)
        self.spinner_lbl = ttk.Label(log_card, text="", style="Dim.TLabel", anchor=tk.W,
                                     font=FONT_DIM)
        self.spinner_lbl.pack(fill=tk.X, pady=(1, 0))

    def _toggle_right_panels(self):
        if self._right_collapsed:
            self._right_collapsible.pack(fill=tk.X, before=self._log_card)
            self._right_collapsed = False
            self._sp_toggle_btn.config(text="Hide panels")
        else:
            self._right_collapsible.pack_forget()
            self._right_collapsed = True
            self._sp_toggle_btn.config(text="Show panels")

    def _on_imggen_change(self):
        mode = self.img_gen.get()
        self.fg_frame.pack_forget()
        self.veo_img_frame.pack_forget()
        self.ref_row.pack_forget()
        if mode == "fastgen":
            self.fg_frame.pack(fill=tk.X, pady=4)
            self.ref_row.pack(fill=tk.X, pady=(0, 4))
        elif mode == "veononstop":
            self.veo_img_frame.pack(fill=tk.X, pady=4)
            self._on_veo_mode_change()
        if self.video_mode.get() == 'components':
            self.ref_row.pack(fill=tk.X, pady=(0, 4))
        # Skip imggen → disable i2v (requires images), allow only t2v/components
        i2v_rb = getattr(self, '_vm_radios', {}).get('i2v')
        if i2v_rb:
            if mode == 'skip':
                i2v_rb.config(state='disabled')
                if self.video_mode.get() == 'i2v':
                    self.video_mode.set('t2v')
                    self._on_video_mode_change()
            else:
                i2v_rb.config(state='normal')

    def _on_video_mode_change(self):
        if self.video_mode.get() == 'components':
            self.ref_row.pack(fill=tk.X, pady=(0, 4))
        else:
            self._on_imggen_change()

    def _browse_veo_adapt_prompt(self):
        path = filedialog.askopenfilename(
            title="Select VEO adapt prompt",
            initialdir=str(SCRIPT_DIR / 'prompts_other'),
            filetypes=[("Text / Markdown", "*.txt *.md"), ("All files", "*.*")]
        )
        if path:
            self.veo_adapt_prompt_path = Path(path)
            self._veo_adapt_lbl.config(text=self.veo_adapt_prompt_path.name)

    def _on_prompt_mode_change(self):
        if self.prompt_mode.get() == "single":
            self.single_prompt_row.pack(fill=tk.X, pady=2)
            self._codex_adapt_row.pack_forget()
        else:
            self.single_prompt_row.pack_forget()
            self._codex_adapt_row.pack(fill=tk.X, pady=2)

    def _on_veo_mode_change(self):
        mode = self.veo_imggen_mode.get()
        if mode == 'imagen':
            self.veo_model_row.pack_forget()
            self.ref_row.pack_forget()
        elif mode == 'banana_ref':
            self.veo_model_row.pack(fill=tk.X, pady=(4, 0))
            self.ref_row.pack(fill=tk.X, pady=(4, 0))
        else:
            self.veo_model_row.pack(fill=tk.X, pady=(4, 0))
            self.ref_row.pack_forget()
        if self.video_mode.get() == 'components':
            self.ref_row.pack(fill=tk.X, pady=(4, 0))

    def _browse_ref_images(self):
        paths = filedialog.askopenfilenames(
            title="Select reference images",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp *.tiff *.tif *.gif *.heic *.heif *.avif *.svg *.ico *.jfif"), ("All files", "*.*")]
        )
        for p in paths:
            pp = Path(p)
            if pp not in self.ref_images:
                self.ref_images.append(pp)
        self._refresh_ref_listbox()

    def _remove_ref_image(self):
        sel = self.ref_listbox.curselection()
        if sel:
            self.ref_images.pop(sel[0])
            self._refresh_ref_listbox()

    def _clear_ref_images(self):
        self.ref_images.clear()
        self._refresh_ref_listbox()

    def _refresh_ref_listbox(self):
        self.ref_listbox.delete(0, tk.END)
        for p in self.ref_images:
            self.ref_listbox.insert(tk.END, p.name)
        self.ref_listbox.config(height=max(2, min(len(self.ref_images), 6)))

    # ── Individual refs ──

    def _on_ref_mode_change(self):
        if self.ref_mode.get() == "one_for_all":
            self.ref_one_frame.tkraise()
        else:
            self.ref_ind_frame.tkraise()
            self._refresh_ref_ind_list()

    def _refresh_ref_ind_list(self):
        self.ref_ind_listbox.delete(0, tk.END)
        for f in self.loaded_files:
            refs = self.ref_individual.get(f.name, [])
            n = len(refs)
            label = f"{f.name}  ->  {n} ref{'s' if n != 1 else ''}" if n else f"{f.name}  ->  (none)"
            self.ref_ind_listbox.insert(tk.END, label)
        self.ref_ind_listbox.config(height=max(2, min(len(self.loaded_files), 5)))

    def _browse_ind_ref(self):
        sel = self.ref_ind_listbox.curselection()
        if not sel:
            messagebox.showinfo("Info", "Select a file in the list first")
            return
        idx = sel[0]
        if idx >= len(self.loaded_files):
            return
        target = self.loaded_files[idx]
        paths = filedialog.askopenfilenames(
            title=f"Refs for {target.name}",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp *.tiff *.tif *.gif *.heic *.heif *.avif *.svg *.ico *.jfif"), ("All files", "*.*")]
        )
        if paths:
            existing = self.ref_individual.setdefault(target.name, [])
            for p in paths:
                pp = Path(p)
                if pp not in existing:
                    existing.append(pp)
            self._refresh_ref_ind_list()

    def _clear_ind_ref(self):
        sel = self.ref_ind_listbox.curselection()
        if not sel:
            messagebox.showinfo("Info", "Select a file in the list first")
            return
        idx = sel[0]
        if idx >= len(self.loaded_files):
            return
        target = self.loaded_files[idx]
        self.ref_individual.pop(target.name, None)
        self._refresh_ref_ind_list()

    def _browse_logo(self):
        path = filedialog.askopenfilename(title="Select logo image",
                                           filetypes=[("Images", "*.png *.jpg *.jpeg *.webp"), ("All", "*.*")])
        if path:
            self.logo_path = Path(path)
            self.logo_lbl.config(text=self.logo_path.name)

    def _clear_logo(self):
        self.logo_path = None
        self.logo_lbl.config(text="(none)")

    def _on_logo_mode_change(self):
        if self.logo_mode.get() == "one_for_all":
            self.logo_one_frame.lift()
        else:
            self.logo_ind_frame.lift()
            self._refresh_logo_ind_list()

    def _refresh_logo_ind_list(self):
        self.logo_ind_listbox.delete(0, tk.END)
        for f in self.loaded_files:
            logo = self.logo_individual.get(f.name)
            label = f"{f.name}  →  {logo.name}" if logo else f"{f.name}  →  (none)"
            self.logo_ind_listbox.insert(tk.END, label)

    def _browse_ind_logo(self):
        sel = self.logo_ind_listbox.curselection()
        if not sel or not self.loaded_files:
            return
        idx = sel[0]
        if idx >= len(self.loaded_files):
            return
        audio_file = self.loaded_files[idx]
        path = filedialog.askopenfilename(
            title=f"Select logo for {audio_file.name}",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp"), ("All", "*.*")]
        )
        if path:
            self.logo_individual[audio_file.name] = Path(path)
            self._refresh_logo_ind_list()

    def _clear_ind_logo(self):
        sel = self.logo_ind_listbox.curselection()
        if not sel or not self.loaded_files:
            return
        idx = sel[0]
        if idx >= len(self.loaded_files):
            return
        audio_file = self.loaded_files[idx]
        self.logo_individual.pop(audio_file.name, None)
        self._refresh_logo_ind_list()

    def _browse_single_prompt(self):
        path = filedialog.askopenfilename(title="Select single prompt file",
                                           filetypes=[("Text / Markdown", "*.txt *.md"), ("All", "*.*")])
        if path:
            self.single_prompt_path = Path(path)
            self.single_prompt_lbl.config(text="VEO prompt: " + self.single_prompt_path.name)
            self._update_summary()

    def _reset_single_prompt(self):
        """Reset to default VEO universal style guide."""
        _default = SCRIPT_DIR / 'prompts_other' / 'VEO_I2V_UNIVERSAL_STYLE_v1.md'
        self.single_prompt_path = _default if _default.exists() else None
        self.single_prompt_lbl.config(text="VEO prompt: " + (_default.name if _default.exists() else "(none)"))
        self._update_summary()

    # ── Source Files management ──

    def _on_files_drop(self, event):
        """Handle drag-and-drop files onto Start Files listbox."""
        import re as _re
        # tkinterdnd2 gives paths as space-separated, with {} around paths containing spaces
        raw = event.data
        # Parse: {C:/path with spaces/file.mp3} normalfile.mp3
        paths = _re.findall(r'\{(.+?)\}|(\S+)', raw)
        _exts = {'.mp3', '.wav', '.flac', '.m4a', '.aac',
                 '.mp4', '.mov', '.mkv', '.webm', '.avi', '.m4v',
                 '.txt', '.md'}
        added = 0
        for groups in paths:
            p = groups[0] or groups[1]
            pp = Path(p)
            if pp.is_file() and pp.suffix.lower() in _exts and pp not in self.loaded_files:
                self.loaded_files.append(pp)
                added += 1
        if added:
            self._refresh_files_list()
            self.app.log(f"Dropped {added} file(s)", "INFO", tab="pipeline")

    def _add_source_files(self):
        sp = self.start_point.get()
        if sp == "audio":
            ftypes = [("Audio / Video", "*.mp3 *.wav *.flac *.m4a *.aac *.mp4 *.mov *.mkv *.webm *.avi *.m4v"), ("All", "*.*")]
        else:
            ftypes = [("Scripts", "*.txt *.md"), ("All", "*.*")]
        # initialdir: last loaded file's folder, or ready_to_go/, or script dir
        if self.loaded_files:
            _initdir = str(self.loaded_files[-1].parent)
        else:
            _rtg = SCRIPT_DIR / 'ready_to_go'
            _initdir = str(_rtg) if _rtg.is_dir() else str(SCRIPT_DIR)
        paths = filedialog.askopenfilenames(title="Select source files",
                                            filetypes=ftypes, initialdir=_initdir)
        if not paths:
            return
        for p in paths:
            pp = Path(p)
            if pp not in self.loaded_files:
                self.loaded_files.append(pp)
        self._refresh_files_list()

    def _remove_source_file(self):
        sel = self.files_listbox.curselection()
        if not sel:
            return
        idx = sel[0]
        removed = self.loaded_files.pop(idx)
        self.sg_individual.pop(removed.name, None)
        self.ref_individual.pop(removed.name, None)
        self.logo_individual.pop(removed.name, None)
        self.preset_individual.pop(removed.name, None)
        self.settings_individual.pop(removed.name, None)
        self._refresh_files_list()

    def _clear_source_files(self):
        self.loaded_files.clear()
        self.sg_individual.clear()
        self.ref_individual.clear()
        self.logo_individual.clear()
        self.preset_individual.clear()
        self.settings_individual.clear()
        self._refresh_files_list()

    def _save_gen_settings_for_file(self):
        """Снять снимок текущих настроек GUI и привязать к выделенному файлу.

        Если файл не выделен — применяется к последнему добавленному (типичный
        поток: Add → настроил GUI → жмёшь кнопку → Add следующий)."""
        if not self.loaded_files:
            messagebox.showinfo("Настройки генерации", "Сначала добавьте файл в очередь (Add).")
            return
        sel = self.files_listbox.curselection()
        idx = sel[0] if sel else len(self.loaded_files) - 1
        if idx >= len(self.loaded_files):
            return
        f = self.loaded_files[idx]
        self.settings_individual[f.name] = self._snapshot_gen_settings()
        self._refresh_files_list()
        try:
            self.files_listbox.selection_clear(0, tk.END)
            self.files_listbox.selection_set(idx)
            self.files_listbox.see(idx)
        except Exception:
            pass
        self.app.log(f"★ Настройки генерации сохранены: {f.name}", "SUCCESS", tab="pipeline")

    def _refresh_files_list(self):
        self.files_listbox.delete(0, tk.END)
        for f in self.loaded_files:
            _mark = '★ ' if f.name in self.settings_individual else ''
            self.files_listbox.insert(tk.END, f"{_mark}{f.name}")
        n = len(self.loaded_files)
        _snapped = sum(1 for f in self.loaded_files if f.name in self.settings_individual)
        _tail = f"  (★ {_snapped} с настройками)" if _snapped else ""
        self.files_count_lbl.config(text=f"{n} file{'s' if n != 1 else ''} loaded{_tail}")
        self._refresh_sg_ind_list()
        self._refresh_ref_ind_list()
        self._refresh_logo_ind_list()
        self._refresh_preset_ind_list()
        self._update_summary()

    # ── Style Guide management ──

    def _on_sg_mode_change(self):
        if self.sg_mode.get() == "one_for_all":
            self.sg_one_frame.tkraise()
        else:
            self.sg_ind_frame.tkraise()
            self._refresh_sg_ind_list()

    def _browse_sg_global(self):
        path = filedialog.askopenfilename(title="Select style guide",
                                           filetypes=[("Text", "*.txt *.md"), ("All", "*.*")])
        if path:
            self.sg_global_path = Path(path)
            self.sg_global_lbl.config(text=self.sg_global_path.name)
            self._update_summary()

    def _refresh_sg_ind_list(self):
        self.sg_ind_listbox.delete(0, tk.END)
        for f in self.loaded_files:
            sg = self.sg_individual.get(f.name)
            sg_name = sg.name if sg else "(none)"
            self.sg_ind_listbox.insert(tk.END, f"{f.name}  ->  {sg_name}")

    def _set_individual_sg(self):
        sel = self.sg_ind_listbox.curselection()
        if not sel:
            messagebox.showinfo("Info", "Select a file in the list first")
            return
        idx = sel[0]
        if idx >= len(self.loaded_files):
            return
        target = self.loaded_files[idx]
        path = filedialog.askopenfilename(title=f"Style guide for {target.name}",
                                           filetypes=[("Text", "*.txt *.md"), ("All", "*.*")])
        if path:
            self.sg_individual[target.name] = Path(path)
            self._refresh_sg_ind_list()
            self._update_summary()

    def _clear_individual_sg(self):
        sel = self.sg_ind_listbox.curselection()
        if not sel:
            return
        idx = sel[0]
        if idx >= len(self.loaded_files):
            return
        target = self.loaded_files[idx]
        self.sg_individual.pop(target.name, None)
        self._refresh_sg_ind_list()

    def _view_adapted_sg(self):
        """Open style_guide_adapted.txt from the most recent project folder."""
        projects_dir = SCRIPT_DIR / 'projects'
        if not projects_dir.exists():
            messagebox.showinfo("View Adapted SG", "No projects folder found")
            return
        # Find the most recently modified project folder that has style_guide_adapted.txt
        candidates = []
        for proj in projects_dir.iterdir():
            if proj.is_dir():
                adapted = proj / 'style_guide_adapted.txt'
                if adapted.exists():
                    candidates.append((adapted.stat().st_mtime, adapted))
        if not candidates:
            messagebox.showinfo("View Adapted SG", "No adapted style guide found yet.\nRun pipeline with 'Adapt SG' enabled first.")
            return
        candidates.sort(reverse=True)
        path = candidates[0][1]
        try:
            os.startfile(str(path))
        except Exception as e:
            messagebox.showerror("View Adapted SG", f"Cannot open file:\n{e}")

    # ── Queue Manager popup ──

    def _open_queue_manager(self):
        """Open a unified popup showing all files with SG and preset assignments."""
        dlg = tk.Toplevel(self.root)
        dlg.title("Queue Manager")
        dlg.configure(bg=COLORS['bg_dark'])
        dlg.geometry("700x480")
        dlg.transient(self.root)
        dlg.resizable(True, True)

        tk.Label(dlg, text="Queue Manager", bg=COLORS['bg_dark'],
                 fg=COLORS['accent'], font=FONT_SECTION
                 ).pack(anchor=tk.W, padx=12, pady=(10, 4))

        # Table area
        body = tk.Frame(dlg, bg=COLORS['bg_dark'])
        body.pack(fill=tk.BOTH, expand=True, padx=12, pady=4)

        # Scrollbar + Listbox
        sb = tk.Scrollbar(body, orient=tk.VERTICAL)
        lb = tk.Listbox(body, bg=COLORS['bg_input'], fg=COLORS['text'],
                        font=FONT_DIM, selectbackground=COLORS['accent'],
                        selectforeground='#ffffff', relief=tk.FLAT,
                        borderwidth=0, yscrollcommand=sb.set,
                        activestyle='none', width=80)
        sb.config(command=lb.yview)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        lb.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        order = list(range(len(self.loaded_files)))
        working_sg = dict(self.sg_individual)
        working_preset = dict(self.preset_individual)
        # Per-file SG Adapt: init from existing or global checkbox
        if not hasattr(self, 'sg_adapt_individual'):
            self.sg_adapt_individual = {}
        working_adapt = dict(self.sg_adapt_individual)
        # Pre-fill from global checkbox for files not yet set
        _global_adapt = self.sg_adapt.get()
        for f in self.loaded_files:
            if f.name not in working_adapt:
                working_adapt[f.name] = _global_adapt

        def _refresh():
            lb.delete(0, tk.END)
            for i, orig_i in enumerate(order):
                f = self.loaded_files[orig_i]
                sg = working_sg.get(f.name)
                sg_name = sg.name if sg else "(none)"
                pr = working_preset.get(f.name, "(default)")
                adapt = "[A]" if working_adapt.get(f.name, False) else "[ ]"
                lb.insert(tk.END, f"  {i+1}. {adapt} {f.name}  |  SG: {sg_name}  |  Preset: {pr}")

        def _move(delta):
            sel = lb.curselection()
            if not sel:
                return
            pos = sel[0]
            new_pos = pos + delta
            if new_pos < 0 or new_pos >= len(order):
                return
            order[pos], order[new_pos] = order[new_pos], order[pos]
            _refresh()
            lb.selection_set(new_pos)
            lb.see(new_pos)

        def _set_sg():
            sel = lb.curselection()
            if not sel:
                messagebox.showinfo("Queue Manager", "Select a file first")
                return
            orig_i = order[sel[0]]
            f = self.loaded_files[orig_i]
            path = filedialog.askopenfilename(title=f"Style guide for {f.name}",
                                               filetypes=[("Text", "*.txt *.md"), ("All", "*.*")])
            if path:
                working_sg[f.name] = Path(path)
                _refresh()
                lb.selection_set(sel[0])

        def _clear_sg():
            sel = lb.curselection()
            if not sel:
                return
            orig_i = order[sel[0]]
            f = self.loaded_files[orig_i]
            working_sg.pop(f.name, None)
            _refresh()
            lb.selection_set(sel[0])

        def _set_preset():
            sel = lb.curselection()
            if not sel:
                messagebox.showinfo("Queue Manager", "Select a file first")
                return
            orig_i = order[sel[0]]
            f = self.loaded_files[orig_i]
            presets = self._load_presets_file() if hasattr(self, '_load_presets_file') else {}
            names = sorted(presets.keys()) if presets else []
            if not names:
                messagebox.showinfo("Queue Manager", "No saved presets found.")
                return
            # Simple selection dialog
            pick = tk.Toplevel(dlg)
            pick.title(f"Preset for {f.name}")
            pick.configure(bg=COLORS['bg_dark'])
            pick.geometry("300x250")
            pick.transient(dlg)
            pick.grab_set()
            plb = tk.Listbox(pick, bg=COLORS['bg_input'], fg=COLORS['text'],
                             font=FONT_DIM, selectbackground=COLORS['accent'],
                             relief=tk.FLAT)
            for n in names:
                plb.insert(tk.END, f"  {n}")
            plb.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)
            def _pick_apply():
                ps = plb.curselection()
                if ps:
                    working_preset[f.name] = names[ps[0]]
                    _refresh()
                    lb.selection_set(sel[0])
                pick.destroy()
            ttk.Button(pick, text="Apply", command=_pick_apply, style="Accent.TButton").pack(pady=4)

        def _toggle_adapt():
            sel = lb.curselection()
            if not sel:
                messagebox.showinfo("Queue Manager", "Select a file first")
                return
            orig_i = order[sel[0]]
            f = self.loaded_files[orig_i]
            working_adapt[f.name] = not working_adapt.get(f.name, False)
            _refresh()
            lb.selection_set(sel[0])

        def _qm_add_files():
            sp = self.start_point.get()
            if sp == "audio":
                ftypes = [("Audio / Video", "*.mp3 *.wav *.flac *.m4a *.aac *.mp4 *.mov *.mkv *.webm *.avi *.m4v"), ("All", "*.*")]
            else:
                ftypes = [("Scripts", "*.txt *.md"), ("All", "*.*")]
            paths = filedialog.askopenfilenames(title="Add files", filetypes=ftypes, parent=dlg)
            if not paths:
                return
            for p in paths:
                pp = Path(p)
                if pp not in self.loaded_files:
                    self.loaded_files.append(pp)
                    idx = len(self.loaded_files) - 1
                    order.append(idx)
                    working_adapt[pp.name] = _global_adapt
            _refresh()
            _update_footer()

        def _qm_remove():
            sel = lb.curselection()
            if not sel:
                return
            pos = sel[0]
            orig_i = order.pop(pos)
            f = self.loaded_files[orig_i]
            working_sg.pop(f.name, None)
            working_preset.pop(f.name, None)
            working_adapt.pop(f.name, None)
            _refresh()

        def _qm_drop(event):
            import re as _re
            raw = event.data
            paths = _re.findall(r'\{(.+?)\}|(\S+)', raw)
            _exts = {'.mp3', '.wav', '.flac', '.m4a', '.aac',
                     '.mp4', '.mov', '.mkv', '.webm', '.avi', '.m4v',
                     '.txt', '.md'}
            added = 0
            for groups in paths:
                p = groups[0] or groups[1]
                pp = Path(p)
                if pp.is_file() and pp.suffix.lower() in _exts and pp not in self.loaded_files:
                    self.loaded_files.append(pp)
                    idx = len(self.loaded_files) - 1
                    order.append(idx)
                    working_adapt[pp.name] = _global_adapt
                    added += 1
            if added:
                _refresh()
                _update_footer()

        def _update_footer():
            _foot_lbl.config(text=f"{len(order)} files")

        _refresh()

        # Buttons
        btn_col = tk.Frame(body, bg=COLORS['bg_dark'])
        btn_col.pack(side=tk.RIGHT, padx=(6, 0))
        ttk.Button(btn_col, text="\u2191", width=3, command=lambda: _move(-1)).pack(pady=2)
        ttk.Button(btn_col, text="\u2193", width=3, command=lambda: _move(1)).pack(pady=2)
        ttk.Button(btn_col, text="Set SG", command=_set_sg).pack(pady=2)
        ttk.Button(btn_col, text="Clear SG", command=_clear_sg).pack(pady=2)
        ttk.Button(btn_col, text="Preset", command=_set_preset).pack(pady=2)
        ttk.Button(btn_col, text="Adapt", command=_toggle_adapt).pack(pady=2)
        tk.Frame(btn_col, bg=COLORS['border'], height=1).pack(fill=tk.X, pady=4)
        ttk.Button(btn_col, text="Add", command=_qm_add_files).pack(pady=2)
        ttk.Button(btn_col, text="Remove", command=_qm_remove).pack(pady=2)

        # DnD on QM listbox
        try:
            lb.drop_target_register('DND_Files')
            lb.dnd_bind('<<Drop>>', lambda e: _qm_drop(e))
        except Exception:
            pass

        # Footer
        foot = tk.Frame(dlg, bg=COLORS['bg_dark'])
        foot.pack(fill=tk.X, padx=12, pady=(4, 10))

        def _apply():
            new_files = [self.loaded_files[i] for i in order]
            self.loaded_files[:] = new_files
            self.sg_individual.clear()
            self.sg_individual.update(working_sg)
            self.preset_individual.clear()
            self.preset_individual.update(working_preset)
            self.sg_adapt_individual.clear()
            self.sg_adapt_individual.update(working_adapt)
            self._refresh_files_list()
            self._refresh_sg_ind_list()
            self._refresh_preset_ind_list()
            self._update_summary()
            # Write order.json for live queue (agent.py reads it on rescan)
            try:
                import json as _oj
                _pq = SCRIPT_DIR / 'pipeline_queue'
                if _pq.exists():
                    (_pq / 'order.json').write_text(
                        _oj.dumps([f.name for f in self.loaded_files], ensure_ascii=False, indent=2),
                        encoding='utf-8')
            except Exception:
                pass
            dlg.destroy()

        ttk.Button(foot, text="Apply", style="Accent.TButton",
                   command=_apply).pack(side=tk.LEFT, padx=4)
        ttk.Button(foot, text="Cancel",
                   command=dlg.destroy).pack(side=tk.LEFT, padx=4)
        ttk.Checkbutton(foot, text="Audio WM Cleaner",
                        variable=self.audio_clean_enabled, state='disabled').pack(side=tk.LEFT, padx=8)
        _foot_lbl = ttk.Label(foot, text=f"{len(order)} files", style="Dim.TLabel")
        _foot_lbl.pack(side=tk.RIGHT, padx=4)

    # ── Preset per file management ──

    def _refresh_preset_ind_list(self):
        self.preset_ind_listbox.delete(0, tk.END)
        for f in self.loaded_files:
            pname = self.preset_individual.get(f.name)
            if not pname:
                _global = self._preset_var.get().strip()
                pname = f"({_global})" if _global else "(default)"
            self.preset_ind_listbox.insert(tk.END, f"{f.name}  ->  {pname}")

    def _set_individual_preset(self):
        sel = self.preset_ind_listbox.curselection()
        if not sel:
            messagebox.showinfo("Info", "Select a file in the list first")
            return
        idx = sel[0]
        if idx >= len(self.loaded_files):
            return
        target = self.loaded_files[idx]
        presets = self._load_presets_file()
        if not presets:
            messagebox.showinfo("Info", "No presets saved yet.\nSave a preset first via the Preset card.")
            return
        names = sorted(presets.keys())
        dlg = tk.Toplevel(self.root)
        dlg.title(f"Preset for {target.name}")
        # Position near the Preset per file card
        try:
            _x = self.preset_ind_listbox.winfo_rootx() + 20
            _y = self.preset_ind_listbox.winfo_rooty() + self.preset_ind_listbox.winfo_height() + 4
            dlg.geometry(f"300x220+{_x}+{_y}")
        except Exception:
            dlg.geometry("300x220")
        dlg.transient(self.root)
        dlg.grab_set()
        lb = tk.Listbox(dlg, bg=COLORS['bg_input'], fg=COLORS['text'], font=FONT_DIM)
        lb.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)
        for n in names:
            lb.insert(tk.END, n)
        result = [None]
        def on_ok():
            s = lb.curselection()
            if s:
                result[0] = names[s[0]]
            dlg.destroy()
        lb.bind('<Double-1>', lambda e: on_ok())
        ttk.Button(dlg, text="OK", command=on_ok).pack(pady=(0, 8))
        dlg.wait_window()
        if result[0]:
            self.preset_individual[target.name] = result[0]
            self._refresh_preset_ind_list()
            self._update_summary()

    def _clear_individual_preset(self):
        sel = self.preset_ind_listbox.curselection()
        if not sel:
            return
        idx = sel[0]
        if idx >= len(self.loaded_files):
            return
        target = self.loaded_files[idx]
        self.preset_individual.pop(target.name, None)
        self._refresh_preset_ind_list()
        self._update_summary()

    def _clear_all_presets(self):
        if not self.preset_individual:
            return
        self.preset_individual.clear()
        self._refresh_preset_ind_list()
        self._update_summary()

    def _build_preset_process_args(self, preset, file, start_mode):
        """Build process CLI args from a preset dict for a single file."""
        import json as _json
        p = preset
        ig = str(p.get('img_gen', 'skip'))
        vm = str(p.get('video_mode', 'skip'))
        if ig == "fastgen" and vm == "i2v":
            pa = 'fastgen_i2v'
        elif ig == "veononstop" and vm == "i2v":
            pa = 'veo_i2v'
        elif vm == "t2v":
            pa = 't2v'
        elif vm == "components":
            pa = 'components'
        else:
            pa = 'skip'
        args = ['python', str(AGENT_DIR / 'agent.py'), 'process', '--run',
                '--language', str(p.get('language', 'ru')),
                '--clip-mode', str(p.get('clip_mode', 'video')),
                '--clip-min', str(int(p.get('clip_min', 4))),
                '--clip-max', str(int(p.get('clip_max', 8))),
                '--post-action', pa,
                '--prompt-mode', str(p.get('prompt_mode', 'auto'))]
        if str(p.get('clip_mode', 'video')) == 'vislide':
            args.extend(['--vislide-interval', str(int(p.get('vislide_interval', 3)))])
        if str(p.get('direction_mode', '1-pass')) == '2-pass':
            args.append('--two-pass')
        # Style guide
        _sg_mode = self.sg_mode.get()
        if _sg_mode == 'one_for_all' and self.sg_global_path:
            args.extend(['--style', str(self.sg_global_path)])
        elif _sg_mode == 'individual':
            sg = self.sg_individual.get(file.name)
            if sg and sg.exists():
                _audio_key = (file.stem + '.mp3') if start_mode == 'script_tts' else file.name
                args.extend(['--style-map', _json.dumps({_audio_key: str(sg)}, ensure_ascii=False)])
        # Single file
        _pqueue = SCRIPT_DIR / 'pipeline_queue'
        _fname = (file.stem + '.mp3') if start_mode == 'script_tts' else file.name
        args.extend(['--file-list', _json.dumps([str(_pqueue / _fname)], ensure_ascii=False)])
        args.extend(['--queue-dir', str(_pqueue)])
        # Ref map
        if self.ref_mode.get() == "individual":
            _pref_root = SCRIPT_DIR / '.pending_refs'
            _sd = _pref_root / file.stem
            if _sd.exists() and any(_sd.iterdir()):
                args.extend(['--ref-map', _json.dumps({file.name: str(_sd)}, ensure_ascii=False)])
        # SG Adapt (per-file from QM, fallback to global checkbox)
        _do_adapt = False
        if hasattr(self, 'sg_adapt_individual') and self.sg_adapt_individual:
            _do_adapt = self.sg_adapt_individual.get(file.name, False)
        else:
            _do_adapt = self.sg_adapt.get()
        if _do_adapt:
            args.append('--adapt-sg')
        # YT pack
        if p.get('yt_pack_enabled', False):
            args.append('--yt-pack')
        return args

    @staticmethod
    def _apply_preset_to_env(env, preset):
        """Override env vars with values from a preset dict."""
        p = preset
        _DIRECT = {
            'veo_parallel': 'VEONONSTOP_MAX_PARALLEL',
            'veo_ratio': 'VEONONSTOP_ASPECT_RATIO',
            'veo_request_delay': 'VEONONSTOP_REQUEST_DELAY',
            'veo_recaptcha_delay': 'VEONONSTOP_RECAPTCHA_DELAY',
            'veo_recaptcha_jitter': 'VEONONSTOP_RECAPTCHA_JITTER',
            'veo_max_retries': 'VEONONSTOP_MAX_RETRIES',
            'veo_max_silent_cycles': 'VEONONSTOP_MAX_SILENT_CYCLES',
            'veo_fast_censor': 'VEONONSTOP_FAST_CENSOR',
            'veo_video_key': 'VARAGENT_VIDEO_KEY_SLOT',
            'veo_imggen_parallel': 'VARAGENT_IMGGEN_PARALLEL',
            'fastgen_aspect': 'FASTGEN_ASPECT_RATIO',
            'fastgen_parallel': 'FASTGEN_MAX_PARALLEL',
            'clip_min': 'VIDEO_CLIP_MIN_DURATION',
            'clip_max': 'VIDEO_CLIP_MAX_DURATION',
            'language': 'ASSEMBLYAI_LANGUAGE_CODE',
            'intro_duration': 'INTRO_BLOCK_DURATION',
            'intro_clip_min': 'INTRO_CLIP_MIN_DURATION',
            'intro_clip_max': 'INTRO_CLIP_MAX_DURATION',
            'remix_engine': 'REMIX_ENGINE',
        }
        for key, env_var in _DIRECT.items():
            if key in p:
                env[env_var] = str(p[key])
        if str(p.get('img_gen', '')).lower() == 'fastgen':
            _fg_key_sel = str(p.get('fastgen_api_key', 'main')).lower()
            env['VARAGENT_IMGGEN_KEY_SLOT'] = {
                'main': '1', 'backup': '2', 'key2': '2',
                'key3': '3', 'key4': '4',
                'both': 'all', 'all': 'all',
            }.get(_fg_key_sel, '1')
            if _fg_key_sel in ('both', 'all'):
                env['FASTGEN_DUAL_KEY'] = '1'
            else:
                env.pop('FASTGEN_DUAL_KEY', None)
        elif 'veo_imggen_key' in p:
            env['VARAGENT_IMGGEN_KEY_SLOT'] = str(p['veo_imggen_key'])
            env.pop('FASTGEN_DUAL_KEY', None)
        if 'veo_parallel' in p:
            env['VARAGENT_VIDEO_PARALLEL'] = str(p['veo_parallel'])
        if 'inflight_mode' in p:
            env['VARAGENT_INFLIGHT_MODE'] = '1' if p['inflight_mode'] else '0'
            env['VARAGENT_SKIP_PREFLIGHT'] = '1' if p.get('skip_preflight', False) else '0'
        if str(p.get('clip_mode', 'video')) == 'vislide' and 'vislide_interval' in p:
            env['VARAGENT_VISLIDE_INTERVAL'] = str(int(p['vislide_interval']))
        if 'fastgen_model' in p:
            env['FASTGEN_MODEL'] = FASTGEN_NAME_TO_KEY.get(str(p['fastgen_model']), str(p['fastgen_model']))
        if 'veo_imggen_mode' in p:
            env['VEONONSTOP_IMGGEN_MODE'] = str(p['veo_imggen_mode'])
        if 'veo_banana_model' in p:
            env['VEONONSTOP_BANANA_MODEL'] = BANANA_NAME_TO_KEY.get(str(p['veo_banana_model']), 'GEM_PIX_2')
        if 'p1_chunk_threshold' in p:
            env['DIRECTOR_PASS1_CHUNK_THRESHOLD'] = str(int(p['p1_chunk_threshold']) * 60)
        if 'p1_chunk_duration' in p:
            env['DIRECTOR_PASS1_CHUNK_DURATION'] = str(int(p['p1_chunk_duration']) * 60)
        if 'watermark' in p and str(p['watermark']) != 'as_is':
            env['WATERMARK_MODE'] = str(p['watermark'])
        if p.get('yt_pack_enabled', False):
            env['YT_PACK_LANGUAGES'] = str(p.get('yt_pack_languages', 'ru,en'))
            env['YT_PACK_SUBTITLES'] = 'true' if p.get('yt_pack_subtitles', True) else 'false'
            env['YT_PACK_DESCRIPTION'] = 'true' if p.get('yt_pack_description', True) else 'false'
            env['YT_PACK_COVERS'] = 'true' if p.get('yt_pack_covers', True) else 'false'
            env['YT_PACK_COVER_PROVIDER'] = str(p.get('cover_provider', 'fastgen'))
            env['YT_PACK_COVER_MODEL'] = str(p.get('cover_model', 'GEM_PIX_2'))

    def _on_start_point_change(self):
        mode = self.start_point.get()
        # Clear files to avoid stale audio/script mix
        self._clear_source_files()
        if mode == "script_no_audio":
            self.type_row.pack(fill=tk.X, pady=(4, 0))
            self.lang_row.pack_forget()
        else:  # audio or script_tts
            self.type_row.pack_forget()
            self.lang_row.pack(fill=tk.X, pady=2)
        self._update_summary()

    def _update_summary(self):
        try:
            self._update_summary_inner()
        except Exception:
            pass

    def _update_summary_inner(self):
        ig = self.img_gen.get()
        if ig == "fastgen":
            img_desc = f"FastGen ({self.fastgen_model.get()}, {self.fastgen_aspect.get()})"
        elif ig == "veononstop":
            veo_mode = self.veo_imggen_mode.get()
            if veo_mode == 'imagen':
                img_desc = "VeoNonStop (Imagen)"
            else:
                img_desc = f"VeoNonStop ({veo_mode}, {self.veo_banana_model.get()})"
        else:
            img_desc = "Skip"

        intro_dur_str = self.intro_duration.get()
        intro_dur = int(intro_dur_str) if intro_dur_str else 0
        if intro_dur > 0:
            imin_str = self.intro_clip_min.get()
            imax_str = self.intro_clip_max.get()
            imin = int(imin_str) if imin_str else 0
            imax = int(imax_str) if imax_str else 0
            intro_desc = f"{intro_dur}s zone, clips {imin}-{imax}s" if imin > 0 else f"{intro_dur}s zone (inherit)"
        else:
            intro_desc = "off"

        # Files info
        n_files = len(self.loaded_files)
        files_desc = f"{n_files} file{'s' if n_files != 1 else ''}" if n_files > 0 else "ready_to_go/"
        sg_mode = self.sg_mode.get()
        if sg_mode == "one_for_all" and self.sg_global_path:
            sg_desc = self.sg_global_path.name
        elif sg_mode == "individual":
            n_sg = sum(1 for v in self.sg_individual.values() if v)
            sg_desc = f"{n_sg}/{n_files} individual"
        else:
            sg_desc = "auto (ready_to_go/)"
        if self.logo_mode.get() == "individual":
            _n_logos = sum(1 for v in self.logo_individual.values() if v)
            logo_desc = f"individual ({_n_logos} set)" if _n_logos else "individual (none set)"
        else:
            logo_desc = self.logo_path.name if self.logo_path else "none"
        prompt_desc = self.single_prompt_path.name if self.single_prompt_path else "auto"
        n_preset_ind = len(self.preset_individual)
        preset_desc = f"{n_preset_ind}/{n_files} with preset" if n_preset_ind else "default"

        sp = self.start_point.get()
        if sp == "script_no_audio":
            script_name = self.loaded_files[0].name if self.loaded_files else "(none)"
            start_desc = f"script ({self.script_type_var.get()}: {script_name})"
            lang_desc = "—"
        elif sp == "script_tts":
            script_name = self.loaded_files[0].name if self.loaded_files else "(none)"
            start_desc = f"script→audio ({script_name})"
            lang_desc = self.language.get()
        else:
            start_desc = "audio"
            lang_desc = self.language.get()

        left_lines = [
            f"Files:     {files_desc}",
            f"Style:     {sg_desc}",
            f"Preset:    {preset_desc}",
            f"Start:     {start_desc}",
            f"Language:  {lang_desc}",
            f"Direction: {self.direction_mode.get()}",
            f"Clips:     {self.clip_mode.get()} ({self.clip_min.get()}-{self.clip_max.get()}s)",
        ]
        right_lines = [
            f"Intro:     {intro_desc}",
            f"ImgGen:    {img_desc}",
            f"VideoGen:  {self.video_mode.get()} ({self.veo_ratio.get()}, x{self.veo_parallel.get()})",
            f"Prompt:    {prompt_desc}",
            f"Render:    {'fast' if self.render_mode.get() == '720p' else '1080p'}, wm={self.watermark.get()}",
            f"Logo:      {logo_desc}",
        ]
        self.summary_label_left.config(text="\n".join(left_lines))
        self.summary_label_right.config(text="\n".join(right_lines))

    def _set_stage(self, index):
        for i, lbl in enumerate(self.stage_labels):
            if i == index:
                lbl.config(fg=COLORS['yellow'])   # active
            elif i < index:
                lbl.config(fg=COLORS['green'])    # done
            else:
                lbl.config(fg=COLORS['accent'])   # pending
        self.stage_progress['value'] = index
        # Reset task progress on new stage
        self.task_progress['value'] = 0
        self.task_progress['maximum'] = 100
        self.task_progress_lbl.config(text="")

    def _set_task_progress(self, current: int, total: int):
        self.task_progress['maximum'] = total
        self.task_progress['value'] = current
        self.task_progress_lbl.config(text=f"{current} / {total}")

    def _set_current_file(self, name: str, pos: int, total: int):
        """Update current file label in Stage Progress header."""
        if name:
            self.stage_file_lbl.config(text=f"{name}  ({pos}/{total})")
        else:
            self.stage_file_lbl.config(text="")

    def start_pipeline(self):
        if self.is_running:
            return

        # Сброс лога и индикаторов стадий
        self.log_widget.delete("1.0", tk.END)
        for lbl in self.stage_labels:
            lbl.config(fg=COLORS['accent'])
        self.stage_progress['value'] = 0
        self.spinner_lbl.config(text="")
        self.stage_file_lbl.config(text="")

        if self.loaded_files:
            # GUI pipeline mode — используем изолированную папку pipeline_queue/
            rtg = SCRIPT_DIR / 'pipeline_queue'
            if rtg.exists():
                shutil.rmtree(str(rtg))   # очистить стейл с прошлого запуска
            rtg.mkdir(parents=True)
            for src in self.loaded_files:
                dst = rtg / src.name
                shutil.copy2(str(src), str(dst))
                self.app.log(f"Copied: {src.name} -> pipeline_queue/", "INFO", tab="pipeline")

            # Log style guides (individual SGs are passed via --style-map, NOT copied to pipeline_queue)
            sg_mode = self.sg_mode.get()
            if sg_mode == "one_for_all" and self.sg_global_path and self.sg_global_path.exists():
                self.app.log(f"Style guide (global): {self.sg_global_path.name}", "INFO", tab="pipeline")
            elif sg_mode == "individual":
                for f in self.loaded_files:
                    sg = self.sg_individual.get(f.name)
                    if sg and sg.exists():
                        self.app.log(f"Style guide: {sg.name}", "INFO", tab="pipeline")
        else:
            # No files loaded — fallback: ready_to_go/ (manual / BAT mode)
            rtg = SCRIPT_DIR / 'ready_to_go'
            rtg.mkdir(parents=True, exist_ok=True)
            audio = (list(rtg.glob('*.mp3')) + list(rtg.glob('*.wav')) + list(rtg.glob('*.flac'))
                     + list(rtg.glob('*.m4a')) + list(rtg.glob('*.aac'))
                     + list(rtg.glob('*.mp4')) + list(rtg.glob('*.mov')) + list(rtg.glob('*.mkv'))
                     + list(rtg.glob('*.webm')) + list(rtg.glob('*.avi')) + list(rtg.glob('*.m4v')))
            if not audio and self.start_point.get() == "audio":
                messagebox.showerror("Error", "No files loaded and no audio/video in ready_to_go/")
                return

        # Валидация: banana_ref требует референсов
        _has_refs = bool(self.ref_images) if self.ref_mode.get() == "one_for_all" \
                    else any(v for v in self.ref_individual.values())
        if self.img_gen.get() == "veononstop" and self.veo_imggen_mode.get() == "banana_ref" and not _has_refs:
            messagebox.showerror(
                "Refs required",
                "Mode is Banana+Ref but no reference images loaded.\n\n"
                "Add refs via the Refs picker, or switch to Banana / Imagen."
            )
            return

        # Валидация: components требует референсов
        if self.video_mode.get() == "components" and not _has_refs:
            messagebox.showerror(
                "Refs required",
                "Video mode is Components but no reference images loaded.\n\n"
                "Add refs via the Refs picker, or switch to i2v / t2v."
            )
            return

        # Stage ref images
        if self.ref_mode.get() == "individual":
            # Per-file staging: .pending_refs/<audio_stem>/
            _pref_root = SCRIPT_DIR / '.pending_refs'
            if _pref_root.exists():
                shutil.rmtree(str(_pref_root))
            for _f in self.loaded_files:
                _refs = self.ref_individual.get(_f.name, [])
                if not _refs:
                    continue
                _sd = _pref_root / _f.stem
                _sd.mkdir(parents=True)
                for _img in _refs:
                    shutil.copy2(str(_img), str(_sd / _img.name))
                self.app.log(f"Staged {len(_refs)} ref(s) for {_f.name} -> .pending_refs/{_f.stem}/", "INFO", tab="pipeline")
        else:
            # One-for-all staging: .pending_refs/ (flat)
            # Always clear old staging first — prevents stale refs from previous runs
            staging = SCRIPT_DIR / '.pending_refs'
            if staging.exists():
                shutil.rmtree(str(staging))
            if self.ref_images:
                staging.mkdir()
                for img in self.ref_images:
                    shutil.copy2(str(img), str(staging / img.name))
                self.app.log(f"Staged {len(self.ref_images)} ref image(s) -> .pending_refs/", "INFO", tab="pipeline")

        # Stage individual logos → .pending_logos/<audio_stem>/
        if self.logo_mode.get() == "individual":
            _plogo_root = SCRIPT_DIR / '.pending_logos'
            if _plogo_root.exists():
                shutil.rmtree(str(_plogo_root))
            for _f in self.loaded_files:
                _logo = self.logo_individual.get(_f.name)
                if not _logo or not _logo.exists():
                    continue
                _sd = _plogo_root / _f.stem
                _sd.mkdir(parents=True)
                shutil.copy2(str(_logo), str(_sd / _logo.name))
                self.app.log(f"Staged logo for {_f.name}: {_logo.name}", "INFO", tab="pipeline")

        # Stage cover ref images → .pending_cover_refs/ (queue.py copies to project/ref_thumb/)
        if self.cover_ref_images:
            staging = SCRIPT_DIR / '.pending_cover_refs'
            if staging.exists():
                shutil.rmtree(str(staging))
            staging.mkdir()
            for img in self.cover_ref_images:
                shutil.copy2(str(img), str(staging / img.name))
            self.app.log(f"Staged {len(self.cover_ref_images)} cover ref(s) -> .pending_cover_refs/", "INFO", tab="pipeline")

        # Script mode validation
        start_mode = self.start_point.get()
        if start_mode in ("script_no_audio", "script_tts"):
            if not self.loaded_files:
                messagebox.showerror("Error", "No script file loaded. Use Add in Start Files to select a .txt script.")
                return
            if not self.loaded_files[0].exists():
                messagebox.showerror("Error", f"Script file not found:\n{self.loaded_files[0]}")
                return
            if start_mode == "script_no_audio":
                sg_mode = self.sg_mode.get()
                if sg_mode == "one_for_all" and not (self.sg_global_path and self.sg_global_path.exists()):
                    messagebox.showerror("Error", "Style guide required for script mode.\nSet a global style guide in the Style Guide card.")
                    return
            # script_tts: files already copied to ready_to_go/ in the loaded_files loop above

        self.is_running = True
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self._cancel = threading.Event()
        threading.Thread(target=self._pipeline_worker, daemon=True).start()

    def stop_pipeline(self):
        self._cancel.set()
        self.app.log("Pipeline stop requested...", "WARNING", tab="pipeline")

    def _restart_key(self):
        """Cancel all server tasks WITHOUT stopping pipeline. Workers will retry."""
        def _do():
            _total = 0
            try:
                from modules.veo_video import _active_clients as _veo_clients
                from modules.imggen import _active_clients as _img_clients
                all_clients = list(_veo_clients) + list(_img_clients)
                if not all_clients:
                    # VideoGen not started yet — create fresh clients from config
                    import config as _cfg
                    from modules.veononstop import VeoNonStopClient
                    # (api_key_attr, base_url_attr) per slot
                    _KEY_PAIRS = [
                        ('VEONONSTOP_API_KEY',   'VEONONSTOP_API_BASE'),
                        ('VEONONSTOP_API_KEY_2', 'VEONONSTOP_API_BASE_2'),
                        ('VEONONSTOP_API_KEY_3', 'VEONONSTOP_API_BASE_3'),
                        ('VEONONSTOP_API_KEY_4', 'VEONONSTOP_API_BASE_4'),
                    ]
                    for _kattr, _battr in _KEY_PAIRS:
                        key = getattr(_cfg, _kattr, '')
                        if key:
                            try:
                                _bu = getattr(_cfg, _battr, _cfg.VEONONSTOP_API_BASE)
                                all_clients.append(VeoNonStopClient(api_key=key, base_url=_bu))
                            except Exception:
                                pass
                for _cc in all_clients:
                    try:
                        _cancelled = _cc.cancel_all_tasks()
                        _total += len(_cancelled) if isinstance(_cancelled, (list, dict)) else int(_cancelled or 0)
                    except Exception:
                        pass
            except Exception:
                pass
            self.app.log(f"Restart Key: cancelled {_total} server task(s) — workers will retry", "WARNING", tab="pipeline")
        threading.Thread(target=_do, daemon=True).start()

    def _update_key_labels(self):
        """Re-fetch VeoNonStop key labels (active/total) in background."""
        threading.Thread(target=self.app.tab_pipeline._fetch_veo_key_labels, daemon=True).start()

    def _pipeline_worker(self):
        """Оркестратор очереди: серия одиночных запусков.

        Если файлам присвоены слепки настроек (★ — кнопка «Сохранить настройки
        генерации»), очередь обрабатывается ПО ОДНОМУ файлу: перед каждым его
        слепок применяется к GUI (в главном потоке), затем прогоняется полный
        путь генерации+concat для этого одного файла, дальше следующий. Файлы
        без слепка идут с текущими настройками GUI. Если слепков нет вовсе —
        один общий прогон (старое поведение).

        tkinter не потокобезопасен → снимок/применение слепка делаются через
        root.after в главном потоке с барьером (Event.wait)."""
        def _apply_snap_sync(snap):
            _ev = threading.Event()
            self.root.after(0, lambda: (self._apply_gen_snapshot(snap), _ev.set()))
            _ev.wait(timeout=15)

        def _take_snap_sync():
            _box = {}
            _ev = threading.Event()
            self.root.after(0, lambda: (_box.update(self._snapshot_gen_settings()), _ev.set()))
            _ev.wait(timeout=15)
            return _box

        try:
            files = list(self.loaded_files)
            has_snaps = any(f.name in self.settings_individual for f in files)
            if has_snaps and files:
                _orig = _take_snap_sync()          # текущий GUI — restore + дефолт для файлов без слепка
                _saved_files = list(self.loaded_files)
                try:
                    for _i, f in enumerate(files, 1):
                        if self._cancel.is_set():
                            break
                        snap = self.settings_individual.get(f.name, _orig)
                        _apply_snap_sync(snap)
                        _tag = 'свой слепок' if f.name in self.settings_individual else 'текущий GUI'
                        self.app.log(f"══ Очередь {_i}/{len(files)}: {f.name}  ({_tag}) ══",
                                     "INFO", tab="pipeline")
                        self.loaded_files = [f]
                        self._run_one_batch()
                finally:
                    self.loaded_files = _saved_files
                    _apply_snap_sync(_orig)         # вернуть GUI как было до очереди
            else:
                self._run_one_batch()
        except Exception as e:
            self.app.log(f"Queue orchestrator error: {e}", "ERROR", tab="pipeline")
        finally:
            self.is_running = False
            self.root.after(0, lambda: self.start_btn.config(state=tk.NORMAL))
            self.root.after(0, lambda: self.stop_btn.config(state=tk.DISABLED))
            if self.sg_adapt.get():
                self.root.after(0, lambda: self.view_adapted_sg_btn.config(state=tk.NORMAL))

    def _run_one_batch(self):
        """Один прогон пайплайна для текущего self.loaded_files (1 файл при серии,
        или все файлы если слепков нет). Тело = бывший _pipeline_worker."""
        try:
            # Set config overrides
            two_pass = self.direction_mode.get() == "2-pass"
            post_action = 'skip'
            ig = self.img_gen.get()
            vm = self.video_mode.get()
            ve = self.video_engine.get()
            if ve == 'both' and vm == 'i2v':
                post_action = 'both_i2v'
            elif ve == 'fastgen_ultra':
                # Flow Ultra: mode mapping (i2v → keyframes, components → ingredients)
                if vm == 'i2v':
                    post_action = 'fastgen_ultra_i2v'
                elif vm == 't2v':
                    post_action = 'fastgen_ultra_t2v'
                elif vm == 'components':
                    post_action = 'fastgen_ultra_ingredients'
            elif ig == "fastgen" and vm == "i2v":
                post_action = 'fastgen_i2v'
            elif ig == "veononstop" and vm == "i2v":
                post_action = 'veo_i2v'
            elif vm == "t2v":
                post_action = 't2v'
            elif vm == "components":
                post_action = 'components'

            # Slideshow mode: skip video animation, keep only image generation
            if self.clip_mode.get() == 'slideshow':
                if post_action == 'veo_i2v':
                    post_action = 'imggen'
                elif post_action == 'fastgen_i2v':
                    post_action = 'fastgen'

            # Build CLI phases (list of arg lists, run sequentially)
            start_mode = self.start_point.get()

            # Standard process pipeline (used by audio and script_tts phase 2)
            process_args = ['python', str(AGENT_DIR / 'agent.py'), 'process', '--run',
                            '--language', self.language.get(),
                            '--clip-mode', self.clip_mode.get(),
                            '--clip-min', str(self.clip_min.get()),
                            '--clip-max', str(self.clip_max.get()),
                            '--post-action', post_action,
                            '--prompt-mode', self.prompt_mode.get()]
            if self.clip_mode.get() == 'vislide':
                process_args.extend(['--vislide-interval', str(self.vislide_interval.get())])
            if two_pass:
                process_args.append('--two-pass')
            if self.codex_adapt_var.get() and self.prompt_mode.get() == 'perclip':
                process_args.append('--codex-adapt')
            if self.sg_adapt.get():
                process_args.append('--adapt-sg')
            # Передаём style guide из GUI — обходит автопоиск по ready_to_go
            import json as _json
            _sg_mode = self.sg_mode.get()
            if _sg_mode == 'one_for_all' and self.sg_global_path:
                process_args.extend(['--style', str(self.sg_global_path)])
            elif _sg_mode == 'individual' and self.sg_individual:
                _sg_map = {}
                for f in self.loaded_files:
                    sg = self.sg_individual.get(f.name)
                    if not (sg and sg.exists()):
                        continue
                    # script_tts: loaded files are .txt scripts, but TTS outputs .mp3 audio
                    # agent.py process sees the generated audio filename, not the script filename
                    if start_mode == 'script_tts':
                        audio_key = f.stem + '.mp3'
                    else:
                        audio_key = f.name
                    _sg_map[audio_key] = str(sg)
                if _sg_map:
                    process_args.extend(['--style-map', _json.dumps(_sg_map, ensure_ascii=False)])

            # Передаём порядок файлов из GUI + папку очереди (pipeline_queue вместо ready_to_go).
            # file-list = строго текущий self.loaded_files (при серии это 1 файл, который
            # подал оркестратор). Без rescan — agent обрабатывает ровно этот список.
            if self.loaded_files and start_mode not in ("script_no_audio",):
                _pqueue = SCRIPT_DIR / 'pipeline_queue'
                _fl = []
                for _f in self.loaded_files:
                    # script_tts: загружены .txt, но после TTS в pipeline_queue лежат .mp3
                    _fname = (_f.stem + '.mp3') if start_mode == 'script_tts' else _f.name
                    _fl.append(str(_pqueue / _fname))
                process_args.extend(['--file-list', _json.dumps(_fl, ensure_ascii=False)])
                process_args.extend(['--queue-dir', str(_pqueue)])

            if start_mode == "script_no_audio":
                script_path = str(self.loaded_files[0])
                sg_mode = self.sg_mode.get()
                _script_file = self.loaded_files[0]
                if sg_mode == "one_for_all" and self.sg_global_path:
                    style_path = str(self.sg_global_path)
                elif sg_mode == "individual":
                    _ind_sg = self.sg_individual.get(_script_file.name)
                    style_path = str(_ind_sg) if (_ind_sg and _ind_sg.exists()) else ""
                else:
                    style_path = ""
                project_name = Path(script_path).stem
                script_args = ['python', str(AGENT_DIR / 'agent.py'), 'script',
                               '--script', script_path,
                               '--style', style_path,
                               '--project', project_name,
                               '--script-type', self.script_type_var.get(),
                               '--clip-mode', self.clip_mode.get(),
                               '--clip-min', str(self.clip_min.get()),
                               '--clip-max', str(self.clip_max.get()),
                               '--post-action', post_action]
                if self.clip_mode.get() == 'vislide':
                    script_args.extend(['--vislide-interval', str(self.vislide_interval.get())])
                if two_pass:
                    script_args.append('--two-pass')
                phases = [script_args]
            elif start_mode == "script_tts":
                # Phase 1: TTS only → generates audio in ready_to_go/
                tts_args = ['python', str(AGENT_DIR / 'tools' / 'tts_runner.py'),
                            '--mode', 'silent', '--tts-only']
                # Phase 2: full pipeline with all GUI settings (identical to audio mode)
                phases = [tts_args, process_args]
            else:
                phases = [process_args]

            # Set env vars for the subprocess
            env = os.environ.copy()
            env['VEONONSTOP_MAX_PARALLEL'] = str(self.veo_parallel.get())
            env['VEONONSTOP_ASPECT_RATIO'] = self.veo_ratio.get()
            env['VEONONSTOP_REQUEST_DELAY'] = str(self.veo_request_delay.get())
            env['VEONONSTOP_RECAPTCHA_DELAY']  = str(self.veo_recaptcha_delay.get())
            env['VEONONSTOP_RECAPTCHA_JITTER'] = str(self.veo_recaptcha_jitter.get())
            env['VEONONSTOP_MAX_RETRIES'] = str(self.veo_max_retries.get())
            env['VEONONSTOP_MAX_SILENT_CYCLES'] = str(self.veo_max_silent_cycles.get())
            env['VEONONSTOP_FAST_CENSOR'] = self.veo_fast_censor.get()
            env['VEONONSTOP_IMAGE_UPSCALE'] = self.image_upscale.get()
            env['VEONONSTOP_VIDEO_UPSCALE'] = 'true' if self.video_upscale.get() else ''
            env['VARAGENT_IMGGEN_KEY_SLOT']   = self.veo_imggen_key.get()
            env['VARAGENT_VIDEO_KEY_SLOT']    = self.veo_video_key.get()
            env['VARAGENT_IMGGEN_PARALLEL']   = str(self.veo_imggen_parallel.get())
            env['VARAGENT_VIDEO_PARALLEL']    = str(self.veo_parallel.get())
            env['VARAGENT_INFLIGHT_MODE']     = '1' if self.inflight_mode.get() else '0'
            env['VARAGENT_SKIP_PREFLIGHT']   = '1' if self.skip_preflight.get() else '0'
            env['STORY_MODE'] = self.story_mode.get()  # off | batch | morph | chain
            # PIPELINE_IMG_GEN — нужно Pass 2 director'у для адаптивного chain prompt
            # (i2v vs t2v режим HEAD клипа). post_action кодирует выбор как CLI флаг,
            # но gpt_director.py не получает post_action — поэтому пробрасываем env.
            env['PIPELINE_IMG_GEN'] = self.img_gen.get()
            # Chain Mode params — backend reads via config (env override)
            env['CHAIN_IMGGEN_HEADS_ONLY']    = '1' if self.app.chain_imggen_heads_only.get() else '0'
            env['VIDEO_EXTEND_MAX_CHAIN']     = str(self.app.chain_max_chain.get())
            env['CHAIN_CASCADE_RECOVERY']     = '1' if self.app.chain_cascade_recovery.get() else '0'
            env['CHAIN_MAX_SAME_CLIP_FAILS']  = str(self.app.chain_max_fails.get())
            env['VIDEO_EXTEND_FRAME_OFFSET']  = str(self.app.chain_frame_offset.get())
            env['VIDEO_EXTEND_TRIM_FRAMES']   = str(self.app.chain_trim_frames.get())
            env['VIDEO_EXTEND_MUTE_AUDIO']    = '1' if self.app.chain_mute_audio.get() else '0'
            if self.clip_mode.get() == 'vislide':
                env['VARAGENT_VISLIDE_INTERVAL'] = str(self.vislide_interval.get())

            # pipeline_config.json — слепок настроек первого запуска для ресюма через Finalize Stage.
            # Подхватится queue.create_project_folder() и положит в папку проекта.
            # Без этого vislide_interval теряется после закрытия GUI и Finalize получает video режим.
            try:
                import json as _json_cfg
                _pipe_cfg = {
                    'clip_mode':            self.clip_mode.get(),
                    'vislide_interval':     int(self.vislide_interval.get()) if self.clip_mode.get() == 'vislide' else 0,
                    'intro_block_duration': int(self.intro_duration.get()),
                    'intro_clip_min':       int(getattr(self, 'intro_clip_min', tk.IntVar(value=0)).get()) if hasattr(self, 'intro_clip_min') else 0,
                    'intro_clip_max':       int(getattr(self, 'intro_clip_max', tk.IntVar(value=0)).get()) if hasattr(self, 'intro_clip_max') else 0,
                    'clip_min':             int(self.clip_min.get()),
                    'clip_max':             int(self.clip_max.get()),
                    'director_backend':     self.director_backend.get(),
                    'gpt_model':            self.gpt_model.get() if self.director_backend.get() == 'gpt' else '',
                    'gemini_model':         self.gemini_model.get() if self.director_backend.get() == 'gemini' else '',
                    'two_pass':             bool(two_pass),
                    'prompt_mode':          self.prompt_mode.get(),
                    'post_action':          post_action,
                    'img_gen':              self.img_gen.get(),
                    'video_mode':           self.video_mode.get() if hasattr(self, 'video_mode') else '',
                    'video_engine':         self.video_engine.get(),
                    'story_mode':           self.story_mode.get(),
                    'language':             self.language.get(),
                }
                env['VARAGENT_PIPELINE_CONFIG_JSON'] = _json_cfg.dumps(_pipe_cfg, ensure_ascii=False)
            except Exception as _cfg_err:
                self.app.log(f"pipeline_config.json prep failed: {_cfg_err}", "WARNING", tab="pipeline")
            # Video engine routing — read by agent.py for inflight watcher script selection
            env['VARAGENT_VIDEO_ENGINE'] = self.video_engine.get()  # veononstop | fastgen_ultra | both
            # Flow Ultra key selection (Pipeline tab radio: key1 / key2 / both)
            if self.video_engine.get() in ('fastgen_ultra', 'both'):
                _fu_keys_pipe = self._pipe_fu_keys.get()
                env.pop('VARAGENT_FU_PRIMARY_KEY', None)
                env.pop('VARAGENT_FU_DUAL_KEY', None)
                if self.video_engine.get() == 'fastgen_ultra':
                    env['VARAGENT_VIDEO_KEY_SLOT'] = {'key1': '1', 'key2': '2', 'both': 'both'}.get(_fu_keys_pipe, '1')
                else:
                    env['VARAGENT_FU_KEY_SLOT'] = {'key1': '1', 'key2': '2', 'both': 'both'}.get(_fu_keys_pipe, '1')
                env['VARAGENT_FU_END_IMAGE'] = '1' if self._pipe_fu_end.get() else '0'
            env['FASTGEN_MODEL'] = FASTGEN_NAME_TO_KEY.get(self.fastgen_model.get(), self.fastgen_model.get())
            env['FASTGEN_ASPECT_RATIO'] = self.fastgen_aspect.get()
            env['FASTGEN_MAX_PARALLEL'] = str(self.fastgen_parallel.get())
            _fg_key_sel = self.fastgen_api_key.get()
            if ig == "fastgen":
                env['VARAGENT_IMGGEN_KEY_SLOT'] = {
                    'main': '1', 'backup': '2', 'key2': '2',
                    'key3': '3', 'key4': '4',
                    'both': 'all', 'all': 'all',
                }.get(_fg_key_sel, '1')
                if _fg_key_sel in ('both', 'all'):
                    env['FASTGEN_DUAL_KEY'] = '1'
                else:
                    env.pop('FASTGEN_DUAL_KEY', None)
            else:
                env.pop('FASTGEN_DUAL_KEY', None)
            env['VIDEO_CLIP_MIN_DURATION'] = str(self.clip_min.get())
            env['VIDEO_CLIP_MAX_DURATION'] = str(self.clip_max.get())
            env['ASSEMBLYAI_LANGUAGE_CODE'] = self.language.get()
            env['GEMINI_MODEL'] = self.gemini_model.get()
            env['DIRECTOR_BACKEND'] = self.director_backend.get()
            if self.director_backend.get() == 'gpt':
                env['GPT_MODEL'] = self.gpt_model.get()
                env['GPT_PASS2_CHUNK_SIZE'] = str(self.gpt_chunk_size.get())
                env['GPT_PASS2_PARALLEL'] = str(self.gpt_parallel.get())
                env['GPT_PROVIDER'] = self.gpt_provider.get()
                # deepseek/openrouter → прямой chat API (chat_director, без Codex/Moon Bridge).
                # openai → Codex (как раньше). Пробрасываем reasoning + max tokens.
                _prov = self.gpt_provider.get()
                if _prov in ('deepseek', 'openrouter'):
                    env['CHAT_REASONING_LEVEL'] = self.chat_reasoning.get()
                    env['CHAT_MAX_TOKENS'] = str(self.chat_max_tokens.get())
                if _prov == 'deepseek':
                    env['DEEPSEEK_MODEL'] = self.deepseek_model.get()
                elif _prov == 'openrouter':
                    # лейбл → (реальный slug, web) через OR_DIRECTOR_LABEL_TO_MV
                    _real, _web = OR_DIRECTOR_LABEL_TO_MV.get(
                        self.openrouter_model.get(), ('openrouter/free', 'disabled'))
                    env['OPENROUTER_MODEL'] = _real
                    env['OPENROUTER_WEB_SEARCH'] = _web
            elif self.director_backend.get() == 'claude_api':
                env['CLAUDE_API_MODEL'] = self.claude_api_model.get()
                env['CLAUDE_API_PASS2_CHUNK_SIZE'] = str(self.claude_chunk_size.get())
            elif self.director_backend.get() == 'claude_code':
                env['CLAUDE_MODEL'] = self.claude_code_model.get()
                env['CLAUDE_CODE_PASS2_CHUNK_SIZE'] = str(self.claude_chunk_size.get())
            env['INTRO_BLOCK_DURATION'] = str(self.intro_duration.get())
            env['INTRO_CLIP_MIN_DURATION'] = str(self.intro_clip_min.get())
            env['INTRO_CLIP_MAX_DURATION'] = str(self.intro_clip_max.get())
            env['DIRECTOR_PASS1_CHUNK_THRESHOLD'] = str(self.p1_chunk_threshold.get() * 60)
            env['DIRECTOR_PASS1_CHUNK_DURATION']  = str(self.p1_chunk_duration.get()  * 60)
            env['REMIX_ENGINE'] = self.remix_engine.get()
            env['REWRITE_MODEL'] = REWRITE_LABEL_TO_SPEC.get(self.rewrite_model.get(), 'gemini:gemini-2.5-flash-lite')
            # --- Экономия токенов (вынос стиль/негатив) passthrough ---
            if self.style_extract_neuro.get():
                env['STYLE_EXTRACT_MODE'] = 'neuro'
            elif self.style_extract_regex.get():
                env['STYLE_EXTRACT_MODE'] = 'regex'
            else:
                env['STYLE_EXTRACT_MODE'] = 'off'
            _seb = self.style_extract_backend.get()
            env['STYLE_EXTRACT_BACKEND'] = '' if _seb == 'auto' else _seb
            # --- Music (Pass 3 — Suno) settings passthrough ---
            env['MUSIC_PROVIDER'] = self.music_provider.get()
            env['MUSIC_DIRECTOR_BACKEND'] = (self.music_backend.get() or '').strip()
            # Music chat-model: openrouter лейбл → slug; deepseek — прямой slug
            _mb = self.music_backend.get()
            if _mb == 'openrouter':
                _mm_real, _ = OR_DIRECTOR_LABEL_TO_MV.get(self.music_chat_model.get(), ('', ''))
                env['MUSIC_CHAT_MODEL'] = _mm_real
            elif _mb == 'deepseek':
                env['MUSIC_CHAT_MODEL'] = self.music_chat_model.get()
            else:
                env['MUSIC_CHAT_MODEL'] = ''
            env['SUNO_COOKIE_BROWSER'] = self.music_browser.get()
            env['SUNO_MODEL'] = self.music_model.get()
            env['MUSIC_DEFAULT_VOLUME_DB'] = str(self.music_volume_db.get())
            env['MUSIC_DUCKING_DB'] = str(self.music_ducking_db.get())
            env['VARAGENT_MUSIC_ENABLED'] = '1' if self.music_enabled.get() else '0'
            env['VARAGENT_MUSIC_REVIEW_GUI'] = '1' if self.music_review_gui.get() else '0'
            # --- Entity overlays passthrough ---
            env['ENTITY_OVERLAY_ENABLED'] = 'true' if self.entity_overlay_enabled.get() else 'false'
            env['ENTITY_OVERLAY_MAX'] = str(self.entity_overlay_max.get())
            env['ENTITY_OVERLAY_BACKEND'] = self.entity_overlay_backend.get()
            if ig == "veononstop":
                env['VEONONSTOP_IMGGEN_MODE'] = self.veo_imggen_mode.get()
                env['VEONONSTOP_BANANA_MODEL'] = BANANA_NAME_TO_KEY.get(self.veo_banana_model.get(), 'GEM_PIX_2')
            wm = self.watermark.get()
            if wm != 'as_is':
                env['WATERMARK_MODE'] = wm
            if self.logo_mode.get() == "individual":
                _plogo_root = SCRIPT_DIR / '.pending_logos'
                _logo_map = {}
                for _f in self.loaded_files:
                    _sd = _plogo_root / _f.stem
                    if _sd.exists():
                        _logos = list(_sd.iterdir())
                        if _logos:
                            _audio_key = (_f.stem + '.mp3') if start_mode == 'script_tts' else _f.name
                            _logo_map[_audio_key] = str(_logos[0])
                if _logo_map:
                    env['VARAGENT_LOGO_MAP'] = _json.dumps(_logo_map, ensure_ascii=False)
            else:
                if self.logo_path and self.logo_path.exists():
                    env['LOGO_PATH'] = str(self.logo_path)
            if self.single_prompt_path and self.single_prompt_path.exists():
                env['SINGLE_PROMPT_FILE'] = str(self.single_prompt_path)
            if self.ref_mode.get() == "individual":
                # Individual refs: build ref-map from per-file staging dirs
                _pref_root = SCRIPT_DIR / '.pending_refs'
                _ref_map = {}
                for _f in self.loaded_files:
                    _sd = _pref_root / _f.stem
                    if _sd.exists() and any(_sd.iterdir()):
                        _ref_map[_f.name] = str(_sd)
                if _ref_map:
                    process_args.extend(['--ref-map', _json.dumps(_ref_map, ensure_ascii=False)])
            else:
                staging = SCRIPT_DIR / '.pending_refs'
                if staging.exists():
                    env['VARAGENT_REF_STAGING'] = str(staging)
            cover_staging = SCRIPT_DIR / '.pending_cover_refs'
            if cover_staging.exists():
                env['VARAGENT_COVER_REF_STAGING'] = str(cover_staging)
            if self.yt_pack_enabled.get():
                env['YT_PACK_CONTENT_MODEL'] = self.yt_pack_content_model.get()
                env['YT_PACK_TRANSLATE_MODEL'] = self.yt_pack_content_model.get()
                env['YT_PACK_LANGUAGES'] = self.yt_pack_languages.get()
                env['YT_PACK_SUBTITLES'] = 'true' if self.yt_pack_subtitles.get() else 'false'
                env['YT_PACK_DESCRIPTION'] = 'true' if self.yt_pack_description.get() else 'false'
                env['YT_PACK_COVERS'] = 'true' if self.yt_pack_covers.get() else 'false'
                env['YT_PACK_COVER_PROVIDER'] = self.cover_provider.get()
                env['YT_PACK_COVER_MODEL'] = self.cover_model.get()
                # Add --yt-pack to every agent.py phase (not tts_runner)
                for phase in phases:
                    if 'tts_runner' not in phase[1] and '--yt-pack' not in phase:
                        phase.append('--yt-pack')

            # ── Watermark / fingerprint removal ──────────────────────────────
            if self.audio_clean_enabled.get():
                env['VARAGENT_AUDIO_CLEAN']       = '1'
                env['VARAGENT_AUDIO_CLEAN_LEVEL'] = self.audio_clean_level.get()
            if self.synthid_clean_enabled.get():
                env['VARAGENT_SYNTHID_CLEAN']     = '1'
                env['VARAGENT_SYNTHID_STRENGTH']  = self.synthid_strength.get()
                env['VARAGENT_SYNTHID_VERSION']   = self.synthid_version.get()
                env['VARAGENT_SYNTHID_SAVE_ORIG'] = '1' if self.synthid_save_orig.get() else '0'

            # ── Real Photo Stage ──────────────────────────────────────────────
            if self.real_photo_enabled.get():
                env['REAL_PHOTO_ENABLED']      = '1'
                env['REAL_PHOTO_RATIO_TARGET'] = f'{self.real_photo_target.get() / 100:.3f}'
                env['REAL_PHOTO_RATIO_MIN']    = f'{self.real_photo_min.get()    / 100:.3f}'
                env['REAL_PHOTO_RATIO_MAX']    = f'{self.real_photo_max.get()    / 100:.3f}'
                _rp_srcs = []
                if self.real_photo_src_wikimedia.get():   _rp_srcs.append('wikimedia')
                if self.real_photo_src_nasa.get():        _rp_srcs.append('nasa')
                if self.real_photo_src_loc.get():         _rp_srcs.append('loc')
                if self.real_photo_src_met.get():         _rp_srcs.append('met')
                if self.real_photo_src_getty.get():       _rp_srcs.append('getty')
                if self.real_photo_src_europeana.get():   _rp_srcs.append('europeana')
                if self.real_photo_src_smithsonian.get(): _rp_srcs.append('smithsonian')
                if self.real_photo_src_rijksmuseum.get(): _rp_srcs.append('rijksmuseum')
                if self.real_photo_src_archive.get():     _rp_srcs.append('archive')
                if _rp_srcs:
                    env['REAL_PHOTO_SOURCES'] = ','.join(_rp_srcs)

            # ── Convert phases to (args, env) tuples ──
            # Per-file split убран: очередь = серия одиночных запусков, оркестратор
            # _pipeline_worker подаёт по одному файлу со своим слепком настроек.
            # Здесь всегда обрабатывается текущий self.loaded_files как есть.
            phases = [(ph, dict(env)) for ph in phases]

            self.app.log("Starting pipeline...", "INFO", tab="pipeline")
            # ── Settings dump (full — for debug) ──
            self.app.log("━" * 56, tab="pipeline")
            files_str = ", ".join(f.name for f in self.loaded_files) if self.loaded_files else "(none)"
            self.app.log(f"  Start:     {start_mode}  |  Files: {files_str}", tab="pipeline")
            self.app.log(f"  Language:  {self.language.get()}  |  Direction: {self.direction_mode.get()}  |  Backend: {self.director_backend.get()}", tab="pipeline")
            self.app.log(f"  Gemini:    {self.gemini_model.get()}  |  Chunk: {self.p1_chunk_threshold.get()}m/{self.p1_chunk_duration.get()}m", tab="pipeline")
            if self.director_backend.get() == 'gpt':
                self.app.log(f"  GPT:       {self.gpt_model.get()}", tab="pipeline")
            self.app.log(f"  Clips:     {self.clip_mode.get()} {self.clip_min.get()}-{self.clip_max.get()}s  |  Intro: {self.intro_duration.get()}s block {self.intro_clip_min.get()}-{self.intro_clip_max.get()}s", tab="pipeline")
            self.app.log(f"  Post:      {post_action}  |  VideoEngine: {self.video_engine.get()}  |  Prompt: {self.prompt_mode.get()}  |  Render: {'fast' if self.render_mode.get() == '720p' else '1080p'}", tab="pipeline")
            if ig == "veononstop":
                self.app.log(f"  VeoNonStop: imggen={self.veo_imggen_mode.get()} model={self.veo_banana_model.get()} ratio={self.veo_ratio.get()}", tab="pipeline")
                self.app.log(f"  VEO keys:  img={self.veo_imggen_key.get()} x{self.veo_imggen_parallel.get()}  |  vid={self.veo_video_key.get()} x{self.veo_parallel.get()}", tab="pipeline")
                self.app.log(f"  VEO opts:  delay={self.veo_request_delay.get()}s retries={self.veo_max_retries.get()} cycles={self.veo_max_silent_cycles.get()} censor={self.veo_fast_censor.get()}", tab="pipeline")
                self.app.log(f"  Upscale:   img={self.image_upscale.get()} vid={self.video_upscale.get()}  |  Inflight: {self.inflight_mode.get()}", tab="pipeline")
            elif ig == "fastgen":
                self.app.log(f"  FastGen:   model={self.fastgen_model.get()} ratio={self.fastgen_aspect.get()} x{self.fastgen_parallel.get()} key={self.fastgen_api_key.get()}", tab="pipeline")
            self.app.log(f"  Remix:     {self.remix_engine.get()}  |  Skip preflight: {self.skip_preflight.get()}  |  Codex adapt: {self.codex_adapt_var.get()}", tab="pipeline")
            self.app.log(f"  Rewrite:   {self.rewrite_model.get()}", tab="pipeline")
            _subs_tpl = self.subtitles_path.get() if self.subtitles_custom.get() else self.subtitles_preset.get()
            self.app.log(f"  Concat:    render={self.render_mode.get()} bitrate={self.concat_bitrate.get()} veo_sound={self.keep_veo_sound.get()} keep_files={self.keep_files.get()} subs={self.subtitles_enabled.get()} ({_subs_tpl})", tab="pipeline")
            extras = []
            if wm != 'as_is':
                extras.append(f"watermark={wm}")
            if self.logo_path and self.logo_path.exists():
                extras.append(f"logo={self.logo_path.name}")
            if self.ref_mode.get() == "individual":
                _n_ind = sum(len(v) for v in self.ref_individual.values())
                if _n_ind:
                    extras.append(f"refs=individual ({_n_ind} total across {len(self.ref_individual)} files)")
            elif self.ref_images:
                extras.append(f"refs={len(self.ref_images)} ({', '.join(r.name for r in self.ref_images)})")
            if self.single_prompt_path and self.single_prompt_path.exists():
                extras.append(f"prompt={self.single_prompt_path.name}")
            if self.clip_mode.get() == 'vislide':
                extras.append(f"vislide={self.vislide_interval.get()}")
            if extras:
                self.app.log(f"  Extras:    {' | '.join(extras)}", tab="pipeline")
            if self.yt_pack_enabled.get():
                self.app.log(f"  YT Pack:   langs={self.yt_pack_languages.get()} subs={self.yt_pack_subtitles.get()} desc={self.yt_pack_description.get()} covers={self.yt_pack_covers.get()} provider={self.cover_provider.get()} model={self.cover_model.get()}", tab="pipeline")
            if self.audio_clean_enabled.get():
                self.app.log(f"  AudioClean: enabled  level={self.audio_clean_level.get()}", tab="pipeline")
            if self.synthid_clean_enabled.get():
                self.app.log(f"  SynthID:    enabled  strength={self.synthid_strength.get()}  version={self.synthid_version.get()}", tab="pipeline")
            if self.real_photo_enabled.get():
                _rp_srcs_log = env.get('REAL_PHOTO_SOURCES', '(none)')
                self.app.log(f"  RealPhoto:  enabled  target={self.real_photo_target.get()}%  sources={_rp_srcs_log}", tab="pipeline")
            self.app.log(f"  Phases:    {len(phases)}", tab="pipeline")
            for _pi, (_ph, _) in enumerate(phases, 1):
                self.app.log(f"    [{_pi}] {' '.join(_ph)}", tab="pipeline")
            self.app.log("━" * 56, tab="pipeline")
            self.root.after(0, lambda: self._set_stage(0))

            stage_map = {
                # English keys
                'STAGE 1': 1, 'Transcrib': 1,
                'STAGE 2': 2, 'Direction': 2, 'Director': 2,
                'STAGE 3:': 3, 'Image gen': 3, 'FastGen': 3, 'imggen': 3,
                'STAGE 3.5': 4, 'Video gen': 4, 'veo_video': 4,
                'STAGE 4': 5, 'Concat': 5, 'video_concat': 5,
                'YT Pack': 6, 'YT PACKER': 6, 'yt_pack': 6,
                # Russian keys (agent outputs in Russian)
                'транскрипц': 1, 'загрузка аудио': 1,
                'режиссерск': 2, 'монтажный план': 2, 'проход 1/2': 2, 'отправка запроса': 2,
                'img2video': 4, 'i2v': 4,
            }

            _SPINNER_CHARS = set('⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏')
            failed = False

            # Stage Progress: file tracking
            _queue_file_index = 0
            _queue_file_total = len(self.loaded_files) if self.loaded_files else 0

            # Concat: запускается сразу на каждый PROJECT_DONE в отдельном потоке
            import concurrent.futures as _cf
            render   = self.render_mode.get()
            bitrate  = self.concat_bitrate.get()
            _concat_pool = _cf.ThreadPoolExecutor(max_workers=1)
            _concat_futs = []

            # ── Audio cleaner async state ─────────────────────────────────────
            _audio_clean_event   = threading.Event()
            _audio_clean_event.set()    # pre-set = not running / already done
            _audio_clean_started = [False]
            _audio_clean_failed  = [False]

            def _do_concat(proj_dir):
                proj_path = Path(proj_dir)
                proj_name = proj_path.name
                _full_log_path = proj_path / 'pipeline_full.log'
                # ── Wait for audio cleaner before FFmpeg reads audio track ────
                if not _audio_clean_event.is_set():
                    self.app.log("── Waiting for audio cleaner (max 600s) ──", "INFO", tab="pipeline")
                    if not _audio_clean_event.wait(timeout=600):
                        self.app.log("[AudioClean] Timeout — using current audio", "WARNING", tab="pipeline")
                    elif _audio_clean_failed[0]:
                        self.app.log("[AudioClean] Reported failure — continuing with current audio", "WARNING", tab="pipeline")
                self.app.log(f"── Concat: {proj_name} ({render}, {bitrate}) ──", "INFO", tab="pipeline")
                _wait_for_concat_readiness(
                    proj_path,
                    lambda msg, lvl='INFO': self.app.log(msg, lvl, tab="pipeline"),
                    cancel_cb=lambda: self._cancel.is_set(),
                )
                self.root.after(0, lambda: self._set_stage(5))
                # ── Music (Pass 3): plan + generate перед concat (если включено) ──
                if self.music_enabled.get():
                    try:
                        self.app.log(f"── Music: plan+generate ({proj_name}) ──", "INFO", tab="pipeline")
                        _mp_plan = subprocess.run(
                            [sys.executable, str(AGENT_DIR / 'agent.py'), 'music-plan', str(proj_path)],
                            env=env, cwd=str(AGENT_DIR), stdin=subprocess.DEVNULL,
                        )
                        if _mp_plan.returncode == 0:
                            subprocess.run(
                                [sys.executable, str(AGENT_DIR / 'agent.py'), 'music-generate', str(proj_path)],
                                env=env, cwd=str(AGENT_DIR), stdin=subprocess.DEVNULL,
                            )
                        else:
                            self.app.log("[Music] music-plan failed — concat без музыки", "WARNING", tab="pipeline")
                    except Exception as _me:
                        self.app.log(f"[Music] error: {_me} — concat без музыки", "WARNING", tab="pipeline")
                cmd = [sys.executable, str(SCRIPT_DIR / 'video_concat.py'),
                       'montage_plan.json', '-o', f'{proj_name}.mp4', '-b', bitrate,
                       '--fps', str(self.concat_fps.get())]
                _mplan_f = proj_path / 'music_plan.json'
                _mdir_f = proj_path / 'music'
                if (self.music_enabled.get() and _mplan_f.exists()
                        and _mdir_f.exists() and any(_mdir_f.glob('*.mp3'))):
                    cmd.extend(['--music-plan', 'music_plan.json', '--music-dir', 'music'])
                if self.entity_overlay_enabled.get():
                    cmd.extend(['--entity-overlays',
                                '--max-entity-overlays', str(self.entity_overlay_max.get()),
                                '--entity-overlay-backend', self.entity_overlay_backend.get()])
                if render == '1080p':
                    cmd.extend(['-r', '1080'])
                elif render == '4k':
                    cmd.extend(['-r', '4k'])
                if self.watermark.get() == 'blur':
                    cmd.append('--blur-borders')
                if (self.logo_mode.get() == "one_for_all"
                        and self.watermark.get() == 'logo'
                        and self.logo_path and self.logo_path.exists()):
                    cmd.extend(['--logo', str(self.logo_path)])
                # Individual + logo watermark: logo.png placed by queue.py, auto-detected by video_concat.py
                if self.keep_veo_sound.get():
                    cmd.append('--veo-audio-inline')
                if self.subtitles_enabled.get():
                    _tpl = (self.subtitles_path.get() if self.subtitles_custom.get()
                            else _find_ass_template(self.render_mode.get(), self.subtitles_preset.get()))
                    if _tpl:
                        cmd.extend(['--subtitles', _tpl])
                if self.keep_files.get():
                    cmd.append('--no-cleanup')
                cp = subprocess.Popen(
                    cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    stdin=subprocess.DEVNULL,
                    text=True, encoding='utf-8', errors='replace',
                    cwd=str(proj_path), env=env
                )
                _flog = open(_full_log_path, 'a', encoding='utf-8')
                _flog.write(f"\n── Concat: {proj_name} ({render}, {bitrate}) ──\n")
                for ln in cp.stdout:
                    if self._cancel.is_set():
                        cp.terminate()
                        break
                    ln = ln.rstrip()
                    if not ln:
                        continue
                    if ln.startswith('PROGRESS:'):
                        pm = re.match(r'PROGRESS:(\d+)/(\d+)', ln)
                        if pm:
                            pc, pt = int(pm.group(1)), int(pm.group(2))
                            if 0 <= pc <= pt <= 50000:
                                self.root.after(0, lambda c=pc, t=pt: self._set_task_progress(c, t))
                        continue
                    # Concat progress: "AAC кодирование: 50% ..." or "Сборка: 52% ..."
                    _pct_m = re.search(r'(?:кодирование|Сборка):\s*(\d+)%', ln)
                    if _pct_m:
                        _pct = int(_pct_m.group(1))
                        self.root.after(0, lambda c=_pct, t=100: self._set_task_progress(c, t))
                    m2 = re.search(r'\b(\d+)\s*/\s*(\d+)\b', ln)
                    if m2:
                        c2, t2 = int(m2.group(1)), int(m2.group(2))
                        if 0 < t2 <= 50000 and 0 <= c2 <= t2:
                            self.root.after(0, lambda c=c2, t=t2: self._set_task_progress(c, t))
                    lv = 'INFO'
                    lo = ln.lower()
                    if any(x in lo for x in ['error', 'fail', 'traceback']):
                        lv = 'ERROR'
                    elif any(x in lo for x in ['done', 'ok', 'complete', 'success', 'written']):
                        lv = 'SUCCESS'
                    self.app.log(ln, lv, tab="pipeline")
                    _flog.write(ln + '\n')
                _flog.close()
                cp.wait()
                return cp.returncode == 0
            # ETA tracking for imggen (stage 3) and videogen (stage 4)
            _eta_stage = 0       # current stage index
            _eta_start = None    # time when first clip of current stage arrived
            _eta_start_cur = 0   # clips already done when we started tracking
            for _phase_idx, (phase_args, phase_env) in enumerate(phases, 1):
                if self._cancel.is_set():
                    break
                if len(phases) > 1:
                    phase_label = Path(phase_args[1]).name if len(phase_args) > 1 else phase_args[0]
                    self.app.log(f"── Phase {_phase_idx}/{len(phases)}: {phase_label} ──", "INFO", tab="pipeline")
                proc = subprocess.Popen(
                    phase_args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    stdin=subprocess.DEVNULL,
                    text=True, encoding='utf-8', errors='replace',
                    cwd=str(SCRIPT_DIR), env=phase_env
                )
                for line in proc.stdout:
                    if self._cancel.is_set():
                        proc.terminate()
                        break
                    line = line.rstrip()
                    if not line:
                        continue
                    # Spinner lines (braille frames from director _run_with_spinner)
                    stripped = line.strip()
                    if stripped and stripped[0] in _SPINNER_CHARS and '✅' not in line:
                        self.root.after(0, lambda t=stripped: self.spinner_lbl.config(text=t))
                        ms = re.search(r'\b(\d+)\s*/\s*(\d+)\b', stripped)
                        if ms:
                            sc, st = int(ms.group(1)), int(ms.group(2))
                            if 0 < st <= 50000 and 0 <= sc <= st:
                                self.root.after(0, lambda c=sc, t=st: self._set_task_progress(c, t))
                        continue
                    # Done line — clear spinner
                    if '✅' in line:
                        self.root.after(0, lambda: self.spinner_lbl.config(text=""))
                    # Сигнал от agent.py: проект полностью готов к конкату
                    if line.startswith('PROJECT_DONE:'):
                        ppath = line.split(':', 1)[1].strip()
                        if ppath:
                            # ── Start audio cleaner in background ────────────
                            if (env.get('VARAGENT_AUDIO_CLEAN') == '1'
                                    and not _audio_clean_started[0]
                                    and not self._cancel.is_set()):
                                _audio_clean_started[0] = True
                                _audio_clean_event.clear()  # signal: running

                                import time as _time_ac
                                _ac_log_path = Path(ppath) / f"stage_AudioClean_{_time_ac.strftime('%H%M%S')}.log"

                                def _audio_clean_worker(
                                        _pp=ppath,
                                        _evt=_audio_clean_event,
                                        _fail=_audio_clean_failed,
                                        _env=dict(env),
                                        _logp=_ac_log_path):
                                    _log_fh = None
                                    try:
                                        _proj = Path(_pp)
                                        _audios = [
                                            f for f in (
                                                list(_proj.glob('*.mp3'))
                                                + list(_proj.glob('*.wav'))
                                                + list(_proj.glob('*.flac'))
                                            )
                                            if '_original' not in f.name and '_clean' not in f.name
                                        ]
                                        if not _audios:
                                            self.app.log("[AudioClean] No audio found in project folder", "WARNING", tab="pipeline")
                                            return
                                        _af = str(_audios[0])
                                        _level = _env.get('VARAGENT_AUDIO_CLEAN_LEVEL', 'moderate')
                                        self.app.log(f"[AudioClean] {_audios[0].name}  level={_level}", "INFO", tab="pipeline")
                                        _log_fh = open(_logp, 'w', encoding='utf-8', buffering=1)
                                        _cmd = [
                                            sys.executable,
                                            str(AGENT_DIR / 'tools' / 'audio_cleaner.py'),
                                            _af, '--level', _level, '--inplace',
                                        ]
                                        _proc = subprocess.Popen(
                                            _cmd,
                                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                            text=True, encoding='utf-8', errors='replace',
                                            cwd=str(SCRIPT_DIR), env=_env,
                                        )
                                        for _ln in _proc.stdout:
                                            _ln = _ln.rstrip()
                                            if not _ln:
                                                continue
                                            if _log_fh:
                                                _log_fh.write(_ln + '\n')
                                            _lv = 'SUCCESS' if '[ok]' in _ln.lower() else ('ERROR' if 'error' in _ln.lower() else 'INFO')
                                            self.app.log(_ln, _lv, tab="pipeline")
                                        _proc.wait()
                                        if _proc.returncode != 0:
                                            _fail[0] = True
                                            self.app.log(f"[AudioClean] FAILED exit={_proc.returncode}", "ERROR", tab="pipeline")
                                        else:
                                            self.app.log("[AudioClean] Done", "SUCCESS", tab="pipeline")
                                    except Exception as _e:
                                        _fail[0] = True
                                        self.app.log(f"[AudioClean] Exception: {_e}", "ERROR", tab="pipeline")
                                    finally:
                                        if _log_fh:
                                            try:
                                                _log_fh.close()
                                            except Exception:
                                                pass
                                        _evt.set()

                                threading.Thread(
                                    target=_audio_clean_worker, daemon=True, name="audio-clean"
                                ).start()
                                self.app.log("[AudioClean] Background cleaning started...", "INFO", tab="pipeline")

                            _concat_futs.append(_concat_pool.submit(_do_concat, ppath))
                        continue
                    # Live Queue: agent.py detected new files in pipeline_queue/
                    if line.startswith('QUEUE_UPDATE:'):
                        _qm = re.match(r'QUEUE_UPDATE:\s*(\d+)', line)
                        if _qm:
                            _queue_file_total = int(_qm.group(1))
                            self.root.after(0, lambda t=_queue_file_total:
                                            self._set_current_file('', _queue_file_index, t))
                        continue
                    # Stage Progress: detect current file from agent.py "ПАЙПЛАЙН: name"
                    if 'ПАЙПЛАЙН:' in line or 'PIPELINE:' in line:
                        _queue_file_index += 1
                        _m_name = re.search(r'(?:ПАЙПЛАЙН|PIPELINE):\s*(.+)', line)
                        _fname = _m_name.group(1).strip() if _m_name else ''
                        _pos = _queue_file_index
                        _tot = _queue_file_total if _queue_file_total > 0 else _pos
                        self.root.after(0, lambda n=_fname, p=_pos, t=_tot:
                                        self._set_current_file(n, p, t))
                    # Явный сигнал прогресса от director.py / imggen / veo_video
                    if line.startswith('PROGRESS:'):
                        pm = re.match(r'PROGRESS:(\d+)/(\d+)', line)
                        if pm:
                            _pc, _pt = int(pm.group(1)), int(pm.group(2))
                            if 0 <= _pc <= _pt <= 50000:
                                self.root.after(0, lambda c=_pc, t=_pt: self._set_task_progress(c, t))
                                if _eta_stage in (3, 4) and _pc > 0 and _pt > 1:
                                    _now = time.time()
                                    if _eta_start is None:
                                        _eta_start = _now
                                        _eta_start_cur = _pc - 1
                                    _clips_since = _pc - _eta_start_cur
                                    _elapsed = _now - _eta_start
                                    if _clips_since > 0 and _elapsed > 0:
                                        _avg = _elapsed / _clips_since
                                        _rem = _pt - _pc
                                        _eta_sec = max(0.0, _avg * _rem)
                                        _cpm = 60.0 / _avg
                                        _mm, _ss = divmod(int(_eta_sec), 60)
                                        _eta_str = f"~{_mm}м {_ss:02d}с" if _mm > 0 else f"~{_ss}с"
                                        _lbl = (f"Final Stage {_eta_str}  "
                                                f"({_pc}/{_pt} клипов, ~{_avg:.0f}с/клип, ~{_cpm:.1f} кл/мин)")
                                        self.root.after(0, lambda t=_lbl: self.spinner_lbl.config(text=t))
                        continue
                    for key, idx in stage_map.items():
                        if key.lower() in line.lower():
                            if idx != _eta_stage:
                                if idx in (3, 4):
                                    _eta_start = None
                                    _eta_start_cur = 0
                                _eta_stage = idx
                            self.root.after(0, lambda i=idx: self._set_stage(i))
                            break
                    m = re.search(r'\b(\d+)\s*/\s*(\d+)\b', line)
                    if m:
                        cur, total = int(m.group(1)), int(m.group(2))
                        if 0 < total <= 50000 and 0 <= cur <= total:
                            if _eta_stage not in (2, 3, 4):
                                self.root.after(0, lambda c=cur, t=total: self._set_task_progress(c, t))
                    level = 'INFO'
                    low = line.lower()
                    stripped_low = low.strip()
                    if stripped_low.startswith('[ok]') or stripped_low.startswith('✅'):
                        level = 'SUCCESS'
                    elif any(x in low for x in ['error', 'fail', 'traceback']) and not _is_false_error_signal(line):
                        level = 'ERROR'
                    elif any(x in low for x in ['warn', 'skip', 'retry']):
                        level = 'WARNING'
                    self.app.log(line, level, tab="pipeline")
                proc.wait()
                if proc.returncode != 0:
                    self.app.log(f"Phase failed (exit code {proc.returncode})", "ERROR", tab="pipeline")
                    failed = True
                    break

            self.root.after(0, lambda: self.spinner_lbl.config(text=""))
            self.root.after(0, lambda: self._set_current_file("", 0, 0))

            # ── Ждём завершения всех конкатов (запускались сразу по PROJECT_DONE) ──
            _concat_pool.shutdown(wait=True)
            for _fut in _concat_futs:
                try:
                    if not _fut.result():
                        failed = True
                except Exception as _fe:
                    self.app.log(f"Concat error: {_fe}", "ERROR", tab="pipeline")
                    failed = True

            if not failed and not self._cancel.is_set():
                self.app.log("Pipeline complete!", "SUCCESS", tab="pipeline")
                self.root.after(0, lambda: self._set_stage(len(self.stage_labels)))
            elif self._cancel.is_set():
                self.app.log("Pipeline cancelled.", "WARNING", tab="pipeline")

        except Exception as e:
            self.app.log(f"Pipeline error: {e}", "ERROR", tab="pipeline")
        # is_running / кнопки сбрасывает оркестратор _pipeline_worker после всей
        # серии — здесь НЕ трогаем, иначе кнопки разблокируются после 1-го файла.

    def _toggle_chain_settings_pipe(self):
        """Показать/скрыть chain settings в зависимости от выбранного режима."""
        if self.story_mode.get() == 'chain':
            self._chain_pipe_frame.pack(fill=tk.X, pady=(4, 0))
        else:
            self._chain_pipe_frame.pack_forget()


# ════════════════════════════════════════════════════════════════════
# TAB 2: CONTROL PANEL
# ════════════════════════════════════════════════════════════════════

def _veo_key_options() -> list:
    """All single-key and multi-key combos for configured VeoNonStop keys."""
    from itertools import combinations as _combs
    _attrs = ['VEONONSTOP_API_KEY', 'VEONONSTOP_API_KEY_2', 'VEONONSTOP_API_KEY_3', 'VEONONSTOP_API_KEY_4']
    configured = [i + 1 for i, attr in enumerate(_attrs) if bool(getattr(config, attr, ''))]
    if not configured:
        return ['1']
    opts = [str(k) for k in configured]
    for r in range(2, len(configured) + 1):
        for combo in _combs(configured, r):
            opts.append(','.join(str(k) for k in combo))
    return opts


def _veo_sel_to_active(sel: str) -> list:
    """Convert key selection string to active_keys list for generate_all_*.
    Formats: 'key1' | 'all' | 'both' | '1,2,3' (comma-separated slot numbers)."""
    _ALL_ATTRS = ['VEONONSTOP_API_KEY', 'VEONONSTOP_API_KEY_2', 'VEONONSTOP_API_KEY_3', 'VEONONSTOP_API_KEY_4']
    if sel in ('both', 'all'):
        active = [i + 1 for i, a in enumerate(_ALL_ATTRS) if bool(getattr(config, a, ''))]
        return active if active else [1]
    # Comma-separated: "1,2" or "1,3"
    if ',' in sel:
        try:
            return [int(x) for x in sel.split(',') if x.strip()]
        except Exception:
            pass
    try:
        n = int(sel.replace('key', ''))
        return [n]
    except Exception:
        return [1]


class ControlPanelTab:
    """Project browser, per-stage buttons, .env editor."""

    def __init__(self, notebook, app: VarAgentGUI):
        self.app = app
        self.root = app.root
        self.frame = ttk.Frame(notebook)
        self.active_tasks = 0
        self._active_subproc = None  # текущий subprocess.Popen (Concat и др.)
        self._active_subprocs = set()
        # SynthID vars for finalize panel (independent from Pipeline tab)
        self._fin_synthid_enabled  = tk.BooleanVar(value=getattr(config, 'SYNTHID_CLEAN_ENABLED', False))
        self._fin_synthid_strength = tk.StringVar(value=getattr(config, 'SYNTHID_STRENGTH',      'moderate'))
        self._fin_synthid_version  = tk.StringVar(value=getattr(config, 'SYNTHID_VERSION',       'v1'))
        self._fin_synthid_save_orig= tk.BooleanVar(value=getattr(config, 'SYNTHID_SAVE_ORIG',    False))
        self.create_ui()

    def _track_subprocess(self, proc):
        if proc:
            self._active_subproc = proc
            self._active_subprocs.add(proc)

    def _untrack_subprocess(self, proc):
        if proc:
            self._active_subprocs.discard(proc)
            if self._active_subproc is proc:
                self._active_subproc = None

    def _terminate_process_tree(self, proc, force=False):
        """Stop a child process and its descendants."""
        if not proc or proc.poll() is not None:
            return False
        try:
            if os.name == 'nt':
                if not force:
                    try:
                        proc.terminate()
                        proc.wait(timeout=1.5)
                        return True
                    except subprocess.TimeoutExpired:
                        pass
                subprocess.run(
                    ['taskkill', '/PID', str(proc.pid), '/T', '/F'],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=10,
                )
            else:
                if force:
                    proc.kill()
                else:
                    proc.terminate()
            return True
        except Exception:
            try:
                proc.kill()
                return True
            except Exception:
                return False

    def _stop_active_subprocesses(self, force=False):
        procs = set(getattr(self, '_active_subprocs', set()))
        if self._active_subproc:
            procs.add(self._active_subproc)
        stopped = 0
        for proc in list(procs):
            if self._terminate_process_tree(proc, force=force):
                stopped += 1
            if proc.poll() is not None:
                self._untrack_subprocess(proc)
        return stopped

    def create_ui(self):
        # Static layout: panels pack top-down, log at bottom with expand=True
        self._inner = self.frame

        # Collapsible project list
        self._projects_frame = ttk.Frame(self._inner)
        self._projects_frame.pack(fill=tk.X)
        self._projects_collapsed = False
        card = self.app.create_card(self._projects_frame, "Projects")

        btn_row = ttk.Frame(card, style="Card.TFrame")
        btn_row.pack(fill=tk.X, pady=(0, 4))
        ttk.Button(btn_row, text="Refresh", command=self.refresh_projects).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="Delete", command=self._delete_projects,
                   style="Danger.TButton").pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="Dry-Run", command=self._run_dryrun).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="Mock Run", command=self._run_mock).pack(side=tk.LEFT, padx=2)
        self._pl_mode_btn = ttk.Button(btn_row, text="Pipeline Mode ▼",
                                       command=self._toggle_finalize_panel,
                                       style="Accent.TButton")
        self._pl_mode_btn.pack(side=tk.RIGHT, padx=2)
        self._hide_panels_btn = ttk.Button(btn_row, text="Hide panels", command=self._toggle_panels)
        self._hide_panels_btn.pack(side=tk.RIGHT, padx=2)

        cols = ("fresh", "name", "audio", "transcr", "plan", "images", "videos", "mp4", "status")
        self.tree = ttk.Treeview(card, columns=cols, show='headings', height=8)
        col_widths = [30, 180, 40, 40, 40, 50, 50, 40, 140]
        col_anchors = {c: (tk.CENTER if w < 100 else tk.W) for c, w in zip(cols, col_widths)}
        col_anchors['fresh'] = tk.CENTER
        for c, w in zip(cols, col_widths):
            self.tree.column(c, width=w, anchor=col_anchors[c])
        self.tree.pack(fill=tk.BOTH, expand=True)
        self.tree.bind('<Double-1>', self._open_project_folder)

        # Sort state: col key → ('fresh'=mtime desc by default), reverse flag
        self._sort_col = 'fresh'
        self._sort_reverse = True
        self._update_tree_headings()

        # Stage buttons
        self._stages_card = card2 = self.app.create_card(self._inner, "Run Stage")
        self.stage_buttons = []
        # Row 1: start stages (no project required — will create one)
        row1 = ttk.Frame(card2, style="Card.TFrame")
        row1.pack(fill=tk.X)
        for label, cmd in [
            ("Script→Audio", self._run_script_tts),
            ("Script→Video", self._run_script_video),
            ("Transcribe", self._run_transcribe),
        ]:
            btn = ttk.Button(row1, text=label, command=cmd)
            btn.pack(side=tk.LEFT, padx=3, pady=2)
            self.stage_buttons.append(btn)
        # Row 2: continuation stages (require existing project)
        row2 = ttk.Frame(card2, style="Card.TFrame")
        row2.pack(fill=tk.X, pady=(2, 0))
        for label, cmd in [
            ("Scene Director", self._run_direct),
            ("ImageGen", self._run_imagegen),
            ("VideoGen", self._run_videogen),
            ("Concat", self._run_concat),
            ("YT Pack", self._run_ytpack),
        ]:
            btn = ttk.Button(row2, text=label, command=cmd)
            btn.pack(side=tk.LEFT, padx=3, pady=2)
            self.stage_buttons.append(btn)

        # Row 3: watermark removal standalone tools
        row3 = ttk.Frame(card2, style="Card.TFrame")
        row3.pack(fill=tk.X, pady=(2, 0))
        _b_audio = ttk.Button(row3, text="Audio WM Cleaner", state='disabled')
        _b_audio.pack(side=tk.LEFT, padx=3, pady=2)
        _b_sid = ttk.Button(row3, text="SynthID Remover", command=self._run_synthid_clean_standalone)
        _b_sid.pack(side=tk.LEFT, padx=3, pady=2)
        self.stage_buttons.append(_b_sid)
        _b_fu = ttk.Button(row3, text="FastGen T2V (Flow Ultra)", command=self._run_fastgen_flow_ultra_t2v)
        _b_fu.pack(side=tk.LEFT, padx=3, pady=2)
        self.stage_buttons.append(_b_fu)
        _b_fu_ing = ttk.Button(row3, text="FastGen Ingredients (ref)", command=self._run_fastgen_flow_ultra_ingredients)
        _b_fu_ing.pack(side=tk.LEFT, padx=3, pady=2)
        self.stage_buttons.append(_b_fu_ing)
        _b_fu_kf = ttk.Button(row3, text="FastGen Keyframes (i2v)", command=self._run_fastgen_flow_ultra_keyframes)
        _b_fu_kf.pack(side=tk.LEFT, padx=3, pady=2)
        self.stage_buttons.append(_b_fu_kf)

        # Status bar + progress
        status_frame = ttk.Frame(card2, style="Card.TFrame")
        status_frame.pack(fill=tk.X, pady=(6, 0))
        self.status_label = tk.Label(status_frame, text="Ready", bg=COLORS['bg_card'],
                                     fg=COLORS['text_dim'], font=FONT_DIM, anchor=tk.W)
        self.status_label.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self._ctrl_stop_btn = ttk.Button(status_frame, text="Stop", command=self._stop_tasks, state=tk.DISABLED)
        self._ctrl_stop_btn.pack(side=tk.RIGHT, padx=4)
        # Always-enabled aggressive cancel — kills server zombies regardless of pipeline state
        self._ctrl_hardstop_btn = ttk.Button(status_frame, text="Hard Stop", command=self._hard_stop)
        self._ctrl_hardstop_btn.pack(side=tk.RIGHT, padx=4)
        ttk.Button(status_frame, text="Update Key", command=self._update_key_labels).pack(side=tk.RIGHT, padx=4)
        ttk.Button(status_frame, text="Restart Key", command=self._restart_key).pack(side=tk.RIGHT, padx=4)
        self.progress_bar = ttk.Progressbar(card2, style="Custom.Horizontal.TProgressbar",
                                            mode='indeterminate', length=300)
        self.progress_bar.pack(fill=tk.X, pady=(4, 0))

        # Log — expands to fill remaining height
        log_card = ttk.Frame(self._inner, style="Card.TFrame", padding=12)
        log_card.pack(fill=tk.BOTH, expand=True, pady=4, padx=2)
        _ctrl_log_hdr = ttk.Frame(log_card, style="Card.TFrame")
        _ctrl_log_hdr.pack(fill=tk.X)
        ttk.Label(_ctrl_log_hdr, text="Task Log", style="Section.TLabel").pack(side=tk.LEFT)
        ttk.Button(_ctrl_log_hdr, text="Clear", command=lambda: self.log_widget.delete("1.0", tk.END)).pack(side=tk.RIGHT)

        self.log_widget = self.app.create_log_widget(log_card)
        self.spinner_lbl = ttk.Label(log_card, text="", style="Dim.TLabel", anchor=tk.W, font=FONT_DIM)
        self.spinner_lbl.pack(fill=tk.X, pady=(1, 0))
        self._log_card = log_card

        # Finalize panel (hidden by default — toggled via Pipeline Mode button)
        self._finalize_visible = False
        self._finalize_frame = self._build_finalize_panel(self._inner)

        # Load data
        self.root.after(200, self.refresh_projects)

    _STATUS_ORDER = {
        'Complete': 0, 'Ready for Concat': 1, 'Ready for VideoGen': 2,
        'Ready for ImgGen': 3, 'Transcribed': 4, 'New': 5,
    }

    def _update_tree_headings(self):
        """Refresh column header labels with sort indicator."""
        cols = ("fresh", "name", "audio", "transcr", "plan", "images", "videos", "mp4", "status")
        labels = {
            'fresh': '🕐', 'name': 'Name', 'audio': 'Aud', 'transcr': 'Tr', 'plan': 'Plan',
            'images': 'Img', 'videos': 'Vid', 'mp4': 'MP4', 'status': 'Status',
        }
        asc_desc = '▲' if not self._sort_reverse else '▼'
        for c in cols:
            if c == self._sort_col:
                prefix = asc_desc + ' '
            else:
                prefix = ''
            self.tree.heading(c, text=prefix + labels[c],
                              command=lambda col=c: self._sort_by(col))

    def _sort_by(self, col):
        if col == self._sort_col:
            self._sort_reverse = not self._sort_reverse
        else:
            self._sort_col = col
            self._sort_reverse = col in ('fresh', 'images', 'videos')  # desc by default
        self._update_tree_headings()
        self.refresh_projects()

    def refresh_projects(self):
        # Remember selection
        sel_names = {
            name for i in self.tree.selection()
            for name in [self._project_name_from_item(i)]
            if name
        }

        self.tree.delete(*self.tree.get_children())
        projects_dir = SCRIPT_DIR / 'projects'
        if not projects_dir.exists():
            return

        projects = [p for p in projects_dir.iterdir()
                    if p.is_dir() and not p.name.startswith('_')]
        infos = [(p, self._scan_project(p)) for p in projects]

        col = self._sort_col
        rev = self._sort_reverse
        if col == 'fresh':
            infos.sort(key=lambda x: x[0].stat().st_mtime, reverse=rev)
        elif col == 'name':
            infos.sort(key=lambda x: x[1]['name'].lower(), reverse=rev)
        elif col == 'status':
            infos.sort(key=lambda x: self._STATUS_ORDER.get(x[1]['status'], 99), reverse=rev)
        elif col == 'images':
            infos.sort(key=lambda x: x[1]['img_count'], reverse=rev)
        elif col == 'videos':
            infos.sort(key=lambda x: x[1]['vid_count'], reverse=rev)
        else:
            infos.sort(key=lambda x: x[1]['name'].lower(), reverse=rev)

        for rank, (p, info) in enumerate(infos, 1):
            iid = self.tree.insert('', tk.END, values=(
                rank,
                info['name'],
                'Y' if info['has_audio'] else '-',
                'Y' if info['has_transcription'] else '-',
                'Y' if info['has_plan'] else '-',
                str(info['img_count']) if info['img_count'] else '-',
                str(info['vid_count']) if info['vid_count'] else '-',
                'Y' if info['has_mp4'] else '-',
                info['status'],
            ))
            if info['name'] in sel_names:
                self.tree.selection_add(iid)

    def _scan_project(self, p: Path) -> dict:
        has_audio = bool(list(p.glob('*.mp3')) + list(p.glob('*.wav')) + list(p.glob('*.flac'))
                         + list(p.glob('*.m4a')) + list(p.glob('*.aac'))
                         + list(p.glob('*.mp4')) + list(p.glob('*.mov')) + list(p.glob('*.mkv'))
                         + list(p.glob('*.webm')) + list(p.glob('*.avi')) + list(p.glob('*.m4v')))
        has_tr = (p / 'transcription.json').exists()
        has_plan = (p / 'montage_plan.json').exists()
        gen = p / 'generated'
        vid = p / 'vid_img'
        img_count = len(list(gen.glob('*.png'))) if gen.exists() else 0
        vid_count = len(list(vid.glob('*.mp4'))) if vid.exists() else 0
        has_mp4 = bool([f for f in p.glob('*.mp4') if f.parent == p])

        if has_mp4:
            status = 'Complete'
        elif vid_count > 0:
            status = 'Ready for Concat'
        elif img_count > 0:
            status = 'Ready for VideoGen'
        elif has_plan:
            status = 'Ready for ImgGen'
        elif has_tr:
            status = 'Ready for Direction'
        elif has_audio:
            status = 'Ready for Transcription'
        else:
            status = 'Empty'
        return dict(name=p.name, has_audio=has_audio, has_transcription=has_tr,
                    has_plan=has_plan, img_count=img_count, vid_count=vid_count,
                    has_mp4=has_mp4, status=status)

    def _project_name_from_item(self, item) -> str:
        """Return project folder name from Treeview row without relying on column order."""
        try:
            name = str(self.tree.set(item, 'name') or '').strip()
            if name:
                return name
        except Exception:
            pass
        try:
            values = list(self.tree.item(item).get('values') or [])
        except Exception:
            values = []
        projects_dir = SCRIPT_DIR / 'projects'
        for value in values:
            name = str(value).strip()
            if name and (projects_dir / name).is_dir():
                return name
        for value in values:
            name = str(value).strip()
            if name and name not in {'-', 'Y'} and not name.isdigit():
                return name
        return ''

    def _open_project_folder(self, event=None):
        sel = self.tree.selection()
        if not sel:
            return
        name = self._project_name_from_item(sel[0])
        if not name:
            return
        folder = SCRIPT_DIR / 'projects' / name
        if folder.exists():
            os.startfile(str(folder))

    def _delete_projects(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Warning", "Select a project first")
            return
        names = [self._project_name_from_item(i) for i in sel]
        names = [n for n in names if n]
        if not names:
            messagebox.showwarning("Warning", "Could not resolve selected project name")
            return
        if len(names) == 1:
            msg = f"Delete project '{names[0]}' from disk?\nThis cannot be undone."
        else:
            listing = '\n'.join(f"  • {n}" for n in names)
            msg = f"Delete {len(names)} projects from disk?\n{listing}\n\nThis cannot be undone."
        if not messagebox.askyesno("Delete Projects", msg, icon='warning'):
            return
        errors = []
        for name in names:
            folder = SCRIPT_DIR / 'projects' / name
            try:
                shutil.rmtree(str(folder))
            except Exception as e:
                errors.append(f"{name}: {e}")
        self.refresh_projects()
        if errors:
            messagebox.showerror("Delete failed", "\n".join(errors))

    def _get_selected(self) -> Optional[Path]:
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Warning", "Select a project first")
            return None
        name = self._project_name_from_item(sel[0])
        if not name:
            messagebox.showwarning("Warning", "Could not resolve selected project name")
            return None
        return SCRIPT_DIR / 'projects' / name

    def _update_status(self):
        n = self.active_tasks
        if n > 0:
            self.status_label.config(text=f"Running: {n} task{'s' if n > 1 else ''}", fg=COLORS['accent'])
            self.progress_bar.start(15)
            self._ctrl_stop_btn.config(state=tk.NORMAL)
        else:
            self.status_label.config(text="Ready", fg=COLORS['text_dim'])
            self.progress_bar.stop()
            self._ctrl_stop_btn.config(state=tk.DISABLED)

    def _ensure_hard_stop_event(self):
        if not hasattr(self.app, '_hard_stop_event'):
            self.app._hard_stop_event = threading.Event()
        return self.app._hard_stop_event

    def _clear_hard_stop_flag(self):
        self._ensure_hard_stop_event().clear()

    def _set_flowultra_stop(self):
        """Set Flow Ultra shutdown in both import namespaces used by old/new code."""
        for _mod_name in ('modules.fastgen', 'fastgen'):
            try:
                import importlib
                _m = importlib.import_module(_mod_name)
                getattr(_m, '_flowultra_shutdown_event').set()
            except Exception:
                pass

    def _clear_flowultra_stop(self):
        """Clear Flow Ultra shutdown in both import namespaces before a new FU run."""
        for _mod_name in ('modules.fastgen', 'fastgen'):
            try:
                import importlib
                _m = importlib.import_module(_mod_name)
                getattr(_m, '_flowultra_shutdown_event').clear()
            except Exception:
                pass

    def _stop_tasks(self):
        """Signal running generators to stop gracefully and cancel server-side tasks."""
        # imggen: set shutdown + cancel all server-side tasks
        try:
            from modules.imggen import _shutdown_event as _img_stop, _active_clients as _img_clients
            _img_stop.set()
            _cancelled_total = 0
            for _cc in _img_clients:
                try:
                    _cancelled_total += len(_cc.cancel_all_tasks())
                except Exception:
                    pass
            if _cancelled_total:
                self.app.log(f"Cancelled {_cancelled_total} imggen server task(s)", "WARNING", tab="control")
        except Exception:
            pass
        # veo_video: set shutdown + cancel all server-side tasks
        try:
            from modules.veo_video import _shutdown_requested as _veo_stop
            _veo_stop.set()
        except Exception:
            pass
        try:
            from modules.veo_video import _active_clients as _veo_clients
            _cancelled_v = 0
            for _cc in _veo_clients:
                try:
                    _cancelled_v += len(_cc.cancel_all_tasks())
                except Exception:
                    pass
            if _cancelled_v:
                self.app.log(f"Cancelled {_cancelled_v} videogen server task(s)", "WARNING", tab="control")
        except Exception:
            pass
        # fastgen Flow Ultra: set shutdown + cancel all server-side ops
        try:
            from modules.fastgen import (
                FastGenClient as _FGC,
                _flowultra_shutdown_event as _fu_stop,
                _flowultra_active_clients as _fu_clients,
            )
            self._set_flowultra_stop()
            _fu_total = 0
            for _cc in list(_fu_clients):
                try:
                    _res = _cc.cancel_all_tasks() or {}
                    _fu_total += int(_res.get('total_cancelled', 0)) if isinstance(_res, dict) else 0
                except Exception:
                    pass
            for _k_attr in ('FASTGEN_API_KEY', 'FASTGEN_API_KEY_2', 'FASTGEN_API_KEY_3', 'FASTGEN_API_KEY_4', 'FASTGEN_API_KEY_BACKUP'):
                try:
                    _key = getattr(config, _k_attr, '')
                    if _key:
                        _res = _FGC(api_key=_key).cancel_all_tasks() or {}
                        _fu_total += int(_res.get('total_cancelled', 0)) if isinstance(_res, dict) else 0
                except Exception:
                    pass
            if _fu_total:
                self.app.log(f"Cancelled {_fu_total} FastGen Flow Ultra op(s)", "WARNING", tab="control")
        except Exception:
            pass
        stopped = self._stop_active_subprocesses(force=False)
        if stopped:
            self.app.log(f"Stopped {stopped} subprocess tree(s)", "WARNING", tab="control")
        self.status_label.config(text="Stopping...", fg=COLORS.get('warning', COLORS['accent']))
        self.app.log("Stop signal sent — cancelling server tasks", "WARNING", tab="control")

    def _hard_stop(self):
        """Aggressive always-on kill: cancel-all on EVERY known server-side client
        (FastGen Flow Ultra, VeoNonStop videogen, VeoNonStop imggen) + set shutdown events
        on all modules. Works regardless of active_tasks count — usable to clean zombies
        when pipeline is idle."""
        self._ensure_hard_stop_event().set()
        _total_fu = 0
        _total_v  = 0
        _total_i  = 0

        # FastGen: cancel-all via known clients, plus direct call using configured keys
        try:
            from modules.fastgen import (
                FastGenClient as _FGC,
                _flowultra_shutdown_event as _fu_stop,
                _flowultra_active_clients as _fu_clients,
            )
            self._set_flowultra_stop()
            for _cc in list(_fu_clients):
                try:
                    _res = _cc.cancel_all_tasks() or {}
                    if isinstance(_res, dict):
                        _total_fu += int(_res.get('total_cancelled', 0))
                except Exception:
                    pass
            # Also try configured keys from .env directly — catches zombies even if no active client registered
            for _k_attr in ('FASTGEN_API_KEY', 'FASTGEN_API_KEY_2', 'FASTGEN_API_KEY_3', 'FASTGEN_API_KEY_4', 'FASTGEN_API_KEY_BACKUP'):
                try:
                    _key = getattr(config, _k_attr, '')
                    if _key:
                        _res = _FGC(api_key=_key).cancel_all_tasks() or {}
                        if isinstance(_res, dict):
                            _total_fu += int(_res.get('total_cancelled', 0))
                except Exception:
                    pass
        except Exception:
            pass

        # VeoNonStop video: shutdown + cancel-all on registered clients + all configured keys
        try:
            from modules.veo_video import _shutdown_requested as _veo_stop, _active_clients as _veo_clients
            _veo_stop.set()
            from modules.veononstop import VeoNonStopClient as _VNC
            for _cc in list(_veo_clients):
                try:
                    _total_v += len(_cc.cancel_all_tasks())
                except Exception:
                    pass
            # Configured keys
            for _key_attr, _base_attr in [
                ('VEONONSTOP_API_KEY',   'VEONONSTOP_API_BASE'),
                ('VEONONSTOP_API_KEY_2', 'VEONONSTOP_API_BASE_2'),
                ('VEONONSTOP_API_KEY_3', 'VEONONSTOP_API_BASE_3'),
                ('VEONONSTOP_API_KEY_4', 'VEONONSTOP_API_BASE_4'),
            ]:
                try:
                    _k = getattr(config, _key_attr, '')
                    if _k:
                        _b = getattr(config, _base_attr, '') or config.VEONONSTOP_API_BASE
                        _total_v += len(_VNC(api_key=_k, base_url=_b).cancel_all_tasks())
                except Exception:
                    pass
        except Exception:
            pass

        # VeoNonStop imggen: shutdown + cancel-all on registered clients
        try:
            from modules.imggen import _shutdown_event as _img_stop, _active_clients as _img_clients
            _img_stop.set()
            for _cc in list(_img_clients):
                try:
                    _total_i += len(_cc.cancel_all_tasks())
                except Exception:
                    pass
        except Exception:
            pass

        stopped = self._stop_active_subprocesses(force=True)
        if stopped:
            self.app.log(f"Hard-stopped {stopped} subprocess tree(s)", "WARNING", tab="control")

        self.app.log(
            f"HARD STOP sent. Cancelled: FastGen={_total_fu}, VideoGen={_total_v}, ImgGen={_total_i}",
            "WARNING", tab="control",
        )

    def _restart_key(self):
        """Cancel all server tasks WITHOUT stopping generation. Workers will retry."""
        def _do():
            _total = 0
            # VeoNonStop video clients
            try:
                from modules.veo_video import _active_clients as _veo_clients
                for _cc in _veo_clients:
                    try:
                        _cancelled = _cc.cancel_all_tasks()
                        _total += len(_cancelled) if isinstance(_cancelled, (list, dict)) else int(_cancelled or 0)
                    except Exception:
                        pass
            except Exception:
                pass
            # VeoNonStop image clients
            try:
                from modules.imggen import _active_clients as _img_clients
                for _cc in _img_clients:
                    try:
                        _cancelled = _cc.cancel_all_tasks()
                        _total += len(_cancelled) if isinstance(_cancelled, (list, dict)) else int(_cancelled or 0)
                    except Exception:
                        pass
            except Exception:
                pass
            self.app.log(f"Restart Key: cancelled {_total} server task(s) — workers will retry", "WARNING")
        threading.Thread(target=_do, daemon=True).start()

    def _update_key_labels(self):
        """Re-fetch VeoNonStop key labels (active/total) in background."""
        threading.Thread(target=self.app.tab_pipeline._fetch_veo_key_labels, daemon=True).start()

    def _run_in_thread(self, func, *args, task_name="", project_dir=None):
        self._clear_hard_stop_flag()
        self.active_tasks += 1
        self.root.after(0, self._update_status)
        self.app.log(f"Started: {task_name}", "INFO", tab="control")
        t_start = time.time()
        def worker():
            import datetime
            log_fh = None
            master_fh = None
            if project_dir:
                try:
                    ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
                    safe = "".join(c if c.isalnum() or c in '-_' else '_' for c in task_name)[:50]
                    log_path = Path(project_dir) / f"stage_{safe}_{ts}.log"
                    log_fh = open(log_path, 'w', encoding='utf-8')
                    log_fh.write(f"=== {task_name} | {datetime.datetime.now()} ===\n\n")
                    master_path = Path(project_dir) / 'pipeline_full.log'
                    master_fh = open(master_path, 'a', encoding='utf-8')
                    master_fh.write(f"\n{'='*60}\n=== {task_name} | {datetime.datetime.now()} ===\n{'='*60}\n\n")
                except Exception:
                    log_fh = None
                    master_fh = None
            try:
                with capture_stdout(self.app.log_queue, "control", log_file=log_fh, task_label=task_name, master_log=master_fh):
                    func(*args)
                elapsed = time.time() - t_start
                m, s = divmod(int(elapsed), 60)
                self.app.log(f"Done: {task_name} ({m}m {s}s)", "SUCCESS", tab="control")
                if log_fh:
                    log_fh.write(f"\n=== DONE: {m}m {s}s ===\n")
                if master_fh:
                    master_fh.write(f"\n=== DONE: {m}m {s}s ===\n")
            except Exception as e:
                elapsed = time.time() - t_start
                m, s = divmod(int(elapsed), 60)
                self.app.log(f"Error in {task_name} after {m}m {s}s: {e}", "ERROR", tab="control")
                if log_fh:
                    log_fh.write(f"\n=== ERROR after {m}m {s}s: {e} ===\n")
                if master_fh:
                    master_fh.write(f"\n=== ERROR after {m}m {s}s: {e} ===\n")
            finally:
                if log_fh:
                    try:
                        log_fh.close()
                    except Exception:
                        pass
                if master_fh:
                    try:
                        master_fh.close()
                    except Exception:
                        pass
                self.active_tasks = max(0, self.active_tasks - 1)
                self.root.after(0, self._update_status)
                self.root.after(0, self.refresh_projects)
        threading.Thread(target=worker, daemon=True).start()

    def _run_subprocess_in_thread(self, args_list, cwd=None, task_name="", env=None, project_dir=None):
        """Run subprocess with stdout piped to GUI log and optionally to stage/master log files."""
        self._clear_hard_stop_flag()
        self.active_tasks += 1
        self.root.after(0, self._update_status)
        self.app.log(f"Started: {task_name}", "INFO", tab="control")
        t_start = time.time()
        def worker():
            import datetime
            stage_fh = None
            master_fh = None
            if project_dir:
                try:
                    ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
                    safe = "".join(c if c.isalnum() or c in '-_' else '_' for c in task_name)
                    stage_path = Path(project_dir) / f"stage_{safe}_{ts}.log"
                    stage_fh = open(stage_path, 'w', encoding='utf-8')
                    stage_fh.write(f"=== {task_name} | {datetime.datetime.now()} ===\n\n")
                    master_path = Path(project_dir) / 'pipeline_full.log'
                    master_fh = open(master_path, 'a', encoding='utf-8')
                    master_fh.write(f"\n{'='*60}\n=== {task_name} | {datetime.datetime.now()} ===\n{'='*60}\n\n")
                except Exception:
                    stage_fh = None
                    master_fh = None
            try:
                _run_env = {**(env or os.environ), 'PYTHONIOENCODING': 'utf-8'}
                # Control Panel separate runs: подтягиваем актуальные REWRITE_MODEL и REMIX_ENGINE из config
                # (os.environ содержит значения на момент старта GUI, а пользователь мог поменять в любом диалоге).
                # Если вызывающий передал свой env с этими ключами — не перезаписываем.
                if 'REWRITE_MODEL' not in _run_env and hasattr(config, 'REWRITE_MODEL'):
                    _run_env['REWRITE_MODEL'] = str(config.REWRITE_MODEL)
                if 'REMIX_ENGINE' not in _run_env and hasattr(config, 'REMIX_ENGINE'):
                    _run_env['REMIX_ENGINE'] = str(config.REMIX_ENGINE)
                proc = subprocess.Popen(
                    args_list, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    stdin=subprocess.DEVNULL,
                    text=True, encoding='utf-8', errors='replace',
                    cwd=cwd or str(SCRIPT_DIR), env=_run_env
                )
                self._track_subprocess(proc)
                try:
                    for line in proc.stdout:
                        line = line.rstrip()
                        if not line:
                            continue
                        level = 'INFO'
                        low = line.lower()
                        if any(x in low for x in ['error', 'fail', 'traceback']) and not _is_false_error_signal(line):
                            level = 'ERROR'
                        elif any(x in low for x in ['[ok]', 'success', 'complete', 'saved']):
                            level = 'SUCCESS'
                        elif any(x in low for x in ['warn', 'skip', 'retry']):
                            level = 'WARNING'
                        self.app.log(line, level, tab="control")
                        if stage_fh:
                            try:
                                stage_fh.write(line + '\n')
                                stage_fh.flush()
                            except Exception:
                                pass
                        if master_fh:
                            try:
                                master_fh.write(line + '\n')
                                master_fh.flush()
                            except Exception:
                                pass
                except OSError:
                    pass  # pipe closed after terminate()
                proc.wait()
                self._untrack_subprocess(proc)
                elapsed = time.time() - t_start
                m, s = divmod(int(elapsed), 60)
                if proc.returncode == 0:
                    self.app.log(f"Done: {task_name} ({m}m {s}s)", "SUCCESS", tab="control")
                    if stage_fh:
                        stage_fh.write(f"\n=== DONE: {m}m {s}s ===\n")
                    if master_fh:
                        master_fh.write(f"\n=== DONE: {m}m {s}s ===\n")
                else:
                    self.app.log(f"Failed: {task_name} (exit {proc.returncode}, {m}m {s}s)", "ERROR", tab="control")
                    if stage_fh:
                        stage_fh.write(f"\n=== FAILED exit={proc.returncode}: {m}m {s}s ===\n")
                    if master_fh:
                        master_fh.write(f"\n=== FAILED exit={proc.returncode}: {m}m {s}s ===\n")
            except Exception as e:
                self.app.log(f"Error in {task_name}: {e}", "ERROR", tab="control")
                if stage_fh:
                    try:
                        stage_fh.write(f"\n=== ERROR: {e} ===\n")
                    except Exception:
                        pass
                if master_fh:
                    try:
                        master_fh.write(f"\n=== ERROR: {e} ===\n")
                    except Exception:
                        pass
            finally:
                if stage_fh:
                    try:
                        stage_fh.close()
                    except Exception:
                        pass
                if master_fh:
                    try:
                        master_fh.close()
                    except Exception:
                        pass
                self.active_tasks = max(0, self.active_tasks - 1)
                self.root.after(0, self._update_status)
                self.root.after(0, self.refresh_projects)
        threading.Thread(target=worker, daemon=True).start()

    # ── Stage Settings Dialog ──────────────────────────────────────
    def _show_stage_dialog(self, title, defaults: dict, on_run, help_text: str = None):
        """Show a dialog with stage defaults. User can edit or approve as-is.
        defaults = {label: (tk_var_class, default_value, options_or_range), ...}
        on_run(settings_dict) called if user confirms.
        """
        dlg = tk.Toplevel(self.root)
        dlg.title(title)
        dlg.configure(bg=COLORS['bg_dark'])
        dlg.resizable(False, True)
        dlg.transient(self.root)
        dlg.grab_set()

        # Fix width to 460px; height auto-expands to fit content
        dlg.geometry("+%d+%d" % (self.root.winfo_x() + 200, self.root.winfo_y() + 150))
        dlg.minsize(460, 1)
        dlg.maxsize(460, 900)

        _lbl_title = title if len(title) <= 55 else title[:52] + '...'
        ttk.Label(dlg, text=_lbl_title, style="Header.TLabel", wraplength=420).pack(padx=20, pady=(12, 4))

        settings_frame = ttk.Frame(dlg, style="Card.TFrame", padding=12)
        settings_frame.pack(fill=tk.X, padx=12, pady=4)

        vars_map = {}
        for label, (var_cls, default, opts) in defaults.items():
            row = ttk.Frame(settings_frame, style="Card.TFrame")
            row.pack(fill=tk.X, pady=3)
            ttk.Label(row, text=f"{label}:", style="Card.TLabel", width=18).pack(side=tk.LEFT)

            var = var_cls(value=default)
            vars_map[label] = var

            if var_cls is tk.BooleanVar:
                ttk.Checkbutton(row, variable=var, style="Card.TCheckbutton").pack(side=tk.LEFT, padx=4)
            elif isinstance(opts, list):
                ttk.Combobox(row, textvariable=var, values=opts, width=16, state='readonly').pack(side=tk.LEFT, padx=4)
            elif isinstance(opts, tuple) and len(opts) == 2:
                tk.Spinbox(row, textvariable=var, from_=opts[0], to=opts[1], width=6,
                           bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=4)
            elif opts == 'browse_file':
                # File picker: Entry + Browse button (var holds path or '')
                ttk.Entry(row, textvariable=var, width=28).pack(side=tk.LEFT, padx=4)
                def _pick_file(_v=var):
                    path = filedialog.askopenfilename(
                        title=f"Select {label}",
                        filetypes=[("Text files", "*.txt"), ("All", "*.*")])
                    if path:
                        _v.set(path)
                ttk.Button(row, text="Browse", command=_pick_file).pack(side=tk.LEFT, padx=2)
            else:
                ttk.Entry(row, textvariable=var, width=20).pack(side=tk.LEFT, padx=4)

        # Buttons
        btn_row = ttk.Frame(dlg, padding=8)
        btn_row.pack(fill=tk.X)
        result = {'confirmed': False}

        def confirm():
            result['confirmed'] = True
            dlg.destroy()

        def cancel():
            dlg.destroy()

        ttk.Button(btn_row, text="Run", command=confirm, style="Accent.TButton").pack(side=tk.RIGHT, padx=4)
        ttk.Button(btn_row, text="Cancel", command=cancel).pack(side=tk.RIGHT, padx=4)
        if help_text:
            ttk.Button(btn_row, text="?",
                       command=lambda: messagebox.showinfo(title, help_text, parent=dlg)
                       ).pack(side=tk.LEFT, padx=4)

        dlg.bind('<Return>', lambda e: confirm())
        dlg.bind('<Escape>', lambda e: cancel())
        dlg.wait_window()

        if result['confirmed']:
            settings = {k: v.get() for k, v in vars_map.items()}
            on_run(settings)

    # ── Per-stage runners ──────────────────────────────────────────

    def _run_script_tts(self):
        """Script → Audio: run TTS on a .txt script, put audio in ready_to_go/."""
        script_path = filedialog.askopenfilename(
            title="Select script file (.txt)",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if not script_path:
            return
        script_file = Path(script_path)

        # Copy script to ready_to_go/ so tts_runner.py picks it up
        rtg = SCRIPT_DIR / 'ready_to_go'
        rtg.mkdir(exist_ok=True)
        dst = rtg / script_file.name
        if not dst.exists():
            shutil.copy2(str(script_file), str(dst))
        self.app.log(f"Script copied to ready_to_go/: {script_file.name}", "INFO", tab="control")

        defaults = {
            'TTS service': (tk.StringVar, getattr(config, 'TTS_SERVICE', 'mat3u'), ['mat3u', 'csv666']),
        }

        def do_run(s):
            env = os.environ.copy()
            env['TTS_SERVICE'] = s['TTS service']
            cmd = [sys.executable, str(AGENT_DIR / 'tools' / 'tts_runner.py'), '--mode', 'silent', '--tts-only']
            self._run_subprocess_in_thread(cmd, cwd=str(AGENT_DIR), task_name=f"TTS {script_file.stem}", env=env)

        self._show_stage_dialog(f"Script → Audio — {script_file.name}", defaults, do_run)

    def _run_script_video(self):
        """Script -> Video: rich dialog -- 1 file dialog, all pipeline stages configurable."""
        script_path = filedialog.askopenfilename(
            title="Select script file (.txt)",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if not script_path:
            return
        script_file = Path(script_path)

        # --- Rich custom dialog ---
        dlg = tk.Toplevel(self.root)
        dlg.title("Script -> Video")
        dlg.configure(bg=COLORS['bg_dark'])
        dlg.resizable(False, False)
        dlg.transient(self.root)
        dlg.grab_set()
        dlg.geometry("+%d+%d" % (self.root.winfo_x() + 160, self.root.winfo_y() + 60))

        outer = ttk.Frame(dlg)
        outer.pack(fill=tk.BOTH, expand=True)
        canvas = tk.Canvas(outer, bg=COLORS['bg_dark'], highlightthickness=0, width=540)
        vsb = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        sf = ttk.Frame(canvas, style="Card.TFrame", padding=14)
        sf.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=sf, anchor="nw")
        canvas.configure(yscrollcommand=vsb.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)

        ttk.Label(sf, text=f"Script -> Video  |  {script_file.name}",
                  style="Header.TLabel").pack(anchor=tk.W, pady=(0, 6))

        # --- Style guide ---
        ttk.Separator(sf, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=(0, 4))
        ttk.Label(sf, text="Style Guide", style="Section.TLabel").pack(anchor=tk.W)
        sg_row = ttk.Frame(sf, style="Card.TFrame"); sg_row.pack(fill=tk.X, pady=3)
        ttk.Label(sg_row, text="Style file:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        style_path_var = tk.StringVar(value='')
        sg_lbl = ttk.Label(sg_row, text="(required)", style="Dim.TLabel")
        sg_lbl.pack(side=tk.LEFT, padx=4, fill=tk.X, expand=True)
        def _browse_style():
            sp = filedialog.askopenfilename(title="Select style guide (.txt)",
                                            filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
            if sp:
                style_path_var.set(sp)
                sg_lbl.config(text=Path(sp).name)
        ttk.Button(sg_row, text="Add", command=_browse_style).pack(side=tk.RIGHT, padx=4)

        # --- Direction ---
        ttk.Separator(sf, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=(4, 2))
        ttk.Label(sf, text="Direction", style="Section.TLabel").pack(anchor=tk.W)
        dr0 = ttk.Frame(sf, style="Card.TFrame"); dr0.pack(fill=tk.X, pady=2)
        ttk.Label(dr0, text="Backend:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        self._fin_backend = tk.StringVar(value=getattr(config, 'DIRECTOR_BACKEND', 'gpt'))
        ttk.Combobox(dr0, textvariable=self._fin_backend, values=['gemini', 'gpt'],
                     width=8, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(dr0, text="GPT Model:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_gpt_model = tk.StringVar(value=getattr(config, 'GPT_MODEL', 'gpt-5.4'))
        ttk.Combobox(dr0, textvariable=self._fin_gpt_model, values=['gpt-5.5', 'gpt-5.4', 'gpt-5.4-mini'],
                     width=12, state='readonly').pack(side=tk.LEFT, padx=4)
        dr1 = ttk.Frame(sf, style="Card.TFrame"); dr1.pack(fill=tk.X, pady=2)
        ttk.Label(dr1, text="Model:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        self._fin_gemini_model = tk.StringVar(value=getattr(config, 'GEMINI_MODEL', _GEMINI_MODEL_OPTS[0]))
        ttk.Combobox(dr1, textvariable=self._fin_gemini_model, values=_GEMINI_MODEL_OPTS,
                     width=22, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(dr1, text="2-pass:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        twopass_var = tk.StringVar(value='true' if getattr(config, 'GEMINI_TWO_PASS', False) else 'false')
        ttk.Combobox(dr1, textvariable=twopass_var, values=['true', 'false'],
                     width=6, state='readonly').pack(side=tk.LEFT, padx=4)
        dr1b = ttk.Frame(sf, style="Card.TFrame"); dr1b.pack(fill=tk.X, pady=2)
        ttk.Label(dr1b, text="Script type:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        script_type_var = tk.StringVar(value='prose')
        ttk.Combobox(dr1b, textvariable=script_type_var, values=['prose', 'screenplay'],
                     width=12, state='readonly').pack(side=tk.LEFT, padx=4)
        dr2 = ttk.Frame(sf, style="Card.TFrame"); dr2.pack(fill=tk.X, pady=2)
        ttk.Label(dr2, text="Clip mode:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        clipmode_var = tk.StringVar(value='video')
        ttk.Combobox(dr2, textvariable=clipmode_var, values=['video', 'slideshow', 'vislide'],
                     width=10, state='readonly').pack(side=tk.LEFT, padx=4)
        _vs_lbl2 = ttk.Label(dr2, text="every:", style="Card.TLabel")
        vislide_var2 = tk.IntVar(value=getattr(config, 'PIPELINE_VISLIDE_INTERVAL', 3))
        _vs_spn2 = tk.Spinbox(dr2, textvariable=vislide_var2, from_=2, to=20, width=3,
                              bg=COLORS['bg_input'], fg=COLORS['text'])
        def _toggle_vislide2(*_):
            if clipmode_var.get() == 'vislide':
                _vs_lbl2.pack(side=tk.LEFT, padx=(6, 0))
                _vs_spn2.pack(side=tk.LEFT, padx=2)
            else:
                _vs_lbl2.pack_forget()
                _vs_spn2.pack_forget()
        clipmode_var.trace_add('write', _toggle_vislide2)
        _toggle_vislide2()
        ttk.Label(dr2, text="min:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        clipmin_var = tk.IntVar(value=getattr(config, 'VIDEO_CLIP_MIN_DURATION', 4))
        tk.Spinbox(dr2, textvariable=clipmin_var, from_=1, to=30, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(dr2, text="max:", style="Card.TLabel").pack(side=tk.LEFT, padx=(4, 0))
        clipmax_var = tk.IntVar(value=getattr(config, 'VIDEO_CLIP_MAX_DURATION', 8))
        tk.Spinbox(dr2, textvariable=clipmax_var, from_=2, to=60, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        dr3 = ttk.Frame(sf, style="Card.TFrame"); dr3.pack(fill=tk.X, pady=2)
        ttk.Label(dr3, text="Intro zone:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        intro_var = tk.IntVar(value=getattr(config, 'INTRO_BLOCK_DURATION', 45))
        tk.Spinbox(dr3, textvariable=intro_var, from_=0, to=9999, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(dr3, text="s  clip:", style="Card.TLabel").pack(side=tk.LEFT, padx=(4, 0))
        intro_min_var = tk.IntVar(value=getattr(config, 'INTRO_CLIP_MIN_DURATION', 0))
        tk.Spinbox(dr3, textvariable=intro_min_var, from_=0, to=30, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(dr3, text="-", style="Card.TLabel").pack(side=tk.LEFT)
        intro_max_var = tk.IntVar(value=getattr(config, 'INTRO_CLIP_MAX_DURATION', 0))
        tk.Spinbox(dr3, textvariable=intro_max_var, from_=0, to=60, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(dr3, text="s", style="Card.TLabel").pack(side=tk.LEFT)

        # --- ImageGen ---
        ttk.Separator(sf, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=(4, 2))
        ttk.Label(sf, text="ImageGen", style="Section.TLabel").pack(anchor=tk.W)
        ig_row = ttk.Frame(sf, style="Card.TFrame"); ig_row.pack(fill=tk.X, pady=2)
        ttk.Label(ig_row, text="Engine:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_engine_var = tk.StringVar(value='skip')
        ttk.Combobox(ig_row, textvariable=sv_engine_var,
                     values=['skip', 'FastGen', 'VeoNonStop'], width=12, state='readonly').pack(side=tk.LEFT, padx=4)

        sv_fg_frame = ttk.Frame(sf, style="Card.TFrame")
        fg_r1 = ttk.Frame(sv_fg_frame, style="Card.TFrame"); fg_r1.pack(fill=tk.X, pady=2)
        ttk.Label(fg_r1, text="API Key:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_fg_key_var = tk.StringVar(value='main')
        ttk.Combobox(fg_r1, textvariable=sv_fg_key_var, values=['main', 'backup'],
                     width=10, state='readonly').pack(side=tk.LEFT, padx=4)
        fg_r2 = ttk.Frame(sv_fg_frame, style="Card.TFrame"); fg_r2.pack(fill=tk.X, pady=2)
        ttk.Label(fg_r2, text="Model:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_fg_model_var = tk.StringVar(value=FASTGEN_KEY_TO_NAME.get(config.FASTGEN_MODEL, config.FASTGEN_MODEL))
        ttk.Combobox(fg_r2, textvariable=sv_fg_model_var, values=FASTGEN_DISPLAY,
                     width=14, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(fg_r2, text="x", style="Card.TLabel").pack(side=tk.LEFT, padx=(6, 0))
        sv_fg_par_var = tk.IntVar(value=config.FASTGEN_MAX_PARALLEL)
        tk.Spinbox(fg_r2, textvariable=sv_fg_par_var, from_=1, to=20, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)

        sv_veo_frame = ttk.Frame(sf, style="Card.TFrame")
        veo_r1 = ttk.Frame(sv_veo_frame, style="Card.TFrame"); veo_r1.pack(fill=tk.X, pady=2)
        ttk.Label(veo_r1, text="Mode:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_veo_mode_var = tk.StringVar(value='banana')
        ttk.Combobox(veo_r1, textvariable=sv_veo_mode_var,
                     values=['banana', 'banana+ref', 'imagen'], width=12, state='readonly').pack(side=tk.LEFT, padx=4)
        veo_r2 = ttk.Frame(sv_veo_frame, style="Card.TFrame"); veo_r2.pack(fill=tk.X, pady=2)
        ttk.Label(veo_r2, text="Model:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_veo_model_var = tk.StringVar(value='Banana Pro')
        ttk.Combobox(veo_r2, textvariable=sv_veo_model_var, values=BANANA_DISPLAY,
                     width=12, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(veo_r2, text="x", style="Card.TLabel").pack(side=tk.LEFT, padx=(6, 0))
        sv_veo_par_var = tk.IntVar(value=config.VEONONSTOP_MAX_PARALLEL)
        tk.Spinbox(veo_r2, textvariable=sv_veo_par_var, from_=1, to=48, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        veo_r3 = ttk.Frame(sv_veo_frame, style="Card.TFrame"); veo_r3.pack(fill=tk.X, pady=2)
        ttk.Label(veo_r3, text="Aspect:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_veo_ratio_var = tk.StringVar(value=config.VEONONSTOP_ASPECT_RATIO)
        ttk.Combobox(veo_r3, textvariable=sv_veo_ratio_var, values=["16:9", "9:16", "1:1"],
                     width=8, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(veo_r3, text="Keys:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        sv_veo_keys_var = tk.StringVar(value='key1')
        ttk.Combobox(veo_r3, textvariable=sv_veo_keys_var,
                     values=_veo_key_options(),
                     width=6, state='readonly').pack(side=tk.LEFT, padx=4)
        sv_ref_dir: list = [None]
        sv_veo_ref_row = ttk.Frame(sv_veo_frame, style="Card.TFrame")
        ttk.Label(sv_veo_ref_row, text="Ref dir:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_ref_lbl = ttk.Label(sv_veo_ref_row, text="(project/ref/)", style="Dim.TLabel")
        sv_ref_lbl.pack(side=tk.LEFT, padx=4, fill=tk.X, expand=True)
        def _sv_browse_ref():
            d = filedialog.askdirectory(title="Select ref images folder")
            if d:
                sv_ref_dir[0] = d
                sv_ref_lbl.config(text=Path(d).name)
        ttk.Button(sv_veo_ref_row, text="Add", command=_sv_browse_ref).pack(side=tk.RIGHT, padx=4)

        def _sv_on_veo_mode(*_):
            if sv_veo_mode_var.get() == 'banana+ref':
                sv_veo_ref_row.pack(fill=tk.X, pady=2)
            else:
                sv_veo_ref_row.pack_forget()
        sv_veo_mode_var.trace_add('write', _sv_on_veo_mode)
        _sv_on_veo_mode()

        def _on_imgeng(*_):
            sv_fg_frame.pack_forget()
            sv_veo_frame.pack_forget()
            if sv_engine_var.get() == 'FastGen':
                sv_fg_frame.pack(fill=tk.X, pady=2)
            elif sv_engine_var.get() == 'VeoNonStop':
                sv_veo_frame.pack(fill=tk.X, pady=2)
        sv_engine_var.trace_add('write', _on_imgeng)
        _on_imgeng()

        # --- VideoGen ---
        ttk.Separator(sf, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=(4, 2))
        ttk.Label(sf, text="VideoGen", style="Section.TLabel").pack(anchor=tk.W)
        vg_row = ttk.Frame(sf, style="Card.TFrame"); vg_row.pack(fill=tk.X, pady=2)
        ttk.Label(vg_row, text="Mode:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_vid_mode_var = tk.StringVar(value='skip')
        ttk.Combobox(vg_row, textvariable=sv_vid_mode_var,
                     values=['skip', 'i2v', 't2v', 'components'],
                     width=12, state='readonly').pack(side=tk.LEFT, padx=4)

        # --- Concat ---
        ttk.Separator(sf, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=(4, 2))
        ttk.Label(sf, text="Concat", style="Section.TLabel").pack(anchor=tk.W)
        sv_concat_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(sf, text="Run concat after pipeline", variable=sv_concat_var,
                        style="Card.TCheckbutton").pack(anchor=tk.W, pady=2)
        sv_cc_settings = ttk.Frame(sf, style="Card.TFrame")
        cc_r1 = ttk.Frame(sv_cc_settings, style="Card.TFrame"); cc_r1.pack(fill=tk.X, pady=2)
        ttk.Label(cc_r1, text="Quality:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_quality_var = tk.StringVar(value='720p')
        ttk.Combobox(cc_r1, textvariable=sv_quality_var, values=['720p', '1080p'],
                     width=6, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(cc_r1, text="Bitrate:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        sv_bitrate_var = tk.StringVar(value='10M')
        ttk.Combobox(cc_r1, textvariable=sv_bitrate_var, values=['5M', '8M', '10M', '15M', '20M'],
                     width=6, state='readonly').pack(side=tk.LEFT, padx=4)
        sv_keep_veo_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(cc_r1, text="Keep VEO sound", variable=sv_keep_veo_var,
                        style="Card.TCheckbutton").pack(side=tk.LEFT, padx=8)
        sv_keep_files_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(cc_r1, text="Keep temp files", variable=sv_keep_files_var,
                        style="Card.TCheckbutton").pack(side=tk.LEFT)
        cc_r2 = ttk.Frame(sv_cc_settings, style="Card.TFrame")
        cc_r2.pack(fill=tk.X, pady=2)
        sv_subtitles_var        = tk.BooleanVar(value=False)
        sv_subtitles_preset_var = tk.StringVar(value='bottom')
        sv_subtitles_custom_var = tk.BooleanVar(value=False)
        sv_subtitles_path_var   = tk.StringVar(value='')
        ttk.Checkbutton(cc_r2, text="Subtitles", variable=sv_subtitles_var,
                        style="Card.TCheckbutton").pack(side=tk.LEFT)
        ttk.Label(cc_r2, text="Preset:", style="Dim.TLabel").pack(side=tk.LEFT, padx=(10, 2))
        ttk.Radiobutton(cc_r2, text="Bottom", variable=sv_subtitles_preset_var,
                        value='bottom', style="Card.TRadiobutton").pack(side=tk.LEFT)
        ttk.Radiobutton(cc_r2, text="Center", variable=sv_subtitles_preset_var,
                        value='center', style="Card.TRadiobutton").pack(side=tk.LEFT, padx=(4, 0))
        _sv_custom_row = ttk.Frame(sv_cc_settings, style="Card.TFrame")
        ttk.Checkbutton(cc_r2, text="Custom template", variable=sv_subtitles_custom_var,
                        style="Card.TCheckbutton",
                        command=lambda: _sv_custom_row.pack(fill=tk.X) if sv_subtitles_custom_var.get()
                                        else _sv_custom_row.pack_forget()).pack(side=tk.LEFT, padx=(8, 0))
        ttk.Entry(_sv_custom_row, textvariable=sv_subtitles_path_var, width=36).pack(side=tk.LEFT, padx=4)
        ttk.Button(_sv_custom_row, text="Add",
                   command=lambda: sv_subtitles_path_var.set(
                       filedialog.askopenfilename(filetypes=[("ASS subtitles", "*.ass"), ("All files", "*.*")])
                   )).pack(side=tk.LEFT)

        def _on_concat_toggle(*_):
            if sv_concat_var.get():
                sv_cc_settings.pack(fill=tk.X)
            else:
                sv_cc_settings.pack_forget()
        sv_concat_var.trace_add('write', _on_concat_toggle)

        # --- YT Pack ---
        ttk.Separator(sf, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=(4, 2))
        ttk.Label(sf, text="YT Pack", style="Section.TLabel").pack(anchor=tk.W)
        sv_ytpack_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(sf, text="Run YT Pack after pipeline", variable=sv_ytpack_var,
                        style="Card.TCheckbutton").pack(anchor=tk.W, pady=2)
        sv_yt_settings = ttk.Frame(sf, style="Card.TFrame")
        _yt_l = getattr(config, 'YT_PACK_LANGUAGES', ['ru', 'en'])
        _yt_l_str = (','.join(str(x).strip(" '\"") for x in _yt_l if str(x).strip(" '\""))
                     if isinstance(_yt_l, (list, tuple)) else
                     ','.join(x.strip() for x in str(_yt_l).strip("[]'\"").split(',') if x.strip()))
        yt_r1 = ttk.Frame(sv_yt_settings, style="Card.TFrame"); yt_r1.pack(fill=tk.X, pady=2)
        ttk.Label(yt_r1, text="Languages:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_yt_langs_var = tk.StringVar(value=_yt_l_str)
        ttk.Entry(yt_r1, textvariable=sv_yt_langs_var, width=16).pack(side=tk.LEFT, padx=4)
        yt_r2 = ttk.Frame(sv_yt_settings, style="Card.TFrame"); yt_r2.pack(fill=tk.X, pady=2)
        ttk.Label(yt_r2, text="Generate:", style="Card.TLabel", width=14).pack(side=tk.LEFT)
        sv_yt_subs_var = tk.BooleanVar(value=bool(getattr(config, 'YT_PACK_SUBTITLES', True)))
        sv_yt_desc_var = tk.BooleanVar(value=bool(getattr(config, 'YT_PACK_DESCRIPTION', True)))
        sv_yt_cov_var  = tk.BooleanVar(value=bool(getattr(config, 'YT_PACK_COVERS', True)))
        ttk.Checkbutton(yt_r2, text="Subtitles",   variable=sv_yt_subs_var,  style="Card.TCheckbutton").pack(side=tk.LEFT, padx=2)
        ttk.Checkbutton(yt_r2, text="Description", variable=sv_yt_desc_var,  style="Card.TCheckbutton").pack(side=tk.LEFT, padx=6)
        ttk.Checkbutton(yt_r2, text="Covers",      variable=sv_yt_cov_var,   style="Card.TCheckbutton").pack(side=tk.LEFT, padx=6)

        def _on_ytpack_toggle(*_):
            if sv_ytpack_var.get():
                sv_yt_settings.pack(fill=tk.X)
            else:
                sv_yt_settings.pack_forget()
        sv_ytpack_var.trace_add('write', _on_ytpack_toggle)

        # --- Buttons ---
        btn_row = ttk.Frame(dlg, padding=8)
        btn_row.pack(fill=tk.X, side=tk.BOTTOM)
        result = {'confirmed': False}
        def _confirm():
            if not style_path_var.get():
                messagebox.showerror("Missing", "Style guide file is required", parent=dlg)
                return
            result['confirmed'] = True
            dlg.destroy()
        ttk.Button(btn_row, text="Run", command=_confirm, style="Accent.TButton").pack(side=tk.RIGHT, padx=4)
        ttk.Button(btn_row, text="Cancel", command=dlg.destroy).pack(side=tk.RIGHT, padx=4)
        dlg.bind('<Escape>', lambda e: dlg.destroy())

        dlg.update_idletasks()
        _h = min(sf.winfo_reqheight() + 50, int(self.root.winfo_screenheight() * 0.85))
        canvas.configure(height=_h)
        dlg.wait_window()

        if not result['confirmed']:
            return

        # --- Collect and execute ---
        project_name = script_file.stem
        projects_dir = SCRIPT_DIR / 'projects'
        projects_dir.mkdir(exist_ok=True)
        p = projects_dir / project_name

        _eng = sv_engine_var.get()
        _vid = sv_vid_mode_var.get()
        if _eng == 'FastGen' and _vid == 'i2v':
            post_action = 'fastgen_i2v'
        elif _eng == 'FastGen' and _vid == 'skip':
            post_action = 'fastgen'
        elif _eng == 'VeoNonStop' and _vid == 'i2v':
            post_action = 'veo_i2v'
        elif _eng == 'skip' and _vid == 't2v':
            post_action = 't2v'
        elif _eng == 'skip' and _vid == 'components':
            post_action = 'components'
        elif _eng == 'skip' and _vid == 'i2v':
            post_action = 'i2v'
        else:
            post_action = 'skip'

        cmd = [sys.executable, str(AGENT_DIR / 'agent.py'), 'script',
               '--script', str(script_file),
               '--style',  style_path_var.get(),
               '--project', project_name,
               '--output',  str(p),
               '--script-type', script_type_var.get(),
               '--clip-mode',   clipmode_var.get(),
               '--clip-min',    str(clipmin_var.get()),
               '--clip-max',    str(clipmax_var.get()),
               '--post-action', post_action]
        if clipmode_var.get() == 'vislide':
            cmd.extend(['--vislide-interval', str(vislide_var2.get())])
        if twopass_var.get() == 'true':
            cmd.append('--two-pass')

        import os as _os
        _sub_env = _os.environ.copy()
        _sub_env['INTRO_BLOCK_DURATION']    = str(intro_var.get())
        _sub_env['INTRO_CLIP_MIN_DURATION'] = str(intro_min_var.get())
        _sub_env['INTRO_CLIP_MAX_DURATION'] = str(intro_max_var.get())
        if _eng == 'VeoNonStop':
            _sub_env['VEONONSTOP_BANANA_MODEL'] = BANANA_NAME_TO_KEY.get(sv_veo_model_var.get(), 'GEM_PIX_2')
            _sub_env['VEONONSTOP_MAX_PARALLEL'] = str(sv_veo_par_var.get())
            _sub_env['VEONONSTOP_ASPECT_RATIO'] = sv_veo_ratio_var.get()
        elif _eng == 'FastGen':
            _sub_env['FASTGEN_MODEL']        = FASTGEN_NAME_TO_KEY.get(sv_fg_model_var.get(), sv_fg_model_var.get())
            _sub_env['FASTGEN_MAX_PARALLEL'] = str(sv_fg_par_var.get())

        cc_settings = {
            'quality': sv_quality_var.get(), 'bitrate': sv_bitrate_var.get(),
            'keep_veo_sound': sv_keep_veo_var.get(), 'keep_files': sv_keep_files_var.get(),
            'subtitles_path': (sv_subtitles_path_var.get() if sv_subtitles_custom_var.get()
                               else _find_ass_template(sv_quality_var.get(), sv_subtitles_preset_var.get())) if sv_subtitles_var.get() else '',
            'yt_langs': sv_yt_langs_var.get(), 'yt_subs': sv_yt_subs_var.get(),
            'yt_desc': sv_yt_desc_var.get(),   'yt_covers': sv_yt_cov_var.get(),
        }
        run_concat = sv_concat_var.get()
        run_ytpack = sv_ytpack_var.get()

        self.app.log(
            f"Script Director: {script_file.name} ({script_type_var.get()}, post={post_action})...",
            "INFO", tab="control"
        )

        def _worker():
            import subprocess as _sp
            self.active_tasks += 1
            self.root.after(0, self._update_status)
            _delegated = False
            try:
                _sub_env.setdefault('PYTHONIOENCODING', 'utf-8')
                proc = _sp.Popen(cmd, stdout=_sp.PIPE, stderr=_sp.STDOUT,
                                 stdin=_sp.DEVNULL,
                                 text=True, encoding='utf-8', errors='replace',
                                 cwd=str(AGENT_DIR), env=_sub_env)
                for line in proc.stdout:
                    line = line.rstrip()
                    if not line:
                        continue
                    low = line.lower()
                    level = 'ERROR' if (any(x in low for x in ['error', 'fail', 'traceback'])
                                        and not _is_false_error_signal(line)) else 'INFO'
                    self.app.log(line, level, tab="control")
                if proc.wait() != 0:
                    raise RuntimeError(f"Script Director failed (exit {proc.returncode})")
                self.app.log(f"Script Director done: {project_name}", "SUCCESS", tab="control")
                post_stages = []
                if run_concat:
                    post_stages.append('Concat')
                if run_ytpack:
                    post_stages.append('YT Pack')
                if post_stages:
                    _delegated = True
                    self._finalize_worker(p, post_stages, cc_settings)
            except Exception as e:
                self.app.log(f"Script Director FAILED: {e}", "ERROR", tab="control")
            finally:
                if not _delegated:
                    self.active_tasks = max(0, self.active_tasks - 1)
                    self.root.after(0, self._update_status)
                    self.root.after(0, self.refresh_projects)

        threading.Thread(target=_worker, daemon=True).start()

        if False:  # unreachable — kept for matching sentinel
            self._show_stage_dialog(f"Script → Video — {script_file.name}", defaults, do_run)

    def _run_transcribe(self):
        # Always ask for audio file — create project from it
        audio_path = filedialog.askopenfilename(
            title="Select audio/video file to transcribe",
            filetypes=[("Audio / Video", "*.mp3 *.wav *.flac *.m4a *.aac *.mp4 *.mov *.mkv *.webm *.avi *.m4v"), ("All", "*.*")]
        )
        if not audio_path:
            return
        audio_file = Path(audio_path)
        projects_dir = SCRIPT_DIR / 'projects'
        projects_dir.mkdir(exist_ok=True)
        project_name = audio_file.stem
        p = projects_dir / project_name
        p.mkdir(exist_ok=True)
        dst = p / audio_file.name
        if not dst.exists():
            shutil.copy2(str(audio_file), str(dst))
        audio = [dst]
        self.app.log(f"Project: {project_name}", "INFO", tab="control")
        self.refresh_projects()
        for item in self.tree.get_children():
            if self._project_name_from_item(item) == project_name:
                self.tree.selection_set(item)
                self.tree.see(item)
                break

        defaults = {
            'Language': (tk.StringVar, config.ASSEMBLYAI_LANGUAGE_CODE,
                        ['ru', 'en', 'es', 'de', 'fr', 'it', 'pt', 'zh', 'pl']),
            'Speech model': (tk.StringVar, 'universal-3-pro',
                            ['universal-3-pro', 'universal-2']),
            'Segmentation': (tk.StringVar, getattr(config, 'ASSEMBLYAI_SEGMENTATION_MODE', 'sentences'),
                            ['sentences', 'paragraphs', 'words']),
        }

        def do_run(s):
            from modules.transcriber import transcribe_audio
            out = str(p / 'transcription.json')
            config.ASSEMBLYAI_LANGUAGE_CODE     = s['Language']
            config.ASSEMBLYAI_SEGMENTATION_MODE = s['Segmentation']
            self.app.log(f"Transcribing {audio[0].name} ({s['Language']}, {s['Speech model']})...", "INFO", tab="control")
            self._run_in_thread(transcribe_audio, str(audio[0]), out, task_name=f"Transcribe {p.name}", project_dir=p)

        self._show_stage_dialog(f"Transcribe — {p.name}", defaults, do_run)

    def _run_direct(self):
        p = self._get_selected()
        if not p:
            return
        tr = p / 'transcription.json'
        if not tr.exists():
            messagebox.showerror("Error", "No transcription.json")
            return
        styles = list(p.glob('*style*')) + list(p.glob('*.txt'))
        style = str(styles[0]) if styles else ''

        defaults = {
            'Mode': (tk.StringVar, 'full', ['full', 'prompts-only']),
            'Backend': (tk.StringVar, getattr(config, 'DIRECTOR_BACKEND', 'gpt'), ['gemini', 'gpt']),
            'Model': (tk.StringVar, getattr(config, 'GEMINI_MODEL', _GEMINI_MODEL_OPTS[0]), _GEMINI_MODEL_OPTS),
            'GPT Model': (tk.StringVar, getattr(config, 'GPT_MODEL', 'gpt-5.4'), ['gpt-5.4', 'gpt-5.4-mini']),
            'Two-pass': (tk.StringVar, 'true' if config.GEMINI_TWO_PASS else 'false', ['true', 'false']),
            'Clip mode': (tk.StringVar, 'video', ['video', 'slideshow']),
            'Clip min': (tk.IntVar, config.VIDEO_CLIP_MIN_DURATION, (1, 30)),
            'Clip max': (tk.IntVar, config.VIDEO_CLIP_MAX_DURATION, (2, 60)),
            'Intro zone (s)': (tk.IntVar, getattr(config, 'INTRO_BLOCK_DURATION', 45), (0, 9999)),
            'Intro clip min': (tk.IntVar, getattr(config, 'INTRO_CLIP_MIN_DURATION', 0), (0, 30)),
            'Intro clip max': (tk.IntVar, getattr(config, 'INTRO_CLIP_MAX_DURATION', 0), (0, 60)),
        }

        def do_run(s):
            from modules.director import direct_project
            mode = s.get('Mode', 'full')
            prompts_only = (mode == 'prompts-only')
            config.DIRECTOR_BACKEND = s['Backend']
            config.GEMINI_MODEL    = s['Model']
            config.GPT_MODEL       = s['GPT Model']
            config.GEMINI_TWO_PASS = s['Two-pass'].lower() in ('true', '1', 'yes')
            cm = s['Clip mode']
            if cm == 'video':
                config.VIDEO_CLIP_MIN_DURATION = int(s['Clip min'])
                config.VIDEO_CLIP_MAX_DURATION = int(s['Clip max'])
            else:
                config.SLIDESHOW_CLIP_MIN_DURATION = int(s['Clip min'])
                config.SLIDESHOW_CLIP_MAX_DURATION = int(s['Clip max'])
            config.INTRO_BLOCK_DURATION    = int(s['Intro zone (s)'])
            config.INTRO_CLIP_MIN_DURATION = int(s['Intro clip min'])
            config.INTRO_CLIP_MAX_DURATION = int(s['Intro clip max'])

            # Resume logic for prompts-only mode
            resume_path = None
            if prompts_only:
                _candidates = sorted(p.glob(f"{p.name}_prompts_*.txt"))
                _non_over = [f for f in _candidates if 'OVERPROMPT' not in f.name]
                _best = _non_over[-1] if _non_over else (_candidates[-1] if _candidates else None)
                if _best:
                    answer = messagebox.askyesno(
                        "Resume prompts?",
                        f"Found existing prompts file:\n{_best.name}\n\nContinue from where left off?\n\n[Yes] Resume   [No] Start fresh"
                    )
                    if answer:
                        resume_path = str(_best)

            mode_label = f"prompts-only{'(resume)' if resume_path else ''}" if prompts_only else f"two-pass={s['Two-pass']}"
            self.app.log(f"Directing {p.name} ({mode_label}, {cm} {s['Clip min']}-{s['Clip max']}s)...", "INFO", tab="control")
            _po, _rp = prompts_only, resume_path
            _fn = lambda *a: direct_project(*a, prompts_only=_po, resume_path=_rp)
            self._run_in_thread(_fn, str(tr), style, str(p), p.name, task_name=f"Direct {p.name}", project_dir=p)

        self._show_stage_dialog(f"Direct — {p.name}", defaults, do_run)

    def _fetch_fastgen_quota(self, api_key):
        """Fetch remaining quota for a FastGen API key."""
        try:
            from modules.fastgen import FastGenClient, parse_usage_remaining, parse_usage_threads
            client = FastGenClient(api_key=api_key)
            usage = client.get_usage()
            remaining = parse_usage_remaining(usage)
            threads = parse_usage_threads(usage)
            return remaining, threads
        except Exception:
            return None, '?'

    def _run_imagegen(self):
        p = self._get_selected()
        if not p:
            return

        # Fetch quotas
        main_key = getattr(config, 'FASTGEN_API_KEY', '')
        backup_key = getattr(config, 'FASTGEN_API_KEY_BACKUP', '')
        main_q, main_t = self._fetch_fastgen_quota(main_key) if main_key else (None, '?')
        backup_q, backup_t = self._fetch_fastgen_quota(backup_key) if backup_key else (None, '?')
        mq = main_q if main_q is not None else '?'
        bq = backup_q if backup_q is not None else '?'

        # Custom dialog with dynamic fields
        dlg = tk.Toplevel(self.root)
        dlg.title(f"Image Gen — {p.name}")
        dlg.configure(bg=COLORS['bg_dark'])
        dlg.resizable(False, False)
        dlg.transient(self.root)
        dlg.grab_set()
        dlg.geometry("+%d+%d" % (self.root.winfo_x() + 200, self.root.winfo_y() + 150))

        ttk.Label(dlg, text=f"Image Gen — {p.name}", style="Header.TLabel").pack(padx=20, pady=(12, 4))

        sf = ttk.Frame(dlg, style="Card.TFrame", padding=12)
        sf.pack(fill=tk.X, padx=12, pady=4)

        # Engine selector
        engine_var = tk.StringVar(value='fastgen')
        row = ttk.Frame(sf, style="Card.TFrame"); row.pack(fill=tk.X, pady=3)
        ttk.Label(row, text="Engine:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        engine_cb = ttk.Combobox(row, textvariable=engine_var, values=['fastgen', 'veononstop'], width=16, state='readonly')
        engine_cb.pack(side=tk.LEFT, padx=4)

        # FastGen fields
        fg_frame = ttk.Frame(sf, style="Card.TFrame")

        r1 = ttk.Frame(fg_frame, style="Card.TFrame"); r1.pack(fill=tk.X, pady=3)
        ttk.Label(r1, text="API Key:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        api_key_var = tk.StringVar(value='main')
        _fg_main_key = getattr(config, 'FASTGEN_API_KEY', '')
        _fg_key2 = getattr(config, 'FASTGEN_API_KEY_2', '') or getattr(config, 'FASTGEN_API_KEY_BACKUP', '')
        _fg_key3 = getattr(config, 'FASTGEN_API_KEY_3', '')
        _fg_key4 = getattr(config, 'FASTGEN_API_KEY_4', '')
        _fg_key2_ok = bool(_fg_key2 and _fg_key2 != _fg_main_key)
        _fg_key3_ok = bool(_fg_key3 and _fg_key3 != _fg_main_key)
        _fg_key4_ok = bool(_fg_key4 and _fg_key4 != _fg_main_key)
        _fg_key_values = ['main']
        if _fg_key2_ok:
            _fg_key_values.append('backup')
        if _fg_key3_ok:
            _fg_key_values.append('key3')
        if _fg_key4_ok:
            _fg_key_values.append('key4')
        if _fg_key2_ok or _fg_key3_ok or _fg_key4_ok:
            _fg_key_values.append('both')
        ttk.Combobox(r1, textvariable=api_key_var, values=_fg_key_values,
                     width=16, state='readonly').pack(side=tk.LEFT, padx=4)

        r1q = ttk.Frame(fg_frame, style="Card.TFrame"); r1q.pack(fill=tk.X, pady=1)
        ttk.Label(r1q, text="", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        ttk.Label(r1q, text=f"Main: {mq}/hr, {main_t} thr  |  Backup: {bq}/hr, {backup_t} thr",
                  style="Dim.TLabel").pack(side=tk.LEFT)

        r2 = ttk.Frame(fg_frame, style="Card.TFrame"); r2.pack(fill=tk.X, pady=3)
        ttk.Label(r2, text="Model:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        fg_model_var = tk.StringVar(value=FASTGEN_KEY_TO_NAME.get(config.FASTGEN_MODEL, config.FASTGEN_MODEL))
        ttk.Combobox(r2, textvariable=fg_model_var, values=FASTGEN_DISPLAY, width=16, state='readonly').pack(side=tk.LEFT, padx=4)

        r3 = ttk.Frame(fg_frame, style="Card.TFrame"); r3.pack(fill=tk.X, pady=3)
        ttk.Label(r3, text="Aspect:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        fg_aspect_var = tk.StringVar(value=config.FASTGEN_ASPECT_RATIO)
        ttk.Combobox(r3, textvariable=fg_aspect_var, values=['landscape', 'portrait', 'square'], width=16, state='readonly').pack(side=tk.LEFT, padx=4)

        r4 = ttk.Frame(fg_frame, style="Card.TFrame"); r4.pack(fill=tk.X, pady=3)
        ttk.Label(r4, text="Parallel:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        fg_par_var = tk.IntVar(value=config.FASTGEN_MAX_PARALLEL)
        tk.Spinbox(r4, textvariable=fg_par_var, from_=1, to=20, width=6,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=4)

        # VeoNonStop fields
        veo_frame = ttk.Frame(sf, style="Card.TFrame")

        rv1 = ttk.Frame(veo_frame, style="Card.TFrame"); rv1.pack(fill=tk.X, pady=3)
        ttk.Label(rv1, text="Mode:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        veo_mode_var = tk.StringVar(value='banana')
        ttk.Combobox(rv1, textvariable=veo_mode_var, values=['banana', 'banana+ref', 'imagen'], width=16, state='readonly').pack(side=tk.LEFT, padx=4)

        rv2 = ttk.Frame(veo_frame, style="Card.TFrame")
        ttk.Label(rv2, text="Model:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        veo_model_var = tk.StringVar(value='Banana Pro')
        ttk.Combobox(rv2, textvariable=veo_model_var, values=BANANA_DISPLAY, width=16, state='readonly').pack(side=tk.LEFT, padx=4)

        rv3 = ttk.Frame(veo_frame, style="Card.TFrame"); rv3.pack(fill=tk.X, pady=3)
        ttk.Label(rv3, text="Parallel:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        veo_par_var = tk.IntVar(value=config.VEONONSTOP_MAX_PARALLEL)
        tk.Spinbox(rv3, textvariable=veo_par_var, from_=1, to=48, width=6,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=4)

        rv4 = ttk.Frame(veo_frame, style="Card.TFrame"); rv4.pack(fill=tk.X, pady=3)
        ttk.Label(rv4, text="Aspect ratio:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        veo_ratio_var = tk.StringVar(value=config.VEONONSTOP_ASPECT_RATIO)
        ttk.Combobox(rv4, textvariable=veo_ratio_var, values=["16:9", "9:16", "1:1"],
                     width=8, state='readonly').pack(side=tk.LEFT, padx=4)

        rv5 = ttk.Frame(veo_frame, style="Card.TFrame"); rv5.pack(fill=tk.X, pady=3)
        ttk.Label(rv5, text="Keys:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        # Checkboxes для всех 4 VeoNonStop ключей (как в Finalize)
        veo_key_var = tk.StringVar(value='1')  # формат "1" / "1,2" / "1,3,4"
        _veo_key_checks: dict = {}
        def _update_veo_keys(*_):
            sel = ','.join(str(i) for i in sorted(_veo_key_checks)
                          if _veo_key_checks[i].get())
            if not sel:
                sel = '1'
                if 1 in _veo_key_checks:
                    _veo_key_checks[1].set(True)
            veo_key_var.set(sel)
        _VKA = [(1, 'VEONONSTOP_API_KEY',   getattr(config, 'VEONONSTOP_KEY1_NAME', 'Key1')),
                (2, 'VEONONSTOP_API_KEY_2', getattr(config, 'VEONONSTOP_KEY2_NAME', 'Key2')),
                (3, 'VEONONSTOP_API_KEY_3', getattr(config, 'VEONONSTOP_KEY3_NAME', 'Key3')),
                (4, 'VEONONSTOP_API_KEY_4', getattr(config, 'VEONONSTOP_KEY4_NAME', 'Key4'))]
        for _ki, _kattr, _kname in _VKA:
            if getattr(config, _kattr, ''):
                _bv = tk.BooleanVar(value=(_ki == 1))
                _veo_key_checks[_ki] = _bv
                ttk.Checkbutton(rv5, text=_kname[:6], variable=_bv,
                                style="Card.TCheckbutton",
                                command=_update_veo_keys).pack(side=tk.LEFT, padx=1)
        _update_veo_keys()

        rv6 = ttk.Frame(veo_frame, style="Card.TFrame"); rv6.pack(fill=tk.X, pady=3)
        ttk.Label(rv6, text="Upscale:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        veo_ups_var = tk.StringVar(value='off')
        ttk.Combobox(rv6, textvariable=veo_ups_var, values=["off", "2K", "4K"],
                     width=8, state='readonly').pack(side=tk.LEFT, padx=4)

        # Ref dir row (shown only for banana+ref)
        veo_ref_dir: list = [None]
        rv_ref = ttk.Frame(veo_frame, style="Card.TFrame")
        ttk.Label(rv_ref, text="Ref dir:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        ref_path_lbl = ttk.Label(rv_ref, text="(project/ref/)", style="Dim.TLabel")
        ref_path_lbl.pack(side=tk.LEFT, padx=4, fill=tk.X, expand=True)
        def _browse_veo_ref():
            d = filedialog.askdirectory(title="Select ref images folder", initialdir=str(p))
            if d:
                veo_ref_dir[0] = d
                ref_path_lbl.config(text=Path(d).name)
        ttk.Button(rv_ref, text="Add", command=_browse_veo_ref).pack(side=tk.RIGHT, padx=4)

        # Show/hide model and ref rows based on veo mode
        def on_veo_mode_change(*_):
            m = veo_mode_var.get()
            if m == 'imagen':
                rv2.pack_forget()
                rv_ref.pack_forget()
            elif m == 'banana+ref':
                rv2.pack(fill=tk.X, pady=3, after=rv1)
                rv_ref.pack(fill=tk.X, pady=3)
            else:
                rv2.pack(fill=tk.X, pady=3, after=rv1)
                rv_ref.pack_forget()

        veo_mode_var.trace_add('write', on_veo_mode_change)
        on_veo_mode_change()

        # Toggle visibility
        def on_engine_change(*_):
            if engine_var.get() == 'fastgen':
                veo_frame.pack_forget()
                fg_frame.pack(fill=tk.X, pady=4)
            else:
                fg_frame.pack_forget()
                veo_frame.pack(fill=tk.X, pady=4)

        engine_var.trace_add('write', on_engine_change)
        on_engine_change()  # show fastgen by default

        # Rewrite model selector (applies to both engines) — единые лейблы REWRITE_DISPLAY
        ttk.Separator(sf, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=(6, 2))
        rw_row = ttk.Frame(sf, style="Card.TFrame"); rw_row.pack(fill=tk.X, pady=3)
        ttk.Label(rw_row, text="Rewrite model:", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        rw_model_var = tk.StringVar(value=REWRITE_SPEC_TO_LABEL.get(
            getattr(config, 'REWRITE_MODEL', 'gemini:gemini-2.5-flash-lite'), REWRITE_DISPLAY[0]))
        ttk.Combobox(rw_row, textvariable=rw_model_var, values=REWRITE_DISPLAY,
                     width=30, state='readonly').pack(side=tk.LEFT, padx=4)

        # Buttons
        btn_row = ttk.Frame(dlg, padding=8); btn_row.pack(fill=tk.X)
        result = {'confirmed': False}
        def confirm():
            result['confirmed'] = True
            dlg.destroy()
        ttk.Button(btn_row, text="Run", command=confirm, style="Accent.TButton").pack(side=tk.RIGHT, padx=4)
        ttk.Button(btn_row, text="Cancel", command=dlg.destroy).pack(side=tk.RIGHT, padx=4)
        dlg.bind('<Return>', lambda e: confirm())
        dlg.bind('<Escape>', lambda e: dlg.destroy())
        dlg.wait_window()

        if not result['confirmed']:
            return

        config.REWRITE_MODEL = REWRITE_LABEL_TO_SPEC.get(rw_model_var.get(), config.REWRITE_MODEL)

        if engine_var.get() == 'fastgen':
            key_name   = api_key_var.get()
            _key2 = getattr(config, 'FASTGEN_API_KEY_2', '') or getattr(config, 'FASTGEN_API_KEY_BACKUP', '')
            _key3 = getattr(config, 'FASTGEN_API_KEY_3', '')
            _key4 = getattr(config, 'FASTGEN_API_KEY_4', '')
            _fg_dual = False
            if key_name in ('backup', 'key2') and _key2:
                actual_key = _key2
            elif key_name == 'key3' and _key3:
                actual_key = _key3
            elif key_name == 'key4' and _key4:
                actual_key = _key4
            elif key_name in ('both', 'all') and (_key2 or _key3 or _key4):
                actual_key = main_key
                _fg_dual = True
            else:
                actual_key = main_key
            actual_model    = FASTGEN_NAME_TO_KEY.get(fg_model_var.get(), fg_model_var.get())
            actual_aspect   = fg_aspect_var.get()
            actual_parallel = fg_par_var.get()
            from modules.fastgen import generate_all_images
            self.app.log(
                f"ImageGen (FastGen {fg_model_var.get()}, {key_name}, x{actual_parallel}) for {p.name}...",
                "INFO", tab="control"
            )
            self._run_in_thread(
                lambda: generate_all_images(
                    str(p),
                    api_key=actual_key,
                    max_parallel=actual_parallel,
                    model=actual_model,
                    aspect_ratio=actual_aspect,
                    dual_key=_fg_dual,
                ),
                task_name=f"ImageGen {p.name}",
                project_dir=p,
            )
        else:
            config.VEONONSTOP_MAX_PARALLEL = veo_par_var.get()
            config.VEONONSTOP_BANANA_MODEL = BANANA_NAME_TO_KEY.get(veo_model_var.get(), 'GEM_PIX_2')
            mode_str = veo_mode_var.get()
            actual_mode = 'banana_ref' if mode_str == 'banana+ref' else mode_str
            ref_d = veo_ref_dir[0]
            from modules.imggen import generate_all_images as veo_gen
            config.VEONONSTOP_BANANA_MODEL = BANANA_NAME_TO_KEY.get(veo_model_var.get(), 'GEM_PIX_2')
            self.app.log(f"ImageGen (VeoNonStop {mode_str}, {veo_model_var.get()}) for {p.name}...", "INFO", tab="control")
            actual_ratio    = veo_ratio_var.get()
            actual_parallel = veo_par_var.get()
            _veo_active     = _veo_sel_to_active(veo_key_var.get())
            _UPS_MAP = {'2k': 'UPSAMPLE_IMAGE_RESOLUTION_2K', '4k': 'UPSAMPLE_IMAGE_RESOLUTION_4K'}
            _ups_res = _UPS_MAP.get(veo_ups_var.get().lower())
            self._run_in_thread(
                lambda: veo_gen(str(p), mode=actual_mode, ref_dir=ref_d,
                                aspect_ratio=actual_ratio, max_parallel=actual_parallel,
                                active_keys=_veo_active, upscale_resolution=_ups_res),
                task_name=f"ImageGen {p.name}", project_dir=p,
            )

    def _run_videogen(self):
        p = self._get_selected()
        if not p:
            return

        defaults = {
            'Mode':          (tk.StringVar, 'i2v', ['i2v', 't2v', 'components']),
            'Aspect ratio':  (tk.StringVar, config.VEONONSTOP_ASPECT_RATIO, ['16:9', '9:16', '1:1']),
            'Parallel':      (tk.IntVar,    config.VEONONSTOP_MAX_PARALLEL, (1, 200)),
            'Keys':          (tk.StringVar, '1', _veo_key_options()),
            'Prompt mode':   (tk.StringVar, 'per-clip', ['per-clip', 'single']),
            'VEO adapt':     (tk.StringVar, '', 'browse_file'),
            'Skipper':       (tk.StringVar, getattr(config, 'VEONONSTOP_FAST_CENSOR', 'off'),
                              ['off', 'after_rewrites', 'ultrafast']),
            'Retries':       (tk.IntVar,    getattr(config, 'VEONONSTOP_MAX_RETRIES', 5), (1, 10)),
            'Cycles':        (tk.IntVar,    getattr(config, 'VEONONSTOP_MAX_SILENT_CYCLES', 5), (1, 10)),
            'Delay (s)':     (tk.DoubleVar, getattr(config, 'VEONONSTOP_REQUEST_DELAY', 10.0), (0.5, 30.0)),
            'reCAPTCHA (s)': (tk.DoubleVar, getattr(config, 'VEONONSTOP_RECAPTCHA_DELAY', 8.0), (1.0, 60.0)),
            'reCAPTCHA jitter': (tk.DoubleVar, getattr(config, 'VEONONSTOP_RECAPTCHA_JITTER', 3.0), (0.5, 30.0)),
            'Rewrite model': (tk.StringVar, REWRITE_SPEC_TO_LABEL.get(getattr(config, 'REWRITE_MODEL', 'gemini:gemini-2.5-flash-lite'), REWRITE_DISPLAY[0]), REWRITE_DISPLAY),
            'Remix engine':  (tk.StringVar, getattr(config, 'REMIX_ENGINE', 'grok'), ['grok', 'kieai']),
            'Skip preflight':(tk.BooleanVar, False, None),
            'Upscale 1080p': (tk.BooleanVar, False, None),
        }

        def do_run(s):
            from modules.veo_video import generate_all_videos
            # Apply config overrides from dialog (rewrite: лейбл → spec)
            config.REWRITE_MODEL                 = REWRITE_LABEL_TO_SPEC.get(s.get('Rewrite model', ''), config.REWRITE_MODEL)
            config.REMIX_ENGINE                  = s.get('Remix engine', config.REMIX_ENGINE)
            config.VEONONSTOP_FAST_CENSOR        = s.get('Skipper', config.VEONONSTOP_FAST_CENSOR)
            config.VEONONSTOP_MAX_RETRIES        = int(s.get('Retries',       config.VEONONSTOP_MAX_RETRIES))
            config.VEONONSTOP_MAX_SILENT_CYCLES  = int(s.get('Cycles',        config.VEONONSTOP_MAX_SILENT_CYCLES))
            config.VEONONSTOP_REQUEST_DELAY      = float(s.get('Delay (s)',     config.VEONONSTOP_REQUEST_DELAY))
            config.VEONONSTOP_RECAPTCHA_DELAY    = float(s.get('reCAPTCHA (s)', config.VEONONSTOP_RECAPTCHA_DELAY))
            config.VEONONSTOP_RECAPTCHA_JITTER   = float(s.get('reCAPTCHA jitter', config.VEONONSTOP_RECAPTCHA_JITTER))
            if s.get('Skip preflight'):
                os.environ['VARAGENT_SKIP_PREFLIGHT'] = '1'
            else:
                os.environ.pop('VARAGENT_SKIP_PREFLIGHT', None)

            _mode = s['Mode']
            _par  = s['Parallel']
            _ar   = s['Aspect ratio']
            _keys = s['Keys']
            _active = _veo_sel_to_active(_keys)
            _sp = None
            if s.get('Prompt mode') == 'single':
                _sp_file = p / 'single_prompt.txt'
                if _sp_file.exists():
                    _sp = _sp_file.read_text(encoding='utf-8').strip() or None
                else:
                    self.app.log("single_prompt.txt not found — using 'default' (first from prompts)",
                                 "WARNING", tab="control")
                    _sp = 'default'
            # VEO adapt: user override → auto-detect fallback
            _prompts_override = None
            _user_adapt = s.get('VEO adapt', '').strip()
            if _user_adapt and Path(_user_adapt).exists():
                _prompts_override = _user_adapt
                self.app.log(f"  Using VEO adapt (user): {Path(_user_adapt).name}", "INFO", tab="control")
            else:
                _veo_adapt_files = sorted(p.glob('*_veo_adapt_*.txt'), key=lambda f: f.stat().st_mtime)
                if _veo_adapt_files:
                    _prompts_override = str(_veo_adapt_files[-1])
                    self.app.log(f"  Using veo_adapt (auto): {_veo_adapt_files[-1].name}", "INFO", tab="control")
            self.app.log(f"VideoGen ({_mode}, {_ar}, x{_par}, {_keys}, prompt={s.get('Prompt mode','per-clip')}, "
                         f"skipper={s.get('Skipper')}, retries={s.get('Retries')}) for {p.name}...",
                         "INFO", tab="control")
            self._run_in_thread(
                lambda: generate_all_videos(str(p), mode=_mode, max_parallel=_par, aspect_ratio=_ar,
                                            active_keys=_active, single_prompt=_sp,
                                            upscale_video=s.get('Upscale 1080p', False),
                                            prompts_file_path=_prompts_override),
                task_name=f"VideoGen {p.name}",
                project_dir=p,
            )

        self._show_stage_dialog(f"Video Gen — {p.name}", defaults, do_run)

    def _resolve_fu_key(self, sel: str):
        """Flow Ultra is available only on FastGen Key1 in this setup."""
        _main = getattr(config, 'FASTGEN_API_KEY', '') or ''
        return (_main, False)

    def _fu_key_choices(self):
        """Available Flow Ultra key options."""
        return ['main']

    def _resolve_single_prompt(self, p: Path, prompt_mode: str) -> 'Optional[str]':
        """For prompt_mode='single': read project/single_prompt.txt. Returns None for per-clip."""
        if prompt_mode != 'single':
            return None
        sp_path = p / 'single_prompt.txt'
        if sp_path.exists():
            txt = sp_path.read_text(encoding='utf-8-sig').strip()
            if txt:
                self.app.log(f"  Using single_prompt.txt ({len(txt)} chars)", "INFO", tab="control")
                return txt
        self.app.log("single_prompt.txt not found or empty — using 'default' (first prompt from file)",
                     "WARNING", tab="control")
        return 'default'  # generate_all_videos_flow_ultra takes first prompt from prompts file

    def _apply_fu_config_overrides(self, s: dict):
        """Apply Skipper/Retries/Cycles/Rewrite/Remix from dialog to module-level config.
        FastGen Flow Ultra reuses VEONONSTOP_* config vars for chain logic (engine-agnostic)."""
        if 'Rewrite model' in s:
            config.REWRITE_MODEL = REWRITE_LABEL_TO_SPEC.get(s['Rewrite model'], config.REWRITE_MODEL)
        if 'Remix engine' in s:
            config.REMIX_ENGINE = s['Remix engine']
        if 'Skipper' in s:
            config.VEONONSTOP_FAST_CENSOR = s['Skipper']
        if 'Retries' in s:
            config.VEONONSTOP_MAX_RETRIES = int(s['Retries'])
        if 'Cycles' in s:
            config.VEONONSTOP_MAX_SILENT_CYCLES = int(s['Cycles'])

    def _fu_common_defaults(self) -> dict:
        """Common VideoGen settings shared across all 3 FU standalone dialogs."""
        return {
            'Aspect ratio':  (tk.StringVar, '16:9', ['16:9', '9:16']),
            'Parallel':      (tk.IntVar, 4, (1, 25)),
            'Key':           (tk.StringVar, 'main', self._fu_key_choices()),
            'Prompt mode':   (tk.StringVar, 'per-clip', ['per-clip', 'single']),
            'VEO adapt':     (tk.StringVar, '', 'browse_file'),
            'Skipper':       (tk.StringVar, getattr(config, 'VEONONSTOP_FAST_CENSOR', 'off'),
                              ['off', 'after_rewrites', 'ultrafast']),
            'Retries':       (tk.IntVar, getattr(config, 'VEONONSTOP_MAX_RETRIES', 5), (1, 10)),
            'Cycles':        (tk.IntVar, getattr(config, 'VEONONSTOP_MAX_SILENT_CYCLES', 5), (1, 10)),
            'Rewrite model': (tk.StringVar, REWRITE_SPEC_TO_LABEL.get(getattr(config, 'REWRITE_MODEL', 'gemini:gemini-2.5-flash-lite'), REWRITE_DISPLAY[0]), REWRITE_DISPLAY),
            'Remix engine':  (tk.StringVar, getattr(config, 'REMIX_ENGINE', 'grok'), ['grok', 'kieai']),
        }

    def _run_fastgen_flow_ultra_t2v(self):
        """Standalone FastGen Flow Ultra T2V — full chain via generate_all_videos_flow_ultra."""
        p = self._get_selected()
        if not p:
            return
        if not getattr(config, 'FASTGEN_API_KEY', ''):
            self.app.log("FastGen Flow Ultra T2V: FASTGEN_API_KEY empty in .env", "ERROR", tab="control")
            return
        defaults = self._fu_common_defaults()

        def do_run(s):
            from modules.flowultra import generate_all_videos_flow_ultra
            self._clear_flowultra_stop()
            self._apply_fu_config_overrides(s)
            _ar = s['Aspect ratio']
            _par = max(1, int(s['Parallel']))
            _api_key, _dual = self._resolve_fu_key(s.get('Key', 'main'))
            if not _api_key:
                self.app.log("FastGen Flow Ultra T2V: API key empty", "ERROR", tab="control")
                return
            _sp = self._resolve_single_prompt(p, s.get('Prompt mode', 'per-clip'))
            _veo_adapt = s.get('VEO adapt', '').strip() or None
            if _veo_adapt and not Path(_veo_adapt).exists():
                self.app.log(f"VEO adapt file not found: {_veo_adapt} — falling back to auto-detect",
                             "WARNING", tab="control")
                _veo_adapt = None

            def _run_all():
                try:
                    with capture_stdout(self.app.log_queue, "control",
                                        task_label=f"FastGen Flow Ultra T2V {p.name}"):
                        result = generate_all_videos_flow_ultra(
                            project_dir=str(p), mode='t2v',
                            max_parallel=_par, aspect_ratio=_ar,
                            api_key=_api_key, dual_key=_dual,
                            single_prompt=_sp,
                            prompts_file_path=_veo_adapt,
                            silent=False,
                        )
                    lvl = "SUCCESS" if result.get('failed', 0) == 0 else "WARNING"
                    self.app.log(f"FastGen Flow Ultra T2V done. "
                                 f"ok={result.get('generated', 0)}, fail={result.get('failed', 0)}",
                                 lvl, tab="control")
                except Exception as _e:
                    self.app.log(f"FastGen Flow Ultra T2V exception: {_e}", "ERROR", tab="control")

            self._run_in_thread(_run_all,
                                task_name=f"FastGen Flow Ultra T2V {p.name}",
                                project_dir=p)

        self._show_stage_dialog(f"FastGen Flow Ultra T2V — {p.name}", defaults, do_run)

    def _run_fastgen_flow_ultra_ingredients(self):
        """Flow Ultra ingredients (t2v + 1-3 refs from ref/) — full chain via
        generate_all_videos_flow_ultra (binary search + remix_ref in-place on censorship)."""
        p = self._get_selected()
        if not p:
            return
        if not getattr(config, 'FASTGEN_API_KEY', ''):
            self.app.log("FastGen Ingredients: FASTGEN_API_KEY empty in .env", "ERROR", tab="control")
            return
        defaults = self._fu_common_defaults()

        def do_run(s):
            from modules.flowultra import generate_all_videos_flow_ultra
            self._clear_flowultra_stop()
            self._apply_fu_config_overrides(s)
            _ar = s['Aspect ratio']
            _par = max(1, int(s['Parallel']))
            _api_key, _dual = self._resolve_fu_key(s.get('Key', 'main'))
            if not _api_key:
                self.app.log("FastGen Ingredients: API key empty", "ERROR", tab="control")
                return
            _sp = self._resolve_single_prompt(p, s.get('Prompt mode', 'per-clip'))
            _veo_adapt = s.get('VEO adapt', '').strip() or None
            if _veo_adapt and not Path(_veo_adapt).exists():
                self.app.log(f"VEO adapt file not found: {_veo_adapt} — falling back to auto-detect",
                             "WARNING", tab="control")
                _veo_adapt = None
            # Safety: ref/ must exist and have images
            _ref_dir = p / 'ref'
            _has_refs = _ref_dir.exists() and any(
                _ref_dir.glob(f'*.{_e}') for _e in ('jpg', 'jpeg', 'png', 'webp')
            )
            if not _has_refs:
                self.app.log(f"FastGen Ingredients: no ref/ images in {p.name}", "ERROR", tab="control")
                return

            def _run_all():
                try:
                    with capture_stdout(self.app.log_queue, "control",
                                        task_label=f"FastGen Ingredients {p.name}"):
                        result = generate_all_videos_flow_ultra(
                            project_dir=str(p), mode='ingredients',
                            max_parallel=_par, aspect_ratio=_ar,
                            api_key=_api_key, dual_key=_dual,
                            ref_dir=str(_ref_dir),
                            single_prompt=_sp,
                            prompts_file_path=_veo_adapt,
                            silent=False,
                        )
                    lvl = "SUCCESS" if result.get('failed', 0) == 0 else "WARNING"
                    self.app.log(f"FastGen Ingredients done. "
                                 f"ok={result.get('generated', 0)}, fail={result.get('failed', 0)}",
                                 lvl, tab="control")
                except Exception as _e:
                    self.app.log(f"FastGen Ingredients exception: {_e}", "ERROR", tab="control")

            self._run_in_thread(_run_all, task_name=f"FastGen Ingredients {p.name}", project_dir=p)

        self._show_stage_dialog(f"FastGen Flow Ultra Ingredients — {p.name}", defaults, do_run)

    def _run_fastgen_flow_ultra_keyframes(self):
        """Flow Ultra keyframes (i2v): generated/NNN + optional end frame — full retry/rewrite/remix chain."""
        p = self._get_selected()
        if not p:
            return
        if not getattr(config, 'FASTGEN_API_KEY', ''):
            self.app.log("FastGen Keyframes: FASTGEN_API_KEY empty in .env", "ERROR", tab="control")
            return
        defaults = self._fu_common_defaults()
        defaults['Use end image'] = (tk.BooleanVar, False, None)  # keyframes-specific

        def do_run(s):
            from modules.flowultra import generate_all_videos_flow_ultra
            self._clear_flowultra_stop()
            self._apply_fu_config_overrides(s)
            _ar = s['Aspect ratio']
            _par = max(1, int(s['Parallel']))
            _use_end = bool(s.get('Use end image', False))
            _api_key, _dual = self._resolve_fu_key(s.get('Key', 'main'))
            if not _api_key:
                self.app.log("FastGen Keyframes: API key empty", "ERROR", tab="control")
                return
            _sp = self._resolve_single_prompt(p, s.get('Prompt mode', 'per-clip'))
            _veo_adapt = s.get('VEO adapt', '').strip() or None
            if _veo_adapt and not Path(_veo_adapt).exists():
                self.app.log(f"VEO adapt file not found: {_veo_adapt} — falling back to auto-detect",
                             "WARNING", tab="control")
                _veo_adapt = None
            # Safety: generated/ must have images
            _gen_dir = p / 'generated'
            _has_imgs = _gen_dir.exists() and any(
                _gen_dir.glob(f'*.{_e}') for _e in ('jpg', 'jpeg', 'png', 'webp')
            )
            if not _has_imgs:
                self.app.log(f"FastGen Keyframes: no generated/ images in {p.name}", "ERROR", tab="control")
                return
            _end_dir = str(_gen_dir) if _use_end else None

            def _run_all():
                try:
                    with capture_stdout(self.app.log_queue, "control",
                                        task_label=f"FastGen Keyframes {p.name}"):
                        result = generate_all_videos_flow_ultra(
                            project_dir=str(p), mode='keyframes',
                            max_parallel=_par, aspect_ratio=_ar,
                            api_key=_api_key, dual_key=_dual,
                            single_prompt=_sp,
                            prompts_file_path=_veo_adapt,
                            end_image_dir=_end_dir,
                            silent=False,
                        )
                    lvl = "SUCCESS" if result.get('failed', 0) == 0 else "WARNING"
                    self.app.log(f"FastGen Keyframes done. "
                                 f"ok={result.get('generated', 0)}, fail={result.get('failed', 0)}",
                                 lvl, tab="control")
                except Exception as _e:
                    self.app.log(f"FastGen Keyframes exception: {_e}", "ERROR", tab="control")

            self._run_in_thread(_run_all, task_name=f"FastGen Keyframes {p.name}", project_dir=p)

        self._show_stage_dialog(f"FastGen Flow Ultra Keyframes — {p.name}", defaults, do_run)

    def _run_concat(self):
        p = self._get_selected()
        if not p:
            return
        plan = p / 'montage_plan.json'
        if not plan.exists():
            messagebox.showerror("Error", "No montage_plan.json")
            return

        # Check if vid_img clips are already 1080p (from video upscale)
        _vid_already_1080 = False
        _sample = sorted((p / 'vid_img').glob('*.mp4'))[:1]
        if _sample:
            try:
                import subprocess as _sp
                _probe = _sp.run(
                    ['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                     '-show_entries', 'stream=height', '-of', 'csv=p=0', str(_sample[0])],
                    capture_output=True, text=True, timeout=10)
                _h = int(_probe.stdout.strip())
                _vid_already_1080 = _h >= 1080
            except Exception:
                pass
        _quality_opts = ['Fast'] if _vid_already_1080 else ['Fast', '1080p']

        defaults = {
            'Quality':        (tk.StringVar, 'Fast',   _quality_opts),
            'Bitrate':        (tk.StringVar, '10M',    ['5M', '8M', '10M', '15M', '20M']),
            'FPS':            (tk.StringVar, '60',     ['24', '25', '30', '50', '60']),
            'Watermark':      (tk.StringVar, 'as_is',  ['as_is', 'logo', 'blur']),
            'Force AMD':      (tk.StringVar, 'yes',    ['yes', 'no']),
            'Keep VEO Sound': (tk.StringVar, 'no',     ['no', 'yes']),
            'Burn Subtitles': (tk.StringVar, 'no',     ['no', 'yes']),
        }

        def do_run(s):
            cmd = [sys.executable, str(SCRIPT_DIR / 'video_concat.py'),
                    'montage_plan.json', '-o', f'{p.name}.mp4', '-b', s['Bitrate'],
                    '--fps', s['FPS']]
            if s['Force AMD'] == 'yes':
                cmd.append('--force-amd')
            if s['Watermark'] == 'blur':
                cmd.append('--blur-borders')
            if s['Quality'] == '1080p':
                cmd.extend(['-r', '1080'])
            if s['Keep VEO Sound'] == 'yes':
                cmd.append('--veo-audio-inline')
            if s['Burn Subtitles'] == 'yes':
                ass_files = list(p.glob('*.ass'))
                if ass_files:
                    cmd.extend(['--subtitles', str(ass_files[0])])
            def _guard_then_concat():
                try:
                    self._clear_hard_stop_flag()
                    _wait_for_concat_readiness(
                        p,
                        lambda msg, lvl='INFO': self.app.log(msg, lvl, tab="control"),
                        cancel_cb=lambda: self._ensure_hard_stop_event().is_set(),
                    )
                    self._run_subprocess_in_thread(cmd, cwd=str(p), task_name=f"Concat {p.name}", project_dir=p)
                except Exception as _e:
                    self.app.log(f"Concat guard failed: {_e}", "ERROR", tab="control")

            threading.Thread(target=_guard_then_concat, daemon=True).start()

        self._show_stage_dialog(f"Concat — {p.name}", defaults, do_run)

    def _run_ytpack(self):
        p = self._get_selected()
        if not p:
            return

        _yt_langs = getattr(config, 'YT_PACK_LANGUAGES', ['ru', 'en'])
        if isinstance(_yt_langs, (list, tuple)):
            _yt_langs_str = ','.join(str(l).strip(" '\"[]()") for l in _yt_langs if str(l).strip(" '\"[]()"))
        else:
            _yt_langs_str = ','.join(l.strip() for l in str(_yt_langs).strip("[]'\"()").split(',') if l.strip())
        defaults = {
            'Content model':   (tk.StringVar, getattr(config, 'YT_PACK_CONTENT_MODEL',   _GEMINI_MODEL_OPTS[0]), _GEMINI_MODEL_OPTS + ['gpt-5.5', 'gpt-5.4', 'gpt-5.4-mini']),
            'Translate model': (tk.StringVar, getattr(config, 'YT_PACK_TRANSLATE_MODEL', _GEMINI_MODEL_OPTS[0]), _GEMINI_MODEL_OPTS + ['gpt-5.5', 'gpt-5.4', 'gpt-5.4-mini']),
            'Languages': (tk.StringVar, _yt_langs_str, None),
            'Subtitles': (tk.StringVar, 'true' if getattr(config, 'YT_PACK_SUBTITLES', False) else 'false', ['true', 'false']),
            'Description': (tk.StringVar, 'true' if getattr(config, 'YT_PACK_DESCRIPTION', False) else 'false', ['true', 'false']),
            'Covers': (tk.StringVar, 'true' if getattr(config, 'YT_PACK_COVERS', False) else 'false', ['true', 'false']),
        }

        def do_run(s):
            import os
            from modules.yt_packer import run_yt_packer
            config.YT_PACK_CONTENT_MODEL   = s['Content model']
            config.YT_PACK_TRANSLATE_MODEL = s['Translate model']
            # Также устанавливаем os.environ для динамического чтения в yt_packer
            os.environ['YT_PACK_CONTENT_MODEL']   = s['Content model']
            os.environ['YT_PACK_TRANSLATE_MODEL'] = s['Translate model']
            config.YT_PACK_LANGUAGES  = [lang.strip() for lang in s['Languages'].split(',') if lang.strip()]
            config.YT_PACK_SUBTITLES  = s['Subtitles'].lower() in ('true', '1', 'yes')
            config.YT_PACK_DESCRIPTION = s['Description'].lower() in ('true', '1', 'yes')
            config.YT_PACK_COVERS     = s['Covers'].lower() in ('true', '1', 'yes')
            self.app.log(f"YT Packing {p.name} (langs={s['Languages']})...", "INFO", tab="control")
            self._run_in_thread(run_yt_packer, str(p), task_name=f"YT Pack {p.name}", project_dir=p)

        self._show_stage_dialog(f"YT Pack — {p.name}", defaults, do_run)

    def _pick_source_dialog(self, title: str, mode: str) -> Optional[str]:
        """Show a project-picker + Browse button dialog.

        mode='audio'  → returns path to audio file (.mp3/.wav/.flac) inside project or browsed
        mode='images' → returns path to images folder (project/generated/ or browsed folder)

        Returns selected path string, or None if cancelled.
        """
        projects_dir = SCRIPT_DIR / 'projects'
        projects = []
        if projects_dir.exists():
            projects = sorted(
                [p for p in projects_dir.iterdir() if p.is_dir() and not p.name.startswith('_')],
                key=lambda p: p.stat().st_mtime, reverse=True
            )

        result = [None]

        dlg = tk.Toplevel(self.root)
        dlg.title(title)
        dlg.configure(bg=COLORS['bg_dark'])
        dlg.resizable(False, False)
        dlg.grab_set()

        ttk.Label(dlg, text="Select a project  —  or browse for a file/folder:",
                  style="Card.TLabel").pack(anchor=tk.W, padx=12, pady=(10, 4))

        # Project listbox
        _lf = ttk.Frame(dlg, style="Card.TFrame", padding=4)
        _lf.pack(fill=tk.BOTH, expand=True, padx=12)
        _sb = ttk.Scrollbar(_lf, orient=tk.VERTICAL)
        _lb = tk.Listbox(_lf, height=12, bg=COLORS['bg_input'], fg=COLORS['text'],
                         selectbackground=COLORS.get('accent', '#5555cc'),
                         activestyle='none', yscrollcommand=_sb.set,
                         font=('Consolas', 9))
        _sb.config(command=_lb.yview)
        _lb.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        _sb.pack(side=tk.RIGHT, fill=tk.Y)
        for p in projects:
            _lb.insert(tk.END, p.name)

        def _resolve_project(proj_path: Path) -> Optional[str]:
            if mode == 'audio':
                # Find the audio file in project root (skip backups/processed)
                for ext in ('*.mp3', '*.wav', '*.flac'):
                    candidates = [
                        f for f in proj_path.glob(ext)
                        if '_original' not in f.name and '_clean' not in f.name
                    ]
                    if candidates:
                        return str(candidates[0])
                messagebox.showwarning("Not found",
                    f"No audio file found in:\n{proj_path.name}", parent=dlg)
                return None
            else:  # images
                gen = proj_path / 'generated'
                if gen.is_dir():
                    return str(gen)
                # Fallback: any subdir with images, or project root
                for sub in proj_path.iterdir():
                    if sub.is_dir() and list(sub.glob('*.jpg')) + list(sub.glob('*.png')):
                        return str(sub)
                return str(proj_path)

        def _use_project():
            sel = _lb.curselection()
            if not sel:
                messagebox.showinfo("Select a project", "Click a project in the list first.", parent=dlg)
                return
            proj = projects[sel[0]]
            path = _resolve_project(proj)
            if path:
                result[0] = path
                dlg.destroy()

        def _browse():
            if mode == 'audio':
                paths = filedialog.askopenfilenames(
                    title="Select audio file(s)",
                    filetypes=[("Audio", "*.mp3 *.wav *.flac"), ("All", "*.*")],
                    parent=dlg)
                if paths:
                    result[0] = list(paths)  # list of strings
                    dlg.destroy()
            else:
                path = filedialog.askdirectory(title="Select images folder", parent=dlg)
                if path:
                    result[0] = path
                    dlg.destroy()

        # Double-click = use project
        _lb.bind('<Double-Button-1>', lambda e: _use_project())

        # Buttons
        btn_row = ttk.Frame(dlg, style="TFrame")
        btn_row.pack(fill=tk.X, padx=12, pady=(8, 10))
        ttk.Button(btn_row, text="Use selected project", style="Accent.TButton",
                   command=_use_project).pack(side=tk.LEFT, padx=(0, 4))
        _browse_lbl = "Browse file..." if mode == 'audio' else "Browse folder..."
        ttk.Button(btn_row, text=_browse_lbl,
                   command=_browse).pack(side=tk.LEFT, padx=4)
        ttk.Button(btn_row, text="Cancel",
                   command=dlg.destroy).pack(side=tk.LEFT, padx=4)

        dlg.wait_window()
        return result[0]

    def _run_audio_clean_standalone(self):
        """Clean AI fingerprints from a project audio file or browsed file(s)."""
        picked = self._pick_source_dialog("Audio WM Cleaner", mode='audio')
        if not picked:
            return
        # Normalize: project returns str, browse returns list
        audio_paths = picked if isinstance(picked, list) else [picked]

        _help = "\n\n".join(f"{l}:\n  {d}" for l, d in _WM_AUDIO_LEVELS)
        defaults = {
            'Уровень': (tk.StringVar, getattr(config, 'AUDIO_CLEAN_LEVEL', 'moderate'),
                        ['gentle', 'moderate', 'aggressive', 'extreme']),
            'Режим':   (tk.StringVar, 'перезаписать (бэкап→_original)',
                        ['перезаписать (бэкап→_original)', 'новый файл (_clean)']),
        }
        label = Path(audio_paths[0]).name if len(audio_paths) == 1 else f"{len(audio_paths)} файлов"

        def do_run(s):
            for ap in audio_paths:
                cmd = [sys.executable,
                       str(AGENT_DIR / 'tools' / 'audio_cleaner.py'),
                       ap, '--level', s['Уровень']]
                if s['Режим'].startswith('перезаписать'):
                    cmd.append('--inplace')
                self._run_subprocess_in_thread(
                    cmd, task_name=f"AudioClean {Path(ap).name}")

        self._show_stage_dialog(f"Audio WM Cleaner — {label}", defaults, do_run,
                                help_text=_help)

    def _run_synthid_clean_standalone(self):
        """Remove SynthID watermarks from a project images folder or a browsed folder."""
        folder = self._pick_source_dialog("SynthID Remover", mode='images')
        if not folder:
            return
        _help = ("СИЛА:\n" + "\n\n".join(f"{l}:\n  {d}" for l, d in _WM_SYNTHID_STRENGTH)
                 + "\n\nВЕРСИЯ:\n" + "\n\n".join(f"{v}:\n  {d}" for v, d in _WM_SYNTHID_VERSIONS))
        defaults = {
            'Сила':       (tk.StringVar,  getattr(config, 'SYNTHID_STRENGTH',  'moderate'),
                           ['gentle', 'moderate', 'aggressive', 'extreme']),
            'Версия':     (tk.StringVar,  getattr(config, 'SYNTHID_VERSION',   'v1'),
                           ['v1', 'v2', 'v3']),
            'Save orig':  (tk.BooleanVar, getattr(config, 'SYNTHID_SAVE_ORIG', False), None),
        }

        def do_run(s):
            cmd = [sys.executable,
                   str(AGENT_DIR / 'tools' / 'synthid_cleaner.py'),
                   folder, '--strength', s['Сила'], '--version', s['Версия']]
            if s.get('Save orig'):
                cmd.append('--save-orig')
            self._run_subprocess_in_thread(
                cmd, task_name=f"SynthID {Path(folder).name}")

        self._show_stage_dialog(f"SynthID Remover — {Path(folder).name}", defaults, do_run,
                                help_text=_help)

    # ── Pipeline Mode: Finalize Project ───────────────────────────

    def _fin_browse_img_refs(self):
        paths = filedialog.askopenfilenames(
            title="Select reference images for banana_ref mode",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp *.tiff *.tif *.gif *.heic *.heif *.avif *.svg *.ico *.jfif"), ("All files", "*.*")]
        )
        for p in paths:
            pp = Path(p)
            if pp not in self._fin_img_refs:
                self._fin_img_refs.append(pp)
        self._fin_refresh_img_ref_listbox()

    def _fin_clear_img_refs(self):
        self._fin_img_refs.clear()
        self._fin_refresh_img_ref_listbox()

    def _fin_refresh_img_ref_listbox(self):
        self._fin_img_ref_listbox.delete(0, tk.END)
        for p in self._fin_img_refs:
            self._fin_img_ref_listbox.insert(tk.END, p.name)
        self._fin_img_ref_listbox.config(height=max(2, min(len(self._fin_img_refs), 5)))

    def _fin_browse_refs(self):
        paths = filedialog.askopenfilenames(
            title="Select reference images for components mode",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp *.tiff *.tif *.gif *.heic *.heif *.avif *.svg *.ico *.jfif"), ("All files", "*.*")]
        )
        for p in paths:
            pp = Path(p)
            if pp not in self._fin_vid_refs:
                self._fin_vid_refs.append(pp)
        self._fin_refresh_ref_listbox()

    def _fin_clear_refs(self):
        self._fin_vid_refs.clear()
        self._fin_refresh_ref_listbox()

    def _fin_refresh_ref_listbox(self):
        self._fin_ref_listbox.delete(0, tk.END)
        for p in self._fin_vid_refs:
            self._fin_ref_listbox.insert(tk.END, p.name)
        self._fin_ref_listbox.config(height=max(2, min(len(self._fin_vid_refs), 5)))

    def _toggle_panels(self):
        if self._projects_collapsed:
            self.tree.pack(fill=tk.BOTH, expand=True)
            self._stages_card.pack(fill=tk.X, padx=2, pady=4, before=self._log_card)
            self._projects_collapsed = False
            self._hide_panels_btn.config(text="Hide panels")
        else:
            if self._finalize_visible:
                self._toggle_finalize_panel()
            self.tree.pack_forget()
            self._stages_card.pack_forget()
            self._projects_collapsed = True
            self._hide_panels_btn.config(text="Show panels")

    def _toggle_finalize_panel(self):
        if self._finalize_visible:
            self._finalize_frame.pack_forget()
            self._finalize_visible = False
            self._pl_mode_btn.config(text="Pipeline Mode ▼")
        else:
            self._finalize_frame.pack(fill=tk.X, padx=2, pady=2, before=self._log_card)
            self._finalize_visible = True
            self._pl_mode_btn.config(text="Pipeline Mode ▲")

    def _build_finalize_panel(self, parent) -> ttk.Frame:
        # Scrollable wrapper — finalize panel can be tall, needs its own scroll
        wrapper = ttk.Frame(parent, style="Card.TFrame")
        _fin_canvas = tk.Canvas(wrapper, bg=COLORS['bg_card'], highlightthickness=0, height=350)
        _fin_vsb = ttk.Scrollbar(wrapper, orient=tk.VERTICAL, command=_fin_canvas.yview)
        outer = ttk.Frame(_fin_canvas, style="Card.TFrame", padding=8)
        outer.bind("<Configure>", lambda e: _fin_canvas.configure(scrollregion=_fin_canvas.bbox("all")))
        _fin_canvas.create_window((0, 0), window=outer, anchor=tk.NW)
        _fin_canvas.configure(yscrollcommand=_fin_vsb.set)
        _fin_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        _fin_vsb.pack(side=tk.RIGHT, fill=tk.Y)
        # Mousewheel
        _fin_mw = lambda e: _fin_canvas.yview_scroll(-1 * (e.delta // 120), "units")
        _fin_canvas.bind("<Enter>", lambda e: _fin_canvas.bind_all("<MouseWheel>", _fin_mw))
        _fin_canvas.bind("<Leave>", lambda e: _fin_canvas.unbind_all("<MouseWheel>"))
        # Stretch inner to canvas width
        def _fin_on_configure(e):
            _fin_canvas.itemconfigure(_fin_canvas.find_all()[0], width=e.width)
        _fin_canvas.bind("<Configure>", _fin_on_configure)

        # Shared BooleanVar (used by both ImageGen and VideoGen sections)
        self._fin_skip_preflight = tk.BooleanVar(value=False)
        # Finalize rewrite — те же лейблы что в Pipeline Launcher (REWRITE_DISPLAY)
        self._fin_rewrite_model = tk.StringVar(value=REWRITE_SPEC_TO_LABEL.get(
            getattr(config, 'REWRITE_MODEL', 'gemini:gemini-2.5-flash-lite'), REWRITE_DISPLAY[0]))
        # VideoGen advanced settings (parity with Pipeline tab)
        self._fin_vid_request_delay    = tk.DoubleVar(value=getattr(config, 'VEONONSTOP_REQUEST_DELAY',    10.0))
        self._fin_vid_recaptcha_delay  = tk.DoubleVar(value=getattr(config, 'VEONONSTOP_RECAPTCHA_DELAY',   8.0))
        self._fin_vid_recaptcha_jitter = tk.DoubleVar(value=getattr(config, 'VEONONSTOP_RECAPTCHA_JITTER',  3.0))
        self._fin_vid_max_retries      = tk.IntVar(value=getattr(config, 'VEONONSTOP_MAX_RETRIES', 5))
        self._fin_vid_max_cycles       = tk.IntVar(value=getattr(config, 'VEONONSTOP_MAX_SILENT_CYCLES', 5))
        self._fin_remix_engine         = tk.StringVar(value=getattr(config, 'REMIX_ENGINE', 'grok'))
        self._fin_codex_adapt          = tk.BooleanVar(value=False)
        self._fin_veo_adapt_path       = None  # override path from Browse dialog
        self._fin_story_mode           = tk.StringVar(value=getattr(config, 'STORY_MODE', 'off'))

        # Description
        ttk.Label(outer, text="Resume pipeline from a specific stage for the selected project",
                  style="Dim.TLabel").pack(anchor=tk.W, pady=(0, 4))

        # Row: Start from + YT Pack toggle
        r0 = ttk.Frame(outer, style="Card.TFrame")
        r0.pack(fill=tk.X, pady=2)
        ttk.Label(r0, text="Start from:", style="Card.TLabel", width=12).pack(side=tk.LEFT)
        _STAGES = ["Direction", "Prompts Only", "ImageGen", "VideoGen", "Concat", "YT Pack"]
        self._fin_start = tk.StringVar(value="ImageGen")
        ttk.Combobox(r0, textvariable=self._fin_start, values=_STAGES,
                     width=12, state='readonly').pack(side=tk.LEFT, padx=4)
        self._fin_ytpack = tk.BooleanVar(value=False)
        ttk.Checkbutton(r0, text="Run YT Pack after", variable=self._fin_ytpack,
                        style="Card.TCheckbutton").pack(side=tk.LEFT, padx=16)

        ttk.Separator(outer, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=(4, 2))

        # ── Direction section ──
        self._fin_dir_section = ttk.Frame(outer, style="Card.TFrame")
        ttk.Label(self._fin_dir_section, text="Direction", style="Section.TLabel").pack(anchor=tk.W)
        dr0 = ttk.Frame(self._fin_dir_section, style="Card.TFrame"); dr0.pack(fill=tk.X, pady=2)
        ttk.Label(dr0, text="Backend:", style="Card.TLabel", width=12).pack(side=tk.LEFT)
        self._fin_backend = tk.StringVar(value=getattr(config, 'DIRECTOR_BACKEND', 'gpt'))
        ttk.Combobox(dr0, textvariable=self._fin_backend, values=['gemini', 'gpt'],
                     width=8, state='readonly').pack(side=tk.LEFT, padx=4)
        # GPT model row (shown when backend=gpt)
        self._fin_dr_gpt = ttk.Frame(self._fin_dir_section, style="Card.TFrame")
        ttk.Label(self._fin_dr_gpt, text="GPT:", style="Card.TLabel", width=12).pack(side=tk.LEFT)
        self._fin_gpt_model = tk.StringVar(value=getattr(config, 'GPT_MODEL', 'gpt-5.4'))
        ttk.Combobox(self._fin_dr_gpt, textvariable=self._fin_gpt_model, values=['gpt-5.5', 'gpt-5.4', 'gpt-5.4-mini'],
                     width=12, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(self._fin_dr_gpt, text="Chunk:", style="Card.TLabel").pack(side=tk.LEFT, padx=(10, 0))
        self._fin_gpt_chunk_size = tk.IntVar(value=getattr(config, 'GPT_PASS2_CHUNK_SIZE', 150))
        tk.Spinbox(self._fin_dr_gpt, textvariable=self._fin_gpt_chunk_size,
                   from_=50, to=1000, increment=50, width=5,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(self._fin_dr_gpt, text="Parallel:", style="Card.TLabel").pack(side=tk.LEFT, padx=(10, 0))
        self._fin_gpt_parallel = tk.IntVar(value=getattr(config, 'GPT_PASS2_PARALLEL', 6))
        tk.Spinbox(self._fin_dr_gpt, textvariable=self._fin_gpt_parallel,
                   from_=1, to=20, increment=1, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        # Gemini row (shown when backend=gemini)
        dr1 = ttk.Frame(self._fin_dir_section, style="Card.TFrame")
        ttk.Label(dr1, text="Gemini:", style="Card.TLabel", width=12).pack(side=tk.LEFT)
        self._fin_gemini_model = tk.StringVar(value=getattr(config, 'GEMINI_MODEL', _GEMINI_MODEL_OPTS[0]))
        ttk.Combobox(dr1, textvariable=self._fin_gemini_model, values=_GEMINI_MODEL_OPTS,
                     width=20, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(dr1, text="2-pass:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_dir_twopass = tk.StringVar(value='true' if getattr(config, 'GEMINI_TWO_PASS', False) else 'false')
        ttk.Combobox(dr1, textvariable=self._fin_dir_twopass, values=['true', 'false'],
                     width=6, state='readonly').pack(side=tk.LEFT, padx=4)
        self._fin_dr_gemini = dr1

        def _fin_backend_changed(*_):
            if self._fin_backend.get() == 'gpt':
                self._fin_dr_gemini.pack_forget()
                self._fin_dr_gpt.pack(fill=tk.X, pady=2, after=dr0)
            else:
                self._fin_dr_gpt.pack_forget()
                self._fin_dr_gemini.pack(fill=tk.X, pady=2, after=dr0)
        self._fin_backend.trace_add('write', _fin_backend_changed)
        _fin_backend_changed()  # apply initial state
        dr2 = ttk.Frame(self._fin_dir_section, style="Card.TFrame"); dr2.pack(fill=tk.X, pady=2)
        ttk.Label(dr2, text="Clip mode:", style="Card.TLabel", width=12).pack(side=tk.LEFT)
        self._fin_dir_clipmode = tk.StringVar(value='video')
        ttk.Combobox(dr2, textvariable=self._fin_dir_clipmode, values=['video', 'slideshow', 'vislide'],
                     width=10, state='readonly').pack(side=tk.LEFT, padx=4)
        # Vislide interval — показывается только когда clip_mode=vislide.
        # Нужен для ресюма Direction-стадии в проекте, который изначально был запущен в vislide.
        ttk.Label(dr2, text="every:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_dir_vislide_interval = tk.IntVar(value=getattr(config, 'PIPELINE_VISLIDE_INTERVAL', 3))
        tk.Spinbox(dr2, textvariable=self._fin_dir_vislide_interval, from_=2, to=20, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(dr2, text="min:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_dir_clipmin = tk.IntVar(value=getattr(config, 'VIDEO_CLIP_MIN_DURATION', 4))
        tk.Spinbox(dr2, textvariable=self._fin_dir_clipmin, from_=1, to=30, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(dr2, text="max:", style="Card.TLabel").pack(side=tk.LEFT, padx=(4, 0))
        self._fin_dir_clipmax = tk.IntVar(value=getattr(config, 'VIDEO_CLIP_MAX_DURATION', 8))
        tk.Spinbox(dr2, textvariable=self._fin_dir_clipmax, from_=2, to=60, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        dr3 = ttk.Frame(self._fin_dir_section, style="Card.TFrame"); dr3.pack(fill=tk.X, pady=2)
        ttk.Label(dr3, text="Intro zone:", style="Card.TLabel", width=12).pack(side=tk.LEFT)
        self._fin_dir_intro = tk.IntVar(value=getattr(config, 'INTRO_BLOCK_DURATION', 45))
        tk.Spinbox(dr3, textvariable=self._fin_dir_intro, from_=0, to=9999, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(dr3, text="s  clip:", style="Card.TLabel").pack(side=tk.LEFT, padx=(4, 0))
        self._fin_dir_intro_min = tk.IntVar(value=getattr(config, 'INTRO_CLIP_MIN_DURATION', 0))
        tk.Spinbox(dr3, textvariable=self._fin_dir_intro_min, from_=0, to=30, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(dr3, text="-", style="Card.TLabel").pack(side=tk.LEFT)
        self._fin_dir_intro_max = tk.IntVar(value=getattr(config, 'INTRO_CLIP_MAX_DURATION', 0))
        tk.Spinbox(dr3, textvariable=self._fin_dir_intro_max, from_=0, to=60, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(dr3, text="s", style="Card.TLabel").pack(side=tk.LEFT)
        dr4 = ttk.Frame(self._fin_dir_section, style="Card.TFrame"); dr4.pack(fill=tk.X, pady=2)
        self._fin_dir_adapt_sg = tk.BooleanVar(value=False)
        ttk.Checkbutton(dr4, text="Adapt SG to script (GPT)",
                        variable=self._fin_dir_adapt_sg).pack(side=tk.LEFT)

        # ── ImageGen section ──
        self._fin_ig_section = ttk.Frame(outer, style="Card.TFrame")
        ttk.Label(self._fin_ig_section, text="ImageGen", style="Section.TLabel").pack(anchor=tk.W)

        ig_row = ttk.Frame(self._fin_ig_section, style="Card.TFrame")
        ig_row.pack(fill=tk.X, pady=2)
        ttk.Label(ig_row, text="Engine:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        self._fin_engine = tk.StringVar(value="veononstop")
        eng_cb = ttk.Combobox(ig_row, textvariable=self._fin_engine,
                               values=["veononstop", "fastgen"], width=12, state='readonly')
        eng_cb.pack(side=tk.LEFT, padx=4)

        # VeoNonStop sub-settings
        self._fin_veo_sub = ttk.Frame(self._fin_ig_section, style="Card.TFrame")
        vr = ttk.Frame(self._fin_veo_sub, style="Card.TFrame")
        vr.pack(fill=tk.X, pady=2)
        ttk.Label(vr, text="Mode:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        self._fin_veo_mode = tk.StringVar(value="banana")
        ttk.Combobox(vr, textvariable=self._fin_veo_mode,
                     values=["banana", "banana_ref", "imagen"], width=12, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(vr, text="Ratio:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_veo_ratio = tk.StringVar(value=config.VEONONSTOP_ASPECT_RATIO)
        ttk.Combobox(vr, textvariable=self._fin_veo_ratio,
                     values=["16:9", "9:16", "1:1"], width=6, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(vr, text="Parallel:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_veo_par = tk.IntVar(value=config.VEONONSTOP_MAX_PARALLEL)
        tk.Spinbox(vr, textvariable=self._fin_veo_par, from_=1, to=200, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=4)
        vr2 = ttk.Frame(self._fin_veo_sub, style="Card.TFrame")
        vr2.pack(fill=tk.X, pady=2)
        ttk.Label(vr2, text="Model:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        self._fin_veo_model = tk.StringVar(value=BANANA_KEY_TO_NAME.get(
            getattr(config, 'VEONONSTOP_BANANA_MODEL', 'GEM_PIX_2'), 'Banana Pro'))
        ttk.Combobox(vr2, textvariable=self._fin_veo_model,
                     values=BANANA_DISPLAY, width=12, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(vr2, text="Keys:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_veo_imgkeys = tk.StringVar(value='1')
        self._fin_img_key_checks = {}
        _img_kf = ttk.Frame(vr2, style="Card.TFrame")
        _img_kf.pack(side=tk.LEFT)
        def _update_img_keys(*_):
            sel = ','.join(str(i) for i in sorted(self._fin_img_key_checks)
                          if self._fin_img_key_checks[i].get())
            if not sel:
                sel = '1'
                if 1 in self._fin_img_key_checks:
                    self._fin_img_key_checks[1].set(True)
            self._fin_veo_imgkeys.set(sel)
            try:
                lims = self.app.tab_pipeline._veo_key_limits
                total = sum(lims.get(s.strip(), 0) for s in sel.split(','))
                if total > 0:
                    self._fin_veo_par.set(total)
            except Exception:
                pass
        _IKA = [(1, 'VEONONSTOP_API_KEY', config.VEONONSTOP_KEY1_NAME),
                (2, 'VEONONSTOP_API_KEY_2', config.VEONONSTOP_KEY2_NAME),
                (3, 'VEONONSTOP_API_KEY_3', config.VEONONSTOP_KEY3_NAME),
                (4, 'VEONONSTOP_API_KEY_4', config.VEONONSTOP_KEY4_NAME)]
        for _ki, _kattr, _kname in _IKA:
            if getattr(config, _kattr, ''):
                _bv = tk.BooleanVar(value=(_ki == 1))
                self._fin_img_key_checks[_ki] = _bv
                ttk.Checkbutton(_img_kf, text=_kname[:6], variable=_bv,
                                style="Card.TCheckbutton",
                                command=_update_img_keys).pack(side=tk.LEFT, padx=1)
        self._refresh_fin_img_par = _update_img_keys
        _update_img_keys()

        vr3 = ttk.Frame(self._fin_veo_sub, style="Card.TFrame")
        vr3.pack(fill=tk.X, pady=2)
        ttk.Label(vr3, text="Upscale:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        self._fin_img_upscale = tk.StringVar(value=getattr(config, 'VEONONSTOP_IMAGE_UPSCALE', 'off'))
        ttk.Combobox(vr3, textvariable=self._fin_img_upscale,
                     values=["off", "2K", "4K"], width=6, state='readonly').pack(side=tk.LEFT, padx=4)

        # Ref images for banana_ref mode
        self._fin_img_ref_row = ttk.Frame(self._fin_veo_sub, style="Card.TFrame")
        self._fin_img_refs: list = []
        _iref_top = ttk.Frame(self._fin_img_ref_row, style="Card.TFrame")
        _iref_top.pack(fill=tk.X)
        ttk.Label(_iref_top, text="Refs:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        ttk.Button(_iref_top, text="Add", command=self._fin_browse_img_refs).pack(side=tk.LEFT, padx=2)
        ttk.Button(_iref_top, text="Clear", command=self._fin_clear_img_refs).pack(side=tk.LEFT, padx=2)
        ttk.Label(_iref_top, text="(if empty: project/ref/)", style="Dim.TLabel").pack(side=tk.LEFT, padx=4)
        self._fin_img_ref_listbox = tk.Listbox(self._fin_img_ref_row, height=3,
                                               bg=COLORS['bg_input'], fg=COLORS['text'],
                                               selectbackground=COLORS['accent'], font=FONT_DIM)
        self._fin_img_ref_listbox.pack(fill=tk.X, pady=(2, 0))

        def _toggle_img_ref_row(*_):
            if self._fin_veo_mode.get() == 'banana_ref':
                self._fin_img_ref_row.pack(fill=tk.X, pady=2)
            else:
                self._fin_img_ref_row.pack_forget()
        self._fin_veo_mode.trace_add('write', _toggle_img_ref_row)
        _toggle_img_ref_row()

        # FastGen sub-settings
        self._fin_fg_sub = ttk.Frame(self._fin_ig_section, style="Card.TFrame")
        fr = ttk.Frame(self._fin_fg_sub, style="Card.TFrame")
        fr.pack(fill=tk.X, pady=2)
        ttk.Label(fr, text="Model:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        self._fin_fg_model = tk.StringVar(
            value=FASTGEN_KEY_TO_NAME.get(config.FASTGEN_MODEL, config.FASTGEN_MODEL))
        ttk.Combobox(fr, textvariable=self._fin_fg_model, values=FASTGEN_DISPLAY,
                     width=12, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(fr, text="Aspect:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_fg_aspect = tk.StringVar(value='landscape')
        ttk.Combobox(fr, textvariable=self._fin_fg_aspect,
                     values=['landscape', 'portrait', 'square'], width=10, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(fr, text="Parallel:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_fg_par = tk.IntVar(value=config.FASTGEN_MAX_PARALLEL)
        tk.Spinbox(fr, textvariable=self._fin_fg_par, from_=1, to=20, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=4)

        # Key selector (Key1 / Key2 / Key3 / Key4 / Both) - disabled values when key not configured
        _kr = ttk.Frame(self._fin_fg_sub, style="Card.TFrame")
        _kr.pack(fill=tk.X, pady=(2, 0))
        ttk.Label(_kr, text="Keys:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        self._fin_fg_keys = tk.StringVar(value='key1')
        _fg_main_key = getattr(config, 'FASTGEN_API_KEY', '')
        _fg_key2 = getattr(config, 'FASTGEN_API_KEY_2', '') or getattr(config, 'FASTGEN_API_KEY_BACKUP', '')
        _fg_key3 = getattr(config, 'FASTGEN_API_KEY_3', '')
        _fg_key4 = getattr(config, 'FASTGEN_API_KEY_4', '')
        _k2_avail = bool(_fg_key2 and _fg_key2 != _fg_main_key)
        _k3_avail = bool(_fg_key3 and _fg_key3 != _fg_main_key)
        _k4_avail = bool(_fg_key4 and _fg_key4 != _fg_main_key)
        ttk.Radiobutton(_kr, text="Key1", variable=self._fin_fg_keys, value='key1',
                        style="Card.TRadiobutton").pack(side=tk.LEFT, padx=2)
        _rb_k2 = ttk.Radiobutton(_kr, text="Key2", variable=self._fin_fg_keys, value='key2',
                                  style="Card.TRadiobutton")
        _rb_k2.pack(side=tk.LEFT, padx=2)
        _rb_k3 = ttk.Radiobutton(_kr, text="Key3", variable=self._fin_fg_keys, value='key3',
                                  style="Card.TRadiobutton")
        _rb_k3.pack(side=tk.LEFT, padx=2)
        _rb_k4 = ttk.Radiobutton(_kr, text="Key4", variable=self._fin_fg_keys, value='key4',
                                  style="Card.TRadiobutton")
        _rb_k4.pack(side=tk.LEFT, padx=2)
        _rb_both = ttk.Radiobutton(_kr, text="Both", variable=self._fin_fg_keys, value='both',
                                    style="Card.TRadiobutton")
        _rb_both.pack(side=tk.LEFT, padx=2)
        if not _k2_avail:
            _rb_k2.state(['disabled'])
        if not _k3_avail:
            _rb_k3.state(['disabled'])
        if not _k4_avail:
            _rb_k4.state(['disabled'])
        if not (_k2_avail or _k3_avail or _k4_avail):
            _rb_both.state(['disabled'])

        def _on_engine(*_):
            if self._fin_engine.get() == 'veononstop':
                self._fin_fg_sub.pack_forget()
                self._fin_veo_sub.pack(fill=tk.X)
            else:
                self._fin_veo_sub.pack_forget()
                self._fin_fg_sub.pack(fill=tk.X)
        eng_cb.bind('<<ComboboxSelected>>', _on_engine)
        _on_engine()

        # Skip preflight for ImageGen (shown when refs are involved)
        self._fin_ig_skip_pf = ttk.Checkbutton(self._fin_ig_section, text="Skip preflight",
                                                variable=self._fin_skip_preflight,
                                                style="Card.TCheckbutton")
        def _toggle_ig_skip_pf(*_):
            engine = self._fin_engine.get()
            veo_mode = self._fin_veo_mode.get()
            # Show when: FastGen (always has refs support) or VeoNonStop banana_ref
            show = (engine == 'fastgen') or (engine == 'veononstop' and veo_mode == 'banana_ref')
            if show:
                self._fin_ig_skip_pf.pack(anchor=tk.W, pady=(2, 0))
            else:
                self._fin_ig_skip_pf.pack_forget()
        self._fin_engine.trace_add('write', _toggle_ig_skip_pf)
        self._fin_veo_mode.trace_add('write', _toggle_ig_skip_pf)
        _toggle_ig_skip_pf()

        # SynthID inflight row
        _sid_fin_row = ttk.Frame(self._fin_ig_section, style="Card.TFrame")
        _sid_fin_row.pack(fill=tk.X, pady=(2, 0))
        _sid_fin_fg = COLORS['text'] if _synthid_installed() else COLORS['text_muted']
        tk.Checkbutton(
            _sid_fin_row, text="SynthID remover (inflight)",
            variable=self._fin_synthid_enabled,
            bg=COLORS['bg_card'], fg=_sid_fin_fg, selectcolor=COLORS['bg_card'],
            activebackground=COLORS['bg_card'], activeforeground=COLORS['text'],
            bd=0, highlightthickness=0,
        ).pack(side=tk.LEFT)
        ttk.Combobox(_sid_fin_row, textvariable=self._fin_synthid_strength,
                     values=['gentle', 'moderate', 'aggressive', 'extreme'],
                     width=10, state='readonly').pack(side=tk.LEFT, padx=(4, 0))
        ttk.Combobox(_sid_fin_row, textvariable=self._fin_synthid_version,
                     values=['v1', 'v2', 'v3'],
                     width=4, state='readonly').pack(side=tk.LEFT, padx=(2, 0))
        tk.Checkbutton(
            _sid_fin_row, text="save orig",
            variable=self._fin_synthid_save_orig,
            bg=COLORS['bg_card'], fg=COLORS['text_muted'], selectcolor=COLORS['bg_card'],
            activebackground=COLORS['bg_card'], activeforeground=COLORS['text'],
            bd=0, highlightthickness=0,
        ).pack(side=tk.LEFT, padx=(6, 0))

        _rw_ig_row = ttk.Frame(self._fin_ig_section, style="Card.TFrame")
        _rw_ig_row.pack(fill=tk.X, pady=2)
        ttk.Label(_rw_ig_row, text="Rewrite:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        ttk.Combobox(_rw_ig_row, textvariable=self._fin_rewrite_model,
                     values=REWRITE_DISPLAY, width=30, state='readonly').pack(side=tk.LEFT, padx=4)

        # ── VideoGen section ──
        self._fin_vg_section = ttk.Frame(outer, style="Card.TFrame")
        ttk.Label(self._fin_vg_section, text="VideoGen", style="Section.TLabel").pack(anchor=tk.W)

        # Engine selector: veononstop | fastgen_ultra
        _eng_row = ttk.Frame(self._fin_vg_section, style="Card.TFrame")
        _eng_row.pack(fill=tk.X, pady=(2, 0))
        ttk.Label(_eng_row, text="Engine:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        self._fin_vid_engine = tk.StringVar(value='veononstop')
        ttk.Combobox(_eng_row, textvariable=self._fin_vid_engine,
                     values=['veononstop', 'fastgen_ultra', 'both'], width=14,
                     state='readonly').pack(side=tk.LEFT, padx=4)
        self._fin_vid_fu_info = ttk.Label(_eng_row, text='', style='Dim.TLabel')
        self._fin_vid_fu_info.pack(side=tk.LEFT, padx=(8, 0))

        vg_row = ttk.Frame(self._fin_vg_section, style="Card.TFrame")
        vg_row.pack(fill=tk.X, pady=2)
        ttk.Label(vg_row, text="Mode:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        # Mode: единые имена для юзера (i2v/t2v/components), в routing маппим для fastgen_ultra
        # (i2v → keyframes, components → ingredients). Mode values одинаковые для обоих engine.
        self._fin_vid_mode = tk.StringVar(value="i2v")
        ttk.Combobox(vg_row, textvariable=self._fin_vid_mode,
                     values=["i2v", "t2v", "components"], width=10, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(vg_row, text="Ratio:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_vid_ratio = tk.StringVar(value=config.VEONONSTOP_ASPECT_RATIO)
        ttk.Combobox(vg_row, textvariable=self._fin_vid_ratio,
                     values=["16:9", "9:16", "1:1"], width=6, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(vg_row, text="x", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_vid_par = tk.IntVar(value=config.VEONONSTOP_MAX_PARALLEL)
        tk.Spinbox(vg_row, textvariable=self._fin_vid_par, from_=1, to=200, width=4,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(vg_row, text="Keys:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_vid_keys = tk.StringVar(value="1")
        self._fin_vid_key_checks = {}
        _vid_kf = ttk.Frame(vg_row, style="Card.TFrame")
        _vid_kf.pack(side=tk.LEFT)
        def _update_vid_keys(*_):
            sel = ','.join(str(i) for i in sorted(self._fin_vid_key_checks)
                          if self._fin_vid_key_checks[i].get())
            if not sel:
                sel = '1'
                if 1 in self._fin_vid_key_checks:
                    self._fin_vid_key_checks[1].set(True)
            self._fin_vid_keys.set(sel)
            try:
                lims = self.app.tab_pipeline._veo_key_limits
                total = sum(lims.get(s.strip(), 0) for s in sel.split(','))
                if total > 0:
                    self._fin_vid_par.set(total)
            except Exception:
                pass
        _VKA = [(1, 'VEONONSTOP_API_KEY', config.VEONONSTOP_KEY1_NAME),
                (2, 'VEONONSTOP_API_KEY_2', config.VEONONSTOP_KEY2_NAME),
                (3, 'VEONONSTOP_API_KEY_3', config.VEONONSTOP_KEY3_NAME),
                (4, 'VEONONSTOP_API_KEY_4', config.VEONONSTOP_KEY4_NAME)]
        for _ki, _kattr, _kname in _VKA:
            if getattr(config, _kattr, ''):
                _bv = tk.BooleanVar(value=(_ki == 1))
                self._fin_vid_key_checks[_ki] = _bv
                ttk.Checkbutton(_vid_kf, text=_kname[:6], variable=_bv,
                                style="Card.TCheckbutton",
                                command=_update_vid_keys).pack(side=tk.LEFT, padx=1)
        self._refresh_fin_vid_par = _update_vid_keys
        _update_vid_keys()

        # FastGen keys (shown when engine=fastgen_ultra) — radio Key1/Key2/Both + end-image
        self._fin_fu_kf = ttk.Frame(vg_row, style="Card.TFrame")
        self._fin_fu_keys = tk.StringVar(value='key1')
        _fg_k2_avail = False
        ttk.Radiobutton(self._fin_fu_kf, text="Key1", variable=self._fin_fu_keys,
                        value='key1', style="Card.TRadiobutton").pack(side=tk.LEFT, padx=1)
        self._fin_fu_rb_k2 = ttk.Radiobutton(
            self._fin_fu_kf, text="Key2", variable=self._fin_fu_keys, value='key2',
            style="Card.TRadiobutton")
        self._fin_fu_rb_k2.pack(side=tk.LEFT, padx=1)
        self._fin_fu_rb_both = ttk.Radiobutton(
            self._fin_fu_kf, text="Both", variable=self._fin_fu_keys, value='both',
            style="Card.TRadiobutton")
        self._fin_fu_rb_both.pack(side=tk.LEFT, padx=1)
        if not _fg_k2_avail:
            self._fin_fu_rb_k2.state(['disabled'])
            self._fin_fu_rb_both.state(['disabled'])
        # End-image opt-in (keyframes pair mode: end = next clip's generated/ image)
        self._fin_fu_end = tk.BooleanVar(value=False)
        ttk.Checkbutton(self._fin_fu_kf, text="End frame (next clip)",
                        variable=self._fin_fu_end,
                        style="Card.TCheckbutton").pack(side=tk.LEFT, padx=(12, 0))

        # Engine toggle: показывает/скрывает VeoNonStop checkboxes или FastGen radio
        def _toggle_vid_engine(*_):
            _eng = self._fin_vid_engine.get()
            if _eng == 'fastgen_ultra':
                _vid_kf.pack_forget()
                self._fin_fu_kf.pack(side=tk.LEFT)
                # Label: Flow Ultra quota (lazy fetch, not blocking)
                try:
                    from modules.fastgen import FastGenClient
                    _c = FastGenClient(api_key=getattr(config, 'FASTGEN_API_KEY', ''))
                    _u = _c.get_flow_ultra_usage()
                    if _u.get('available'):
                        self._fin_vid_fu_info.config(
                            text=f"Flow Ultra: {_u['hour_limit']}/hr, {_u['threads_allowed']} thr")
                    else:
                        self._fin_vid_fu_info.config(
                            text="Flow Ultra: no subscription on Key1", foreground='#c05858')
                except Exception as _fu_e:
                    self._fin_vid_fu_info.config(text=f"Flow Ultra quota: {_fu_e}")
                # Clamp parallel to Flow Ultra threads_allowed
                try:
                    _thr = int(self._fin_vid_fu_info.cget('text').split(',')[-1].strip().split()[0])
                    if _thr > 0 and self._fin_vid_par.get() > _thr:
                        self._fin_vid_par.set(_thr)
                except Exception:
                    pass
            else:
                self._fin_fu_kf.pack_forget()
                _vid_kf.pack(side=tk.LEFT)
                self._fin_vid_fu_info.config(text='', foreground='')
        self._fin_vid_engine.trace_add('write', _toggle_vid_engine)
        _toggle_vid_engine()
        vg_row2 = ttk.Frame(self._fin_vg_section, style="Card.TFrame")
        vg_row2.pack(fill=tk.X, pady=2)
        ttk.Label(vg_row2, text="Prompt:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        self._fin_vid_prompt_mode = tk.StringVar(value="per-clip")
        ttk.Combobox(vg_row2, textvariable=self._fin_vid_prompt_mode,
                     values=["per-clip", "single"], width=8, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(vg_row2, text="(single reads single_prompt.txt)", style="Dim.TLabel").pack(side=tk.LEFT, padx=4)
        ttk.Label(vg_row2, text="Skipper:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_fast_censor = tk.StringVar(value=getattr(config, 'VEONONSTOP_FAST_CENSOR', 'off'))
        ttk.Combobox(vg_row2, textvariable=self._fin_fast_censor,
                     values=['off', 'after_rewrites', 'ultrafast'], width=14, state='readonly').pack(side=tk.LEFT, padx=2)
        self._fin_vg_skip_pf = ttk.Checkbutton(vg_row2, text="Skip preflight",
                                                variable=self._fin_skip_preflight,
                                                style="Card.TCheckbutton")
        # shown/hidden dynamically based on vid_mode
        self._fin_vid_upscale = tk.BooleanVar(value=getattr(config, 'VEONONSTOP_VIDEO_UPSCALE', False))
        ttk.Checkbutton(vg_row2, text="Upscale 1080p", variable=self._fin_vid_upscale,
                        style="Card.TCheckbutton").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_inflight = tk.BooleanVar(value=False)
        ttk.Checkbutton(vg_row2, text="Inflight", variable=self._fin_inflight,
                        style="Card.TCheckbutton").pack(side=tk.LEFT, padx=(8, 0))

        # Ref images for components mode
        self._fin_vid_ref_row = ttk.Frame(self._fin_vg_section, style="Card.TFrame")
        self._fin_vid_refs: list = []
        _ref_top = ttk.Frame(self._fin_vid_ref_row, style="Card.TFrame")
        _ref_top.pack(fill=tk.X)
        ttk.Label(_ref_top, text="Refs:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        ttk.Button(_ref_top, text="Add", command=self._fin_browse_refs).pack(side=tk.LEFT, padx=2)
        ttk.Button(_ref_top, text="Clear", command=self._fin_clear_refs).pack(side=tk.LEFT, padx=2)
        ttk.Label(_ref_top, text="(if empty: project/ref/)", style="Dim.TLabel").pack(side=tk.LEFT, padx=4)
        self._fin_ref_listbox = tk.Listbox(self._fin_vid_ref_row, height=3,
                                           bg=COLORS['bg_input'], fg=COLORS['text'],
                                           selectbackground=COLORS['accent'], font=FONT_DIM)
        self._fin_ref_listbox.pack(fill=tk.X, pady=(2, 0))

        def _toggle_ref_row(*_):
            if self._fin_vid_mode.get() == 'components':
                self._fin_vid_ref_row.pack(fill=tk.X, pady=2, after=vg_row2)
                self._fin_vg_skip_pf.pack(side=tk.LEFT, padx=(8, 0))
            else:
                self._fin_vid_ref_row.pack_forget()
                self._fin_vg_skip_pf.pack_forget()
        self._fin_vid_mode.trace_add('write', _toggle_ref_row)
        _toggle_ref_row()

        _rw_vg_row = ttk.Frame(self._fin_vg_section, style="Card.TFrame")
        _rw_vg_row.pack(fill=tk.X, pady=2)
        ttk.Label(_rw_vg_row, text="Rewrite:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        ttk.Combobox(_rw_vg_row, textvariable=self._fin_rewrite_model,
                     values=REWRITE_DISPLAY, width=30, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(_rw_vg_row, text="Remix:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        ttk.Combobox(_rw_vg_row, textvariable=self._fin_remix_engine,
                     values=['grok', 'kieai'], width=8, state='readonly').pack(side=tk.LEFT, padx=4)

        # Retry / delay row (VeoNonStop engine only — FU ignores these)
        _vg_row3 = ttk.Frame(self._fin_vg_section, style="Card.TFrame")
        _vg_row3.pack(fill=tk.X, pady=2)
        ttk.Label(_vg_row3, text="Retries:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        tk.Spinbox(_vg_row3, textvariable=self._fin_vid_max_retries, from_=1, to=10, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(_vg_row3, text="Cycles:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        tk.Spinbox(_vg_row3, textvariable=self._fin_vid_max_cycles, from_=1, to=10, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(_vg_row3, text="Delay:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        tk.Spinbox(_vg_row3, textvariable=self._fin_vid_request_delay, from_=0.5, to=30.0,
                   increment=0.5, width=4, format="%.1f",
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(_vg_row3, text="s", style="Dim.TLabel").pack(side=tk.LEFT)

        # reCAPTCHA tuning row (VeoNonStop only)
        _vg_row4 = ttk.Frame(self._fin_vg_section, style="Card.TFrame")
        _vg_row4.pack(fill=tk.X, pady=2)
        ttk.Label(_vg_row4, text="reCAPTCHA:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        tk.Spinbox(_vg_row4, textvariable=self._fin_vid_recaptcha_delay, from_=1.0, to=60.0,
                   increment=1.0, width=4, format="%.1f",
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(_vg_row4, text="s  jitter:", style="Dim.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(_vg_row4, textvariable=self._fin_vid_recaptcha_jitter, from_=0.5, to=30.0,
                   increment=0.5, width=4, format="%.1f",
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=2)
        ttk.Label(_vg_row4, text="s", style="Dim.TLabel").pack(side=tk.LEFT)

        # GPT adapt VEO prompts row
        self._fin_codex_adapt_row = ttk.Frame(self._fin_vg_section, style="Card.TFrame")
        self._fin_codex_adapt_row.pack(fill=tk.X, pady=2)
        ttk.Checkbutton(self._fin_codex_adapt_row, text="GPT adapt VEO prompts",
                        variable=self._fin_codex_adapt,
                        style="Card.TCheckbutton").pack(side=tk.LEFT)
        self._fin_veo_adapt_lbl = ttk.Label(self._fin_codex_adapt_row, text="(default)", style="Dim.TLabel")
        self._fin_veo_adapt_lbl.pack(side=tk.LEFT, padx=(6, 0))

        def _browse_fin_veo_adapt():
            path = filedialog.askopenfilename(
                title="VEO adapt prompts override",
                filetypes=[("Text files", "*.txt"), ("All", "*.*")])
            if path:
                self._fin_veo_adapt_path = Path(path)
                self._fin_veo_adapt_lbl.config(text=self._fin_veo_adapt_path.name)

        ttk.Button(self._fin_codex_adapt_row, text="Browse",
                   command=_browse_fin_veo_adapt).pack(side=tk.LEFT, padx=4)

        # ── Story Mode section ──
        _sm_section = ttk.Frame(self._fin_vg_section, style="Card.TFrame")
        _sm_section.pack(fill=tk.X, pady=(4, 0))
        ttk.Label(_sm_section, text="Story Mode:", style="Card.TLabel").pack(anchor=tk.W)
        for _val, _txt in [
            ('off',   'Off (independent clips)'),
            ('batch', 'Batch (Start -> End video)'),
            ('morph', 'Morph (one continuous chain)'),
            ('chain', 'Chain (LLM scene breaks)')
        ]:
            ttk.Radiobutton(_sm_section, text=_txt, variable=self._fin_story_mode, value=_val,
                            style="Card.TRadiobutton",
                            command=self._toggle_chain_settings_fin).pack(anchor=tk.W, padx=(10, 0), pady=1)

        # Chain Mode Settings (показывается только при Chain)
        self._chain_fin_frame = ttk.Frame(_sm_section, style="Card.TFrame")
        ttk.Separator(self._chain_fin_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=(4, 6))
        _r1 = ttk.Frame(self._chain_fin_frame, style="Card.TFrame")
        _r1.pack(fill=tk.X, pady=2, padx=(10, 0))
        ttk.Checkbutton(_r1, text="Mute audio", variable=self.app.chain_mute_audio,
                        style="Card.TCheckbutton").pack(side=tk.LEFT)
        ttk.Checkbutton(_r1, text="ImgGen heads only", variable=self.app.chain_imggen_heads_only,
                        style="Card.TCheckbutton").pack(side=tk.LEFT, padx=(6, 0))
        _r1b = ttk.Frame(self._chain_fin_frame, style="Card.TFrame")
        _r1b.pack(fill=tk.X, pady=2, padx=(10, 0))
        ttk.Checkbutton(_r1b, text="Cascade recovery", variable=self.app.chain_cascade_recovery,
                        style="Card.TCheckbutton").pack(side=tk.LEFT)
        _r2 = ttk.Frame(self._chain_fin_frame, style="Card.TFrame")
        _r2.pack(fill=tk.X, pady=2, padx=(10, 0))
        ttk.Label(_r2, text="Trim:", style="Card.TLabel", width=5).pack(side=tk.LEFT)
        ttk.Spinbox(_r2, from_=1, to=5, textvariable=self.app.chain_trim_frames, width=4).pack(side=tk.LEFT, padx=2)
        ttk.Label(_r2, text="Offset:", style="Card.TLabel", width=6).pack(side=tk.LEFT, padx=(8, 0))
        ttk.Spinbox(_r2, from_=0.1, to=2.0, increment=0.1, textvariable=self.app.chain_frame_offset, width=4).pack(side=tk.LEFT, padx=2)
        _r3 = ttk.Frame(self._chain_fin_frame, style="Card.TFrame")
        _r3.pack(fill=tk.X, pady=2, padx=(10, 0))
        ttk.Label(_r3, text="Max chain:", style="Card.TLabel", width=9).pack(side=tk.LEFT)
        ttk.Spinbox(_r3, from_=1, to=50, textvariable=self.app.chain_max_chain, width=4).pack(side=tk.LEFT, padx=2)
        ttk.Label(_r3, text="Max fails:", style="Card.TLabel", width=8).pack(side=tk.LEFT, padx=(8, 0))
        ttk.Spinbox(_r3, from_=1, to=10, textvariable=self.app.chain_max_fails, width=4).pack(side=tk.LEFT, padx=2)
        self._toggle_chain_settings_fin()  # Initial visibility

        # ── Concat section ──
        self._fin_cc_section = ttk.Frame(outer, style="Card.TFrame")
        ttk.Label(self._fin_cc_section, text="Concat", style="Section.TLabel").pack(anchor=tk.W)
        cc_row = ttk.Frame(self._fin_cc_section, style="Card.TFrame")
        cc_row.pack(fill=tk.X, pady=2)
        ttk.Label(cc_row, text="Quality:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        self._fin_quality = tk.StringVar(value="Fast")
        _QUALITY_OPTIONS = ["Fast", "1080p", "4K"]
        self._fin_quality_cb = ttk.Combobox(cc_row, textvariable=self._fin_quality,
                     values=_QUALITY_OPTIONS, width=8, state='readonly')
        self._fin_quality_cb.pack(side=tk.LEFT, padx=4)

        def _on_fin_vid_upscale(*_):
            if self._fin_vid_upscale.get():
                self._fin_quality.set("Fast")
                self._fin_quality_cb.config(state='disabled')
            else:
                self._fin_quality_cb.config(state='readonly')
        self._fin_vid_upscale.trace_add('write', _on_fin_vid_upscale)
        _on_fin_vid_upscale()
        ttk.Label(cc_row, text="Bitrate:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_bitrate = tk.StringVar(value="10M")
        ttk.Combobox(cc_row, textvariable=self._fin_bitrate,
                     values=["5M", "8M", "10M", "15M", "20M", "25M", "30M", "35M", "40M"],
                     width=6, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(cc_row, text="FPS:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_fps = tk.IntVar(value=60)
        ttk.Combobox(cc_row, textvariable=self._fin_fps,
                     values=[24, 25, 30, 50, 60], width=4, state='readonly').pack(side=tk.LEFT, padx=4)
        self._fin_keep_veo = tk.BooleanVar(value=False)
        ttk.Checkbutton(cc_row, text="Keep VEO Sound", variable=self._fin_keep_veo,
                        style="Card.TCheckbutton").pack(side=tk.LEFT, padx=12)
        self._fin_keep_files = tk.BooleanVar(value=False)
        ttk.Checkbutton(cc_row, text="Keep temp files", variable=self._fin_keep_files,
                        style="Card.TCheckbutton").pack(side=tk.LEFT)

        # Watermark/Logo row
        wm_row = ttk.Frame(self._fin_cc_section, style="Card.TFrame")
        wm_row.pack(fill=tk.X, pady=2)
        ttk.Label(wm_row, text="Watermark:", style="Card.TLabel", width=10).pack(side=tk.LEFT)
        self._fin_watermark = tk.StringVar(value=getattr(config, 'PIPELINE_WATERMARK', 'as_is'))
        ttk.Combobox(wm_row, textvariable=self._fin_watermark,
                     values=['as_is', 'logo', 'blur'], width=8, state='readonly').pack(side=tk.LEFT, padx=4)
        self._fin_logo_path = tk.StringVar(value='')
        self._fin_logo_entry = ttk.Entry(wm_row, textvariable=self._fin_logo_path, width=30)
        self._fin_logo_entry.pack(side=tk.LEFT, padx=4)

        def _fin_pick_logo():
            path = filedialog.askopenfilename(
                title="Select logo PNG",
                filetypes=[("PNG image", "*.png"), ("All images", "*.png *.jpg *.jpeg *.webp"), ("All", "*.*")])
            if path:
                self._fin_logo_path.set(path)

        self._fin_logo_btn = ttk.Button(wm_row, text="Browse", command=_fin_pick_logo)
        self._fin_logo_btn.pack(side=tk.LEFT, padx=2)
        ttk.Label(wm_row, text="(empty = project/logo.png)", style="Dim.TLabel").pack(side=tk.LEFT, padx=4)

        def _toggle_logo_fields(*_):
            _is_logo = (self._fin_watermark.get() == 'logo')
            _state = 'normal' if _is_logo else 'disabled'
            self._fin_logo_entry.config(state=_state)
            self._fin_logo_btn.config(state=_state)
        self._fin_watermark.trace_add('write', _toggle_logo_fields)
        _toggle_logo_fields()
        sub_row = ttk.Frame(self._fin_cc_section, style="Card.TFrame")
        sub_row.pack(fill=tk.X, pady=2)
        self._fin_subtitles_enabled = tk.BooleanVar(value=False)
        self._fin_subtitles_preset  = tk.StringVar(value='bottom')
        self._fin_subtitles_custom  = tk.BooleanVar(value=False)
        self._fin_subtitles_path    = tk.StringVar(value='')
        ttk.Checkbutton(sub_row, text="Subtitles", variable=self._fin_subtitles_enabled,
                        style="Card.TCheckbutton").pack(side=tk.LEFT)
        ttk.Label(sub_row, text="Preset:", style="Dim.TLabel").pack(side=tk.LEFT, padx=(10, 2))
        ttk.Radiobutton(sub_row, text="Bottom", variable=self._fin_subtitles_preset,
                        value='bottom', style="Card.TRadiobutton").pack(side=tk.LEFT)
        ttk.Radiobutton(sub_row, text="Center", variable=self._fin_subtitles_preset,
                        value='center', style="Card.TRadiobutton").pack(side=tk.LEFT, padx=(4, 0))
        _fin_custom_row = ttk.Frame(self._fin_cc_section, style="Card.TFrame")
        ttk.Checkbutton(sub_row, text="Custom template", variable=self._fin_subtitles_custom,
                        style="Card.TCheckbutton",
                        command=lambda: _fin_custom_row.pack(fill=tk.X) if self._fin_subtitles_custom.get()
                                        else _fin_custom_row.pack_forget()).pack(side=tk.LEFT, padx=(8, 0))
        ttk.Entry(_fin_custom_row, textvariable=self._fin_subtitles_path, width=36).pack(side=tk.LEFT, padx=4)
        ttk.Button(_fin_custom_row, text="Add",
                   command=lambda: self._fin_subtitles_path.set(
                       filedialog.askopenfilename(filetypes=[("ASS subtitles", "*.ass"), ("All files", "*.*")])
                   )).pack(side=tk.LEFT)

        # ── YT Pack settings section ──
        _yt_langs_p = getattr(config, 'YT_PACK_LANGUAGES', ['ru', 'en'])
        if isinstance(_yt_langs_p, (list, tuple)):
            _yt_langs_p_str = ','.join(str(l).strip(" '\"[]()") for l in _yt_langs_p if str(l).strip(" '\"[]()"))
        else:
            _yt_langs_p_str = ','.join(l.strip() for l in str(_yt_langs_p).strip("[]'\"()").split(',') if l.strip())
        _YT_MODEL_OPTS = _GEMINI_MODEL_OPTS + ['gpt-5.5', 'gpt-5.4', 'gpt-5.4-mini']
        self._fin_yt_section = ttk.Frame(outer, style="Card.TFrame")
        ttk.Label(self._fin_yt_section, text="YT Pack", style="Section.TLabel").pack(anchor=tk.W)
        yt0 = ttk.Frame(self._fin_yt_section, style="Card.TFrame"); yt0.pack(fill=tk.X, pady=2)
        ttk.Label(yt0, text="Content:", style="Card.TLabel", width=12).pack(side=tk.LEFT)
        self._fin_yt_content_model = tk.StringVar(value=getattr(config, 'YT_PACK_CONTENT_MODEL', _GEMINI_MODEL_OPTS[0]))
        ttk.Combobox(yt0, textvariable=self._fin_yt_content_model, values=_YT_MODEL_OPTS,
                     width=20, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Label(yt0, text="Translate:", style="Card.TLabel").pack(side=tk.LEFT, padx=(8, 0))
        self._fin_yt_translate_model = tk.StringVar(value=getattr(config, 'YT_PACK_TRANSLATE_MODEL', _GEMINI_MODEL_OPTS[0]))
        ttk.Combobox(yt0, textvariable=self._fin_yt_translate_model, values=_YT_MODEL_OPTS,
                     width=20, state='readonly').pack(side=tk.LEFT, padx=4)
        yt1 = ttk.Frame(self._fin_yt_section, style="Card.TFrame"); yt1.pack(fill=tk.X, pady=2)
        ttk.Label(yt1, text="Languages:", style="Card.TLabel", width=12).pack(side=tk.LEFT)
        self._fin_yt_langs = tk.StringVar(value=_yt_langs_p_str)
        ttk.Entry(yt1, textvariable=self._fin_yt_langs, width=16).pack(side=tk.LEFT, padx=4)
        yt2 = ttk.Frame(self._fin_yt_section, style="Card.TFrame"); yt2.pack(fill=tk.X, pady=2)
        ttk.Label(yt2, text="Generate:", style="Card.TLabel", width=12).pack(side=tk.LEFT)
        self._fin_yt_subs = tk.BooleanVar(value=bool(getattr(config, 'YT_PACK_SUBTITLES', True)))
        ttk.Checkbutton(yt2, text="Subtitles", variable=self._fin_yt_subs, style="Card.TCheckbutton").pack(side=tk.LEFT, padx=2)
        self._fin_yt_desc = tk.BooleanVar(value=bool(getattr(config, 'YT_PACK_DESCRIPTION', True)))
        ttk.Checkbutton(yt2, text="Description", variable=self._fin_yt_desc, style="Card.TCheckbutton").pack(side=tk.LEFT, padx=6)
        self._fin_yt_covers = tk.BooleanVar(value=bool(getattr(config, 'YT_PACK_COVERS', True)))
        ttk.Checkbutton(yt2, text="Covers", variable=self._fin_yt_covers, style="Card.TCheckbutton").pack(side=tk.LEFT, padx=6)

        # Finalize button
        btn_f = ttk.Frame(outer, style="Card.TFrame")
        btn_f.pack(fill=tk.X, pady=(6, 0))
        ttk.Button(btn_f, text="Finalize Project →", command=self._finalize_project,
                   style="Accent.TButton").pack(side=tk.RIGHT)

        # Show/hide sections based on start stage and ytpack toggle
        def _update_visibility(*_):
            start = self._fin_start.get()
            order = ["Direction", "Prompts Only", "ImageGen", "VideoGen", "Concat", "YT Pack"]
            idx = order.index(start) if start in order else 0
            for sec in (self._fin_dir_section, self._fin_ig_section, self._fin_vg_section,
                        self._fin_cc_section, self._fin_yt_section):
                sec.pack_forget()
            if idx <= 1:  # Direction or Prompts Only
                self._fin_dir_section.pack(fill=tk.X, pady=2, before=btn_f)
                # Prompts Only: hide clip/intro/sg settings (only backend+model needed)
                if start == "Prompts Only":
                    dr2.pack_forget(); dr3.pack_forget()
                    dr4.pack(fill=tk.X, pady=2)
                else:
                    dr2.pack(fill=tk.X, pady=2); dr3.pack(fill=tk.X, pady=2); dr4.pack(fill=tk.X, pady=2)
            if idx <= 2:
                self._fin_ig_section.pack(fill=tk.X, pady=2, before=btn_f)
            if idx <= 3:
                self._fin_vg_section.pack(fill=tk.X, pady=2, before=btn_f)
            if idx <= 4:
                self._fin_cc_section.pack(fill=tk.X, pady=2, before=btn_f)
            if start == "YT Pack" or self._fin_ytpack.get():
                self._fin_yt_section.pack(fill=tk.X, pady=2, before=btn_f)

        self._fin_start.trace_add('write', _update_visibility)
        self._fin_ytpack.trace_add('write', _update_visibility)
        _update_visibility()

        return wrapper

    def _finalize_project(self):
        p = self._get_selected()
        if not p:
            return
        _STAGE_ORDER = ["Direction", "Prompts Only", "ImageGen", "VideoGen", "Concat", "YT Pack"]
        start = self._fin_start.get()
        start_idx = _STAGE_ORDER.index(start) if start in _STAGE_ORDER else 0
        stages = list(_STAGE_ORDER[start_idx:])
        if not self._fin_ytpack.get():
            stages = [s for s in stages if s != "YT Pack"]
        if not stages:
            return

        # Validate prerequisites
        if "Direction" in stages and not (p / 'transcription.json').exists():
            messagebox.showerror("Missing file", "No transcription.json — cannot run Direction stage")
            return
        if any(s in stages for s in ("ImageGen", "VideoGen", "Concat")) and \
                not (p / 'montage_plan.json').exists() and "Direction" not in stages:
            messagebox.showerror("Missing file", "No montage_plan.json — run Direction stage first")
            return

        settings = {
            'engine':       self._fin_engine.get(),
            'veo_mode':     self._fin_veo_mode.get(),
            'veo_ratio':    self._fin_veo_ratio.get(),
            'veo_parallel': self._fin_veo_par.get(),
            'veo_model':    BANANA_NAME_TO_KEY.get(self._fin_veo_model.get(), 'GEM_PIX_2'),
            'veo_imgkeys':  self._fin_veo_imgkeys.get(),
            'fg_model':     FASTGEN_NAME_TO_KEY.get(self._fin_fg_model.get(), self._fin_fg_model.get()),
            'fg_aspect':    self._fin_fg_aspect.get(),
            'fg_parallel':  self._fin_fg_par.get(),
            'fg_keys':      self._fin_fg_keys.get(),
            'vid_engine':   self._fin_vid_engine.get(),
            'fu_keys':      self._fin_fu_keys.get(),
            'fu_end_image': self._fin_fu_end.get(),
            'vid_mode':     self._fin_vid_mode.get(),
            'vid_ratio':    self._fin_vid_ratio.get(),
            'vid_parallel':     self._fin_vid_par.get(),
            'vid_keys':         self._fin_vid_keys.get(),
            'vid_prompt_mode':  self._fin_vid_prompt_mode.get(),
            'vid_ref_files':    list(self._fin_vid_refs),
            'img_ref_files':    list(self._fin_img_refs),
            'skip_preflight':   self._fin_skip_preflight.get(),
            'fast_censor':      self._fin_fast_censor.get(),
            'img_upscale':      self._fin_img_upscale.get(),
            'vid_upscale':      self._fin_vid_upscale.get(),
            'inflight_mode':    self._fin_inflight.get(),
            'vid_max_retries':       self._fin_vid_max_retries.get(),
            'vid_max_cycles':        self._fin_vid_max_cycles.get(),
            'vid_request_delay':     float(self._fin_vid_request_delay.get()),
            'vid_recaptcha_delay':   float(self._fin_vid_recaptcha_delay.get()),
            'vid_recaptcha_jitter':  float(self._fin_vid_recaptcha_jitter.get()),
            'remix_engine':          self._fin_remix_engine.get(),
            'codex_adapt':           self._fin_codex_adapt.get(),
            'veo_adapt_path':        (str(self._fin_veo_adapt_path) if self._fin_veo_adapt_path else None),
            'story_mode':            self._fin_story_mode.get(),
            'chain_imggen_heads_only': self.app.chain_imggen_heads_only.get(),
            'chain_max_chain':         self.app.chain_max_chain.get(),
            'chain_cascade_recovery':  self.app.chain_cascade_recovery.get(),
            'chain_max_fails':         self.app.chain_max_fails.get(),
            'chain_frame_offset':      self.app.chain_frame_offset.get(),
            'chain_trim_frames':       self.app.chain_trim_frames.get(),
            'chain_mute_audio':        self.app.chain_mute_audio.get(),
            'watermark':             self._fin_watermark.get(),
            'logo_path':             self._fin_logo_path.get().strip(),
            'synthid_enabled':   self._fin_synthid_enabled.get(),
            'synthid_strength':  self._fin_synthid_strength.get(),
            'synthid_version':   self._fin_synthid_version.get(),
            'synthid_save_orig': self._fin_synthid_save_orig.get(),
            'quality':      self._fin_quality.get(),
            'bitrate':      self._fin_bitrate.get(),
            'fps':          int(self._fin_fps.get()),
            'keep_veo_sound': self._fin_keep_veo.get(),
            'keep_files': self._fin_keep_files.get(),
            'subtitles_path': (self._fin_subtitles_path.get() if self._fin_subtitles_custom.get()
                               else _find_ass_template(self._fin_quality.get(), self._fin_subtitles_preset.get())) if self._fin_subtitles_enabled.get() else '',
            # Direction settings
            'dir_backend':         self._fin_backend.get(),
            'dir_gpt_model':       self._fin_gpt_model.get(),
            'dir_gpt_chunk_size':  self._fin_gpt_chunk_size.get(),
            'dir_gpt_parallel':    self._fin_gpt_parallel.get(),
            'dir_model':           self._fin_gemini_model.get(),
            'dir_twopass':         self._fin_dir_twopass.get(),
            'dir_clipmode':   self._fin_dir_clipmode.get(),
            'dir_vislide_interval': self._fin_dir_vislide_interval.get(),
            'dir_clipmin':    self._fin_dir_clipmin.get(),
            'dir_clipmax':    self._fin_dir_clipmax.get(),
            'dir_intro':      self._fin_dir_intro.get(),
            'dir_intro_min':  self._fin_dir_intro_min.get(),
            'dir_intro_max':  self._fin_dir_intro_max.get(),
            'dir_adapt_sg':   self._fin_dir_adapt_sg.get(),
            'rewrite_model':  REWRITE_LABEL_TO_SPEC.get(self._fin_rewrite_model.get(), 'gemini:gemini-2.5-flash-lite'),
            # YT Pack settings
            'yt_content_model':   self._fin_yt_content_model.get(),
            'yt_translate_model': self._fin_yt_translate_model.get(),
            'yt_langs':    self._fin_yt_langs.get(),
            'yt_subs':     self._fin_yt_subs.get(),
            'yt_desc':     self._fin_yt_desc.get(),
            'yt_covers':   self._fin_yt_covers.get(),
        }
        self.active_tasks += 1
        self.root.after(0, self._update_status)
        self.app.log(
            f"Finalize {p.name}  |  from: {start}  |  stages: {', '.join(stages)}",
            "INFO", tab="control"
        )
        threading.Thread(target=self._finalize_worker,
                         args=(p, stages, settings), daemon=True).start()

    def _finalize_worker(self, p: Path, stages: list, settings: dict):
        import datetime
        t_start = time.time()
        master_path = p / 'pipeline_full.log'
        self._clear_hard_stop_flag()

        # Восстанавливаем параметры первого запуска проекта (vislide_interval, intro_block_duration,
        # clip_min/max) в os.environ варагента. Внутри стадий ImageGen/VideoGen многие участки кода
        # читают os.environ.get('VARAGENT_VISLIDE_INTERVAL', '0') — а у нас этой переменной нет
        # после закрытия GUI. Без этого ресюм проекта в vislide-режиме теряет фильтрацию клипов
        # и анимируется ВСЁ. Конфиг лежит в pipeline_config.json (или fallback — [ARGS] из лога).
        try:
            _restored_cfg = _load_project_config(p)
            if _restored_cfg:
                _inject_project_config_env(os.environ, p)
                _vi_log = _restored_cfg.get('vislide_interval', 0) if _restored_cfg.get('clip_mode') == 'vislide' else 0
                _ibd_log = _restored_cfg.get('intro_block_duration', 0)
                if _vi_log or _ibd_log:
                    self.app.log(
                        f"Project config restored: clip_mode={_restored_cfg.get('clip_mode', '?')}, "
                        f"vislide_interval={_vi_log}, intro_block={_ibd_log}s",
                        "INFO", tab="control"
                    )
        except Exception as _restore_err:
            self.app.log(f"pipeline_config restore failed: {_restore_err}", "WARNING", tab="control")

        # Сбросить shutdown events — новый запуск, прежний Hard Stop не должен блокировать
        try:
            from modules.fastgen import _flowultra_shutdown_event as _fu
            _fu.clear()
        except Exception:
            pass
        try:
            from modules.imggen import _shutdown_event as _img
            _img.clear()
        except Exception:
            pass
        try:
            from modules.veo_video import _shutdown_requested as _veo
            _veo.clear()
        except Exception:
            pass
        _current_stage = "(init)"

        def _open_logs(label):
            ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
            safe = "".join(c if c.isalnum() or c in '-_' else '_' for c in label)
            log_fh = open(p / f"stage_{safe}_{ts}.log", 'w', encoding='utf-8')
            log_fh.write(f"=== {label} | {datetime.datetime.now()} ===\n\n")
            mfh = open(master_path, 'a', encoding='utf-8')
            mfh.write(f"\n{'='*60}\n=== {label} | {datetime.datetime.now()} ===\n{'='*60}\n\n")
            return log_fh, mfh

        def _close_logs(log_fh, mfh, elapsed):
            m, s = divmod(int(elapsed), 60)
            for fh in (log_fh, mfh):
                if fh:
                    try:
                        fh.write(f"\n=== DONE: {m}m {s}s ===\n")
                        fh.close()
                    except Exception:
                        pass

        try:
            with open(master_path, 'a', encoding='utf-8') as f:
                f.write(
                    f"\n{'='*60}\n=== FINALIZE PIPELINE | {datetime.datetime.now()} ===\n"
                    f"Stages: {', '.join(stages)}\n{'='*60}\n"
                )

            # Helper: check if any module's shutdown event is set (Hard Stop)
            def _is_hard_stopped() -> bool:
                try:
                    from modules.fastgen import _flowultra_shutdown_event as _fu
                    if _fu.is_set(): return True
                except Exception: pass
                try:
                    from modules.imggen import _shutdown_event as _img
                    if _img.is_set(): return True
                except Exception: pass
                try:
                    from modules.veo_video import _shutdown_requested as _veo
                    if _veo.is_set(): return True
                except Exception: pass
                return False

            for stage in stages:
                # Global Hard Stop — не идём в следующий stage
                if _is_hard_stopped():
                    self.app.log(
                        f"Hard Stop detected — skipping remaining stages for {p.name}",
                        "WARNING", tab="control"
                    )
                    break
                _current_stage = stage
                t_stage = time.time()
                self.app.log(f"── Finalize: {stage} ({p.name}) ──", "INFO", tab="control")
                log_fh, mfh = _open_logs(f"Finalize_{stage}")
                try:
                    if stage in ("Direction", "Prompts Only"):
                        tr = p / 'transcription.json'
                        styles = list(p.glob('*style*')) + list(p.glob('*.txt'))
                        style = str(styles[0]) if styles else ''
                        from modules.director import direct_project
                        _dir_backend = settings.get('dir_backend', 'gpt')
                        config.DIRECTOR_BACKEND = _dir_backend
                        if _dir_backend == 'gpt':
                            config.GPT_MODEL = settings.get('dir_gpt_model', 'gpt-5.4')
                            if settings.get('dir_gpt_chunk_size'):
                                config.GPT_PASS2_CHUNK_SIZE = int(settings['dir_gpt_chunk_size'])
                            if settings.get('dir_gpt_parallel'):
                                config.GPT_PASS2_PARALLEL = int(settings['dir_gpt_parallel'])
                        else:
                            config.GEMINI_MODEL    = settings['dir_model']
                            config.GEMINI_TWO_PASS = settings['dir_twopass'].lower() in ('true', '1', 'yes')
                        if settings['dir_clipmode'] == 'video':
                            config.VIDEO_CLIP_MIN_DURATION = settings['dir_clipmin']
                            config.VIDEO_CLIP_MAX_DURATION = settings['dir_clipmax']
                        else:
                            config.SLIDESHOW_CLIP_MIN_DURATION = settings['dir_clipmin']
                            config.SLIDESHOW_CLIP_MAX_DURATION = settings['dir_clipmax']
                        config.INTRO_BLOCK_DURATION    = settings['dir_intro']
                        config.INTRO_CLIP_MIN_DURATION = settings['dir_intro_min']
                        config.INTRO_CLIP_MAX_DURATION = settings['dir_intro_max']
                        # Vislide: пробрасываем interval в env для последующих стадий (ImageGen/VideoGen)
                        # которые в той же сессии Finalize запустятся после Direction.
                        if settings['dir_clipmode'] == 'vislide':
                            _vi = int(settings.get('dir_vislide_interval', 0) or 0)
                            if _vi >= 2:
                                os.environ['VARAGENT_VISLIDE_INTERVAL'] = str(_vi)
                            # Также обновляем pipeline_config.json чтобы это сохранилось для будущих ресюмов
                            try:
                                import json as _json_dir
                                _cfg_path_dir = p / 'pipeline_config.json'
                                _cfg_dir = _json_dir.loads(_cfg_path_dir.read_text(encoding='utf-8')) if _cfg_path_dir.exists() else {}
                                _cfg_dir['clip_mode'] = 'vislide'
                                _cfg_dir['vislide_interval'] = _vi
                                _cfg_dir['intro_block_duration'] = int(settings['dir_intro'])
                                _cfg_dir['clip_min'] = int(settings['dir_clipmin'])
                                _cfg_dir['clip_max'] = int(settings['dir_clipmax'])
                                _cfg_path_dir.write_text(_json_dir.dumps(_cfg_dir, indent=2, ensure_ascii=False),
                                                          encoding='utf-8')
                            except Exception:
                                pass
                        else:
                            os.environ.pop('VARAGENT_VISLIDE_INTERVAL', None)
                        _prompts_only = (stage == "Prompts Only")
                        # SG Adapt: адаптируем стайлгайд под текущий сюжет
                        if settings.get('dir_adapt_sg') and style:
                            self.app.log(f"SG Adapt: adapting style guide for {p.name}...", "INFO", tab="control")
                            from modules.sg_adapter import adapt_style_guide
                            with capture_stdout(self.app.log_queue, "control",
                                               log_file=log_fh, task_label=f"SG Adapt {p.name}",
                                               master_log=mfh):
                                adapted = adapt_style_guide(
                                    original_sg_path=style,
                                    project_dir=str(p),
                                    project_name=p.name,
                                )
                            style = adapted
                            self.app.log(f"SG Adapt: done → {Path(adapted).name}", "INFO", tab="control")
                        with capture_stdout(self.app.log_queue, "control",
                                           log_file=log_fh, task_label=f"Direction {p.name}",
                                           master_log=mfh):
                            direct_project(str(tr), style, str(p), p.name,
                                          prompts_only=_prompts_only)

                    elif stage == "ImageGen":
                        if settings.get('rewrite_model'):
                            config.REWRITE_MODEL = settings['rewrite_model']
                        # SynthID inflight watermark removal
                        if settings.get('synthid_enabled'):
                            os.environ['VARAGENT_SYNTHID_CLEAN']     = '1'
                            os.environ['VARAGENT_SYNTHID_STRENGTH']  = settings.get('synthid_strength', 'moderate')
                            os.environ['VARAGENT_SYNTHID_VERSION']   = settings.get('synthid_version',  'v1')
                            os.environ['VARAGENT_SYNTHID_SAVE_ORIG'] = '1' if settings.get('synthid_save_orig') else '0'
                            self.app.log(f"  SynthID: enabled  strength={settings.get('synthid_strength')}  version={settings.get('synthid_version')}", tab="control")
                        else:
                            os.environ.pop('VARAGENT_SYNTHID_CLEAN', None)
                        # Inflight: launch watch_i2v*.py BEFORE ImageGen
                        # Engine routing: fastgen_ultra → watch_i2v_flowultra.py, veononstop → watch_i2v.py,
                        # both → запускаем ОБА watcher'а параллельно (как в Pipeline _launch_both_watchers).
                        _inflight_proc = None
                        _inflight_procs_both = []
                        if settings.get('inflight_mode') and 'VideoGen' in stages:
                            _vid_engine_inflight = settings.get('vid_engine', 'veononstop')
                            if _vid_engine_inflight == 'fastgen_ultra':
                                _watch_scripts = [('Flow Ultra', AGENT_DIR / 'watch_i2v_flowultra.py')]
                            elif _vid_engine_inflight == 'both':
                                _watch_scripts = [
                                    ('VeoNonStop', AGENT_DIR / 'watch_i2v.py'),
                                    ('Flow Ultra', AGENT_DIR / 'watch_i2v_flowultra.py'),
                                ]
                            else:
                                _watch_scripts = [('VeoNonStop', AGENT_DIR / 'watch_i2v.py')]
                            _watch_script = _watch_scripts[0][1]  # legacy fallback (single-engine)
                            if _watch_script.exists():
                                _vid_par = settings.get('vid_parallel', config.VEONONSTOP_MAX_PARALLEL)
                                _vid_ar = settings.get('vid_ratio', config.VEONONSTOP_ASPECT_RATIO)
                                if _vid_engine_inflight == 'fastgen_ultra':
                                    _fu_keys = settings.get('fu_keys', 'key1')
                                    if _fu_keys != 'key1':
                                        self.app.log(f"[INFLIGHT] Flow Ultra supports only FastGen Key1; ignoring { _fu_keys }", "WARN", tab="control")
                                    _key_slot_str = '1'
                                else:
                                    _key_slot_str = settings.get('vid_keys', '1')
                                _w_cmd = [sys.executable, str(_watch_script),
                                          '--project', str(p),
                                          '--parallel', str(_vid_par),
                                          '--key-slot', _key_slot_str,
                                          '--aspect', _vid_ar,
                                          '--no-cancel']
                                if settings.get('vid_prompt_mode') == 'single':
                                    _w_cmd.append('--single-prompt')
                                # Vislide interval passes through env → watch picks up via arg flag.
                                # Restore from pipeline_config.json — varagent's own os.environ doesn't
                                # have VARAGENT_VISLIDE_INTERVAL after GUI restart (set only for child
                                # process at first Pipeline Launcher run).
                                _proj_cfg_for_vi = _load_project_config(p)
                                _vi_env = os.environ.get('VARAGENT_VISLIDE_INTERVAL', '0')
                                if _proj_cfg_for_vi.get('clip_mode') == 'vislide':
                                    _vi_env = str(int(_proj_cfg_for_vi.get('vislide_interval', 0) or 0))
                                try:
                                    if int(_vi_env) >= 2:
                                        _w_cmd += ['--vislide-interval', _vi_env]
                                except Exception:
                                    pass
                                # End-image dir (FU only, if user enabled)
                                if (_vid_engine_inflight == 'fastgen_ultra'
                                        and settings.get('fu_end_image')
                                        and settings.get('vid_mode') == 'i2v'):
                                    _w_cmd += ['--end-image-dir', str(p / 'generated')]
                                _w_env = dict(os.environ)
                                _w_env['PYTHONUTF8'] = '1'
                                # Подмешиваем настройки первого запуска проекта (vislide_interval,
                                # intro_block_duration и т.д.) — иначе watch subprocess не знает что был vislide.
                                _inject_project_config_env(_w_env, p)
                                # Stage Finalize выбирает rewriter отдельно — передаём в subprocess
                                # (иначе watch → config.py читает REWRITE_MODEL из .env, игнорируя GUI-выбор)
                                if settings.get('rewrite_model'):
                                    _w_env['REWRITE_MODEL'] = settings['rewrite_model']
                                if settings.get('remix_engine'):
                                    _w_env['REMIX_ENGINE'] = settings['remix_engine']
                                # Запускаем по одному subprocess для каждого watch-скрипта.
                                # При vid_engine='both' — оба watch'a (VeoNonStop + Flow Ultra) идут параллельно.
                                def _spawn_watcher(label, watch_script):
                                    if not watch_script.exists():
                                        self.app.log(f"[INFLIGHT-{label}] {watch_script.name} not found — skipped", "WARN", tab="control")
                                        return None
                                    # Каждый subprocess получает свой -w_cmd с правильным path к скрипту
                                    _wc = list(_w_cmd)
                                    _wc[1] = str(watch_script)
                                    try:
                                        _proc = subprocess.Popen(
                                            _wc, cwd=str(AGENT_DIR), env=_w_env,
                                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                            bufsize=1, text=True, encoding='utf-8', errors='replace')
                                        self._track_subprocess(_proc)
                                        # Stream
                                        def _stream():
                                            try:
                                                for line in _proc.stdout:
                                                    line = line.rstrip('\n\r')
                                                    if line:
                                                        self.app.log(f"[INFLIGHT-{label}] {line}", tab="control")
                                                        if log_fh:
                                                            try:
                                                                log_fh.write(f"[INFLIGHT-{label}] {line}\n")
                                                                log_fh.flush()
                                                            except Exception:
                                                                pass
                                            finally:
                                                try: _proc.wait(timeout=0)
                                                except Exception: pass
                                                self._untrack_subprocess(_proc)
                                        threading.Thread(target=_stream, daemon=True).start()
                                        self.app.log(f"[INFLIGHT-{label}] {watch_script.name} started (parallel={_vid_par})",
                                                     "INFO", tab="control")
                                        return _proc
                                    except Exception as _ie:
                                        self.app.log(f"[INFLIGHT-{label}] Failed to start: {_ie}", "WARN", tab="control")
                                        return None

                                for _wlabel, _wscript in _watch_scripts:
                                    _p = _spawn_watcher(_wlabel, _wscript)
                                    if _p is not None:
                                        _inflight_procs_both.append(_p)
                                # Legacy: первый watcher хранится как _inflight_proc для совместимости
                                _inflight_proc = _inflight_procs_both[0] if _inflight_procs_both else None

                        if settings['engine'] == 'fastgen':
                            from modules.fastgen import generate_all_images, _flowultra_shutdown_event
                            _flowultra_shutdown_event.clear()  # reset after prior Hard Stop
                            _fg_keys = settings.get('fg_keys', 'key1')
                            if _fg_keys == 'key2':
                                _fg_api_key = (getattr(config, 'FASTGEN_API_KEY_2', '') or
                                               getattr(config, 'FASTGEN_API_KEY_BACKUP', '') or
                                               getattr(config, 'FASTGEN_API_KEY', None))
                                _fg_dual = False
                            elif _fg_keys == 'key3':
                                _fg_api_key = getattr(config, 'FASTGEN_API_KEY_3', '') or getattr(config, 'FASTGEN_API_KEY', None)
                                _fg_dual = False
                            elif _fg_keys == 'key4':
                                _fg_api_key = getattr(config, 'FASTGEN_API_KEY_4', '') or getattr(config, 'FASTGEN_API_KEY', None)
                                _fg_dual = False
                            elif _fg_keys in ('both', 'all'):
                                _fg_api_key = getattr(config, 'FASTGEN_API_KEY', None)
                                _fg_dual = True
                            else:  # key1
                                _fg_api_key = getattr(config, 'FASTGEN_API_KEY', None)
                                _fg_dual = False
                            with capture_stdout(self.app.log_queue, "control",
                                               log_file=log_fh, task_label=f"ImageGen {p.name}",
                                               master_log=mfh):
                                generate_all_images(
                                    str(p),
                                    api_key=_fg_api_key,
                                    max_parallel=settings['fg_parallel'],
                                    model=settings['fg_model'],
                                    aspect_ratio=settings.get('fg_aspect', config.FASTGEN_ASPECT_RATIO),
                                    dual_key=_fg_dual,
                                    preflight=not settings.get('skip_preflight', False),
                                    silent=True,
                                )
                        else:
                            from modules.imggen import generate_all_images as veo_gen
                            config.VEONONSTOP_BANANA_MODEL = settings.get('veo_model', 'GEM_PIX_2')
                            _ig_active = _veo_sel_to_active(settings.get('veo_imgkeys', 'key1'))
                            # Copy img refs to project/ref/ for banana_ref
                            if settings['veo_mode'] == 'banana_ref':
                                _iref_files = settings.get('img_ref_files', [])
                                if _iref_files:
                                    _ird = p / 'ref'
                                    _ird.mkdir(exist_ok=True)
                                    import shutil as _sh2
                                    _copied_refs = 0
                                    for _irf in _iref_files:
                                        _dst = str(_ird / Path(_irf).name)
                                        if Path(_irf).resolve() != Path(_dst).resolve():
                                            _sh2.copy(str(_irf), _dst)
                                            _copied_refs += 1
                                    if _copied_refs:
                                        self.app.log(f"Copied {_copied_refs} img refs → ref/", tab="control")
                            with capture_stdout(self.app.log_queue, "control",
                                               log_file=log_fh, task_label=f"ImageGen {p.name}",
                                               master_log=mfh):
                                _UPS_MAP = {'2k': 'UPSAMPLE_IMAGE_RESOLUTION_2K', '4k': 'UPSAMPLE_IMAGE_RESOLUTION_4K'}
                                _ups_res = _UPS_MAP.get(settings.get('img_upscale', 'off').lower())
                                veo_gen(str(p), mode=settings['veo_mode'],
                                        aspect_ratio=settings['veo_ratio'],
                                        max_parallel=settings['veo_parallel'],
                                        active_keys=_ig_active,
                                        upscale_resolution=_ups_res,
                                        preflight=not settings.get('skip_preflight', False),
                                        silent=True)

                        # Inflight: wait for watch_i2v to finish
                        if _inflight_proc is not None:
                            self.app.log("[INFLIGHT] ImageGen done, waiting for watch_i2v...",
                                         "INFO", tab="control")
                            _inflight_proc.wait()
                            self.app.log("[INFLIGHT] watch_i2v done → vid_img/", "INFO", tab="control")

                    elif stage == "VideoGen":
                        # === Engine-agnostic config overrides ===
                        # ВСЕ через `if 'key' in settings` — чтобы даже falsy значения ('off', 0, '')
                        # применялись. Иначе config.VAR залипает из предыдущего запуска / .env.
                        # Эти переменные используются И VeoNonStop, И Flow Ultra цепочкой
                        # (_process_single_clip / _process_single_clip_fu).
                        if 'rewrite_model' in settings:
                            config.REWRITE_MODEL = settings['rewrite_model']
                        if 'fast_censor' in settings:
                            config.VEONONSTOP_FAST_CENSOR = settings['fast_censor']
                        if 'remix_engine' in settings:
                            config.REMIX_ENGINE = settings['remix_engine']
                        if 'vid_max_retries' in settings:
                            config.VEONONSTOP_MAX_RETRIES = int(settings['vid_max_retries'])
                        if 'vid_max_cycles' in settings:
                            config.VEONONSTOP_MAX_SILENT_CYCLES = int(settings['vid_max_cycles'])
                        if 'vid_request_delay' in settings:
                            config.VEONONSTOP_REQUEST_DELAY = float(settings['vid_request_delay'])
                        if 'vid_recaptcha_delay' in settings:
                            config.VEONONSTOP_RECAPTCHA_DELAY = float(settings['vid_recaptcha_delay'])
                        if 'vid_recaptcha_jitter' in settings:
                            config.VEONONSTOP_RECAPTCHA_JITTER = float(settings['vid_recaptcha_jitter'])
                        # Skip preflight — общий env var для обеих engine веток
                        # (VeoNonStop использует для components ref preflight; FU сейчас no-op)
                        if settings.get('skip_preflight'):
                            os.environ['VARAGENT_SKIP_PREFLIGHT'] = '1'
                        else:
                            os.environ.pop('VARAGENT_SKIP_PREFLIGHT', None)
                        # Story Mode (chain extends) — Finalize runs in-process,
                        # обновляем И config.* (для модулей которые читают config),
                        # И os.environ (для подпроцессов inflight watchers)
                        if 'story_mode' in settings:
                            config.STORY_MODE = settings['story_mode']
                            os.environ['STORY_MODE'] = settings['story_mode']
                        # Chain Mode params — пробрасываем во все читатели
                        if 'chain_imggen_heads_only' in settings:
                            _v = bool(settings['chain_imggen_heads_only'])
                            config.CHAIN_IMGGEN_HEADS_ONLY = _v
                            os.environ['CHAIN_IMGGEN_HEADS_ONLY'] = '1' if _v else '0'
                        if 'chain_max_chain' in settings:
                            _v = int(settings['chain_max_chain'])
                            config.VIDEO_EXTEND_MAX_CHAIN = _v
                            os.environ['VIDEO_EXTEND_MAX_CHAIN'] = str(_v)
                        if 'chain_cascade_recovery' in settings:
                            _v = bool(settings['chain_cascade_recovery'])
                            config.CHAIN_CASCADE_RECOVERY = _v
                            os.environ['CHAIN_CASCADE_RECOVERY'] = '1' if _v else '0'
                        if 'chain_max_fails' in settings:
                            _v = int(settings['chain_max_fails'])
                            config.CHAIN_MAX_SAME_CLIP_FAILS = _v
                            os.environ['CHAIN_MAX_SAME_CLIP_FAILS'] = str(_v)
                        if 'chain_frame_offset' in settings:
                            _v = float(settings['chain_frame_offset'])
                            config.VIDEO_EXTEND_FRAME_OFFSET = _v
                            os.environ['VIDEO_EXTEND_FRAME_OFFSET'] = str(_v)
                        if 'chain_trim_frames' in settings:
                            _v = int(settings['chain_trim_frames'])
                            config.VIDEO_EXTEND_TRIM_FRAMES = _v
                            os.environ['VIDEO_EXTEND_TRIM_FRAMES'] = str(_v)
                        if 'chain_mute_audio' in settings:
                            _v = bool(settings['chain_mute_audio'])
                            config.VIDEO_EXTEND_MUTE_AUDIO = _v
                            os.environ['VIDEO_EXTEND_MUTE_AUDIO'] = '1' if _v else '0'
                        # Codex-adapt: если чекбокс включён, режим i2v/keyframes и нет user override
                        # и нет готового *_veo_adapt_*.txt → запустить adapt_prompts_for_veo синхронно
                        _wants_adapt = (settings.get('codex_adapt')
                                        and settings.get('vid_mode') == 'i2v'
                                        and not settings.get('veo_adapt_path'))
                        if _wants_adapt:
                            _existing_adapt = sorted(p.glob('*_veo_adapt_*.txt'),
                                                      key=lambda f: f.stat().st_mtime)
                            if not _existing_adapt:
                                self.app.log("  [codex-adapt] No *_veo_adapt_*.txt — running adapter...",
                                             "INFO", tab="control")
                                try:
                                    import sys as _sys
                                    _agent_dir = str(AGENT_DIR)
                                    if _agent_dir not in _sys.path:
                                        _sys.path.insert(0, _agent_dir)
                                    from modules.codex_adapt import adapt_prompts_for_veo
                                    with capture_stdout(self.app.log_queue, "control",
                                                        log_file=log_fh,
                                                        task_label=f"codex-adapt {p.name}",
                                                        master_log=mfh):
                                        _adapted = adapt_prompts_for_veo(str(p))
                                    if _adapted:
                                        self.app.log(f"  [codex-adapt] Done: {Path(_adapted).name}",
                                                     "SUCCESS", tab="control")
                                    else:
                                        self.app.log("  [codex-adapt] Returned empty — using original prompts",
                                                     "WARNING", tab="control")
                                except Exception as _ce:
                                    self.app.log(f"  [codex-adapt] Failed: {_ce} — continuing with original prompts",
                                                 "WARNING", tab="control")
                            else:
                                self.app.log(f"  [codex-adapt] Using existing: {_existing_adapt[-1].name}",
                                             "INFO", tab="control")
                        # Skip VideoGen if inflight already handled it
                        if settings.get('inflight_mode') and 'ImageGen' in stages:
                            self.app.log("[INFLIGHT] VideoGen skipped — already done by watch_i2v",
                                         "INFO", tab="control")
                            _close_logs(log_fh, mfh, time.time() - t_stage)
                            continue

                        # ── 'both' (без inflight): два engine параллельно через ThreadPoolExecutor.
                        # video_claims внутри veo_video.py и flowultra.py обеспечат разделение клипов:
                        # каждый клип возьмёт тот engine который первый создал .NNN.claim.
                        if settings.get('vid_engine') == 'both':
                            from concurrent.futures import ThreadPoolExecutor as _BothPool
                            self.app.log("[BOTH] Starting VeoNonStop + Flow Ultra in parallel (claims will split clips)",
                                         "INFO", tab="control")

                            def _run_both_veo():
                                try:
                                    from modules.veo_video import generate_all_videos as _veo_gen
                                    _veo_active = _veo_sel_to_active(settings.get('vid_keys', 'key1'))
                                    _veo_sp = None
                                    if settings.get('vid_prompt_mode') == 'single':
                                        _spf = p / 'single_prompt.txt'
                                        if _spf.exists():
                                            _veo_sp = _spf.read_text(encoding='utf-8').strip() or None
                                    with capture_stdout(self.app.log_queue, "control",
                                                       log_file=log_fh, task_label=f"VideoGen-VEO {p.name}",
                                                       master_log=mfh):
                                        return _veo_gen(
                                            str(p),
                                            mode=settings['vid_mode'],
                                            max_parallel=settings['vid_parallel'],
                                            aspect_ratio=settings['vid_ratio'],
                                            active_keys=_veo_active,
                                            single_prompt=_veo_sp,
                                            upscale_video=settings.get('vid_upscale', False),
                                            silent=True,
                                        )
                                except Exception as _ee:
                                    self.app.log(f"[BOTH-VEO] failed: {_ee}", "ERROR", tab="control")
                                    return None

                            def _run_both_fu():
                                try:
                                    from modules.flowultra import (
                                        generate_all_videos_flow_ultra as _fu_gen,
                                        _flowultra_shutdown_event as _fu_stop_evt,
                                    )
                                    self._clear_flowultra_stop()
                                    _fu_mode_map_b = {'i2v': 'keyframes', 't2v': 't2v', 'components': 'ingredients'}
                                    _fu_mode_b = _fu_mode_map_b.get(settings['vid_mode'], settings['vid_mode'])
                                    _fu_api_b = getattr(config, 'FASTGEN_API_KEY', None)
                                    _fu_sp = None
                                    if settings.get('vid_prompt_mode') == 'single':
                                        _spf = p / 'single_prompt.txt'
                                        if _spf.exists():
                                            _fu_sp = _spf.read_text(encoding='utf-8').strip() or None
                                    with capture_stdout(self.app.log_queue, "control",
                                                       log_file=log_fh, task_label=f"VideoGen-FU {p.name}",
                                                       master_log=mfh):
                                        return _fu_gen(
                                            project_dir=str(p),
                                            mode=_fu_mode_b,
                                            max_parallel=settings['vid_parallel'],
                                            aspect_ratio=settings['vid_ratio'],
                                            api_key=_fu_api_b,
                                            single_prompt=_fu_sp,
                                            silent=True,
                                        )
                                except Exception as _ee:
                                    self.app.log(f"[BOTH-FU] failed: {_ee}", "ERROR", tab="control")
                                    return None

                            with _BothPool(max_workers=2) as _bp:
                                _f_veo = _bp.submit(_run_both_veo)
                                _f_fu = _bp.submit(_run_both_fu)
                                _r_veo = _f_veo.result()
                                _r_fu = _f_fu.result()
                            self.app.log(f"[BOTH] VeoNonStop done: {_r_veo}", "INFO", tab="control")
                            self.app.log(f"[BOTH] Flow Ultra done: {_r_fu}", "INFO", tab="control")
                            _close_logs(log_fh, mfh, time.time() - t_stage)
                            continue

                        # ── FastGen Flow Ultra path ──
                        if settings.get('vid_engine') == 'fastgen_ultra':
                            from modules.flowultra import (
                                generate_all_videos_flow_ultra,
                                _flowultra_shutdown_event as _fu_stop,
                            )
                            self._clear_flowultra_stop()
                            # Mode mapping: user sees i2v/t2v/components, Flow Ultra uses keyframes/t2v/ingredients
                            _fu_mode_map = {
                                'i2v': 'keyframes',
                                't2v': 't2v',
                                'components': 'ingredients',
                            }
                            _fu_mode = _fu_mode_map.get(settings['vid_mode'], settings['vid_mode'])
                            # Key routing
                            _fu_keys = settings.get('fu_keys', 'key1')
                            if _fu_keys != 'key1':
                                self.app.log(f"Flow Ultra supports only FastGen Key1; ignoring { _fu_keys }", "WARN", tab="control")
                            _fu_api = getattr(config, 'FASTGEN_API_KEY', None)
                            _fu_dual = False
                            # single_prompt
                            _sp = None
                            if settings.get('vid_prompt_mode') == 'single':
                                _sp_file = p / 'single_prompt.txt'
                                if _sp_file.exists():
                                    _sp = _sp_file.read_text(encoding='utf-8').strip() or None
                            # Vislide filter
                            _vislide_cids = None
                            _vi = int(os.environ.get('VARAGENT_VISLIDE_INTERVAL', '0'))
                            if _vi >= 2:
                                try:
                                    import json as _json
                                    _mp = p / 'montage_plan.json'
                                    if _mp.exists():
                                        _md = _json.loads(_mp.read_text(encoding='utf-8'))
                                        _plan = _md.get('montage_plan', _md)
                                        _clips = _plan.get('clips', [])
                                        _animated = set()
                                        _all_ids = [c['id'] for c in _clips]
                                        for _ii, _cid in enumerate(_all_ids):
                                            if (_ii + 1) % _vi == 0:
                                                _animated.add(_cid)
                                        _intro_dur = config.INTRO_BLOCK_DURATION
                                        if _intro_dur > 0:
                                            for _c in _clips:
                                                if _c.get('startTime', 0) < _intro_dur:
                                                    _animated.add(_c['id'])
                                        _vislide_cids = sorted(_animated)
                                except Exception:
                                    pass
                            # ref_dir (для ingredients) — из settings['vid_ref_files'] или project/ref/
                            _ref_dir_fu = None
                            if _fu_mode == 'ingredients':
                                _ref_files = settings.get('vid_ref_files', [])
                                if _ref_files:
                                    _rd = p / 'ref'
                                    _rd.mkdir(exist_ok=True)
                                    import shutil as _sh_fu
                                    for _rf in _ref_files:
                                        _vdst = str(_rd / Path(_rf).name)
                                        if Path(_rf).resolve() != Path(_vdst).resolve():
                                            _sh_fu.copy(str(_rf), _vdst)
                                _ref_dir_fu = str(p / 'ref')
                            # End-image dir (keyframes pair mode, opt-in via GUI checkbox)
                            _fu_end_dir = None
                            if (_fu_mode == 'keyframes' and settings.get('fu_end_image')):
                                _fu_end_dir = str(p / 'generated')
                            # VEO adapt override (Browse path) or auto-detect
                            _fu_prompts_override = None
                            _fu_user_adapt = settings.get('veo_adapt_path')
                            if _fu_user_adapt and Path(_fu_user_adapt).exists():
                                _fu_prompts_override = _fu_user_adapt
                                self.app.log(f"  Using VEO adapt prompts (user override): {Path(_fu_user_adapt).name}",
                                             "INFO", tab="control")
                            with capture_stdout(self.app.log_queue, "control",
                                               log_file=log_fh,
                                               task_label=f"VideoGen (Flow Ultra) {p.name}",
                                               master_log=mfh):
                                _vg_result = generate_all_videos_flow_ultra(
                                    project_dir=str(p),
                                    mode=_fu_mode,
                                    max_parallel=settings['vid_parallel'],
                                    aspect_ratio=settings['vid_ratio'],
                                    api_key=_fu_api,
                                    dual_key=_fu_dual,
                                    single_prompt=_sp,
                                    clip_ids=_vislide_cids,
                                    ref_dir=_ref_dir_fu,
                                    end_image_dir=_fu_end_dir,
                                    prompts_file_path=_fu_prompts_override,
                                    silent=True,
                                )
                            _vg_ok = _vg_result.get('generated', 0)
                            _vg_fail = _vg_result.get('failed', 0)
                            if _vg_ok == 0:
                                raise RuntimeError(
                                    f"VideoGen (Flow Ultra) produced 0 clips ({_vg_fail} failed).")
                            _close_logs(log_fh, mfh, time.time() - t_stage)
                            continue
                        # ── existing VeoNonStop path ──
                        # fast_censor + skip_preflight применяются в ОБЩЕЙ секции выше
                        # (до routing Flow Ultra / VeoNonStop). Здесь дубликат НЕ нужен.
                        from modules.veo_video import generate_all_videos
                        _vid_active = _veo_sel_to_active(settings.get('vid_keys', 'key1'))
                        _sp = None
                        if settings.get('vid_prompt_mode') == 'single':
                            _sp_file = p / 'single_prompt.txt'
                            if _sp_file.exists():
                                _sp = _sp_file.read_text(encoding='utf-8').strip() or None
                            else:
                                self.app.log("single_prompt.txt not found — using per-clip", "WARN", tab="control")
                        # Vislide: фильтрация clip_ids
                        _vislide_cids = None
                        _vi = int(os.environ.get('VARAGENT_VISLIDE_INTERVAL', '0'))
                        if _vi >= 2:
                            try:
                                import json as _json
                                _mp = p / 'montage_plan.json'
                                if _mp.exists():
                                    _md = _json.loads(_mp.read_text(encoding='utf-8'))
                                    _plan = _md.get('montage_plan', _md)
                                    _clips = _plan.get('clips', [])
                                    _animated = set()
                                    _all_ids = [c['id'] for c in _clips]
                                    for _ii, _cid in enumerate(_all_ids):
                                        if (_ii + 1) % _vi == 0:
                                            _animated.add(_cid)
                                    _intro_dur = config.INTRO_BLOCK_DURATION
                                    if _intro_dur > 0:
                                        for _c in _clips:
                                            if _c.get('startTime', 0) < _intro_dur:
                                                _animated.add(_c['id'])
                                    _vislide_cids = sorted(_animated)
                                    self.app.log(f"Vislide: {len(_vislide_cids)}/{len(_clips)} clips → i2v", tab="control")
                            except Exception as _ve:
                                self.app.log(f"Vislide filter error: {_ve}", "WARN", tab="control")
                        # Components: copy ref files to project/ref/ BEFORE capture_stdout
                        _ref_dir = None
                        if settings['vid_mode'] == 'components':
                            _ref_files = settings.get('vid_ref_files', [])
                            _rd = p / 'ref'
                            if _ref_files:
                                _rd.mkdir(exist_ok=True)
                                import shutil as _sh
                                _copied_vrefs = 0
                                for _rf in _ref_files:
                                    _vdst = str(_rd / Path(_rf).name)
                                    if Path(_rf).resolve() != Path(_vdst).resolve():
                                        _sh.copy(str(_rf), _vdst)
                                        _copied_vrefs += 1
                                if _copied_vrefs:
                                    self.app.log(f"Copied {_copied_vrefs} ref images → ref/", tab="control")
                            _ref_dir = str(_rd)
                        # Prompts source priority:
                        #   1. Explicit Browse override (settings['veo_adapt_path']) — user picked a specific file
                        #   2. Auto-detect *_veo_adapt_*.txt in project dir (if codex_adapt checkbox set OR adapt file exists)
                        #   3. Fallback to *_prompts_*.txt (default, handled by generate_all_videos internally)
                        _vg_prompts_override = None
                        _user_adapt_path = settings.get('veo_adapt_path')
                        if _user_adapt_path and Path(_user_adapt_path).exists():
                            _vg_prompts_override = _user_adapt_path
                            self.app.log(f"  Using VEO adapt prompts (user override): {Path(_user_adapt_path).name}",
                                         "INFO", tab="control")
                        else:
                            _veo_adapt_candidates = sorted(p.glob('*_veo_adapt_*.txt'), key=lambda f: f.stat().st_mtime)
                            if _veo_adapt_candidates:
                                _vg_prompts_override = str(_veo_adapt_candidates[-1])
                                self.app.log(f"  Using veo_adapt prompts (auto): {_veo_adapt_candidates[-1].name}",
                                             "INFO", tab="control")
                        with capture_stdout(self.app.log_queue, "control",
                                           log_file=log_fh, task_label=f"VideoGen {p.name}",
                                           master_log=mfh):
                            _vg_result = generate_all_videos(
                                str(p),
                                mode=settings['vid_mode'],
                                max_parallel=settings['vid_parallel'],
                                aspect_ratio=settings['vid_ratio'],
                                active_keys=_vid_active,
                                single_prompt=_sp,
                                clip_ids=_vislide_cids,
                                ref_dir=_ref_dir,
                                upscale_video=settings.get('vid_upscale', False),
                                prompts_file_path=_vg_prompts_override,
                                silent=True,
                            )
                        _vg_ok = _vg_result.get('generated', 0) if isinstance(_vg_result, dict) else 0
                        _vg_fail = _vg_result.get('failed', 0) if isinstance(_vg_result, dict) else 0
                        if _vg_ok == 0:
                            raise RuntimeError(f"VideoGen produced 0 clips ({_vg_fail} failed). Cannot proceed.")
                        if _vg_fail > 0:
                            # Find missing clips in vid_img/
                            _vid_dir_check = p / 'vid_img'
                            _gen_dir_check = p / 'generated'
                            _mp_path = p / 'montage_plan.json'
                            _missing_ids = []
                            if _mp_path.exists():
                                import json as _json2
                                _mp_data = _json2.loads(_mp_path.read_text(encoding='utf-8'))
                                _plan = _mp_data.get('montage_plan', _mp_data)
                                for _c in _plan.get('clips', []):
                                    _cid = _c['id']
                                    if _vislide_cids and _cid not in set(_vislide_cids):
                                        continue
                                    if not any((_vid_dir_check / f"{_cid:03d}{_e}").exists()
                                               for _e in ('.mp4', '.png', '.jpg', '.jpeg', '.webp')):
                                        _missing_ids.append(_cid)
                            if _missing_ids:
                                self.app.log(f"VideoGen: {len(_missing_ids)} clips missing, retrying...",
                                             "WARN", tab="control")
                                # Retry missing clips
                                try:
                                    with capture_stdout(self.app.log_queue, "control",
                                                       log_file=log_fh, task_label=f"VideoGen retry {p.name}",
                                                       master_log=mfh):
                                        generate_all_videos(
                                            str(p), mode=settings['vid_mode'],
                                            max_parallel=settings['vid_parallel'],
                                            aspect_ratio=settings['vid_ratio'],
                                            active_keys=_vid_active,
                                            single_prompt=_sp,
                                            clip_ids=_missing_ids,
                                            upscale_video=settings.get('vid_upscale', False),
                                            silent=True,
                                        )
                                except Exception as _retry_e:
                                    self.app.log(f"VideoGen retry failed: {_retry_e}", "WARN", tab="control")

                                # Static fallback for anything still missing
                                _still_missing = []
                                for _cid in _missing_ids:
                                    if any((_vid_dir_check / f"{_cid:03d}{_e}").exists()
                                           for _e in ('.mp4', '.png', '.jpg', '.jpeg', '.webp')):
                                        continue
                                    # Copy static image from generated/
                                    _found = False
                                    for _ext in ('.png', '.jpg', '.jpeg', '.webp'):
                                        _src_img = _gen_dir_check / f"{_cid:03d}{_ext}"
                                        if _src_img.exists():
                                            import shutil as _sh3
                                            _vid_dir_check.mkdir(exist_ok=True)
                                            _sh3.copy(str(_src_img), str(_vid_dir_check / f"{_cid:03d}{_ext}"))
                                            _found = True
                                            break
                                    if not _found:
                                        _still_missing.append(_cid)
                                if _still_missing:
                                    self.app.log(f"WARNING: {len(_still_missing)} clips have no video or image: {_still_missing[:20]}",
                                                 "WARN", tab="control")
                                elif _missing_ids:
                                    _recovered = len(_missing_ids) - len(_still_missing)
                                    self.app.log(f"Recovered {_recovered} missing clips (retry + static fallback)",
                                                 "INFO", tab="control")
                        # Vislide: copy static fallback for non-animated clips
                        if _vislide_cids:
                            import shutil as _shutil
                            _gen_dir = p / 'generated'
                            _vid_dir = p / 'vid_img'
                            _vid_dir.mkdir(exist_ok=True)
                            _all_ids = [c['id'] for c in _clips] if '_clips' in dir() else []
                            _anim_set = set(_vislide_cids)
                            _copied = 0
                            for _cid in _all_ids:
                                if _cid in _anim_set or (_vid_dir / f"{_cid:03d}.mp4").exists():
                                    continue
                                for _ext in ('.png', '.jpg', '.jpeg', '.webp'):
                                    _src = _gen_dir / f"{_cid:03d}{_ext}"
                                    if _src.exists():
                                        _shutil.copy(str(_src), str(_vid_dir / f"{_cid:03d}{_ext}"))
                                        _copied += 1
                                        break
                            if _copied:
                                self.app.log(f"Vislide static fallback: {_copied} images → vid_img/", tab="control")

                    elif stage == "Concat":
                        _wait_for_concat_readiness(
                            p,
                            lambda msg, lvl='INFO': self.app.log(msg, lvl, tab="control"),
                            cancel_cb=lambda: self._ensure_hard_stop_event().is_set(),
                        )
                        cmd = [sys.executable, str(SCRIPT_DIR / 'video_concat.py'),
                               'montage_plan.json', '-o', f'{p.name}.mp4',
                               '-b', settings['bitrate'], '--force-amd',
                               '--fps', str(settings.get('fps', 60))]
                        if settings['quality'] == '1080p':
                            cmd.extend(['-r', '1080'])
                        elif settings['quality'] == '4K':
                            cmd.extend(['-r', '4k'])
                        if settings['keep_veo_sound']:
                            cmd.append('--veo-audio-inline')
                        if settings.get('subtitles_path'):
                            cmd.extend(['--subtitles', settings['subtitles_path']])
                        if settings.get('keep_files'):
                            cmd.append('--no-cleanup')
                        # Watermark: blur borders / custom logo. 'as_is' = video_concat.py
                        # still auto-detects project/logo.png если есть.
                        _wm = settings.get('watermark', 'as_is')
                        if _wm == 'blur':
                            cmd.append('--blur-borders')
                        elif _wm == 'logo':
                            _logo = settings.get('logo_path', '').strip()
                            if _logo and Path(_logo).exists():
                                cmd.extend(['--logo', _logo])
                                self.app.log(f"  Using custom logo: {Path(_logo).name}",
                                             "INFO", tab="control")
                            # else: auto-detect logo.png in project dir (video_concat.py handles it)
                        _env = {**os.environ, 'PYTHONIOENCODING': 'utf-8'}
                        proc = subprocess.Popen(
                            cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            stdin=subprocess.DEVNULL,
                            text=True, encoding='utf-8', errors='replace',
                            cwd=str(p), env=_env
                        )
                        self._track_subprocess(proc)
                        try:
                            for line in proc.stdout:
                                line = line.rstrip()
                                if not line:
                                    continue
                                low = line.lower()
                                level = 'ERROR' if (any(x in low for x in ['error', 'fail', 'traceback'])
                                        and not _is_false_error_signal(line)) else 'INFO'
                                self.app.log(line, level, tab="control")
                                log_fh.write(line + '\n')
                                mfh.write(line + '\n')
                        except OSError:
                            pass  # pipe closed after terminate()
                        finally:
                            self._untrack_subprocess(proc)
                        if proc.wait() != 0:
                            raise RuntimeError(f"Concat failed (exit {proc.returncode})")

                    elif stage == "YT Pack":
                        from modules.yt_packer import run_yt_packer
                        config.YT_PACK_CONTENT_MODEL   = settings.get('yt_content_model', getattr(config, 'YT_PACK_CONTENT_MODEL', ''))
                        config.YT_PACK_TRANSLATE_MODEL = settings.get('yt_translate_model', getattr(config, 'YT_PACK_TRANSLATE_MODEL', ''))
                        # Также устанавливаем os.environ для динамического чтения в yt_packer
                        os.environ['YT_PACK_CONTENT_MODEL']   = config.YT_PACK_CONTENT_MODEL
                        os.environ['YT_PACK_TRANSLATE_MODEL'] = config.YT_PACK_TRANSLATE_MODEL
                        config.YT_PACK_LANGUAGES   = [l.strip() for l in settings['yt_langs'].split(',') if l.strip()]
                        config.YT_PACK_SUBTITLES   = settings['yt_subs']
                        config.YT_PACK_DESCRIPTION = settings['yt_desc']
                        config.YT_PACK_COVERS      = settings['yt_covers']
                        with capture_stdout(self.app.log_queue, "control",
                                           log_file=log_fh, task_label=f"YT Pack {p.name}",
                                           master_log=mfh):
                            run_yt_packer(str(p))

                    elapsed_stage = time.time() - t_stage
                    _close_logs(log_fh, mfh, elapsed_stage)
                    m, s = divmod(int(elapsed_stage), 60)
                    self.app.log(f"Stage {stage}: done ({m}m {s}s)", "SUCCESS", tab="control")

                except Exception:
                    _close_logs(log_fh, mfh, time.time() - t_stage)
                    raise

            elapsed_total = time.time() - t_start
            m, s = divmod(int(elapsed_total), 60)
            self.app.log(f"Finalize complete: {p.name} ({m}m {s}s)", "SUCCESS", tab="control")
            with open(master_path, 'a', encoding='utf-8') as f:
                f.write(f"\n=== FINALIZE DONE: {m}m {s}s ===\n")

        except Exception as e:
            elapsed_total = time.time() - t_start
            m, s = divmod(int(elapsed_total), 60)
            self.app.log(
                f"Finalize FAILED at '{_current_stage}' ({m}m {s}s): {e}",
                "ERROR", tab="control"
            )
            try:
                with open(master_path, 'a', encoding='utf-8') as f:
                    f.write(f"\n=== FINALIZE ERROR at '{_current_stage}': {e} ===\n")
            except Exception:
                pass
        finally:
            self.active_tasks = max(0, self.active_tasks - 1)
            self.root.after(0, self._update_status)
            self.root.after(0, self.refresh_projects)

    def _run_dryrun(self):
        self._run_subprocess_in_thread(
            ['python', str(AGENT_DIR / 'agent.py'), 'dry-run'],
            task_name="Dry-Run")

    def _run_mock(self):
        self._run_subprocess_in_thread(
            ['python', str(AGENT_DIR / 'agent.py'), 'dry-run', '--mock'],
            task_name="Mock Run")

    def _toggle_chain_settings_fin(self):
        """Показать/скрыть chain settings в Finalize panel в зависимости от режима."""
        if self._fin_story_mode.get() == 'chain':
            self._chain_fin_frame.pack(fill=tk.X, pady=(4, 0))
        else:
            self._chain_fin_frame.pack_forget()


# ════════════════════════════════════════════════════════════════════
# TAB: PROMPTS EDITOR
# ════════════════════════════════════════════════════════════════════

_PROMPT_FILES = [
    ("Director Instruction (pass 2)",   AGENT_DIR / "prompts" / "director_instruction.txt"),
    ("Director Instruction (pass 1)",   AGENT_DIR / "prompts" / "director_instruction_pass1.txt"),
    ("Director Pause Guide",            AGENT_DIR / "prompts" / "director_pause_guide.txt"),
    ("Script Director — Prose",         AGENT_DIR / "prompts" / "script_director_prose.txt"),
    ("Script Director — Screenplay",    AGENT_DIR / "prompts" / "script_director_screenplay.txt"),
    ("Rewrite Prompt (censorship)",     AGENT_DIR / "prompts" / "rewrite_prompt.txt"),
    ("Ref Remix (Grok)",                AGENT_DIR / "prompts" / "ref_remix_prompt.txt"),
    ("i2v Remix (Grok)",                AGENT_DIR / "prompts" / "i2v_remix_prompt.txt"),
    ("YT Packer Prompt",                AGENT_DIR / "prompts" / "yt_packer_prompt.txt"),
    ("VEO Adapt Prompt (GPT)",          AGENT_DIR / "prompts" / "veo_adapt_prompt.txt"),
    ("SG Adapt Prompt (GPT)",           AGENT_DIR / "prompts" / "sg_adapt_prompt.txt"),
    ("VEO i2v Universal Style Guide",   SCRIPT_DIR / "prompts_other" / "VEO_I2V_UNIVERSAL_STYLE_v1.md"),
    ("Subtitle Template 720p (.ass)",   AGENT_DIR / "templates" / "subtitles_720p.ass"),
    ("Subtitle Template 1080p (.ass)",  AGENT_DIR / "templates" / "subtitles_1080p.ass"),
    ("Subtitle Center 720p (.ass)",     AGENT_DIR / "templates" / "subtitles_720p_center.ass"),
    ("Subtitle Center 1080p (.ass)",    AGENT_DIR / "templates" / "subtitles_1080p_center.ass"),
]


class PromptsTab:
    """Prompt files editor — view and edit all agent prompt files."""

    def __init__(self, notebook, app: VarAgentGUI):
        self.app = app
        self.frame = ttk.Frame(notebook)
        self._current_path: Optional[Path] = None
        self._modified = False
        self.create_ui()

    def create_ui(self):
        # Top bar
        top = ttk.Frame(self.frame)
        top.pack(fill=tk.X, padx=10, pady=(8, 0))
        self.save_btn = ttk.Button(top, text="Save", command=self._save,
                                   style="Accent.TButton")
        self.save_btn.pack(side=tk.LEFT, padx=(0, 4))
        ttk.Button(top, text="Reload", command=self._reload).pack(side=tk.LEFT, padx=4)
        ttk.Button(top, text="Open Folder", command=self._open_folder).pack(side=tk.LEFT, padx=4)
        self.status_lbl = ttk.Label(top, text="", style="Dim.TLabel")
        self.status_lbl.pack(side=tk.LEFT, padx=10)
        self.file_lbl = ttk.Label(top, text="", style="Dim.TLabel")
        self.file_lbl.pack(side=tk.RIGHT, padx=4)

        # Body: left list + right editor
        body = ttk.Frame(self.frame)
        body.pack(fill=tk.BOTH, expand=True, padx=10, pady=6)

        # Left: prompt file list
        left = ttk.Frame(body, style="Card.TFrame")
        left.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 6))
        ttk.Label(left, text="Prompts", style="Section.TLabel").pack(anchor=tk.W, padx=10, pady=(8, 4))
        self.listbox = tk.Listbox(left, width=28, bg=COLORS['bg_card'], fg=COLORS['text'],
                                   font=FONT_DIM, selectbackground=COLORS['accent'],
                                   selectforeground='#ffffff', relief=tk.FLAT,
                                   borderwidth=0, activestyle='none')
        for label, _ in _PROMPT_FILES:
            self.listbox.insert(tk.END, f"  {label}")
        self.listbox.pack(fill=tk.Y, expand=True, padx=4, pady=(0, 8))
        self.listbox.bind("<<ListboxSelect>>", self._on_select)

        # Right: text editor
        right = ttk.Frame(body, style="Card.TFrame")
        right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        right.rowconfigure(0, weight=1)
        right.columnconfigure(0, weight=1)
        self.text = tk.Text(right, bg=COLORS['bg_input'], fg=COLORS['text'],
                             insertbackground=COLORS['text'], font=FONT_LOG,
                             relief=tk.FLAT, wrap=tk.WORD, padx=10, pady=8,
                             undo=True)
        vsb = ttk.Scrollbar(right, orient=tk.VERTICAL, command=self.text.yview)
        self.text.configure(yscrollcommand=vsb.set)
        self.text.grid(row=0, column=0, sticky='nsew', padx=(6, 0), pady=6)
        vsb.grid(row=0, column=1, sticky='ns', pady=6, padx=(0, 4))
        self.text.bind("<<Modified>>", self._on_text_modified)

        # Select first by default
        self.listbox.selection_set(0)
        self.frame.after(100, lambda: self._load_file(_PROMPT_FILES[0][1]))

    def _on_select(self, event=None):
        sel = self.listbox.curselection()
        if not sel:
            return
        if self._modified and self._current_path:
            if not messagebox.askyesno("Unsaved changes",
                                        f"Discard changes to {self._current_path.name}?"):
                return
        _, path = _PROMPT_FILES[sel[0]]
        self._load_file(path)

    def _load_file(self, path: Path):
        self._current_path = path
        self.text.edit_modified(False)
        self._modified = False
        self.text.delete('1.0', tk.END)
        if path.exists():
            self.text.insert('1.0', path.read_text(encoding='utf-8'))
        else:
            self.text.insert('1.0', f"# File not found: {path}\n")
        self.text.edit_modified(False)
        self.file_lbl.config(text=str(path.relative_to(AGENT_DIR.parent)
                                       if path.is_relative_to(AGENT_DIR.parent) else path))
        self.status_lbl.config(text="")

    def _on_text_modified(self, event=None):
        if self.text.edit_modified():
            self._modified = True
            self.status_lbl.config(text="● unsaved", foreground=COLORS.get('yellow', '#f5c842'))

    def _save(self):
        if not self._current_path:
            return
        content = self.text.get('1.0', 'end-1c')
        self._current_path.write_text(content, encoding='utf-8')
        # Sync to PORTABLE
        portable_path = Path(str(self._current_path).replace('VARAGENT_API', 'VARAGENT_API_PORTABLE'))
        if portable_path.parent.exists():
            portable_path.write_text(content, encoding='utf-8')
        self.text.edit_modified(False)
        self._modified = False
        self.status_lbl.config(text="Saved", foreground=COLORS['green'])
        self.frame.after(3000, lambda: self.status_lbl.config(text=""))

    def _reload(self):
        if self._current_path:
            self._load_file(self._current_path)

    def _open_folder(self):
        folder = AGENT_DIR / "prompts"
        if folder.exists():
            os.startfile(str(folder))


# ════════════════════════════════════════════════════════════════════
# TAB 3: SETTINGS (.env Editor)
# ════════════════════════════════════════════════════════════════════

class SettingsTab:
    """.env editor — view and edit all config values."""

    def __init__(self, notebook, app: VarAgentGUI):
        self.app = app
        self.root = app.root
        self.frame = ttk.Frame(notebook)
        self.env_entries = {}
        self.env_lines = []
        self.create_ui()

    def create_ui(self):
        # Top buttons
        top = ttk.Frame(self.frame)
        top.pack(fill=tk.X, padx=10, pady=(8, 0))
        ttk.Button(top, text="Save .env", command=self._save_env, style="Accent.TButton").pack(side=tk.LEFT, padx=4)
        ttk.Button(top, text="Reload", command=self._load_env_editor).pack(side=tk.LEFT, padx=4)
        self.save_status = ttk.Label(top, text="", style="Dim.TLabel")
        self.save_status.pack(side=tk.LEFT, padx=8)
        ttk.Button(top, text="Codex Login (browser)", command=lambda: self._codex_login(False)).pack(side=tk.RIGHT, padx=4)
        ttk.Button(top, text="Codex Login (device code)", command=lambda: self._codex_login(True)).pack(side=tk.RIGHT, padx=4)
        # Update Codex CLI button — check version in background, update style if needed
        self.update_codex_btn = ttk.Button(top, text="Update Codex CLI", command=self._update_codex_cli)
        self.update_codex_btn.pack(side=tk.RIGHT, padx=4)
        threading.Thread(target=self._check_codex_version_bg, daemon=True).start()
        # ── Watermark Removal Tools (same row) ───────────────────────────────
        ttk.Separator(top, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=6)
        self._audio_inst_lbl = tk.Label(top, text="", bg=COLORS['bg_dark'], font=('Segoe UI', 10))
        self._audio_inst_lbl.pack(side=tk.LEFT, padx=(0, 2))
        ttk.Button(top, text="Install Audio Cleaner", state='disabled',
                   command=self._install_audio_remover).pack(side=tk.LEFT, padx=(0, 6))
        self._synthid_inst_lbl = tk.Label(top, text="", bg=COLORS['bg_dark'], font=('Segoe UI', 10))
        self._synthid_inst_lbl.pack(side=tk.LEFT, padx=(0, 2))
        ttk.Button(top, text="Install SynthID Remover",
                   command=self._install_synthid_remover).pack(side=tk.LEFT)
        self._update_install_labels()

        # Theme selector
        theme_row = ttk.Frame(self.frame)
        theme_row.pack(fill=tk.X, padx=10, pady=(4, 0))
        ttk.Label(theme_row, text="Theme:", style="Card.TLabel").pack(side=tk.LEFT)
        self._theme_var = tk.StringVar(value=_ACTIVE_THEME.get('name', 'Default'))
        _theme_names = _available_themes()
        ttk.Combobox(theme_row, textvariable=self._theme_var,
                     values=_theme_names, width=16, state='readonly').pack(side=tk.LEFT, padx=4)
        ttk.Button(theme_row, text="Apply (restart)", command=self._apply_theme).pack(side=tk.LEFT, padx=4)
        ttk.Label(theme_row, text="Requires restart", style="Dim.TLabel").pack(side=tk.LEFT, padx=4)

        # Scrollable two-column layout
        outer = ttk.Frame(self.frame)
        outer.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        canvas = tk.Canvas(outer, bg=COLORS['bg_dark'], highlightthickness=0)
        scrollbar = ttk.Scrollbar(outer, orient=tk.VERTICAL, command=canvas.yview)
        self.scroll_inner = ttk.Frame(canvas, style="TFrame")
        self.scroll_inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        self._canvas_win = canvas.create_window((0, 0), window=self.scroll_inner, anchor=tk.NW)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self._canvas = canvas
        # Stretch inner frame to canvas width
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(self._canvas_win, width=e.width))
        _mw = lambda e: canvas.yview_scroll(-1 * (e.delta // 120), "units")
        canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", _mw))
        canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))

        # Two columns
        _cols = ttk.Frame(self.scroll_inner, style="TFrame")
        _cols.pack(fill=tk.BOTH, expand=True)
        self.col_left = ttk.Frame(_cols, style="TFrame")
        self.col_left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 4))
        self.col_right = ttk.Frame(_cols, style="TFrame")
        self.col_right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(4, 0))

        # Chain Mode Settings card (full-width, above WM guide)
        _chain_card = self.app.create_card(self.scroll_inner, "Chain Mode Settings")
        _chain_card.pack(fill=tk.X, pady=(4, 8))
        self._build_chain_settings(_chain_card)

        # WM Tools guide (full-width, below env columns)
        _guide = ttk.Frame(self.scroll_inner, style="TFrame")
        _guide.pack(fill=tk.X, pady=(12, 4))
        self._build_wm_guide(_guide)

        self.root.after(200, self._load_env_editor)

    def _build_wm_guide(self, parent):
        """WM Tools reference cards — shown in Settings scrollable area."""
        ttk.Label(parent, text="WM Tools — Processing Guide",
                  style="Section.TLabel").pack(anchor=tk.W, pady=(0, 6))

        row = ttk.Frame(parent, style="TFrame")
        row.pack(fill=tk.X)

        # ── Audio Cleaner card ──────────────────────────────────────────────
        ac = ttk.Frame(row, style="Card.TFrame", padding=12)
        ac.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 4))
        ttk.Label(ac, text="Audio WM Cleaner — Levels",
                  style="Section.TLabel").pack(anchor=tk.W, pady=(0, 4))
        for lvl, desc in _WM_AUDIO_LEVELS:
            f = ttk.Frame(ac, style="Card.TFrame")
            f.pack(fill=tk.X, pady=(0, 4))
            ttk.Label(f, text=lvl, style="Card.TLabel",
                      font=('Consolas', 9, 'bold')).pack(anchor=tk.W)
            ttk.Label(f, text=desc, style="Dim.TLabel",
                      wraplength=300, justify=tk.LEFT).pack(anchor=tk.W, padx=(10, 0))

        # ── SynthID card ────────────────────────────────────────────────────
        sid = ttk.Frame(row, style="Card.TFrame", padding=12)
        sid.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(4, 0))
        ttk.Label(sid, text="SynthID Remover — Strength & Version",
                  style="Section.TLabel").pack(anchor=tk.W, pady=(0, 4))
        ttk.Label(sid, text="Strength", style="Card.TLabel",
                  font=('Consolas', 9, 'bold')).pack(anchor=tk.W, pady=(0, 2))
        for lvl, desc in _WM_SYNTHID_STRENGTH:
            f = ttk.Frame(sid, style="Card.TFrame")
            f.pack(fill=tk.X, pady=(0, 3))
            ttk.Label(f, text=lvl, style="Card.TLabel",
                      font=('Consolas', 9, 'bold')).pack(anchor=tk.W)
            ttk.Label(f, text=desc, style="Dim.TLabel",
                      wraplength=300, justify=tk.LEFT).pack(anchor=tk.W, padx=(10, 0))
        ttk.Separator(sid, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=6)
        ttk.Label(sid, text="Version", style="Card.TLabel",
                  font=('Consolas', 9, 'bold')).pack(anchor=tk.W, pady=(0, 2))
        for ver, desc in _WM_SYNTHID_VERSIONS:
            f = ttk.Frame(sid, style="Card.TFrame")
            f.pack(fill=tk.X, pady=(0, 3))
            ttk.Label(f, text=ver, style="Card.TLabel",
                      font=('Consolas', 9, 'bold')).pack(anchor=tk.W)
            ttk.Label(f, text=desc, style="Dim.TLabel",
                      wraplength=300, justify=tk.LEFT).pack(anchor=tk.W, padx=(10, 0))

    def _build_chain_settings(self, parent):
        """Chain Mode настройки с GUI контролами."""
        # Row 1: Trim + Offset + Mute
        r1 = ttk.Frame(parent, style="Card.TFrame")
        r1.pack(fill=tk.X, pady=2)
        ttk.Label(r1, text="Trim frames:", style="Card.TLabel", width=15).pack(side=tk.LEFT)
        ttk.Spinbox(r1, from_=1, to=5, textvariable=self.app.chain_trim_frames, width=6).pack(side=tk.LEFT, padx=4)
        ttk.Label(r1, text="Frame offset (s):", style="Card.TLabel", width=16).pack(side=tk.LEFT, padx=(12, 0))
        ttk.Spinbox(r1, from_=0.1, to=2.0, increment=0.1, textvariable=self.app.chain_frame_offset, width=6).pack(side=tk.LEFT, padx=4)
        ttk.Checkbutton(r1, text="Mute audio (extends)", variable=self.app.chain_mute_audio).pack(side=tk.LEFT, padx=(12, 0))

        # Row 2: Imggen heads only + Max chain + Cascade
        r2 = ttk.Frame(parent, style="Card.TFrame")
        r2.pack(fill=tk.X, pady=2)
        ttk.Checkbutton(r2, text="ImgGen heads only (~85% saving)", variable=self.app.chain_imggen_heads_only).pack(side=tk.LEFT)
        ttk.Label(r2, text="Max chain:", style="Card.TLabel", width=10).pack(side=tk.LEFT, padx=(12, 0))
        ttk.Spinbox(r2, from_=1, to=50, textvariable=self.app.chain_max_chain, width=6).pack(side=tk.LEFT, padx=4)
        ttk.Checkbutton(r2, text="Cascade recovery", variable=self.app.chain_cascade_recovery).pack(side=tk.LEFT, padx=(12, 0))

        # Row 3: Max fails
        r3 = ttk.Frame(parent, style="Card.TFrame")
        r3.pack(fill=tk.X, pady=2)
        ttk.Label(r3, text="Max fails (same clip):", style="Card.TLabel", width=20).pack(side=tk.LEFT)
        ttk.Spinbox(r3, from_=1, to=10, textvariable=self.app.chain_max_fails, width=6).pack(side=tk.LEFT, padx=4)
        ttk.Label(r3, text="(forced sub-chain head after)", style="Dim.TLabel").pack(side=tk.LEFT, padx=4)

    def _load_env_editor(self):
        env_path = AGENT_DIR / '.env'
        if not env_path.exists():
            return
        # patch_env удалён — он вызывал _ENV_FORCE и затирал пользовательские ключи
        # при каждом запуске varagent. Недостающие ключи добавляет updater при
        # реальном обновлении, а не при простом открытии Settings.
        self.env_entries = {}
        self.env_lines = []
        for widget in self.col_left.winfo_children():
            widget.destroy()
        for widget in self.col_right.winfo_children():
            widget.destroy()

        with open(env_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        # Parse into sections
        sections = []
        current_title = "General"
        current_items = []
        for line in lines:
            raw = line.rstrip('\n')
            self.env_lines.append(raw)
            if raw.startswith('# ====') or raw.startswith('# ----'):
                title = raw.strip('# =- ')
                if title:
                    if current_items:
                        sections.append((current_title, current_items))
                    current_title = title
                    current_items = []
            elif '=' in raw and not raw.startswith('#'):
                key, _, val = raw.partition('=')
                current_items.append((key.strip(), val.strip()))
        if current_items:
            sections.append((current_title, current_items))

        # Distribute sections to two columns (left-right by count balance)
        left_count = 0
        right_count = 0
        for title, items in sections:
            if left_count <= right_count:
                col = self.col_left
                left_count += len(items) + 1
            else:
                col = self.col_right
                right_count += len(items) + 1

            card = ttk.Frame(col, style="Card.TFrame", padding=10)
            card.pack(fill=tk.X, pady=4, padx=2)
            ttk.Label(card, text=title, style="Section.TLabel").pack(anchor=tk.W, pady=(0, 4))
            for key, val in items:
                row = ttk.Frame(card, style="Card.TFrame")
                row.pack(fill=tk.X, pady=1)
                ttk.Label(row, text=key, style="Dim.TLabel", width=30).pack(side=tk.LEFT)
                opts = ENV_DROPDOWN_OPTIONS.get(key)
                if opts:
                    entry = ttk.Combobox(row, values=opts, state='normal', font=FONT_DIM)
                    # Match current .env value to a display option (e.g. "GEM_PIX_2" → "GEM_PIX_2 — Banana Pro")
                    matched = next((o for o in opts if o.split(' \u2014')[0].strip() == val), val)
                    entry.set(matched)
                else:
                    show = '•' if 'API_KEY' in key.upper() else ''
                    entry = tk.Entry(row, bg=COLORS['bg_input'], fg=COLORS['text'],
                                     insertbackground=COLORS['text'], relief=tk.FLAT, show=show,
                                     font=FONT_DIM)
                    entry.insert(0, val)
                    # Full clipboard support for Entry fields (show='•' blocks defaults on Windows)
                    def _setup_entry(w):
                        _undo_stack = []
                        def _snapshot():
                            _undo_stack.append(w.get())
                            if len(_undo_stack) > 50:
                                _undo_stack.pop(0)
                        def _paste(e=None):
                            try:
                                text = w.clipboard_get()
                            except tk.TclError:
                                return 'break'
                            _snapshot()
                            try:
                                w.delete(tk.SEL_FIRST, tk.SEL_LAST)
                            except tk.TclError:
                                pass
                            w.insert(tk.INSERT, text)
                            return 'break'
                        def _cut(e=None):
                            try:
                                sel = w.selection_get()
                            except tk.TclError:
                                return 'break'
                            _snapshot()
                            w.clipboard_clear()
                            w.clipboard_append(sel)
                            w.delete(tk.SEL_FIRST, tk.SEL_LAST)
                            return 'break'
                        def _copy(e=None):
                            try:
                                sel = w.selection_get()
                            except tk.TclError:
                                return 'break'
                            w.clipboard_clear()
                            w.clipboard_append(sel)
                            return 'break'
                        def _undo(e=None):
                            if _undo_stack:
                                cur = w.get()
                                prev = _undo_stack.pop()
                                w.delete(0, tk.END)
                                w.insert(0, prev)
                            return 'break'
                        def _select_all(e=None):
                            w.select_range(0, tk.END)
                            w.icursor(tk.END)
                            return 'break'
                        def _ctx(e):
                            m = tk.Menu(w, tearoff=0)
                            m.add_command(label='Cut', command=_cut)
                            m.add_command(label='Copy', command=_copy)
                            m.add_command(label='Paste', command=_paste)
                            m.add_separator()
                            m.add_command(label='Undo', command=_undo)
                            m.add_separator()
                            m.add_command(label='Select All', command=_select_all)
                            m.post(e.x_root, e.y_root)
                        # Snapshot before each keystroke for undo
                        w.bind('<Key>', lambda e: _snapshot() if len(e.char) == 1 else None)
                        # Clipboard shortcuts (virtual events + key combos)
                        w.bind('<<Paste>>', lambda e: _paste())
                        w.bind('<Control-v>', lambda e: _paste())
                        w.bind('<Control-V>', lambda e: _paste())
                        w.bind('<Command-v>', lambda e: _paste())
                        w.bind('<Control-c>', lambda e: _copy())
                        w.bind('<Control-C>', lambda e: _copy())
                        w.bind('<Command-c>', lambda e: _copy())
                        w.bind('<Control-x>', lambda e: _cut())
                        w.bind('<Control-X>', lambda e: _cut())
                        w.bind('<Command-x>', lambda e: _cut())
                        w.bind('<Control-z>', lambda e: _undo())
                        w.bind('<Control-Z>', lambda e: _undo())
                        w.bind('<Command-z>', lambda e: _undo())
                        w.bind('<Control-a>', lambda e: _select_all())
                        w.bind('<Control-A>', lambda e: _select_all())
                        w.bind('<Command-a>', lambda e: _select_all())
                        w.bind('<Button-3>', _ctx)
                    _setup_entry(entry)
                    if show:
                        def _make_toggle(ent, r):
                            def _toggle():
                                if ent.cget('show') == '•':
                                    ent.configure(show='')
                                    _btn.configure(text='Hide')
                                else:
                                    ent.configure(show='•')
                                    _btn.configure(text='Show')
                            _btn = ttk.Button(r, text='Show', width=5, command=_toggle)
                            _btn.pack(side=tk.RIGHT, padx=(0, 2))
                        _make_toggle(entry, row)
                entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)
                self.env_entries[key] = entry

    def _apply_theme(self):
        """Write VARAGENT_THEME to .env and prompt restart."""
        theme_name = self._theme_var.get().strip()
        if not theme_name:
            return
        # Find theme file by name
        for t_file in _THEMES_DIR.glob('*.json'):
            try:
                import json as _j
                data = _j.loads(t_file.read_text(encoding='utf-8'))
                if data.get('name', t_file.stem) == theme_name:
                    theme_name = t_file.stem
                    break
            except Exception:
                continue
        # Write to .env
        env_path = AGENT_DIR / '.env'
        if env_path.exists():
            lines = env_path.read_text(encoding='utf-8').splitlines()
            found = False
            for i, line in enumerate(lines):
                if line.strip().startswith('VARAGENT_THEME='):
                    lines[i] = f'VARAGENT_THEME={theme_name}'
                    found = True
                    break
            if not found:
                lines.append(f'VARAGENT_THEME={theme_name}')
            env_path.write_text('\n'.join(lines) + '\n', encoding='utf-8')
        os.environ['VARAGENT_THEME'] = theme_name
        if messagebox.askyesno("Theme", f"Theme set to '{theme_name}'.\nRestart VarAgent now?"):
            # Reuse DonateTab._restart logic
            try:
                from dotenv import load_dotenv
                load_dotenv(str(AGENT_DIR / '.env'), override=True)
            except Exception:
                pass
            import subprocess
            subprocess.Popen([sys.executable] + sys.argv)
            self.app.root.destroy()

    def _codex_login(self, device_auth=False):
        """Launch codex login in a terminal window. Auto-install if missing."""
        import subprocess, shutil
        codex_exe = Path(getattr(config, 'CODEX_EXE_PATH', ''))
        if not codex_exe.exists():
            _which = shutil.which('codex')
            if _which:
                codex_exe = Path(_which)
        if not codex_exe.exists():
            if sys.platform == 'darwin':
                # Mac: install codex via brew
                if not shutil.which('brew'):
                    self.save_status.config(text="Homebrew not installed — cannot auto-install Codex")
                    return
                self.save_status.config(text="Installing Codex CLI via brew...")
                script = 'brew install --cask codex && echo && echo Codex installed! Run Codex Login again. && read'
                script_escaped = script.replace('\\', '\\\\').replace('"', '\\"')
                cmd = ['osascript', '-e',
                       f'tell application "Terminal" to do script "{script_escaped}"']
                subprocess.Popen(cmd)
                return
            else:
                # Windows: download exe from GitHub releases
                self._download_codex_win()
                return
        login_args = [str(codex_exe), 'login']
        if device_auth:
            login_args.append('--device-auth')
        if sys.platform == 'darwin':
            script = f'export NO_COLOR=1 && {" ".join(login_args)}'
            script_escaped = script.replace('\\', '\\\\').replace('"', '\\"')
            cmd = ['osascript', '-e',
                   f'tell application "Terminal" to do script "{script_escaped}"']
            subprocess.Popen(cmd, cwd=str(codex_exe.parent))
        else:
            # Windows: формируем единую строку для cmd (через shell=True), чтобы '&&'
            # интерпретировался как chain, а не передавался как аргумент.
            quoted = subprocess.list2cmdline(login_args)
            cmd_str = f'start "Codex Login" cmd /k "set NO_COLOR=1 && {quoted}"'
            subprocess.Popen(cmd_str, shell=True, cwd=str(codex_exe.parent))
        msg = "Codex login — enter code in browser" if device_auth else "Codex login — authorize in browser"
        self.save_status.config(text=msg)

    def _download_codex_win(self):
        """Download codex exe from GitHub releases into Codex/ folder."""
        import threading
        codex_dir = SCRIPT_DIR / 'Codex'
        codex_dir.mkdir(exist_ok=True)
        dest = codex_dir / 'codex-x86_64-pc-windows-msvc.exe'
        url = 'https://github.com/openai/codex/releases/latest/download/codex-x86_64-pc-windows-msvc.exe'
        self.save_status.config(text="Downloading Codex CLI (~166 MB)...")

        def _dl():
            try:
                import requests
                resp = requests.get(url, stream=True, timeout=300, allow_redirects=True)
                resp.raise_for_status()
                total = int(resp.headers.get('content-length', 0))
                downloaded = 0
                with open(dest, 'wb') as f:
                    for chunk in resp.iter_content(chunk_size=1024 * 1024):
                        f.write(chunk)
                        downloaded += len(chunk)
                        if total > 0:
                            pct = int(downloaded * 100 / total)
                            self.root.after(0, lambda p=pct: self.save_status.config(
                                text=f"Downloading Codex CLI... {p}%"))
                self.root.after(0, lambda: self.save_status.config(
                    text="Codex CLI downloaded! Press Codex Login again."))
            except Exception as e:
                self.root.after(0, lambda: self.save_status.config(
                    text=f"Download failed: {e}"))
                if dest.exists() and dest.stat().st_size < 1_000_000:
                    dest.unlink(missing_ok=True)

        threading.Thread(target=_dl, daemon=True).start()

    def _check_codex_version_bg(self):
        """Background thread: check if Codex update needed, highlight button if yes. Cached forever."""
        import json

        cache_file = SCRIPT_DIR / '.codex_version_cache.json'
        codex_exe = SCRIPT_DIR / 'Codex' / 'codex-x86_64-pc-windows-msvc.exe'

        # Check cache — if "all good", don't check again
        try:
            if cache_file.exists():
                cache = json.loads(cache_file.read_text(encoding='utf-8'))
                if not cache.get('update_needed', True):
                    return  # Cache says all good — done, no task
        except Exception:
            pass

        # Cache miss or says update needed — check now
        update_needed = True
        if codex_exe.exists():
            try:
                result = subprocess.run(
                    [str(codex_exe), 'exec', '-m', 'gpt-5.5', 'test'],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                # If stderr contains "requires a newer version" — update needed
                update_needed = 'requires a newer version' in result.stderr.lower()
            except subprocess.TimeoutExpired:
                update_needed = False  # Timeout = working, just slow
            except Exception:
                pass  # Assume update needed on error

        # Save cache
        try:
            cache_file.write_text(json.dumps({'update_needed': update_needed}), encoding='utf-8')
        except Exception:
            pass

        # Update button style if needed
        if update_needed:
            self.root.after(0, lambda: self.update_codex_btn.configure(style='Accent.TButton'))

    def _update_codex_cli(self):
        """Update Codex CLI to latest version."""
        import threading
        update_script = SCRIPT_DIR / 'update_codex.py'
        if not update_script.exists():
            self.save_status.config(text="Update script not found")
            return

        self.save_status.config(text="Updating Codex CLI...")

        def _update():
            try:
                import subprocess
                result = subprocess.run(
                    [sys.executable, str(update_script)],
                    capture_output=True,
                    text=True,
                    timeout=120
                )
                output = result.stdout + result.stderr
                if result.returncode == 0:
                    if 'already latest' in output.lower():
                        msg = "Codex CLI is up to date"
                    else:
                        msg = "Codex CLI updated successfully!"
                else:
                    msg = f"Update failed (exit {result.returncode})"
                self.root.after(0, lambda: self.save_status.config(text=msg))
            except Exception as e:
                self.root.after(0, lambda: self.save_status.config(text=f"Update error: {e}"))

        threading.Thread(target=_update, daemon=True).start()

    # ── Watermark Removal Tools install ──────────────────────────────────────

    def _update_install_labels(self):
        ac_ok  = _audio_installed()
        sid_ok = _synthid_installed()
        self._audio_inst_lbl.config(
            text="\u2713" if ac_ok else "\u2717",
            fg=COLORS['text'] if ac_ok else COLORS['text_muted'])
        self._synthid_inst_lbl.config(
            text="\u2713" if sid_ok else "\u2717",
            fg=COLORS['text'] if sid_ok else COLORS['text_muted'])

    def _run_install(self, script: str, lbl: tk.Label, which: str):
        """Run an --install script in a thread, streaming stdout steps to lbl."""
        _DOTS = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
        _dot_idx = [0]
        _running = [True]
        _step = ['']

        def _spin():
            if not _running[0]:
                return
            dot = _DOTS[_dot_idx[0] % len(_DOTS)]
            _dot_idx[0] += 1
            short = _step[0][:18] + '…' if len(_step[0]) > 18 else _step[0]
            lbl.config(text=f"{dot} {short}" if short else dot,
                       fg=COLORS['text_muted'])
            self.root.after(100, _spin)

        _spin()

        def _do():
            cmd = [sys.executable,
                   str(AGENT_DIR / 'tools' / script), '--install']
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                    text=True, encoding='utf-8', errors='replace')
            for line in proc.stdout:
                line = line.strip()
                if not line:
                    continue
                # Extract meaningful part after prefix like "[audio_cleaner] "
                text = line.split('] ', 1)[-1] if '] ' in line else line
                _step[0] = text
            proc.wait()
            ok = _audio_installed() if which == 'audio' else _synthid_installed()
            _running[0] = False
            self.root.after(0, lambda: self._on_install_done(which, ok))

        threading.Thread(target=_do, daemon=True).start()

    def _install_audio_remover(self):
        self._run_install('audio_cleaner.py', self._audio_inst_lbl, 'audio')

    def _install_synthid_remover(self):
        self._run_install('synthid_cleaner.py', self._synthid_inst_lbl, 'synthid')

    def _on_install_done(self, which: str, ok: bool):
        self._update_install_labels()
        self.app.tab_pipeline._refresh_remover_status()
        name = 'Audio Cleaner' if which == 'audio' else 'SynthID Remover'
        if ok:
            messagebox.showinfo("Install Complete", f"{name}: installed OK", parent=self.root)
        else:
            messagebox.showerror("Install Failed",
                f"{name}: install FAILED\nCheck internet connection.", parent=self.root)

    def _save_env(self):
        env_path = AGENT_DIR / '.env'
        # Chain Mode controls (чекбоксы/спинбоксы) НЕ привязаны к env_entries —
        # это отдельные BooleanVar/IntVar/DoubleVar. Перед сохранением .env
        # синхронизируем их значения в env_entries (если такие ключи в .env есть)
        # ИЛИ запоминаем как override чтобы дописать в файл.
        chain_overrides = {
            'CHAIN_IMGGEN_HEADS_ONLY':   '1' if self.app.chain_imggen_heads_only.get() else '0',
            'VIDEO_EXTEND_MAX_CHAIN':    str(self.app.chain_max_chain.get()),
            'CHAIN_CASCADE_RECOVERY':    '1' if self.app.chain_cascade_recovery.get() else '0',
            'CHAIN_MAX_SAME_CLIP_FAILS': str(self.app.chain_max_fails.get()),
            'VIDEO_EXTEND_FRAME_OFFSET': str(self.app.chain_frame_offset.get()),
            'VIDEO_EXTEND_TRIM_FRAMES':  str(self.app.chain_trim_frames.get()),
            'VIDEO_EXTEND_MUTE_AUDIO':   '1' if self.app.chain_mute_audio.get() else '0',
        }
        for _ck, _cv in chain_overrides.items():
            if _ck in self.env_entries:
                try:
                    self.env_entries[_ck].delete(0, tk.END)
                    self.env_entries[_ck].insert(0, _cv)
                except Exception:
                    pass
        new_lines = []
        written_keys = set()
        with open(env_path, 'r', encoding='utf-8') as f:
            for line in f:
                raw = line.rstrip('\n')
                if '=' in raw and not raw.startswith('#'):
                    key = raw.split('=', 1)[0].strip()
                    if key in self.env_entries:
                        new_val = self.env_entries[key].get()
                        # Strip display label suffix (e.g. "GEM_PIX_2 — Banana Pro" → "GEM_PIX_2")
                        if ' \u2014 ' in new_val:
                            new_val = new_val.split(' \u2014 ')[0].strip()
                        new_lines.append(f"{key}={new_val}")
                        written_keys.add(key)
                        continue
                    if key in chain_overrides:
                        new_lines.append(f"{key}={chain_overrides[key]}")
                        written_keys.add(key)
                        continue
                new_lines.append(raw)

        # Append keys that user edited in GUI but didn't exist in .env file
        for key, entry in self.env_entries.items():
            if key not in written_keys:
                val = entry.get()
                if ' \u2014 ' in val:
                    val = val.split(' \u2014 ')[0].strip()
                if val:  # only add if user actually entered a value
                    new_lines.append(f"{key}={val}")
                    written_keys.add(key)

        # Append chain overrides that weren't represented in .env or env_entries
        for _ck, _cv in chain_overrides.items():
            if _ck not in written_keys:
                new_lines.append(f"{_ck}={_cv}")
                written_keys.add(_ck)

        with open(env_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(new_lines) + '\n')

        # Reload config: push saved values into os.environ so config.py picks them up
        for key, entry in self.env_entries.items():
            val = entry.get()
            if ' \u2014 ' in val:
                val = val.split(' \u2014 ')[0].strip()
            os.environ[key] = val
        for _ck, _cv in chain_overrides.items():
            os.environ[_ck] = _cv
        try:
            from dotenv import load_dotenv
            load_dotenv(str(env_path), override=True)
        except ImportError:
            pass
        importlib.reload(config)
        self.save_status.config(text="Saved + reloaded", foreground=COLORS['green'])
        self.root.after(3000, lambda: self.save_status.config(text=""))
        self.app.log(".env saved and config reloaded", "SUCCESS", tab="control")


# ════════════════════════════════════════════════════════════════════
# TAB 4: VEONONSTOP GENERATOR
# ════════════════════════════════════════════════════════════════════

class VeoGeneratorTab:
    """Standalone VeoNonStop generator — port of 2.py with VeoNonStopClient."""

    def __init__(self, notebook, app: VarAgentGUI):
        self.app = app
        self.root = app.root
        self.frame = ttk.Frame(notebook)
        self.output_dir = get_output_dir()

        # State
        self.api_key = tk.StringVar(value=config.VEONONSTOP_API_KEY or '')
        self.mode = tk.StringVar(value="video_t2v")
        self.aspect_ratio = tk.StringVar(value="16:9")
        self.generation_count = tk.IntVar(value=1)
        self.model_key = tk.StringVar(value="Banana Pro")
        self.thread_count = tk.IntVar(value=min(4, config.VEONONSTOP_MAX_PARALLEL))
        self.max_threads = 24

        self.reference_images = []
        self.video_images = []
        self.single_image = None
        self.single_image_list = []
        self.batch_start_images: list = []   # [{image_base64, mime_type, name}, ...]
        self.batch_end_images: list = []
        self.prompts_list = []
        self.is_generating = False
        self.last_video_result = None
        self.stats = {"success": 0, "failed": 0, "total": 0}
        self.stats_lock = threading.Lock()

        self.create_ui()

    def create_ui(self):
        content = ttk.Frame(self.frame)
        content.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        # LEFT column (fixed width)
        left = ttk.Frame(content)
        left.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 5))

        # RIGHT column
        right = ttk.Frame(content)
        right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self._build_left(left)
        self._build_right(right)

    def _build_left(self, parent):
        # API Key
        card = self.app.create_card(parent, "API Key")
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(fill=tk.X)
        self.api_entry = tk.Entry(row, textvariable=self.api_key, bg=COLORS['bg_input'],
                                  fg=COLORS['text'], insertbackground=COLORS['text'],
                                  relief=tk.FLAT, show='*')
        self.api_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 4))
        ttk.Button(row, text="Show", command=self._toggle_key, width=5).pack(side=tk.LEFT, padx=1)
        ttk.Button(row, text="Account", command=self.check_account, width=8).pack(side=tk.LEFT, padx=1)

        # Mode
        card = self.app.create_card(parent, "Generation Mode")
        modes = [
            ("Text to Video", "video_t2v"),
            ("Image to Video", "video_i2v"),
            ("Text2Video + References", "video_multi"),
            ("Batch Frame", "video_batch"),
            ("Banana (image)", "image_banana"),
            ("IMAGEN 3.5", "image_imagen"),
        ]
        for label, val in modes:
            ttk.Radiobutton(card, text=label, variable=self.mode, value=val,
                            command=self._on_mode_change).pack(anchor=tk.W)

        # Parameters
        card = self.app.create_card(parent, "Parameters")
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(fill=tk.X, pady=2)
        ttk.Label(row, text="Ratio:", style="Card.TLabel").pack(side=tk.LEFT)
        for v in ['16:9', '9:16', '1:1']:
            ttk.Radiobutton(row, text=v, variable=self.aspect_ratio, value=v).pack(side=tk.LEFT, padx=3)
        row2 = ttk.Frame(card, style="Card.TFrame")
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="Count:", style="Card.TLabel").pack(side=tk.LEFT)
        tk.Spinbox(row2, textvariable=self.generation_count, from_=1, to=8, width=3,
                   bg=COLORS['bg_input'], fg=COLORS['text']).pack(side=tk.LEFT, padx=4)

        # Threads
        card = self.app.create_card(parent, "Threads")
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(fill=tk.X)
        self.thread_label = ttk.Label(row, text=f"Threads: {self.thread_count.get()}", style="Card.TLabel")
        self.thread_label.pack(side=tk.LEFT)
        slider = tk.Scale(row, from_=1, to=self.max_threads, orient=tk.HORIZONTAL,
                          variable=self.thread_count, bg=COLORS['bg_card'], fg=COLORS['text'],
                          highlightbackground=COLORS['bg_card'], troughcolor=COLORS['bg_input'],
                          command=lambda v: self.thread_label.config(text=f"Threads: {v}"))
        slider.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)
        presets = ttk.Frame(card, style="Card.TFrame")
        presets.pack(fill=tk.X, pady=2)
        for n in [1, 4, 8, 12, 24]:
            ttk.Button(presets, text=str(n), width=3,
                       command=lambda x=n: self.thread_count.set(x)).pack(side=tk.LEFT, padx=2)

        # Images (dynamic based on mode)
        card = self.app.create_card(parent, "Images")
        # i2v: single image
        self.single_frame = ttk.Frame(card, style="Card.TFrame")
        self.single_img_label = ttk.Label(self.single_frame, text="No image", style="Dim.TLabel")
        self.single_img_label.pack(side=tk.LEFT)
        ttk.Button(self.single_frame, text="Select", command=self._select_single_image).pack(side=tk.RIGHT)

        # multi: image list
        self.multi_frame = ttk.Frame(card, style="Card.TFrame")
        multi_top = ttk.Frame(self.multi_frame, style="Card.TFrame")
        multi_top.pack(fill=tk.X)
        self.multi_label = ttk.Label(multi_top, text="Images: (0)", style="Dim.TLabel")
        self.multi_label.pack(side=tk.LEFT)
        ttk.Button(multi_top, text="Add", command=self._add_video_image).pack(side=tk.RIGHT, padx=2)
        ttk.Button(multi_top, text="Remove", command=self._remove_selected_video_image).pack(side=tk.RIGHT, padx=2)
        ttk.Button(multi_top, text="Clear", command=self._clear_video_images).pack(side=tk.RIGHT)
        self.multi_listbox = tk.Listbox(self.multi_frame, height=3, bg=COLORS['bg_input'],
                                        fg=COLORS['text'], font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        self.multi_listbox.pack(fill=tk.X, pady=(2, 0))

        # batch: start + end
        self.batch_frame = ttk.Frame(card, style="Card.TFrame")
        # Start images
        row_s = ttk.Frame(self.batch_frame, style="Card.TFrame")
        row_s.pack(fill=tk.X, pady=(0, 2))
        self.start_count_lbl = ttk.Label(row_s, text="Start (0):", style="Dim.TLabel")
        self.start_count_lbl.pack(side=tk.LEFT)
        ttk.Button(row_s, text="Clear", command=lambda: self._clear_batch("start")).pack(side=tk.RIGHT, padx=2)
        ttk.Button(row_s, text="Remove", command=lambda: self._remove_batch_item("start")).pack(side=tk.RIGHT, padx=2)
        ttk.Button(row_s, text="Select", command=lambda: self._select_batch("start")).pack(side=tk.RIGHT, padx=2)
        self.start_listbox = tk.Listbox(self.batch_frame, height=3, bg=COLORS['bg_input'],
                                         fg=COLORS['text'], font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        self.start_listbox.pack(fill=tk.X, pady=(0, 4))
        # End images
        row_e = ttk.Frame(self.batch_frame, style="Card.TFrame")
        row_e.pack(fill=tk.X, pady=(0, 2))
        self.end_count_lbl = ttk.Label(row_e, text="End (0):", style="Dim.TLabel")
        self.end_count_lbl.pack(side=tk.LEFT)
        ttk.Button(row_e, text="Clear", command=lambda: self._clear_batch("end")).pack(side=tk.RIGHT, padx=2)
        ttk.Button(row_e, text="Remove", command=lambda: self._remove_batch_item("end")).pack(side=tk.RIGHT, padx=2)
        ttk.Button(row_e, text="Select", command=lambda: self._select_batch("end")).pack(side=tk.RIGHT, padx=2)
        self.end_listbox = tk.Listbox(self.batch_frame, height=3, bg=COLORS['bg_input'],
                                       fg=COLORS['text'], font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        self.end_listbox.pack(fill=tk.X)
        self.batch_pairs_lbl = ttk.Label(self.batch_frame, text="", style="Dim.TLabel")
        self.batch_pairs_lbl.pack(anchor=tk.W, pady=(2, 0))

        # banana: model + refs
        self.model_frame = ttk.Frame(card, style="Card.TFrame")
        row_m = ttk.Frame(self.model_frame, style="Card.TFrame")
        row_m.pack(fill=tk.X)
        ttk.Label(row_m, text="Model:", style="Card.TLabel").pack(side=tk.LEFT)
        ttk.Combobox(row_m, textvariable=self.model_key, values=BANANA_DISPLAY,
                     width=12, state='readonly').pack(side=tk.LEFT, padx=4)

        self.ref_frame = ttk.Frame(card, style="Card.TFrame")
        ref_row = ttk.Frame(self.ref_frame, style="Card.TFrame")
        ref_row.pack(fill=tk.X)
        self.ref_count_label = ttk.Label(ref_row, text="Refs: (0)", style="Dim.TLabel")
        self.ref_count_label.pack(side=tk.LEFT)
        ttk.Button(ref_row, text="Add Named", command=self._add_named_reference).pack(side=tk.RIGHT, padx=2)
        ttk.Button(ref_row, text="Load ref/", command=self._load_refs_from_dir).pack(side=tk.RIGHT, padx=2)
        ttk.Button(ref_row, text="Remove", command=self._remove_selected_ref).pack(side=tk.RIGHT, padx=2)
        ttk.Button(ref_row, text="Clear", command=self._clear_references).pack(side=tk.RIGHT)
        self.ref_veo_listbox = tk.Listbox(self.ref_frame, height=3, bg=COLORS['bg_input'],
                                          fg=COLORS['text'], font=FONT_DIM, relief=tk.FLAT, borderwidth=0)
        self.ref_veo_listbox.pack(fill=tk.X, pady=(2, 0))

        self._on_mode_change()

    def _build_right(self, parent):
        # Prompts
        card = self.app.create_card(parent, "Prompts")
        btn_row = ttk.Frame(card, style="Card.TFrame")
        btn_row.pack(fill=tk.X, pady=(0, 4))
        ttk.Button(btn_row, text="Load File", command=self._load_prompts_file).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="Clipboard", command=self._load_clipboard).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="Clear", command=self._clear_prompts).pack(side=tk.LEFT, padx=2)
        self.prompts_count_label = ttk.Label(btn_row, text="0 prompts", style="Dim.TLabel")
        self.prompts_count_label.pack(side=tk.RIGHT)
        self.prompt_text = scrolledtext.ScrolledText(card, height=5, bg=COLORS['bg_input'],
                                                     fg=COLORS['text'], font=FONT_LOG,
                                                     insertbackground=COLORS['text'], relief=tk.FLAT)
        self.prompt_text.pack(fill=tk.X)
        self.prompt_text.bind('<KeyRelease>', self._on_prompt_change)

        # Actions + Stats
        card = self.app.create_card(parent, "Actions")
        stats_row = ttk.Frame(card, style="Card.TFrame")
        stats_row.pack(fill=tk.X, pady=2)
        self.stats_success = ttk.Label(stats_row, text="OK: 0", style="Stats.TLabel")
        self.stats_success.pack(side=tk.LEFT, padx=6)
        self.stats_failed = ttk.Label(stats_row, text="Fail: 0", style="Stats.TLabel")
        self.stats_failed.pack(side=tk.LEFT, padx=6)
        self.stats_progress = ttk.Label(stats_row, text="0/0", style="Stats.TLabel")
        self.stats_progress.pack(side=tk.LEFT, padx=6)
        self.active_threads_label = ttk.Label(stats_row, text="0 active", style="Stats.TLabel")
        self.active_threads_label.pack(side=tk.RIGHT, padx=6)

        self.progress_bar = ttk.Progressbar(card, style="Green.Horizontal.TProgressbar",
                                            mode='determinate', length=300)
        self.progress_bar.pack(fill=tk.X, pady=4)

        # Project name row (для Generate All — создаёт папку с датой+именем)
        proj_row = ttk.Frame(card, style="Card.TFrame")
        proj_row.pack(fill=tk.X, pady=(4, 2))
        ttk.Label(proj_row, text="Project name:", style="Dim.TLabel").pack(side=tk.LEFT)
        self.project_name = tk.StringVar(value="")
        ttk.Entry(proj_row, textvariable=self.project_name,
                  style="Dark.TEntry", width=24).pack(side=tk.LEFT, padx=6)

        btn_row = ttk.Frame(card, style="Card.TFrame")
        btn_row.pack(fill=tk.X, pady=4)
        self.generate_btn = ttk.Button(btn_row, text="Генерировать 1", command=self.start_generation,
                                       style="Accent.TButton")
        self.generate_btn.pack(side=tk.LEFT, padx=3)
        self.multithread_btn = ttk.Button(btn_row, text="Генерировать все",
                                          command=self.start_multithread, style="Accent.TButton")
        self.multithread_btn.pack(side=tk.LEFT, padx=3)
        self.stop_btn = ttk.Button(btn_row, text="Stop", command=self.stop_generation,
                                   state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=3)

        btn_row2 = ttk.Frame(card, style="Card.TFrame")
        btn_row2.pack(fill=tk.X, pady=2)
        ttk.Button(btn_row2, text="Upsample 4K", command=self.upsample_video).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_row2, text="Cancel All", command=self.cancel_all).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_row2, text="Open Folder",
                   command=lambda: os.startfile(str(self.output_dir))).pack(side=tk.LEFT, padx=3)

        # Log
        log_card = self.app.create_card(parent, "Log")
        self.log_widget = self.app.create_log_widget(log_card)
        ttk.Button(log_card, text="Clear Log",
                   command=lambda: self.log_widget.delete("1.0", tk.END)).pack(anchor=tk.W, pady=2)

    # ═══════════ MODE SWITCHING ═══════════

    def _on_mode_change(self):
        mode = self.mode.get()
        for f in (self.single_frame, self.multi_frame, self.batch_frame, self.model_frame, self.ref_frame):
            f.pack_forget()
        if mode == "video_i2v":
            self.single_frame.pack(fill=tk.X, pady=4)
        elif mode == "video_multi":
            self.multi_frame.pack(fill=tk.X, pady=4)
        elif mode == "video_batch":
            self.batch_frame.pack(fill=tk.X, pady=4)
        elif mode == "image_banana":
            self.model_frame.pack(fill=tk.X, pady=4)
            self.ref_frame.pack(fill=tk.X, pady=4)

    # ═══════════ IMAGE MANAGEMENT ═══════════

    def _select_single_image(self):
        files = filedialog.askopenfilenames(filetypes=[("Images", "*.png *.jpg *.jpeg *.webp")])
        if not files:
            return
        if len(files) == 1:
            b64, mime = _image_to_base64(files[0])
            self.single_image = {"image_base64": b64, "mime_type": mime}
            self.single_img_label.config(text=Path(files[0]).name[:20])
            self._log(f"Image: {Path(files[0]).name}")
        else:
            # Multiple images → batch i2v (one request per image)
            self.single_image_list = []
            for fp in files:
                b64, mime = _image_to_base64(fp)
                self.single_image_list.append({"image_base64": b64, "mime_type": mime, "name": Path(fp).stem})
            self.single_image = self.single_image_list[0]  # keep compat
            self.single_img_label.config(text=f"{len(files)} images")
            self._log(f"Images for i2v: {len(files)} loaded")

    def _add_video_image(self):
        files = filedialog.askopenfilenames(filetypes=[("Images", "*.png *.jpg *.jpeg *.webp")])
        for fp in files:
            b64, mime = _image_to_base64(fp)
            name = Path(fp).stem
            self.video_images.append({"name": name, "image_base64": b64, "mime_type": mime})
            self._log(f"Added: {name}")
        if files:
            self.multi_listbox.insert(tk.END, name)
            self.multi_listbox.config(height=max(3, min(len(self.video_images), 6)))
            self.multi_label.config(text=f"Images: ({len(self.video_images)})")

    def _remove_selected_video_image(self):
        sel = self.multi_listbox.curselection()
        if sel:
            self.video_images.pop(sel[0])
            self.multi_listbox.delete(sel[0])
            self.multi_listbox.config(height=max(3, min(len(self.video_images), 6)))
            self.multi_label.config(text=f"Images: ({len(self.video_images)})")

    def _clear_video_images(self):
        self.video_images = []
        self.multi_listbox.delete(0, tk.END)
        self.multi_listbox.config(height=3)
        self.multi_label.config(text="Images: (0)")

    def _select_batch(self, which):
        fps = filedialog.askopenfilenames(filetypes=[("Images", "*.png *.jpg *.jpeg *.webp")])
        if not fps:
            return
        # Сортируем по имени файла — порядок пар определяется именем
        fps = sorted(fps, key=lambda p: Path(p).name)
        imgs = []
        for fp in fps:
            b64, mime = _image_to_base64(fp)
            imgs.append({"image_base64": b64, "mime_type": mime, "name": Path(fp).name})
        if which == "start":
            self.batch_start_images = imgs
            self.start_listbox.delete(0, tk.END)
            for img in imgs:
                self.start_listbox.insert(tk.END, img["name"])
            self.start_listbox.config(height=max(3, min(len(imgs), 6)))
            self.start_count_lbl.config(text=f"Start ({len(imgs)}):")
        else:
            self.batch_end_images = imgs
            self.end_listbox.delete(0, tk.END)
            for img in imgs:
                self.end_listbox.insert(tk.END, img["name"])
            self.end_listbox.config(height=max(3, min(len(imgs), 6)))
            self.end_count_lbl.config(text=f"End ({len(imgs)}):")
        self._update_batch_pairs_lbl()

    def _remove_batch_item(self, which):
        lb = self.start_listbox if which == "start" else self.end_listbox
        imgs = self.batch_start_images if which == "start" else self.batch_end_images
        sel = lb.curselection()
        if sel:
            imgs.pop(sel[0])
            lb.delete(sel[0])
            lb.config(height=max(3, min(len(imgs), 6)))
            lbl = self.start_count_lbl if which == "start" else self.end_count_lbl
            lbl.config(text=f"{'Start' if which == 'start' else 'End'} ({len(imgs)}):")
            self._update_batch_pairs_lbl()

    def _clear_batch(self, which):
        if which == "start":
            self.batch_start_images = []
            self.start_listbox.delete(0, tk.END)
            self.start_count_lbl.config(text="Start (0):")
        else:
            self.batch_end_images = []
            self.end_listbox.delete(0, tk.END)
            self.end_count_lbl.config(text="End (0):")
        self._update_batch_pairs_lbl()

    def _update_batch_pairs_lbl(self):
        ns, ne = len(self.batch_start_images), len(self.batch_end_images)
        if ns == 0 and ne == 0:
            self.batch_pairs_lbl.config(text="")
        else:
            pairs = min(ns, ne)
            warn = "  ⚠ unequal!" if ns != ne else ""
            self.batch_pairs_lbl.config(text=f"Pairs: {pairs}{warn}")

    def _add_named_reference(self):
        files = filedialog.askopenfilenames(filetypes=[("Images", "*.png *.jpg *.jpeg *.webp")])
        for fp in files:
            name = Path(fp).stem
            b64, mime = _image_to_base64(fp)
            self.reference_images.append({"name": name, "image_base64": b64, "mime_type": mime})
            self._log(f"Reference added: {name}")
        if files:
            self._refresh_ref_list()

    def _load_refs_from_dir(self):
        dirpath = filedialog.askdirectory(initialdir=str(SCRIPT_DIR / 'projects'))
        if dirpath:
            ref_dir = Path(dirpath) / 'ref' if (Path(dirpath) / 'ref').exists() else Path(dirpath)
            from modules.veononstop import _load_ref_images
            refs = _load_ref_images(str(ref_dir))
            if refs:
                self.reference_images = refs
                self._refresh_ref_list()
                self._log(f"Loaded {len(refs)} refs from {ref_dir}")
            else:
                messagebox.showwarning("Warning", f"No images found in {ref_dir}")

    def _clear_references(self):
        self.reference_images = []
        self._refresh_ref_list()

    def _refresh_ref_list(self):
        self.ref_veo_listbox.delete(0, tk.END)
        self.ref_count_label.config(text=f"Refs: ({len(self.reference_images)})")
        for ref in self.reference_images:
            self.ref_veo_listbox.insert(tk.END, ref['name'])
        self.ref_veo_listbox.config(height=max(3, min(len(self.reference_images), 6)))

    def _remove_selected_ref(self):
        sel = self.ref_veo_listbox.curselection()
        if sel:
            self.reference_images.pop(sel[0])
            self._refresh_ref_list()

    def _remove_ref(self, idx):
        self.reference_images.pop(idx)
        self._refresh_ref_list()

    def _rename_ref(self, idx):
        old_name = self.reference_images[idx]['name']
        new_name = simpledialog.askstring("Rename", "New name:", initialvalue=old_name)
        if new_name:
            self.reference_images[idx]['name'] = new_name
            self._refresh_ref_list()

    # ═══════════ PROMPTS ═══════════

    def _on_prompt_change(self, event=None):
        text = self.prompt_text.get("1.0", tk.END).strip()
        self.prompts_list = [l.strip() for l in text.split("\n") if l.strip()]
        self.prompts_count_label.config(text=f"{len(self.prompts_list)} prompts")

    def _load_prompts_file(self):
        fp = filedialog.askopenfilename(filetypes=[("Text", "*.txt")])
        if fp:
            with open(fp, 'r', encoding='utf-8') as f:
                self.prompt_text.delete("1.0", tk.END)
                self.prompt_text.insert("1.0", f.read())
            self._on_prompt_change()

    def _load_clipboard(self):
        try:
            text = self.root.clipboard_get()
            self.prompt_text.insert("1.0", text)
            self._on_prompt_change()
        except tk.TclError:
            pass

    def _clear_prompts(self):
        self.prompt_text.delete("1.0", tk.END)
        self.prompts_list = []
        self.prompts_count_label.config(text="0 prompts")

    # ═══════════ LOGGING ═══════════

    def _log(self, msg, level="INFO", tid=None):
        self.app.log(msg, level, tid, tab="veo")

    def _update_stats(self):
        with self.stats_lock:
            s, f = self.stats['success'], self.stats['failed']
            t = self.stats['total']
            done = s + f
        self.root.after(0, lambda: self.stats_success.config(text=f"OK: {s}"))
        self.root.after(0, lambda: self.stats_failed.config(text=f"Fail: {f}"))
        self.root.after(0, lambda: self.stats_progress.config(text=f"{done}/{t}"))
        if t > 0:
            self.root.after(0, lambda: self.progress_bar.config(value=(done / t) * 100))

    def _reset_stats(self):
        with self.stats_lock:
            self.stats = {"success": 0, "failed": 0, "total": 0}
        self._update_stats()
        self.progress_bar.config(value=0)

    def _reset_ui(self):
        self.generate_btn.config(state=tk.NORMAL)
        self.multithread_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        self.progress_bar.stop()
        self.active_threads_label.config(text="0 active")

    # ═══════════ API ═══════════

    def _get_headers(self):
        return {"X-API-Key": self.api_key.get().strip(), "Content-Type": "application/json"}

    def _toggle_key(self):
        self.api_entry.config(show="" if self.api_entry.cget('show') == '*' else "*")

    def check_account(self):
        key = self.api_key.get().strip()
        if not key:
            messagebox.showerror("Error", "Enter API key")
            return
        try:
            resp = requests.get(f"{BASE_URL}/account/info", headers=self._get_headers(), timeout=10)
            data = resp.json()
            if data.get("success"):
                info = data['data']
                plan = info.get('plan', '?')
                slots = info.get('concurrent_tasks', '?')
                expires = info.get('expires_at', '?')
                self.thread_count.set(min(int(slots) if isinstance(slots, int) else 4, self.max_threads))
                messagebox.showinfo("Account", f"Plan: {plan}\nSlots: {slots}\nExpires: {expires}")
            else:
                messagebox.showerror("Error", data.get("error", "Unknown"))
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def cancel_all(self):
        if not messagebox.askyesno("Cancel All", "Cancel all active tasks on server?"):
            return
        try:
            resp = requests.post(f"{BASE_URL}/video/cancel-all", headers=self._get_headers(), timeout=30)
            data = resp.json()
            cancelled = data.get("data", {}).get("cancelled_count", 0)
            self._log(f"Cancelled {cancelled} tasks", "SUCCESS")
        except Exception as e:
            self._log(f"Cancel error: {e}", "ERROR")

    # ═══════════ GENERATION ═══════════

    def start_generation(self):
        if self.is_generating:
            return
        key = self.api_key.get().strip()
        if not key:
            messagebox.showerror("Error", "Enter API key")
            return
        prompt = self.prompt_text.get("1.0", tk.END).strip()
        if not prompt:
            messagebox.showerror("Error", "Enter prompt")
            return
        first = prompt.split("\n")[0].strip()
        self.is_generating = True
        self.generate_btn.config(state=tk.DISABLED)
        self.multithread_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.progress_bar.config(mode='indeterminate')
        self.progress_bar.start()

        def worker():
            try:
                self._generate_single(first)
                self._log("Done!", "SUCCESS")
            except Exception as e:
                self._log(f"Error: {e}", "ERROR")
            finally:
                self.is_generating = False
                self.root.after(0, self._reset_ui)

        threading.Thread(target=worker, daemon=True).start()

    def start_multithread(self):
        if self.is_generating:
            return
        if not self.api_key.get().strip():
            messagebox.showerror("Error", "Enter API key")
            return
        self._on_prompt_change()
        tc = self.thread_count.get()

        # Batch Frame: итерируем по парам изображений, промпты цикличны
        if self.mode.get() == "video_batch":
            ns, ne = len(self.batch_start_images), len(self.batch_end_images)
            pc = min(ns, ne)
            if pc == 0:
                messagebox.showerror("Error", "Select start and end images")
                return
            if not self.prompts_list:
                messagebox.showerror("Error", "Enter at least one prompt")
                return
        else:
            if not self.prompts_list:
                messagebox.showerror("Error", "No prompts")
                return
            pc = len(self.prompts_list)
            if pc == 1:
                self.start_generation()
                return

        if not messagebox.askyesno("Confirm", f"Generate {pc} items with {tc} threads?"):
            return

        # Создаём папку проекта: veononstop_output/YYYYMMDD_HHMMSS[_name]/
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        name_part = self.project_name.get().strip()
        folder_name = f"{ts}_{name_part}" if name_part else ts
        # Очищаем от символов, недопустимых в именах папок
        folder_name = "".join(c for c in folder_name if c not in r'\/:*?"<>|')
        session_dir = get_output_dir() / folder_name
        session_dir.mkdir(parents=True, exist_ok=True)
        self.output_dir = session_dir

        self.is_generating = True
        self.generate_btn.config(state=tk.DISABLED)
        self.multithread_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.progress_bar.config(mode='determinate')
        self._reset_stats()
        with self.stats_lock:
            self.stats['total'] = pc
        self._update_stats()
        self._log(f"Output folder: {session_dir.name}", "INFO")

        threading.Thread(target=self._multithread_worker, daemon=True).start()

    def _multithread_worker(self):
        tc = self.thread_count.get()
        is_batch_frame = self.mode.get() == "video_batch"

        if is_batch_frame:
            # Итерируем по парам, промпты цикличны
            ns, ne = len(self.batch_start_images), len(self.batch_end_images)
            pairs = list(zip(self.batch_start_images[:min(ns, ne)],
                             self.batch_end_images[:min(ns, ne)]))
            prompts = self.prompts_list.copy()
            tasks = [(i, pairs[i][0], pairs[i][1], prompts[i % len(prompts)])
                     for i in range(len(pairs))]
            self._log(f"Batch Frame: {len(tasks)} pairs, {tc} threads", "INFO")
        else:
            prompts = self.prompts_list.copy()
            tasks = None
            self._log(f"Starting {len(prompts)} tasks with {tc} threads", "INFO")

        active = [0]
        active_lock = threading.Lock()

        def update_active(delta):
            with active_lock:
                active[0] += delta
                c = active[0]
            self.root.after(0, lambda: self.active_threads_label.config(text=f"{c} active"))

        def process(args):
            tid = threading.current_thread().name.split('_')[-1]
            if not self.is_generating:
                return False
            update_active(1)
            try:
                if is_batch_frame:
                    idx, s_img, e_img, prompt = args
                    self._log(f"Pair {idx+1}: {s_img['name']} → {e_img['name']}", "INFO", tid)
                    self._video_batch(prompt, tid, start_img=s_img, end_img=e_img)
                else:
                    idx, prompt = args
                    self._log(f"Start: {prompt[:40]}...", "INFO", tid)
                    self._generate_single(prompt, tid)
                with self.stats_lock:
                    self.stats['success'] += 1
                self._update_stats()
                return True
            except Exception as e:
                with self.stats_lock:
                    self.stats['failed'] += 1
                self._update_stats()
                self._log(f"Failed: {str(e)[:60]}", "ERROR", tid)
                return False
            finally:
                update_active(-1)

        if is_batch_frame:
            task_args = tasks
        else:
            task_args = [(i, p) for i, p in enumerate(prompts)]

        with ThreadPoolExecutor(max_workers=tc, thread_name_prefix="Gen") as exe:
            futures = {exe.submit(process, a): a for a in task_args}
            for f in as_completed(futures):
                if not self.is_generating:
                    exe.shutdown(wait=False, cancel_futures=True)
                    break

        with self.stats_lock:
            s, f, t = self.stats['success'], self.stats['failed'], self.stats['total']
        self._log(f"Done: {s} ok, {f} failed, {t} total", "SUCCESS")
        self.is_generating = False
        self.root.after(0, self._reset_ui)

    def _generate_single(self, prompt, tid=None):
        mode = self.mode.get()
        if mode == "video_t2v":
            self._video_t2v(prompt, tid)
        elif mode == "video_i2v":
            self._video_i2v(prompt, tid)
        elif mode == "video_multi":
            self._video_multi(prompt, tid)
        elif mode == "video_batch":
            self._video_batch(prompt, tid)
        elif mode == "image_banana":
            self._image_banana(prompt, tid)
        elif mode == "image_imagen":
            self._image_imagen(prompt, tid)

    def stop_generation(self):
        self.is_generating = False
        self._log("Stopping...", "WARNING")
        self._reset_ui()

    # ═══════════ VIDEO MODES ═══════════

    def _video_t2v(self, prompt, tid=None):
        self._log("Text to Video...", "INFO", tid)
        payload = {"prompt": prompt, "aspect_ratio": self.aspect_ratio.get(),
                   "count": self.generation_count.get()}
        self._submit_video("/video/text-to-video", payload, tid)

    def _video_i2v(self, prompt, tid=None):
        if not self.single_image:
            raise Exception("Select image first")
        img_list = getattr(self, 'single_image_list', None)
        if img_list and len(img_list) > 1:
            self._log(f"Batch i2v: {len(img_list)} images...", "INFO", tid)
            for i, img in enumerate(img_list):
                self._log(f"  i2v [{i+1}/{len(img_list)}] {img.get('name', '')}...", "INFO", tid)
                payload = {"prompt": prompt, "image_base64": img["image_base64"],
                           "mime_type": img["mime_type"],
                           "aspect_ratio": self.aspect_ratio.get(), "count": self.generation_count.get()}
                self._submit_video("/video/image-to-video", payload, tid)
        else:
            self._log("Image to Video...", "INFO", tid)
            payload = {"prompt": prompt, "image_base64": self.single_image["image_base64"],
                       "mime_type": self.single_image["mime_type"],
                       "aspect_ratio": self.aspect_ratio.get(), "count": self.generation_count.get()}
            self._submit_video("/video/image-to-video", payload, tid)

    def _video_multi(self, prompt, tid=None):
        if not self.video_images:
            raise Exception("Add images first")
        self._log(f"Multi-Image ({len(self.video_images)})...", "INFO", tid)
        payload = {"prompt": prompt, "images": self.video_images,
                   "aspect_ratio": self.aspect_ratio.get(), "count": self.generation_count.get()}
        self._submit_video("/video/multi-image-to-video", payload, tid)

    def _video_batch(self, prompt, tid=None, start_img=None, end_img=None):
        s = start_img or (self.batch_start_images[0] if self.batch_start_images else None)
        e = end_img or (self.batch_end_images[0] if self.batch_end_images else None)
        if not s or not e:
            raise Exception("Select start and end images")
        self._log(f"Batch Frame: {s['name']} → {e['name']}", "INFO", tid)
        payload = {"prompt": prompt, "start_image_base64": s["image_base64"],
                   "end_image_base64": e["image_base64"],
                   "aspect_ratio": self.aspect_ratio.get(), "count": self.generation_count.get()}
        self._submit_video("/video/batch-frame", payload, tid)

    def _submit_video(self, endpoint, payload, tid=None):
        resp = requests.post(f"{BASE_URL}{endpoint}", json=payload,
                             headers=self._get_headers(), timeout=REQUEST_TIMEOUT)
        data = resp.json()
        if not data.get("success"):
            raise Exception(data.get("error", "Unknown error"))
        task_id = data.get("data", {}).get("task_id")
        if not task_id:
            raise Exception("No task_id")
        self._log(f"Task: {task_id[:20]}...", "SUCCESS", tid)
        self._poll_video(task_id, tid)

    def _poll_video(self, task_id, tid=None):
        while self.is_generating:
            try:
                resp = requests.get(f"{BASE_URL}/video/status/{task_id}",
                                    headers=self._get_headers(), timeout=30)
                result = resp.json().get("data", {})
                status = result.get("status", "unknown")
                if status == "completed":
                    self.last_video_result = result
                    self._download_videos(result, tid)
                    return
                elif status in ("failed", "error"):
                    raise Exception(result.get("error", "Failed"))
                time.sleep(VIDEO_POLL_INTERVAL)
            except Exception as e:
                if "failed" in str(e).lower():
                    raise
                time.sleep(VIDEO_POLL_INTERVAL)

    def _download_videos(self, result, tid=None):
        videos = result.get("videos", [])
        self.output_dir.mkdir(parents=True, exist_ok=True)
        for i, v in enumerate(videos):
            url = v.get("fifeUrl")
            if url:
                try:
                    r = requests.get(url, timeout=120)
                    fn = self.output_dir / f"video_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}_{i+1}.mp4"
                    fn.write_bytes(r.content)
                    self._log(f"Saved: {fn.name}", "SUCCESS", tid)
                except Exception as e:
                    self._log(f"Download error: {e}", "ERROR", tid)

    # ═══════════ IMAGE MODES ═══════════

    def _image_banana(self, prompt, tid=None):
        display = self.model_key.get()
        api_key = BANANA_NAME_TO_KEY.get(display, display)
        self._log(f"Banana ({display})...", "INFO", tid)
        payload = {"prompt": prompt, "aspect_ratio": self.aspect_ratio.get(),
                   "num_images": self.generation_count.get(), "model_key": api_key}
        if self.reference_images:
            payload["reference_images"] = self.reference_images
        resp = requests.post(f"{BASE_URL}/image/banana/generate", json=payload,
                             headers=self._get_headers(), timeout=REQUEST_TIMEOUT)
        data = resp.json()
        if not data.get("success"):
            raise Exception(data.get("error", "Unknown error"))
        media = data.get("data", {}).get("media", [])
        self.output_dir.mkdir(parents=True, exist_ok=True)
        for i, m in enumerate(media):
            url = m.get("fifeUrl")
            if url:
                try:
                    r = requests.get(url, timeout=60)
                    fn = self.output_dir / f"banana_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}_{i+1}.png"
                    fn.write_bytes(r.content)
                    self._log(f"Saved: {fn.name}", "SUCCESS", tid)
                except Exception as e:
                    self._log(f"Error: {e}", "ERROR", tid)

    def _image_imagen(self, prompt, tid=None):
        self._log("IMAGEN 3.5...", "INFO", tid)
        payload = {"prompt": prompt, "aspect_ratio": self.aspect_ratio.get()}
        resp = requests.post(f"{BASE_URL}/image/generate", json=payload,
                             headers=self._get_headers(), timeout=REQUEST_TIMEOUT)
        data = resp.json()
        if not data.get("success"):
            raise Exception(data.get("error", "Unknown error"))
        media_id = data.get("data", {}).get("mediaGenerationId")
        if media_id:
            self._log(f"ID: {media_id[:30]}...", "SUCCESS", tid)

    # ═══════════ UPSAMPLE ═══════════

    def upsample_video(self):
        if not self.last_video_result:
            messagebox.showwarning("Warning", "Generate video first")
            return
        videos = self.last_video_result.get("videos", [])
        if not videos:
            return
        media_id = videos[0].get("mediaGenerationId")
        if not media_id:
            messagebox.showerror("Error", "No mediaGenerationId")
            return
        self.is_generating = True
        self.generate_btn.config(state=tk.DISABLED)
        self.progress_bar.config(mode='indeterminate')
        self.progress_bar.start()

        def do_upsample():
            try:
                self._log("Upsampling to 4K...", "INFO")
                payload = {"media_generation_id": media_id, "aspect_ratio": self.aspect_ratio.get()}
                resp = requests.post(f"{BASE_URL}/video/upsample", json=payload,
                                     headers=self._get_headers(), timeout=REQUEST_TIMEOUT)
                data = resp.json()
                if data.get("success"):
                    tid = data.get("data", {}).get("task_id")
                    self._poll_video(tid)
                    self._log("Upsample done!", "SUCCESS")
                else:
                    raise Exception(data.get("error", "Failed"))
            except Exception as e:
                self._log(f"Upsample error: {e}", "ERROR")
            finally:
                self.is_generating = False
                self.root.after(0, self._reset_ui)

        threading.Thread(target=do_upsample, daemon=True).start()


# ════════════════════════════════════════════════════════════════════
# TAB: DONATE
# ════════════════════════════════════════════════════════════════════

class DonateTab:
    def __init__(self, notebook, app: 'VarAgentGUI'):
        self.app = app
        self.frame = ttk.Frame(notebook)
        self._build()

    def _build(self):
        outer = ttk.Frame(self.frame)
        outer.pack(expand=True)  # center vertically

        card = ttk.Frame(outer, style="Card.TFrame", padding=32)
        card.pack(padx=40, pady=40)

        # Header text
        lines = [
            "Пока Вар ещё на пути к первым миллионам на YouTube,",
            "вы можете сказать спасибо Вару,",
            "если программа оказалась вам полезной,",
            "по реквизитам ниже:",
        ]
        for line in lines:
            ttk.Label(card, text=line, style="Card.TLabel",
                      font=("Segoe UI", 11)).pack(anchor=tk.W, pady=1)

        ttk.Separator(card, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=16)

        def _card_row(icon, label, action_text, action):
            row = ttk.Frame(card, style="Card.TFrame")
            row.pack(fill=tk.X, pady=6)
            ttk.Label(row, text=icon, font=("Segoe UI", 16), style="Card.TLabel").pack(side=tk.LEFT, padx=(0, 10))
            ttk.Label(row, text=label, style="Card.TLabel",
                      font=("Segoe UI", 12)).pack(side=tk.LEFT, expand=True, anchor=tk.W)
            btn = ttk.Button(row, text=action_text, command=action)
            btn.pack(side=tk.RIGHT, padx=(12, 0))

        CARD_NUM = "5599002019861089"
        def _copy_card():
            self.frame.clipboard_clear()
            self.frame.clipboard_append(CARD_NUM)
            self.frame.update()

        def _open(url):
            import webbrowser
            webbrowser.open(url)

        _card_row("\u20BD", f"Карта  {CARD_NUM}", "Скопировать", _copy_card)
        _card_row("\u20BD", "ЮMoney", "Открыть",
                  lambda: _open("https://yoomoney.ru/to/410017958835828"))
        _card_row("$ \u20AC \u20BF", "DeStream (USD / EUR / BTC)",
                  "Открыть", lambda: _open("https://destream.net/live/VARGART/don"))

        ttk.Separator(card, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=16)

        # ── Обновления ──────────────────────────────────────────────
        upd_row = ttk.Frame(card, style="Card.TFrame")
        upd_row.pack(fill=tk.X, pady=6)
        ttk.Label(upd_row, text="↑", font=("Segoe UI", 16), style="Card.TLabel").pack(side=tk.LEFT, padx=(0, 10))
        self._upd_label = ttk.Label(upd_row, text="Обновления программы", style="Card.TLabel", font=("Segoe UI", 12))
        self._upd_label.pack(side=tk.LEFT, expand=True, anchor=tk.W)
        ttk.Button(upd_row, text="Перезапустить",
                   command=self._restart).pack(side=tk.RIGHT, padx=(4, 0))
        self._upd_btn = ttk.Button(upd_row, text="Проверить", command=self._check_updates)
        self._upd_btn.pack(side=tk.RIGHT, padx=(12, 0))

        ttk.Separator(card, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=16)

        _card_row("\u2708", "Написать Вару",
                  "Telegram", lambda: _open("https://t.me/vargartor"))

    def _restart(self):
        import subprocess
        # Force .env values into os.environ so new process inherits fresh config
        try:
            from dotenv import load_dotenv
            load_dotenv(str(AGENT_DIR / '.env'), override=True)
        except Exception:
            pass
        subprocess.Popen([sys.executable] + sys.argv)
        self.app.root.destroy()

    def _check_updates(self):
        self._upd_btn.config(state='disabled', text='Проверка...')
        self._upd_label.config(text='Проверка обновлений...')

        def _do():
            try:
                import importlib, modules.updater as _mu
                importlib.reload(_mu)
                return _mu.check_updates(SCRIPT_DIR)
            except Exception as e:
                return {'available': False, 'error': str(e)}

        def _done(result):
            self._upd_btn.config(state='normal', text='Проверить')
            if result.get('error'):
                self._upd_label.config(text=f"Ошибка: {result['error']}")
                return
            if not result['available']:
                self._upd_label.config(text="Обновлений нет — у вас актуальная версия")
                return
            changelog = result.get('changelog', [])
            n = len(result.get('changed_files', []))
            self._upd_label.config(text=f"Доступно обновление v{result['version']} ({n} файлов)")
            msg = "Доступно обновление!\n\n"
            msg += "\n".join(f"• {c}" for c in changelog)
            msg += f"\n\nИзменено файлов: {n}"
            msg += "\n\nУстановить?"
            if messagebox.askyesno("Обновление VarAgent", msg):
                self._install_updates()

        import threading
        threading.Thread(target=lambda: self.frame.after(0, _done, _do()), daemon=True).start()

    def _install_updates(self):
        self._upd_btn.config(state='disabled', text='Установка...')
        self._upd_label.config(text='Установка обновления...')

        def _do():
            try:
                import importlib, modules.updater as _mu
                importlib.reload(_mu)
                return _mu.install_update(SCRIPT_DIR, progress_cb=lambda m: self.app.log(m, tab='pipeline'))
            except Exception as e:
                return {'ok': False, 'error': str(e)}

        def _done(result):
            self._upd_btn.config(state='normal', text='Проверить')
            if result.get('ok'):
                n = len(result.get('installed', []))
                needs_restart = result.get('requires_restart', False)
                if needs_restart:
                    self._upd_label.config(text=f"Установлено ({n} файлов). Перезапустите программу.")
                    messagebox.showinfo("Обновление установлено",
                        f"Установлено файлов: {n}\n\nПерезапустите VarAgent для применения изменений.")
                else:
                    self._upd_label.config(text=f"Установлено ({n} файлов). Готово.")
                    messagebox.showinfo("Обновление установлено",
                        f"Установлено файлов: {n}\n\nОбновление применено, перезапуск не нужен.")
            else:
                self._upd_label.config(text=f"Ошибка установки: {result['error']}")
                messagebox.showerror("Ошибка обновления", result['error'])

        import threading
        threading.Thread(target=lambda: self.frame.after(0, _done, _do()), daemon=True).start()


# ════════════════════════════════════════════════════════════════════
# TAB 7: BRAINSTORM  (YouTube channel transcription)
# ════════════════════════════════════════════════════════════════════

class BrainstormTab:
    """YouTube channel subtitle downloader + script builder via AssemblyAI."""

    SORT_OPTIONS = ["latest", "popular", "oldest", "random"]
    SORT_LABELS  = ["Свежие", "Популярные", "Старые", "Случайные"]

    def __init__(self, notebook, app: 'VarAgentGUI'):
        self.app  = app
        self.frame = ttk.Frame(notebook)
        self._stop_event = threading.Event()
        self._running    = False
        self._build()

    # ── UI ───────────────────────────────────────────────────────────────

    def _build(self):
        outer = ttk.Frame(self.frame)
        outer.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

        # ── TOP: controls card ────────────────────────────────────────
        top_card = ttk.Frame(outer, style="Card.TFrame", padding=14)
        top_card.pack(fill=tk.X, pady=(0, 6))

        # Row 1 — channel URL
        r1 = ttk.Frame(top_card, style="Card.TFrame")
        r1.pack(fill=tk.X, pady=3)
        ttk.Label(r1, text="Канал YouTube:", style="Card.TLabel", width=16).pack(side=tk.LEFT)
        self._channel_var = tk.StringVar(value="https://www.youtube.com/@/videos")
        ttk.Entry(r1, textvariable=self._channel_var, width=60).pack(side=tk.LEFT, padx=(4, 0), fill=tk.X, expand=True)

        # Row 2 — sort + max videos + output folder
        r2 = ttk.Frame(top_card, style="Card.TFrame")
        r2.pack(fill=tk.X, pady=3)

        ttk.Label(r2, text="Сортировка:", style="Card.TLabel", width=16).pack(side=tk.LEFT)
        self._sort_var = tk.StringVar(value="Свежие")
        sort_cb = ttk.Combobox(r2, textvariable=self._sort_var,
                               values=self.SORT_LABELS, width=12, state="readonly")
        sort_cb.pack(side=tk.LEFT, padx=(4, 16))

        ttk.Label(r2, text="Макс. видео:", style="Card.TLabel").pack(side=tk.LEFT)
        self._max_var = tk.StringVar(value="0")
        max_e = ttk.Entry(r2, textvariable=self._max_var, width=6)
        max_e.pack(side=tk.LEFT, padx=(4, 4))
        ttk.Label(r2, text="(0 = все)", style="Dim.TLabel").pack(side=tk.LEFT, padx=(0, 16))

        # Row 3 — output directory
        r3 = ttk.Frame(top_card, style="Card.TFrame")
        r3.pack(fill=tk.X, pady=3)
        ttk.Label(r3, text="Папка вывода:", style="Card.TLabel", width=16).pack(side=tk.LEFT)
        default_out = str(SCRIPT_DIR / "projects" / "yt_subs")
        self._out_var = tk.StringVar(value=default_out)
        ttk.Entry(r3, textvariable=self._out_var, width=55).pack(side=tk.LEFT, padx=(4, 4), fill=tk.X, expand=True)
        ttk.Button(r3, text="Add",
                   command=lambda: self._out_var.set(
                       filedialog.askdirectory(title="Выберите папку для субтитров") or self._out_var.get()
                   )).pack(side=tk.LEFT, padx=4)

        # Row 4 — yt-dlp path (optional)
        r4 = ttk.Frame(top_card, style="Card.TFrame")
        r4.pack(fill=tk.X, pady=3)
        ttk.Label(r4, text="yt-dlp путь:", style="Card.TLabel", width=16).pack(side=tk.LEFT)
        self._ytdlp_var = tk.StringVar(value="")
        ttk.Entry(r4, textvariable=self._ytdlp_var, width=40).pack(side=tk.LEFT, padx=(4, 4))
        ttk.Label(r4, text="(пусто = авто)", style="Dim.TLabel").pack(side=tk.LEFT, padx=(0, 16))
        ttk.Button(r4, text="Add",
                   command=lambda: self._ytdlp_var.set(
                       filedialog.askopenfilename(
                           title="Выберите yt-dlp",
                           filetypes=[("yt-dlp", "yt-dlp.exe yt-dlp"), ("All", "*.*")]
                       ) or self._ytdlp_var.get()
                   )).pack(side=tk.LEFT, padx=4)

        # Row 5 — subtitle download options
        r5 = ttk.Frame(top_card, style="Card.TFrame")
        r5.pack(fill=tk.X, pady=3)
        self._try_subs_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(r5, text="Сначала скачать субтитры (без AssemblyAI)",
                        variable=self._try_subs_var, style="Card.TCheckbutton").pack(side=tk.LEFT)
        ttk.Label(r5, text="Язык:", style="Card.TLabel").pack(side=tk.LEFT, padx=(16, 0))
        self._subs_lang_var = tk.StringVar(value="auto")
        # auto = skip yt-dlp subs, use AssemblyAI language_detection straight away.
        # zh/zh-Hans/zh-Hant/zh-CN/zh-TW — YouTube использует разные коды для китайского;
        # пользователю удобнее всего выбирать конкретный вариант (или auto).
        ttk.Combobox(r5, textvariable=self._subs_lang_var,
                     values=["auto",
                             "ru", "en",
                             "zh", "zh-Hans", "zh-Hant", "zh-CN", "zh-TW",
                             "ja", "ko", "vi", "th", "id",
                             "es", "pt", "fr", "de", "it", "pl", "nl", "sv",
                             "tr", "uk", "ar", "hi"],
                     width=8, state="readonly").pack(side=tk.LEFT, padx=4)
        ttk.Label(r5, text="Режим:", style="Card.TLabel").pack(side=tk.LEFT, padx=(16, 0))
        self._subs_segmode_var = tk.StringVar(value="sentences")
        ttk.Combobox(r5, textvariable=self._subs_segmode_var,
                     values=["words", "sentences", "paragraphs"],
                     width=11, state="readonly").pack(side=tk.LEFT, padx=4)

        # ── Action buttons (TOP RIGHT area) ──────────────────────────
        btn_row = ttk.Frame(top_card, style="Card.TFrame")
        btn_row.pack(fill=tk.X, pady=(10, 0))

        self._run_btn = ttk.Button(btn_row, text="▶  Скачать субтитры",
                                   style="Accent.TButton", command=self._start)
        self._run_btn.pack(side=tk.LEFT, padx=(0, 8))

        self._stop_btn = ttk.Button(btn_row, text="■  Стоп", command=self._stop,
                                    state="disabled")
        self._stop_btn.pack(side=tk.LEFT, padx=(0, 16))

        self._open_btn = ttk.Button(btn_row, text="Открыть папку",
                                    command=self._open_out_dir)
        self._open_btn.pack(side=tk.LEFT)

        self._status_lbl = ttk.Label(btn_row, text="", style="Dim.TLabel")
        self._status_lbl.pack(side=tk.RIGHT, padx=8)

        # ── Progress bar ──────────────────────────────────────────────
        self._progress = ttk.Progressbar(outer, style="Green.Horizontal.TProgressbar",
                                         mode="determinate", length=400)
        self._progress.pack(fill=tk.X, pady=(0, 4))

        # ── Log ───────────────────────────────────────────────────────
        log_card = ttk.Frame(outer, style="Card.TFrame", padding=10)
        log_card.pack(fill=tk.BOTH, expand=True)
        ttk.Label(log_card, text="Log", style="Section.TLabel").pack(anchor=tk.W)
        self.log_widget = self.app.create_log_widget(log_card)

    # ── Helpers ──────────────────────────────────────────────────────────

    def _log(self, msg: str, level: str = "INFO"):
        self.app.log(msg, level, tab="brainstorm")

    def _set_status(self, txt: str):
        self.frame.after(0, lambda: self._status_lbl.config(text=txt))

    def _set_progress(self, val: float, maximum: float = 100.0):
        self.frame.after(0, lambda: (
            self._progress.config(maximum=max(1, maximum), value=val)
        ))

    def _open_out_dir(self):
        p = self._out_var.get()
        if p and Path(p).exists():
            if sys.platform == "win32":
                os.startfile(p)
            else:
                subprocess.Popen(["open" if sys.platform == "darwin" else "xdg-open", p])

    # ── Run ──────────────────────────────────────────────────────────────

    def _start(self):
        if self._running:
            return

        channel = self._channel_var.get().strip()
        if not channel or channel == "https://www.youtube.com/@/videos":
            messagebox.showwarning("Brainstorm", "Введите URL канала YouTube")
            return

        out_dir = self._out_var.get().strip()
        if not out_dir:
            messagebox.showwarning("Brainstorm", "Укажите папку вывода")
            return

        try:
            max_v = int(self._max_var.get() or "0")
        except ValueError:
            max_v = 0

        sort_label = self._sort_var.get()
        try:
            sort_mode = self.SORT_OPTIONS[self.SORT_LABELS.index(sort_label)]
        except (ValueError, IndexError):
            sort_mode = "latest"

        ytdlp_path = self._ytdlp_var.get().strip() or None

        self._running = True
        self._stop_event.clear()
        self._run_btn.config(state="disabled")
        self._stop_btn.config(state="normal")
        self._set_status("Запущено...")
        self._set_progress(0)
        self.log_widget.delete("1.0", tk.END)

        def _worker():
            try:
                from modules.yt_transcriber import run_channel_transcription

                total_known = [0]

                def _cb(msg: str, level: str = "INFO"):
                    self._log(msg, level)
                    # parse progress from "Транскрибируем N видео"
                    if msg.startswith("Транскрибируем"):
                        import re as _re
                        m = _re.search(r"(\d+) видео", msg)
                        if m:
                            total_known[0] = int(m.group(1))
                    # parse "[i/N]" lines
                    m2 = __import__('re').match(r"\[(\d+)/(\d+)\]", msg.strip())
                    if m2:
                        cur, tot = int(m2.group(1)), int(m2.group(2))
                        total_known[0] = tot
                        self._set_progress(cur - 1, tot)
                        self._set_status(f"{cur}/{tot}")

                result = run_channel_transcription(
                    channel_url=channel,
                    out_dir=Path(out_dir),
                    max_videos=max_v,
                    sort_mode=sort_mode,
                    ytdlp_path=ytdlp_path,
                    progress_cb=_cb,
                    stop_event=self._stop_event,
                    try_subs_first=self._try_subs_var.get(),
                    subs_lang=self._subs_lang_var.get(),
                    seg_mode=self._subs_segmode_var.get(),
                )
                done, total = result["done"], result["total"]
                self._set_progress(total, total)
                self._set_status(f"Готово: {done}/{total}")
                self._log(f"Результат в: {result['srt_dir']}", "SUCCESS")

            except Exception as e:
                self._log(f"FATAL: {e}", "ERROR")
                self._set_status(f"Ошибка: {e}")
            finally:
                self._running = False
                self.frame.after(0, lambda: (
                    self._run_btn.config(state="normal"),
                    self._stop_btn.config(state="disabled"),
                ))

        threading.Thread(target=_worker, daemon=True).start()

    def _stop(self):
        self._stop_event.set()
        self._set_status("Остановка...")
        self._log("Запрошена остановка...", "WARNING")


# ════════════════════════════════════════════════════════════════════
# TAB: GPT CHAT
# ════════════════════════════════════════════════════════════════════

class ChatTab:
    """Direct chat with GPT models. Session history maintained within tab."""

    def __init__(self, notebook, app: 'VarAgentGUI'):
        self.app = app
        self.root = app.root
        self.frame = ttk.Frame(notebook)
        self.messages = []  # [(role, content, files)]
        self.attached_files = []
        self.current_session_file = None
        self.sessions_dir = SCRIPT_DIR / 'chat_sessions'
        self.sessions_dir.mkdir(exist_ok=True)
        self._build()

    def _build(self):
        outer = ttk.Frame(self.frame)
        outer.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

        # ── TOP: Model selection + controls ──────────────────────────────
        top = ttk.Frame(outer, style="Card.TFrame", padding=10)
        top.pack(fill=tk.X, pady=(0, 6))

        ttk.Label(top, text="Model:", style="Card.TLabel").pack(side=tk.LEFT, padx=(0, 4))
        self.model_var = tk.StringVar(value='gpt-5.4')
        ttk.Combobox(top, textvariable=self.model_var,
                     values=['gpt-5.5', 'gpt-5.4', 'gpt-5.4-mini', 'gpt-5.3-codex'],
                     width=18, state='readonly').pack(side=tk.LEFT, padx=4)

        ttk.Button(top, text="New Session", command=self._new_session).pack(side=tk.LEFT, padx=(12, 0))
        ttk.Button(top, text="Save", command=self._save_session).pack(side=tk.LEFT, padx=4)

        # Local sessions dropdown
        ttk.Label(top, text="Local:", style="Card.TLabel").pack(side=tk.LEFT, padx=(12, 4))
        self.local_session_var = tk.StringVar()
        self.local_session_combo = ttk.Combobox(top, textvariable=self.local_session_var,
                                                 width=25, state='readonly')
        self.local_session_combo.pack(side=tk.LEFT, padx=4)
        self.local_session_combo.bind('<<ComboboxSelected>>', self._on_local_session_selected)
        ttk.Button(top, text="⟳", command=self._refresh_local_sessions, width=3).pack(side=tk.LEFT, padx=2)

        # Codex sessions dropdown
        ttk.Label(top, text="Codex:", style="Card.TLabel").pack(side=tk.LEFT, padx=(12, 4))
        self.codex_session_var = tk.StringVar()
        self.codex_session_combo = ttk.Combobox(top, textvariable=self.codex_session_var,
                                                 width=25, state='readonly')
        self.codex_session_combo.pack(side=tk.LEFT, padx=4)
        self.codex_session_combo.bind('<<ComboboxSelected>>', self._on_codex_session_selected)
        ttk.Button(top, text="⟳", command=self._refresh_codex_sessions, width=3).pack(side=tk.LEFT, padx=2)
        ttk.Button(top, text="Attach Files", command=self._attach_files).pack(side=tk.LEFT, padx=4)

        self.session_label = ttk.Label(top, text="New session", style="Dim.TLabel")
        self.session_label.pack(side=tk.LEFT, padx=8)

        self.files_label = ttk.Label(top, text="", style="Dim.TLabel")
        self.files_label.pack(side=tk.LEFT, padx=8)

        # ── MIDDLE: Chat history ─────────────────────────────────────────
        history_frame = ttk.Frame(outer)
        history_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 6))

        scroll_y = ttk.Scrollbar(history_frame)
        scroll_y.pack(side=tk.RIGHT, fill=tk.Y)

        self.history_text = tk.Text(
            history_frame,
            wrap=tk.WORD,
            yscrollcommand=scroll_y.set,
            bg=COLORS['bg_input'],
            fg=COLORS['text'],
            font=('Segoe UI', 10),
            undo=True
        )
        self.history_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll_y.config(command=self.history_text.yview)

        # Tags for formatting
        self.history_text.tag_config('user', foreground='#60a5fa', font=('Segoe UI', 10, 'bold'))
        self.history_text.tag_config('assistant', foreground='#34d399', font=('Segoe UI', 10, 'bold'))
        self.history_text.tag_config('system', foreground='#fbbf24', font=('Segoe UI', 10, 'italic'))

        # ── BOTTOM: Input + Send ─────────────────────────────────────────
        bottom = ttk.Frame(outer)
        bottom.pack(fill=tk.X)

        input_frame = ttk.Frame(bottom)
        input_frame.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)

        self.input_text = tk.Text(
            input_frame,
            height=3,
            wrap=tk.WORD,
            bg=COLORS['bg_input'],
            fg=COLORS['text'],
            font=('Segoe UI', 10)
        )
        self.input_text.pack(fill=tk.BOTH, expand=True)

        def _on_enter(e):
            if not e.state & 0x1:  # If Shift is not pressed
                self._send_message()
                return 'break'  # Prevent default newline

        self.input_text.bind('<Return>', _on_enter)

        btn_frame = ttk.Frame(bottom)
        btn_frame.pack(side=tk.RIGHT, padx=(8, 0))

        self.send_btn = ttk.Button(btn_frame, text="Send\n(Enter)",
                                     command=self._send_message, style="Accent.TButton")
        self.send_btn.pack(fill=tk.BOTH, expand=True)

        # Load sessions lists
        self._refresh_local_sessions()
        self._refresh_codex_sessions()

    def _refresh_local_sessions(self):
        """Scan chat_sessions/*.json and populate dropdown."""
        sessions = []

        if self.sessions_dir.exists():
            for json_file in sorted(self.sessions_dir.glob('*.json'),
                                     key=lambda x: x.stat().st_mtime, reverse=True):
                try:
                    import json
                    data = json.loads(json_file.read_text(encoding='utf-8'))
                    created = data.get('created', '')
                    if created:
                        from datetime import datetime
                        date_obj = datetime.fromisoformat(created)
                        date_str = date_obj.strftime('%Y-%m-%d %H:%M')
                    else:
                        mtime = json_file.stat().st_mtime
                        from datetime import datetime
                        date_str = datetime.fromtimestamp(mtime).strftime('%Y-%m-%d %H:%M')
                    sessions.append(f"{json_file.stem} | {date_str}")
                except Exception:
                    sessions.append(json_file.stem)

        self.local_session_combo['values'] = sessions
        if sessions:
            self.local_session_var.set('')  # Clear selection

    def _on_local_session_selected(self, event=None):
        """Load selected local session from chat_sessions/."""
        selected = self.local_session_var.get()
        if not selected:
            return

        # Extract filename from "name | date" format
        session_name = selected.split(' | ')[0]
        session_file = self.sessions_dir / f"{session_name}.json"

        if not session_file.exists():
            return

        try:
            import json
            session_data = json.loads(session_file.read_text(encoding='utf-8'))

            # Clear current
            self.messages.clear()
            self.history_text.delete('1.0', tk.END)

            # Load model
            if 'model' in session_data:
                self.model_var.set(session_data['model'])

            # Load messages
            for msg in session_data.get('messages', []):
                role = msg['role']
                content = msg['content']
                files = msg.get('files')
                self.messages.append((role, content, files))
                self._add_message(role, content, files)

            self.current_session_file = session_file
            self.session_label.config(text=f"💾 {session_name}")
        except Exception as e:
            self._add_message('system', f"Failed to load session: {e}", None)

    def _refresh_codex_sessions(self):
        """Scan ~/.codex/sessions/*.jsonl and populate dropdown."""
        codex_sessions_dir = Path.home() / '.codex' / 'sessions'
        sessions = []

        if codex_sessions_dir.exists():
            for jsonl_file in sorted(codex_sessions_dir.glob('*.jsonl'),
                                      key=lambda x: x.stat().st_mtime, reverse=True):
                # Parse first line to get thread name/id
                try:
                    first_line = jsonl_file.read_text(encoding='utf-8').split('\n', 1)[0]
                    import json
                    data = json.loads(first_line)
                    thread_name = data.get('thread_name') or data.get('thread_id') or jsonl_file.stem
                    mtime = jsonl_file.stat().st_mtime
                    from datetime import datetime
                    date_str = datetime.fromtimestamp(mtime).strftime('%Y-%m-%d %H:%M')
                    sessions.append(f"{thread_name} | {date_str}")
                except Exception:
                    sessions.append(jsonl_file.stem)

        self.codex_session_combo['values'] = sessions
        if sessions:
            self.codex_session_var.set('')  # Clear selection

    def _on_codex_session_selected(self, event=None):
        """Load selected Codex session from ~/.codex/sessions/."""
        selected = self.codex_session_var.get()
        if not selected:
            return

        # Extract filename from "name | date" format
        session_name = selected.split(' | ')[0]

        codex_sessions_dir = Path.home() / '.codex' / 'sessions'
        # Find matching file
        matching = None
        for jsonl_file in codex_sessions_dir.glob('*.jsonl'):
            try:
                first_line = jsonl_file.read_text(encoding='utf-8').split('\n', 1)[0]
                import json
                data = json.loads(first_line)
                thread_name = data.get('thread_name') or data.get('thread_id') or jsonl_file.stem
                if thread_name == session_name:
                    matching = jsonl_file
                    break
            except Exception:
                if jsonl_file.stem == session_name:
                    matching = jsonl_file
                    break

        if not matching:
            return

        # Parse JSONL and load messages
        self.messages.clear()
        self.history_text.delete('1.0', tk.END)

        try:
            lines = matching.read_text(encoding='utf-8').strip().split('\n')
            import json
            for line in lines:
                if not line.strip():
                    continue
                msg = json.loads(line)
                # Extract role and content from Codex JSONL format
                role = msg.get('role') or msg.get('type', 'user')
                content = msg.get('content') or msg.get('text', '')
                if role in ('user', 'assistant', 'system'):
                    self.messages.append((role, content, None))
                    self._add_message(role, content, None)

            self.current_session_file = None  # Codex sessions are read-only
            self.session_label.config(text=f"Codex: {session_name}")
        except Exception as e:
            self._add_message('system', f"Failed to load Codex session: {e}", None)

    def _new_session(self):
        """Start a new chat session (clears history)."""
        if self.messages and self.current_session_file is None:
            # Ask to save unsaved session
            from tkinter import messagebox
            if messagebox.askyesno("Save session?", "Save current session before starting new one?"):
                self._save_session()

        self.messages.clear()
        self.attached_files.clear()
        self.current_session_file = None
        self.history_text.config(state='normal')
        self.history_text.delete('1.0', tk.END)
        self.history_text.config(state='disabled')
        self.files_label.config(text="")
        self.session_label.config(text="New session")
        self._add_message('system', 'Новая сессия. Начните диалог.')

    def _save_session(self):
        """Save current session to file."""
        import json
        from datetime import datetime
        from tkinter import simpledialog

        if not self.messages:
            return

        # Ask for session name
        default_name = datetime.now().strftime("Chat_%Y%m%d_%H%M%S")
        name = simpledialog.askstring("Save Session", "Session name:", initialvalue=default_name)
        if not name:
            return

        # Save to file
        session_file = self.sessions_dir / f"{name}.json"
        session_data = {
            'model': self.model_var.get(),
            'created': datetime.now().isoformat(),
            'messages': [
                {'role': role, 'content': content, 'files': files}
                for role, content, files in self.messages
            ]
        }

        session_file.write_text(json.dumps(session_data, ensure_ascii=False, indent=2), encoding='utf-8')
        self.current_session_file = session_file
        self.session_label.config(text=f"💾 {name}")
        self._add_message('system', f'Сессия сохранена: {name}')
        # Refresh dropdown
        self._refresh_local_sessions()

    def _attach_files(self):
        from tkinter import filedialog
        files = filedialog.askopenfilenames(
            title="Attach files to message",
            filetypes=[("All files", "*.*")]
        )
        if files:
            self.attached_files.extend(files)
            count = len(self.attached_files)
            names = ', '.join(Path(f).name for f in self.attached_files[:3])
            if count > 3:
                names += f' +{count-3} more'
            self.files_label.config(text=f"📎 {count}: {names}")

    def _add_message(self, role, content, files=None):
        # Role prefix
        if role == 'user':
            prefix = "User: "
            tag = 'user'
        elif role == 'assistant':
            prefix = "GPT: "
            tag = 'assistant'
        else:
            prefix = ""
            tag = 'system'

        self.history_text.insert(tk.END, prefix, tag)
        self.history_text.insert(tk.END, content + '\n')

        if files:
            file_names = ', '.join(Path(f).name for f in files)
            self.history_text.insert(tk.END, f"   Files: {file_names}\n", 'system')

        self.history_text.insert(tk.END, '\n')
        self.history_text.see(tk.END)

    def _send_message(self):
        message = self.input_text.get('1.0', tk.END).strip()
        if not message:
            return

        # Add user message to history
        files = list(self.attached_files) if self.attached_files else None
        self.messages.append(('user', message, files))
        self._add_message('user', message, files)

        # Clear input
        self.input_text.delete('1.0', tk.END)
        self.attached_files.clear()
        self.files_label.config(text="")

        # Disable send while processing
        self.send_btn.config(state=tk.DISABLED, text="Sending...")

        # Send to GPT in background thread
        threading.Thread(target=self._process_message, daemon=True).start()

    def _process_message(self):
        try:
            import tempfile, subprocess, json
            from pathlib import Path

            # Create temp dir for this request
            tmpdir = Path(tempfile.mkdtemp())

            # Build full conversation prompt with history
            model_name = self.model_var.get()
            conversation = [f"System: You are {model_name}. The user is chatting with you via Codex CLI."]

            for role, content, files in self.messages[:-1]:  # All except last (current) message
                if role == 'user':
                    conversation.append(f"User: {content}")
                elif role == 'assistant':
                    conversation.append(f"Assistant: {content}")

            # Add current message
            current_msg = self.messages[-1][1]

            # Build full prompt with context
            full_prompt = "\n".join(conversation) + f"\n\nUser: {current_msg}\n\nAssistant:"

            # Prepare codex command
            codex_exe = Path(getattr(config, 'CODEX_EXE_PATH', ''))
            if not codex_exe.exists():
                codex_exe = SCRIPT_DIR / 'Codex' / 'codex-x86_64-pc-windows-msvc.exe'

            if not codex_exe.exists():
                raise FileNotFoundError("Codex CLI not found")

            cmd = [
                str(codex_exe), 'exec',
                full_prompt,
                '--dangerously-bypass-approvals-and-sandbox',
                '--skip-git-repo-check',
                '-m', self.model_var.get(),
                '-C', str(tmpdir)
            ]

            # Add file attachments from current message only
            _, _, current_files = self.messages[-1]
            if current_files:
                for f in current_files:
                    cmd.extend(['--file', str(f)])

            # Execute
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='replace',
                timeout=120
            )

            # Extract response
            response = result.stdout.strip()
            if result.returncode != 0:
                response = f"Error: {result.stderr[:500]}"

            # Add assistant response
            self.messages.append(('assistant', response, None))
            self.root.after(0, lambda: self._add_message('assistant', response))

            # Auto-save if this is a named session
            if self.current_session_file:
                self.root.after(0, self._auto_save)

        except Exception as e:
            error_msg = f"Error: {e}"
            self.root.after(0, lambda: self._add_message('system', error_msg))

        finally:
            self.root.after(0, lambda: self.send_btn.config(state=tk.NORMAL, text="Send\n(Enter)"))

    def _auto_save(self):
        """Auto-save current session without prompting."""
        if not self.current_session_file or not self.messages:
            return

        import json
        from datetime import datetime

        session_data = {
            'model': self.model_var.get(),
            'created': datetime.now().isoformat(),
            'messages': [
                {'role': role, 'content': content, 'files': files}
                for role, content, files in self.messages
            ]
        }

        try:
            self.current_session_file.write_text(
                json.dumps(session_data, ensure_ascii=False, indent=2),
                encoding='utf-8'
            )
        except Exception:
            pass  # Silent fail on auto-save


# ════════════════════════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════════════════════════

class ClaudeChatTab:
    """Direct chat with Claude through the unofficial claude-api package."""

    TEXT_EXTENSIONS = {'.txt', '.md', '.json', '.csv', '.py', '.js', '.ts', '.html', '.css', '.yaml', '.yml'}

    def __init__(self, notebook, app: 'VarAgentGUI'):
        self.app = app
        self.root = app.root
        self.frame = ttk.Frame(notebook)
        self.messages = []
        self.attached_files = []
        self.client = None
        self.conversation_id = None
        self.last_response = ""
        self.cookie_json_var = tk.StringVar(value=getattr(config, 'CLAUDE_COOKIE_JSON', '') or '')
        self.work_dir_var = tk.StringVar(value=getattr(config, 'CLAUDE_WORK_DIR', '') or '')
        self.auto_save_var = tk.BooleanVar(value=False)
        self.agent_files_var = tk.BooleanVar(value=True)
        self.destructive_ops_var = tk.BooleanVar(value=False)
        self.output_dir_var = tk.StringVar(value=str(SCRIPT_DIR / 'claude_outputs'))
        self.agent_sources = []
        self._build()

    def _build(self):
        outer = ttk.Frame(self.frame)
        outer.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

        top = ttk.Frame(outer, style="Card.TFrame", padding=10)
        top.pack(fill=tk.X, pady=(0, 6))

        row1 = ttk.Frame(top, style="Card.TFrame")
        row1.pack(fill=tk.X, pady=(0, 6))
        ttk.Label(row1, text="Cookie JSON:", style="Card.TLabel").pack(side=tk.LEFT)
        self.cookie_entry = tk.Entry(row1, textvariable=self.cookie_json_var,
                                     bg=COLORS['bg_input'], fg=COLORS['text'],
                                     insertbackground=COLORS['text'], relief=tk.FLAT)
        self.cookie_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=6)
        ttk.Button(row1, text="Browse", command=self._browse_cookie_json).pack(side=tk.LEFT, padx=2)
        ttk.Button(row1, text="Save .env", command=self._save_cookie_path).pack(side=tk.LEFT, padx=2)
        ttk.Button(row1, text="Reload", command=self._reset_client).pack(side=tk.LEFT, padx=2)

        row2 = ttk.Frame(top, style="Card.TFrame")
        row2.pack(fill=tk.X, pady=(0, 6))
        ttk.Label(row2, text="Work Folder:", style="Card.TLabel").pack(side=tk.LEFT)
        self.work_entry = tk.Entry(row2, textvariable=self.work_dir_var,
                                   bg=COLORS['bg_input'], fg=COLORS['text'],
                                   insertbackground=COLORS['text'], relief=tk.FLAT)
        self.work_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=6)
        ttk.Button(row2, text="Browse", command=self._browse_work_dir).pack(side=tk.LEFT, padx=2)
        ttk.Button(row2, text="Save .env", command=self._save_work_dir).pack(side=tk.LEFT, padx=2)

        row3 = ttk.Frame(top, style="Card.TFrame")
        row3.pack(fill=tk.X)
        ttk.Button(row3, text="New Chat", command=self._new_chat).pack(side=tk.LEFT, padx=(0, 4))
        ttk.Button(row3, text="Test Auth", command=self._test_auth).pack(side=tk.LEFT, padx=4)
        ttk.Button(row3, text="Attach Files", command=self._attach_files).pack(side=tk.LEFT, padx=(12, 4))
        ttk.Button(row3, text="Clear Files", command=self._clear_files).pack(side=tk.LEFT, padx=4)
        ttk.Button(row3, text="Save Last Answer", command=self._save_last_response).pack(side=tk.LEFT, padx=(12, 4))
        ttk.Checkbutton(row3, text="Auto-save answers", variable=self.auto_save_var).pack(side=tk.LEFT, padx=4)
        ttk.Checkbutton(row3, text="Agent files", variable=self.agent_files_var).pack(side=tk.LEFT, padx=4)
        ttk.Checkbutton(row3, text="Destructive ops", variable=self.destructive_ops_var).pack(side=tk.LEFT, padx=4)
        ttk.Button(row3, text="Output Folder", command=self._browse_output_dir).pack(side=tk.LEFT, padx=4)

        self.status_label = ttk.Label(top, text="Claude ready", style="Dim.TLabel")
        self.status_label.pack(anchor=tk.W, pady=(6, 0))
        self.files_label = ttk.Label(top, text="", style="Dim.TLabel")
        self.files_label.pack(anchor=tk.W)

        history_frame = ttk.Frame(outer)
        history_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 6))
        scroll_y = ttk.Scrollbar(history_frame)
        scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
        self.history_text = tk.Text(
            history_frame,
            wrap=tk.WORD,
            yscrollcommand=scroll_y.set,
            bg=COLORS['bg_input'],
            fg=COLORS['text'],
            font=('Segoe UI', 10),
            undo=True
        )
        self.history_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll_y.config(command=self.history_text.yview)
        self.history_text.tag_config('user', foreground='#60a5fa', font=('Segoe UI', 10, 'bold'))
        self.history_text.tag_config('assistant', foreground='#34d399', font=('Segoe UI', 10, 'bold'))
        self.history_text.tag_config('system', foreground='#fbbf24', font=('Segoe UI', 10, 'italic'))

        bottom = ttk.Frame(outer)
        bottom.pack(fill=tk.X)
        input_frame = ttk.Frame(bottom)
        input_frame.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        self.input_text = tk.Text(
            input_frame,
            height=3,
            wrap=tk.WORD,
            bg=COLORS['bg_input'],
            fg=COLORS['text'],
            insertbackground=COLORS['text'],
            font=('Segoe UI', 10)
        )
        self.input_text.pack(fill=tk.BOTH, expand=True)

        def _on_enter(e):
            if not e.state & 0x1:
                self._send_message()
                return 'break'
            return None

        self.input_text.bind('<Return>', _on_enter)
        btn_frame = ttk.Frame(bottom)
        btn_frame.pack(side=tk.RIGHT, padx=(8, 0))
        self.send_btn = ttk.Button(btn_frame, text="Send\n(Enter)",
                                   command=self._send_message, style="Accent.TButton")
        self.send_btn.pack(fill=tk.BOTH, expand=True)

        self._add_message('system', 'Select a Claude cookie JSON file, then start chatting.')

    def _set_status(self, text):
        self.status_label.config(text=text)

    def _add_message(self, role, content, files=None):
        if role == 'user':
            prefix, tag = "User: ", 'user'
        elif role == 'assistant':
            prefix, tag = "Claude: ", 'assistant'
        else:
            prefix, tag = "", 'system'
        self.history_text.insert(tk.END, prefix, tag)
        self.history_text.insert(tk.END, str(content).rstrip() + '\n')
        if files:
            file_names = ', '.join(Path(f).name for f in files)
            self.history_text.insert(tk.END, f"   Files: {file_names}\n", 'system')
        self.history_text.insert(tk.END, '\n')
        self.history_text.see(tk.END)

    def _write_env_value(self, key, value):
        env_path = AGENT_ENV_FILE
        line = f"{key}={value}\n"
        lines = env_path.read_text(encoding='utf-8').splitlines(keepends=True) if env_path.exists() else []
        found = False
        new_lines = []
        for existing in lines:
            if existing.lstrip().startswith(f"{key}="):
                new_lines.append(line)
                found = True
            else:
                new_lines.append(existing)
        if not found:
            if new_lines and not new_lines[-1].endswith(('\n', '\r')):
                new_lines[-1] += '\n'
            new_lines.append(line)
        env_path.write_text(''.join(new_lines), encoding='utf-8')
        os.environ[key] = value
        setattr(config, key, value)

    def _browse_cookie_json(self):
        path = filedialog.askopenfilename(
            title="Select Claude cookies JSON",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        if path:
            self.cookie_json_var.set(path)
            self._reset_client()

    def _save_cookie_path(self):
        path = self.cookie_json_var.get().strip()
        if not path:
            messagebox.showwarning("Claude", "Choose a cookie JSON file first.")
            return
        self._write_env_value('CLAUDE_COOKIE_JSON', path)
        self._set_status("Saved CLAUDE_COOKIE_JSON to agent/.env")
        self._reset_client()

    def _workspace_root(self):
        root = SCRIPT_DIR.resolve()
        selected = (self.work_dir_var.get().strip() or getattr(config, 'CLAUDE_WORK_DIR', '') or '').strip()
        if not selected:
            return root
        path = Path(selected).expanduser()
        if not path.is_absolute():
            path = root / path
        resolved = path.resolve()
        root_s = str(root).lower()
        resolved_s = str(resolved).lower()
        if resolved_s != root_s and not resolved_s.startswith(root_s + os.sep.lower()):
            raise ValueError("Claude work folder must be inside VARAGENT_API")
        return resolved

    def _browse_work_dir(self):
        path = filedialog.askdirectory(
            title="Choose Claude work folder inside VARAGENT_API",
            initialdir=str(SCRIPT_DIR),
        )
        if not path:
            return
        try:
            resolved = Path(path).resolve()
            root = SCRIPT_DIR.resolve()
            root_s = str(root).lower()
            resolved_s = str(resolved).lower()
            if resolved_s != root_s and not resolved_s.startswith(root_s + os.sep.lower()):
                messagebox.showwarning("Claude", "Choose a folder inside VARAGENT_API.")
                return
            self.work_dir_var.set(str(resolved))
            self._set_status(f"Claude work folder: {resolved}")
        except Exception as e:
            messagebox.showwarning("Claude", str(e))

    def _save_work_dir(self):
        try:
            work_dir = self._workspace_root()
        except Exception as e:
            messagebox.showwarning("Claude", str(e))
            return
        value = '' if work_dir == SCRIPT_DIR.resolve() else str(work_dir)
        self._write_env_value('CLAUDE_WORK_DIR', value)
        self._set_status(f"Saved Claude work folder: {work_dir}")

    def _reset_client(self):
        self.client = None
        self.conversation_id = None
        self._set_status("Claude client will reconnect on next send.")

    def _get_client(self):
        if self.client is None:
            from modules.claude_chat import ClaudeChatClient
            cookie_json = self.cookie_json_var.get().strip() or getattr(config, 'CLAUDE_COOKIE_JSON', '')
            raw_cookie = getattr(config, 'CLAUDE_COOKIE', '')
            self.client = ClaudeChatClient(cookie_json=cookie_json, raw_cookie=raw_cookie)
        return self.client

    def _test_auth(self):
        self._set_status("Testing Claude auth...")
        self.send_btn.config(state=tk.DISABLED)

        def _worker():
            try:
                count = len(self._get_client().list_conversations())
                self.root.after(0, lambda: self._set_status(f"Claude auth OK. Conversations: {count}"))
            except Exception as e:
                self.root.after(0, lambda: self._add_message('system', f"Claude auth failed: {e}"))
                self.root.after(0, lambda: self._set_status("Claude auth failed"))
            finally:
                self.root.after(0, lambda: self.send_btn.config(state=tk.NORMAL))

        threading.Thread(target=_worker, daemon=True).start()

    def _new_chat(self):
        self.messages.clear()
        self.attached_files.clear()
        self.conversation_id = None
        self.last_response = ""
        self.history_text.delete('1.0', tk.END)
        self.files_label.config(text="")
        self._set_status("New Claude conversation")
        self._add_message('system', 'New Claude chat.')

    def _attach_files(self):
        files = filedialog.askopenfilenames(
            title="Attach files to Claude message",
            filetypes=[
                ("Useful files", "*.txt *.md *.json *.csv *.py *.pdf"),
                ("All files", "*.*"),
            ],
        )
        if files:
            self.attached_files.extend(files)
            self._refresh_files_label()

    def _clear_files(self):
        self.attached_files.clear()
        self._refresh_files_label()

    def _refresh_files_label(self):
        if not self.attached_files:
            self.files_label.config(text="")
            return
        names = ', '.join(Path(f).name for f in self.attached_files[:4])
        if len(self.attached_files) > 4:
            names += f" +{len(self.attached_files) - 4} more"
        self.files_label.config(text=f"Files: {names}")

    def _parse_write_command(self, message):
        first, sep, rest = message.partition('\n')
        parts = first.strip().split(maxsplit=1)
        if not parts or parts[0].lower() not in ('/write', '/append'):
            return message, None, 'write'
        if len(parts) < 2 or not parts[1].strip():
            raise ValueError("Use /write path\\file.md on the first line, then your prompt.")
        mode = 'append' if parts[0].lower() == '/append' else 'write'
        prompt = rest.strip() if sep else ''
        if not prompt:
            prompt = f"Write the requested content for file: {parts[1].strip()}"
        return prompt, parts[1].strip().strip('"'), mode

    def _parse_agent_command(self, message):
        text = message.strip()
        if not text.lower().startswith('/agent'):
            return False, message
        prompt = text[6:].strip()
        if not prompt:
            prompt = "Inspect the local project and help with the requested file task."
        return True, prompt

    def _resolve_write_path(self, target):
        path = Path(target).expanduser()
        if not path.is_absolute():
            path = self._workspace_root() / path
        return self._safe_project_path(path)

    def _prepare_prompt(self, message, files):
        if not files:
            return message
        blocks = [message, "\n\nAttached file notes:"]
        budget = 90000
        for file_path in files[1:]:
            path = Path(file_path)
            if path.suffix.lower() not in self.TEXT_EXTENSIONS:
                blocks.append(f"\n[{path.name}] attached separately or binary; inspect by filename/context.")
                continue
            try:
                text = path.read_text(encoding='utf-8', errors='replace')
                remain = max(0, budget - sum(len(b) for b in blocks))
                if remain <= 0:
                    blocks.append("\n[Further text attachments skipped: prompt budget reached.]")
                    break
                if len(text) > remain:
                    text = text[:remain] + "\n[truncated]"
                blocks.append(f"\n--- {path.name} ---\n{text}\n--- end {path.name} ---")
            except Exception as e:
                blocks.append(f"\n[{path.name}] read failed: {e}")
        return ''.join(blocks)

    def _send_message(self):
        message = self.input_text.get('1.0', tk.END).strip()
        if not message:
            return
        try:
            prompt, write_target, write_mode = self._parse_write_command(message)
            agent_mode, prompt = self._parse_agent_command(prompt)
        except Exception as e:
            messagebox.showwarning("Claude", str(e))
            return
        files = list(self.attached_files)
        prompt_to_send = self._prepare_prompt(prompt, files)
        attachment = files[0] if files else None

        self.messages.append(('user', message, files or None))
        self._add_message('user', message, files or None)
        self.input_text.delete('1.0', tk.END)
        self.attached_files.clear()
        self._refresh_files_label()
        self.send_btn.config(state=tk.DISABLED, text="Sending...")
        self._set_status("Sending to Claude...")

        threading.Thread(target=self._process_message,
                         args=(prompt_to_send, attachment, write_target, write_mode, agent_mode),
                         daemon=True).start()

    def _process_message(self, prompt, attachment, write_target, write_mode, agent_mode=False):
        try:
            client = self._get_client()
            if agent_mode and self.agent_files_var.get():
                conversation_id, response = self._run_file_agent(client, prompt, attachment)
            else:
                conversation_id, response = client.send(
                    prompt,
                    conversation_id=self.conversation_id,
                    attachment=attachment,
                )
            self.conversation_id = conversation_id
            self.last_response = response
            self.messages.append(('assistant', response, None))
            saved_path = None
            if write_target:
                saved_path = self._write_response_file(write_target, response, write_mode)
            elif self.auto_save_var.get():
                saved_path = self._auto_save_response(response)
            self.root.after(0, lambda: self._add_message('assistant', response))
            if saved_path:
                self.root.after(0, lambda: self._set_status(f"Claude answer saved: {saved_path}"))
            else:
                self.root.after(0, lambda: self._set_status(f"Claude conversation: {conversation_id}"))
        except Exception as e:
            msg = f"Claude error: {e}"
            self.root.after(0, lambda: self._add_message('system', msg))
            self.root.after(0, lambda: self._set_status("Claude error"))
        finally:
            self.root.after(0, lambda: self.send_btn.config(state=tk.NORMAL, text="Send\n(Enter)"))

    def _safe_project_path(self, target):
        root = self._workspace_root()
        path = Path(str(target)).expanduser()
        if not path.is_absolute():
            path = root / path
        resolved = path.resolve()
        root_s = str(root).lower()
        resolved_s = str(resolved).lower()
        if resolved_s != root_s and not resolved_s.startswith(root_s + os.sep.lower()):
            raise ValueError(f"Refusing path outside Claude work folder: {target}")
        return resolved

    def _list_project_files(self, target='.', pattern='*', limit=200):
        base = self._safe_project_path(target)
        if base.is_file():
            return str(base.relative_to(self._workspace_root()))
        if not base.exists():
            raise FileNotFoundError(str(base))
        ignored = {'venv314', '__pycache__', '.pytest_cache', '.git'}
        files = []
        for p in base.rglob(pattern or '*'):
            if len(files) >= int(limit or 200):
                break
            if any(part in ignored for part in p.parts):
                continue
            if p.is_file():
                files.append(str(p.relative_to(self._workspace_root())))
        return '\n'.join(files)

    def _file_tree(self, target='.', depth=3, include_files=True, limit=500):
        base = self._safe_project_path(target)
        if not base.exists():
            raise FileNotFoundError(str(base))
        max_depth = int(depth or 3)
        include_files = bool(include_files)
        ignored = {'venv314', '__pycache__', '.pytest_cache', '.git'}
        lines = [str(base.relative_to(self._workspace_root()) if base != self._workspace_root() else '.')]
        count = 0
        for p in sorted(base.rglob('*'), key=lambda x: str(x).lower()):
            if count >= int(limit or 500):
                lines.append('[truncated]')
                break
            rel = p.relative_to(base)
            if any(part in ignored for part in rel.parts):
                continue
            rel_depth = len(rel.parts)
            if rel_depth > max_depth:
                continue
            if p.is_file() and not include_files:
                continue
            marker = '/' if p.is_dir() else ''
            lines.append(f"{'  ' * rel_depth}{p.name}{marker}")
            count += 1
        return '\n'.join(lines)

    def _search_project_files(self, query, target='.', glob='*', case_sensitive=False, limit=200):
        query = str(query)
        if not query:
            raise ValueError("search_files requires query")
        base = self._safe_project_path(target)
        if not base.exists():
            raise FileNotFoundError(str(base))
        needle = query if case_sensitive else query.lower()
        results = []
        for p in base.rglob(glob or '*'):
            if len(results) >= int(limit or 200):
                break
            if not p.is_file() or p.suffix.lower() not in self.TEXT_EXTENSIONS:
                continue
            try:
                for idx, line in enumerate(p.read_text(encoding='utf-8', errors='replace').splitlines(), 1):
                    hay = line if case_sensitive else line.lower()
                    if needle in hay:
                        rel = p.relative_to(self._workspace_root())
                        results.append(f"{rel}:{idx}: {line[:500]}")
                        if len(results) >= int(limit or 200):
                            break
            except Exception as e:
                results.append(f"{p.name}: read failed: {e}")
        return '\n'.join(results) if results else "(no matches)"

    def _read_project_file(self, target, max_chars=120000):
        path = self._safe_project_path(target)
        if not path.exists() or not path.is_file():
            raise FileNotFoundError(str(path))
        text = path.read_text(encoding='utf-8', errors='replace')
        if len(text) > int(max_chars or 120000):
            text = text[:int(max_chars or 120000)] + "\n[truncated]"
        return text

    def _read_many_project_files(self, paths, max_chars_per_file=60000):
        if isinstance(paths, str):
            paths = [p.strip() for p in paths.split(',') if p.strip()]
        if not isinstance(paths, list) or not paths:
            raise ValueError("read_many_files requires paths list")
        blocks = []
        for item in paths[:30]:
            path = str(item)
            try:
                content = self._read_project_file(path, max_chars_per_file)
                blocks.append(f"--- {path} ---\n{content}\n--- end {path} ---")
            except Exception as e:
                blocks.append(f"--- {path} ---\nERROR: {e}\n--- end {path} ---")
        return '\n\n'.join(blocks)

    def _write_project_file(self, target, content, mode='write'):
        path = self._safe_project_path(target)
        path.parent.mkdir(parents=True, exist_ok=True)
        if mode == 'append':
            with path.open('a', encoding='utf-8') as f:
                if path.exists() and path.stat().st_size:
                    f.write('\n')
                f.write(str(content))
        else:
            path.write_text(str(content), encoding='utf-8')
        return f"{mode} {len(str(content))} chars -> {path.relative_to(self._workspace_root())}"

    def _replace_in_project_file(self, target, old, new, count=0):
        path = self._safe_project_path(target)
        if not path.exists() or not path.is_file():
            raise FileNotFoundError(str(path))
        text = path.read_text(encoding='utf-8', errors='replace')
        old = str(old)
        if not old:
            raise ValueError("replace_in_file requires non-empty old")
        limit = int(count or 0)
        replaced = text.count(old) if limit <= 0 else min(text.count(old), limit)
        if replaced == 0:
            raise ValueError("old text not found")
        new_text = text.replace(old, str(new), limit if limit > 0 else -1)
        self._snapshot_files([str(path.relative_to(self._workspace_root()))])
        path.write_text(new_text, encoding='utf-8')
        return f"replaced {replaced} occurrence(s) -> {path.relative_to(self._workspace_root())}"

    def _make_project_dir(self, target):
        path = self._safe_project_path(target)
        path.mkdir(parents=True, exist_ok=True)
        return f"created dir -> {path.relative_to(self._workspace_root())}"

    def _require_destructive_ops(self):
        if not self.destructive_ops_var.get():
            raise PermissionError("Destructive ops are disabled in Claude Chat tab")

    def _delete_project_file(self, target):
        self._require_destructive_ops()
        path = self._safe_project_path(target)
        if not path.exists():
            raise FileNotFoundError(str(path))
        if path.is_dir():
            raise IsADirectoryError("delete_file only deletes files")
        self._snapshot_files([str(path.relative_to(self._workspace_root()))])
        path.unlink()
        return f"deleted -> {path.relative_to(self._workspace_root())}"

    def _move_project_file(self, source, dest):
        self._require_destructive_ops()
        src = self._safe_project_path(source)
        dst = self._safe_project_path(dest)
        if not src.exists():
            raise FileNotFoundError(str(src))
        self._snapshot_files([str(src.relative_to(self._workspace_root()))])
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(dst))
        return f"moved -> {dst.relative_to(self._workspace_root())}"

    def _snapshot_files(self, paths):
        if isinstance(paths, str):
            paths = [p.strip() for p in paths.split(',') if p.strip()]
        if not isinstance(paths, list) or not paths:
            raise ValueError("snapshot_files requires paths")
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_root = self._workspace_root() / '_claude_backups' / stamp
        made = []
        for item in paths:
            src = self._safe_project_path(item)
            if not src.exists() or not src.is_file():
                continue
            rel = src.relative_to(self._workspace_root())
            dst = backup_root / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            made.append(str(dst.relative_to(self._workspace_root())))
        return '\n'.join(made) if made else "(no files snapshotted)"

    def _parse_hunk_header(self, header):
        m = re.match(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', header)
        if not m:
            raise ValueError(f"Invalid hunk header: {header}")
        return int(m.group(1)), int(m.group(2) or 1), int(m.group(3)), int(m.group(4) or 1)

    def _apply_hunks_to_lines(self, original, hunks):
        out = []
        src_idx = 0
        for hunk in hunks:
            old_start, _old_count, _new_start, _new_count, lines = hunk
            copy_until = max(old_start - 1, 0)
            if copy_until < src_idx:
                raise ValueError("Overlapping hunks")
            out.extend(original[src_idx:copy_until])
            src_idx = copy_until
            for line in lines:
                if not line:
                    continue
                sign = line[0]
                text = line[1:]
                if sign == ' ':
                    if src_idx >= len(original) or original[src_idx].rstrip('\n\r') != text.rstrip('\n\r'):
                        raise ValueError(f"Patch context mismatch near: {text[:80]}")
                    out.append(original[src_idx])
                    src_idx += 1
                elif sign == '-':
                    if src_idx >= len(original) or original[src_idx].rstrip('\n\r') != text.rstrip('\n\r'):
                        raise ValueError(f"Patch delete mismatch near: {text[:80]}")
                    src_idx += 1
                elif sign == '+':
                    out.append(text if text.endswith(('\n', '\r')) else text + '\n')
                elif line.startswith('\\ No newline'):
                    continue
                else:
                    raise ValueError(f"Invalid patch line: {line[:80]}")
        out.extend(original[src_idx:])
        return out

    def _apply_unified_patch(self, patch_text):
        lines = str(patch_text).splitlines(keepends=True)
        files = []
        i = 0
        while i < len(lines):
            if not lines[i].startswith('--- '):
                i += 1
                continue
            old_name = lines[i][4:].strip().split('\t')[0]
            i += 1
            if i >= len(lines) or not lines[i].startswith('+++ '):
                raise ValueError("Patch missing +++ line")
            new_name = lines[i][4:].strip().split('\t')[0]
            i += 1
            path_name = new_name
            if path_name.startswith('b/'):
                path_name = path_name[2:]
            if path_name == '/dev/null':
                path_name = old_name[2:] if old_name.startswith('a/') else old_name
            hunks = []
            while i < len(lines) and lines[i].startswith('@@ '):
                old_start, old_count, new_start, new_count = self._parse_hunk_header(lines[i].strip())
                i += 1
                hunk_lines = []
                while i < len(lines) and not lines[i].startswith(('@@ ', '--- ')):
                    hunk_lines.append(lines[i])
                    i += 1
                hunks.append((old_start, old_count, new_start, new_count, hunk_lines))
            files.append((path_name, hunks))

        if not files:
            raise ValueError("No unified diff files found")

        changed = []
        for path_name, hunks in files:
            path = self._safe_project_path(path_name)
            original = path.read_text(encoding='utf-8', errors='replace').splitlines(keepends=True) if path.exists() else []
            if path.exists():
                self._snapshot_files([str(path.relative_to(self._workspace_root()))])
            updated = self._apply_hunks_to_lines(original, hunks)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(''.join(updated), encoding='utf-8')
            changed.append(str(path.relative_to(self._workspace_root())))
        return "patched:\n" + '\n'.join(changed)

    def _run_python_check(self, action='py_compile', paths=None, timeout=120):
        action = str(action or 'py_compile').strip()
        cwd = self._workspace_root()
        timeout = int(timeout or 120)
        if paths is None:
            paths = []
        if isinstance(paths, str):
            paths = [p.strip() for p in paths.split(',') if p.strip()]

        if action == 'py_compile':
            if not paths:
                paths = [str(p.relative_to(cwd)) for p in cwd.rglob('*.py')
                         if 'venv314' not in p.parts and '__pycache__' not in p.parts][:80]
            cmd = [sys.executable, '-m', 'py_compile'] + [str(self._safe_project_path(p)) for p in paths]
        elif action == 'pytest':
            cmd = [sys.executable, '-m', 'pytest'] + [str(self._safe_project_path(p)) for p in paths]
        else:
            raise ValueError("run_python_check action must be py_compile or pytest")

        result = subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True,
                                encoding='utf-8', errors='replace', timeout=timeout)
        return (
            f"returncode={result.returncode}\n"
            f"stdout:\n{result.stdout[-12000:]}\n"
            f"stderr:\n{result.stderr[-12000:]}"
        )

    def _run_varagent_import_check(self):
        result = subprocess.run(
            [sys.executable, '-c', "import varagent; import config; print('varagent import ok')"],
            cwd=str(SCRIPT_DIR),
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='replace',
            timeout=60,
        )
        return (
            f"returncode={result.returncode}\n"
            f"stdout:\n{result.stdout}\n"
            f"stderr:\n{result.stderr}"
        )

    def _write_plan(self, content, path='CLAUDE_PLAN.md'):
        return self._write_project_file(path, content, 'write')

    def _extract_tool_json(self, text):
        raw = str(text).strip()
        if raw.startswith('```'):
            raw = re.sub(r'^```(?:json)?\s*', '', raw, flags=re.IGNORECASE)
            raw = re.sub(r'\s*```$', '', raw)
        try:
            return json.loads(raw)
        except Exception:
            pass
        match = re.search(r'\{.*\}', raw, flags=re.DOTALL)
        if not match:
            return None
        try:
            return json.loads(match.group(0))
        except Exception:
            return None

    def _execute_file_tool(self, data):
        tool = str(data.get('tool', '')).lower().strip()
        if tool == 'list_files':
            return self._list_project_files(
                data.get('path', '.'),
                data.get('pattern', '*'),
                data.get('limit', 200),
            )
        if tool == 'file_tree':
            return self._file_tree(
                data.get('path', '.'),
                data.get('depth', 3),
                data.get('include_files', True),
                data.get('limit', 500),
            )
        if tool == 'search_files':
            return self._search_project_files(
                data.get('query', ''),
                data.get('path', '.'),
                data.get('glob', '*'),
                data.get('case_sensitive', False),
                data.get('limit', 200),
            )
        if tool == 'read_file':
            return self._read_project_file(data.get('path', ''), data.get('max_chars', 120000))
        if tool == 'read_many_files':
            return self._read_many_project_files(data.get('paths', []), data.get('max_chars_per_file', 60000))
        if tool == 'write_file':
            return self._write_project_file(data.get('path', ''), data.get('content', ''), 'write')
        if tool == 'append_file':
            return self._write_project_file(data.get('path', ''), data.get('content', ''), 'append')
        if tool == 'replace_in_file':
            return self._replace_in_project_file(
                data.get('path', ''),
                data.get('old', ''),
                data.get('new', ''),
                data.get('count', 0),
            )
        if tool == 'patch_file':
            return self._apply_unified_patch(data.get('patch', ''))
        if tool == 'make_dir':
            return self._make_project_dir(data.get('path', ''))
        if tool == 'delete_file':
            return self._delete_project_file(data.get('path', ''))
        if tool == 'move_file':
            return self._move_project_file(data.get('source', ''), data.get('dest', ''))
        if tool == 'snapshot_files':
            return self._snapshot_files(data.get('paths', []))
        if tool == 'web_search':
            return self._web_search(data.get('query', ''), data.get('limit', 5))
        if tool == 'fetch_url':
            return self._fetch_url(data.get('url', ''), data.get('max_chars', 60000))
        if tool == 'web_search_and_fetch':
            return self._web_search_and_fetch(
                data.get('query', ''),
                data.get('limit', 3),
                data.get('max_chars_per_page', 20000),
            )
        if tool == 'save_url':
            return self._save_url(
                data.get('url', ''),
                data.get('path', ''),
                data.get('mode', 'text'),
                data.get('max_chars', 120000),
            )
        if tool == 'cite_sources':
            return self._cite_sources(data.get('path', 'research_sources.md'))
        if tool == 'run_python_check':
            return self._run_python_check(data.get('action', 'py_compile'), data.get('paths', []), data.get('timeout', 120))
        if tool == 'run_varagent_import_check':
            return self._run_varagent_import_check()
        if tool == 'write_plan':
            return self._write_plan(data.get('content', ''), data.get('path', 'CLAUDE_PLAN.md'))
        if tool == 'final':
            return None
        raise ValueError(f"Unknown file tool: {tool}")

    def _web_search(self, query, limit=5):
        query = str(query).strip()
        if not query:
            raise ValueError("web_search requires query")
        limit = int(limit or 5)
        headers = {'User-Agent': 'Mozilla/5.0 VarAgent/1.0'}
        resp = requests.get(
            'https://duckduckgo.com/html/',
            params={'q': query},
            headers=headers,
            timeout=25,
        )
        resp.raise_for_status()
        from urllib.parse import parse_qs, unquote, urlparse
        results = []
        for m in re.finditer(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>', resp.text, re.I | re.S):
            href = m.group(1).replace('&amp;', '&')
            parsed = urlparse(href)
            qs = parse_qs(parsed.query)
            if 'uddg' in qs:
                href = unquote(qs['uddg'][0])
            title = re.sub(r'<.*?>', '', m.group(2))
            title = re.sub(r'\s+', ' ', title).strip()
            if href and title:
                self.agent_sources.append({'title': title, 'url': href, 'query': query})
                results.append(f"{len(results)+1}. {title}\n{href}")
            if len(results) >= limit:
                break
        if results:
            return '\n\n'.join(results)
        text = re.sub(r'<.*?>', ' ', resp.text)
        return re.sub(r'\s+', ' ', text)[:4000]

    def _fetch_url(self, url, max_chars=60000):
        url = str(url).strip()
        if not url.lower().startswith(('http://', 'https://')):
            raise ValueError("fetch_url requires http(s) url")
        self.agent_sources.append({'title': url, 'url': url, 'query': 'fetch_url'})
        headers = {'User-Agent': 'Mozilla/5.0 VarAgent/1.0'}
        resp = requests.get(url, headers=headers, timeout=30)
        resp.raise_for_status()
        text = resp.text
        text = re.sub(r'(?is)<script.*?</script>|<style.*?</style>', ' ', text)
        text = re.sub(r'(?s)<.*?>', ' ', text)
        text = re.sub(r'\s+', ' ', text).strip()
        limit = int(max_chars or 60000)
        return text[:limit] + ('\n[truncated]' if len(text) > limit else '')

    def _web_search_and_fetch(self, query, limit=3, max_chars_per_page=20000):
        results_text = self._web_search(query, limit)
        urls = re.findall(r'https?://\S+', results_text)
        blocks = [f"Search results:\n{results_text}"]
        for url in urls[:int(limit or 3)]:
            try:
                blocks.append(f"\n--- {url} ---\n{self._fetch_url(url, max_chars_per_page)}")
            except Exception as e:
                blocks.append(f"\n--- {url} ---\nERROR: {e}")
        return '\n'.join(blocks)

    def _save_url(self, url, path, mode='text', max_chars=120000):
        url = str(url).strip()
        out_path = self._safe_project_path(path)
        headers = {'User-Agent': 'Mozilla/5.0 VarAgent/1.0'}
        resp = requests.get(url, headers=headers, timeout=30)
        resp.raise_for_status()
        content = resp.text
        if str(mode or 'text').lower() == 'text':
            content = re.sub(r'(?is)<script.*?</script>|<style.*?</style>', ' ', content)
            content = re.sub(r'(?s)<.*?>', ' ', content)
            content = re.sub(r'\s+', ' ', content).strip()
        limit = int(max_chars or 120000)
        if len(content) > limit:
            content = content[:limit] + '\n[truncated]'
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(content, encoding='utf-8')
        self.agent_sources.append({'title': url, 'url': url, 'query': 'save_url'})
        return f"saved url -> {out_path.relative_to(self._workspace_root())}"

    def _cite_sources(self, path='research_sources.md'):
        seen = set()
        lines = ["# Research Sources\n"]
        for item in self.agent_sources:
            url = item.get('url', '')
            if not url or url in seen:
                continue
            seen.add(url)
            title = item.get('title') or url
            query = item.get('query') or ''
            suffix = f" - query: {query}" if query else ""
            lines.append(f"- [{title}]({url}){suffix}")
        if len(lines) == 1:
            lines.append("- No sources recorded yet.")
        return self._write_project_file(path, '\n'.join(lines) + '\n', 'write')

    def _run_file_agent(self, client, prompt, attachment):
        agent_prompt = (
            "You are Claude inside VarAgent GUI with controlled local file tools. "
            "You cannot use shell commands. To inspect or edit files, reply with exactly one JSON object and no prose. "
            "Tools: "
            "{\"tool\":\"list_files\",\"path\":\".\",\"pattern\":\"*.py\",\"limit\":100}; "
            "{\"tool\":\"file_tree\",\"path\":\".\",\"depth\":3,\"include_files\":true,\"limit\":500}; "
            "{\"tool\":\"search_files\",\"query\":\"needle\",\"path\":\".\",\"glob\":\"*.py\",\"case_sensitive\":false,\"limit\":200}; "
            "{\"tool\":\"read_file\",\"path\":\"relative/path.txt\",\"max_chars\":120000}; "
            "{\"tool\":\"read_many_files\",\"paths\":[\"a.py\",\"b.py\"],\"max_chars_per_file\":60000}; "
            "{\"tool\":\"write_file\",\"path\":\"relative/path.txt\",\"content\":\"full file content\"}; "
            "{\"tool\":\"append_file\",\"path\":\"relative/path.txt\",\"content\":\"text to append\"}; "
            "{\"tool\":\"replace_in_file\",\"path\":\"relative/path.txt\",\"old\":\"exact text\",\"new\":\"replacement\",\"count\":1}; "
            "{\"tool\":\"patch_file\",\"patch\":\"--- a/file\\n+++ b/file\\n@@ ...\"}; "
            "{\"tool\":\"make_dir\",\"path\":\"relative/dir\"}; "
            "{\"tool\":\"delete_file\",\"path\":\"relative/path.txt\"}; "
            "{\"tool\":\"move_file\",\"source\":\"old.txt\",\"dest\":\"new.txt\"}; "
            "{\"tool\":\"snapshot_files\",\"paths\":[\"a.py\",\"b.py\"]}; "
            "{\"tool\":\"web_search\",\"query\":\"search query\",\"limit\":5}; "
            "{\"tool\":\"fetch_url\",\"url\":\"https://example.com\",\"max_chars\":60000}; "
            "{\"tool\":\"web_search_and_fetch\",\"query\":\"search query\",\"limit\":3,\"max_chars_per_page\":20000}; "
            "{\"tool\":\"save_url\",\"url\":\"https://example.com\",\"path\":\"research/page.md\",\"mode\":\"text\"}; "
            "{\"tool\":\"cite_sources\",\"path\":\"research_sources.md\"}; "
            "{\"tool\":\"run_python_check\",\"action\":\"py_compile\",\"paths\":[\"file.py\"],\"timeout\":120}; "
            "{\"tool\":\"run_varagent_import_check\"}; "
            "{\"tool\":\"write_plan\",\"path\":\"CLAUDE_PLAN.md\",\"content\":\"plan text\"}; "
            "{\"tool\":\"final\",\"answer\":\"short final answer\"}. "
            f"Current allowed work folder is: {self._workspace_root()}. "
            "All relative paths are relative to that work folder, and the GUI refuses paths outside it. "
            f"delete_file and move_file require the Destructive ops checkbox; currently {self.destructive_ops_var.get()}. "
            "User request:\n" + prompt
        )
        conversation_id = self.conversation_id
        response = ""
        for step in range(20):
            conversation_id, response = client.send(
                agent_prompt if step == 0 else prompt,
                conversation_id=conversation_id,
                attachment=attachment if step == 0 else None,
            )
            data = self._extract_tool_json(response)
            if not isinstance(data, dict):
                return conversation_id, response
            if str(data.get('tool', '')).lower().strip() == 'final':
                return conversation_id, str(data.get('answer', ''))
            try:
                result = self._execute_file_tool(data)
                prompt = (
                    "Tool result:\n"
                    f"{result}\n\n"
                    "Continue. If done, return {\"tool\":\"final\",\"answer\":\"...\"}."
                )
            except Exception as e:
                prompt = (
                    "Tool error:\n"
                    f"{e}\n\n"
                    "Choose another file tool or return final JSON."
                )
        return conversation_id, response

    def _browse_output_dir(self):
        path = filedialog.askdirectory(title="Choose Claude output folder")
        if path:
            self.output_dir_var.set(path)
            self._set_status(f"Output folder: {path}")

    def _write_response_file(self, target, response, mode):
        path = self._resolve_write_path(target)
        path.parent.mkdir(parents=True, exist_ok=True)
        if mode == 'append':
            with path.open('a', encoding='utf-8') as f:
                if path.exists() and path.stat().st_size:
                    f.write('\n\n')
                f.write(response)
        else:
            path.write_text(response, encoding='utf-8')
        return path

    def _auto_save_response(self, response):
        out_dir = Path(self.output_dir_var.get().strip() or (SCRIPT_DIR / 'claude_outputs'))
        out_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        path = out_dir / f"claude_answer_{stamp}.md"
        path.write_text(response, encoding='utf-8')
        return path

    def _save_last_response(self):
        if not self.last_response:
            messagebox.showwarning("Claude", "No Claude answer to save yet.")
            return
        path = filedialog.asksaveasfilename(
            title="Save Claude answer",
            defaultextension=".md",
            filetypes=[("Markdown", "*.md"), ("Text", "*.txt"), ("All files", "*.*")]
        )
        if not path:
            return
        Path(path).write_text(self.last_response, encoding='utf-8')
        self._set_status(f"Saved: {path}")


def main():
    try:
        from tkinterdnd2 import TkinterDnD
        root = TkinterDnD.Tk()
    except ImportError:
        root = tk.Tk()
    app = VarAgentGUI(root)
    root.mainloop()


if __name__ == '__main__':
    # Mark this process so in-process modules (veo_video etc.) skip interactive
    # prompts — stdin may be attached to a hidden console the user can't see.
    os.environ['VARAGENT_GUI_MODE'] = '1'
    main()
