#!/bin/bash
# SCENAGENT RTG - Checker + Auto-Fix for macOS
# Run: double-click this file in Finder

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Auto-set execute permissions
chmod +x *.command 2>/dev/null

PYTHON_CMD="python3"
ERRORS=0
FIX_PYTHON=0
FIX_PIP=0
FIX_PACKAGES=0
FIX_FFMPEG=0
FIX_ENV=0
MISSING=""

echo ""
echo "================================================================================"
echo " SCENAGENT RTG - CHECKER + AUTO-FIX (macOS)"
echo "================================================================================"
echo ""

# ============================================================================
# CHECK ALL
# ============================================================================

echo "[1/5] Python3..."
PYVER=$(python3 --version 2>&1)
if [ $? -eq 0 ]; then
    echo " [OK] $PYVER"
else
    echo " [ERROR] Python3 not found!"
    FIX_PYTHON=1
    ERRORS=$((ERRORS + 1))
fi

echo ""
echo "[2/5] pip..."
$PYTHON_CMD -m pip --version &>/dev/null
if [ $? -eq 0 ]; then
    echo " [OK] pip available"
else
    echo " [ERROR] pip not found!"
    FIX_PIP=1
    ERRORS=$((ERRORS + 1))
fi

echo ""
echo "[3/5] Python packages..."
PKG_ERRORS=0
$PYTHON_CMD -c "import assemblyai" 2>/dev/null || { echo " [MISS] assemblyai"; MISSING="$MISSING assemblyai"; PKG_ERRORS=$((PKG_ERRORS + 1)); }
$PYTHON_CMD -c "import google.genai" 2>/dev/null || { echo " [MISS] google.genai"; MISSING="$MISSING google-genai"; PKG_ERRORS=$((PKG_ERRORS + 1)); }
$PYTHON_CMD -c "import dotenv" 2>/dev/null || { echo " [MISS] python-dotenv"; MISSING="$MISSING python-dotenv"; PKG_ERRORS=$((PKG_ERRORS + 1)); }
$PYTHON_CMD -c "import tqdm" 2>/dev/null || { echo " [MISS] tqdm"; MISSING="$MISSING tqdm"; PKG_ERRORS=$((PKG_ERRORS + 1)); }
$PYTHON_CMD -c "import httpx" 2>/dev/null || { echo " [MISS] httpx"; MISSING="$MISSING httpx"; PKG_ERRORS=$((PKG_ERRORS + 1)); }
$PYTHON_CMD -c "import pydantic" 2>/dev/null || { echo " [MISS] pydantic"; MISSING="$MISSING pydantic"; PKG_ERRORS=$((PKG_ERRORS + 1)); }
ERRORS=$((ERRORS + PKG_ERRORS))
if [ $PKG_ERRORS -eq 0 ]; then
    echo " [OK] All packages installed"
else
    echo " [WARN] Missing:$MISSING"
    FIX_PACKAGES=1
fi

echo ""
echo "[4/5] FFmpeg..."
if ffmpeg -version &>/dev/null; then
    echo " [OK] FFmpeg installed"
else
    echo " [ERROR] FFmpeg not found!"
    FIX_FFMPEG=1
    ERRORS=$((ERRORS + 1))
fi

echo ""
echo "[5/5] .env file..."
if [ -f "agent/.env" ]; then
    echo " [OK] agent/.env exists"
else
    echo " [ERROR] agent/.env not found!"
    FIX_ENV=1
    ERRORS=$((ERRORS + 1))
fi

# ============================================================================
# SUMMARY
# ============================================================================
echo ""
echo "================================================================================"
echo " RESULT: $ERRORS error(s) found"
echo "================================================================================"
echo ""

if [ $ERRORS -eq 0 ]; then
    echo " [OK] All components ready!"
    echo ""
    echo " You can run:"
    echo "   ./run_stage1_simple.command"
    echo "   ./run_stage2_auto.command"
    echo ""
    echo "================================================================================"
    exit 0
fi

echo " Problems found:"
[ $FIX_PYTHON -eq 1 ] && echo "   - Python3 not installed"
[ $FIX_PIP -eq 1 ] && echo "   - pip not available"
[ $FIX_PACKAGES -eq 1 ] && echo "   - Missing packages:$MISSING"
[ $FIX_FFMPEG -eq 1 ] && echo "   - FFmpeg not installed"
[ $FIX_ENV -eq 1 ] && echo "   - agent/.env not found"
echo ""

if [ $FIX_PYTHON -eq 1 ]; then
    echo " [!] Python3 must be installed manually first!"
    echo "     Install Xcode Command Line Tools: xcode-select --install"
    echo "     Or install via Homebrew: brew install python@3.11"
    echo ""
fi

echo "================================================================================"
echo " AUTO-FIX AVAILABLE"
echo "================================================================================"
echo ""
echo " Do you want to install missing components automatically?"
echo ""
echo " Y - Yes, install everything missing"
echo " N - No, exit"
echo ""
read -p "Your choice (Y/N): " CHOICE

if [[ "$CHOICE" =~ ^[Yy]([Ee][Ss])?$ ]]; then
    echo ""
    echo "================================================================================"
    echo " STARTING AUTO-FIX..."
    echo "================================================================================"
    echo ""

    # Fix PIP
    if [ $FIX_PIP -eq 1 ]; then
        echo "[FIX] Installing pip via ensurepip..."
        $PYTHON_CMD -m ensurepip --upgrade
        if [ $? -eq 0 ]; then
            echo " [OK] pip installed"
        else
            echo " [ERROR] Failed to install pip!"
        fi
        echo ""
    fi

    # Fix PACKAGES
    if [ $FIX_PACKAGES -eq 1 ]; then
        echo "[FIX] Installing missing packages..."
        $PYTHON_CMD -m pip install --upgrade pip
        $PYTHON_CMD -m pip install assemblyai google-genai python-dotenv tqdm httpx pydantic
        if [ $? -eq 0 ]; then
            echo " [OK] Packages installed"
        else
            echo " [WARN] Some packages may have failed to install"
            echo " Try mirror: $PYTHON_CMD -m pip install assemblyai google-genai python-dotenv tqdm httpx pydantic \\"
            echo "     --index-url https://pypi.tuna.tsinghua.edu.cn/simple"
        fi
        echo ""
    fi

    # Fix FFMPEG
    if [ $FIX_FFMPEG -eq 1 ]; then
        echo "[FIX] Installing FFmpeg..."
        if command -v brew &>/dev/null; then
            echo " Using Homebrew..."
            brew install ffmpeg
            if [ $? -eq 0 ]; then
                echo " [OK] FFmpeg installed via Homebrew"
            else
                echo " [WARN] Failed to install via Homebrew"
            fi
        else
            echo " [WARN] Homebrew not available. Install FFmpeg manually:"
            echo "   1. Install Homebrew: /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\""
            echo "   2. Then: brew install ffmpeg"
            echo "   OR download: https://github.com/BtbN/FFmpeg-Builds/releases"
        fi
        echo ""
    fi

    # Fix .ENV
    if [ $FIX_ENV -eq 1 ]; then
        echo "[FIX] Creating agent/.env..."
        if [ -f "agent/.env.example" ]; then
            cp "agent/.env.example" "agent/.env"
            echo " [OK] Created from template"
            echo " [!] Don't forget to fill in API keys in agent/.env!"
        else
            echo " [WARN] agent/.env.example not found. Creating empty agent/.env..."
            cat > "agent/.env" << EOF
ASSEMBLYAI_API_KEY=
GEMINI_API_KEY=
FASTGEN_API_KEY=
EOF
            echo " [OK] Created empty agent/.env - fill in your API keys!"
        fi
        echo ""
    fi

    echo "================================================================================"
    echo " AUTO-FIX COMPLETED"
    echo "================================================================================"
    echo ""
    echo " Please restart terminal and run ./check_install.command again to verify."
    echo ""
else
    echo ""
    echo " Exiting without changes."
    echo "================================================================================"
    exit 1
fi

echo "================================================================================"
