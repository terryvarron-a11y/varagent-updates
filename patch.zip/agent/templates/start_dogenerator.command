#!/bin/bash
# START_DOGENERATOR.COMMAND - Do-generation of missing clips (macOS - double click)
# Run: double-click this file in Finder

PROJECT_NAME="{project_name}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Auto-set execute permissions
chmod +x *.command *.sh 2>/dev/null

# Open Terminal.app for interactive mode
if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
    osascript -e "tell app \"Terminal\" to do script \"cd '$SCRIPT_DIR' && exec '$0'\""
    exit 0
fi

# Delegate to root script
cd "$ROOT_DIR"
bash run_dogenerator.sh "$PROJECT_NAME"
