"""Auto Visual Story profile orchestrator."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import config
from modules.director_profiles import DirectorProfileTransport, coerce_json_list
from modules.textio import read_user_text
from modules.visual_story_context import (
    ContextWindowBuilder,
    DurationPolicy,
    materialize_scenes,
    normalize_words,
    write_context_packets,
)
from modules.visual_story_epf import materialize_visual_assets
from modules.visual_story_query import create_visual_plans
from modules.visual_story_validator import (
    final_asset_gate,
    validate_montage_compatibility,
    validate_narrative_state,
    validate_scenes,
)


def _json_read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _json_write(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def _input_hash(*parts: Any) -> str:
    digest = hashlib.sha256()
    for part in parts:
        if isinstance(part, Path):
            digest.update(part.read_bytes())
        else:
            digest.update(
                json.dumps(part, ensure_ascii=False, sort_keys=True, default=str).encode("utf-8")
            )
    return digest.hexdigest()


class StoryState:
    def __init__(self, story_dir: Path, input_hash: str):
        self.path = story_dir / "state.json"
        if self.path.exists():
            try:
                self.data = _json_read(self.path)
            except Exception:
                self.data = {}
        else:
            self.data = {}
        if self.data.get("input_hash") != input_hash:
            self.data = {
                "schema_version": 1,
                "director_profile": "auto_visual_story",
                "input_hash": input_hash,
                "stages": {},
            }
        self.save()

    def save(self) -> None:
        _json_write(self.path, self.data)

    def status(self, stage: str) -> str:
        value = self.data.get("stages", {}).get(stage, {})
        return value.get("status", "pending") if isinstance(value, dict) else str(value)

    def mark(self, stage: str, status: str, **fields: Any) -> None:
        self.data.setdefault("stages", {})[stage] = {
            "status": status,
            **fields,
        }
        self.save()


def _mock_scene_plan(
    words: list[dict[str, Any]],
    audio_duration: float,
    target_duration: float,
) -> dict[str, Any]:
    # Keep mock output deliberately coarse. ``materialize_scenes`` owns the
    # real split and knows the active range plus the separate intro limits.
    # Pre-splitting here could leave an unmergeable short tail at that boundary.
    if not words:
        return {"scenes": []}
    return {
        "scenes": [{
            "word_start_index": 0,
            "word_end_index": len(words) - 1,
            "scene_role": "event",
            "description": " ".join(item["text"] for item in words),
            "chapter_id": "chapter_1",
            "entities": [],
        }]
    }


def _mock_narrative_state(scenes: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "chapters": [{
            "id": "chapter_1",
            "summary": "Deterministic mock chapter",
            "scene_ids": [scene["id"] for scene in scenes],
            "active_entities": [],
            "hidden_entities": [],
            "revealed_entities": [],
        }],
        "entities": {},
        "global_summary": "Deterministic mock narrative state",
    }


def _load_prompt(name: str) -> str:
    path = Path(__file__).parents[1] / "prompts" / name
    return path.read_text(encoding="utf-8")


def _active_duration_profile() -> tuple[
    float, float, float, DurationPolicy, dict[str, Any]
]:
    """Use the active GUI/process clip ranges, including the intro range."""
    active_min = float(getattr(
        config,
        "ACTIVE_CLIP_MIN_DURATION",
        getattr(config, "VIDEO_CLIP_MIN_DURATION", 4),
    ))
    active_max = float(getattr(
        config,
        "ACTIVE_CLIP_MAX_DURATION",
        getattr(config, "VIDEO_CLIP_MAX_DURATION", 8),
    ))
    active_min = max(0.1, active_min)
    active_max = max(active_min, active_max)

    intro_boundary = max(0.0, float(getattr(config, "INTRO_BLOCK_DURATION", 0)))
    try:
        intro_min = float(config.get_intro_clip_min())
        intro_max = float(config.get_intro_clip_max())
    except AttributeError:
        intro_min, intro_max = active_min, active_max
    intro_min = max(0.1, intro_min)
    intro_max = max(intro_min, intro_max)

    def policy(start_time: float) -> tuple[float, float, float]:
        if intro_boundary > 0 and start_time < intro_boundary:
            low, high = intro_min, intro_max
        else:
            low, high = active_min, active_max
        return low, (low + high) / 2.0, high

    global_min = min(active_min, intro_min if intro_boundary > 0 else active_min)
    global_max = max(active_max, intro_max if intro_boundary > 0 else active_max)
    global_target = (global_min + global_max) / 2.0
    profile = {
        "active": {"min": active_min, "max": active_max},
        "intro": {
            "boundary": intro_boundary,
            "min": intro_min,
            "max": intro_max,
        },
    }
    return global_min, global_target, global_max, policy, profile


def _build_montage(
    *,
    scenes: list[dict[str, Any]],
    plans: list[dict[str, Any]],
    audio_duration: float,
    project_name: str,
) -> dict[str, Any]:
    plans_by_id = {int(plan["scene_id"]): plan for plan in plans}
    clips = []
    for scene in scenes:
        clip_id = int(scene["id"])
        plan = plans_by_id[clip_id]
        clips.append({
            "id": clip_id,
            "file": f"generated/{clip_id:03d}.jpg",
            "startTime": scene["startTime"],
            "endTime": scene["endTime"],
            "description": scene["description"],
            "voiceover": scene["text"],
            "source": (
                "youtube_pending"
                if str(plan.get("preferred_source") or "").lower() == "youtube"
                else (
                    "stock_pending"
                    if str(plan.get("preferred_source") or "").lower()
                    in {"stock", "local", "stock_photo", "stock_video"}
                    else "real_photo_pending"
                )
            ),
            "scene_role": scene.get("scene_role", "event"),
            "entities": scene.get("entities") or [],
            "visual_intent": plan.get("visual_intent", ""),
            "search_queries": plan.get("search_queries")
            or plan.get("youtube_queries")
            or ([plan.get("search_query")] if plan.get("search_query") else []),
            "must_have": plan.get("must_have") or [],
            "avoid": plan.get("avoid")
            or plan.get("negative_constraints")
            or [],
            "candidate_windows": plan.get("candidate_windows")
            or plan.get("youtube_candidate_windows")
            or [],
            "chain_id": clip_id,
            "visual_story": {
                "schema_version": 1,
                "word_start_index": scene["word_start_index"],
                "word_end_index": scene["word_end_index"],
                "strategy": plan["visual_strategy"],
                "reuse_clip_id": plan.get("reuse_clip_id"),
                "visual_intent": plan["visual_intent"],
                "query": plan.get("search_query", ""),
            },
        })
    return {
        "project": project_name,
        "audioDuration": audio_duration,
        "director_profile": "auto_visual_story",
        "clips": clips,
    }


_GENERIC_STOCK_TERMS = {
    "ссора", "дружба", "разговор", "работает", "работа", "человек",
    "люди", "встреча", "улыбается", "идет", "идут", "бытовой",
    "спор", "обнимаются", "говорит", "говорят",
    "argument", "friendship", "conversation", "person", "people",
    "working", "work", "talking", "smiling", "hugging", "meeting",
}
_CONCRETE_YOUTUBE_TERMS = {
    "грузия", "тбилиси", "кавказ", "животное", "животные", "архив",
    "событие", "интервью", "выступление", "митинг", "спорт", "транспорт",
    "самолет", "поезд", "море", "горы", "улица", "природа", "производство",
    "georgia", "tbilisi", "caucasus", "animal", "animals", "archive",
    "event", "interview", "speech", "sports", "transport", "airplane",
    "train", "sea", "mountains", "street", "nature", "factory",
}


def _source_text(plan: dict[str, Any]) -> str:
    return " ".join(
        str(plan.get(key) or "")
        for key in ("visual_intent", "search_query", "description")
    ).lower()


def _youtube_specificity(plan: dict[str, Any]) -> tuple[int, int]:
    text = _source_text(plan)
    concrete = sum(term in text for term in _CONCRETE_YOUTUBE_TERMS)
    generic = sum(term in text for term in _GENERIC_STOCK_TERMS)
    return concrete, -generic


def _allocate_source_plans(plans: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Make Stock/YouTube targets deterministic inside Auto Visual Story."""
    stock_names = {"stock", "local", "stock_photo", "stock_video"}
    if not getattr(config, "STOCK_ENABLED", False):
        for plan in plans:
            if plan.get("preferred_source") in stock_names:
                plan["preferred_source"] = "epf"
    if not getattr(config, "YOUTUBE_FOOTAGE_ENABLED", False):
        for plan in plans:
            if plan.get("preferred_source") == "youtube":
                plan["preferred_source"] = "epf"

    new_plans = [p for p in plans if p.get("visual_strategy") == "new_search"]
    youtube_target = 0
    if getattr(config, "YOUTUBE_FOOTAGE_ENABLED", False):
        youtube_target = min(
            len(new_plans),
            max(0, int(round(len(new_plans) * float(
                getattr(config, "YOUTUBE_RATIO_TARGET", 0.0) or 0.0
            )))),
        )
    youtube_explicit = sorted(
        [
            p for p in new_plans
            if p.get("preferred_source") == "youtube"
        ],
        key=_youtube_specificity,
        reverse=True,
    )
    selected_youtube = {id(p) for p in youtube_explicit[:youtube_target]}
    for plan in sorted(new_plans, key=_youtube_specificity, reverse=True):
        if len(selected_youtube) >= youtube_target:
            break
        if id(plan) not in selected_youtube and plan.get("preferred_source") not in stock_names:
            selected_youtube.add(id(plan))

    stock_target = 0
    if getattr(config, "STOCK_ENABLED", False):
        stock_target = min(
            len(new_plans) - len(selected_youtube),
            max(0, int(round(len(new_plans) * float(
                getattr(config, "STOCK_RATIO_TARGET", 0.30) or 0.30
            )))),
        )
    stock_explicit = [
        p for p in new_plans
        if id(p) not in selected_youtube and p.get("preferred_source") in stock_names
    ]
    selected_stock = {id(p) for p in stock_explicit[:stock_target]}
    for plan in new_plans:
        if len(selected_stock) >= stock_target:
            break
        if id(plan) not in selected_youtube and id(plan) not in selected_stock:
            selected_stock.add(id(plan))

    for plan in new_plans:
        if id(plan) in selected_youtube:
            plan["preferred_source"] = "youtube"
        elif id(plan) in selected_stock:
            plan["preferred_source"] = "stock"
        elif plan.get("preferred_source") in stock_names or plan.get("preferred_source") == "youtube":
            plan["preferred_source"] = "epf"
    return plans


def _allocate_stock_plans(plans: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Backward-compatible name for callers outside this module."""
    return _allocate_source_plans(plans)


def analyze_visual_story_project(
    *,
    director,
    transcription_path: str,
    style_guide_path: str,
    output_dir: str,
    project_name: str = "Untitled",
    resume: bool = False,
    step: str = "full",
    mock: bool = False,
    mock_assets: bool = False,
) -> dict[str, Any]:
    step = (step or "full").strip().lower()
    if step not in {"analyze", "search", "finalize", "full"}:
        raise ValueError(f"Unknown Auto Visual Story step: {step}")

    project = Path(output_dir).resolve()
    project.mkdir(parents=True, exist_ok=True)
    story = project / "visual_story"
    story.mkdir(parents=True, exist_ok=True)
    transcription_file = Path(transcription_path).resolve()
    style_file = Path(style_guide_path).resolve()
    duration_min, duration_target, duration_max, duration_policy, duration_profile = (
        _active_duration_profile()
    )
    settings = {
        "duration_profile": duration_profile,
        "before": config.VISUAL_STORY_CONTEXT_BEFORE,
        "after": config.VISUAL_STORY_CONTEXT_AFTER,
        "history": config.VISUAL_STORY_VISUAL_HISTORY,
        "batch": config.VISUAL_STORY_QUERY_BATCH_SIZE,
        "allow_reuse": config.VISUAL_STORY_ALLOW_REUSE,
        "fallback": config.VISUAL_STORY_FALLBACK,
        "stock_enabled": bool(getattr(config, "STOCK_ENABLED", False)),
        "stock_sources": list(getattr(config, "STOCK_SOURCES", []) or []),
        "stock_ratio": float(getattr(config, "STOCK_RATIO_TARGET", 0.30) or 0.30),
    }
    run_hash = _input_hash(transcription_file, style_file, settings)
    state = StoryState(story, run_hash)
    transport = DirectorProfileTransport(director, project)

    transcription = _json_read(transcription_file)
    audio_duration = float(transcription.get("audioDuration") or 0)
    if audio_duration <= 0:
        raise ValueError("transcription.json has no positive audioDuration")

    words_path = project / "transcription_words.json"
    scene_path = story / "scene_plan.json"
    narrative_path = story / "narrative_state.json"
    plans_path = story / "visual_plans.json"
    montage_path = project / "montage_plan.json"

    analysis_artifacts = (
        words_path,
        scene_path,
        narrative_path,
        plans_path,
        montage_path,
    )
    reuse_analysis = bool(
        resume
        and step in {"analyze", "full"}
        and all(path.exists() for path in analysis_artifacts)
    )

    if step in {"analyze", "full"} and not reuse_analysis:
        state.mark("words", "running")
        words = normalize_words(transcription)
        _json_write(words_path, {
            "schema_version": 1,
            "audioDuration": audio_duration,
            "language": transcription.get("language"),
            "words": words,
        })
        state.mark("words", "done", words=len(words), artifact=str(words_path))

        state.mark("scenes", "running")
        if mock:
            raw_scene_plan = _mock_scene_plan(
                words,
                audio_duration,
                duration_target,
            )
        else:
            prompt = (
                _load_prompt("visual_story_scene_plan.txt")
                .replace("{{PROJECT_NAME}}", project_name)
                .replace(
                    "{{WORDS_JSON}}",
                    json.dumps(words, ensure_ascii=False, indent=2),
                )
                .replace(
                    "{{MIN_DURATION}}",
                    str(duration_min),
                )
                .replace(
                    "{{TARGET_DURATION}}",
                    str(duration_target),
                )
                .replace(
                    "{{MAX_DURATION}}",
                    str(duration_max),
                )
                .replace(
                    "{{DURATION_PROFILE_JSON}}",
                    json.dumps(duration_profile, ensure_ascii=False, indent=2),
                )
            )
            raw_scene_plan = transport.call_json(
                phase="scene_plan",
                prompt=prompt,
                schema_file="visual_story_scene_plan.json",
            )
        scenes = materialize_scenes(
            words,
            coerce_json_list(raw_scene_plan.get("scenes") or [], "scenes"),
            audio_duration,
            min_duration=duration_min,
            target_duration=duration_target,
            max_duration=duration_max,
            duration_policy=duration_policy,
        )
        validate_scenes(
            scenes,
            len(words),
            audio_duration,
            min_duration=duration_min,
            max_duration=duration_max,
            duration_policy=duration_policy,
        )
        _json_write(scene_path, {
            "schema_version": 1,
            "audioDuration": audio_duration,
            "scenes": scenes,
        })
        state.mark("scenes", "done", scenes=len(scenes), artifact=str(scene_path))

        state.mark("narrative", "running")
        if mock:
            narrative = _mock_narrative_state(scenes)
        else:
            style_guide = read_user_text(style_file)
            prompt = (
                _load_prompt("visual_story_narrative_state.txt")
                .replace(
                    "{{SCENES_JSON}}",
                    json.dumps(scenes, ensure_ascii=False, indent=2),
                )
                .replace("{{STYLE_GUIDE}}", style_guide[:16000])
            )
            narrative = transport.call_json(
                phase="narrative_state",
                prompt=prompt,
                schema_file="visual_story_narrative_state.json",
            )
        validate_narrative_state(narrative)
        _json_write(narrative_path, narrative)
        state.mark("narrative", "done", artifact=str(narrative_path))

        state.mark("context", "running")
        packets = ContextWindowBuilder(
            config.VISUAL_STORY_CONTEXT_BEFORE,
            config.VISUAL_STORY_CONTEXT_AFTER,
            config.VISUAL_STORY_VISUAL_HISTORY,
        ).build_all(scenes, narrative)
        context_path = write_context_packets(story, packets)
        state.mark(
            "context",
            "done",
            packets=len(packets),
            artifact=str(context_path),
        )

        state.mark("queries", "running")
        plans = create_visual_plans(
            packets=packets,
            transport=transport,
            prompt_template=_load_prompt("visual_story_query.txt"),
            story_dir=story,
            batch_size=config.VISUAL_STORY_QUERY_BATCH_SIZE,
            allow_reuse=config.VISUAL_STORY_ALLOW_REUSE,
            mock=mock,
        )
        plans = _allocate_source_plans(plans)
        state.mark("queries", "done", plans=len(plans), artifact=str(plans_path))

        montage = _build_montage(
            scenes=scenes,
            plans=plans,
            audio_duration=audio_duration,
            project_name=project_name,
        )
        validate_montage_compatibility(
            montage,
            audio_duration,
            min_duration=0.0,
            max_duration=float("inf"),
        )
        _json_write(montage_path, montage)
        state.mark("montage", "done", artifact=str(montage_path))
    else:
        if not all(path.exists() for path in (scene_path, narrative_path, plans_path, montage_path)):
            raise FileNotFoundError(
                "Auto Visual Story analyze artifacts are incomplete; run step=analyze first"
            )
        scenes = _json_read(scene_path)["scenes"]
        plans = _json_read(plans_path)["plans"]
        montage = _json_read(montage_path)
        validate_scenes(
            scenes,
            len(normalize_words(transcription)),
            audio_duration,
            min_duration=duration_min,
            max_duration=duration_max,
            duration_policy=duration_policy,
        )
        validate_montage_compatibility(
            montage,
            audio_duration,
            min_duration=0.0,
            max_duration=float("inf"),
        )
        if reuse_analysis:
            state.mark(
                "analysis",
                "resumed",
                artifacts=[str(path) for path in analysis_artifacts],
            )

    selection = None
    if step in {"search", "full"}:
        state.mark("assets", "running")
        selection = materialize_visual_assets(
            project_dir=project,
            plans=plans,
            fallback=config.VISUAL_STORY_FALLBACK,
            provider=getattr(config, "REAL_PHOTO_VISION_PROVIDER", None),
            model=getattr(config, "REAL_PHOTO_VISION_MODEL", None),
            mock_assets=mock_assets,
        )
        state.mark(
            "assets",
            "done" if not selection.get("unresolved") else "partial",
            resolved=len(selection.get("resolved") or []),
            unresolved=len(selection.get("unresolved") or []),
            artifact=str(story / "selection_manifest.json"),
        )
        montage = _json_read(montage_path)

    final_gate = None
    if step in {"finalize", "full"}:
        state.mark("final_gate", "running")
        montage = _json_read(montage_path)
        final_gate = final_asset_gate(project, montage)
        state.mark("final_gate", "done", **final_gate)

    result = {
        "profile": "auto_visual_story",
        "provider": transport.provider_label,
        "step": step,
        "montage_plan": str(montage_path),
        "state": str(state.path),
        "num_clips": len(montage.get("clips", [])),
        "num_prompts": 0,
        "prompts": None,
        "duration_profile": duration_profile,
        "selection": selection,
        "final_gate": final_gate,
        "cost": {
            "total_cost": 0,
            "input_tokens": 0,
            "output_tokens": 0,
            "note": f"Tracked by selected Director transport ({transport.provider_label})",
        },
    }
    _json_write(story / "run_result.json", result)
    return result
