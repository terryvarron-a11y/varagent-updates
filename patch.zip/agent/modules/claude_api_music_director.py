"""Claude Nexus music director backend."""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Optional

import config
from modules.claude_api_runner import ClaudeApiRunner, extract_json_object
from modules.music_director import MusicDirector


class ClaudeApiMusicDirector(MusicDirector):
    def __init__(self, model_name: Optional[str] = None):
        self.model_name = model_name or config.CLAUDE_API_MODEL
        self.schemas_dir = Path(__file__).parent.parent / 'schemas'
        self.prompts_dir = Path(__file__).parent.parent / 'prompts'
        self.timeout = config.CLAUDE_DIRECTOR_TIMEOUT
        self.claude = ClaudeApiRunner(self.model_name, self.timeout)

    def _build_prompt(
        self,
        sys_instr_path: Path,
        transcription_path: Path,
        montage_plan_path: Path,
        style_guide_path: Path,
        output_path: Path,
        project_name: str,
        audio_duration: float,
    ) -> str:
        prompt = super()._build_prompt(
            sys_instr_path,
            transcription_path,
            montage_plan_path,
            style_guide_path,
            output_path,
            project_name,
            audio_duration,
        )
        def _read(path: Path, label: str) -> str:
            try:
                return path.read_text(encoding='utf-8-sig', errors='replace')
            except Exception as exc:
                return f"(could not read {label}: {exc})"

        return prompt + f"""

## CLAUDE API INLINE FILE CONTENTS
You are running through Claude Nexus, so you cannot open local paths. Use the
inline copies below as the source of truth.

### music_director_pass.txt
{_read(sys_instr_path, 'music instruction')}

### transcription.json
```json
{_read(transcription_path, 'transcription')}
```

### montage_plan.json
```json
{_read(montage_plan_path, 'montage plan')}
```

### style guide
{_read(style_guide_path, 'style guide')}
"""

    def _run_codex(
        self,
        task_prompt: str,
        schema_file: str,
        result_file: Path,
        working_dir: Path,
    ) -> dict:
        if result_file.exists():
            result_file.unlink()

        output_path = working_dir / 'music_plan.json'
        target_volume_db = float(getattr(config, 'MUSIC_DEFAULT_VOLUME_DB', -21))
        api_prompt = task_prompt + f"""

## CLAUDE API OUTPUT CONTRACT
You cannot write files directly. Return ONLY one valid JSON object:
{{
  "control": {{
    "music_plan_path": "{output_path.as_posix()}",
    "status": "ok",
    "tracks_count": 0,
    "audio_duration": 0,
    "error_message": ""
  }},
  "music_plan": {{
    "audioDuration": 0,
    "global_volume_db": {target_volume_db:g},
    "tracks": []
  }}
}}

The `music_plan` value must be exactly the JSON content that should be saved to
music_plan.json.
"""
        text, _cost, elapsed = self.claude.complete(
            api_prompt,
            label='Claude Nexus Music',
            temperature=0.35,
        )
        try:
            data = extract_json_object(text)
        except Exception as exc:
            raise RuntimeError(f"Claude Nexus Music вернул невалидный JSON: {exc}\n{text[:1000]}") from exc

        plan = data.get('music_plan') if isinstance(data.get('music_plan'), dict) else data
        if 'music_plan' in plan and isinstance(plan.get('music_plan'), dict):
            plan = plan['music_plan']
        tracks = plan.get('tracks') or []
        if not tracks:
            logging.warning("Claude Nexus Music returned empty tracks")
        target_ducking_db = float(getattr(config, 'MUSIC_DUCKING_DB', -5))
        plan['global_volume_db'] = target_volume_db
        plan['global_ducking_db'] = target_ducking_db
        for track in tracks:
            if isinstance(track, dict):
                track['volume_db'] = target_volume_db

        output_path.write_text(
            json.dumps({'music_plan': plan}, ensure_ascii=False, indent=2),
            encoding='utf-8',
        )
        control = data.get('control') if isinstance(data.get('control'), dict) else {}
        control = {
            'music_plan_path': str(output_path),
            'status': control.get('status') or 'ok',
            'tracks_count': int(control.get('tracks_count') or len(tracks)),
            'audio_duration': control.get('audio_duration') or plan.get('audioDuration') or 0,
            'error_message': control.get('error_message') or '',
        }
        result_file.write_text(json.dumps(control, ensure_ascii=False, indent=2), encoding='utf-8')
        print(f"   ⏱  Music Director (Claude Nexus): {elapsed:.0f}с, model={self.model_name}")
        return control
