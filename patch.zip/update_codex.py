#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Update Codex CLI to latest version. Windows: download exe. Mac: brew install/upgrade --cask codex."""

import sys
import os
import platform
import shutil
import subprocess
import urllib.request
from pathlib import Path

CODEX_DIR = Path(__file__).parent / "Codex"
CODEX_EXE_WIN = CODEX_DIR / "codex-x86_64-pc-windows-msvc.exe"
DOWNLOAD_URL_WIN = "https://github.com/openai/codex/releases/latest/download/codex-x86_64-pc-windows-msvc.exe"


def get_current_version_win():
    if not CODEX_EXE_WIN.exists():
        return None
    try:
        result = subprocess.run(
            [str(CODEX_EXE_WIN), "--version"],
            capture_output=True, text=True, timeout=5
        )
        return result.stdout.strip()
    except Exception:
        return None


def get_current_version_mac():
    """Try `codex --version` from PATH (brew install --cask codex)."""
    codex_bin = shutil.which('codex')
    if not codex_bin:
        return None
    try:
        result = subprocess.run(
            [codex_bin, "--version"],
            capture_output=True, text=True, timeout=5
        )
        return result.stdout.strip()
    except Exception:
        return None


def update_windows():
    """Download latest Codex .exe from GitHub releases."""
    print(f"Downloading latest Codex CLI from {DOWNLOAD_URL_WIN}...")

    CODEX_DIR.mkdir(exist_ok=True)

    if CODEX_EXE_WIN.exists():
        backup = CODEX_EXE_WIN.with_suffix('.exe.bak')
        print(f"Backing up current version to {backup.name}...")
        shutil.copy2(CODEX_EXE_WIN, backup)

    try:
        with urllib.request.urlopen(DOWNLOAD_URL_WIN, timeout=60) as response:
            total = int(response.headers.get('content-length', 0))
            downloaded = 0
            chunk_size = 8192
            with open(CODEX_EXE_WIN, 'wb') as f:
                while True:
                    chunk = response.read(chunk_size)
                    if not chunk:
                        break
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total:
                        pct = int(downloaded * 100 / total)
                        print(f"\rDownloading: {pct}% ({downloaded}/{total} bytes)", end='', flush=True)
        print("\n[OK] Download complete")
        return True
    except Exception as e:
        print(f"\n[FAIL] Download failed: {e}")
        backup = CODEX_EXE_WIN.with_suffix('.exe.bak')
        if backup.exists():
            print("Restoring backup...")
            shutil.copy2(backup, CODEX_EXE_WIN)
        return False


def update_mac():
    """Install or upgrade Codex via Homebrew."""
    if not shutil.which('brew'):
        print("[FAIL] Homebrew не установлен.")
        print("Установи brew: https://brew.sh")
        print("Потом: brew install --cask codex")
        return False

    # If already installed → upgrade. Else → install.
    already_installed = shutil.which('codex') is not None

    if already_installed:
        print("Codex уже установлен — запускаем `brew upgrade --cask codex`...")
        cmd = ['brew', 'upgrade', '--cask', 'codex']
    else:
        print("Codex не найден — запускаем `brew install --cask codex`...")
        cmd = ['brew', 'install', '--cask', 'codex']

    try:
        result = subprocess.run(cmd, text=True)
        if result.returncode == 0:
            print("[OK] brew завершился успешно")
            return True
        else:
            # `brew upgrade` returns non-zero if already at latest — это не ошибка
            if already_installed:
                print("[OK] Codex уже последней версии (brew upgrade exit != 0)")
                return True
            print(f"[FAIL] brew exit code: {result.returncode}")
            return False
    except Exception as e:
        print(f"[FAIL] brew error: {e}")
        return False


def main():
    print("=" * 60)
    print(f"Codex CLI Update Tool ({platform.system()} {platform.machine()})")
    print("=" * 60)

    system = platform.system()

    if system == 'Windows':
        current = get_current_version_win()
        print(f"Current version: {current or 'Not installed'}")
        print()
        if update_windows():
            new_version = get_current_version_win()
            if new_version:
                print(f"[OK] Updated to: {new_version}")
                if current and new_version == current:
                    print("  (Version unchanged - already latest)")
            else:
                print("[FAIL] Update verification failed")
            return 0
        return 1

    elif system == 'Darwin':
        current = get_current_version_mac()
        print(f"Current version: {current or 'Not installed'}")
        print()
        if update_mac():
            new_version = get_current_version_mac()
            if new_version:
                print(f"[OK] Updated to: {new_version}")
                if current and new_version == current:
                    print("  (Version unchanged - already latest)")
            else:
                print("[OK] brew finished — open new terminal to use `codex`")
            return 0
        return 1

    else:
        print(f"[FAIL] Платформа {system} не поддерживается. Установи Codex вручную:")
        print("  https://github.com/openai/codex/releases/latest")
        return 1


if __name__ == '__main__':
    sys.exit(main())
