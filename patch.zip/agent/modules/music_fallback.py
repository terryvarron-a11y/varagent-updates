"""
Local fallback background beds for when Suno auth/rate-limit fails.

This is intentionally modest: quiet instrumental ambient pads that sit under
narration. It is not a Suno replacement, but it avoids rendering a completely
dry video when cookies are broken.
"""
from __future__ import annotations

import logging
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict, List


def generate_fallback_tracks(
    project_dir: str | Path,
    plan: Dict[str, Any],
    *,
    only_missing: bool = True,
    ffmpeg_path: str | None = None,
) -> Dict[str, int]:
    project_dir = Path(project_dir)
    music_dir = project_dir / "music"
    raw_dir = music_dir / "raw"
    music_dir.mkdir(parents=True, exist_ok=True)
    raw_dir.mkdir(parents=True, exist_ok=True)

    ffmpeg = ffmpeg_path or _resolve_ffmpeg()
    tracks = [
        t for t in plan.get("tracks", [])
        if (t.get("genre") or "").lower() != "silence"
    ]

    created = skipped = failed = 0
    for track in tracks:
        tid = int(track.get("id") or 0)
        if tid <= 0:
            continue
        target = music_dir / f"{tid}.mp3"
        if only_missing and target.exists():
            skipped += 1
            continue

        duration = _fallback_duration(track)
        try:
            temp = raw_dir / str(tid) / "fallback_v1.mp3"
            temp.parent.mkdir(parents=True, exist_ok=True)
            _render_ambient_bed(ffmpeg, temp, duration, track)
            shutil.copy2(temp, target)
            track["file"] = f"{tid}.mp3"
            track["selected_variant"] = 1
            track["suno_clip_ids"] = track.get("suno_clip_ids") or []
            track["suno_durations"] = track.get("suno_durations") or [duration]
            track["fallback"] = "ffmpeg_ambient"
            created += 1
            print(f"   [fallback] Track {tid}: local ambient bed {duration:.0f}s -> {target.name}")
        except Exception as exc:
            failed += 1
            logging.exception("Music fallback failed for track %s", tid)
            print(f"   [fallback] Track {tid}: failed - {exc}")

    return {"created": created, "skipped": skipped, "failed": failed}


def _fallback_duration(track: Dict[str, Any]) -> float:
    try:
        slot = float(track.get("endTime", 0.0)) - float(track.get("startTime", 0.0))
    except (TypeError, ValueError):
        slot = 120.0
    return max(120.0, min(240.0, slot if slot > 0 else 120.0))


def _resolve_ffmpeg() -> str:
    found = shutil.which("ffmpeg")
    return found or "ffmpeg"


def _render_ambient_bed(
    ffmpeg: str,
    output_path: Path,
    duration: float,
    track: Dict[str, Any],
) -> None:
    root, fifth, shimmer = _frequencies_for_track(track)
    noise_amp = _noise_amp_for_track(track)
    fade_out_start = max(0.0, duration - 4.0)

    filter_complex = (
        f"[0:a]lowpass=f=900,highpass=f=70,volume={noise_amp:.4f}[noise];"
        "[1:a]volume=0.035,tremolo=f=0.12:d=0.45[tone1];"
        "[2:a]volume=0.022,tremolo=f=0.16:d=0.35[tone2];"
        "[3:a]volume=0.012,tremolo=f=0.21:d=0.25[tone3];"
        "[noise][tone1][tone2][tone3]"
        "amix=inputs=4:normalize=0,"
        "aecho=0.55:0.35:900:0.22,"
        "volume=44dB,"
        "afade=t=in:st=0:d=3,"
        f"afade=t=out:st={fade_out_start:.3f}:d=4,"
        "aformat=sample_rates=44100:channel_layouts=stereo[aout]"
    )

    cmd: List[str] = [
        ffmpeg,
        "-y",
        "-hide_banner",
        "-loglevel",
        "error",
        "-f",
        "lavfi",
        "-i",
        f"anoisesrc=color=pink:amplitude=0.055:duration={duration:.3f}:sample_rate=44100",
        "-f",
        "lavfi",
        "-i",
        f"sine=frequency={root}:duration={duration:.3f}:sample_rate=44100",
        "-f",
        "lavfi",
        "-i",
        f"sine=frequency={fifth}:duration={duration:.3f}:sample_rate=44100",
        "-f",
        "lavfi",
        "-i",
        f"sine=frequency={shimmer}:duration={duration:.3f}:sample_rate=44100",
        "-filter_complex",
        filter_complex,
        "-map",
        "[aout]",
        "-c:a",
        "libmp3lame",
        "-b:a",
        "192k",
        str(output_path),
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if proc.returncode != 0:
        tail = "\n".join((proc.stderr or "").splitlines()[-10:])
        raise RuntimeError(f"ffmpeg rc={proc.returncode}: {tail}")
    if not output_path.exists() or output_path.stat().st_size <= 0:
        raise RuntimeError(f"ffmpeg did not create {output_path}")


def _frequencies_for_track(track: Dict[str, Any]) -> tuple[int, int, int]:
    text = " ".join(
        str(track.get(key, "")) for key in ("genre", "mood", "energy", "tags", "prompt")
    ).lower()
    if any(word in text for word in ("cold", "arctic", "ice", "underwater", "ocean")):
        return 98, 147, 392
    if any(word in text for word in ("industrial", "urban", "fire", "desert")):
        return 110, 165, 440
    if any(word in text for word in ("hopeful", "warm", "resolution", "finale")):
        return 131, 196, 523
    if any(word in text for word in ("dark", "horror", "ominous", "tense", "suspense")):
        return 87, 130, 349
    return 110, 165, 440


def _noise_amp_for_track(track: Dict[str, Any]) -> float:
    energy = str(track.get("energy") or "").lower()
    if energy == "high":
        return 0.22
    if energy == "mid":
        return 0.16
    return 0.11
