@echo off
chcp 65001 >nul
echo ========================================
echo VARAGENT Emergency Update
echo ========================================
echo.
echo Этот скрипт обходит SSL ошибку и
echo устанавливает обновление напрямую.
echo.
python emergency_update.py
if errorlevel 1 (
    echo.
    echo ОШИБКА при обновлении!
    pause
    exit /b 1
)
pause
