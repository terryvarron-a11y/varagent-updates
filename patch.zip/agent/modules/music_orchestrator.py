"""
Music Orchestrator — генерирует MP3-треки по music_plan.json через SunoClient.

Suno даёт 2 варианта на 1 запрос. Сохраняем оба в music/raw/<id>/<v1|v2>.mp3,
выбранный вариант копируем в music/<id>.mp3 (по умолчанию v1, можно поменять
в GUI Music Review).

После генерации обновляет music_plan.json — добавляет поля:
  tracks[i].suno_clip_ids   — оба clip_id от Suno
  tracks[i].suno_durations  — длительности обоих
  tracks[i].selected_variant — 1 или 2 (default=1)
  tracks[i].file            — путь к выбранному mp3 (относительно проекта)
"""
from __future__ import annotations

import json
import logging
import shutil
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Optional, List, Dict, Any

import config
from modules.music_fallback import generate_fallback_tracks
from modules.music_plan_utils import normalize_music_plan
from modules.suno_client import (
    SunoClient, SunoAuthError, SunoQuotaError, SunoAPIError,
    normalize_suno_model,
)


# Suno даёт ~3.5 минуты на трек. Если эпизод длиннее — нужен continuation
# через continue_clip_id, либо несколько треков склеить crossfade в concat.
SUNO_MAX_TRACK_DURATION = 240  # security: треки длиннее 4 минут — warning, но не блок


class MusicOrchestrator:
    """Гонит SunoClient по music_plan.json"""

    def __init__(
        self,
        project_dir: str | Path,
        plan_path: Optional[str | Path] = None,
        browser: Optional[str] = None,
        model: Optional[str] = None,
        parallel: int = 1,
    ):
        self.project_dir = Path(project_dir)
        self.plan_path = Path(plan_path) if plan_path else (self.project_dir / 'music_plan.json')
        self.browser = browser or getattr(config, 'SUNO_COOKIE_BROWSER', 'firefox')
        self.model = normalize_suno_model(model or getattr(config, 'SUNO_MODEL', 'chirp-fenix'))
        self.parallel = max(1, parallel)

        self.music_dir = self.project_dir / 'music'
        self.music_raw_dir = self.music_dir / 'raw'
        self.music_dir.mkdir(parents=True, exist_ok=True)
        self.music_raw_dir.mkdir(parents=True, exist_ok=True)

        self._client: Optional[SunoClient] = None
        self._client_lock = threading.Lock()

    def _get_client(self) -> SunoClient:
        with self._client_lock:
            if self._client is None:
                self._client = SunoClient(browser=self.browser)
            return self._client

    # =========================================================================
    # Public API
    # =========================================================================

    def generate_all(self, force: bool = False) -> Dict[str, Any]:
        """
        Запускает генерацию всех треков из music_plan.json.

        force=True перегенерирует уже готовые треки (по умолчанию пропускаем).

        Возвращает summary: {ok, skipped, failed, total}.
        """
        plan = self._load_plan()
        original_count = len(plan.get('tracks', []))
        existing_music = any(self.music_dir.glob('*.mp3'))
        if force or not existing_music:
            plan = normalize_music_plan(
                plan,
                float(plan.get('audioDuration', 0) or 0),
                min_track_duration=getattr(config, 'MUSIC_MIN_TRACK_DURATION', 120),
                max_track_duration=getattr(config, 'MUSIC_MAX_TRACK_DURATION', 240),
                max_tracks=getattr(config, 'MUSIC_MAX_TRACKS', 10),
            )
        tracks = plan.get('tracks', [])
        if (force or not existing_music) and len(tracks) != original_count:
            print(
                f"   Music plan simplified: {original_count} -> {len(tracks)} tracks "
                f"(min {getattr(config, 'MUSIC_MIN_TRACK_DURATION', 120)}s, "
                f"max {getattr(config, 'MUSIC_MAX_TRACKS', 10)} total)"
            )
            self._save_plan(plan)
        if not tracks:
            print("⚠️  music_plan не содержит треков — нечего генерировать")
            return {'ok': 0, 'skipped': 0, 'failed': 0, 'total': 0}

        print(f"\n🎵 Music Orchestrator: {len(tracks)} треков, browser={self.browser}, model={self.model}")
        provider = str(getattr(config, 'MUSIC_PROVIDER', 'suno') or 'suno').strip().lower()
        if provider in {'procedural', 'local_library', 'local_sound_library',
                        'safe_stock', 'safe', 'stock', 'stock_safe', 'pixabay', 'pexels'}:
            from modules.music_safe_stock import generate_safe_music_for_project

            print(f"\nMusic provider: {provider} (Local Sound Library)")
            return generate_safe_music_for_project(
                self.project_dir,
                plan_path=self.plan_path,
                provider=provider,
                force=force,
            )

        tracks_to_generate = [
            t for t in tracks
            if (t.get('genre') or '').lower() != 'silence'
            and (t.get('prompt') or '').strip()
            and (force or not (self.music_dir / self._track_filename(t.get('id'))).exists())
        ]
        suno_available = bool(tracks_to_generate)
        if tracks_to_generate:
            try:
                client = self._get_client()
                credits = client.get_credits()
                left = credits.get('total_credits_left', 0)
                need = len(tracks_to_generate) * 10  # 10 кредитов / запрос
                print(f"   Кредиты Suno: {left} (нужно ~{need})")
                if left < need:
                    print(f"   ⚠️  Недостаточно кредитов — некоторые треки не сгенерируются")
            except Exception as e:
                suno_available = False
                print(f"   ⚠️  Suno unavailable before generation: {e}")
        else:
            print("   All music files already exist - skipping Suno auth")

        ok = skipped = failed = 0
        results: List[Dict[str, Any]] = []

        if not suno_available:
            failed = len(tracks_to_generate)
        elif self.parallel > 1:
            print(f"   Параллельно: {self.parallel} потоков")
            with ThreadPoolExecutor(max_workers=self.parallel) as pool:
                futs = {
                    pool.submit(self._generate_one, t, force): t for t in tracks
                }
                for fut in as_completed(futs):
                    res = fut.result()
                    results.append(res)
                    if res['status'] == 'ok':       ok += 1
                    elif res['status'] == 'skipped': skipped += 1
                    else:                            failed += 1
        else:
            # Sleep между треками — Suno rate-limit ~6 запросов на сессию.
            # 30 сек между генерациями имитирует человеческий темп webapp.
            inter_track_sleep = int(getattr(__import__('config'), 'SUNO_INTER_TRACK_SLEEP', 30))
            for i, t in enumerate(tracks, 1):
                print(f"\n[{i}/{len(tracks)}] Track {t.get('id')} «{t.get('title') or t.get('mood', '')}»")
                res = self._generate_one(t, force)
                results.append(res)
                if res['status'] == 'ok':       ok += 1
                elif res['status'] == 'skipped': skipped += 1
                else:                            failed += 1
                failure_reason = str(res.get('reason', ''))
                if (
                    res.get('status') == 'failed'
                    and (
                        'token_validation_failed' in failure_reason
                        or 'rate_limited' in failure_reason
                        or 'Too many requests' in failure_reason
                    )
                ):
                    print("   ⚠️  Suno временно отклоняет Create-запросы — останавливаю генерацию, чтобы не добивать rate-limit")
                    break

                # Sleep между генерациями (rate-limit prevention).
                # Не нужен после skipped (трек уже был) и после последнего трека.
                if i < len(tracks) and res['status'] == 'ok' and inter_track_sleep > 0:
                    print(f"   ⏱  Пауза {inter_track_sleep}с (rate-limit prevention)")
                    time.sleep(inter_track_sleep)

        # Обновить plan с результатами. Для skipped тоже сохраняем — это сохраняет
        # данные предыдущих успешных запусков при retry/догонке.
        results.sort(key=lambda r: r['id'])
        for t, r in zip(sorted(tracks, key=lambda x: x.get('id', 0)), results):
            if r['status'] in ('ok', 'skipped') and r.get('clip_ids'):
                t['suno_clip_ids'] = r['clip_ids']
                t['suno_durations'] = r['durations']
                t['selected_variant'] = t.get('selected_variant', 1)
                t['file'] = self._track_filename(t['id'])
        self._save_plan(plan)

        fallback_created = 0
        if getattr(config, 'MUSIC_FALLBACK_ON_SUNO_FAIL', True) and self._missing_music_count(tracks) > 0:
            print("\n   Suno did not produce every track - creating local fallback beds for missing files")
            fb = generate_fallback_tracks(self.project_dir, plan, only_missing=True)
            fallback_created = int(fb.get('created', 0))
            if fallback_created:
                self._save_plan(plan)

        final_missing = self._missing_music_count(tracks)
        if force and not getattr(config, 'MUSIC_FALLBACK_ON_SUNO_FAIL', True):
            final_missing = max(final_missing, failed)
        ready = max(0, len(tracks) - final_missing)
        print(
            f"\n✅ Music Orchestrator: ready={ready}, suno_ok={ok}, "
            f"skipped={skipped}, fallback={fallback_created}, missing={final_missing}"
        )
        return {
            'ok': ready,
            'skipped': skipped,
            'failed': final_missing,
            'fallback': fallback_created,
            'total': len(tracks),
        }

    # =========================================================================
    # Per-track generation
    # =========================================================================

    def _generate_one(self, track: Dict[str, Any], force: bool) -> Dict[str, Any]:
        tid = track.get('id')
        prompt = track.get('prompt', '').strip()
        tags = track.get('tags', '').strip()
        if track.get('intro_dynamic'):
            low_prompt = prompt.lower()
            intro_bits = []
            if 'dynamic cinematic intro' not in low_prompt:
                intro_bits.append('dynamic cinematic intro')
            if 'starts immediately' not in low_prompt:
                intro_bits.append('starts immediately with pulsing percussion')
            if 'audible in the first second' not in low_prompt:
                intro_bits.append('impact hit on the first beat, audible in the first second')
            if 'no quiet opening' not in low_prompt:
                intro_bits.append('no silence before the music, no slow fade-in, no quiet opening')
            if 'settles under narration' not in low_prompt:
                intro_bits.append('first 8-12 seconds are breathtaking, then settles under narration')
            if intro_bits:
                prompt = ', '.join(intro_bits + [prompt])
            if 'dynamic intro' not in tags.lower():
                tags = ', '.join(
                    p for p in [
                        tags,
                        'dynamic intro, first beat impact, urgent, pulsing percussion, cinematic, instrumental',
                    ] if p
                )
        title = str(track.get('title') or f"Track {tid}").strip()
        if len(title) > 100:
            print(f"   ⚠️  Track {tid}: title too long ({len(title)} chars), truncating to 100 characters")
            title = title[:97].rstrip() + '...'
        genre = (track.get('genre') or '').lower()

        # Тишина: ничего не генерируем
        if genre == 'silence' or not prompt:
            print(f"   ⏸  Track {tid}: silence — skip")
            return {'id': tid, 'status': 'skipped', 'reason': 'silence', 'clip_ids': [], 'durations': []}

        target = self.music_dir / self._track_filename(tid)
        if target.exists() and not force:
            print(f"   ⏭  Track {tid}: {target.name} уже есть — skip (force=True для перегенерации)")
            return {'id': tid, 'status': 'skipped', 'reason': 'exists',
                    'clip_ids': track.get('suno_clip_ids', []),
                    'durations': track.get('suno_durations', [])}

        duration = float(track.get('endTime', 0)) - float(track.get('startTime', 0))
        if duration > SUNO_MAX_TRACK_DURATION:
            print(f"   ⚠️  Track {tid}: эпизод {duration:.0f}с > {SUNO_MAX_TRACK_DURATION}с (Suno даёт ~3.5 мин)")

        client = self._get_client()
        try:
            t0 = time.time()
            clip_ids = client.generate(
                prompt=prompt,
                tags=tags,
                title=title,
                instrumental=True,    # ВСЕГДА
                model=self.model,
            )

            print(f"   📤 Track {tid}: запущены {len(clip_ids)} клипов, ждём...")

            def _on_progress(cid, status, elapsed, _clip):
                if int(elapsed) % 15 == 0:
                    sys.stdout.write(
                        f"\r      {cid[:8]} {status:10} t={elapsed:5.0f}с\n"
                    )
                    sys.stdout.flush()

            durations: List[float] = []
            track_raw_dir = self.music_raw_dir / str(tid)
            track_raw_dir.mkdir(parents=True, exist_ok=True)

            for variant_idx, cid in enumerate(clip_ids, 1):
                clip = client.wait_for_clip(cid, on_progress=_on_progress)
                dur = float(clip.get('metadata', {}).get('duration', 0))
                durations.append(dur)
                dst = track_raw_dir / f'v{variant_idx}.mp3'
                client.download_audio(clip, dst)
                print(f"   ✅ Track {tid} v{variant_idx}: {dur:.1f}с → {dst.relative_to(self.project_dir)}")

            # Копируем выбранный вариант (по умолчанию v1) в music/<id>.mp3
            chosen_variant = track.get('selected_variant', 1)
            chosen_src = track_raw_dir / f'v{chosen_variant}.mp3'
            if not chosen_src.exists():
                chosen_src = track_raw_dir / 'v1.mp3'
            if chosen_src.exists():
                self._copy_selected_music(chosen_src, target, intro_dynamic=bool(track.get('intro_dynamic')))

            elapsed = time.time() - t0
            print(f"   ✓ Track {tid} готов за {elapsed:.0f}с (выбран v{chosen_variant})")
            return {
                'id': tid,
                'status': 'ok',
                'clip_ids': clip_ids,
                'durations': durations,
            }

        except SunoAuthError as e:
            print(f"   ❌ Track {tid}: AUTH ERROR — {e}")
            return {'id': tid, 'status': 'failed', 'reason': f'auth: {e}', 'clip_ids': [], 'durations': []}
        except SunoQuotaError as e:
            print(f"   ❌ Track {tid}: КРЕДИТЫ ЗАКОНЧИЛИСЬ — {e}")
            return {'id': tid, 'status': 'failed', 'reason': f'quota: {e}', 'clip_ids': [], 'durations': []}
        except SunoAPIError as e:
            print(f"   ❌ Track {tid}: API ERROR — {e}")
            return {'id': tid, 'status': 'failed', 'reason': f'api: {e}', 'clip_ids': [], 'durations': []}
        except Exception as e:
            logging.exception(f"Track {tid}: unexpected error")
            print(f"   ❌ Track {tid}: {e}")
            return {'id': tid, 'status': 'failed', 'reason': str(e), 'clip_ids': [], 'durations': []}

    # =========================================================================
    # Variant switching (вызывается из Music Review GUI)
    # =========================================================================

    def select_variant(self, track_id: int, variant: int) -> bool:
        """Меняет selected_variant и копирует raw/<id>/v<variant>.mp3 → music/<id>.mp3."""
        plan = self._load_plan()
        tracks = plan.get('tracks', [])
        track = next((t for t in tracks if t.get('id') == track_id), None)
        if not track:
            return False

        src = self.music_raw_dir / str(track_id) / f'v{variant}.mp3'
        if not src.exists():
            print(f"⚠️  Вариант v{variant} не найден для track {track_id}: {src}")
            return False

        dst = self.music_dir / self._track_filename(track_id)
        self._copy_selected_music(src, dst, intro_dynamic=bool(track.get('intro_dynamic')))
        track['selected_variant'] = variant
        track['file'] = self._track_filename(track_id)
        self._save_plan(plan)
        print(f"✓ Track {track_id}: выбран v{variant}")
        return True

    # =========================================================================
    # Helpers
    # =========================================================================

    def _track_filename(self, track_id: int) -> str:
        return f'{track_id}.mp3'

    def _copy_selected_music(self, src: Path, dst: Path, *, intro_dynamic: bool = False) -> None:
        """
        Copy the selected Suno variant into music/<id>.mp3 while trimming encoder
        padding or generated leading silence. This keeps the background audible
        from the first second when the plan starts at 0.0.
        """
        ffmpeg = shutil.which('ffmpeg')
        if not ffmpeg:
            shutil.copy2(src, dst)
            return

        threshold = '-45dB' if intro_dynamic else '-50dB'
        start_duration = '0.03' if intro_dynamic else '0.05'
        temp = dst.with_name(f"{dst.stem}__trimmed{dst.suffix}")
        cmd = [
            ffmpeg, '-y', '-hide_banner', '-loglevel', 'error',
            '-i', str(src),
            '-af',
            (
                'silenceremove='
                f'start_periods=1:start_duration={start_duration}:start_threshold={threshold}'
            ),
            '-c:a', 'libmp3lame', '-b:a', '192k',
            str(temp),
        ]
        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True, encoding='utf-8', errors='replace',
            )
            if proc.returncode != 0 or not temp.exists() or temp.stat().st_size <= 0:
                raise RuntimeError((proc.stderr or '').strip()[-500:])
            if dst.exists():
                dst.unlink()
            temp.replace(dst)
        except Exception as exc:
            logging.warning("Music trim/copy fallback for %s: %s", src, exc)
            if temp.exists():
                try:
                    temp.unlink()
                except OSError:
                    pass
            shutil.copy2(src, dst)

    def _ready_music_count(self, tracks: List[Dict[str, Any]]) -> int:
        return sum(
            1 for t in tracks
            if (t.get('genre') or '').lower() == 'silence'
            or (self.music_dir / self._track_filename(t.get('id'))).exists()
        )

    def _missing_music_count(self, tracks: List[Dict[str, Any]]) -> int:
        return sum(
            1 for t in tracks
            if (t.get('genre') or '').lower() != 'silence'
            and not (self.music_dir / self._track_filename(t.get('id'))).exists()
        )

    def _load_plan(self) -> Dict[str, Any]:
        if not self.plan_path.exists():
            raise FileNotFoundError(f"music_plan.json не найден: {self.plan_path}")
        data = json.loads(self.plan_path.read_text(encoding='utf-8-sig'))
        if 'music_plan' in data and 'tracks' in data['music_plan']:
            return data['music_plan']
        return data

    def _save_plan(self, plan: Dict[str, Any]) -> None:
        wrapped = {'music_plan': plan} if 'tracks' in plan else plan
        self.plan_path.write_text(
            json.dumps(wrapped, indent=2, ensure_ascii=False),
            encoding='utf-8',
        )


# =========================================================================
# CLI helper для запуска вручную
# =========================================================================

def generate_for_project(
    project_dir: str,
    force: bool = False,
    browser: Optional[str] = None,
    model: Optional[str] = None,
    parallel: int = 1,
) -> Dict[str, Any]:
    orch = MusicOrchestrator(
        project_dir=project_dir, browser=browser, model=model, parallel=parallel,
    )
    return orch.generate_all(force=force)
