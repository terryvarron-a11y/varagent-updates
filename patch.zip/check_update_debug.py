import sys
sys.path.insert(0, r'l:\_комбайн\режиссер_сцен\SCENAGENT_RTG\VARAGENT_API_PORTABLE\agent\modules')

from pathlib import Path
import updater as mu

result = mu.check_updates(Path(r'l:\_комбайн\режиссер_сцен\SCENAGENT_RTG\VARAGENT_API_PORTABLE'))

print('available:', result.get('available'))
print('version:', result.get('version'))
print('error:', result.get('error'))
print('changed_files:', result.get('changed_files'))
