"""
Shared Gemini-based prompt rewriter for censorship bypass.

Instruction template is loaded from:
    agent/prompts/rewrite_prompt.txt

Edit that file to customize the rewrite instruction without touching code.
The file must contain the placeholder {original_prompt} somewhere.
"""

import logging
from pathlib import Path

_PROMPT_FILE = Path(__file__).resolve().parent.parent / "prompts" / "rewrite_prompt.txt"

_DEFAULT_TEMPLATE = (
    "A video/image generation prompt was rejected by the generation engine (Google Veo / VeoNonStop). "
    "The rejection could be caused by ANY of the reasons listed below — not necessarily the obvious ones. "
    "Analyze the prompt carefully and fix ALL potential triggers simultaneously.\n\n"

    "1. REAL PERSON NAMES: Replace any real celebrity, politician, historical figure, athlete, "
    "religious leader, or other named public figure with a detailed physical description "
    "(approximate age, face shape, hair color/style, eye color, skin tone, body build, "
    "distinctive features). Do NOT include the name or any identifying label.\n\n"

    "2. VIOLENCE / EXPLICIT CONTENT: Replace blood, gore, weapons, fights, death, nudity, "
    "sexual content with cinematic equivalents. Show tension instead of violence, "
    "aftermath instead of action, suggestion instead of depiction. Keep dramatic mood intact.\n\n"

    "3. AMBIGUOUS / GENERIC TRIGGERS (fix these even if the above seem fine):\n"
    "   - Copyrighted characters, logos, brand names, trademarked objects → describe generically "
    "     (e.g. 'a red-capped cartoon plumber' instead of a Nintendo character name)\n"
    "   - Politically sensitive symbols, flags, disputed territories, government buildings "
    "     → describe visually without naming the political entity\n"
    "   - Age-ambiguous characters that could be perceived as minors in adult situations "
    "     → explicitly describe as clearly adult (25-35 years old, mature appearance)\n"
    "   - Overly complex or contradictory scene instructions that may confuse the model "
    "     → simplify and clarify the visual description\n"
    "   - Phrases that could imply harm, danger, or illegal activity (even metaphorically) "
    "     → reword to remove the ambiguity while preserving the visual meaning\n"
    "   - Names that coincidentally match celebrities even if used generically "
    "     → replace with a physical description or a clearly fictional placeholder\n\n"

    "CRITICAL RULES:\n"
    "- The output MUST be textually different from the input — even slightly different wording counts.\n"
    "- Keep scene composition, camera angle, lighting, color palette, visual style, and setting.\n"
    "- Do NOT summarize, explain, or add commentary. Return ONLY the rewritten prompt.\n\n"
    "Prompt: {original_prompt}"
)

# Fallback used when the normal rewrite returns the same text.
# More aggressive: explicitly lists trigger words and forces rephrasing.
_FORCE_TEMPLATE = (
    "An image generation prompt was blocked by safety filters. "
    "Your task is to rephrase it so the same visual scene is described with different words.\n\n"
    "ALWAYS replace these types of words with neutral cinematic equivalents:\n"
    "- 'bloody', 'blood', 'bleeding' → 'battle-worn', 'marked', 'injured'\n"
    "- 'nose bleed', 'bloody nose' → 'face injury', 'marked face', 'bruised face'\n"
    "- 'fighting', 'fight', 'brawl' → 'physical confrontation', 'struggle', 'clash'\n"
    "- 'punch', 'hit', 'beat', 'strike' → 'impact', 'force', 'tension'\n"
    "- 'kill', 'dead', 'death', 'murder' → 'end', 'silence', 'finality'\n"
    "- 'weapon', 'gun', 'knife', 'blade' → 'tool', 'object', 'instrument'\n"
    "- 'gore', 'wound', 'injury' → 'mark', 'aftermath', 'trace'\n"
    "- Real person names → detailed physical description (age, hair, eyes, skin, build)\n\n"
    "Even if none of the above seem present, ALWAYS produce a DIFFERENT version "
    "using synonyms, restructured sentences, or alternative visual descriptions. "
    "The output MUST NOT be identical to the input.\n\n"
    "Rules:\n"
    "- Keep camera angle, lighting, color style, setting, and composition.\n"
    "- Return ONLY the rewritten prompt, no explanations.\n\n"
    "Original prompt:\n{original_prompt}"
)


def _load_template() -> str:
    """Load rewrite instruction template from file, fall back to built-in default."""
    try:
        text = _PROMPT_FILE.read_text(encoding='utf-8').strip()
        if '{original_prompt}' not in text:
            logging.warning(
                f"rewrite_prompt.txt is missing {{original_prompt}} placeholder — using built-in default"
            )
            return _DEFAULT_TEMPLATE
        return text
    except Exception as e:
        logging.warning(f"Could not read rewrite_prompt.txt ({e}) — using built-in default")
        return _DEFAULT_TEMPLATE


def _call_gemini(client, model: str, instruction: str) -> str:
    """Call Gemini and return stripped text, or empty string on failure."""
    try:
        resp = client.models.generate_content(model=model, contents=instruction)
        return resp.text.strip() if resp.text else ''
    except Exception as e:
        logging.warning(f"Gemini generate_content failed: {e}")
        return ''


def _save_rewrite_debug(project_dir, clip_id, original: str, pass1: str, pass2: str, final: str):
    """Save rewrite debug info to project_dir/rewrite_debug.log if project_dir given."""
    if not project_dir:
        return
    try:
        import datetime
        path = Path(project_dir) / 'rewrite_debug.log'
        ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        with open(path, 'a', encoding='utf-8') as f:
            f.write(f"\n{'='*60}\n")
            f.write(f"[{ts}] Clip #{clip_id}\n")
            f.write(f"--- ORIGINAL ---\n{original}\n")
            if pass1:
                f.write(f"--- GEMINI PASS 1 ---\n{pass1}\n")
            else:
                f.write(f"--- GEMINI PASS 1 --- (empty)\n")
            if pass2 is not None:
                f.write(f"--- GEMINI PASS 2 (force) ---\n{pass2 if pass2 else '(empty)'}\n")
            f.write(f"--- FINAL ---\n{final}\n")
    except Exception as e:
        logging.debug(f"rewrite_debug save failed: {e}")


def rewrite_prompt(original_prompt: str, project_dir=None, clip_id=None) -> str:
    """
    Rewrite a blocked generation prompt via Gemini API.

    Uses GEMINI_API_KEY and GEMINI_MODEL from agent/config (agent/.env).
    Instruction is loaded from agent/prompts/rewrite_prompt.txt — edit freely.

    If the first rewrite returns identical text, retries with a more aggressive
    force-rephrase instruction.

    Args:
        original_prompt: The blocked prompt to rewrite.
        project_dir: Optional path to project folder — used for rewrite_debug.log.
        clip_id: Optional clip ID — used for debug logging.

    Returns:
        Rewritten prompt string, or the original if all rewrites fail / return identical text.
    """
    try:
        from google import genai as _genai
    except ImportError:
        logging.warning("google-genai not installed — prompt rewrite skipped")
        return original_prompt

    try:
        import config
        api_key = config.GEMINI_API_KEY
        model = config.GEMINI_MODEL
    except Exception as e:
        logging.warning(f"Could not load config for Gemini rewrite: {e}")
        return original_prompt

    if not api_key:
        logging.warning("GEMINI_API_KEY not set — prompt rewrite skipped")
        return original_prompt

    prompt_snippet = original_prompt[:100].replace('\n', ' ')
    gemini_client = _genai.Client(api_key=api_key)

    # ── Pass 1: normal rewrite instruction ────────────────────────────
    template = _load_template()
    instruction = template.replace("{original_prompt}", original_prompt)
    text1 = _call_gemini(gemini_client, model, instruction)

    if not text1:
        logging.warning(f"Gemini rewrite pass 1 returned EMPTY. Original: [{prompt_snippet}]")
    elif text1 == original_prompt:
        logging.warning(f"Gemini rewrite pass 1 returned IDENTICAL text. Original: [{prompt_snippet}]")
    else:
        logging.info(f"Prompt rewritten via Gemini (pass 1): [{prompt_snippet}...]")
        _save_rewrite_debug(project_dir, clip_id, original_prompt, text1, None, text1)
        return text1

    # ── Pass 2: aggressive force-rephrase ─────────────────────────────
    logging.warning(f"Retrying with force-rephrase template (pass 2)...")
    force_instruction = _FORCE_TEMPLATE.replace("{original_prompt}", original_prompt)
    text2 = _call_gemini(gemini_client, model, force_instruction)

    if not text2:
        logging.warning(f"Gemini rewrite pass 2 returned EMPTY.")
    elif text2 == original_prompt:
        logging.warning(f"Gemini rewrite pass 2 also returned IDENTICAL text.")
    else:
        logging.info(f"Prompt rewritten via Gemini (pass 2 force): [{prompt_snippet}...]")
        _save_rewrite_debug(project_dir, clip_id, original_prompt, text1, text2, text2)
        return text2

    logging.warning(f"All Gemini rewrite passes failed — using original prompt")
    _save_rewrite_debug(project_dir, clip_id, original_prompt, text1, text2, original_prompt)
    return original_prompt
