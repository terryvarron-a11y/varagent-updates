"""
Конфигурация агента Video Production Agent
"""
import os
import sys
from pathlib import Path
from dotenv import load_dotenv

# Загрузка переменных окружения из .env
load_dotenv(Path(__file__).parent / '.env')


def _model(key: str, default: str = '') -> str:
    """Читает имя модели из env, обрезая инлайн-комментарии (# ...)."""
    return os.getenv(key, default).split('#')[0].strip()


def _db_env(key: str, default: str) -> int:
    """Read a dB env value. Positive UI values like 16 mean -16 dB."""
    raw = os.getenv(key, default).split('#')[0].strip()
    try:
        value = float(raw)
    except (TypeError, ValueError):
        value = float(default)
    if value > 0:
        value = -value
    value = max(-60.0, min(0.0, value))
    return int(round(value))

# ============================================================================
# API КЛЮЧИ
# ============================================================================

# AssemblyAI API (транскрипция)
ASSEMBLYAI_API_KEY = os.getenv('ASSEMBLYAI_API_KEY', '')

# Gemini API (режиссура)
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY', '')

# ============================================================================
# ПУТИ К ФАЙЛАМ
# ============================================================================

# Базовая директория проекта
BASE_DIR = Path(__file__).parent

# Директория с промптами
PROMPTS_DIR = BASE_DIR / 'prompts'

# Директория для временных файлов
TEMP_DIR = BASE_DIR / 'temp'

# Директория для логов
LOGS_DIR = BASE_DIR / 'logs'

# ============================================================================
# НАСТРОЙКИ ASSEMBLYAI
# ============================================================================

# Модели транскрипции (приоритетный список, через запятую)
# universal-3-pro — лучшее качество ($0.21/ч)
# universal-2     — быстрее и дешевле ($0.15/ч, -40%)
_speech_models_raw = os.getenv('ASSEMBLYAI_SPEECH_MODELS', 'universal-3-pro,universal-2')
ASSEMBLYAI_SPEECH_MODELS = [m.strip() for m in _speech_models_raw.split(',') if m.strip()]

# Язык транскрипции (по умолчанию, можно переопределить в CLI)
ASSEMBLYAI_LANGUAGE_CODE = os.getenv('ASSEMBLYAI_LANGUAGE_CODE', 'ru')

# Поддерживаемые языки
ASSEMBLYAI_SUPPORTED_LANGUAGES = [
    'en',  # English
    'ru',  # Russian
    'es',  # Spanish
    'fr',  # French
    'de',  # German
    'it',  # Italian
    'pt',  # Portuguese
    'nl',  # Dutch
    'pl',  # Polish
    'ja',  # Japanese
    'zh',  # Chinese
    'ko',  # Korean
    'hi',  # Hindi
    'ar',  # Arabic
]

# Режим сегментации транскрипции: 'sentences' или 'paragraphs'
# sentences  — каждое предложение отдельный блок (по умолчанию)
# paragraphs — группирует предложения в смысловые абзацы (меньше блоков, шире охват)
ASSEMBLYAI_SEGMENTATION_MODE = os.getenv('ASSEMBLYAI_SEGMENTATION_MODE', 'sentences')

# HTTP timeout for AssemblyAI SDK (seconds). Default 30s is too low for large files on slow connections.
ASSEMBLYAI_HTTP_TIMEOUT = float(os.getenv('ASSEMBLYAI_HTTP_TIMEOUT', '600'))

# Браузер для cookies yt-dlp: chrome, edge, firefox, opera, brave (пустой = авто-детект)
YTDLP_COOKIES_BROWSER = os.getenv('YTDLP_COOKIES_BROWSER', '')

# ============================================================================
# НАСТРОЙКИ GEMINI
# ============================================================================

# Модель для режиссуры (по умолчанию)
GEMINI_MODEL = _model('GEMINI_MODEL', 'gemini-3.1-pro')

# Модель для rewrite промптов (при цензуре VEO). flash = бесплатно/быстро, pro = точнее
# Формат: 'gemini:model-name' или 'gpt:model-name'
REWRITE_MODEL = os.getenv('REWRITE_MODEL', 'gpt:gpt-5.4-mini')

# Модель для vision_checks (проверки изображений перед ремиксом)
VISION_CHECK_MODEL = _model('VISION_CHECK_MODEL', 'gemini-2.5-flash')

# Free-tier Gemini API-ключ — используется как fallback для vision_checks / rewrite,
# если VISION_API_KEY пуст. paid GEMINI_API_KEY не трогаем.
GEMINI_API_KEY_FREE = os.getenv('GEMINI_API_KEY_FREE', '')

# Отдельный API-ключ для vision_checks + gemini_rewrite (free-tier, чтобы не жрать paid-квоту)
# Priority: VISION_API_KEY → GEMINI_API_KEY_FREE → (пусто, операция скипается — paid НЕ используется)
VISION_API_KEY = os.getenv('VISION_API_KEY', '') or GEMINI_API_KEY_FREE

# Thinking Level для Gemini 3.x Pro (уровень мышления)
# Значения: 'low', 'medium', 'high'
# Влияет на глубину анализа и количество токенов
GEMINI_THINKING_LEVEL = os.getenv('GEMINI_THINKING_LEVEL', 'medium')

# Двухпроходный режим: проход 1 = JSON план, проход 2 = промпты (для длинных проектов)
GEMINI_TWO_PASS = os.getenv('GEMINI_TWO_PASS', 'false').lower() in ('true', '1', 'yes')

# Прямое задание thinking budget в токенах (для Gemini 2.x)
# Если задан — переопределяет GEMINI_THINKING_LEVEL для 2.x моделей
# 0 = не задан, используется маппинг из GEMINI_THINKING_LEVEL
_budget_raw = os.getenv('GEMINI_THINKING_BUDGET', '0')
GEMINI_THINKING_BUDGET = int(_budget_raw) if _budget_raw.isdigit() else 0

# Thinking для второго прохода (промпты) в двухпроходном режиме
# Gemini 3.x: 'low', 'medium', 'high' (по умолчанию 'low')
GEMINI_THINKING_LEVEL_PASS2 = os.getenv('GEMINI_THINKING_LEVEL_PASS2', 'medium')
# Gemini 2.x: budget в токенах (0 = использовать дефолт: 8000 для Pro, 0 для Flash)
_budget_p2_raw = os.getenv('GEMINI_THINKING_BUDGET_PASS2', '0')
GEMINI_THINKING_BUDGET_PASS2 = int(_budget_p2_raw) if _budget_p2_raw.isdigit() else 0

# Генерация director_analysis.md (по умолчанию включена для отладки)
GENERATE_DIRECTOR_ANALYSIS = os.getenv('GENERATE_DIRECTOR_ANALYSIS', 'true').lower() in ('true', '1', 'yes')

# Максимальный размер чанка промптов в проходе 2.
# Если клипов больше — pass 2 разбивается на чанки по PROMPT_CHUNK_SIZE клипов.
# 0 = чанкование отключено (один запрос на все клипы).
_chunk_raw = os.getenv('PROMPT_CHUNK_SIZE', '150')
PROMPT_CHUNK_SIZE = int(_chunk_raw) if _chunk_raw.isdigit() else 150

# Чанкование Pass 1 (монтажный план) для длинных озвучек.
# THRESHOLD: если audioDuration > этого порога (сек), Pass 1 разбивается на чанки.
# 0 = всегда монолит (старый режим).
DIRECTOR_PASS1_CHUNK_THRESHOLD = int(os.getenv('DIRECTOR_PASS1_CHUNK_THRESHOLD', '2400'))
# Длина одного чанка Pass 1 (сек). 2400 сек = 40 мин, 1200 = 20 мин.
DIRECTOR_PASS1_CHUNK_DURATION  = int(os.getenv('DIRECTOR_PASS1_CHUNK_DURATION',  '1200'))

# Откат при авто-дополнении (rollback).
# Continuation loop отсекает последние N "уставших" промптов и просит их заново.
# 0 = откат отключён (дописываем строго с позиции обрыва).
_rollback_raw = os.getenv('CONT_ROLLBACK_SIZE', '20')
CONT_ROLLBACK_SIZE = int(_rollback_raw) if _rollback_raw.isdigit() else 20

# ---- Чанкинг Pass 1 для АКТИВНОГО режиссёра (chat_director: cliproxy/deepseek/openrouter) ----
# Отдельные ключи от DIRECTOR_PASS1_CHUNK_* (те — мёртвый director.py/Gemini). Управляются
# ЧЕКБОКСОМ в GUI; .env — только хранилище дефолтов.
#
# PASS1_CHUNK_ENABLED: чекбокс «Чанкинг Pass 1». true → длинное аудио режется на окна по
#   PASS1_CHUNK_MINUTES минут, план строится по окну и сшивается (id_offset). false → монолит
#   (одно окно на весь ролик). В ОБОИХ режимах работает валидатор обрезки окна (докач).
_p1chunk_raw = (os.getenv('PASS1_CHUNK_ENABLED', '') or 'false').strip().lower()
PASS1_CHUNK_ENABLED = _p1chunk_raw in ('1', 'true', 'yes', 'on')
# Размер окна чанка Pass 1 в МИНУТАХ (клипов заранее нет — меряем временем). Дефолт 20 мин.
_p1min_raw = os.getenv('PASS1_CHUNK_MINUTES', '') or '20'
PASS1_CHUNK_MINUTES = int(_p1min_raw) if _p1min_raw.isdigit() and int(_p1min_raw) > 0 else 20
# Параллель Pass 1: число воркеров. 1 = последовательно, >1 = параллель (окна непересекающиеся).
# Та же семантика, что у GPT_PASS2_PARALLEL.
_p1par_raw = os.getenv('PASS1_PARALLEL', '') or '1'
PASS1_PARALLEL = int(_p1par_raw) if _p1par_raw.isdigit() and int(_p1par_raw) > 0 else 1

# ============================================================================
# GPT / CODEX DIRECTOR (alternative to Gemini)
# ============================================================================

# Backend режиссуры: 'gemini' (default) или 'gpt' (Codex CLI)
DIRECTOR_BACKEND = (os.getenv('DIRECTOR_BACKEND', '') or 'gpt').strip().lower()

# Путь к Codex CLI exe (auto-detect per platform)
import shutil as _shutil
_codex_env = os.getenv('CODEX_EXE_PATH', '')
if _codex_env and os.path.exists(_codex_env):
    CODEX_EXE_PATH = _codex_env
elif sys.platform == 'win32':
    _codex_win = str(BASE_DIR.parent / 'Codex' / 'codex-x86_64-pc-windows-msvc.exe')
    CODEX_EXE_PATH = _codex_win if os.path.exists(_codex_win) else ''
else:
    # macOS / Linux: ищем в PATH (npm install -g @openai/codex)
    CODEX_EXE_PATH = _shutil.which('codex') or ''

# Модель GPT для режиссуры через Codex
GPT_MODEL = _model('GPT_MODEL', 'gpt-5.4')  # default: full model, not mini

# Таймаут на один exec вызов Codex (секунды)
GPT_DIRECTOR_TIMEOUT = int(os.getenv('GPT_DIRECTOR_TIMEOUT', '1200'))
# Отдельный короткий таймаут для одного вызова Codex в rewrite-цепочке цензуры.
# Не должен зависать на 20 мин из-за одного клипа — rewrite быстрый по природе.
GPT_REWRITE_TIMEOUT = int(os.getenv('GPT_REWRITE_TIMEOUT', '90'))

# ============================================================================
# CLAUDE DIRECTOR (alternative backend: Claude Code CLI + Claude API)
# ============================================================================
_claude_env = os.getenv('CLAUDE_CODE_EXE_PATH', '').strip()
if _claude_env:
    CLAUDE_CODE_EXE_PATH = _claude_env
else:
    CLAUDE_CODE_EXE_PATH = _shutil.which('claude') or _shutil.which('claude.cmd') or ''

# Claude Code accepts aliases like "sonnet" / "opus" and full model names.
CLAUDE_MODEL = _model('CLAUDE_MODEL', 'sonnet')
CLAUDE_DIRECTOR_TIMEOUT = int(os.getenv('CLAUDE_DIRECTOR_TIMEOUT', str(GPT_DIRECTOR_TIMEOUT)))
CLAUDE_CODE_MAX_TURNS = int(os.getenv('CLAUDE_CODE_MAX_TURNS', '20'))
CLAUDE_CODE_PERMISSION_MODE = os.getenv('CLAUDE_CODE_PERMISSION_MODE', 'bypassPermissions').strip()

# true = prefer logged-in Claude Pro/Max subscription. We remove ANTHROPIC_API_KEY
# from the child process so Claude Code does not silently switch to API billing.
CLAUDE_CODE_USE_SUBSCRIPTION = os.getenv(
    'CLAUDE_CODE_USE_SUBSCRIPTION', 'true'
).lower() in ('true', '1', 'yes')

# CLAUDE API DIRECTOR (direct API key, no browser/CLI login)
CLAUDE_API_KEY = os.getenv('CLAUDE_API_KEY', '').strip()
ANTHROPIC_API_KEY = os.getenv('ANTHROPIC_API_KEY', '').strip()
CLAUDE_API_BASE = os.getenv('CLAUDE_API_BASE', 'https://api.codexhub.click/v1').strip()
CLAUDE_API_FORMAT = os.getenv('CLAUDE_API_FORMAT', 'openai').strip().lower()
_claude_api_default_model = (
    'kr/claude-sonnet-4.6'
    if CLAUDE_API_FORMAT in ('openai', 'auto') and 'api.codexhub.click' in CLAUDE_API_BASE
    else (CLAUDE_MODEL if str(CLAUDE_MODEL).startswith('claude-') else 'claude-sonnet-4-20250514')
)
CLAUDE_API_MODEL = _model('CLAUDE_API_MODEL', _claude_api_default_model)
CLAUDE_API_VERSION = os.getenv('CLAUDE_API_VERSION', '2023-06-01').strip()
CLAUDE_API_BETA = os.getenv('CLAUDE_API_BETA', '').strip()
CLAUDE_API_MAX_TOKENS = int(os.getenv('CLAUDE_API_MAX_TOKENS', '16000'))
CLAUDE_API_TEMPERATURE = float(os.getenv('CLAUDE_API_TEMPERATURE', '0.4'))
CLAUDE_API_RESPONSE_FORMAT = os.getenv('CLAUDE_API_RESPONSE_FORMAT', 'json_object').strip()
_claude_api_debug_dir = os.getenv('CLAUDE_API_DEBUG_DIR', str(LOGS_DIR)).strip()
CLAUDE_API_DEBUG_DIR = str(
    (BASE_DIR / _claude_api_debug_dir) if _claude_api_debug_dir and not Path(_claude_api_debug_dir).is_absolute()
    else Path(_claude_api_debug_dir or LOGS_DIR)
)
_claude_api_pass2_chunk_raw = os.getenv('CLAUDE_API_PASS2_CHUNK_SIZE', '20')
CLAUDE_API_PASS2_CHUNK_SIZE = (
    int(_claude_api_pass2_chunk_raw) if _claude_api_pass2_chunk_raw.isdigit() else 20
)
# Claude Code (CLI) pass2 chunk — отдельный от api; по умолчанию как api (20)
_claude_code_pass2_chunk_raw = os.getenv('CLAUDE_CODE_PASS2_CHUNK_SIZE', '20')
CLAUDE_CODE_PASS2_CHUNK_SIZE = (
    int(_claude_code_pass2_chunk_raw) if _claude_code_pass2_chunk_raw.isdigit() else 20
)
CLAUDE_API_USER_AGENT = os.getenv(
    'CLAUDE_API_USER_AGENT',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) VARAGENT/1.0'
).strip()
CLAUDE_API_REFERER = os.getenv('CLAUDE_API_REFERER', 'https://codexhub.click/').strip()

# ============================================================================
# MUSIC (Pass 3) — Suno cookie auth + music director
# ============================================================================
MUSIC_PROVIDER = os.getenv('MUSIC_PROVIDER', 'suno').strip().lower()
MUSIC_SAFE_MODE = os.getenv('MUSIC_SAFE_MODE', 'true').lower() in ('true', '1', 'yes', 'on')
MUSIC_ALLOW_CONTENT_ID = os.getenv('MUSIC_ALLOW_CONTENT_ID', 'false').lower() in ('true', '1', 'yes', 'on')

# Local Sound Library — папка с личной музыкой (провайдер local_library).
# Задаётся в GUI (блок Music). Пусто = ищем только в проекте
# (music_stock/ или stock_music/) — старое поведение.
MUSIC_LIBRARY_DIR = os.getenv('MUSIC_LIBRARY_DIR', '').strip()

MUSIC_STOCK_PROVIDER = os.getenv('MUSIC_STOCK_PROVIDER', 'pixabay').strip().lower()

# ============================================================================
# STOCK (Pexels / Pixabay / Local Stock Library) — сток-футаж и фото
# ============================================================================
STOCK_ENABLED = os.getenv('STOCK_ENABLED', 'false').lower() in ('true', '1', 'yes', 'on')
# Источники через запятую: local | pexels | pixabay
STOCK_SOURCES = [s.strip().lower() for s in os.getenv('STOCK_SOURCES', 'local,pexels,pixabay').split(',') if s.strip()]
# Доля ВСЕХ клипов под сток; внутри неё — доля видео (остальное фото)
STOCK_RATIO_TARGET = float(os.getenv('STOCK_RATIO_TARGET', '0.30') or '0.30')
STOCK_VIDEO_SHARE = float(os.getenv('STOCK_VIDEO_SHARE', '0.70') or '0.70')
# Звук футажа: убирать по умолчанию (музыка футажа поверх голоса + канал Content ID-клеймов)
STOCK_MUTE_AUDIO = os.getenv('STOCK_MUTE_AUDIO', 'true').lower() in ('true', '1', 'yes', 'on')
# Стартовая точка сегмента и её случайный разброс
STOCK_CLIP_START_SEC = float(os.getenv('STOCK_CLIP_START_SEC', '0') or '0')
STOCK_CLIP_START_JITTER = os.getenv('STOCK_CLIP_START_JITTER', 'false').lower() in ('true', '1', 'yes', 'on')
STOCK_CLIP_START_JITTER_SEC = float(os.getenv('STOCK_CLIP_START_JITTER_SEC', '2') or '2')
# Не нашлось нигде → клип уходит в обычную нейрогенерацию
STOCK_PROMPT_FALLBACK = os.getenv('STOCK_PROMPT_FALLBACK', 'true').lower() in ('true', '1', 'yes', 'on')
# Макс. время фоновой загрузки стока (сек). Дедлайн = МИН(это, готовность пайплайна):
# конкат не ждёт — недокачанные клипы уходят в нейрогенерацию по промпту режиссёра.
# Своя настройка (не общая с real_photo): видео качается дольше архивных фото.
STOCK_WAIT_TIMEOUT = int(os.getenv('STOCK_WAIT_TIMEOUT', '1800'))
# Оператор промптажа стока (запросы + сопоставление своей библиотеки).
# Пусто/auto = тот же, кем размечает режиссёр.
STOCK_PROMPT_PROVIDER = os.getenv('STOCK_PROMPT_PROVIDER', '').strip().lower()
STOCK_PROMPT_MODEL = _model('STOCK_PROMPT_MODEL', '')
# Отсекать ИИ-сгенерированный сток (умеет только Pixabay: isAiGenerated)
STOCK_EXCLUDE_AI = os.getenv('STOCK_EXCLUDE_AI', 'true').lower() in ('true', '1', 'yes', 'on')
# Своя папка с футажами (Local Stock Library). Пусто = источник выключен
STOCK_LIBRARY_DIR = os.getenv('STOCK_LIBRARY_DIR', '').strip()
STOCK_PROXY_URL = os.getenv('STOCK_PROXY_URL', '').strip()

# Прокси для ВСЕГО Codex/ChatGPT (одна подписка = один IP): режиссёр + промптеры + адаптеры
# + запрос квоты. Пусто = напрямую. Задаётся юзером в GUI (Settings). http:// или socks5://.
# Пробрасывается в env запускаемого codex.exe (HTTPS_PROXY/HTTP_PROXY/ALL_PROXY) и в usage-запрос.
CODEX_PROXY = os.getenv('CODEX_PROXY', '').strip()

# Прокси для Claude (подписка Pro/Max через CLIProxyAPI, claude.ai блокит РФ). Пусто = напрямую.
# Юзер задаёт в GUI (формат host:port:user:pass — нормализуется в URL). НЕ тянем из config.yaml втихую.
CLAUDE_PROXY = os.getenv('CLAUDE_PROXY', '').strip()
# Ключи (бесплатные). Пул: _2.._8 для ротации
PEXELS_API_KEY = os.getenv('PEXELS_API_KEY', '').strip()
PEXELS_API_KEY_2 = os.getenv('PEXELS_API_KEY_2', '').strip()
PEXELS_API_KEY_3 = os.getenv('PEXELS_API_KEY_3', '').strip()
PIXABAY_API_KEY = os.getenv('PIXABAY_API_KEY', '').strip()
PIXABAY_API_KEY_2 = os.getenv('PIXABAY_API_KEY_2', '').strip()
PIXABAY_API_KEY_3 = os.getenv('PIXABAY_API_KEY_3', '').strip()
MUSIC_STOCK_FALLBACK_PROCEDURAL = os.getenv(
    'MUSIC_STOCK_FALLBACK_PROCEDURAL', 'false'
).lower() in ('true', '1', 'yes', 'on')

# Браузер для извлечения Suno cookies. Chrome v127+ (App-Bound Encryption) не
# читается без admin/rookiepy — рекомендуется firefox или edge.
SUNO_COOKIE_BROWSER = os.getenv('SUNO_COOKIE_BROWSER', 'firefox').lower().strip()

# Suno model: chirp-fenix (v5.5), chirp-v3-5, chirp-v4
SUNO_MODEL = _model('SUNO_MODEL', 'chirp-fenix')

# Параллельные потоки music_orchestrator (1 = последовательно; не >2-3 из-за rate-limit).
SUNO_PARALLEL = int(os.getenv('SUNO_PARALLEL', '1'))

# Sleep между sequential генерациями (sec) — против Suno 422 rate-limit.
SUNO_INTER_TRACK_SLEEP = int(os.getenv('SUNO_INTER_TRACK_SLEEP', '30'))

# Громкость музыки в финальном миксе. Положительное 16 = -16 dB.
MUSIC_DEFAULT_VOLUME_DB = _db_env('MUSIC_DEFAULT_VOLUME_DB', '-21')
MUSIC_MIX_MAX_VOLUME_DB = _db_env('MUSIC_MIX_MAX_VOLUME_DB', '0')

# На сколько dB музыка душится под голосом (sidechain compressor).
MUSIC_DUCKING_DB = _db_env('MUSIC_DUCKING_DB', '-5')
MUSIC_SIDECHAIN_THRESHOLD_DB = int(os.getenv('MUSIC_SIDECHAIN_THRESHOLD_DB', '-25'))
MUSIC_SIDECHAIN_RATIO = float(os.getenv('MUSIC_SIDECHAIN_RATIO', '0') or '0')
MUSIC_SIDECHAIN_ATTACK_MS = int(os.getenv('MUSIC_SIDECHAIN_ATTACK_MS', '25'))
MUSIC_SIDECHAIN_RELEASE_MS = int(os.getenv('MUSIC_SIDECHAIN_RELEASE_MS', '800'))

# Crossfade между соседними треками (мс)
MUSIC_CROSSFADE_MS = int(os.getenv('MUSIC_CROSSFADE_MS', '2000'))

# Music plan simplification — coarse long beds, concat trims/loops them.
MUSIC_MIN_TRACK_DURATION = int(os.getenv('MUSIC_MIN_TRACK_DURATION', '120'))
MUSIC_MAX_TRACK_DURATION = int(os.getenv('MUSIC_MAX_TRACK_DURATION', '240'))
MUSIC_MAX_TRACKS = int(os.getenv('MUSIC_MAX_TRACKS', '10'))

# Локальный fallback (FFmpeg ambient) если Suno auth/rate-limit упал.
MUSIC_FALLBACK_ON_SUNO_FAIL = os.getenv(
    'MUSIC_FALLBACK_ON_SUNO_FAIL', 'true'
).lower() in ('true', '1', 'yes')
MUSIC_FALLBACK_MODE = os.getenv('MUSIC_FALLBACK_MODE', 'ffmpeg_ambient').strip().lower()

# Backend для Music Director — gpt (Codex), deepseek/openrouter (chat),
# claude_code, claude_api или gemini. Пусто = наследует DIRECTOR_BACKEND.
MUSIC_DIRECTOR_BACKEND = os.getenv('MUSIC_DIRECTOR_BACKEND', '').strip().lower()

# Конкретная модель (slug) для music-режиссёра при chat-backend (deepseek/openrouter).
# Пусто = провайдерский дефолт (OPENROUTER_MODEL / DEEPSEEK_MODEL). Позволяет писать
# музыкальный план любой моделью независимо от модели основного director'а.
MUSIC_CHAT_MODEL = _model('MUSIC_CHAT_MODEL', '')

# ============================================================================
# ENTITY OVERLAY (карточки персон/мест из Wikipedia поверх видео)
# ============================================================================
ENTITY_OVERLAY_ENABLED = os.getenv('ENTITY_OVERLAY_ENABLED', 'false').lower() in ('true', '1', 'yes', 'on')
ENTITY_OVERLAY_BACKEND = os.getenv('ENTITY_OVERLAY_BACKEND', 'auto').strip().lower()  # auto|gpt|deepseek|openrouter|cliproxy|claude_api|gemini|claude|regex
# Модель детекции сущностей. Пусто → дефолт выбранного провайдера.
ENTITY_OVERLAY_MODEL = _model('ENTITY_OVERLAY_MODEL', '')
_entity_overlay_max_raw = os.getenv('ENTITY_OVERLAY_MAX', '20').strip().lower()
try:
    ENTITY_OVERLAY_MAX = 0 if _entity_overlay_max_raw in ('0', 'all', 'auto', 'max') else int(_entity_overlay_max_raw or '20')
except ValueError:
    ENTITY_OVERLAY_MAX = 20
ENTITY_OVERLAY_HOLD_SEC = float(os.getenv('ENTITY_OVERLAY_HOLD_SEC', '4.2'))
ENTITY_OVERLAY_MIN_GAP_SEC = float(os.getenv('ENTITY_OVERLAY_MIN_GAP_SEC', '24'))
ENTITY_OVERLAY_PROVIDERS = os.getenv('ENTITY_OVERLAY_PROVIDERS', 'wikipedia,yandex').strip()
ENTITY_OVERLAY_WIKI_LANGS = os.getenv('ENTITY_OVERLAY_WIKI_LANGS', 'ru,en').strip()
ENTITY_OVERLAY_MAX_DOWNLOAD_MB = int(os.getenv('ENTITY_OVERLAY_MAX_DOWNLOAD_MB', '12'))
# Сколько карточек качать одновременно. Раньше качались строго по одной, и на 20 карточках
# это давало минуты ожидания. 1 = старое поведение (последовательно).
ENTITY_OVERLAY_PARALLEL = max(1, int(os.getenv('ENTITY_OVERLAY_PARALLEL', '4') or '4'))
# Макс. время фоновой подготовки карточек (сек). Дедлайн = МИН(это, готовность пайплайна):
# конкат не ждёт — берёт из кэша те карточки, что успели.
ENTITY_OVERLAY_WAIT_TIMEOUT = int(os.getenv('ENTITY_OVERLAY_WAIT_TIMEOUT', '1800'))
ENTITY_OVERLAY_PLACE_CAPTION = os.getenv('ENTITY_OVERLAY_PLACE_CAPTION', 'false').lower() in ('true', '1', 'yes', 'on')

# YT Packer: длинные multi-lang промпты (титры+описание+теги × N языков)
# 90с мало — пакет может быть на 10+ минут. 600с = 10 мин.
YT_PACK_GPT_TIMEOUT = int(os.getenv('YT_PACK_GPT_TIMEOUT', '600'))

# Codex "high demand" cooldown (s) — пауза перед retry когда OpenAI возвращает
# "We're currently experiencing high demand". Retry сразу = опять та же стена.
GPT_HIGH_DEMAND_COOLDOWN = int(os.getenv('GPT_HIGH_DEMAND_COOLDOWN', '90'))

# Sandbox mode: 'danger-full-access' или 'workspace-write'
GPT_SANDBOX_MODE = os.getenv('GPT_SANDBOX_MODE', 'danger-full-access')

# Количество клипов на один exec вызов pass 2 (0 = все за раз).
# Default 80 — для chain mode жадная сборка чанков по цепочкам (см. _run_pass2).
_gpt_chunk_raw = os.getenv('GPT_PASS2_CHUNK_SIZE', '') or '80'
GPT_PASS2_CHUNK_SIZE = int(_gpt_chunk_raw) if _gpt_chunk_raw.isdigit() else 80

# Параллельных Codex процессов для Pass 2: max workers
# (1 = последовательно, N = до N одновременно). Дефолт 6 — баланс между скоростью
# и rate-limit ChatGPT Plus.
_gpt_parallel_raw = os.getenv('GPT_PASS2_PARALLEL', '') or '6'
GPT_PASS2_PARALLEL = int(_gpt_parallel_raw) if _gpt_parallel_raw.isdigit() else 6

# ============================================================================
# GPT PROVIDER: 'openai' | 'deepseek' | 'openrouter' (все кроме openai через Moon Bridge)
# ============================================================================
# Codex общается с моделью через OpenAI Responses API. DeepSeek и OpenRouter его не поддерживают,
# поэтому используется локальный прокси Moon Bridge (транслирует Responses → chat/completions).
# OpenRouter = унифицированный прокси ко всем моделям (Qwen, Claude, Gemini, etc) через OpenAI-формат.
# См. https://github.com/deepseek-ai/awesome-deepseek-agent (DeepSeek), https://openrouter.ai/docs (OpenRouter)
GPT_PROVIDER = (os.getenv('GPT_PROVIDER', '') or 'openai').strip().lower()

# DeepSeek API ключ (используется Moon Bridge'ом, прокидывается в его config.yml)
DEEPSEEK_API_KEY = os.getenv('DEEPSEEK_API_KEY', '').strip()
# Модель DeepSeek для режиссуры
DEEPSEEK_MODEL = _model('DEEPSEEK_MODEL', 'deepseek-v4-flash')

# OpenRouter API ключ (https://openrouter.ai/settings/keys)
OPENROUTER_API_KEY = os.getenv('OPENROUTER_API_KEY', '').strip()
# Модель OpenRouter: 'openrouter/free' (auto router), 'qwen/qwen3-coder:free', etc
OPENROUTER_MODEL = _model('OPENROUTER_MODEL', 'openrouter/free')
# Web Search для OpenRouter (прямой chat_director): 'enabled' → к модели добавляется
# суффикс ':online', 'disabled' → чистый slug (без интернета). GUI: web_on/web_off.
OPENROUTER_WEB_SEARCH = (os.getenv('OPENROUTER_WEB_SEARCH', '') or 'disabled').strip().lower()

# Codex/GPT через OpenAI-совместимый reseller-шлюз (тот же контракт, что в Story Rewriter).
CODEX_RESELLER_URL = (
    os.getenv('CODEX_RESELLER_URL', '')
    or 'https://ai.ailink1.com/v1/chat/completions'
).strip()
CODEX_RESELLER_API_KEY = os.getenv('CODEX_RESELLER_API_KEY', '').strip()
CODEX_RESELLER_MODEL = _model('CODEX_RESELLER_MODEL', 'gpt-5.6-terra')

# CLIProxyAPI — локальный прокси к Gemini 3.1 Pro через Antigravity OAuth (обход выжженной
# API-квоты Gemini). OpenAI-совместимый /v1/chat/completions на localhost:8317.
# Директор: GPT_PROVIDER=cliproxy. Реврайтер: REWRITE_MODEL=cliproxy:gemini-3.1-pro-low.
# Прокси должен быть запущен (cli-proxy-api -config ~/.cli-proxy-api/config.yaml).
# См. plan_cliproxy_gemini.md.
CLIPROXY_BASE_URL = (os.getenv('CLIPROXY_BASE_URL', '') or 'http://localhost:8317/v1/chat/completions').strip()
# Локальный ключ прокси (совпадает с api-keys в его config.yaml). НЕ внешний секрет — localhost.
CLIPROXY_API_KEY = os.getenv('CLIPROXY_API_KEY', 'varagent-cliproxy-local').strip()
CLIPROXY_MODEL = _model('CLIPROXY_MODEL', 'gemini-3.1-pro-low')
# Требовать прокси при добавлении Gemini-аккаунта CLIProxyAPI. true = строгий режим
# (без прокси не пускаем — IP спалится). false = можно без прокси: юзер сам под VPN,
# логин и инстанс пойдут напрямую (конфиги пишутся без proxy-url).
CLIPROXY_REQUIRE_PROXY = os.getenv('CLIPROXY_REQUIRE_PROXY', 'true').lower() in ('true', '1', 'yes', 'on')

# ============================================================================
# CHAT DIRECTOR (прямой HTTP для deepseek|openrouter, без Codex/Moon Bridge)
# ============================================================================
# Уровень reasoning/thinking режиссёра: off | low | medium | high | max.
# Маппится в нативные параметры провайдера (см. reasoning_params_for_provider).
CHAT_REASONING_LEVEL = (os.getenv('CHAT_REASONING_LEVEL', '') or 'medium').strip().lower()
# Максимум output-токенов на один chat-запрос (Pass2-чанк). Reasoning-модели жгут
# токены на размышления — нужен запас. Один общий лимит на каждый чанк.
try:
    CHAT_MAX_TOKENS = int(os.getenv('CHAT_MAX_TOKENS', '') or 64000)
except ValueError:
    CHAT_MAX_TOKENS = 64000

# Pass 2 оптимизация: выносить NEGATIVE-блок из вывода модели (дописывать скриптом).
# Стайлгайд должен иметь секцию "## NEGATIVE PROMPT — APPEND ... VERBATIM" с code-блоком.
# Срезает ~180 слов × N клипов дублирования → модель влезает в лимит ответа на больших чанках.
# Если секции нет — авто-fallback (модель пишет негатив сама). 1=вкл (дефолт), 0=выкл.
PASS2_EXTERNALIZE_NEGATIVE = (os.getenv('PASS2_EXTERNALIZE_NEGATIVE', '') or '1').strip() not in ('0', 'false', 'no', '')
# Pass 2 оптимизация: выносить hard-match подпись рефов '(MATCH the face...)' из вывода.
# Модель пишет короткий [name_ref.jpg], скрипт дописывает подпись к ПЕРВОМУ появлению токена
# (имя берётся из самого токена). Срезает ~40-80 слов в 96% промптов. 1=вкл (дефолт), 0=выкл.
PASS2_EXTERNALIZE_REFMATCH = (os.getenv('PASS2_EXTERNALIZE_REFMATCH', '') or '1').strip() not in ('0', 'false', 'no', '')
# Pass 2 оптимизация: выносить STYLE-блок из вывода модели (дописывать скриптом, как negative).
# Срезает ещё ~120 слов × N клипов. 1=вкл (дефолт), 0=выкл.
PASS2_EXTERNALIZE_STYLE = (os.getenv('PASS2_EXTERNALIZE_STYLE', '') or '1').strip() not in ('0', 'false', 'no', '')
# КАК выделять style/negative блоки из стайлгайда:
#   neuro  — семантически нейрой (style_extractor, любой SG, +1 дешёвый вызов) — ДЕФОЛТ
#   regex  — питон по якорям ("...VERBATIM..." + code) — 0 токенов, нужна конвенция в SG
#   off    — не выносить (модель пишет стиль/негатив сама, как раньше)
STYLE_EXTRACT_MODE = (os.getenv('STYLE_EXTRACT_MODE', '') or 'neuro').strip().lower()
# Backend для нейро-выделения блоков: deepseek|openrouter|gemini|claude_api.
# Пусто = подобрать дешёвый по доступному ключу (deepseek→openrouter→gemini).
STYLE_EXTRACT_BACKEND = os.getenv('STYLE_EXTRACT_BACKEND', '').strip().lower()
# Конкретная модель (slug) для нейро-выделения. Пусто = провайдерский дефолт.
STYLE_EXTRACT_MODEL = _model('STYLE_EXTRACT_MODEL', '')


def reasoning_params_for_provider(provider: str, level: str = None) -> dict:
    """Маппит GUI-уровень reasoning (off/low/medium/high/max) в нативные параметры
    провайдера для тела chat/completions запроса.

    DeepSeek: thinking {enabled|disabled} + reasoning_effort (только high|max).
    OpenRouter: reasoning {effort: none|low|medium|high|xhigh, exclude: true}.
    Возвращает dict, который мёрджится в request body (пустой при неизвестном провайдере).
    """
    level = (level or CHAT_REASONING_LEVEL or 'medium').strip().lower()
    provider = (provider or '').strip().lower()

    if provider == 'deepseek':
        if level == 'off':
            return {'thinking': {'type': 'disabled'}}
        # DeepSeek знает только high|max (low/medium → high по их же compat-слою)
        effort = 'max' if level == 'max' else 'high'
        return {'thinking': {'type': 'enabled'}, 'reasoning_effort': effort}

    if provider == 'openrouter':
        # off: НЕ шлём effort:none — на reasoning-обязательных моделях free-роутера это
        # даёт HTTP 400 ("Reasoning is mandatory..."). Вместо этого exclude:true —
        # модель думает минимально, но COT не возвращает. Совместимо со всеми моделями.
        if level == 'off':
            return {'reasoning': {'exclude': True}}
        _map = {'low': 'low', 'medium': 'medium', 'high': 'high', 'max': 'xhigh'}
        effort = _map.get(level, 'medium')
        # exclude=true: модель думает, но COT не возвращает (нам нужен только финальный JSON)
        return {'reasoning': {'effort': effort, 'exclude': True}}

    return {}

# Moon Bridge: бинарь (собранный go build) + config.yml + изолированный CODEX_HOME
MOONBRIDGE_DIR = BASE_DIR.parent / 'moonbridge'
_mb_exe_env = os.getenv('MOONBRIDGE_EXE_PATH', '')
if _mb_exe_env and os.path.exists(_mb_exe_env):
    MOONBRIDGE_EXE_PATH = _mb_exe_env
elif sys.platform == 'win32':
    MOONBRIDGE_EXE_PATH = str(MOONBRIDGE_DIR / 'moonbridge.exe')
else:
    MOONBRIDGE_EXE_PATH = str(MOONBRIDGE_DIR / 'moonbridge')
# Адрес прокси (host:port). Codex ходит на http://<addr>/v1
MOONBRIDGE_ADDR = os.getenv('MOONBRIDGE_ADDR', '127.0.0.1:38440').strip()
# Изолированный CODEX_HOME для DeepSeek-режима (чтобы не трогать пользовательский ~/.codex с OpenAI-авторизацией)
DEEPSEEK_CODEX_HOME = str(MOONBRIDGE_DIR / '_codex_home')


def gpt_provider_is_deepseek() -> bool:
    """True если активен DeepSeek-провайдер (и есть ключ)."""
    return GPT_PROVIDER == 'deepseek' and bool(DEEPSEEK_API_KEY)


def gpt_provider_is_openrouter() -> bool:
    """True если активен OpenRouter-провайдер (и есть ключ)."""
    return GPT_PROVIDER == 'openrouter' and bool(OPENROUTER_API_KEY)


def gpt_provider_is_cliproxy() -> bool:
    """True если активен CLIProxyAPI-провайдер (Gemini Pro через локальный прокси на :8317)."""
    return GPT_PROVIDER == 'cliproxy' and bool(CLIPROXY_API_KEY)


def gpt_provider_is_codex_reseller() -> bool:
    """True если активен Codex/GPT reseller и задан его API-ключ."""
    return GPT_PROVIDER == 'codex_reseller' and bool(CODEX_RESELLER_API_KEY)


def gpt_provider_uses_moonbridge() -> bool:
    """True если текущий провайдер требует Moon Bridge (DeepSeek или OpenRouter)."""
    return gpt_provider_is_deepseek() or gpt_provider_is_openrouter()


def codex_model_for_provider(default_model: str = None) -> str:
    """Имя модели для передачи в codex -m. При DeepSeek/OpenRouter всегда 'moonbridge' (route)."""
    if gpt_provider_uses_moonbridge():
        return 'moonbridge'
    return default_model or GPT_MODEL


def codex_cli_args_for_provider(provider: str = None) -> list:
    """Codex CLI args that keep the OpenAI subscription route isolated from custom providers."""
    active_provider = (provider or GPT_PROVIDER or 'openai').strip().lower()
    if active_provider == 'openai':
        return ['--ignore-user-config', '-c', 'model_provider="openai"']
    return []


def codex_env_for_provider(base_env: dict = None, provider: str = None) -> dict:
    """Окружение для subprocess codex. При DeepSeek/OpenRouter подменяет CODEX_HOME на
    изолированный (с config.toml, указывающим на Moon Bridge).
    Если задан CODEX_PROXY — весь трафик codex.exe (Node) идёт через него (обход гео-блока
    ChatGPT без Proxifier). Ставим и UPPER, и lower варианты — Node/разные либы читают по-разному."""
    env = dict(base_env if base_env is not None else os.environ)
    active_provider = (provider or GPT_PROVIDER or 'openai').strip().lower()
    uses_moonbridge = (
        (active_provider == 'deepseek' and bool(DEEPSEEK_API_KEY))
        or (active_provider == 'openrouter' and bool(OPENROUTER_API_KEY))
    )
    if uses_moonbridge:
        env['CODEX_HOME'] = DEEPSEEK_CODEX_HOME
    _px = CODEX_PROXY
    if _px:
        for _k in ('HTTPS_PROXY', 'https_proxy', 'HTTP_PROXY', 'http_proxy', 'ALL_PROXY', 'all_proxy'):
            env[_k] = _px
        # localhost мимо прокси (свои cliproxy-инстансы и callback)
        env.setdefault('NO_PROXY', '127.0.0.1,localhost')
        env.setdefault('no_proxy', '127.0.0.1,localhost')
    return env


# VEO style guide для Codex adapt (дефолт = универсальный, можно заменить в GUI)
VEO_ADAPT_STYLE_GUIDE = os.getenv('VEO_ADAPT_STYLE_GUIDE',
    str(BASE_DIR.parent / 'prompts_other' / 'VEO_I2V_UNIVERSAL_STYLE_v1.md'))

# Claude web chat (unofficial claude-api package).
# Prefer CLAUDE_COOKIE_JSON with a browser-exported JSON file. CLAUDE_COOKIE can
# hold a raw "name=value; name2=value2" Cookie header as a fallback.
CLAUDE_COOKIE_JSON = os.getenv('CLAUDE_COOKIE_JSON', '')
CLAUDE_COOKIE = os.getenv('CLAUDE_COOKIE', '')
CLAUDE_WORK_DIR = os.getenv('CLAUDE_WORK_DIR', '')

# ============================================================================
# ТАРИФЫ GEMINI API (на 2026-03-29)
# ============================================================================
# Источник: https://ai.google.dev/pricing
#
# gemini-3-flash-preview:    $0.50 in / $3.00 out  — быстрая, дешёвая
# gemini-2.5-pro:            $1.25 in / $10.00 out (>200K: $2.50/$15.00)
# gemini-3.1-pro-low:    $2.00 in / $12.00 out — флагман
#
# gemini-3-pro-preview: DEPRECATED 2026-03-09, shut down
# ============================================================================

GEMINI_PRICING = {
    'gemini-3-flash-preview': {
        'input': 0.50,
        'output': 3.00,
    },
    'gemini-2.5-flash': {
        'input': 0.075,
        'output': 0.30,
    },
    'gemini-2.5-pro': {
        'input': 1.25,
        'output': 10.00,
    },
    'gemini-3.1-pro-low': {
        'input': 2.00,
        'output': 12.00,
    },
}

# ============================================================================
# НАСТРОЙКИ TTS (Text-to-Speech / Озвучка)
# ============================================================================

# Сервис озвучки: 'csv666' | 'mat3u'
TTS_SERVICE = os.getenv('TTS_SERVICE', 'mat3u')

# API ключи
TTS_API_KEY_CSV666 = os.getenv('TTS_API_KEY_CSV666', '')
TTS_API_KEY_MAT3U  = os.getenv('TTS_API_KEY_MAT3U', '')

# --- Настройки csv666 (voiceapi.csv666.ru) ---
TTS_CSV666_CHUNK_SIZE    = int(os.getenv('TTS_CSV666_CHUNK_SIZE', '1000'))
TTS_CSV666_OUTPUT_FORMAT = os.getenv('TTS_CSV666_OUTPUT_FORMAT', 'mp3')  # mp3 | zip

# --- Настройки mat3u (voicer.mat3u.com) ---
TTS_MAT3U_MODEL_ID             = os.getenv('TTS_MAT3U_MODEL_ID', 'eleven_multilingual_v2')
TTS_MAT3U_SPLIT_TYPE           = os.getenv('TTS_MAT3U_SPLIT_TYPE', 'smart')       # smart|sentences|paragraphs|max_length
TTS_MAT3U_MAX_CHUNK_LENGTH     = int(os.getenv('TTS_MAT3U_MAX_CHUNK_LENGTH', '1000'))  # 100-1000
TTS_MAT3U_SPLIT_OUTPUT         = os.getenv('TTS_MAT3U_SPLIT_OUTPUT', 'false').lower() in ('true', '1', 'yes')
TTS_MAT3U_AUTO_PAUSE_ENABLED   = os.getenv('TTS_MAT3U_AUTO_PAUSE_ENABLED', 'false').lower() in ('true', '1', 'yes')
TTS_MAT3U_AUTO_PAUSE_DURATION  = float(os.getenv('TTS_MAT3U_AUTO_PAUSE_DURATION', '0.5'))
TTS_MAT3U_AUTO_PAUSE_FREQUENCY = int(os.getenv('TTS_MAT3U_AUTO_PAUSE_FREQUENCY', '1'))

# ============================================================================
# НАСТРОЙКИ YT PACKER (YouTube-упаковщик)
# ============================================================================

# Языки (через запятую). Первый = исходный язык транскрипции
_yt_langs_raw = os.getenv('YT_PACK_LANGUAGES', 'ru,en')
YT_PACK_LANGUAGES = [lang.strip() for lang in _yt_langs_raw.split(',') if lang.strip()]

# Оператор YT Packer (заголовки/описание/теги/перевод). Пусто → определяется по имени модели
# (gpt-* → Codex, иначе Gemini) — старое поведение. Явный выбор:
#   gemini | codex | cliproxy | deepseek | openrouter | claude_api
YT_PACK_BACKEND = (os.getenv('YT_PACK_BACKEND', '') or '').strip().lower()
# Модель Gemini по умолчанию (используется как fallback для перевода и контента)
YT_PACK_MODEL = _model('YT_PACK_MODEL', 'gemini-2.5-flash')
# Модель для перевода субтитров (можно дешевле — flash/flash-lite)
YT_PACK_TRANSLATE_MODEL = _model('YT_PACK_TRANSLATE_MODEL') or YT_PACK_MODEL
# Модель для контента: заголовки, описание, теги, промпты обложек (можно мощнее — pro)
YT_PACK_CONTENT_MODEL = _model('YT_PACK_CONTENT_MODEL') or YT_PACK_MODEL

# Переключатели подэтапов
YT_PACK_SUBTITLES = os.getenv('YT_PACK_SUBTITLES', 'true').lower() in ('true', '1', 'yes')

# Длина фразы субтитров (для subtitles.srt, выжигаемых конкатом).
# UNIT=chars → по символам (дефолт 50). UNIT=words → по СЛОВАМ (1 = каждое слово отдельным
# субтитром, динамичная смена по слову). Задаётся в GUI (блок Subtitles).
SUBTITLE_PHRASE_UNIT = (os.getenv('SUBTITLE_PHRASE_UNIT', 'chars').strip().lower()
                        if os.getenv('SUBTITLE_PHRASE_UNIT', 'chars').strip().lower() in ('chars', 'words')
                        else 'chars')
try:
    SUBTITLE_PHRASE_LEN = int(os.getenv('SUBTITLE_PHRASE_LEN', '') or ('50' if SUBTITLE_PHRASE_UNIT == 'chars' else '1'))
except ValueError:
    SUBTITLE_PHRASE_LEN = 50 if SUBTITLE_PHRASE_UNIT == 'chars' else 1
YT_PACK_DESCRIPTION = os.getenv('YT_PACK_DESCRIPTION', 'true').lower() in ('true', '1', 'yes')
YT_PACK_COVERS = os.getenv('YT_PACK_COVERS', 'true').lower() in ('true', '1', 'yes')

# Настройки обложек
YT_PACK_COVER_PROVIDER = os.getenv('YT_PACK_COVER_PROVIDER', 'fastgen')  # fastgen | veononstop
YT_PACK_COVER_MODEL = _model('YT_PACK_COVER_MODEL', 'GEM_PIX_2')
YT_PACK_COVER_COUNT = int(os.getenv('YT_PACK_COVER_COUNT', '4'))

# ============================================================================
# НАСТРОЙКИ FASTGEN API (генерация изображений)
# ============================================================================

# API ключ FastGen (основной)
FASTGEN_API_KEY = os.getenv('FASTGEN_API_KEY', '')

# Резервный API ключ FastGen (используется когда основной исчерпал квоту/лицензию)
# Если не задан — fallback на основной ключ (чтобы auto-switch не падал)
FASTGEN_API_KEY_BACKUP = os.getenv('FASTGEN_API_KEY_BACKUP', '') or FASTGEN_API_KEY

# Второй API ключ FastGen (dual-key: параллельная работа двумя аккаунтами)
# Если FASTGEN_API_KEY_2 не задан — fallback на FASTGEN_API_KEY_BACKUP
FASTGEN_API_KEY_2 = os.getenv('FASTGEN_API_KEY_2', '') or os.getenv('FASTGEN_API_KEY_BACKUP', '')
FASTGEN_MAX_PARALLEL_2 = int(os.getenv('FASTGEN_MAX_PARALLEL_2',
                                        os.getenv('FASTGEN_MAX_PARALLEL', '25')))

# Дополнительные API ключи FastGen для multi-key ImageGen worker pool.
FASTGEN_API_KEY_3 = os.getenv('FASTGEN_API_KEY_3', '')
FASTGEN_API_KEY_4 = os.getenv('FASTGEN_API_KEY_4', '')
FASTGEN_MAX_PARALLEL_3 = int(os.getenv('FASTGEN_MAX_PARALLEL_3',
                                        os.getenv('FASTGEN_MAX_PARALLEL', '25')))
FASTGEN_MAX_PARALLEL_4 = int(os.getenv('FASTGEN_MAX_PARALLEL_4',
                                        os.getenv('FASTGEN_MAX_PARALLEL', '25')))

# Базовые URL
FASTGEN_API_BASE = 'https://api.fast-gen.ai/api'
FASTGEN_STORAGE_URL = 'https://storage.fast-gen.ai'

# Движок/модель генерации изображений:
#   Flow API:  GEM_PIX_2 (Nano Pro, рекомендуется), GEM_PIX (Nano), IMAGEN_3_5, NARWHAL (Nano Banana 2), FLOWER (Nano Banana 2 via Flower)
#   Gemini:    GEMINI  (Gemini native, быстрый)
#   Grok:      GROK    (Grok, возвращает 4 варианта)
#   Whisk:     WHISK   (Whisk, категоризированные рефы subject/scene/style)
FASTGEN_MODEL = os.getenv('FASTGEN_MODEL', 'FLOWER')
# Мёртвые движки (API V6: провайдеров gemini/whisk/imagen нет → 404). Авто-миграция
# старых .env на FLOWER (flower_image_generate, 1 credit — дефолт).
if FASTGEN_MODEL in ('GEMINI', 'WHISK', 'IMAGEN_3_5'):
    FASTGEN_MODEL = 'FLOWER'

# Соотношение сторон: portrait, landscape, square
FASTGEN_ASPECT_RATIO = os.getenv('FASTGEN_ASPECT_RATIO', 'landscape')

# Максимум параллельных генераций
FASTGEN_MAX_PARALLEL = int(os.getenv('FASTGEN_MAX_PARALLEL', '25'))

# Интервал поллинга статуса (секунды)
FASTGEN_POLL_INTERVAL = 8

# Таймаут ожидания одной генерации (секунды)
FASTGEN_POLL_TIMEOUT = 300

# Количество повторных попыток при ошибках
FASTGEN_MAX_RETRIES = 3

# Предполётная проверка рефов: тест до начала генерации (True = включена)
FASTGEN_PREFLIGHT_REFS = os.getenv('FASTGEN_PREFLIGHT_REFS', 'true').lower() in ('true', '1', 'yes')

# Автоматический Grok-ремикс заблокированных рефов и цензурированных i2v кадров
FASTGEN_GROK_REMIX = os.getenv('FASTGEN_GROK_REMIX', 'true').lower() in ('true', '1', 'yes')

# ============================================================================
# НАСТРОЙКИ KIE.AI (ремиксер рефов и i2v кадров)
# ============================================================================

# API ключ Kie.ai (https://kie.ai)
KIE_AI_API_KEY = os.getenv('KIE_AI_API_KEY', '')

# Kie.ai ремикс включён если задан ключ
KIE_AI_REMIX = bool(KIE_AI_API_KEY)

# Выбор ремиксера: 'kieai' или 'grok'
REMIX_ENGINE = os.getenv('REMIX_ENGINE', 'grok').lower()

# Хотя бы один ремиксер доступен (KieAI или Grok)
REMIX_AVAILABLE = KIE_AI_REMIX or FASTGEN_GROK_REMIX

# ============================================================================
# НАСТРОЙКИ VEONONSTOP API (видеогенерация + картинки)
# ============================================================================

# API ключ VeoNonStop (https://veononstop.org)
VEONONSTOP_API_KEY = os.getenv('VEONONSTOP_API_KEY', '')
# Второй API ключ (опционально): если задан — задачи распределяются round-robin
VEONONSTOP_API_KEY_2 = os.getenv('VEONONSTOP_API_KEY_2', '')
VEONONSTOP_MAX_PARALLEL_2 = int(os.getenv('VEONONSTOP_MAX_PARALLEL_2',
                                           os.getenv('VEONONSTOP_MAX_PARALLEL', '4')))
# Третий API ключ (опционально)
VEONONSTOP_API_KEY_3 = os.getenv('VEONONSTOP_API_KEY_3', '')
VEONONSTOP_MAX_PARALLEL_3 = int(os.getenv('VEONONSTOP_MAX_PARALLEL_3',
                                           os.getenv('VEONONSTOP_MAX_PARALLEL', '4')))
# Четвёртый API ключ (опционально)
VEONONSTOP_API_KEY_4 = os.getenv('VEONONSTOP_API_KEY_4', '')
VEONONSTOP_MAX_PARALLEL_4 = int(os.getenv('VEONONSTOP_MAX_PARALLEL_4',
                                           os.getenv('VEONONSTOP_MAX_PARALLEL', '4')))
# Названия планов для Key1-Key4 (показываются в GUI)
VEONONSTOP_KEY1_NAME = os.getenv('VEONONSTOP_KEY1_NAME', 'Key1')
VEONONSTOP_KEY2_NAME = os.getenv('VEONONSTOP_KEY2_NAME', 'Key2')
VEONONSTOP_KEY3_NAME = os.getenv('VEONONSTOP_KEY3_NAME', 'Key3')
VEONONSTOP_KEY4_NAME = os.getenv('VEONONSTOP_KEY4_NAME', 'Key4')

# Базовый URL API (можно переопределить через env для переключения хоста)
# Варианты: 'https://veononstop.org/api/v1' | 'https://viet.veo.kotsklad.ru/api/v1'
VEONONSTOP_API_BASE = os.getenv('VEONONSTOP_API_BASE', 'https://veononstop.org/api/v1').strip()
# Per-key base URL override. Пусто → fallback на VEONONSTOP_API_BASE.
# Позволяет использовать разные URL для разных ключей одновременно.
VEONONSTOP_API_BASE_2 = (os.getenv('VEONONSTOP_API_BASE_2', '') or '').strip() or VEONONSTOP_API_BASE
VEONONSTOP_API_BASE_3 = (os.getenv('VEONONSTOP_API_BASE_3', '') or '').strip() or VEONONSTOP_API_BASE
VEONONSTOP_API_BASE_4 = (os.getenv('VEONONSTOP_API_BASE_4', '') or '').strip() or VEONONSTOP_API_BASE

# Параллельных задач (default=4, max=concurrent_tasks из API).
# 4 — безопасное значение без slots_full. Можно повысить через .env до 12.
VEONONSTOP_MAX_PARALLEL = int(os.getenv('VEONONSTOP_MAX_PARALLEL', '4'))

# Соотношение сторон видео/картинок: 16:9, 9:16, 1:1
VEONONSTOP_ASPECT_RATIO = os.getenv('VEONONSTOP_ASPECT_RATIO', '16:9')

# Режим imggen: imagen, banana, banana_ref
VEONONSTOP_IMGGEN_MODE = os.getenv('VEONONSTOP_IMGGEN_MODE', 'banana')

# Интервал поллинга статуса (секунды)
VEONONSTOP_POLL_INTERVAL = int(os.getenv('VEONONSTOP_POLL_INTERVAL', '10'))

# Таймаут ожидания одной задачи (секунды, 30 мин по умолчанию)
VEONONSTOP_POLL_TIMEOUT = int(os.getenv('VEONONSTOP_POLL_TIMEOUT', '') or '180')

# Модель Banana VeoNonStop imggen: GEM_PIX_2 (Pro, дефолт) | NARWHAL (Banana 2) | HARBOR_SEAL (Banana 2 Lite)
VEONONSTOP_BANANA_MODEL = os.getenv('VEONONSTOP_BANANA_MODEL', 'GEM_PIX_2')

# Режим применения рефов: name_match (по именам из промпта) или use_all (все рефы на каждый промпт)
VEONONSTOP_REF_MODE = os.getenv('VEONONSTOP_REF_MODE', 'name_match')

# Задержка между запросами воркеров (секунды). Увеличь если много reCAPTCHA ошибок.
# 3.0 = 24 воркера стартуют за 72с (было 10.0 = 230с). Уменьши если нужен более плотный старт.
VEONONSTOP_REQUEST_DELAY = float(os.getenv('VEONONSTOP_REQUEST_DELAY', '3.0'))

# Макс. попыток на шаг генерации (Phase 1 и каждый шаг цепочки при техн. ошибке)
VEONONSTOP_MAX_RETRIES = int(os.getenv('VEONONSTOP_MAX_RETRIES', '') or '5')

# Макс. server-timeout ретраев на клип (после превышения — тратим попытку, идём к static fallback)
VEONONSTOP_MAX_TIMEOUT_RETRIES = int(os.getenv('VEONONSTOP_MAX_TIMEOUT_RETRIES', '') or '5')

# Повторные запуски в silent режиме (для клипов с техн. ошибками)
VEONONSTOP_MAX_SILENT_CYCLES = int(os.getenv('VEONONSTOP_MAX_SILENT_CYCLES', '5'))
VEONONSTOP_MAX_RESUBMITS       = int(os.getenv('VEONONSTOP_MAX_RESUBMITS', '') or '3')
VEONONSTOP_RECAPTCHA_DELAY     = float(os.getenv('VEONONSTOP_RECAPTCHA_DELAY', '8.0'))   # base delay (s) before reCAPTCHA retry
VEONONSTOP_RECAPTCHA_JITTER    = float(os.getenv('VEONONSTOP_RECAPTCHA_JITTER', '3.0'))  # max jitter (s) added to base

# Режим быстрой цензуры: off | after_rewrites | ultrafast
#   off            — полная цепочка (реврайты + ремиксы + минималистик)
#   after_rewrites — реврайты да, ремиксы нет, сразу static fallback
#   ultrafast      — сразу static fallback без реврайтов и ремиксов
VEONONSTOP_FAST_CENSOR = os.getenv('VEONONSTOP_FAST_CENSOR', 'off').lower()

# Апскейл изображений после генерации: off | 2K | 4K
VEONONSTOP_IMAGE_UPSCALE = os.getenv('VEONONSTOP_IMAGE_UPSCALE', 'off').lower()

# Апскейл видео после генерации (1080p): true/false
VEONONSTOP_VIDEO_UPSCALE = os.getenv('VEONONSTOP_VIDEO_UPSCALE', '').lower() in ('true', '1', 'yes')

# ============================================================================
# НАСТРОЙКИ ВИДЕО
# ============================================================================

# Длительность одного фрагмента (секунды)
VIDEO_FRAGMENT_DURATION = 8.0

# FPS для финального видео
VIDEO_FPS = 60

# ============================================================================
# ДЛИТЕЛЬНОСТЬ КЛИПОВ МОНТАЖНОГО ПЛАНА
# ============================================================================

# Видеорежим (Veo3-фрагменты)
VIDEO_CLIP_MIN_DURATION    = int(os.getenv('VIDEO_CLIP_MIN_DURATION',    '4'))
VIDEO_CLIP_MAX_DURATION    = int(os.getenv('VIDEO_CLIP_MAX_DURATION',    '8'))

# Слайдшоурежим (картинки)
SLIDESHOW_CLIP_MIN_DURATION = int(os.getenv('SLIDESHOW_CLIP_MIN_DURATION', '2'))
SLIDESHOW_CLIP_MAX_DURATION = int(os.getenv('SLIDESHOW_CLIP_MAX_DURATION', '7'))

# Активный режим — выставляется агентом при старте (по умолчанию видео)
ACTIVE_CLIP_MIN_DURATION = VIDEO_CLIP_MIN_DURATION
ACTIVE_CLIP_MAX_DURATION = VIDEO_CLIP_MAX_DURATION

# ============================================================================
# ВСТУПИТЕЛЬНЫЙ БЛОК (intro)
# ============================================================================

# Длительность вступительной зоны таймлайна (секунды)
# Все клипы до этой отметки используют intro-настройки длительности
INTRO_BLOCK_DURATION = int(os.getenv('INTRO_BLOCK_DURATION', '30'))

# Мин/макс длительность клипов во вступительном блоке (0 = авто)
# Если 0 — берётся из ACTIVE с ограничением max≤7
INTRO_CLIP_MIN_DURATION = int(os.getenv('INTRO_CLIP_MIN_DURATION', '0'))
INTRO_CLIP_MAX_DURATION = int(os.getenv('INTRO_CLIP_MAX_DURATION', '0'))


def get_intro_clip_min():
    return INTRO_CLIP_MIN_DURATION if INTRO_CLIP_MIN_DURATION > 0 else ACTIVE_CLIP_MIN_DURATION


def get_intro_clip_max():
    return INTRO_CLIP_MAX_DURATION if INTRO_CLIP_MAX_DURATION > 0 else min(7, ACTIVE_CLIP_MAX_DURATION)

# ============================================================================
# ZOOM на статичных кадрах (video_concat: Ken Burns)
# ============================================================================
# Амплитуда зума за клип (0.05 / 0.10 / 0.15 / 0.20)
try:
    ZOOM_AMOUNT = float(os.getenv('ZOOM_AMOUNT', '0.10'))
except (TypeError, ValueError):
    ZOOM_AMOUNT = 0.10
# Кривая времени (linear / constant_speed / ease_out)
ZOOM_CURVE = os.getenv('ZOOM_CURVE', 'linear')

# ============================================================================
# НАСТРОЙКИ ЛОГГИРОВАНИЯ
# ============================================================================

# Уровень логгирования
LOG_LEVEL = 'DEBUG'  # 'DEBUG', 'INFO', 'WARNING', 'ERROR'

# Формат логов
LOG_FORMAT = '%(asctime)s | %(levelname)-8s | %(message)s'

# ============================================================================
# НАСТРОЙКИ GUI ПАЙПЛАЙНА (умолчания вкладки Pipeline Launcher)
# ============================================================================

# Точка старта: audio | script
PIPELINE_START_POINT  = os.getenv('PIPELINE_START_POINT', '') or 'audio'
# Режим клипов: video | slideshow | vislide
PIPELINE_CLIP_MODE         = os.getenv('PIPELINE_CLIP_MODE', '') or 'video'
PIPELINE_VISLIDE_INTERVAL  = int(os.getenv('PIPELINE_VISLIDE_INTERVAL', '') or '3')
# Источник изображений: fastgen | veononstop | skip
PIPELINE_IMG_GEN      = os.getenv('PIPELINE_IMG_GEN', '') or 'veononstop'
# Режим видеогенерации: i2v | t2v | components | skip
PIPELINE_VIDEO_MODE   = os.getenv('PIPELINE_VIDEO_MODE', '') or 'i2v'
# Режим промптов: single | per_clip
PIPELINE_PROMPT_MODE  = os.getenv('PIPELINE_PROMPT_MODE', '') or 'single'
# Рендер: 720p | 1080p | fast
PIPELINE_RENDER_MODE  = os.getenv('PIPELINE_RENDER_MODE', '') or '720p'
# Ватермарка: as_is | blur_borders | skip
PIPELINE_WATERMARK    = os.getenv('PIPELINE_WATERMARK', '') or 'as_is'
# Переходы между клипами (dip-to-X) + Ken Burns zoom-стиль — опции video_concat (дефолт выкл/старое)
PIPELINE_TRANSITIONS  = (os.getenv('PIPELINE_TRANSITIONS', '') or 'false').lower() in ('true', '1', 'yes')
PIPELINE_TRANSITION_DURATION = float(os.getenv('PIPELINE_TRANSITION_DURATION', '') or 0.5)
PIPELINE_TRANSITION_STYLES   = os.getenv('PIPELINE_TRANSITION_STYLES', '') or 'fade'
PIPELINE_ZOOM_STYLES  = os.getenv('PIPELINE_ZOOM_STYLES', '') or 'in-center'
# Оставить ретайминг файлы: true | false
PIPELINE_KEEP_FILES   = (os.getenv('PIPELINE_KEEP_FILES', '') or 'false').lower() in ('true', '1', 'yes')
# Оставить оригинальный звук из Veo-видео: true | false
PIPELINE_KEEP_VEO_SOUND = (os.getenv('PIPELINE_KEEP_VEO_SOUND', '') or 'false').lower() in ('true', '1', 'yes')
# Очередь склейки: хвост пайплайна (музыка+concat) уходит в фоновую последовательную
# очередь (Control Panel), оркестратор сразу берёт следующий файл. false = старый
# inline-путь (склейка блокирует очередь генерации до завершения).
CONCAT_QUEUE_ENABLED  = (os.getenv('CONCAT_QUEUE_ENABLED', '') or 'true').lower() in ('true', '1', 'yes')

# ============================================================================
# WATERMARK REMOVAL
# ============================================================================
# Audio AI fingerprint removal (ai-audio-fingerprint-remover)
AUDIO_CLEAN_ENABLED  = os.getenv('AUDIO_CLEAN_ENABLED',  'false').lower() in ('true', '1', 'yes')
AUDIO_CLEAN_LEVEL    = os.getenv('AUDIO_CLEAN_LEVEL',    'moderate')  # gentle|moderate|aggressive|extreme

# SynthID image watermark removal (reverse-SynthID)
SYNTHID_CLEAN_ENABLED = os.getenv('SYNTHID_CLEAN_ENABLED', 'false').lower() in ('true', '1', 'yes')
SYNTHID_STRENGTH      = os.getenv('SYNTHID_STRENGTH',      'moderate')  # gentle|moderate|aggressive|extreme
SYNTHID_VERSION       = os.getenv('SYNTHID_VERSION',       'v1')        # v1|v2|v3
SYNTHID_SAVE_ORIG     = os.getenv('SYNTHID_SAVE_ORIG',     'false').lower() in ('true', '1', 'yes')

# ============================================================================
# REAL PHOTO STAGE (archival photo/video insertion)
# ============================================================================
# Replace AI-generated imagery with real archival material from PD/CC sources
# (Wikimedia / NASA / Library of Congress / Internet Archive) for selected clips.
# Stage runs between Director and ImgGen. Produces vid_img/{id}.mp4 directly,
# so ImgGen and Veo i2v skip these clips automatically.

REAL_PHOTO_ENABLED       = os.getenv('REAL_PHOTO_ENABLED',       'false').lower() in ('true', '1', 'yes')
REAL_PHOTO_RATIO_TARGET  = float(os.getenv('REAL_PHOTO_RATIO_TARGET', '0.40'))   # target % of clips to replace
REAL_PHOTO_RATIO_MIN     = float(os.getenv('REAL_PHOTO_RATIO_MIN',    '0.30'))   # hard floor
REAL_PHOTO_RATIO_MAX     = float(os.getenv('REAL_PHOTO_RATIO_MAX',    '0.55'))   # hard ceiling
# Архив-фото легитимны только с этой секунды ролика. Клипы раньше неё (вступительный хук —
# динамичные атмосферные кадры) режиссёр часто ошибочно метит под архив, потому что интро
# насыщено топонимами. Гейт снимает маркер с таких клипов → они идут в обычную генерацию.
# 0 = выключено (метить с самого начала). Дефолт 15 ≈ зона «динамичного вступления» Pass1.
REAL_PHOTO_START_SEC     = float(os.getenv('REAL_PHOTO_START_SEC',    '15'))
# Глубина выдачи АРХИВНЫХ источников (wikimedia/nasa/loc/met/getty/europeana/smithsonian/archive):
# сколько записей/статей копнуть в каждом, прежде чем перейти к следующему источнику каскада.
# Для wikimedia это число вики-СТАТЕЙ (берём pageimage каждой, дедуп по странице → «иная статья»).
# Yandex — веб-хранилище картинок, глубину «статей» к нему не применяем (берёт топ релевантных).
REAL_PHOTO_SEARCH_DEPTH  = max(1, int(os.getenv('REAL_PHOTO_SEARCH_DEPTH', '6') or '6'))

# Comma-separated source list; order = priority.
# Allowed: wikimedia, nasa, loc, met, getty, europeana, smithsonian, rijksmuseum, archive
# - wikimedia, nasa, loc, met, getty — no API key needed
# - europeana                        — free key from https://pro.europeana.eu/page/get-api
# - smithsonian                      — free key from https://api.data.gov/signup/
# - rijksmuseum                      — FROZEN (legacy API requires key, new API needs Linked Art rewrite)
# - archive                          — Internet Archive (archive.org), no key needed
_real_photo_sources_raw  = os.getenv('REAL_PHOTO_SOURCES', 'wikimedia,yandex,nasa,loc,met,getty,europeana,smithsonian,archive')
REAL_PHOTO_SOURCES       = [s.strip() for s in _real_photo_sources_raw.split(',') if s.strip()]
# Yandex Картинки: минус-флаги исключения AI/3D-генераций из выдачи (гравюры/карты/схемы НЕ режем)
REAL_PHOTO_YANDEX_EXCLUDE = os.getenv('REAL_PHOTO_YANDEX_EXCLUDE', '') or '-нейросеть -нейро -ии -ai -midjourney -render -3d -рендер'

# Optional API keys for extra sources (leave blank if not registered)
EUROPEANA_API_KEY        = os.getenv('EUROPEANA_API_KEY',        '').strip()
SMITHSONIAN_API_KEY      = os.getenv('SMITHSONIAN_API_KEY',      '').strip()
RIJKSMUSEUM_API_KEY      = os.getenv('RIJKSMUSEUM_API_KEY',      '').strip()

# Codex model for selection + keyframe pick + fallback queries.
# Real Photo stage prefers gpt-5.5 (better at structured output and rejecting weak candidates).
# Override in .env if needed; leave the env var blank to inherit the global GPT_MODEL.
REAL_PHOTO_CODEX_MODEL   = os.getenv('REAL_PHOTO_CODEX_MODEL',   'gpt-5.5').strip()
# Оператор промптажа Real Photo (генерация search_query + альтернатив при 0 hits).
# НЕ зависит от выбранного режиссёра — задаётся отдельно в GUI/env.
#   codex      — Codex CLI (агент, пишет файлы; падает если CLI не установлен/не авторизован)
#   cliproxy   — CLIProxyAPI (Gemini/Claude через локальный прокси)
#   deepseek | openrouter — прямой chat API
# chat-провайдеры надёжнее (inline, без агента и файловой системы).
REAL_PHOTO_PROMPT_PROVIDER = (os.getenv('REAL_PHOTO_PROMPT_PROVIDER', '') or 'codex').strip().lower()
# Модель промптера. Пусто → дефолт выбранного провайдера (CLIPROXY_MODEL / DEEPSEEK_MODEL / ...).
REAL_PHOTO_PROMPT_MODEL    = os.getenv('REAL_PHOTO_PROMPT_MODEL', '').strip()
# Cache lives inside each project at <project>/real_photo_cache/. No global limit needed —
# caches are bounded by project lifetime and disposed when project is deleted.

# Fallback-страховка: Pass 2 пишет промпты ДЛЯ ВСЕХ клипов (включая real_photo_pending).
# Если real_photo не нашёл/не скачал/завис — клип догенерится нейросетью по готовому
# промпту (картинкой, без анимации). 1=вкл (дефолт). 0=старое поведение (Pass2 скип).
REAL_PHOTO_PROMPT_FALLBACK = (os.getenv('REAL_PHOTO_PROMPT_FALLBACK', '') or '1').strip() not in ('0', 'false', 'no', '')
# Макс. ожидание фонового real_photo-потока перед тем как идти дальше (сек). По истечении
# недокачанные клипы догенерятся нейросетью (промпт готов). Защита от вечного зависания.
REAL_PHOTO_WAIT_TIMEOUT  = int(os.getenv('REAL_PHOTO_WAIT_TIMEOUT', '1800'))

# ============================================================================
# CHAIN MODE (seamless video continuation)
# ============================================================================
# Story mode: off=independent clips, batch=morph between imggen pairs,
#             morph=one big chain (all extends), chain=LLM-decided chains
STORY_MODE = os.getenv('STORY_MODE', 'off').lower()

# Gen images only for chain heads (skip imggen for extends) — saves ~85% imggen
CHAIN_IMGGEN_HEADS_ONLY = os.getenv('CHAIN_IMGGEN_HEADS_ONLY', '1').lower() in ('true', '1', 'yes')

# Seconds from end to extract last frame (ffmpeg -sseof offset)
VIDEO_EXTEND_FRAME_OFFSET = float(os.getenv('VIDEO_EXTEND_FRAME_OFFSET', '0.5'))

# video_concat.py: skip N first frames of extend clips (fps-independent via select filter)
VIDEO_EXTEND_TRIM_FRAMES = int(os.getenv('VIDEO_EXTEND_TRIM_FRAMES', '1'))

# Mute audio for extend clips (VEO sound artifacts on each extend start)
VIDEO_EXTEND_MUTE_AUDIO = os.getenv('VIDEO_EXTEND_MUTE_AUDIO', '1').lower() in ('true', '1', 'yes')

# Soft safety net: max clips in one chain before forced break (0=unlimited)
VIDEO_EXTEND_MAX_CHAIN = int(os.getenv('VIDEO_EXTEND_MAX_CHAIN', '10'))

# Cascade recovery: regen prev clip on fail instead of immediate force break
CHAIN_CASCADE_RECOVERY = os.getenv('CHAIN_CASCADE_RECOVERY', '1').lower() in ('true', '1', 'yes')

# Max fails of same clip before forced sub-chain head (prevents infinite loop)
CHAIN_MAX_SAME_CLIP_FAILS = int(os.getenv('CHAIN_MAX_SAME_CLIP_FAILS', '3'))

# ============================================================================
# ПРОВЕРКА КЛЮЧЕЙ
# ============================================================================

def check_api_keys():
    """Проверяет наличие API ключей"""
    errors = []

    if not ASSEMBLYAI_API_KEY:
        errors.append('ASSEMBLYAI_API_KEY не найден в .env')

    if not GEMINI_API_KEY:
        errors.append('GEMINI_API_KEY не найден в .env')

    return errors


def get_model_pricing(model_name: str) -> dict:
    """Возвращает тарифы для указанной модели"""
    return GEMINI_PRICING.get(model_name, {'input': 0.0, 'output': 0.0})


def estimate_cost(input_tokens: int, output_tokens: int, model_name: str) -> dict:
    """
    Оценивает стоимость запроса
    
    Args:
        input_tokens: Количество входных токенов
        output_tokens: Количество выходных токенов
        model_name: Название модели
    
    Returns:
        Словарь с оценкой стоимости
    """
    pricing = get_model_pricing(model_name)
    
    input_cost = (input_tokens / 1_000_000) * pricing['input']
    output_cost = (output_tokens / 1_000_000) * pricing['output']
    total_cost = input_cost + output_cost
    
    return {
        'model': model_name,
        'input_tokens': input_tokens,
        'output_tokens': output_tokens,
        'input_cost': input_cost,
        'output_cost': output_cost,
        'total_cost': total_cost,
    }


# ============================================================================
# СОЗДАНИЕ ДИРЕКТОРИЙ
# ============================================================================

def create_directories():
    """Создаёт необходимые директории"""
    TEMP_DIR.mkdir(exist_ok=True)
    LOGS_DIR.mkdir(exist_ok=True)
    PROMPTS_DIR.mkdir(exist_ok=True)
