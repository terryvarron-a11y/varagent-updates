"""Общий вижн-отбор кандидатов для стадий-источников (сток, архивы real_photo).

Одна реализация на всех (решение 25.08): собрать контактный лист из
кандидатов (видео — три кадра: начало/середина/конец, фото — один кадр),
отдать вижну лист + описание сцены + запреты + запрос, разобрать ответ
{pick, rejected_ids, reasons}. «Никто не подходит» → pick пуст, все в
rejected — вызывающая стадия отдаёт сцену другому источнику.

Модуль не качает файлы и не режет — это делает стадия; он только смотрит.
Артефакты в work_dir: contact_sheet.jpg, frames/, vision_prompt.json,
vision_response.txt, selection.json (или vision_error.json).
"""
from __future__ import annotations

import base64
import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Потолок размера контактного листа (на весь лист, не на кандидата).
_SHEET_MAX_BYTES = 1_200_000


@dataclass
class Candidate:
    candidate_id: str          # C1, C2, …
    path: Path                 # скачанный файл (видео или картинка)
    kind: str = "photo"        # video | photo
    duration: float = 0.0      # для видео — чтобы взять кадры по времени
    title: str = ""
    meta: dict = field(default_factory=dict)


@dataclass
class VisionVerdict:
    pick: Optional[str]                 # candidate_id или None
    rejected_ids: list[str]
    reasons: dict[str, str]
    provider: str = ""
    model: str = ""
    error: str = ""                     # непусто — вижн не отработал (деградация на стороне стадии)


def _panel_font(size: int = 15):
    """Читаемый шрифт для подписи панели; дефолтный bitmap — фолбэк."""
    from PIL import ImageFont

    for name in ("arial.ttf", "DejaVuSans.ttf", "LiberationSans-Regular.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except (OSError, ImportError):
            continue                    # шрифта нет в системе — пробуем следующий
    try:
        return ImageFont.load_default()
    except Exception:  # noqa: BLE001
        return None


def build_contact_sheet(candidates: list[Candidate], output_path: Path) -> Optional[Path]:
    """Один лист на всех: видео — 3 кадра в ряд, фото — один.

    Подпись панели — id И название кандидата (страница источника или имя
    файла). Раньше на панели был только `C1`, а названия шли отдельным списком
    в тексте запроса, и вижн должен был сам сопоставлять картинку со строкой по
    порядку — лишнее звено, где ошибка выглядела бы как обычный вердикт
    (решение пользователя 25.08)."""
    from PIL import Image, ImageDraw
    from modules.youtube_stage import _extract_preview_frame

    panels = []
    frame_dir = output_path.parent / "frames"
    # Размер кадра в листе — от числа кандидатов: на 3-4 штуки можно позволить
    # крупные панели (раньше EPF слал 640 px на кадр — лист не должен быть хуже),
    # на дюжину приходится ужиматься, иначе лист не влезет в лимит.
    count = max(1, len(candidates))
    panel_side = 900 if count <= 4 else (720 if count <= 9 else 560)
    # Почему кандидат не попал в лист — обязано быть в логе. Молчание здесь
    # оборачивалось загадкой «вижн не отработал»: у клипа 15 прогона 26.08 оба
    # кандидата не открылись, лист не собрался, и сцена молча ушла в слепой
    # фолбэк, откуда битый файл попал прямо в кадр.
    skipped: dict[str, int] = {}

    def _skip(reason: str, cand_id: str) -> None:
        skipped[reason] = skipped.get(reason, 0) + 1
        logger.info("   [вижн] кандидат %s не попал в лист: %s", cand_id, reason)

    for cand in candidates:
        if not cand.path:
            _skip("нет файла", cand.candidate_id)
            continue
        if not Path(cand.path).exists():
            _skip("файл не найден на диске", cand.candidate_id)
            continue
        images = []
        if cand.kind == "video":
            duration = max(0.1, float(cand.duration or 0) or 3.0)
            # «Конец» — с запасом: сик в последние 50 мс часто не даёт кадра
            # (контейнер кончается раньше заявленной длительности) — smoke 25.08.
            end_ts = max(0.0, min(duration - 0.5, duration * 0.9))
            for label, ts in (("start", 0.0), ("mid", duration / 2), ("end", end_ts)):
                frame = _extract_preview_frame(Path(cand.path), ts, frame_dir / f"{cand.candidate_id}_{label}.jpg")
                if frame:
                    try:
                        images.append(Image.open(frame).convert("RGB"))
                    except (OSError, ValueError) as exc:
                        logger.warning("   [вижн] кадр %s не открылся (%s) — панель без него",
                                       frame.name, exc)
        else:
            try:
                image = Image.open(cand.path).convert("RGB")
                image.thumbnail((panel_side, panel_side))
                images.append(image)
            except (OSError, ValueError) as exc:
                # Не открылась как изображение: почти всегда это HTML-страница,
                # сохранённая под именем .jpg (защита от хотлинка, редирект).
                logger.info("   [вижн] кандидат %s не открылся: %s",
                            cand.candidate_id, exc)
        if not images:
            _skip("не удалось получить ни одного кадра", cand.candidate_id)
            continue
        width = max(im.width for im in images)
        height = max(im.height for im in images)
        caption_height = 26
        panel = Image.new("RGB", (width * len(images), height + caption_height), "white")
        draw = ImageDraw.Draw(panel)
        font = _panel_font()
        caption = cand.candidate_id
        title = " ".join(str(cand.title or "").split())
        if title:
            # Обрезаем по ширине панели, чтобы подпись не уезжала за край
            limit = max(12, int((panel.width - 16) / 8.2) - len(caption) - 3)
            caption = f"{caption} · {title[:limit]}" + ("…" if len(title) > limit else "")
        draw.text((8, 6), caption, fill="black", font=font)
        for index, im in enumerate(images):
            panel.paste(im, (index * width, caption_height))
        panels.append(panel)
    if not panels:
        details = ", ".join(f"{reason}: {n}" for reason, n in skipped.items()) or "причина не установлена"
        logger.warning(
            "   [вижн] лист не собран: ни один из %d кандидатов не дал кадра (%s)",
            len(candidates), details)
        return None
    if skipped:
        logger.info("   [вижн] в лист попало %d из %d кандидатов (%s)",
                    len(panels), len(candidates),
                    ", ".join(f"{reason}: {n}" for reason, n in skipped.items()))
    # Колонок — по числу кандидатов: 12 штук в две колонки дают «простыню»
    # высотой в шесть рядов, на которой вижн теряет нижние кадры.
    columns = 2 if len(panels) <= 4 else (3 if len(panels) <= 9 else 4)
    rows = (len(panels) + columns - 1) // columns
    pw = max(p.width for p in panels)
    ph = max(p.height for p in panels)
    sheet = Image.new("RGB", (pw * columns, ph * rows), "#d8d8d8")
    for index, panel in enumerate(panels):
        sheet.paste(panel, ((index % columns) * pw, (index // columns) * ph))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    # Предел — на ВЕСЬ лист (а не на каждую картинку, как было в EPF: там бюджет
    # делился на число кандидатов и при 12 штуках падал до 43 КБ и 448 px — на
    # таком мыле вижн не отличает деталей). Сначала жмём качеством, и только
    # если не хватило — уменьшаем лист целиком.
    for quality in (82, 72, 62):
        sheet.save(output_path, format="JPEG", quality=quality, optimize=True)
        if output_path.stat().st_size <= _SHEET_MAX_BYTES:
            return output_path
    scaled = sheet.copy()
    scaled.thumbnail((sheet.width // 2, sheet.height // 2))
    scaled.save(output_path, format="JPEG", quality=70, optimize=True)
    return output_path


# Chat-провайдеры, принимающие картинку в сообщении. CLI-агенты (codex,
# claude_code) сюда не входят: они смотрят лист файлом, а не через chat API, —
# см. `vision_capable`.
VISION_CHAT_PROVIDERS = frozenset({
    "gemini", "cliproxy", "deepseek", "openrouter",
    "meta_muse", "claude_api", "codex_reseller", "gpt_nexus",
})


# Кадр мельче этого по длинной стороне на 1080p — каша: Ken Burns растянет
# его на весь экран. Порог тот же, что у Wikimedia (`_COMMONS_MIN_WIDTH`), но
# теперь по ФАКТУ скачанного файла, а не по метаданным источника.
MIN_FRAME_SIDE = 640


def drop_tiny_images(paths: list[Path], *, min_side: int = MIN_FRAME_SIDE) -> tuple[list[Path], list[tuple[Path, str]]]:
    """(годные, отброшенные) — по фактическому размеру картинки.

    Улов живого прогона 25.08: сцена получила кадр 239×317 — вижн смотрел
    уменьшенную панель контактного листа и оценить оригинал не мог, а в ролике
    это мыло во весь экран.
    """
    from PIL import Image

    kept: list[Path] = []
    dropped: list[tuple[Path, str]] = []
    for path in paths:
        try:
            with Image.open(path) as image:
                width, height = image.size
        except Exception as exc:                      # noqa: BLE001
            dropped.append((path, f"не открылся: {exc}"))
            continue
        if max(width, height) < min_side:
            dropped.append((path, f"{width}x{height}"))
            continue
        kept.append(path)
    return kept, dropped


def normalize_reasons(value) -> dict[str, str]:
    """Причины вижна в единый вид {candidate_id: текст}.

    chat-провайдер отдаёт объект, CLI-агент по схеме — список пар: у structured
    output нет свободных ключей объекта."""
    if isinstance(value, list):
        reasons = {str(item.get("candidate_id", "")).strip(): str(item.get("reason", ""))
                   for item in value if isinstance(item, dict)}
        reasons.pop("", None)
        return reasons
    if isinstance(value, dict):
        return {str(key): str(text) for key, text in value.items()}
    return {}


def vision_capable(provider: str) -> bool:
    """Умеет ли этот оператор СМОТРЕТЬ картинки — единственный источник правды.

    Своих списков стадии больше не держат: у ютуба был свой `CHAT_PROVIDERS`,
    и после того как вижн научился ходить CLI-агентом, стадия продолжала
    считать codex «не умеющим смотреть» и молча выключала проверку кадров
    (улов прогона 25.08)."""
    from modules.text_operator import CLI_AGENTS

    provider = (provider or "").strip().lower()
    return provider in VISION_CHAT_PROVIDERS or provider in CLI_AGENTS


def resolve_vision_provider(stage: str) -> tuple[str, str]:
    """(провайдер, модель) вижна для стадии — СВОЯ настройка, потом общий фолбэк.

    Улов живого теста 25.08: real_photo и сток брали провайдера у ютуб-селектора
    (`YOUTUBE_SELECTOR_PROVIDER`), а он у пользователя стоит в «auto» и
    разворачивается в режиссёрский бэкенд; если тот не chat-провайдер, вижн молча
    не вызывался — стадия брала первого кандидата и никто этого не видел.
      • real_photo / epf → REAL_PHOTO_VISION_PROVIDER + REAL_PHOTO_VISION_MODEL
      • stock            → STOCK_VISION_PROVIDER + STOCK_VISION_MODEL, пусто =
                           «как у Real Photo»
    Последний фолбэк для обоих — ютуб-селектор (если он задан явно).
    Всё это выбирается в GUI, руками в .env лезть не нужно.
    """
    import config
    from modules.text_operator import CLI_AGENTS, _model_for
    from modules.youtube_stage import _selector_provider_model

    def _pair(provider_key: str, model_key: str) -> tuple[str, str]:
        provider = str(getattr(config, provider_key, "") or "").strip().lower()
        model = str(getattr(config, model_key, "") or "").strip()
        if provider in ("", "auto"):
            return "", ""
        # CLI-агенту (Codex на GPT-подписке, Claude Code) модель можно не
        # задавать — он возьмёт свою из настроек режиссёра.
        if not model and provider not in CLI_AGENTS:
            return "", ""
        return provider, model or _model_for(provider)

    stage = (stage or "").split("/")[0].strip().lower()
    chain = (
        [("STOCK_VISION_PROVIDER", "STOCK_VISION_MODEL"),
         ("REAL_PHOTO_VISION_PROVIDER", "REAL_PHOTO_VISION_MODEL")]
        if stage == "stock" else
        [("REAL_PHOTO_VISION_PROVIDER", "REAL_PHOTO_VISION_MODEL")]
    )
    for provider_key, model_key in chain:
        provider, model = _pair(provider_key, model_key)
        if provider:
            return provider, model
    return _selector_provider_model()


def _ask_vision(provider: str, model: str, task: str, sheet: Path,
                work_dir: Optional[Path] = None,
                schema_file: str = "vision_pick.json") -> str:
    """Один вопрос с картинкой.

    Транспорта три: CLI-агент (Codex — GPT-подписка, Claude Code), `gemini`
    через google.genai (у него свой ключ) и общий chat_completion для остальных
    chat-провайдеров. CLI-ветка появилась 25.08 по требованию пользователя —
    контактный лист уходит в `codex exec -i`, ответ пишется файлом по схеме.
    """
    from modules.text_operator import CLI_AGENTS

    if provider in CLI_AGENTS:
        work = Path(work_dir or Path(sheet).parent)
        work.mkdir(parents=True, exist_ok=True)
        result_file = work / "vision_cli_result.json"
        result_file.unlink(missing_ok=True)
        if provider in ("claude_code", "claude"):
            # Claude Code читает картинку сам — путь к листу идёт текстом.
            from modules.claude_code_runner import ClaudeCodeRunner

            task_file = work / "_vision_task.md"
            task_file.write_text(
                task
                + "\n\nThe contact sheet is this image file — open and look at it:\n"
                + Path(sheet).resolve().as_posix()
                + "\n\nWrite the JSON answer to this exact path and print nothing:\n"
                + result_file.resolve().as_posix(),
                encoding="utf-8")
            code, out, err, _ = ClaudeCodeRunner(model_name=model or None, timeout=300).run_task_file(
                task_file, work, label="vision")
            if code != 0:
                raise RuntimeError(f"claude_code vision failed ({code}): {(err or out)[-300:]}")
            if not result_file.exists():
                raise RuntimeError("claude_code vision: result file was not created")
            return result_file.read_text(encoding="utf-8-sig", errors="replace")

        from modules.real_photo import CodexRunner

        runner = CodexRunner(model_name=model or None, timeout=300)
        # Схема отдаёт reasons списком пар: у structured output нет произвольных
        # ключей объекта, а вердикт нужен по КАЖДОМУ кандидату. Схема зависит от
        # задачи: выбрать один кадр (vision_pick) или отранжировать все
        # (vision_rank у ютуба).
        runner.run(task, schema_file, result_file, work, images=[Path(sheet)])
        return result_file.read_text(encoding="utf-8-sig", errors="replace")

    if provider == "gemini":
        from google import genai
        import config

        key = getattr(config, "VISION_API_KEY", "") or getattr(config, "GEMINI_API_KEY", "")
        if not key:
            raise RuntimeError("Gemini vision key is not configured (VISION_API_KEY/GEMINI_API_KEY)")
        response = genai.Client(api_key=key).models.generate_content(
            model=model,
            contents=[{"parts": [
                {"text": task},
                {"inline_data": {"mime_type": "image/jpeg",
                                 "data": base64.b64encode(Path(sheet).read_bytes()).decode("ascii")}},
            ]}],
        )
        return response.text or ""

    from modules.chat_client import chat_completion

    return chat_completion(
        provider, model,
        [{"role": "user", "content": [
            {"type": "text", "text": task},
            {"type": "image_url", "image_url": {"url": "data:image/jpeg;base64,"
                + base64.b64encode(Path(sheet).read_bytes()).decode("ascii")}},
        ]}],
        max_tokens=600, json_mode=True, timeout=240,
    )


def pick_with_vision(
    candidates: list[Candidate],
    *,
    work_dir: Path,
    provider: str,
    model: str,
    scene_brief: str,
    forbidden: list[str],
    search_query: str = "",
    media_kind: str = "photo",
    stage: str = "",
) -> VisionVerdict:
    """Лист → вижн → вердикт. Ошибки не бросает: возвращает verdict.error."""
    from modules.youtube_stage import _parse_json_object

    from modules.text_operator import CLI_AGENTS

    work_dir = Path(work_dir)
    work_dir.mkdir(parents=True, exist_ok=True)
    empty = VisionVerdict(pick=None, rejected_ids=[], reasons={}, provider=provider, model=model)
    # У CLI-агента своя модель из настроек режиссёра — пустое поле не порок.
    if not provider or (not model and provider not in CLI_AGENTS):
        empty.error = "vision provider/model is not configured"
        return empty
    sheet = build_contact_sheet(candidates, work_dir / "contact_sheet.jpg")
    if not sheet:
        empty.error = "contact sheet could not be built"
        return empty

    contract = {
        "stage": stage,
        "scene_brief": scene_brief,
        "must_not_appear": [str(x).replace("_", " ") for x in (forbidden or [])][:8],
        "search_query": search_query,
        "media_type": media_kind,
        "candidates": [{"candidate_id": c.candidate_id, "title": (c.title or "")[:80]} for c in candidates],
        "response_schema": {
            "pick": "C1 or null",
            "rejected_ids": ["C2"],
            "reasons": {"C1": "why it fits the scene brief (kept)", "C2": "what is wrong (rejected)"},
        },
    }
    task = (
        # ДИСКВАЛИФИКАТОР ИДЁТ ПЕРВЫМ. Раньше правило про водяные знаки стояло в
        # конце длинного блока о снисходительности («не бракуй за мелочи»,
        # «отказ стоит целого нового поиска») и вдобавок соседствовало с
        # разрешением на credit line по краю. Вижн честно взвешивал «сцена
        # подходит идеально» против «какие-то знаки» и выбирал соответствие:
        # прогон 26.08, клип 6 — кадр гримёрной, залитый логотипами Vecteezy по
        # всей площади, выбран со словами «fits the dressing-room routine best»,
        # про знаки НЕ сказано ни слова (у соседнего кандидата он их назвал).
        # Знаки на панели были прекрасно видны — дело не в разрешении, а в том,
        # что правило было слабее правила о снисходительности.
        "DISQUALIFIER, check it FIRST and independently of how well the frame "
        "fits: a candidate whose image is covered by stock-agency watermarks — "
        "a logo or wordmark repeated across the picture, or one large mark over "
        "the subject (Vecteezy, Alamy, Shutterstock, Dreamstime, Getty, "
        "iStock, 123RF, Depositphotos and the like) — is UNUSABLE. Such a frame "
        "goes to rejected_ids even when it matches the brief perfectly: the "
        "lettering would be burned into the finished film. This overrides every "
        "leniency rule below — never keep a watermarked frame because nothing "
        "better is available. A single credit line or caption printed along an "
        "edge, above or below the picture, is normal for archive material and "
        "is NOT a watermark: archive photographs routinely carry the archive's "
        "name, a photographer credit or a catalogue number along an edge, and "
        "such a frame is perfectly usable. The test is WHERE the mark sits — "
        "over the picture (unusable) or along its edge (fine).\n\n"
        "Judge each candidate by whether it WORKS for this scene, not by whether "
        "every detail of the brief is visible. The brief describes an idea; a "
        "frame that carries that idea is a keeper even when it lacks incidental "
        "details — aisles, a specific number of people, an exact camera angle, a "
        "prop mentioned in passing. Reject only on a REAL mismatch: the wrong "
        "place (an open-air field where the scene needs a hall), the wrong period, "
        "the wrong person or country, or material that is broken (see below). "
        "The MOMENT is not a mismatch: the same subject caught a minute earlier or "
        "later still shows this scene. A vehicle driving rather than standing "
        "where the brief has it parked, a worker walking up to the machine rather "
        "than already at it, a process one step further along — all of these are "
        "the right frame. Reject on the wrong THING or the wrong KIND of place, "
        "never on the wrong instant of the same event. Nor is a brief's staging a "
        "requirement: it was written for an image generator, so demands like "
        "unmarked equipment, blank packaging or a person posed just so describe a "
        "frame nobody photographed. Real material carries brand names, signage and "
        "lettering on the things themselves — that is life, not a defect, and it "
        "is unrelated to the stock-agency watermarks disqualified above. "
        "Never reject a fitting frame because a minor element of the description "
        "is missing — a rejection costs a whole new search, and the scene may end "
        "up with nothing at all. When the PLACE and the PERIOD are right, the "
        "frame works even if the people or objects the brief mentions are absent: "
        "an archival shot of the right station, hall or street carries the scene. "
        "A missing named person lowers a candidate's rank; it does not reject it. "
        "Choose the single candidate that best illustrates the scene brief. The "
        "contact sheet shows every candidate captioned with its id and the title "
        "of its source page or file; video candidates show three frames (start, "
        "middle, end), photos one frame. The visible content decides whether a "
        "frame fits the brief and the must_not_appear list. The caption carries "
        "the facts the pixels cannot give you — WHO this person is, WHERE and "
        "WHEN it was taken. When the caption names a different person, country "
        "or era than the brief requires, reject that candidate even if the frame "
        "looks perfect: a singer with a microphone captioned 'Madonna' is not the "
        "Polish artist of the brief. A caption that carries no such fact (a file "
        "name assembled from keywords and a code, an auto-generated string) simply "
        "tells you nothing — ignore it, and never let a caption justify a frame "
        "whose visible content does not fit. Reject what is broken as material: "
        "logos, thumbnails, screenshots, previews, icons, AI art. A map, chart, "
        "diagram, flag, poster, magazine page or drawing is LEGITIMATE material, "
        "not a defect: keep it when it conveys what this scene is about — a "
        "border, a route, a place, a period, a scale, a printed source — even if "
        "the brief describes live action the frame does not literally show. "
        "Documentaries illustrate a border with a map all the time. Reject such a "
        "frame only when it says nothing about this scene. When NO "
        "candidate matches the brief, set pick to null and put ALL ids into "
        "rejected_ids — the scene will be covered by another source; never keep a "
        "weak match to fill the slot. reasons: one short visual reason for EVERY "
        "candidate, the picked one included. Return strict JSON only.\n\n"
        + json.dumps(contract, ensure_ascii=False)
    )
    (work_dir / "vision_prompt.json").write_text(json.dumps(contract, ensure_ascii=False, indent=2), encoding="utf-8")
    logger.info(
        "   [вижн/%s] %s/%s (%s) ← лист %s КБ, кандидатов %s%s",
        stage or "?", provider, model or "—",
        "CLI-агент" if provider in CLI_AGENTS else "chat API",
        sheet.stat().st_size // 1024, len(candidates),
        f", запрос «{search_query[:40]}»" if search_query else "")
    try:
        raw = _ask_vision(provider, model, task, sheet, work_dir=work_dir)
        (work_dir / "vision_response.txt").write_text(str(raw or ""), encoding="utf-8")
        parsed = _parse_json_object(raw)
    except Exception as exc:  # noqa: BLE001
        (work_dir / "vision_error.json").write_text(json.dumps({"error": str(exc)}, ensure_ascii=False), encoding="utf-8")
        # Раньше ошибка вижна оседала только в файле, и в логе прогона стадия
        # выглядела здоровой, хотя брала первого попавшегося (улов 25.08).
        logger.warning("   [вижн/%s] %s/%s не ответил: %s — беру первого кандидата",
                       stage or "?", provider, model, str(exc)[:160])
        empty.error = str(exc)
        return empty

    known = {c.candidate_id for c in candidates}
    pick = parsed.get("pick")
    pick = str(pick).strip() if pick else ""
    rejected = sorted({str(x).strip() for x in (parsed.get("rejected_ids") or []) if str(x).strip() in known})
    if pick not in known or pick in rejected:
        pick = ""
    reasons = normalize_reasons(parsed.get("reasons"))
    verdict = VisionVerdict(pick=pick or None, rejected_ids=rejected, reasons=reasons,
                            provider=provider, model=model)
    (work_dir / "selection.json").write_text(json.dumps({
        "provider": provider, "model": model, "pick": verdict.pick, "rejected_ids": rejected,
        "reasons": verdict.reasons,
        "candidates": [{"candidate_id": c.candidate_id, "title": c.title, **c.meta} for c in candidates],
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    if verdict.pick is None:
        logger.info("   [вижн/%s] забракованы все %d: %s", stage or "?", len(candidates),
                    "; ".join(f"{cid} — {str(verdict.reasons.get(cid, ''))[:60]}"
                              for cid in rejected[:3]) or "ответ без выбора")
    else:
        won = next((c for c in candidates if c.candidate_id == verdict.pick), None)
        logger.info("   [вижн/%s] выбран %s «%s» — %s", stage or "?", verdict.pick,
                    (won.title if won else "")[:40],
                    str(verdict.reasons.get(verdict.pick, ""))[:70])
    return verdict
